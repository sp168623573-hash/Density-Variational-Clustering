"""Known-fine pair semantic certificate; no target/UNA labels are fitted."""
import hashlib
import numpy as np
from sklearn.neighbors import NearestNeighbors
from sklearn.ensemble import HistGradientBoostingClassifier

def split(ids,y):
    ref=[];val=[]
    for c in range(9):
        ix=np.flatnonzero(y==c);ix=sorted(ix,key=lambda i:hashlib.sha256(str(ids[i]).encode()).hexdigest())
        at=max(1,int(len(ix)*2/3));ref+=ix[:at];val+=ix[at:]
    return np.array(ref),np.array(val)
def features(x,z,left,right,fields):
    difference=x[left]-x[right]
    native=np.column_stack([np.mean(difference[:,cols]**2,axis=1) for cols in fields])
    return np.column_stack((np.log1p(native),np.abs(z[left]-z[right])))
def cross_features(a,za,b,zb,fields):
    diff=a-b;return np.column_stack((np.log1p(np.column_stack([np.mean(diff[:,cols]**2,axis=1) for cols in fields])),np.abs(za-zb)))
def pairs(x,y,queries,refs,fields,exclude_self):
    weights=np.zeros(x.shape[1])
    for cols in fields:weights[cols]=1/np.sqrt(len(cols))
    scaled=x*weights;left=[];right=[];same=[]
    for c in range(9):
        qs=queries[y[queries]==c]
        for equal in (True,False):
            bank=refs[(y[refs]==c) if equal else (y[refs]!=c)];k=min(8 if exclude_self and equal else 7,len(bank))
            if not len(qs) or not k:continue
            ix=NearestNeighbors(n_neighbors=k,algorithm='brute',n_jobs=1).fit(scaled[bank]).kneighbors(scaled[qs],return_distance=False)
            for row,near in zip(qs,ix):
                candidates=[int(bank[j]) for j in near if bank[j]!=row][:7]
                left+= [int(row)]*len(candidates);right+=candidates;same += [int(equal)]*len(candidates)
    return np.array(left),np.array(right),np.array(same)
def fit(x,z,y,ids,fields):
    refs,val=split(ids,y);assert not set(ids[refs])&set(ids[val])
    left,right,target=pairs(x,y,refs,refs,fields,True);f=features(x,z,left,right,fields)
    # Every genuine query contributes the same total weight to each target class.
    code=left*2+target;counts=np.bincount(code,minlength=len(x)*2);weight=1/counts[code]
    model=HistGradientBoostingClassifier(max_iter=80,max_leaf_nodes=15,learning_rate=.08,min_samples_leaf=20,l2_regularization=1.,early_stopping=False,random_state=20261031)
    model.fit(f,target,sample_weight=weight)
    vl,vr,vy=pairs(x,y,val,refs,fields,False);prob=model.predict_proba(features(x,z,vl,vr,fields))[:,1]
    maximum=np.full(len(x),-np.inf);np.maximum.at(maximum,vl[vy==0],prob[vy==0]);assert np.isfinite(maximum[val]).all()
    cuts=[]
    for c in (0,1):
        ix=val[(y[val]>0).astype(int)==c];values=np.sort(maximum[ix]);rank=(99*(len(values)+1)+99)//100;assert rank<=len(values)
        cuts.append(dict(coarse=c,parents=len(values),rank=rank,cut=float(values[rank-1])))
    cut=max(v['cut'] for v in cuts)
    return model,dict(refs=refs,val=val,left=left,right=right,pair_target=target,val_left=vl,val_right=vr,val_pair_target=vy,val_probability=prob,
        source_negative_max=maximum[val]),dict(cuts=cuts,cut=cut,fit_parent_rows=len(refs),validation_parent_rows=len(val),
        training_pairs=len(left),validation_pairs=len(vl),true_validation_pair_pass=int(np.sum((vy==1)&(prob>cut))),
        false_validation_pair_pass=int(np.sum((vy==0)&(prob>cut))),
        rule='Per validation QUERY maximum affinity among different-fine neighbors, true-coarse finite99 cut; edges never counted as independent calibration parents.')
