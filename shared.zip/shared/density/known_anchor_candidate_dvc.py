"""BEN-reference anchored Algorithm-2/3 candidate clustering experiment.

The caller freezes real known calibration BEN anchors, at most 512. Query
truth, family, identity and source are not inputs. Both stages use one fixed
graph and selected eps/minPts. Only non-noise query clusters containing no
known BEN anchor can be newly rejected. Mixed/noise clusters fail closed.
Internal graph rows include train-side anchors, not extra evaluation rows.
This is a declared paper-structured extension, not a literal paper Eq.9.
"""
from dataclasses import dataclass
import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.metrics import silhouette_score, calinski_harabasz_score
from sklearn.neighbors import NearestNeighbors
from .dependence_candidate_paper_dvc import knee_radius
from .density_affinity_noise_revision import affinity_geometry


@dataclass
class AnchoredDVC:
    retained: np.ndarray
    first: np.ndarray
    second: np.ndarray
    suspected: np.ndarray
    primary_anchor_free: np.ndarray
    secondary_anchor_free: np.ndarray
    manifest: dict


def anchor_free(labels, anchor):
    labels, anchor = np.asarray(labels), np.asarray(anchor)
    if (labels.ndim != 1 or anchor.shape != labels.shape or labels.dtype.kind not in "iu" or anchor.dtype != bool):
        raise ValueError("paired integer cluster labels and known-anchor flags required")
    contaminated = set(labels[anchor & (labels >= 0)].tolist())
    return np.asarray([v >= 0 and int(v) not in contaminated for v in labels], dtype=bool)


def canonical(labels):
    result = np.full(len(labels), -1, dtype=np.int64); mapping = {}
    for i, value in enumerate(labels):
        if value >= 0: result[i] = mapping.setdefault(int(value), len(mapping))
    return result


def route(query_coordinates, raw_candidate, known_BEN_anchors):
    q, a = map(lambda x: np.asarray(x, dtype=np.float64), (query_coordinates, known_BEN_anchors))
    raw = np.asarray(raw_candidate)
    if (q.ndim != 2 or a.ndim != 2 or q.shape[1] != a.shape[1] or not 0 < q.shape[1] <= 513
            or not 0 < len(q) <= 6000 or not 20 <= len(a) <= 512
            or not np.isfinite(q).all() or not np.isfinite(a).all() or raw.shape != (len(q),) or raw.dtype != bool):
        raise ValueError("<=6000 query rows, 20..512 real known anchors, paired finite coordinates required")
    first, second = (np.full(len(q), -2, dtype=np.int64) for _ in range(2))
    suspect = np.zeros(len(q), dtype=bool); primary_free = suspect.copy(); secondary_free = suspect.copy()
    indices = np.flatnonzero(raw)
    manifest = {"schema_version": "known-BEN-anchor-candidate-paper-DVC-v1", "query_rows": len(q),
        "query_raw_candidate_rows": len(indices), "known_BEN_anchor_rows": len(a), "internal_graph_rows": len(a) + len(indices),
        "internal_known_anchors_NOT_additional_test_rows": True, "minPts_grid": list(range(2, 11)),
        "eps_rule": "one normalized k-distance knee for each minPts",
        "parameter_selection": "max silhouette then C-H, needs >1 cluster",
        "anchor_roles_used_only_for_pure_cluster_admission_NOT_parameter_selection": True,
        "known_anchor_rows_from_fit_or_calibration_NOT_query_labels": True,
        "query_truth_family_ID_source_used": False, "coordinates_frozen_known_fit_NOT_query_rescaled": True,
        "secondary_eps_minPts_graph_coordinates_unchanged": True,
        "alpha": 1., "beta": 1., "density_neighbors": 7,
        "noise_thresholds": "label-blind primary non-noise R95 and density median",
        "new_query_UNA_requires_anchor_free_non_noise_cluster": True,
        "primary_anchor_contamination_cannot_be_undone_by_secondary": True,
        "noise_singleton_or_mixed_cluster_NOT_UNA_fallback": True,
        "calibration_anchors_reused_for_calibration_sanity_NOT_held_out_accuracy": True,
        "published": False, "final_test_executed": False}
    if not len(indices):
        manifest.update(status="NO_RAW_QUERY_CANDIDATES", selected=None, evaluations=[])
        return AnchoredDVC(suspect.copy(), first, second, suspect, primary_free, secondary_free, manifest)
    graph = np.vstack([a, q[indices]])
    is_anchor = np.arange(len(graph)) < len(a)
    order = np.lexsort(tuple(graph[:, j] for j in range(graph.shape[1] - 1, -1, -1)))
    x = graph[order]; anchored = is_anchor[order]
    inverse = np.empty(len(order), dtype=np.int64); inverse[order] = np.arange(len(order))
    best = best_labels = None; evaluations = []
    for k in range(2, 11):
        kth = NearestNeighbors(n_neighbors=k, n_jobs=1).fit(x).kneighbors(x)[0][:, -1]
        eps, knee = knee_radius(kth)
        labels = DBSCAN(eps=eps, min_samples=k, n_jobs=1).fit_predict(x)
        nonnoise = labels >= 0; clusters = len(set(labels[nonnoise].tolist())); sc = ch = None
        if clusters > 1 and int(nonnoise.sum()) >= clusters + 2:
            sc = float(silhouette_score(x[nonnoise], labels[nonnoise], sample_size=min(1000, int(nonnoise.sum())), random_state=20261002))
            ch = float(calinski_harabasz_score(x[nonnoise], labels[nonnoise]))
            if not np.isfinite(sc) or not np.isfinite(ch): sc = ch = None
        item = {"minPts": k, "eps": eps, "knee_index": knee, "cluster_count": clusters,
            "non_noise_rows": int(nonnoise.sum()), "silhouette": sc, "calinski_harabasz": ch}
        evaluations.append(item)
        if sc is not None and (best is None or (sc, ch) > (best["silhouette"], best["calinski_harabasz"])):
            best, best_labels = item, labels
    manifest.update(selected=best, evaluations=evaluations)
    if best is None:
        first[indices] = -1; manifest["status"] = "NO_ELIGIBLE_MULTI_CLUSTER_PARAMETER_FAIL_CLOSED"
        return AnchoredDVC(suspect.copy(), first, second, suspect, primary_free, secondary_free, manifest)
    geom = affinity_geometry(x, best_labels, eps=best["eps"], min_samples=best["minPts"])
    nonnoise = best_labels >= 0
    r_cut = float(np.quantile(geom.reconstruction[nonnoise], .95, method="higher"))
    d_cut = float(np.median(geom.density[nonnoise]))
    s = (geom.reconstruction > r_cut) & (geom.density < d_cut)
    secondary = np.full(len(x), -2, dtype=np.int64)
    if s.any(): secondary[s] = canonical(DBSCAN(eps=best["eps"], min_samples=best["minPts"], n_jobs=1).fit_predict(x[s]))
    free_first = anchor_free(best_labels, anchored)
    # Noise has no primary supported cluster: allow secondary recovery only
    # if it is pure. A mixed primary cluster cannot shed its anchor veto.
    primary_not_mixed = free_first | (best_labels < 0)
    free_second = anchor_free(secondary, anchored)
    graph_retained = ~anchored & ((~s & free_first) | (s & primary_not_mixed & free_second))
    position = inverse[len(a):]
    first[indices] = canonical(best_labels)[position]; second[indices] = secondary[position]
    suspect[indices] = s[position]; primary_free[indices] = free_first[position]; secondary_free[indices] = free_second[position]
    retained = np.zeros(len(q), dtype=bool); retained[indices] = graph_retained[position]
    manifest.update(status="ANCHORED_DVC_COMPLETED_NOT_FINAL", reconstruction_cutoff=r_cut, density_cutoff=d_cut,
        suspected_noise_rows=int(s.sum()), retained_raw_query_rows=int(retained.sum()),
        primary_anchor_contaminated_cluster_count=len(set(best_labels[anchored & nonnoise].tolist())),
        second_anchor_contaminated_cluster_count=len(set(secondary[anchored & (secondary >= 0)].tolist())))
    return AnchoredDVC(retained, first, second, suspect, primary_free, secondary_free, manifest)
