"""Known-only local density conditioned on observed authentication state."""
from dataclasses import dataclass
import numpy as np
from scipy.spatial.distance import cdist
from .known_ben_context_whitened_fit_loo import KnownContextWhitener,context_keys
from .known_ben_whitened_local_density_guards import rowwise_coordinates,raw_geometry,reference_density_and_jackknife
from .greedy_known_reference_guards import guards_for_constraints


@dataclass
class AuthProfile:
    feature_names:tuple
    columns:dict
    auth_splits:tuple
    nodes:dict
    manifest:dict


def keys(profile,x):
    base=context_keys(x,profile.feature_names)
    return [key+tuple(int(row[col]>cut) for col,cut in profile.auth_splits) for key,row in zip(base,x)]


def fit_profile(original,calibration,protected_BEN,*,fit_features,fit_truth):
    fit=np.asarray(fit_features,dtype=np.float64);cal=np.asarray(calibration,dtype=np.float64)
    truth=np.asarray(fit_truth);protected=np.asarray(protected_BEN)
    if (fit.ndim!=2 or cal.ndim!=2 or fit.shape[1]!=cal.shape[1] or fit.shape[1]!=len(original.feature_names)
            or len(fit)>6000 or len(cal)>6000 or truth.shape!=(len(fit),) or set(truth.tolist())!={0,1}
            or protected.shape!=(len(cal),) or protected.dtype!=bool
            or not np.isfinite(fit).all() or not np.isfinite(cal).all()):raise ValueError('capped known BEN/KNA fit and BEN calibration only required')
    names=tuple(original.feature_names);splits=[];declarations=[]
    for field in ('logged_in','is_guest_login'):
        if field not in names:continue
        col=names.index(field);values=np.unique(fit[:,col])
        if len(values)!=2:raise ValueError('authentication state must have two frozen fit levels')
        split=float((values[0]+values[1])/2);splits.append((col,split))
        declarations.append(dict(field=field,column=col,low=float(values[0]),high=float(values[1]),midpoint=split))
    if not splits:raise ValueError('no measured authentication state selected in known model')
    profile=AuthProfile(names,original.columns,tuple(splits),{},{});fk=keys(profile,fit);ck=keys(profile,cal);audit=[]
    for key in sorted({k for k,y in zip(fk,truth) if y==0}):
        fi=np.asarray([i for i,k in enumerate(fk) if k==key and truth[i]==0],dtype=np.int64)
        ci=np.asarray([i for i,k in enumerate(ck) if k==key and protected[i]],dtype=np.int64)
        row=dict(context=list(key),fit_BEN_rows=len(fi),correct_calibration_BEN_rows=len(ci),admitted=len(fi)>=9 and len(ci)>=3,references_guard_reduced=0)
        if not row['admitted']:audit.append(row);continue
        groups={}
        for view,columns in profile.columns.items():
            raw=fit[fi][:,columns];raw=raw[np.lexsort(tuple(raw[:,j] for j in range(raw.shape[1]-1,-1,-1)))]
            metric=KnownContextWhitener().fit(raw);z=rowwise_coordinates(metric,raw)
            kth,density,loo=reference_density_and_jackknife(z)
            group=dict(metric=metric,reference=z,k_distance=kth,local_density=density)
            cal_score,cal_neighbors=raw_geometry(group,cal[ci][:,columns]);fit_score,actual=raw_geometry(group,raw)
            distance=cdist(z,z);np.fill_diagonal(distance,np.inf)
            nonself=np.argsort(distance,axis=1,kind='stable')[:,:7]
            group['reference_cutoff']=guards_for_constraints(len(z),[(fit_score,actual),(loo,nonself),(cal_score,cal_neighbors)])
            group['cutoff']=1.;groups[view]=group
        profile.nodes[key]=groups;audit.append(row)
    if not profile.nodes:raise ValueError('no authentication context meets nine fit and three correct calibration rows')
    profile.manifest=dict(schema_version='known-only-authentication-context-greedy-local-density-v1',
        nodes=audit,authentication_splits_from_fit_only=declarations,
        semantic_states=['logged_in','is_guest_login'],context_roles='protocol service flag and measured authentication state',
        known_fit_neighbor_density_jackknife_and_calibration_constraints_protected=True,
        covariance_and_density_fit_only_on_real_BEN_fit_rows=True,
        unsupported_context_action='retain parent prediction and all denominator rows',
        unknown_truth_or_query_scores_used_for_fit=False,held_out_known_scores_used_for_fit=False,
        minimum_context_support_NOT_family_floor=True,published=False,independent_final_admitted=False)
    return profile


def evaluate(profile,features,stage1):
    x=np.asarray(features,dtype=np.float64);stage=np.asarray(stage1)
    if (x.ndim!=2 or x.shape[1]!=len(profile.feature_names) or not 0<len(x)<=6000
            or not np.isfinite(x).all() or stage.shape!=(len(x),) or not np.isin(stage,(0,1)).all()):raise ValueError('capped measured features and frozen Stage1 required')
    ratios=np.zeros((len(x),4));eligible=np.zeros(len(x),dtype=bool);query_keys=keys(profile,x)
    for key,groups in profile.nodes.items():
        indices=np.asarray([i for i,k in enumerate(query_keys) if k==key],dtype=np.int64)
        if not len(indices):continue
        eligible[indices]=True
        for j,view in enumerate(profile.columns):
            raw,neighbors=raw_geometry(groups[view],x[indices][:,profile.columns[view]])
            ratios[indices,j]=raw/np.max(groups[view]['reference_cutoff'][neighbors],axis=1)
    score=np.maximum(ratios[:,tuple(profile.columns).index('content_login_activity')],np.sort(ratios,axis=1)[:,-2])
    return dict(score=score,raw_candidate=(stage==0)&eligible&(score>1),eligible=eligible,per_view_ratio=ratios)
