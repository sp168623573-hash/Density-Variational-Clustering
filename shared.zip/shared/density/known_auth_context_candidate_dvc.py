"""Run the unchanged anchored candidate DVC within known auth contexts.

Contexts and BEN anchors freeze from known fit/calibration measurements.
Different protocol/service/flag/authentication contexts never share a graph.
Twenty distinct frozen anchor coordinates are required; unsupported contexts
keep the parent prediction and every denominator row.  Distinct coordinates
and source rows do not certify physical-event independence.
"""
from dataclasses import dataclass
import hashlib
import json

import numpy as np

from .known_anchor_candidate_dvc import route as anchored_route
from .known_auth_context_reference_density import keys


SCHEMA = "known-only-auth-context-separated-anchored-candidate-DVC-v1"
MIN_ANCHORS = 20
MAX_ANCHORS = 512


def _sha(array):
    value = np.asarray(array, dtype="<f8", order="C")
    digest = hashlib.sha256(str(value.shape).encode("ascii"))
    digest.update(value.tobytes())
    return digest.hexdigest()


def _manifest_sha(manifest):
    payload = {key: value for key, value in manifest.items() if key != "frozen_manifest_sha256"}
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"),
                                   ensure_ascii=False).encode("utf8")).hexdigest()


@dataclass
class ContextAnchors:
    feature_names: tuple
    auth_splits: tuple
    nodes: dict
    manifest: dict


@dataclass
class ContextDVC:
    retained: np.ndarray
    first: np.ndarray
    second: np.ndarray
    supported: np.ndarray
    manifest: dict


def check(policy):
    manifest = policy.manifest
    if (manifest.get("schema_version") != SCHEMA
            or manifest.get("frozen_manifest_sha256") != _manifest_sha(manifest)
            or manifest.get("feature_names") != list(policy.feature_names)
            or manifest.get("auth_splits") != [list(pair) for pair in policy.auth_splits]
            or manifest.get("minimum_unique_anchor_coordinates") != MIN_ANCHORS
            or manifest.get("maximum_anchor_coordinates") != MAX_ANCHORS
            or manifest.get("query_labels_or_families_or_IDs_used_for_anchor_fit") is not False):
        raise ValueError("frozen known-only authentication anchor policy required")
    admitted = {tuple(row["context"]): row for row in manifest["nodes"] if row["admitted"]}
    if set(policy.nodes) != set(admitted):
        raise ValueError("frozen admitted anchor contexts changed")
    width = manifest["coordinate_width"]
    for key, anchors in policy.nodes.items():
        if (anchors.ndim != 2 or anchors.shape[1] != width
                or not MIN_ANCHORS <= len(anchors) <= MAX_ANCHORS
                or not np.isfinite(anchors).all()
                or len(np.unique(anchors, axis=0)) != len(anchors)
                or _sha(anchors) != admitted[key]["anchor_coordinate_sha256"]):
            raise ValueError("frozen unique measured anchor coordinates changed")


def fit_anchor_groups(profile, fit_features, fit_truth, fit_coordinates,
                      calibration_features, protected_BEN, calibration_coordinates):
    fit, cal, fc, cc = [np.asarray(value, dtype=np.float64) for value in (
        fit_features, calibration_features, fit_coordinates, calibration_coordinates)]
    truth, protected = np.asarray(fit_truth), np.asarray(protected_BEN)
    names, splits = tuple(profile.feature_names), tuple(profile.auth_splits)
    if (fit.ndim != 2 or cal.ndim != 2 or fc.ndim != 2 or cc.ndim != 2
            or fit.shape[1] != len(names) or cal.shape[1] != len(names)
            or fc.shape[0] != len(fit) or cc.shape[0] != len(cal)
            or fc.shape[1] != cc.shape[1] or not 0 < fc.shape[1] <= 513
            or not 40 <= len(fit) <= 6000 or not 3 <= len(cal) <= 6000
            or truth.shape != (len(fit),) or truth.dtype.kind not in "iu"
            or set(truth.tolist()) != {0, 1}
            or protected.shape != (len(cal),) or protected.dtype != bool
            or any(not np.isfinite(value).all() for value in (fit, cal, fc, cc))):
        raise ValueError("capped real BEN/KNA fit and protected known BEN calibration required")
    fit_keys, cal_keys = keys(profile, fit), keys(profile, cal)
    nodes, audit = {}, []
    for key in sorted(profile.nodes):
        fi = np.asarray([i for i, value in enumerate(fit_keys) if value == key and truth[i] == 0], dtype=np.int64)
        ci = np.asarray([i for i, value in enumerate(cal_keys) if value == key and protected[i]], dtype=np.int64)
        features = np.vstack([fit[fi], cal[ci]])
        coordinates = np.vstack([fc[fi], cc[ci]])
        # Feature duplicates cannot manufacture known anchor support. Sorting
        # coordinates first makes the representative independent of source IDs
        # and of input row ordering if equal features carry rounded coordinates.
        if len(features):
            order = np.lexsort(tuple(coordinates[:, j] for j in range(coordinates.shape[1] - 1, -1, -1)))
            features, coordinates = features[order], coordinates[order]
            _, unique_rows = np.unique(features, axis=0, return_index=True)
            coordinates = coordinates[unique_rows]
        unique_coordinates = np.unique(coordinates, axis=0)
        row = dict(context=list(key), real_BEN_fit_rows=len(fi), protected_BEN_calibration_rows=len(ci),
            distinct_known_feature_rows=len(coordinates), unique_anchor_coordinates=len(unique_coordinates),
            admitted=len(unique_coordinates) >= MIN_ANCHORS, anchor_rows=0)
        if row["admitted"]:
            selected = (np.linspace(0, len(unique_coordinates) - 1, MAX_ANCHORS, dtype=np.int64)
                        if len(unique_coordinates) > MAX_ANCHORS else np.arange(len(unique_coordinates)))
            anchors = unique_coordinates[selected].copy()
            nodes[key] = anchors
            row.update(anchor_rows=len(anchors), anchor_coordinate_sha256=_sha(anchors))
        audit.append(row)
    policy = ContextAnchors(names, splits, nodes, dict(schema_version=SCHEMA, nodes=audit,
        feature_names=list(names), auth_splits=[list(pair) for pair in splits],
        coordinate_width=fc.shape[1], minimum_unique_anchor_coordinates=MIN_ANCHORS,
        maximum_anchor_coordinates=MAX_ANCHORS,
        anchor_source="real BEN fit rows plus correctly routed protected BEN calibration rows",
        anchor_selection="deduplicate exact features and coordinates; evenly spaced lexicographic coordinate ranks if >512",
        anchor_fit_uses_query_features=False,
        query_labels_or_families_or_IDs_used_for_anchor_fit=False,
        contexts="frozen protocol/service/flag and measured logged_in/is_guest_login states",
        graph_scope="one same-context graph; frozen MHFD plus unchanged quorum score coordinate",
        eps_minPts_and_noise_criteria="unchanged known_anchor_candidate_dvc.route",
        unsupported_context_action="retain parent prediction and every query denominator row",
        minimum_anchor_coordinates_NOT_family_floor_or_independence_certificate=True,
        physical_event_independence_verified=False, independent_final_admitted=False, published=False))
    policy.manifest["frozen_manifest_sha256"] = _manifest_sha(policy.manifest)
    check(policy)
    return policy


def route(query_coordinates, raw_candidate, query_features, policy):
    check(policy)
    q, features = np.asarray(query_coordinates, dtype=np.float64), np.asarray(query_features, dtype=np.float64)
    raw = np.asarray(raw_candidate)
    if (q.ndim != 2 or features.ndim != 2 or not 0 < len(q) <= 6000
            or len(features) != len(q) or features.shape[1] != len(policy.feature_names)
            or q.shape[1] != policy.manifest["coordinate_width"]
            or not np.isfinite(q).all() or not np.isfinite(features).all()
            or raw.shape != (len(q),) or raw.dtype != bool):
        raise ValueError("paired capped feature-only queries and fixed known coordinates required")
    query_keys = keys(policy, features)
    retained = np.zeros(len(q), dtype=bool)
    supported = np.zeros(len(q), dtype=bool)
    first, second = np.full(len(q), -2, dtype=np.int64), np.full(len(q), -2, dtype=np.int64)
    evaluations, first_offset, second_offset = [], 0, 0
    for key in sorted(set(query_keys)):
        indices = np.asarray([i for i, value in enumerate(query_keys) if value == key], dtype=np.int64)
        if key not in policy.nodes:
            first[indices[raw[indices]]] = -3
            evaluations.append(dict(context=list(key), query_rows=len(indices),
                raw_candidate_rows=int(raw[indices].sum()), anchor_rows=0,
                status="UNSUPPORTED_KNOWN_ANCHOR_CONTEXT_RETAIN_PARENT"))
            continue
        supported[indices] = True
        result = anchored_route(q[indices], raw[indices], policy.nodes[key])
        retained[indices] = result.retained
        local_first, local_second = result.first.copy(), result.second.copy()
        local_first[local_first >= 0] += first_offset
        local_second[local_second >= 0] += second_offset
        first[indices], second[indices] = local_first, local_second
        if np.any(result.first >= 0):
            first_offset += int(result.first[result.first >= 0].max()) + 1
        if np.any(result.second >= 0):
            second_offset += int(result.second[result.second >= 0].max()) + 1
        evaluations.append(dict(context=list(key), query_rows=len(indices),
            raw_candidate_rows=int(raw[indices].sum()), anchor_rows=len(policy.nodes[key]),
            retained_raw_query_rows=int(result.retained.sum()), DVC=result.manifest))
    if np.any(retained & ~raw) or np.any(retained & ~supported):
        raise AssertionError("only supported actual raw candidates may pass DVC")
    return ContextDVC(retained, first, second, supported, dict(
        schema_version=SCHEMA, status="AUTH_CONTEXT_SEPARATED_DVC_COMPLETED_NOT_FINAL",
        query_rows=len(q), query_raw_candidate_rows=int(raw.sum()),
        supported_query_rows=int(supported.sum()), unsupported_query_rows=int((~supported).sum()),
        unsupported_raw_candidate_rows=int((raw & ~supported).sum()),
        retained_raw_query_rows=int(retained.sum()), contexts=evaluations,
        frozen_anchor_manifest_sha256=policy.manifest["frozen_manifest_sha256"],
        known_anchor_rows_NOT_additional_test_rows=True,
        query_truth_family_ID_source_used=False,
        contexts_selected_from_measured_features_NOT_query_labels=True,
        coordinates_and_score_unchanged_from_frozen_known_quorum_policy=True,
        eps_minPts_grid_and_noise_criteria_unchanged=True,
        new_query_UNA_requires_same_context_anchor_free_non_noise_cluster=True,
        unsupported_noise_singleton_and_mixed_clusters_retain_parent=True,
        physical_event_independence_verified=False, independent_final_admitted=False,
        published=False, final_test_executed=False))
