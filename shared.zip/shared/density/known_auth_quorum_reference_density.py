"""Known BEN authentication density with a fixed four-of-seven guard quorum.

One distant known constraint must protect four real neighbours, rather than
letting a single high guard admit every query sharing that neighbour.  The
median of seven score/guard ratios is the query statistic.  Actual fit,
neighbour-graph jackknife and protected calibration constraints remain
protected.  Whitening and guard fitting are not a full-model LOO refit.
"""
from dataclasses import dataclass
import hashlib
import json

import numpy as np
from scipy.spatial.distance import cdist

from .known_auth_context_reference_density import keys
from .known_ben_context_whitened_fit_loo import KnownContextWhitener
from .known_ben_whitened_local_density_guards import (
    raw_geometry, reference_density_and_jackknife, rowwise_coordinates,
    state_sha,
)


NEIGHBORS = 7
QUORUM = 4
SCHEMA = "known-only-authentication-context-quorum-local-density-v1"


def quorum_ratios(values, neighbours, guards):
    values = np.asarray(values, dtype=np.float64)
    neighbours = np.asarray(neighbours)
    guards = np.asarray(guards, dtype=np.float64)
    if (values.ndim != 1 or neighbours.shape != (len(values), NEIGHBORS)
            or neighbours.dtype.kind not in "iu" or guards.ndim != 1
            or len(guards) < 9 or not np.isfinite(values).all()
            or not np.isfinite(guards).all() or np.any(values < 0)
            or np.any(guards < 1) or np.any(neighbours < 0)
            or np.any(neighbours >= len(guards))
            or any(len(set(row.tolist())) != NEIGHBORS for row in neighbours)):
        raise ValueError("finite density scores and seven distinct real references required")
    return np.median(values[:, None] / guards[neighbours], axis=1)


def guards_for_constraints(reference_count, constraints):
    if type(reference_count) is not int or reference_count < 9:
        raise ValueError("at least nine real known reference rows required")
    scores, neighbours = [], []
    for value, refs in constraints:
        value = np.asarray(value, dtype=np.float64)
        refs = np.asarray(refs)
        # Validation also prevents repeating one reference to fake a quorum.
        quorum_ratios(value, refs, np.ones(reference_count))
        scores.extend(value.tolist())
        neighbours.extend(refs.tolist())
    values = np.asarray(scores, dtype=np.float64)
    refs = np.asarray(neighbours, dtype=np.int64)
    if not len(values):
        raise ValueError("real known protection constraints required")
    incidence = np.bincount(refs.ravel(), minlength=reference_count)
    order = sorted(range(len(values)), key=lambda i: (-values[i], tuple(sorted(refs[i]))))
    guard = np.ones(reference_count, dtype=np.float64)
    for i in order:
        protected = int(np.sum(guard[refs[i]] >= values[i]))
        need = max(0, QUORUM - protected)
        available = sorted((int(j) for j in refs[i] if guard[j] < values[i]),
                           key=lambda j: (incidence[j], j))
        for j in available[:need]:
            guard[j] = values[i]
    guard += 64 * np.finfo(np.float64).eps * np.maximum(1., guard)
    if np.any(quorum_ratios(values, refs, guard) > 1):
        raise AssertionError("known quorum protection constraint lost")
    return guard


@dataclass
class AuthQuorumProfile:
    feature_names: tuple
    columns: dict
    auth_splits: tuple
    nodes: dict
    manifest: dict


def _manifest_sha(manifest):
    payload = {k: v for k, v in manifest.items() if k != "frozen_manifest_sha256"}
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"),
                                   ensure_ascii=False).encode("utf8")).hexdigest()


def check(profile):
    manifest = profile.manifest
    if (manifest.get("schema_version") != SCHEMA
            or manifest.get("neighbors") != NEIGHBORS
            or manifest.get("quorum") != QUORUM
            or manifest.get("frozen_manifest_sha256") != _manifest_sha(manifest)
            or manifest.get("query_truth_or_ID_or_family_used") is not False
            or manifest.get("columns") != {k: list(v) for k, v in profile.columns.items()}
            or manifest.get("feature_names") != list(profile.feature_names)
            or manifest.get("auth_splits") != [list(pair) for pair in profile.auth_splits]):
        raise ValueError("frozen fixed-quorum known-only policy required")
    admitted = {tuple(row["context"]): row for row in manifest["nodes"] if row["admitted"]}
    if set(admitted) != set(profile.nodes):
        raise ValueError("frozen authentication support contexts changed")
    for key, groups in profile.nodes.items():
        if tuple(groups) != tuple(profile.columns):
            raise ValueError("frozen four semantic views required")
        for view, group in groups.items():
            if (state_sha(group) != admitted[key]["views"][view]["state_sha256"]
                    or group["cutoff"] != 1.
                    or group["reference_cutoff"].shape != (len(group["reference"]),)
                    or not np.isfinite(group["reference_cutoff"]).all()
                    or np.any(group["reference_cutoff"] < 1)):
                raise ValueError("frozen quorum density geometry or guards changed")


def fit_profile(original, calibration, protected_BEN, *, fit_features, fit_truth):
    fit = np.asarray(fit_features, dtype=np.float64)
    cal = np.asarray(calibration, dtype=np.float64)
    truth, protected = np.asarray(fit_truth), np.asarray(protected_BEN)
    names = tuple(original.feature_names)
    columns = {key: tuple(value) for key, value in original.columns.items()}
    if (fit.ndim != 2 or cal.ndim != 2 or fit.shape[1] != cal.shape[1]
            or fit.shape[1] != len(names) or len(set(names)) != len(names)
            or not 40 <= len(fit) <= 6000 or not 3 <= len(cal) <= 6000
            or truth.shape != (len(fit),) or truth.dtype.kind not in "iu"
            or set(truth.tolist()) != {0, 1}
            or protected.shape != (len(cal),) or protected.dtype != bool
            or not np.isfinite(fit).all() or not np.isfinite(cal).all()
            or len(columns) != 4 or "content_login_activity" not in columns
            or any(not value or min(value) < 0 or max(value) >= len(names)
                   or len(set(value)) != len(value) for value in columns.values())):
        raise ValueError("capped BEN/KNA fit, four frozen views and protected BEN calibration required")
    splits, declarations = [], []
    for field in ("logged_in", "is_guest_login"):
        if field not in names:
            continue
        col = names.index(field)
        levels = np.unique(fit[:, col])
        if len(levels) != 2:
            raise ValueError("authentication state requires two frozen fit levels")
        split = float((levels[0] + levels[1]) / 2)
        splits.append((col, split))
        declarations.append(dict(field=field, column=col, low=float(levels[0]),
                                 high=float(levels[1]), midpoint=split))
    if not splits:
        raise ValueError("measured authentication state required")
    profile = AuthQuorumProfile(names, columns, tuple(splits), {}, {})
    fk, ck = keys(profile, fit), keys(profile, cal)
    audit = []
    for key in sorted({key for key, label in zip(fk, truth) if label == 0}):
        fi = np.asarray([i for i, value in enumerate(fk) if value == key and truth[i] == 0])
        ci = np.asarray([i for i, value in enumerate(ck) if value == key and protected[i]])
        row = dict(context=list(key), fit_BEN_rows=len(fi), correct_calibration_BEN_rows=len(ci),
                   admitted=len(fi) >= 9 and len(ci) >= 3, views={})
        if not row["admitted"]:
            audit.append(row)
            continue
        groups = {}
        for view, cols in columns.items():
            raw = fit[fi][:, cols]
            raw = raw[np.lexsort(tuple(raw[:, j] for j in range(raw.shape[1] - 1, -1, -1)))]
            metric = KnownContextWhitener().fit(raw)
            z = rowwise_coordinates(metric, raw)
            kth, density, loo = reference_density_and_jackknife(z)
            group = dict(metric=metric, reference=z, k_distance=kth, local_density=density)
            cal_score, cal_neighbours = raw_geometry(group, cal[ci][:, cols])
            fit_score, actual = raw_geometry(group, raw)
            distance = cdist(z, z)
            np.fill_diagonal(distance, np.inf)
            nonself = np.argsort(distance, axis=1, kind="stable")[:, :NEIGHBORS]
            constraints = [(fit_score, actual), (loo, nonself), (cal_score, cal_neighbours)]
            group["reference_cutoff"] = guards_for_constraints(len(z), constraints)
            group["cutoff"] = 1.
            maxima = [float(quorum_ratios(v, n, group["reference_cutoff"]).max())
                      for v, n in constraints]
            row["views"][view] = dict(state_sha256=state_sha(group),
                actual_fit_maximum=maxima[0], neighbor_jackknife_maximum=maxima[1],
                protected_calibration_maximum=maxima[2],
                elevated_reference_guards=int(np.sum(group["reference_cutoff"] > 1 + 1e-12)))
            groups[view] = group
        profile.nodes[key] = groups
        audit.append(row)
    if not profile.nodes:
        raise ValueError("no authentication context meets nine fit and three correct calibration rows")
    profile.manifest = dict(schema_version=SCHEMA, nodes=audit, neighbors=NEIGHBORS, quorum=QUORUM,
        feature_names=list(names), columns={k: list(v) for k, v in columns.items()},
        auth_splits=[list(pair) for pair in splits], authentication_splits_from_fit_only=declarations,
        guard_assignment="descending known score; protect four least-incidence real neighbors",
        per_view_statistic="median of seven raw-score/reference-guard ratios",
        candidate_rule="content > 1 OR second-largest of four semantic views > 1",
        fixed_quorum_declared_before_new_query=True,
        all_actual_fit_neighbor_jackknife_and_protected_calibration_constraints_protected=True,
        covariance_and_density_fit_only_on_real_BEN_fit_rows=True,
        whitener_and_guard_are_NOT_full_model_leave_one_out_refit=True,
        query_truth_or_ID_or_family_used=False, unknown_truth_or_query_scores_used_for_fit=False,
        held_out_known_scores_used_for_fit=False,
        unsupported_context_action="retain parent prediction and all denominator rows",
        minimum_context_support_NOT_Table1_family_floor=True,
        historical_development_inspection_precedes_design=True,
        independent_final_admitted=False, published=False)
    profile.manifest["frozen_manifest_sha256"] = _manifest_sha(profile.manifest)
    check(profile)
    return profile


def evaluate(profile, features, stage1):
    check(profile)
    x, stage = np.asarray(features, dtype=np.float64), np.asarray(stage1)
    if (x.ndim != 2 or x.shape[1] != len(profile.feature_names) or not 0 < len(x) <= 6000
            or not np.isfinite(x).all() or stage.shape != (len(x),)
            or stage.dtype.kind not in "iu" or not np.isin(stage, (0, 1)).all()):
        raise ValueError("capped measured features and frozen Stage1 required")
    ratios = np.zeros((len(x), 4))
    eligible = np.zeros(len(x), dtype=bool)
    query_keys = keys(profile, x)
    for key, groups in profile.nodes.items():
        indices = np.asarray([i for i, value in enumerate(query_keys) if value == key], dtype=np.int64)
        if not len(indices):
            continue
        eligible[indices] = True
        for j, view in enumerate(profile.columns):
            raw, neighbours = raw_geometry(groups[view], x[indices][:, profile.columns[view]])
            ratios[indices, j] = quorum_ratios(raw, neighbours, groups[view]["reference_cutoff"])
    score = np.maximum(ratios[:, tuple(profile.columns).index("content_login_activity")],
                       np.sort(ratios, axis=1)[:, -2])
    return dict(score=score, raw_candidate=(stage == 0) & eligible & (score > 1),
                eligible=eligible, per_view_ratio=ratios)
