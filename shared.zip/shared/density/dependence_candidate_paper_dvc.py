"""Label-blind candidate DVC using the manuscript's Algorithm 2/3 structure.

minPts is 2..10; one normalized k-distance knee per minPts; silhouette then
C-H breaks ties. No truth/identity argument and no all-noise UNA fallback.
The caller supplies frozen known-fit coordinates. Algorithm-3 alpha=beta=1,
7th-neighbor density and label-blind primary-cluster R95/Dmedian thresholds
are declared choices where the manuscript leaves implementation unspecified.
The noise pass reuses exactly the primary eps/minPts and coordinates.
"""
from dataclasses import dataclass

import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.metrics import calinski_harabasz_score, silhouette_score
from sklearn.neighbors import NearestNeighbors

from .density_affinity_noise_revision import affinity_geometry


@dataclass
class CandidateDVC:
    retained: np.ndarray
    primary_cluster: np.ndarray
    second_cluster: np.ndarray
    suspected_noise: np.ndarray
    manifest: dict


def knee_radius(distances):
    ordered = np.sort(np.asarray(distances, dtype=np.float64))
    if ordered.ndim != 1 or not len(ordered) or not np.isfinite(ordered).all() or np.any(ordered < 0):
        raise ValueError("finite nonnegative k-distance sequence required")
    if len(ordered) == 1 or ordered[-1] == ordered[0]:
        return max(float(ordered[-1]), 1.e-6), len(ordered) - 1
    line = np.linspace(0., 1., len(ordered))
    scaled = (ordered - ordered[0]) / (ordered[-1] - ordered[0])
    index = int(np.argmax(line - scaled))
    return max(float(ordered[index]), 1.e-6), index


def _canonical(labels):
    result, mapping = np.full(len(labels), -1, dtype=np.int64), {}
    for i, label in enumerate(labels):
        if label >= 0:
            result[i] = mapping.setdefault(int(label), len(mapping))
    return result


def route(coordinates, candidate, *, seed=20261002):
    values, raw = np.asarray(coordinates, dtype=np.float64), np.asarray(candidate)
    if (values.ndim != 2 or not 0 < len(values) <= 6000 or not 0 < values.shape[1] <= 513
            or not np.isfinite(values).all() or raw.shape != (len(values),) or raw.dtype != bool):
        raise ValueError("bounded finite paired coordinates and boolean candidates required")
    first, second = (np.full(len(values), -2, dtype=np.int64) for _ in range(2))
    suspected = np.zeros(len(values), dtype=bool)
    indices = np.flatnonzero(raw)
    # Geometry ordering only; IDs cannot pick the density model or border assignment.
    order = np.lexsort(tuple(values[indices, j] for j in range(values.shape[1] - 1, -1, -1)))
    indices = indices[order]
    x = values[indices]
    manifest = {"schema_version": "dependence-density-candidate-paper-DVC-v1",
        "candidate_rows": len(x), "minPts_grid": list(range(2, 11)),
        "parameter_selection": "silhouette maximum; C-H tie-break; requires >1 cluster",
        "eps_rule": "largest normalized distance below diagonal in sorted k-distances",
        "coordinates_frozen_known_fit_scaled_NOT_query_rescaled": True,
        "row_order_policy": "lexicographic coordinates; no IDs",
        "truth_family_or_identity_used": False,
        "all_noise_or_one_cluster_frontier_fails_closed": True,
        "secondary_eps_minPts_and_coordinates_unchanged": True,
        "noise_or_singleton_routed_directly_as_UNA": False,
        "alpha": 1., "beta": 1., "local_density_neighbors": 7,
        "noise_thresholds": "label-blind primary non-noise R95 and density median",
        "noise_thresholds_NOT_prequery_known_calibration_thresholds": True,
        "silhouette_limit": 1000, "published": False}
    evaluations, best, best_labels = [], None, None
    for min_pts in range(2, min(10, len(x)) + 1):
        kth = NearestNeighbors(n_neighbors=min_pts, n_jobs=1).fit(x).kneighbors(x)[0][:, -1]
        eps, knee = knee_radius(kth)
        labels = DBSCAN(eps=eps, min_samples=min_pts, n_jobs=1).fit_predict(x)
        mask = labels >= 0
        clusters = len(set(labels[mask].tolist()))
        sc = ch = None
        if clusters > 1 and int(mask.sum()) >= clusters + 2:
            sc = float(silhouette_score(x[mask], labels[mask],
                sample_size=min(1000, int(mask.sum())), random_state=seed))
            ch = float(calinski_harabasz_score(x[mask], labels[mask]))
            if not np.isfinite(sc) or not np.isfinite(ch):
                sc = ch = None
        entry = {"eps": eps, "minPts": min_pts, "knee_index": knee,
            "cluster_count": clusters, "non_noise_rows": int(mask.sum()), "silhouette": sc,
            "calinski_harabasz": ch}
        evaluations.append(entry)
        if sc is not None and (best is None or (sc, ch) > (best["silhouette"], best["calinski_harabasz"])):
            best, best_labels = entry, labels
    manifest["evaluations"], manifest["selected"] = evaluations, best
    if best is None:
        first[indices] = -1
        manifest["status"] = "NO_ELIGIBLE_MULTI_CLUSTER_PARAMETER_FAIL_CLOSED"
        return CandidateDVC(np.zeros(len(values), dtype=bool), first, second, suspected, manifest)
    first[indices] = _canonical(best_labels)
    geometry = affinity_geometry(x, best_labels, eps=best["eps"], min_samples=best["minPts"])
    supported = best_labels >= 0
    r_cut = float(np.quantile(geometry.reconstruction[supported], .95, method="higher"))
    d_cut = float(np.median(geometry.density[supported]))
    local_suspect = (geometry.reconstruction > r_cut) & (geometry.density < d_cut)
    suspected[indices] = local_suspect
    if local_suspect.any():
        second[indices[local_suspect]] = _canonical(DBSCAN(eps=best["eps"],
            min_samples=best["minPts"], n_jobs=1).fit_predict(x[local_suspect]))
    # Suspicious primary members must survive the fixed-coordinate second pass.
    retained = raw & (((first >= 0) & ~suspected) | (suspected & (second >= 0)))
    manifest.update({"status": "DVC_COMPLETED_NOT_FINAL", "reconstruction_cutoff": r_cut,
        "density_cutoff": d_cut, "suspected_noise_rows": int(local_suspect.sum()),
        "non_noise_retained": int(retained.sum()), "primary_clusters": geometry.clusters,
        "second_cluster_count": len(set(second[second >= 0].tolist())),
        "parameters_fit_query_features_label_blind_as_Algorithm2": True})
    return CandidateDVC(retained, first, second, suspected, manifest)
