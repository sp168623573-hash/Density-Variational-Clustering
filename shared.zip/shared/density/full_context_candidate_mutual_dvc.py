"""Root-frozen V980 density: complete unlabelled context and local second pass.

No traffic loader, target labels, historical U labels/seeds or model weights.
Original DBSCAN knee/SC/CH/affinity body is reused at the actual new dimension.
"""
from __future__ import annotations
from pathlib import Path
import sys
import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.metrics import silhouette_score

ROOT=Path('F:/shenpeng/Experiments/Chinese Science')
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from paper_open_set.cic2_allpair_relation158_dvc_v106 import knee_radius,metric_CH,metric_affinity_geometry

K=7
SEED=20261023


def require(ok,message):
    if not bool(ok):raise ValueError(message)


def recipe():
    return dict(schema='V980_FULL_CONTEXT_ORIGINAL_DVC_LOCAL_SCALE_SECONDARY_AND_FIXED_VOTES',
        allowed_dimensions=[359],context='every unlabelled physical group, not raw subset',
        primary='original knee-radius DBSCAN minPts2..10; eligible multicluster SC then same-metric CH',
        primary_fallback='fixed minPts=min(7,N) knee DBSCAN when SC/CH unavailable; a single cluster is valid, SC_UNASSESSABLE',
        suspicion='original primary-nonnoise reconstruction higher-R95 AND density<Dmedian',
        secondary='one DBSCAN on the COMPLETE context using d/sqrt(r_i*r_j), fixed minPts=min(7,N) knee',
        r_i='seventh nonself physical neighbour distance; zeros -> smallest positive r, else1',
        secondary_review='every primary noise or suspected point; never re-cluster only the noise subset',
        votes='primary retained and verified known use fullcontext7NN strict majority; candidate mutual component rescue has own candidate evidence and no fullcontext rawmajority',
        candidate_noise_rescue='sameNEW359metric candidate-only mutual nearest7 graph, component>=8 genuinephysicalgroups and mutualdegree>=1',
        old_U_or_parent_input=False,unknown_truth_input=False,source_NN_logits_veto=False,
        guarantees_99=False,status='FAIL_TARGET99',published=False,final_test_executed=False)


def local_vote_masks(neighbors,raw,unique_accept=None):
    """Neighbour indices are full-cohort first representative row indices."""
    ix=np.asarray(neighbors);r=np.asarray(raw)
    require(ix.ndim==2 and ix.dtype.kind in 'iu' and r.dtype==bool and r.shape==(len(ix),),
            'aligned physical-neighbour indices and full raw boolean')
    require(not ix.size or np.all((ix>=0)&(ix<len(r))), 'neighbour original-row index range')
    k=ix.shape[1];need=k//2+1
    result=dict(raw_majority=np.zeros(len(r),bool) if not k else (r[ix].sum(axis=1)>=need),
                neighbor_count=k,majority_required=need if k else None)
    if unique_accept is not None:
        u=np.asarray(unique_accept)
        if u.shape==(len(r),2):
            require(u.dtype==bool,'unique-accept matrix must be boolean')
            require(np.all(u.sum(axis=1)<=1),'a node cannot uniquely accept two classes')
            a=u
        else:
            require(u.shape==(len(r),) and u.dtype.kind in 'iu' and np.isin(u,(-1,0,1)).all(),
                    'unique accept codes: -1 ambiguous,0 BEN,1 KNA')
            a=np.stack((u==0,u==1),axis=1)
        require(not np.any(r&a.any(axis=1)), 'raw dual-reject and unique accept are disjoint evidence states')
        result['known_B_majority']=np.zeros(len(r),bool) if not k else a[ix,0].sum(axis=1)>=need
        result['known_K_majority']=np.zeros(len(r),bool) if not k else a[ix,1].sum(axis=1)>=need
    return result


def _select_primary(metric,z,d):
    best=labels=None;fallback=None;evaluations=[]
    for k in range(2,min(10,len(z))+1):
        eps,knee=knee_radius(np.partition(d,k-1,axis=1)[:,k-1])
        lab=DBSCAN(eps=eps,min_samples=k,metric='precomputed',n_jobs=1).fit_predict(d)
        supported=lab>=0;count=len(np.unique(lab[supported]));sc=ch=None
        if count>1 and int(supported.sum())>=count+2:
            sc=float(silhouette_score(d[np.ix_(supported,supported)],lab[supported],metric='precomputed',
                                     sample_size=min(1000,int(supported.sum())),random_state=SEED))
            ch=float(metric_CH(metric,z[supported],lab[supported]))
            if not np.isfinite(sc) or not np.isfinite(ch):sc=ch=None
        row=dict(minPts=k,eps=eps,knee_index=knee,cluster_count=count,non_noise_rows=int(supported.sum()),
                 silhouette=sc,calinski_harabasz=ch)
        evaluations.append(row)
        if k==min(K,len(z)):fallback=(row,lab)
        if sc is not None and (best is None or (sc,ch)>(best['silhouette'],best['calinski_harabasz'])):
            best,labels=row,lab
    if best is not None:return labels,dict(status='ORIGINAL_SC_CH_SELECTED',selected=best,evaluations=evaluations)
    if fallback is not None:return fallback[1],dict(status='SC_UNASSESSABLE_FIXED_K7_FALLBACK',selected=fallback[0],evaluations=evaluations,SC_CH_success_claimed=False)
    return np.full(len(z),-1,np.int64),dict(status='NO_CONTEXT_NEIGHBOUR',selected=None,evaluations=evaluations,SC_CH_success_claimed=False)


def candidate_mutual_component_support(distances,raw):
    """Candidate-only symmetric mutual k7 graph; components need >=8 groups.

    A component of8 contains at least7 other genuine groups per node via graph
    connectivity; direct mutual degree may be1. No fabricated/padded neighbours.
    Unknown labels and historic prediction state are not arguments.
    """
    d=np.asarray(distances,np.float64);r=np.asarray(raw);n=len(r)
    require(r.dtype==bool and d.shape==(n,n) and np.isfinite(d).all() and np.all(d>=0)
            and np.array_equal(d,d.T) and np.all(np.diag(d)==0),'candidate graph needs same complete new metric distance')
    ids=np.flatnonzero(r);m=len(ids);support=np.zeros(n,bool);degree=np.zeros(n,np.int64)
    component_id=np.full(n,-1,np.int64);component_size=np.zeros(n,np.int64)
    if m<2:return dict(candidate_component_support=support,candidate_mutual_degree=degree,
        candidate_component_id=component_id,candidate_component_size=component_size,
        manifest=dict(candidate_groups=m,neighbors_per_candidate=0,component_sizes=[],minimum_component_groups=8))
    sub=d[np.ix_(ids,ids)].copy();np.fill_diagonal(sub,np.inf);k=min(7,m-1)
    nearest=np.argsort(sub,axis=1,kind='stable')[:,:k]
    directed=np.zeros((m,m),bool);directed[np.arange(m)[:,None],nearest]=True
    mutual=directed&directed.T;deg=mutual.sum(axis=1);seen=np.zeros(m,bool);sizes=[]
    for first in range(m):
        if seen[first]:continue
        stack=[first];seen[first]=True;members=[]
        while stack:
            row=stack.pop();members.append(row)
            for other in np.flatnonzero(mutual[row]&~seen):seen[other]=True;stack.append(int(other))
        code=len(sizes);size=len(members);sizes.append(size);original=ids[members]
        component_id[original]=code;component_size[original]=size
        support[original]=(size>=8)&(deg[members]>=1)
    degree[ids]=deg
    return dict(candidate_component_support=support,candidate_mutual_degree=degree,
        candidate_component_id=component_id,candidate_component_size=component_size,
        manifest=dict(candidate_groups=m,neighbors_per_candidate=k,component_sizes=sizes,
            minimum_component_groups=8,minimum_mutual_degree=1,edges='both candidate endpoints list each other among nearest7 nonself under SAME new359Eq',
            fullcontext_raw_majority_required_for_rescue=False,old_U_seeds_used=False))


def route_physical_context(metric,Z,raw,*,max_distance_working_bytes=1024**3):
    z=np.asarray(Z,np.float64);raw=np.asarray(raw);n=len(z)
    require(z.ndim==2 and n>0 and z.shape[1]==metric.dimension and z.shape[1] in (359,)
            and np.isfinite(z).all() and raw.dtype==bool and raw.shape==(n,), 'complete finite actual new geometry and raw')
    require(type(max_distance_working_bytes)==int and max_distance_working_bytes>0
            and 3*n*n*8<=max_distance_working_bytes, 'explicit full-context memory budget; never silently crop rows')
    d=metric.pairwise_distances(z)
    require(d.shape==(n,n) and np.isfinite(d).all() and np.all(d>=0) and np.array_equal(d,d.T)
            and np.all(np.diag(d)==0), 'same new Eq9/10 symmetric full-context distance')
    k=min(K,n-1)
    if k:
        work=d.copy();np.fill_diagonal(work,np.inf)
        neighbours=np.argsort(work,axis=1,kind='stable')[:,:k]
        radii=np.take_along_axis(d,neighbours,axis=1)[:,-1]
    else:neighbours=np.empty((n,0),np.int64);radii=np.zeros(n)
    first,selection=_select_primary(metric,z,d)
    suspected=np.zeros(n,bool);reconstruction=np.zeros(n);density=np.zeros(n);anomaly=np.zeros(n)
    if np.any(first>=0):
        geom=metric_affinity_geometry(metric,z,first,d);supported=first>=0
        rcut=float(np.quantile(geom['reconstruction'][supported],.95,method='higher'))
        dcut=float(np.median(geom['density'][supported]))
        reconstruction=geom['reconstruction'];density=geom['density'];anomaly=geom['anomaly']
        suspected=(reconstruction>rcut)&(density<dcut)
        selection.update(reconstruction_cutoff=rcut,density_cutoff=dcut)
    primary=(first>=0)&~suspected
    positive=radii[radii>0]
    fallback=float(positive.min()) if len(positive) else 1.
    safe=np.where(radii>0,radii,fallback)
    local=d/np.sqrt(safe[:,None]*safe[None,:]);np.fill_diagonal(local,0.)
    second=np.full(n,-1,np.int64);secondary_info=dict(status='NO_CONTEXT_NEIGHBOUR')
    if n>1:
        minpts=min(K,n)
        eps,knee=knee_radius(np.partition(local,minpts-1,axis=1)[:,minpts-1])
        second=DBSCAN(eps=eps,min_samples=minpts,metric='precomputed',n_jobs=1).fit_predict(local)
        secondary_info=dict(status='FULL_CONTEXT_LOCAL_SCALE_DBSCAN',minPts=minpts,eps=eps,knee_index=knee,
                            zero_radius_replacement=fallback,zero_radius_groups=int(np.sum(radii==0)),
                            cluster_count=len(np.unique(second[second>=0])))
    secondary=(~primary)&(second>=0)
    votes=local_vote_masks(neighbours,raw)
    primary_retained=raw&(primary|secondary)&votes['raw_majority']
    components=candidate_mutual_component_support(d,raw)
    component_rescue=raw&components['candidate_component_support']&~primary_retained
    retained=primary_retained|component_rescue
    return dict(retained=retained,primary_retained=primary_retained,candidate_component_rescue=component_rescue,
                candidate_component_support=components['candidate_component_support'],
                candidate_mutual_degree=components['candidate_mutual_degree'],
                candidate_component_id=components['candidate_component_id'],
                candidate_component_size=components['candidate_component_size'],
                first=first,second=second,suspected=suspected,
                primary_supported=primary,secondary_supported=secondary,neighbors=neighbours,
                raw_majority=votes['raw_majority'],radii=radii,reconstruction=reconstruction,density=density,anomaly=anomaly,
                manifest=dict(recipe=recipe(),context_physical_groups=n,raw_groups=int(raw.sum()),
                    primary_selection=selection,secondary_selection=secondary_info,
                    retained_groups=int(retained.sum()),candidate_component_rescue_groups=int(component_rescue.sum()),
                    candidate_mutual_graph=components['manifest'],primary_supported_groups=int(primary.sum()),
                    secondary_supported_groups=int(secondary.sum()),raw_majority_groups=int(votes['raw_majority'].sum()),
                    full_unlabelled_context=True,old_U_seeds_used=False,query_truth_used=False))


def make_dvc_callback(physical_groups,*,max_distance_working_bytes=1024**3):
    groups=np.asarray(physical_groups)
    require(groups.ndim==1 and len(groups)>0,'complete role physical-group inventory')
    _,reps,inverse=np.unique(groups,return_index=True,return_inverse=True)
    # np.unique orders groups; first-representative row within each group is
    # frozen by the original cohort order. No view averaging or rounding.
    def callback(metric,Z,raw,unique_accept=None):
        z=np.asarray(Z,np.float64);r=np.asarray(raw)
        require(len(z)==len(groups) and r.shape==(len(groups),) and r.dtype==bool,'same full role frame')
        grouped_raw=np.zeros(len(reps),bool);np.logical_or.at(grouped_raw,inverse,r)
        q=route_physical_context(metric,z[reps],grouped_raw,max_distance_working_bytes=max_distance_working_bytes)
        result={name:(value[inverse] if isinstance(value,np.ndarray) and value.shape[:1]==(len(reps),) else value)
                for name,value in q.items() if name!='neighbors'}
        result['neighbors']=reps[q['neighbors']][inverse]
        result['retained']=q['retained'][inverse]&r
        result['representatives']=reps;result['inverse']=inverse
        result['physical_raw']=grouped_raw;result['physical_neighbors']=q['neighbors']
        if unique_accept is not None:
            u=np.asarray(unique_accept)
            physical_u=u[reps].copy()
            # A few legacy views of the same physical group can straddle a
            # numeric boundary. The density raw-OR context cannot also cast an
            # accepted-class vote from another alias of that very same node.
            if physical_u.ndim==2:physical_u[grouped_raw]=False
            else:physical_u[grouped_raw]=-1
            votes=local_vote_masks(q['neighbors'],grouped_raw,physical_u)
            result['known_B_majority']=votes['known_B_majority'][inverse]
            result['known_K_majority']=votes['known_K_majority'][inverse]
        result['manifest']=dict(q['manifest'],full_flow_rows=len(groups),physical_groups=len(reps),
                                representative_policy='first original-cohort complete geometry; no rounding/mean',
                                physical_raw_OR=True,retained_intersects_each_full_row_raw=True,
                                source_view_nonuniform_within_raw_group=not np.array_equal(z,z[reps][inverse]))
        return result
    return callback
