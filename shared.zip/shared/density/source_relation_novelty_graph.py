"""Source-calibrated relation nonconformity as an explicit unknown unary.

The field relation models and pair descriptors are frozen V1027 inputs.
Only genuine source Qcal groups form empirical reference distributions.
No query parameter, relation model, native transform or metric is fitted.
"""
from __future__ import annotations

from pathlib import Path
import hashlib
import importlib.util
import sys
import time

import numpy as np
from threadpoolctl import threadpool_limits

SCHEMA = 'V1029_SOURCE_RELATION_NOVELTY_UNKNOWN_UNARY_GRAPH'
CALIBRATION_SCHEMA = 'V1029_GENUINE_SOURCE_QCAL_RELATION_NONCONFORMITY_REFERENCES'
NONCONFORMITY_SCHEMA = 'V1029_RAW_CLASS_RESTRICTED_SOURCE_RELATION_NONCONFORMITY'
SOURCE_FIT_STATUS = 'SOURCE_PARAMETERS_COMPLETE'
UNKNOWN_BOOST_SCALE, TAIL_ALPHA = 7., .01
FIELD_CODE = dict(
    path='E:/Experiment/software transcition/target99_v1027_20261024/common/field_conditioned_relational_graph_v1027.py',
    sha256='1bd2211417b6f5a5d1dfd1bd0bf7d41e0dd835940b6d394d86b3cd5bd37870d1')


def _load_field():
    path = Path(FIELD_CODE['path'])
    if hashlib.sha256(path.read_bytes()).hexdigest() != FIELD_CODE['sha256']:
        raise ValueError('frozen V1027 field relation bytes changed')
    name = 'V1029_frozen_field_relation_' + FIELD_CODE['sha256']
    if name in sys.modules:
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


G = _load_field()
B, D = G.B, G.D
require = B.require


def _validate_edge(nr, zr, yc, gr, edge):
    require(edge['schema'] == G.SCHEMA
            and np.array_equal(gr, edge['source_groups'])
            and np.array_equal(yc, (np.asarray(edge['source_fine']) > 0).astype(np.int64))
            and edge['native_width'] == nr.shape[1] and edge['metric_width'] == zr.shape[1]
            and edge['model'].n_features_in_ == 6+2*nr.shape[1],
            'same frozen field relation, genuine source roster and view widths')


def _raw_probability(left_n, right_n, left_z, right_z, edge, paired_metric):
    if not len(left_n):
        return np.empty(0, np.float64)
    features = G.pair_features(left_n, right_n, left_z, right_z, edge['scales'], paired_metric)
    with threadpool_limits(limits=G.CPU_THREADS):
        probability = edge['model'].predict_proba(features)[:, 1]
    require(probability.shape == (len(left_n),) and np.isfinite(probability).all()
            and np.all((probability >= 0) & (probability <= 1)),
            'raw fixed same-fine probabilities before any QR mass normalization')
    return probability


def source_relation_nonconformity(N_R, Z_R, ycoarse, g_R, N_Q, Z_Q, g_Q,
                                  edge_bundle, paired_metric):
    """Return r_c=1-max(raw same-fine probability), for each source coarse c.

    Searches use native7 and Euclidean-paper32 reranked by the original metric
    to paper7, separately inside each real source class. Every source group
    occurring anywhere in the query batch is removed before either search.
    An unavailable class returns r=1 plus an explicit unavailable marker.
    """
    started = time.perf_counter()
    nr, zr, nq, zq = (B._matrix(x) for x in (N_R, Z_R, N_Q, Z_Q))
    r, n = len(nr), len(nq)
    require(n > 0 and len(zr) == r and len(zq) == n
            and nr.shape[1] == nq.shape[1] and zr.shape[1] == zq.shape[1],
            'same finite source/query native and paper coordinates')
    gr, gq = B._strings(g_R, r, 'source groups'), B._strings(g_Q, n, 'canonical query groups')
    yc = B._labels(ycoarse, r, (0, 1))
    _validate_edge(nr, zr, yc, gr, edge_bundle)
    keep = ~np.isin(gr, gq)
    maximum = np.zeros((n, 2), np.float64)
    available = np.zeros(2, bool)
    counts = np.zeros(2, np.int64)
    native_neighbors, paper_shortlists, paper_neighbors = {}, {}, {}
    relation_queries, relation_sources, relation_probabilities = {}, {}, {}
    for c in (0, 1):
        key = str(c)
        source_indices = np.flatnonzero(keep & (yc == c))
        counts[c], available[c] = len(source_indices), bool(len(source_indices))
        cn, cz = nr[source_indices], zr[source_indices]
        native = D._cross_euclidean_neighbors(nq, cn, B.K_NATIVE)
        shortlist = D._cross_euclidean_neighbors(zq, cz, B.PAPER_EUCLIDEAN_SHORTLIST)
        paper = D._refine_paper(zq, cz, shortlist, paired_metric)
        native_neighbors[key] = source_indices[native]
        paper_shortlists[key] = source_indices[shortlist]
        paper_neighbors[key] = source_indices[paper]
        query_rows, physical_rows = [], []
        for i in range(n):
            # np.unique keeps the original source roster's deterministic order.
            union = np.unique(np.r_[native[i], paper[i]])
            query_rows.extend([i]*len(union))
            physical_rows.extend(source_indices[union].tolist())
        qi, si = np.asarray(query_rows, np.int64), np.asarray(physical_rows, np.int64)
        probability = _raw_probability(nq[qi], nr[si], zq[qi], zr[si], edge_bundle, paired_metric)
        np.maximum.at(maximum[:, c], qi, probability)
        relation_queries[key], relation_sources[key], relation_probabilities[key] = qi, si, probability
        require(np.all(yc[si] == c) and not np.isin(gr[si], gq).any(),
                'class-restricted genuine source roster excludes all query-overlap groups')
    return dict(
        schema=NONCONFORMITY_SCHEMA, nonconformity=1.-maximum,
        raw_max_probability=maximum, class_available=available, source_class_counts=counts,
        source_anchor_indices=np.flatnonzero(keep), excluded_source_anchor_groups=gr[~keep],
        class_native_neighbors=native_neighbors, class_paper_euclidean_shortlist=paper_shortlists,
        class_paper_neighbors=paper_neighbors, class_relation_query=relation_queries,
        class_relation_source_original=relation_sources, class_relation_probability=relation_probabilities,
        raw_probability_before_QR_normalization=True, per_class_neighbor_quotas=True,
        source_overlap_exclusion_is_batch_wide=True, genuine_source_references_only=True,
        reference_resampling=False, query_parameter_fit=False, new_NN_fits=0,
        new_HGB_fits=0, new_metric_fits=0, seconds=time.perf_counter()-started)


def calibrate_refs(nonconformity, truecoarse, genuine_unique_groups):
    """Fit two empirical source-Qcal references; caller excludes held family.

    The caller must first require both source_relation_nonconformity class
    availability markers. Physical groups must be unique; FIT copies are not
    calibration observations. These references do not assert conformal or
    finite-sample guarantees for dependent graph actions or true UNA.
    """
    values = np.asarray(nonconformity, np.float64)
    require(values.ndim == 2 and values.shape[1] == 2 and 0 < len(values) <= 6000
            and np.isfinite(values).all() and np.all((values >= 0) & (values <= 1)),
            'finite source Qcal two-class nonconformity within genuine source cap')
    y = B._labels(truecoarse, len(values), (0, 1))
    groups = B._strings(genuine_unique_groups, len(values), 'genuine source Qcal groups')
    references, reference_groups = {}, {}
    counts = np.bincount(y, minlength=2)
    require(np.all(counts > 0), 'nonempty genuine Qcal reference in both source coarse classes')
    for c in (0, 1):
        selected = np.flatnonzero(y == c)
        order = np.argsort(values[selected, c], kind='stable')
        references[str(c)] = values[selected[order], c].copy()
        reference_groups[str(c)] = groups[selected[order]].copy()
    minimum = 1./(counts.astype(np.float64)+1.)
    bound = UNKNOWN_BOOST_SCALE*max(0., 1.-float(minimum.max())/TAIL_ALPHA)
    return dict(
        schema=CALIBRATION_SCHEMA, reference_nonconformity_by_class=references,
        reference_groups_by_class=reference_groups, class_counts=counts,
        class_minimum_p_value=minimum, minimum_possible_known_p_value=float(minimum.max()),
        discrete_max_boost=float(bound), genuine_unique_group_count=len(groups),
        source_relation_reference_fits=2, source_Qcal_role_caller_enforced=True,
        held_family_exclusion_caller_enforced=True, reference_resampling=False,
        upper_tail_ties_conservative=True, alpha=TAIL_ALPHA, unknown_boost_scale=UNKNOWN_BOOST_SCALE,
        finite_sample_graph_guarantee_claimed=False, true_UNA_calibration=False,
        new_NN_fits=0, new_HGB_fits=0, new_metric_fits=0, query_parameter_fit=False)


def calibrated_boost(nonconformity, relation_calibration):
    """Conservative upper-tail ranks, then reject known only if both reject."""
    values = np.asarray(nonconformity, np.float64)
    require(values.ndim == 2 and values.shape[1] == 2 and np.isfinite(values).all()
            and np.all((values >= 0) & (values <= 1)), 'finite two-class query nonconformity')
    cal = relation_calibration
    require(cal['schema'] == CALIBRATION_SCHEMA and cal['alpha'] == TAIL_ALPHA
            and cal['unknown_boost_scale'] == UNKNOWN_BOOST_SCALE,
            'frozen source relation reference formula and constants')
    p = np.empty_like(values)
    counts = np.empty(2, np.int64)
    all_groups = []
    for c in (0, 1):
        reference = np.asarray(cal['reference_nonconformity_by_class'][str(c)], np.float64)
        require(reference.ndim == 1 and len(reference) > 0 and np.isfinite(reference).all()
                and np.all((reference >= 0) & (reference <= 1))
                and np.all(reference[1:] >= reference[:-1]), 'nonempty sorted genuine class reference')
        groups = B._strings(cal['reference_groups_by_class'][str(c)], len(reference), 'class reference groups')
        all_groups.extend(groups.tolist())
        counts[c] = len(reference)
        # side=left counts every reference equal to the query in the upper tail.
        at = np.searchsorted(reference, values[:, c], side='left')
        p[:, c] = (1.+len(reference)-at)/(len(reference)+1.)
    require(len(set(all_groups)) == len(all_groups)
            and np.array_equal(counts, cal['class_counts']), 'genuine unique class calibration parents/counts')
    known_p = p.max(axis=1)
    boost = UNKNOWN_BOOST_SCALE*np.maximum(0., 1.-known_p/TAIL_ALPHA)
    minimum = 1./(counts.astype(np.float64)+1.)
    bound = UNKNOWN_BOOST_SCALE*max(0., 1.-float(minimum.max())/TAIL_ALPHA)
    require(np.all(boost[known_p >= TAIL_ALPHA] == 0.)
            and np.all(boost >= 0.) and np.all(boost <= bound+1e-12),
            'conservative zero-boost region and discrete finite-reference bound')
    return dict(class_p_values=p, known_p_value=known_p, boost=boost,
                class_reference_counts=counts, class_minimum_p_value=minimum,
                minimum_possible_known_p_value=float(minimum.max()), discrete_max_boost=float(bound),
                alpha=TAIL_ALPHA, unknown_boost_scale=UNKNOWN_BOOST_SCALE,
                source_relation_reference_fits=0, query_parameter_fit=False)


def infer_graph(N_R, Z_R, ycoarse, g_R, N_Q, Z_Q, g_Q, threeway_logits,
                parent_group_labels, edge_bundle, paired_metric, *, relation_calibration):
    started = time.perf_counter()
    nr, zr, nq, zq = B._matrix(N_R), B._matrix(Z_R), B._matrix(N_Q), B._matrix(Z_Q)
    n, r = len(nq), len(nr)
    require(n > 0 and len(zq) == n and len(zr) == r and nr.shape[1] == nq.shape[1]
            and zr.shape[1] == zq.shape[1], 'matched native/paper source-query coordinates')
    gr, gq = B._strings(g_R, r, 'source groups'), B._strings(g_Q, n, 'canonical query groups')
    yc, parent = B._labels(ycoarse, r, (0, 1)), B._labels(parent_group_labels, n, (0, 1, 2))
    _validate_edge(nr, zr, yc, gr, edge_bundle)
    logits = B._matrix(threeway_logits); require(logits.shape == (n, 3), 'continuous weak threeway logits')
    support = source_relation_nonconformity(nr, zr, yc, gr, nq, zq, gq, edge_bundle, paired_metric)
    require(np.all(support['class_available']), 'both source classes available after query overlap exclusion')
    novelty = calibrated_boost(support['nonconformity'], relation_calibration)
    keep = ~np.isin(gr, gq); source_indices = np.flatnonzero(keep)
    source_n, source_z, source_y = nr[keep], zr[keep], yc[keep]
    m = len(source_indices)

    q_native = B._exact_euclidean_neighbors(nq, nq, np.arange(n), B.K_NATIVE)
    q_shortlist = B._exact_euclidean_neighbors(zq, zq, np.arange(n), B.PAPER_EUCLIDEAN_SHORTLIST)
    q_paper = D._refine_paper(zq, zq, q_shortlist, paired_metric)
    s_native = D._cross_euclidean_neighbors(nq, source_n, B.K_NATIVE)
    s_shortlist = D._cross_euclidean_neighbors(zq, source_z, B.PAPER_EUCLIDEAN_SHORTLIST)
    s_paper = D._refine_paper(zq, source_z, s_shortlist, paired_metric)
    qq, qr = set(), set()
    for i in range(n):
        for j in np.unique(np.r_[q_native[i], q_paper[i]]):
            j = int(j); require(j != i, 'query self edges excluded')
            qq.add((min(i, j), max(i, j)))
        for j in np.unique(np.r_[s_native[i], s_paper[i]]):
            qr.add((i, int(j)))
    qq, qr = np.asarray(sorted(qq), np.int64).reshape(-1, 2), np.asarray(sorted(qr), np.int64).reshape(-1, 2)
    pq = _raw_probability(nq[qq[:, 0]], nq[qq[:, 1]], zq[qq[:, 0]], zq[qq[:, 1]], edge_bundle, paired_metric)
    pr = _raw_probability(nq[qr[:, 0]], source_n[qr[:, 1]], zq[qr[:, 0]], source_z[qr[:, 1]], edge_bundle, paired_metric)
    degree = np.bincount(qq.ravel(), minlength=n)
    qw = 7.*pq/np.maximum(7, np.maximum(degree[qq[:, 0]], degree[qq[:, 1]]))
    mass = np.bincount(qr[:, 0], weights=pr, minlength=n)
    rw = pr/np.maximum(1., mass[qr[:, 0]])
    source_unary = B.source_elimination(qr[:, 0], source_y[qr[:, 1]], rw, n)
    weighted_degree = np.bincount(qq[:, 0], weights=qw, minlength=n)+np.bincount(qq[:, 1], weights=qw, minlength=n)
    require(np.all(weighted_degree <= 7.+1e-12) and np.all(source_unary[:, 2] <= 1.+1e-12),
            'only numerical validation of unchanged edge-mass bounds')
    centered = logits-logits.max(axis=1, keepdims=True)
    prob = np.exp(centered); prob /= prob.sum(axis=1, keepdims=True)
    base = 1.-prob
    strength = np.where(parent == 2, B.UNKNOWN_CHANGE_PRIOR, B.KNOWN_CHANGE_PRIOR)
    prior = strength[:, None]*(np.arange(3)[None, :] != parent[:, None])
    no_parent = base+source_unary
    unknown_unary = np.zeros((n, 3), np.float64)
    unknown_unary[:, 2] = -novelty['boost']
    no_parent += unknown_unary
    inference = B.alpha_expansion(no_parent+prior, qq[:, 0], qq[:, 1], qw, parent)
    labels = inference['labels']
    costs = B.local_costs(labels, no_parent, qq[:, 0], qq[:, 1], qw)
    coarse = costs[:, :2].argmin(axis=1).astype(np.int8); row = np.arange(n)
    S = costs[:, :2].min(axis=1)-costs[:, 2]
    counter = costs+np.asarray([B.UNKNOWN_CHANGE_PRIOR, B.UNKNOWN_CHANGE_PRIOR, 0.])[None, :]
    A = np.minimum(counter[row, 1-coarse], counter[:, 2])-counter[row, coarse]
    known = (labels < 2) & (labels == coarse) & (A > 0.)
    raw = (labels == 2) & (S > 0.)
    require(not np.any(known & raw), 'same disjoint positive known/unknown proposals')
    return dict(schema=SCHEMA, labels=labels.astype(np.int8), S=S, A=A, predicted_coarse=coarse,
        known_proposal=known, raw_proposal=raw, local_cost_no_parent=costs,
        local_cost_actual_prior=costs+prior, weak_probabilities=prob, base_unary=base,
        source_unary=source_unary, prior_unary=prior, QQ_left=qq[:, 0], QQ_right=qq[:, 1],
        QQ_probability=pq, QQ_weight=qw, QQ_degree=degree, QQ_weighted_degree=weighted_degree,
        QR_query=qr[:, 0], QR_source_original=source_indices[qr[:, 1]], QR_probability=pr, QR_weight=rw,
        source_anchor_indices=source_indices, excluded_source_anchor_groups=gr[~keep],
        native_QQ_neighbors=q_native, native_QS_neighbors=s_native,
        paper_QQ_euclidean_shortlist=q_shortlist, paper_QS_euclidean_shortlist=s_shortlist,
        paper_QQ_neighbors=q_paper, paper_QS_neighbors=s_paper,
        native_neighbors=np.concatenate((s_native, m+q_native), axis=1),
        paper_euclidean_shortlist=np.concatenate((s_shortlist, m+q_shortlist), axis=1),
        paper_neighbors=np.concatenate((s_paper, m+q_paper), axis=1),
        neighbor_index_convention='combined compatibility arrays: kept source first, then query; independent QQ arrays use query-local indices, QS arrays kept-source-local indices',
        QQ_QS_search_populations_decoupled=True,
        fixed_theta_query_QQ_invariant_to_source_anchor_addition=True,
        native_neighbors_exact_full_search=True, paper_neighbors_are_sparse_shortlist_approximation=True,
        source_anchor_elimination_exact=True, energy_history=inference['energy_history'],
        expansion_moves=inference['moves'], converged=inference['converged'],
        completed_sweeps=inference['completed_sweeps'], accepted_moves=inference['accepted_moves'],
        global_three_label_optimum_claimed=False, inference_seconds=time.perf_counter()-started,
        reused_energy_code=G.ORIGINAL, reused_field_relation_code=FIELD_CODE,
        source_relation_nonconformity=support['nonconformity'],
        source_relation_raw_max_probability=support['raw_max_probability'],
        source_relation_class_p_values=novelty['class_p_values'],
        source_relation_known_p_value=novelty['known_p_value'],
        source_relation_unknown_boost=novelty['boost'], source_relation_unknown_unary=unknown_unary,
        source_relation_class_reference_counts=novelty['class_reference_counts'],
        source_relation_class_minimum_p_value=novelty['class_minimum_p_value'],
        source_relation_discrete_max_boost=novelty['discrete_max_boost'],
        source_relation_support=support, source_relation_reference_fits=0,
        source_relation_finite_sample_graph_guarantee_claimed=False,
        new_NN_fits=0, new_HGB_fits=0, new_metric_fits=0,
        source_only_evidence_cannot_certify_known=True, query_parameter_fit=False,
        current_truth_used=False, published=False, final_test_executed=False)


def pure_small_checks():
    """Synthetic array/rank/roster checks; no trained estimator is run or fitted."""
    refs = calibrate_refs(np.asarray([[.2, .8], [.2, .8], [.6, .8],
                                     [.8, .3], [.8, .7], [.8, .7]]),
                          np.asarray([0, 0, 0, 1, 1, 1]), np.asarray(['g%d'%i for i in range(6)]))
    ties = calibrated_boost(np.asarray([[.2, .7]]), refs)
    require(np.array_equal(ties['class_p_values'], [[1., .75]]) and ties['boost'][0] == 0.,
            'equal references counted conservatively in upper tail')

    def constant_refs(count):
        return calibrate_refs(np.full((2*count, 2), .2),
                              np.repeat(np.asarray([0, 1]), count),
                              np.asarray(['rank%d'%i for i in range(2*count)]))

    at_alpha = calibrated_boost(np.asarray([[1., 1.]]), constant_refs(99))
    require(np.array_equal(at_alpha['class_p_values'], [[.01, .01]])
            and at_alpha['boost'][0] == 0., 'exact alpha and small reference counts give zero boost')
    large = calibrated_boost(np.asarray([[1., 1.], [1., 0.]]), constant_refs(150))
    require(large['boost'][0] > 0. and large['known_p_value'][1] == 1.
            and large['boost'][1] == 0. and large['boost'][0] == large['discrete_max_boost'],
            'max class p direction and actual discrete maximum')

    class SyntheticRelation:
        n_features_in_ = 10

        def predict_proba(self, features):
            probability = np.clip(.2+.02*features[:, 8], 0., 1.)
            return np.column_stack((1.-probability, probability))

    nr = np.asarray([[0., 0.], [1., 0.], [3., 0.], [10., 0.], [12., 0.]])
    zr = nr[:, :1].copy()
    yc = np.asarray([0, 0, 0, 1, 1])
    gr = np.asarray(['sameQ', 'b2', 'b3', 'k1', 'k2'])
    nq, zq = np.asarray([[0., 0.], [2., 0.]]), np.asarray([[0.], [2.]])
    edge = dict(schema=G.SCHEMA, model=SyntheticRelation(), scales=np.ones(2),
                source_groups=gr, source_fine=np.asarray([0, 0, 0, 1, 2]), native_width=2, metric_width=1)
    metric = lambda left, right: np.linalg.norm(left-right, axis=1)
    support = source_relation_nonconformity(nr, zr, yc, gr, nq, zq,
                                            np.asarray(['sameQ', 'q2']), edge, metric)
    require(np.array_equal(support['source_class_counts'], [2, 2])
            and support['excluded_source_anchor_groups'].tolist() == ['sameQ'],
            'all query-overlap source groups removed before class search')
    for c in (0, 1):
        si = support['class_relation_source_original'][str(c)]
        require(np.all(yc[si] == c) and np.all(si != 0), 'class restricted roster with original indices')
        for i in range(2):
            selected = support['class_relation_query'][str(c)] == i
            expected = 1.-support['class_relation_probability'][str(c)][selected].max()
            require(support['nonconformity'][i, c] == expected, 'maximum raw same-fine affinity, no mass normalization')
    empty = source_relation_nonconformity(nr, zr, yc, gr, nq, zq,
                                          np.asarray(['k1', 'k2']), edge, metric)
    require(not empty['class_available'][1] and np.all(empty['nonconformity'][:, 1] == 1.),
            'unavailable class has explicit marker and neutral raw maximum zero')
    negative = infer_graph(nr, zr, yc, gr, nq, zq, np.asarray(['sameQ', 'q2']),
                           np.asarray([[2., 0., -1.], [2., 0., -1.]]), np.asarray([0, 0]),
                           edge, metric, relation_calibration=constant_refs(150))
    require(np.array_equal(negative['labels'], [2, 2])
            and np.all(negative['source_relation_unknown_unary'][:, :2] == 0.)
            and np.array_equal(negative['source_relation_unknown_unary'][:, 2],
                               -negative['source_relation_unknown_boost'])
            and np.any((negative['base_unary']+negative['source_unary']
                        +negative['source_relation_unknown_unary'])[:, 2] < 0.)
            and np.all(negative['QQ_weighted_degree'] <= 7.+1e-12)
            and np.all(negative['source_unary'][:, 2] <= 1.+1e-12)
            and all(m['candidate'] < m['before'] for m in negative['expansion_moves'] if m['accepted']),
            'unknown-only negative unary is integrated with the frozen bounded graph solver')
    return dict(upper_tail_ties=True, zero_boost_at_or_above_alpha=True,
                known_p_uses_maximum=True, small_n99_max_boost=float(at_alpha['discrete_max_boost']),
                n150_actual_discrete_max_boost=float(large['discrete_max_boost']),
                all_query_overlap_groups_excluded=True, source_class_rosters_restricted=True,
                raw_max_probability_before_normalization=True, unavailable_class_marker=True,
                negative_unknown_unary_solver=True, old_solver_regression_suite_rerun=False,
                trained_estimator_fits=0, trained_estimator_predictions=0,
                source_reference_data_reads=0, actual_role_reads=0, current_truth_reads=0,
                frozen_field_code=FIELD_CODE, frozen_mathematical_code=G.ORIGINAL)
