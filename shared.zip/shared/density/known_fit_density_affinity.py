"""Known-reference realization of the paper's affinity/error/density score.

This is an explicitly versioned candidate, not literal Algorithm 3 pseudocode.
All geometry and normalization fit known training only. A sparse query can be
rejected only by THREE strict known-calibrated signals, never by noise alone.
alpha=beta=1 and the existing bounded DVC frontier are declared before scoring.
"""

from __future__ import annotations

import hashlib

import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

from .bounded_density_frontier import bounded_quality
from .dvc import _stable_select_dbscan


SCHEMA = "known-fit-density-affinity-v1"
ALPHA = BETA = 1.0


def _geometry(values, available):
    x, mask = np.asarray(values, dtype=np.float64), np.asarray(available)
    if (x.ndim != 2 or x.shape[1] == 0 or mask.shape != (len(x),)
            or mask.dtype != bool or not np.isfinite(x).all()
            or np.any(x[~mask] != 0)):
        raise ValueError("affinity needs finite geometry, boolean availability and zero missing evidence")
    return x, mask


def _raw_scores(model, scaled):
    if not len(scaled):
        return np.empty(0), np.empty(0)
    squared = ((scaled[:, None, :] - model["centres"][None, :, :]) ** 2).sum(axis=2)
    # Work in log affinity to avoid exp-underflow in -alpha*log(p).
    log_affinity = -squared / (2 * model["bandwidths"][None, :] ** 2)
    reconstruction = (squared - ALPHA * log_affinity).min(axis=1)
    kth = model["neighbours"].kneighbors(scaled, return_distance=True)[0][:, -1]
    log_density = -0.5 * (kth / model["selected"]["eps"]) ** 2
    if not np.isfinite(reconstruction).all() or not np.isfinite(log_density).all():
        raise ValueError("affinity geometry overflows finite numeric evidence")
    return reconstruction, log_density


def fit_affinity(reference, reference_ids, reference_available, *, seed):
    x, mask = _geometry(reference, reference_available)
    ids = np.asarray(reference_ids, dtype=str)
    if ids.shape != (len(x),) or len(set(ids.tolist())) != len(ids):
        raise ValueError("known affinity reference identities differ or repeat")
    if mask.sum() < 5:
        return {"schema_version": SCHEMA, "available": False,
                "audit": {"status": "INSUFFICIENT_AVAILABLE_KNOWN_REFERENCE", "known_fit_only": True}}
    order = np.argsort(ids[mask], kind="stable")
    known, known_ids = x[mask][order], ids[mask][order]
    _, legacy = _stable_select_dbscan(known, known_ids, seed)
    frontier = [{**row, "legacy_quality": row["quality"],
                 "quality": bounded_quality(row, len(known))} for row in legacy["evaluations"]]
    selected = max(frontier, key=lambda row: (row["quality"], row["cluster_count"],
                                               -row["noise_fraction"], -row["eps"]))
    scaler = StandardScaler().fit(known)
    scaled = scaler.transform(known)
    labels = DBSCAN(eps=selected["eps"], min_samples=selected["min_samples"], n_jobs=1).fit_predict(scaled)
    centres, bandwidths, supports = [], [], []
    for label in sorted(set(labels[labels >= 0].tolist())):
        members = scaled[labels == label]
        centre = members.mean(axis=0)
        bandwidth = float(np.linalg.norm(members - centre, axis=1).mean())
        centres.append(centre)
        # A zero-radius discrete cluster needs a declared finite kernel.
        bandwidths.append(bandwidth if bandwidth > 0 else selected["eps"])
        supports.append(len(members))
    # Known noise is not discarded: each retained reference contributes a
    # support kernel, preventing an unsupported claim of complete known space.
    for index in np.flatnonzero(labels < 0):
        centres.append(scaled[index])
        bandwidths.append(selected["eps"])
        supports.append(1)
    model = {"schema_version": SCHEMA, "available": True, "scaler": scaler,
             "centres": np.asarray(centres), "bandwidths": np.asarray(bandwidths),
             "selected": selected, "dimensions": x.shape[1],
             "neighbours": NearestNeighbors(n_neighbors=selected["min_samples"], n_jobs=1).fit(scaled)}
    r, _ = _raw_scores(model, scaled)
    model["normalization_min"] = float(r.min())
    model["normalization_range"] = float(r.max() - r.min()) if r.max() > r.min() else 1.0
    model["audit"] = {"status": "KNOWN_FIT_ONLY_DVC_DENSITY_AFFINITY",
        "known_fit_only": True, "query_used_for_centres_scaler_bandwidth_or_normalization": False,
        "alpha_predeclared": ALPHA, "beta_predeclared": BETA,
        "local_density_definition": "exp(-0.5*(known_fit_kth_neighbour_distance/known_fit_eps)**2)",
        "selected": selected, "evaluations": frontier, "available_reference_rows": len(known),
        "unavailable_reference_rows_retained": int((~mask).sum()),
        "cluster_kernel_count": int(np.sum(labels >= 0) > 0 and len(set(labels[labels >= 0].tolist()))),
        "known_noise_singleton_kernels_retained": int((labels < 0).sum()),
        "kernel_support": supports, "scaler_mean": scaler.mean_.tolist(), "scaler_scale": scaler.scale_.tolist(),
        "normalization_min": model["normalization_min"], "normalization_range": model["normalization_range"],
        "fit_geometry_sha256": hashlib.sha256(np.ascontiguousarray(known).tobytes()).hexdigest(),
        "target_labels_used": False, "independent_final_claim_allowed": False}
    return model


def score_affinity(model, query, query_available):
    x, mask = _geometry(query, query_available)
    available = mask & model["available"]
    r, log_density, score = (np.zeros(len(x), dtype=np.float64) for _ in range(3))
    if model["available"]:
        if x.shape[1] != model["dimensions"]:
            raise ValueError("affinity query and known-fit dimensions differ")
        r[available], log_density[available] = _raw_scores(model, model["scaler"].transform(x[available]))
        normalized = np.maximum(0, (r[available] - model["normalization_min"]) / model["normalization_range"])
        score[available] = normalized * np.exp(-BETA * np.exp(log_density[available]))
        if not np.isfinite(score).all():
            raise ValueError("affinity anomaly score is not finite")
    return {"available": available, "reconstruction": r, "log_density": log_density, "anomaly_score": score}


def _vectors(primary, baseline, scores):
    p, b = np.asarray(primary), np.asarray(baseline)
    if (p.ndim != 1 or p.dtype.kind not in "iu" or b.shape != p.shape or b.dtype.kind not in "iu"
            or not np.isin(p, (0, 1)).all() or not np.isin(b, (0, 1, 2)).all()
            or np.any((b != 2) & (b != p)) or set(scores) != {"available", "reconstruction", "log_density", "anomaly_score"}
            or any(np.asarray(v).shape != p.shape for v in scores.values())
            or np.asarray(scores["available"]).dtype != bool
            or any(not np.isfinite(scores[k]).all() for k in ("reconstruction", "log_density", "anomaly_score"))
            or np.any(scores["reconstruction"] < 0) or np.any(scores["anomaly_score"] < 0)
            or np.any(scores["log_density"] > 0)
            or any(np.any(np.asarray(scores[k])[~scores["available"]] != 0)
                   for k in ("reconstruction", "log_density", "anomaly_score"))):
        raise ValueError("known affinity predictions or score evidence differ")
    return p, b


def calibrate_affinity(known_truth, primary, baseline, scores):
    p, b = _vectors(primary, baseline, scores)
    truth = np.asarray(known_truth)
    if truth.shape != p.shape or truth.dtype.kind not in "iu" or set(truth.tolist()) != {0, 1}:
        raise ValueError("affinity calibration accepts paired BEN/KNA truth only")
    branches = []
    for label, name in ((0, "BEN"), (1, "KNA")):
        protected = (truth == label) & (b == label) & (p == label) & scores["available"]
        branches.append({"stage1_label": label, "name": name, "protected_correct_available": int(protected.sum()),
            "admitted": bool(protected.any()),
            "reconstruction_strict_maximum": float(scores["reconstruction"][protected].max()) if protected.any() else None,
            "log_density_strict_minimum": float(scores["log_density"][protected].min()) if protected.any() else None,
            "anomaly_score_strict_maximum": float(scores["anomaly_score"][protected].max()) if protected.any() else None})
    policy = {"schema_version": SCHEMA, "branches": branches, "known_truth_only": True,
              "query_truth_used": False, "unknown_labels_used": False,
              "noise_label_is_not_rejection_evidence": True, "baseline_UNA_retained": True}
    final, _ = apply_affinity(p, b, scores, policy)
    if np.any((b == truth) & (final != truth)):
        raise AssertionError("affinity strict known calibration protection failed")
    return policy


def apply_affinity(primary, baseline, scores, policy):
    p, b = _vectors(primary, baseline, scores)
    branches = policy.get("branches", [])
    if (policy.get("schema_version") != SCHEMA or policy.get("known_truth_only") is not True
            or policy.get("query_truth_used") is not False or policy.get("unknown_labels_used") is not False
            or policy.get("noise_label_is_not_rejection_evidence") is not True
            or policy.get("baseline_UNA_retained") is not True or len(branches) != 2
            or [v.get("stage1_label") for v in branches] != [0, 1]
            or any(type(v.get("admitted")) is not bool for v in branches)):
        raise ValueError("affinity policy is not a frozen known-only two-branch policy")
    permission = np.zeros(len(p), dtype=bool)
    for branch in branches:
        if not branch["admitted"]:
            continue
        thresholds = [branch[k] for k in ("reconstruction_strict_maximum", "log_density_strict_minimum", "anomaly_score_strict_maximum")]
        if not all(isinstance(v, (int, float)) and not isinstance(v, bool) and np.isfinite(v) for v in thresholds):
            raise ValueError("admitted affinity policy lacks finite known thresholds")
        permission |= (p == branch["stage1_label"]) & scores["available"] & (
            scores["reconstruction"] > thresholds[0]) & (scores["log_density"] < thresholds[1]) & (
            scores["anomaly_score"] > thresholds[2])
    final = b.copy()
    final[permission] = 2
    return final, permission & (b != 2)


def secondary_cluster(model, query, query_ids, proposal):
    """Keep known-fit scaling and eps/minPts; never re-fit to sparse queries."""
    x = np.asarray(query, dtype=np.float64)
    ids, mask = np.asarray(query_ids, dtype=str), np.asarray(proposal)
    if (mask.dtype != bool or mask.shape != (len(x),) or ids.shape != mask.shape
            or len(set(ids.tolist())) != len(ids) or not np.isfinite(x).all()):
        raise ValueError("secondary affinity candidate identities or mask differ")
    labels = np.full(len(x), -2, dtype=np.int64)
    if model["available"] and mask.any():
        indices = np.flatnonzero(mask)
        order = np.argsort(ids[indices], kind="stable")
        indices = indices[order]
        labels[indices] = DBSCAN(eps=model["selected"]["eps"],
            min_samples=model["selected"]["min_samples"], n_jobs=1).fit_predict(model["scaler"].transform(x[indices]))
    return labels
