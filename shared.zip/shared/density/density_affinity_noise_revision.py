"""Opt-in, label-blind Algorithm-3 noise correction candidate.

The manuscript specifies cluster centres, mean-distance kernel bandwidth,
affinity reconstruction, density-modulated anomaly and a second DVC pass
with the *same* eps/minPts. It does not specify alpha/beta, local-density
normalisation or rejection cutoffs. This development implementation declares
alpha=beta=1, density=1/(1+7th-neighbour-distance), strict known-only
reconstruction cutoffs and known median density cutoffs. These choices are
not fitted on UNA. Low density does NOT mean DBSCAN non-core: selecting
only non-core points cannot create a core in a subset at the same eps/minPts.

No singleton/noise point is called UNA. A correction needs a non-noise
second-pass cluster with no known reference anchor. All Stage-1 predictions
and existing final decisions are frozen; correctly classified known
calibration rows must remain unchanged. This is not a final-test runner.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

from .dvc import _stable_select_dbscan


@dataclass
class AffinityGeometry:
    reconstruction: np.ndarray
    density: np.ndarray
    anomaly: np.ndarray
    affinity: np.ndarray
    nearest_cluster: np.ndarray
    neighbor_count: np.ndarray
    density_neighbor_distance: np.ndarray
    clusters: list[dict[str, Any]]


@dataclass
class NoiseRevision:
    final_prediction: np.ndarray
    correction_candidate: np.ndarray
    suspected_noise: np.ndarray
    primary_cluster: np.ndarray
    second_cluster: np.ndarray
    geometry: AffinityGeometry | None
    manifest: dict[str, Any]


def affinity_geometry(
    scaled_features: np.ndarray, labels: np.ndarray, *, eps: float,
    min_samples: int, alpha: float = 1.0, beta: float = 1.0,
) -> AffinityGeometry:
    """Evaluate Algorithm 3 in the exact coordinate system used by DVC."""
    values = np.asarray(scaled_features, dtype=np.float64)
    clusters = np.asarray(labels)
    if (values.ndim != 2 or not len(values) or not values.shape[1]
            or not np.isfinite(values).all() or clusters.shape != (len(values),)
            or clusters.dtype.kind not in "iu" or np.any(clusters < -1)
            or not np.isfinite(eps) or eps <= 0
            or not isinstance(min_samples, int) or min_samples < 2
            or not np.isfinite(alpha) or alpha < 0
            or not np.isfinite(beta) or beta < 0):
        raise ValueError("affinity geometry requires finite aligned DVC coordinates")
    cluster_ids = sorted(set(clusters[clusters >= 0].tolist()))
    if not cluster_ids:
        raise ValueError("affinity geometry requires a non-noise primary cluster")
    errors, log_affinities, descriptions = [], [], []
    for cluster in cluster_ids:
        part = values[clusters == cluster]
        centre = np.mean(part, axis=0)
        bandwidth = max(float(np.mean(np.linalg.norm(part - centre, axis=1))),
                        1.0e-12)
        squared_distance = np.sum((values - centre) ** 2, axis=1)
        # Compute -log(p) analytically, avoiding exp/log underflow.
        log_p = -squared_distance / (2.0 * bandwidth ** 2)
        errors.append(squared_distance - alpha * log_p)
        log_affinities.append(log_p)
        descriptions.append({"cluster": int(cluster), "rows": len(part),
                             "kernel_bandwidth": bandwidth})
    error_matrix = np.column_stack(errors)
    nearest = np.argmin(error_matrix, axis=1)
    row = np.arange(len(values))
    reconstruction = error_matrix[row, nearest]
    affinity = np.exp(np.column_stack(log_affinities)[row, nearest])
    neighbors = NearestNeighbors(radius=eps, n_jobs=1).fit(values)
    count = np.asarray([len(indices) for indices in
                        neighbors.radius_neighbors(values, return_distance=False)],
                       dtype=np.int64)
    density_distance = NearestNeighbors(n_neighbors=min(7, len(values)), n_jobs=1).fit(
        values).kneighbors(values, return_distance=True)[0][:, -1]
    density = 1.0 / (1.0 + density_distance)
    span = float(np.ptp(reconstruction))
    normalized = ((reconstruction - np.min(reconstruction)) / span
                  if span > 0 else np.zeros(len(values), dtype=np.float64))
    anomaly = normalized * np.exp(-beta * density)
    if not all(np.isfinite(item).all() for item in
               (reconstruction, density, anomaly, affinity)):
        raise ValueError("affinity geometry overflowed; no decisions were produced")
    return AffinityGeometry(reconstruction, density, anomaly, affinity,
                            np.asarray(cluster_ids, dtype=np.int64)[nearest],
                            count, density_distance, descriptions)


def _fixed_second_pass(values: np.ndarray, ids: np.ndarray, *,
                       eps: float, min_samples: int) -> np.ndarray:
    """Reuse primary parameters *and scaling*, with stable canonical labels."""
    if not len(values):
        return np.empty(0, dtype=np.int64)
    order = np.argsort(ids, kind="stable")
    sorted_labels = DBSCAN(eps=eps, min_samples=min_samples, n_jobs=1).fit_predict(
        values[order])
    mapping: dict[int, int] = {}
    canonical = np.full(len(values), -1, dtype=np.int64)
    for index, label in enumerate(sorted_labels):
        if label >= 0:
            canonical[index] = mapping.setdefault(int(label), len(mapping))
    result = np.empty(len(values), dtype=np.int64)
    result[order] = canonical
    return result


def revise_noise(
    *, reference_features: np.ndarray, query_features: np.ndarray,
    reference_roles: np.ndarray, reference_ids: np.ndarray, query_ids: np.ndarray,
    stage1_prediction: np.ndarray, baseline_prediction: np.ndarray,
    calibration_truth: np.ndarray, seed: int,
) -> NoiseRevision:
    """Add guarded corrections; calibration is the known-only query prefix.

    Unknown/final truth is deliberately absent from this interface. Query
    features may take part in unsupervised clustering as in Algorithm 2.
    The caller must not treat this batch calibration diagnostic as evidence
    of independent generalisation.
    """
    reference = np.asarray(reference_features, dtype=np.float64)
    query = np.asarray(query_features, dtype=np.float64)
    roles = np.asarray(reference_roles)
    stage1 = np.asarray(stage1_prediction)
    baseline = np.asarray(baseline_prediction)
    truth = np.asarray(calibration_truth)
    ref_ids, open_ids = np.asarray(reference_ids, dtype=str), np.asarray(query_ids, dtype=str)
    if (reference.ndim != 2 or query.ndim != 2 or not len(reference)
            or not len(query) or reference.shape[1] != query.shape[1]
            or not reference.shape[1] or not np.isfinite(reference).all()
            or not np.isfinite(query).all() or roles.shape != (len(reference),)
            or stage1.shape != (len(query),) or baseline.shape != stage1.shape
            or truth.ndim != 1 or not 0 < len(truth) <= len(query)
            or any(item.dtype.kind not in "iu" for item in (roles, stage1, baseline, truth))
            or not set(roles.tolist()) <= {0, 1}
            or not set(stage1.tolist()) <= {0, 1}
            or not set(baseline.tolist()) <= {0, 1, 2}
            or set(truth.tolist()) != {0, 1}
            or np.any((baseline != stage1) & (baseline != 2))
            or ref_ids.shape != (len(reference),) or open_ids.shape != (len(query),)
            or len(set(ref_ids)) != len(ref_ids) or len(set(open_ids)) != len(open_ids)
            or set(ref_ids) & set(open_ids)
            or any(not item for item in [*ref_ids, *open_ids])):
        raise ValueError("noise revision requires disjoint finite known/query roles and IDs")
    keys = np.concatenate([np.char.add("reference::", ref_ids),
                           np.char.add("query::", open_ids)])
    combined = np.vstack([reference, query])
    labels, selection = _stable_select_dbscan(combined, keys, seed)
    nf, nc = len(reference), len(truth)
    second = np.full(len(combined), -2, dtype=np.int64)
    suspects = np.zeros(len(combined), dtype=bool)
    candidate = np.zeros(len(query), dtype=bool)
    manifest: dict[str, Any] = {
        "schema_version": "paper-algorithm3-known-guarded-noise-revision-v2",
        "primary_parameter_selection": selection,
        "alpha": 1.0, "beta": 1.0,
        "density_definition": "1 / (1 + kth_neighbor_distance), k=min(7,rows), includes self",
        "low_density_cutoff_origin": "median correctly retained known calibration by Stage1 role",
        "reconstruction_cutoff_origin": "max correctly retained known calibration by Stage1 role",
        "calibration_rows": nc, "query_rows": len(query), "reference_rows": nf,
        "second_pass_reuses_primary_scaling": True,
        "second_pass_reuses_primary_eps_minPts": True,
        "unknown_labels_used": False, "final_test_labels_used": False,
        "unlabeled_query_features_used": True,
        "noise_routed_directly_as_UNA": False, "baseline_replaced": False,
        "target99_status": "FAIL_TARGET99", "published": False,
    }
    if not np.any(labels >= 0):
        return NoiseRevision(baseline.copy(), candidate, suspects[nf:], labels[nf:],
                             second[nf:], None,
                             dict(manifest, status="NO_PRIMARY_CLUSTER_NO_REVISION"))
    selected = selection["selected"]
    eps, min_pts = float(selected["eps"]), int(selected["min_samples"])
    scaled = StandardScaler().fit_transform(combined)
    geometry = affinity_geometry(scaled, labels, eps=eps, min_samples=min_pts)
    cutoffs: dict[int, float] = {}
    density_cutoffs: dict[int, float] = {}
    guards = {}
    for role in (0, 1):
        retained = (truth == role) & (stage1[:nc] == role) & (baseline[:nc] == role)
        support, correct = int(np.sum(truth == role)), int(np.sum(retained))
        required = (99 * support + 99) // 100
        guards[str(role)] = {"correct": correct, "support": support,
                             "required_correct": required, "pass_99": correct >= required}
        if not correct:
            return NoiseRevision(baseline.copy(), candidate, suspects[nf:], labels[nf:],
                                 second[nf:], geometry,
                                 dict(manifest, status="NO_RETAINED_KNOWN_ROLE_NO_REVISION",
                                      known_guards=guards))
        cutoffs[role] = float(np.max(geometry.reconstruction[nf:nf + nc][retained]))
        density_cutoffs[role] = float(np.median(geometry.density[nf:nf + nc][retained]))
    combined_roles = np.concatenate([roles, stage1])
    cutoff = np.asarray([cutoffs[int(role)] for role in combined_roles])
    density_cutoff = np.asarray([density_cutoffs[int(role)] for role in combined_roles])
    suspects = ((geometry.reconstruction > cutoff) & (geometry.density < density_cutoff))
    indices = np.flatnonzero(suspects)
    second[indices] = _fixed_second_pass(scaled[indices], keys[indices],
                                         eps=eps, min_samples=min_pts)
    anchored = set(second[:nf][second[:nf] >= 0].tolist())
    candidate = np.asarray([label >= 0 and int(label) not in anchored
                            for label in second[nf:]], dtype=bool)
    allowed = np.asarray([guards[str(int(role))]["pass_99"] for role in stage1])
    correction = candidate & allowed & (baseline != 2)
    final = baseline.copy()
    final[correction] = 2
    correct_before = baseline[:nc] == truth
    if np.any(final[:nc][correct_before] != baseline[:nc][correct_before]):
        raise AssertionError("Algorithm-3 correction degraded known calibration")
    manifest.update({
        "status": "DEVELOPMENT_NOISE_REVISION_EVALUATED_NOT_FINAL",
        "known_guards": guards,
        "reconstruction_cutoffs": {str(k): v for k, v in cutoffs.items()},
        "density_cutoffs": {str(k): v for k, v in density_cutoffs.items()},
        "primary_eps": eps, "primary_minPts": min_pts,
        "kernel_clusters": geometry.clusters,
        "primary_query_noise_rows": int(np.sum(labels[nf:] < 0)),
        "suspected_reference_rows": int(np.sum(suspects[:nf])),
        "suspected_query_rows": int(np.sum(suspects[nf:])),
        "second_pass_noise_rows": int(np.sum(second[indices] < 0)),
        "second_pass_cluster_count": len(set(second[second >= 0].tolist())),
        "query_correction_candidates": int(np.sum(candidate)),
        "new_UNA_decisions": int(np.sum(correction)),
        "known_calibration_non_decrease": True,
        "calibration_admission_is_not_independent_validation": True,
    })
    return NoiseRevision(final, candidate, suspects[nf:], labels[nf:], second[nf:],
                         geometry, manifest)
