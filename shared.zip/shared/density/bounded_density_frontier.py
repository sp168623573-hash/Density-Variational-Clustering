"""Opt-in label-blind DVC frontier for availability-gated feature experts.

The existing router is unchanged. Duplicate discrete observations can produce
CH near 1e31, so unbounded log(CH) overwhelms silhouette/coverage. This
candidate bounds its contribution to [0, .05] using CH/(CH+n). The original
kNN eps/minPts frontier is retained; no query labels enter its selection.
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import calinski_harabasz_score, silhouette_score

from .dvc import _stable_select_dbscan


def bounded_quality(evaluation: dict[str, Any], n: int) -> float:
    clusters = int(evaluation["cluster_count"])
    noise = float(evaluation["noise_fraction"])
    if clusters >= 2 and evaluation["silhouette"] is not None and evaluation["calinski_harabasz"] is not None:
        ch = float(evaluation["calinski_harabasz"])
        if ch < 0 or math.isnan(ch):
            raise ValueError("invalid CH in density frontier")
        bounded_ch = 1.0 if math.isinf(ch) else ch / (ch + n)
        return float(evaluation["silhouette"]) + 0.05 * bounded_ch - 0.20 * noise
    return 0.05 - 0.20 * noise if clusters == 1 else -noise


def request_expert_candidates(*, reference: np.ndarray, query: np.ndarray,
                              reference_ids: np.ndarray, query_ids: np.ndarray,
                              reference_available: np.ndarray, query_available: np.ndarray,
                              seed: int, include_tail99: bool = False) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    x_fit, x_query = np.asarray(reference, dtype=np.float64), np.asarray(query, dtype=np.float64)
    fit_ids, open_ids = np.asarray(reference_ids, dtype=str), np.asarray(query_ids, dtype=str)
    fit_mask, open_mask = np.asarray(reference_available), np.asarray(query_available)
    if (x_fit.ndim != 2 or x_query.ndim != 2 or x_fit.shape[1] != x_query.shape[1]
            or not np.isfinite(x_fit).all() or not np.isfinite(x_query).all()
            or len(fit_ids) != len(x_fit) or len(open_ids) != len(x_query)
            or fit_mask.shape != (len(x_fit),) or open_mask.shape != (len(x_query),)
            or fit_mask.dtype != bool or open_mask.dtype != bool
            or len(set(fit_ids)) != len(fit_ids) or len(set(open_ids)) != len(open_ids)
            or set(fit_ids) & set(open_ids)):
        raise ValueError("expert features, masks and disjoint identities differ")
    candidate = np.zeros(len(x_query), dtype=bool)
    query_labels = np.full(len(x_query), -2, dtype=np.int64)
    selected_fit, selected_query = x_fit[fit_mask], x_query[open_mask]
    if not len(selected_fit) or not len(selected_query):
        return candidate, query_labels, {"status": "UNAVAILABLE_REFERENCE_OR_QUERY_CONTEXT",
                                         "all_query_rows_retained_in_scoring": True}
    combined = np.vstack([selected_fit, selected_query])
    stable_ids = np.concatenate([np.char.add("reference::", fit_ids[fit_mask]),
                                 np.char.add("query::", open_ids[open_mask])])
    _legacy_labels, legacy = _stable_select_dbscan(combined, stable_ids, seed)
    frontier = legacy.get("evaluations", [])
    if not frontier:
        return candidate, query_labels, {"status": "INSUFFICIENT_EXPERT_DENSITY",
                                         "legacy_frontier": legacy}
    evaluations = [{**row, "legacy_quality": row["quality"],
                    "quality": bounded_quality(row, len(combined))} for row in frontier]
    order = np.argsort(stable_ids, kind="stable")
    scaled = StandardScaler().fit_transform(combined[order])
    if include_tail99:
        # A declared density-coverage frontier extension, not an attack-score
        # cutoff. It uses only unlabeled kNN geometry, like the paper's grid.
        for min_samples in sorted({row["min_samples"] for row in frontier}):
            kth = NearestNeighbors(n_neighbors=min_samples, n_jobs=1).fit(scaled).kneighbors(
                scaled, return_distance=True)[0][:, -1]
            eps = max(float(np.quantile(kth, 0.99)), 1e-6)
            labels = DBSCAN(eps=eps, min_samples=min_samples, n_jobs=1).fit_predict(scaled)
            selected = labels >= 0
            cluster_count = len(set(labels[selected].tolist()))
            row = {"eps": eps, "eps_quantile": 0.99, "min_samples": min_samples,
                   "cluster_count": cluster_count, "noise_fraction": float(np.mean(~selected)),
                   "silhouette": None, "calinski_harabasz": None, "legacy_quality": None}
            if cluster_count >= 2 and int(np.sum(selected)) >= cluster_count + 2:
                row["silhouette"] = float(silhouette_score(scaled[selected], labels[selected],
                    sample_size=min(1000, int(np.sum(selected))), random_state=seed))
                row["calinski_harabasz"] = float(calinski_harabasz_score(scaled[selected], labels[selected]))
            row["quality"] = bounded_quality(row, len(combined))
            evaluations.append(row)
    best = max(evaluations, key=lambda row: (row["quality"], row["cluster_count"],
                                           -row["noise_fraction"], -row["eps"]))
    ordered_labels = DBSCAN(eps=best["eps"], min_samples=best["min_samples"], n_jobs=1).fit_predict(scaled)
    # Canonical labels depend only on stable identity, not physical input order.
    clusters = sorted(set(ordered_labels[ordered_labels >= 0].tolist()),
                      key=lambda label: min(stable_ids[order][ordered_labels == label]))
    canonical = {old: index for index, old in enumerate(clusters)}
    ordered_labels = np.asarray([canonical.get(int(label), -1) for label in ordered_labels], dtype=np.int64)
    labels = np.empty_like(ordered_labels)
    labels[order] = ordered_labels
    fit_labels, open_labels = labels[:len(selected_fit)], labels[len(selected_fit):]
    anchored = set(fit_labels[fit_labels >= 0].tolist())
    candidate[open_mask] = np.asarray([label >= 0 and int(label) not in anchored for label in open_labels])
    query_labels[open_mask] = open_labels
    return candidate, query_labels, {
        "status": "REQUEST_CONTEXT_EXPERT_BOUNDED_CH_ADAPTIVE_DVC",
        "selection_formula": "silhouette + 0.05 * CH/(CH+n) - 0.20 * noise_fraction",
        "reference_rows": len(x_fit), "query_rows": len(x_query),
        "available_reference_rows": len(selected_fit), "available_query_rows": len(selected_query),
        "unavailable_query_rows_retained": int(np.sum(~open_mask)),
        "selected": best, "evaluations": evaluations, "legacy_selected": legacy["selected"],
        "extra_kNN_quantiles_predeclared": [0.99] if include_tail99 else [],
        "cluster_composition": [{"cluster": label,
            "reference_anchor_rows": int(np.sum(fit_labels == label)),
            "query_rows": int(np.sum(open_labels == label)), "anchored": label in anchored}
            for label in range(len(clusters))],
        "query_no_anchor_count": int(np.sum(candidate)), "query_noise_count": int(np.sum(open_labels < 0)),
        "target_labels_used": False, "noise_routed_as_unknown": False,
        "same_availability_predicate_for_fit_and_query": True,
        "all_query_rows_retained_in_scoring": True, "baseline_router_modified": False}
