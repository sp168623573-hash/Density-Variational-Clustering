"""Single-frame support episodes with Qcal-only empirical rank features.

One caller-frozen FULL encoder/basis supplies all original native and paper
coordinates. FULL-R FIT-weighted units are fixed across full, held and nested
support episodes. This corrects episode coordinates/reference roles; it is not
a new PCA algorithm or proof of unseen-family performance.
"""
from copy import deepcopy
from pathlib import Path
import hashlib
import importlib.util
import sys
import time

import numpy as np
from sklearn.cluster import KMeans
from threadpoolctl import threadpool_limits

FRAME_SCHEMA='V1047_FIXED_FULL_R_FIT_WEIGHTED_TWO_VIEW_FRAME'
CALIBRATION_PROTOCOL='V1047_QCAL_ONLY_SUPPORT_EPISODE_RANK_FEATURES'
SOURCE_FIT_STATUS='SOURCE_PARAMETERS_COMPLETE'
TANGENT_CODE=dict(path='E:/Experiment/software transcition/target99_v1038_20261024/common/local_tangent_compatibility_v1038.py',
    sha256='29de338af0e1f3375e2a570041e654d1018965205f5dfe0770303ae792dd4666')


def _load_tangent():
    path=Path(TANGENT_CODE['path'])
    if hashlib.sha256(path.read_bytes()).hexdigest()!=TANGENT_CODE['sha256']:
        raise ValueError('frozen local weighted tangent math changed')
    name='V1047_frozen_tangent_'+TANGENT_CODE['sha256']
    if name in sys.modules:return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module;spec.loader.exec_module(module);return module


T=_load_tangent();require=T.require
SCHEMA=T.SCHEMA
calibrated_evidence=T.calibrated_evidence


def _slots(values,n):
    slots=np.asarray(values)
    require(slots.ndim==1 and np.issubdtype(slots.dtype,np.integer)and n<=len(slots)<=6000
        and slots.min()>=0 and slots.max()<n,'genuine FULL-R traced FIT slots within6000')
    slots=slots.astype(np.int64,copy=True);weight=np.bincount(slots,minlength=n)
    require(np.all(weight>=1),'every genuine FULL-R parent appears in original FIT map')
    return slots,weight


def fit_shared_frame(N_R,Z_R,FITslots):
    """Fit exactly one pair of FULL-R units; no class or query information."""
    native,paper=T._matrix(N_R),T._matrix(Z_R);n=len(native)
    require(1<n<=6000 and len(paper)==n,'same genuine FULL-R rows in two original fixed-basis views')
    slots,weight=_slots(FITslots,n)
    views={name:dict(width=x.shape[1],units=T._weighted_units(x,weight),original_R_view_sha256=T._digest(x))
           for name,x in(('native',native),('paper',paper))}
    digest=hashlib.sha256()
    for name in('native','paper'):
        digest.update(views[name]['original_R_view_sha256'].encode())
        digest.update(T._digest(views[name]['units']['mean']).encode())
        digest.update(T._digest(views[name]['units']['scale']).encode())
    digest.update(T._digest(slots).encode())
    return dict(schema=FRAME_SCHEMA,frame_sha256=digest.hexdigest(),views=views,
        full_original_R_genuine_rows=n,FIT_slot_parent_indices=slots,FIT_parent_multiplicity=weight,
        logical_FIT_rows=len(slots),units_source='FULL genuine R with original FIT multiplicity, fine-blind',
        units_shared_exact_across_all_support_episodes=True,encoder_basis_caller_contract='one frozen FULL encoder and original paper view for every episode',
        full_original_R_overlap_must_be_unavailable=True,source_true_UNA_fit=False,new_NN_fits=0,new_HGB_fits=0,new_metric_fits=0)


def fit_support_bank(N_R,Z_R,fineR,gR,idsR,FITslots,shared_frame,excluded_fines,*,seed=T.SEED):
    """Delete support families, filter original FIT slots, retain fixed units.

    Per-view/class KMeans and local projection math are exactly the pinned
    V1038 operators. Overlapping neighborhoods/duplicate centers are retained.
    No new repeat, sample, reference copy or episode-specific scale is created.
    """
    started=time.perf_counter();native,paper=T._matrix(N_R),T._matrix(Z_R);n=len(native)
    require(shared_frame['schema']==FRAME_SCHEMA and len(paper)==n==shared_frame['full_original_R_genuine_rows'],'same full original R frame')
    fine=np.asarray(fineR);require(fine.shape==(n,)and np.issubdtype(fine.dtype,np.integer)and np.isin(fine,np.arange(9)).all(),'original BEN0/KNA1..8 source fine labels')
    groups,ids=T._strings(gR,n,'FULL-R groups'),T._strings(idsR,n,'FULL-R IDs')
    slots,weights=_slots(FITslots,n)
    require(np.array_equal(slots,shared_frame['FIT_slot_parent_indices'])and np.array_equal(weights,shared_frame['FIT_parent_multiplicity']),'exact original FULL-R FIT trace')
    for name,x in(('native',native),('paper',paper)):
        require(T._digest(x)==shared_frame['views'][name]['original_R_view_sha256'],'same numerical original view; no new encoder basis')
    excluded=np.asarray(excluded_fines)
    require(excluded.ndim==1 and(excluded.size==0 or(np.issubdtype(excluded.dtype,np.integer)and np.all(excluded>=0))),'explicit source fine support exclusions')
    excluded=np.unique(excluded.astype(np.int64));keep=~np.isin(fine,excluded);original_positions=np.flatnonzero(keep)
    require(len(original_positions)>1 and set((fine[keep]>0).astype(int).tolist())=={0,1},'retained support has real BEN and KNA')
    remap=np.full(n,-1,np.int64);remap[original_positions]=np.arange(len(original_positions))
    retained_slot_ordinals=np.flatnonzero(keep[slots]);retained_original_slots=slots[retained_slot_ordinals]
    remapped_slots=remap[retained_original_slots];multiplicity=np.bincount(remapped_slots,minlength=len(original_positions))
    require(len(remapped_slots)<=6000 and np.all(multiplicity>=1)
        and all(np.sum(fine[retained_original_slots]==f)>=20 for f in np.unique(fine[keep])),
        'remaining present fine floor20 using only filtered original FIT slots; no new resampling')
    retained_fine=fine[keep];coarse=(retained_fine>0).astype(np.int64);views={};local_count=0
    with threadpool_limits(limits=T.CPU_THREADS):
        for name,x in(('native',native),('paper',paper)):
            units=deepcopy(shared_frame['views'][name]['units'])
            standard=(x[keep]-units['mean'])/units['scale'];classes={}
            for c in(0,1):
                positions=np.flatnonzero(coarse==c);class_x=standard[positions];class_w=multiplicity[positions].astype(np.float64)
                count=min(T.CENTERS,len(positions));km=KMeans(n_clusters=count,n_init=3,max_iter=100,random_state=int(seed))
                km.fit(class_x,sample_weight=class_w)
                locals_=[T._fit_local(class_x,class_w,positions,ids[keep][positions],center,int(seed))for center in km.cluster_centers_]
                for local in locals_:local['source_original_R_positions']=original_positions[local['source_positions']]
                local_count+=len(locals_)
                classes[str(c)]=dict(genuine_source_rows=len(positions),logical_FIT_rows=int(class_w.sum()),KMeans_centers=km.cluster_centers_.copy(),
                    KMeans_labels=km.labels_.copy(),KMeans_iterations=int(km.n_iter_),KMeans_inertia=float(km.inertia_),
                    KMeans_parameters=dict(n_clusters=count,n_init=3,max_iter=100,random_state=int(seed)),locals=locals_,local_model_count=len(locals_),overlapping_neighborhoods_and_duplicate_centers_allowed=True)
            views[name]=dict(width=x.shape[1],units=units,classes=classes,original_R_view_sha256=T._digest(x[keep]),
                full_original_R_view_sha256=shared_frame['views'][name]['original_R_view_sha256'])
    return dict(schema=T.SCHEMA,fit_status=SOURCE_FIT_STATUS,views=views,source_R_ids=ids[keep],source_R_groups=groups[keep],
        source_R_coarse=coarse,source_R_fine=retained_fine,source_genuine_rows=len(original_positions),source_original_R_positions=original_positions,
        full_original_R_ids=ids.copy(),full_original_R_groups=groups.copy(),full_original_R_fine=fine.copy(),excluded_fines=excluded,
        FIT_slot_parent_indices=remapped_slots,FIT_parent_multiplicity=multiplicity,logical_FIT_rows=len(remapped_slots),
        FIT_slot_original_R_positions=retained_original_slots,FIT_slot_original_FULL_R_slot_ordinals=retained_slot_ordinals,
        FIT_slot_parent_ids=ids[retained_original_slots],FIT_slot_parent_groups=groups[retained_original_slots],FIT_slot_parent_fine=fine[retained_original_slots],
        shared_frame_sha256=shared_frame['frame_sha256'],global_R_units_unchanged_across_episodes=True,
        full_original_R_overlap_must_be_unavailable=True,score_api_for_full_R_guard='score_support_bank; raw T.score_bank alone only masks retained support R',
        fit_record=dict(KMeans_fits=4,local_weighted_PCA_models=local_count,local_neighborhood_genuine_row_cap=128,local_rank_cap=8,class_center_cap=12,
            original_FIT_slots_filtered_only=True,new_resampling=False,global_units_fitted_in_this_episode=False,reference_copies_materialized=False,
            present_fine_floor20_inherited_FIT_only=True,FIT_copies_are_not_independent_events=True,source_training_classes=['BEN','KNA'],source_true_UNA_fit=False,
            new_NN_fits=0,new_HGB_fits=0,new_metric_fits=0,entire_bank_source_seconds=time.perf_counter()-started),
        encoder_full_original_R_may_include_outer_family=True,full_system_unseen_family_claimed=False,query_parameter_fit=False,published=False,final_test_executed=False)


def score_support_bank(N_Q,Z_Q,g_Q,bank):
    """Tangent score with ALL original FULL-encoder training groups neutral."""
    native,paper=T._matrix(N_Q),T._matrix(Z_Q);n=len(native);groups=T._strings(g_Q,n,'query groups')
    require(n>0 and len(paper)==n and native.shape[1]==bank['views']['native']['width']
        and paper.shape[1]==bank['views']['paper']['width'],'same complete query view widths')
    eligible=~np.isin(groups,bank['full_original_R_groups']);use=np.flatnonzero(eligible)
    raw=np.zeros((n,2));bounded=np.zeros((n,2));scores={k:np.zeros((n,2))for k in('native','paper')}
    view_bounded={k:np.zeros((n,2))for k in scores};selected={k:np.full((n,2),-1,np.int64)for k in scores}
    if len(use):
        valid=T.score_bank(native[use],paper[use],groups[use],bank)
        require(valid['conditional_eligible'].all(),'FULL-R guard also excludes every retained support parent')
        raw[use],bounded[use]=valid['raw_r'],valid['bounded_nonconformity']
        for key in scores:scores[key][use]=valid['view_scores'][key];view_bounded[key][use]=valid['view_bounded_nonconformity'][key];selected[key][use]=valid['selected_local_indices'][key]
    return dict(schema=T.SCHEMA+'_SCORES',raw_r=raw,bounded_nonconformity=bounded,view_scores=scores,view_bounded_nonconformity=view_bounded,
        selected_local_indices=selected,conditional_eligible=eligible,conditional_available=np.broadcast_to(eligible[:,None],(n,2)).copy(),
        unavailable_row_count=int((~eligible).sum()),unavailable_placeholders=0.,full_original_R_overlap_guard=True,
        excluded_R_rows_are_not_eligible_queries=True,query_parameter_fit=False,new_NN_fits=0,new_HGB_fits=0,new_metric_fits=0)


def calibrate_support(N_cal,Z_cal,coarse,g_cal,bank,*,ids_cal=None,role='Qcal'):
    """Qcal-only rank FEATURES; small nonempty classes never license U action.

    The caller supplies genuine Qcal excluding all support-excluded fines and
    holds V entirely out of reference distributions. Roles/excluded fine labels
    are caller-audited because this API accepts coarse labels only. A matched
    source unknown-action cut remains separate and requires n>=100 via V1041.
    """
    require(role=='Qcal','rank reference role is ONLY Qcal, never V or V union Qcal')
    scores=score_support_bank(N_cal,Z_cal,g_cal,bank);n=len(scores['raw_r']);y=T._coarse(coarse,n)
    groups=T._strings(g_cal,n,'genuine Qcal groups');ids=groups.copy()if ids_cal is None else T._strings(ids_cal,n,'genuine Qcal IDs')
    require(scores['conditional_eligible'].all(),'Qcal references are disjoint from ALL original R groups')
    counts=np.bincount(y,minlength=2);require(np.all(counts>0),'nonempty true-known coarse Qcal rank feature references')
    combined=T.calibrate_refs(scores['bounded_nonconformity'],y,groups)
    views={key:T.calibrate_refs(scores['view_bounded_nonconformity'][key],y,groups)for key in('native','paper')}
    return dict(schema=T.CALIBRATION_SCHEMA,protocol=CALIBRATION_PROTOCOL,combined_calibration=combined,view_calibrations=views,
        true_class_counts=counts,genuine_reference_ids=ids,genuine_reference_groups=groups,true_coarse=y.copy(),
        reference_raw_r=scores['raw_r'],reference_bounded_nonconformity=scores['bounded_nonconformity'],reference_view_scores=scores['view_scores'],
        reference_view_bounded_nonconformity=scores['view_bounded_nonconformity'],source_R_ids_sha256=T._digest(bank['source_R_ids']),
        source_R_groups_sha256=T._digest(bank['source_R_groups']),shared_frame_sha256=bank['shared_frame_sha256'],
        three_calibration_sets=3,true_class_reference_arrays=6,learned_model_fits=0,role='Qcal',source_V_used_as_reference=False,
        excluded_fines_caller_enforced=bank['excluded_fines'].copy(),reference_copies=False,small_n_nonempty_rank_features_allowed=True,
        matched_unknown_action_cut_separate=True,matched_unknown_action_cut_requires_each_true_class_atleast100=True,
        source_rank_feature_alone_never_unknown_or_known_license=True,source_true_UNA_calibration=False,
        empirical_p_values_are_membership_posteriors=False,views_are_independent_claimed=False,finite_sample_graph_or_true_UNA_guarantee_claimed=False)


def pure_toy_checks():
    rng=np.random.default_rng(1047);native=rng.normal(size=(42,4));paper=np.column_stack((native[:,0]+native[:,1],native[:,2]-native[:,3],native[:,0]))
    fine=np.repeat([0,1,2],14);groups=np.asarray(['R%d'%i for i in range(42)]);ids=np.asarray(['id%03d'%i for i in range(42)])
    slots=np.r_[np.arange(42),np.arange(0,6),np.arange(14,20),np.arange(28,34)]
    frame=fit_shared_frame(native,paper,slots);full=fit_support_bank(native,paper,fine,groups,ids,slots,frame,[])
    drop=fit_support_bank(native,paper,fine,groups,ids,slots,frame,[2]);keep=fine!=2
    for key in('native','paper'):
        require(np.array_equal(full['views'][key]['units']['mean'],drop['views'][key]['units']['mean'])
            and np.array_equal(full['views'][key]['units']['scale'],drop['views'][key]['units']['scale']),'exact shared FULL-R units across support deletion')
    require(np.array_equal(drop['FIT_slot_original_R_positions'],slots[keep[slots]])
        and np.array_equal(drop['FIT_parent_multiplicity'],np.bincount(drop['FIT_slot_parent_indices'],minlength=28))
        and drop['logical_FIT_rows']==40,'filter/remap original FIT slots only with honest weights')
    query=native[[0,30,40]].copy();zquery=paper[[0,30,40]].copy()
    scored=score_support_bank(query,zquery,np.asarray(['R0','R30','new']),drop)
    require(scored['conditional_eligible'].tolist()==[False,False,True]
        and not scored['bounded_nonconformity'][:2].any(),'retained and excluded FULL-R parents both unavailable')
    cn=rng.normal(size=(6,4));cz=np.column_stack((cn[:,0]+cn[:,1],cn[:,2]-cn[:,3],cn[:,0]))
    cal=calibrate_support(cn,cz,np.asarray([0,0,0,1,1,1]),np.asarray(['Q%d'%i for i in range(6)]),drop)
    require(cal['true_class_counts'].tolist()==[3,3]and not cal['source_V_used_as_reference']
        and cal['combined_calibration']['discrete_max_boost']==0.,'small genuine Qcal ranks permitted only as features with conservative boost')
    try:calibrate_support(cn,cz,np.asarray([0,0,0,1,1,1]),np.asarray(['V%d'%i for i in range(6)]),drop,role='V')
    except ValueError:pass
    else:raise AssertionError('V reference declaration must fail')
    return dict(shared_units_across_full_and_drop_exact=True,original_FIT_filter_remap_exact=True,remaining_fine_floor20_FIT_only=True,
        local_references_genuine_only=True,full_original_R_overlap_neutral=True,Qcal_only_role_guard=True,small_Qcal_rank_features_not_action_guarantee=True,
        toy_KMeans_fits=8,toy_local_PCA_models=full['fit_record']['local_weighted_PCA_models']+drop['fit_record']['local_weighted_PCA_models'],
        real_source_fits=0,real_data_reads=0,actual_role_reads=0,new_NN_fits=0,new_HGB_fits=0,new_metric_fits=0,
        performance_claimed=False,frozen_tangent_math=TANGENT_CODE)
