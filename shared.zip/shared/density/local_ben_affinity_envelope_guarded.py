"""Known-only local calibration envelope for a BEN affinity prefilter.

This is an opt-in realization within MHFD/DVC, not literal Algorithm 3 or
an independent-final certificate. Known BEN alone fits scaling, bounded
DBSCAN kernels and seven-neighbour density. Each query compares against
the TWENTY nearest correctly routed BEN calibration points: strict maximum
reconstruction, strict maximum density-modulated anomaly, and median local
density. All coefficients and neighbour counts are fixed, not UNA-fitted.

The local score is a ratio, NOT a percentile/probability. A candidate still
needs the existing non-noise DVC route and known-core protection. Query
truth/family/identity and KNA coordinates cannot fit this profile. Local
calibration self-retention is not a 99% out-of-sample guarantee.
"""

from dataclasses import dataclass

import numpy as np
from sklearn.neighbors import NearestNeighbors

from .dvc import NoveltyOutput
from .known_fit_density_affinity import fit_affinity


LOCAL_CALIBRATION_NEIGHBORS = 20
DENSITY_NEIGHBORS = 7
SCHEMA = "known-only-local-BEN-affinity-envelope-guarded-v2"
FLOAT_BOUNDARY_ULPS = 64


def _matrix(values, name):
    x = np.asarray(values, dtype=np.float64)
    if (x.ndim != 2 or not 0 < len(x) <= 6000 or not 0 < x.shape[1] <= 512
            or not np.isfinite(x).all()):
        raise ValueError(name + " needs bounded finite geometry")
    return x


def _roles(values, length, name):
    y = np.asarray(values)
    if y.shape != (length,) or y.dtype.kind not in "iu" or not np.isin(y, (0, 1)).all():
        raise ValueError(name + " needs known BEN/KNA roles")
    return y


def _components(model, features):
    x = _matrix(features, "affinity query")
    if x.shape[1] != model["dimensions"]:
        raise ValueError("query/known geometry dimensions differ")
    values = model["scaler"].transform(x)
    centres, bandwidth = model["centres"], model["bandwidths"]
    reconstruction = np.empty(len(x), dtype=np.float64)
    # Bounded temporary matrices; never allocate query*kernel*feature axes.
    for start in range(0, len(x), 128):
        part = values[start:start + 128]
        squared = np.empty((len(part), len(centres)), dtype=np.float64)
        for kernel, centre in enumerate(centres):
            delta = part - centre
            squared[:, kernel] = np.einsum("ij,ij->i", delta, delta)
        error = squared * (1. + 1. / (2. * bandwidth[None, :] ** 2))
        reconstruction[start:start + len(part)] = error.min(axis=1)
    kth = model["local_density_neighbors"].kneighbors(values, return_distance=True)[0][:, -1]
    density = 1. / (1. + kth)
    normalized = np.maximum(0., (reconstruction - model["normalization_min"])
        / model["normalization_range"])
    anomaly = normalized * np.exp(-density)
    if not all(np.isfinite(v).all() for v in (reconstruction, density, anomaly)):
        raise ValueError("local affinity components are nonfinite")
    return values, reconstruction, density, anomaly


@dataclass
class LocalBENAffinity:
    model: dict
    calibration_neighbors: NearestNeighbors
    calibration_reconstruction: np.ndarray
    calibration_density: np.ndarray
    calibration_anomaly: np.ndarray
    manifest: dict

    def components(self, features):
        scaled, reconstruction, density, anomaly = _components(self.model, features)
        indices = self.calibration_neighbors.kneighbors(scaled, return_distance=False)
        r_cut = self.calibration_reconstruction[indices].max(axis=1)
        d_cut = np.median(self.calibration_density[indices], axis=1)
        a_cut = self.calibration_anomaly[indices].max(axis=1)
        # A fixed float64 rounding envelope tightens rejection, never relaxes
        # retention. It is not a data-fitted/UNA-tuned statistical allowance.
        precision = FLOAT_BOUNDARY_ULPS * np.finfo(np.float64).eps
        r_effective = np.maximum(r_cut + precision * np.maximum(1., np.abs(r_cut)), 1.e-12)
        a_effective = np.maximum(a_cut + precision * np.maximum(1., np.abs(a_cut)), 1.e-12)
        d_effective = np.maximum(0., d_cut - precision * np.maximum(1., np.abs(d_cut)))
        score = np.minimum.reduce([reconstruction / r_effective,
            d_effective / density, anomaly / a_effective])
        candidate = (reconstruction > r_effective) & (density < d_effective) & (anomaly > a_effective)
        if not np.isfinite(score).all():
            raise ValueError("local affinity ratio is nonfinite")
        return {"score": score, "candidate": candidate, "reconstruction": reconstruction,
            "density": density, "anomaly": anomaly, "local_reconstruction_cutoff": r_cut,
            "local_density_cutoff": d_cut, "local_anomaly_cutoff": a_cut,
            "effective_reconstruction_cutoff": r_effective,
            "effective_density_cutoff": d_effective, "effective_anomaly_cutoff": a_effective}


def fit_profile(fit_features, fit_truth, calibration_features, calibration_truth,
                calibration_primary, *, seed):
    x, cal = _matrix(fit_features, "fit features"), _matrix(calibration_features, "calibration features")
    y = _roles(fit_truth, len(x), "fit truth")
    cy = _roles(calibration_truth, len(cal), "calibration truth")
    cp = _roles(calibration_primary, len(cal), "calibration primary")
    if x.shape[1] != cal.shape[1]:
        raise ValueError("fit/calibration geometry dimensions differ")
    known, protected = x[y == 0], cal[(cy == 0) & (cp == 0)]
    if len(known) < 20 or len(protected) < LOCAL_CALIBRATION_NEIGHBORS:
        raise ValueError("twenty BEN fit and correct calibration rows required")
    # Geometry-only canonical ordering, not source identity or family lookup.
    order = np.lexsort(tuple(known[:, i] for i in range(known.shape[1] - 1, -1, -1)))
    known = known[order]
    model = fit_affinity(known, np.array([f"known-BEN-{i:04}" for i in range(len(known))]),
        np.ones(len(known), dtype=bool), seed=seed)
    if not model["available"]:
        raise ValueError("known BEN density kernels unavailable")
    model["local_density_neighbors"] = NearestNeighbors(n_neighbors=DENSITY_NEIGHBORS,
        n_jobs=1).fit(model["scaler"].transform(known))
    # Stable geometry ordering also resolves deterministic neighbour ties.
    order = np.lexsort(tuple(protected[:, i] for i in range(protected.shape[1] - 1, -1, -1)))
    protected = protected[order]
    scaled, reconstruction, density, anomaly = _components(model, protected)
    neighbours = NearestNeighbors(n_neighbors=LOCAL_CALIBRATION_NEIGHBORS, n_jobs=1).fit(scaled)
    manifest = {"schema_version": SCHEMA, "BEN_fit_rows": len(known),
        "correct_calibration_BEN_rows": len(protected), "local_calibration_neighbors": LOCAL_CALIBRATION_NEIGHBORS,
        "known_fit_density_neighbors": DENSITY_NEIGHBORS, "alpha": 1., "beta": 1.,
        "reconstruction_cutoff": "maximum among nearest 20 correct BEN calibration features",
        "density_cutoff": "median among same nearest 20 correct BEN calibration features",
        "anomaly_cutoff": "maximum among same nearest 20 correct BEN calibration features",
        "threshold_comparisons_strict": True, "ratio_zero_denominator_floor": 1.e-12,
        "fixed_float64_boundary_ULPs": FLOAT_BOUNDARY_ULPS,
        "boundary_guard_formula": "64*float64.eps*max(1,abs(cutoff)); raise R/A and lower density cutoff",
        "numerical_guard_can_only_reduce_not_increase_rejections": True,
        "scale_kernels_and_density_known_BEN_fit_only": True, "density_definition": "1/(1+known_fit_7th_distance)",
        "kernel_audit": model["audit"], "unknown_or_query_truth_used": False,
        "query_identity_or_family_used": False, "query_used_for_geometry_or_cutoff_fit": False,
        "rule_selected_after_historical_development_inspection": True,
        "self_retention_is_not_out_of_sample_99_certificate": True,
        "ratio_is_NOT_percentile_or_probability": True, "DVC_non_noise_cluster_required": True,
        "noise_routed_directly_as_UNA": False, "new_neural_training": False,
        "independent_final_admitted": False, "status": "FAIL_TARGET99", "published": False}
    profile = LocalBENAffinity(model, neighbours, reconstruction, density, anomaly, manifest)
    if profile.components(protected)["candidate"].any():
        raise AssertionError("local calibration self-retention failed")
    return profile


def score(profile, features, primary, original):
    components = profile.components(features)
    p = _roles(primary, len(components["score"]), "query primary")
    fields = ("score", "threshold", "high_threshold", "prototype_percentile", "embedding_knn_percentile",
        "feature_knn_percentile", "reconstruction_percentile", "uncertainty_percentile", "candidate")
    if (not isinstance(original, NoveltyOutput)
            or any(np.asarray(getattr(original, k)).shape != p.shape for k in fields)
            or any(not np.isfinite(np.asarray(getattr(original, k))).all() for k in fields)):
        raise ValueError("finite paired original novelty arrays required")
    updated = {k: np.asarray(getattr(original, k)).copy() for k in fields}
    ben = p == 0
    updated["score"][ben] = components["score"][ben]
    updated["threshold"][ben] = updated["high_threshold"][ben] = 1.
    updated["candidate"][ben] = components["candidate"][ben]
    # True inherited BEN geometry ECDFs stay unchanged for known-core rescue.
    return NoveltyOutput(**updated, score_strategy="local_BEN_affinity_KNA_unchanged_" + original.score_strategy)
