"""Refit a source-only relation on the frozen physical pair plan.

The only prospective intervention is the descriptor: the original six pair
distance features plus native coordinate absolute differences and midpoints.
Native coordinates and paper distances have already been fitted on source R.
All graph searches, capacities, priors and solver operations stay at V1025.
"""
from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import hashlib
import importlib.util
import sys
import time

import numpy as np
from threadpoolctl import threadpool_limits

SCHEMA = 'V1027_SOURCE_FIELD_CONDITIONED_RELATIONAL_GRAPH'
SOURCE_FIT_STATUS = 'SOURCE_PARAMETERS_COMPLETE'
CPU_THREADS = 4
DECOUPLED = dict(
    path='E:/Experiment/software transcition/target99_v1025_20261024/common/decoupled_relational_potts_v1025.py',
    sha256='40878e82040e87cc9596b6c8fb9d2d7cd56573910409b6167e7e98d52afe91c7')


def _load_decoupled():
    path = Path(DECOUPLED['path'])
    if hashlib.sha256(path.read_bytes()).hexdigest() != DECOUPLED['sha256']:
        raise ValueError('frozen V1025 neighborhoods/energy bytes changed')
    spec = importlib.util.spec_from_file_location(
        'V1027_frozen_decoupled_' + DECOUPLED['sha256'], path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


D = _load_decoupled()
B = D.B
ORIGINAL = D.ORIGINAL
require = B.require


def feature_names(native_width):
    require(isinstance(native_width, (int, np.integer)) and native_width > 0,
            'positive native coordinate width')
    return tuple(B.FEATURE_NAMES) + tuple(
        'native_abs_difference_%03d' % i for i in range(native_width)) + tuple(
        'native_midpoint_%03d' % i for i in range(native_width))


def pair_features(left_n, right_n, left_z, right_z, scales, paired_metric):
    """Symmetric descriptor; no normalization or fitted query transformation."""
    ln, rn, lz, rz = (B._matrix(x) for x in (left_n, right_n, left_z, right_z))
    require(ln.shape == rn.shape and lz.shape == rz.shape and len(ln) == len(lz),
            'aligned native/paper physical pair rows')
    scale = np.asarray(scales, np.float64)
    require(scale.shape == (2,) and np.isfinite(scale).all() and np.all(scale > 0),
            'unchanged positive source distance scales')
    dn = np.linalg.norm(ln-rn, axis=1)
    dm = B._paired(paired_metric, lz, rz)
    result = np.column_stack((B._features(dn, dm, scale), np.abs(ln-rn), (ln+rn)/2.))
    require(result.shape == (len(ln), 6+2*ln.shape[1]) and np.isfinite(result).all(),
            'six aggregate plus symmetric coordinate differences and midpoints')
    return result


def _array_digest(value):
    array = np.ascontiguousarray(value)
    digest = hashlib.sha256()
    digest.update(str(array.dtype).encode('ascii'))
    digest.update(str(array.shape).encode('ascii'))
    digest.update(array.tobytes())
    return digest.hexdigest()


def fit_reused_pairs(N_R, Z_R, source_edge_bundle, paired_metric):
    """Fit one new fixed HGB, retaining the complete prior physical pair plan.

    Profiles must assert source IDs, groups, retained-R/frame positions and
    transformed coordinates against their frozen source bank before this call.
    This API has no query argument and does not generate/resample any pairs.
    """
    started = time.perf_counter()
    native, z = B._matrix(N_R), B._matrix(Z_R)
    n, width = native.shape
    old = source_edge_bundle
    require(old['schema'] == B.SCHEMA, 'frozen V1023 physical source edge bundle')
    require(1 < n <= 6000 and len(z) == n and old['native_width'] == width
            and old['metric_width'] == z.shape[1], 'unchanged genuine source view widths/cap')
    identifiers = B._strings(old['source_ids'], n, 'source IDs').copy()
    groups = B._strings(old['source_groups'], n, 'source groups').copy()
    fine = B._labels(old['source_fine'], n).copy()
    require(np.all(fine >= 0) and 0 in fine and np.any(fine > 0),
            'real source BEN and KNA only; no source UNA')
    record = old['fit_record']
    slots = np.asarray(record['FIT_slot_parent_indices'])
    require(slots.ndim == 1 and np.issubdtype(slots.dtype, np.integer)
            and n <= len(slots) <= 6000 and slots.min() >= 0 and slots.max() < n,
            'retained logical FIT parent map within6000')
    slots = slots.astype(np.int64, copy=True)
    multiplicity = np.bincount(slots, minlength=n)
    require(np.all(multiplicity >= 1)
            and all(np.sum(fine[slots] == f) >= 20 for f in np.unique(fine))
            and np.array_equal(multiplicity, record['FIT_parent_multiplicity'])
            and record['genuine_source_parents'] == n and record['logical_FIT_rows'] == len(slots),
            'exact prior FIT traces; all genuine parents; present fine floor20')
    pair = np.asarray(old['pair_indices'])
    binary = np.asarray(old['pair_labels'])
    weights = np.asarray(old['pair_weights'], np.float64)
    scales = np.asarray(old['scales'], np.float64)
    require(pair.shape == (B.PAIR_COUNT, 2) and np.issubdtype(pair.dtype, np.integer)
            and np.all(pair[:, 0] < pair[:, 1]) and pair.min() >= 0 and pair.max() < n
            and len(np.unique(pair, axis=0)) == B.PAIR_COUNT
            and np.array_equal(np.unique(pair), np.arange(n)),
            'same8192 distinct physical pairs cover all genuine source parents')
    require(binary.shape == (B.PAIR_COUNT,) and np.issubdtype(binary.dtype, np.integer)
            and np.array_equal(binary, (fine[pair[:, 0]] == fine[pair[:, 1]]).astype(np.int8))
            and np.bincount(binary, minlength=2).tolist() == [4096, 4096],
            'same balanced physical same-fine pair labels')
    require(weights.shape == (B.PAIR_COUNT,) and np.isfinite(weights).all() and np.all(weights > 0)
            and scales.shape == (2,) and np.isfinite(scales).all() and np.all(scales > 0),
            'reuse prior pair weights and source distance scales verbatim')
    expected_weights = np.sqrt(multiplicity[pair[:, 0]]*multiplicity[pair[:, 1]]).astype(np.float64)
    for label in (0, 1):
        selected = binary == label
        expected_weights[selected] /= expected_weights[selected].mean()
    require(np.array_equal(weights, expected_weights), 'unchanged logical FIT physical-pair weights')
    pair, binary, weights, scales = pair.copy(), binary.copy(), weights.copy(), scales.copy()
    features = pair_features(native[pair[:, 0]], native[pair[:, 1]],
                             z[pair[:, 0]], z[pair[:, 1]], scales, paired_metric)
    model = B.HistGradientBoostingClassifier(
        max_iter=80, max_leaf_nodes=15, learning_rate=.05, l2_regularization=1.,
        max_bins=64, min_samples_leaf=20, class_weight='balanced',
        early_stopping=False, random_state=B.SEED)
    tick = time.perf_counter()
    with threadpool_limits(limits=CPU_THREADS):
        model.fit(features, binary, sample_weight=weights)
    seconds = time.perf_counter()-tick
    require(model.classes_.tolist() == [0, 1] and model.n_iter_ == 80
            and model.n_features_in_ == 6+2*width, 'actual new fixed80 field-conditioned HGB')
    previous = dict(
        schema=old['schema'], feature_names=tuple(old['feature_names']),
        descriptor_width=int(record['pair_features_count']),
        pair_indices_sha256=_array_digest(pair), pair_labels_sha256=_array_digest(binary),
        pair_weights_sha256=_array_digest(weights), scales_sha256=_array_digest(scales),
        source_ids_sha256=_array_digest(identifiers), source_groups_sha256=_array_digest(groups),
        source_fine_sha256=_array_digest(fine), logical_slots_sha256=_array_digest(slots),
        previous_model_type=type(old['model']).__module__+'.'+type(old['model']).__name__,
        previous_model_parameters=deepcopy(old['model'].get_params()),
        previous_model_used_for_prediction=False, previous_model_weights_copied=False,
        previous_fit_record=deepcopy(record),
        artifact_reference=deepcopy(old.get('previous_artifact_ref', {})))
    new_record = deepcopy(record)
    new_record.update(
        FIT_slot_parent_indices=slots, FIT_parent_multiplicity=multiplicity,
        pair_features_count=features.shape[1], pair_feature_native_width=width,
        aggregate_pair_features_count=6, native_coordinate_difference_features=width,
        native_coordinate_midpoint_features=width, pair_plan_reused_verbatim=True,
        pair_labels_reused_verbatim=True, pair_weights_reused_verbatim=True,
        logical_FIT_map_reused_verbatim=True, distance_scales_reused_verbatim=True,
        native_coordinates_reused_without_new_transform=True, no_new_pair_sampling=True,
        pair_views_are_not_independent_traffic=True, reference_resampling=False,
        HGB_fits=1, HGB_iterations=int(model.n_iter_), HGB_fit_seconds=seconds,
        HGB_feature_width=int(model.n_features_in_), CPU_threads=CPU_THREADS,
        total_edge_source_seconds=time.perf_counter()-started,
        source_only_positive_median_distance_scales=scales,
        source_true_UNA_fit=False, query_fit=False, new_NN_fits=0,
        new_HGB_fits=1, new_metric_fits=0, previous_model_weights_copied=False)
    return dict(
        schema=SCHEMA, model=model, scales=scales, feature_names=feature_names(width),
        pair_indices=pair, pair_labels=binary, pair_weights=weights, source_ids=identifiers,
        source_groups=groups, source_fine=fine, native_width=width, metric_width=z.shape[1],
        fit_record=new_record, previous_pairplan_model_ref=previous,
        descriptor='[base6(dNative,dPaper),abs(N_i-N_j),(N_i+N_j)/2]',
        fitted_from_real_source_BEN_KNA_only=True, new_NN_fits=0, new_HGB_fits=1,
        new_metric_fits=0, query_parameter_fit=False, current_truth_used=False,
        published=False, final_test_executed=False)


def infer_graph(N_R, Z_R, ycoarse, g_R, N_Q, Z_Q, g_Q, threeway_logits,
                parent_group_labels, edge_bundle, paired_metric):
    started = time.perf_counter()
    nr, zr, nq, zq = B._matrix(N_R), B._matrix(Z_R), B._matrix(N_Q), B._matrix(Z_Q)
    n, r = len(nq), len(nr)
    require(n > 0 and len(zq) == n and len(zr) == r and nr.shape[1] == nq.shape[1]
            and zr.shape[1] == zq.shape[1], 'matched native/paper source-query coordinates')
    gr, gq = B._strings(g_R, r, 'source groups'), B._strings(g_Q, n, 'canonical query groups')
    yc, parent = B._labels(ycoarse, r, (0, 1)), B._labels(parent_group_labels, n, (0, 1, 2))
    require(edge_bundle['schema'] == SCHEMA and np.array_equal(gr, edge_bundle['source_groups'])
            and np.array_equal(yc, (edge_bundle['source_fine'] > 0).astype(np.int64))
            and edge_bundle['native_width'] == nr.shape[1] and edge_bundle['metric_width'] == zr.shape[1]
            and edge_bundle['model'].n_features_in_ == 6+2*nr.shape[1],
            'unchanged new field relation/source roster and real boundary classes')
    logits = B._matrix(threeway_logits); require(logits.shape == (n, 3), 'continuous weak threeway logits')
    keep = ~np.isin(gr, gq); source_indices = np.flatnonzero(keep)
    source_n, source_z, source_y = nr[keep], zr[keep], yc[keep]
    m = len(source_indices)

    q_native = B._exact_euclidean_neighbors(nq, nq, np.arange(n), B.K_NATIVE)
    q_shortlist = B._exact_euclidean_neighbors(zq, zq, np.arange(n), B.PAPER_EUCLIDEAN_SHORTLIST)
    q_paper = D._refine_paper(zq, zq, q_shortlist, paired_metric)
    s_native = D._cross_euclidean_neighbors(nq, source_n, B.K_NATIVE)
    s_shortlist = D._cross_euclidean_neighbors(zq, source_z, B.PAPER_EUCLIDEAN_SHORTLIST)
    s_paper = D._refine_paper(zq, source_z, s_shortlist, paired_metric)
    qq, qr = set(), set()
    for i in range(n):
        for j in np.unique(np.r_[q_native[i], q_paper[i]]):
            j = int(j); require(j != i, 'query self edges excluded')
            qq.add((min(i, j), max(i, j)))
        for j in np.unique(np.r_[s_native[i], s_paper[i]]):
            qr.add((i, int(j)))
    qq, qr = np.asarray(sorted(qq), np.int64).reshape(-1, 2), np.asarray(sorted(qr), np.int64).reshape(-1, 2)

    def probability(left_n, right_n, left_z, right_z):
        if not len(left_n):
            return np.empty(0, np.float64)
        features = pair_features(left_n, right_n, left_z, right_z, edge_bundle['scales'], paired_metric)
        with threadpool_limits(limits=CPU_THREADS):
            value = edge_bundle['model'].predict_proba(features)[:, 1]
        require(np.isfinite(value).all() and np.all((value >= 0) & (value <= 1)),
                'new source-only field relation probabilities')
        return value

    pq = probability(nq[qq[:, 0]], nq[qq[:, 1]], zq[qq[:, 0]], zq[qq[:, 1]])
    pr = probability(nq[qr[:, 0]], source_n[qr[:, 1]], zq[qr[:, 0]], source_z[qr[:, 1]])
    degree = np.bincount(qq.ravel(), minlength=n)
    qw = 7.*pq/np.maximum(7, np.maximum(degree[qq[:, 0]], degree[qq[:, 1]]))
    mass = np.bincount(qr[:, 0], weights=pr, minlength=n)
    rw = pr/np.maximum(1., mass[qr[:, 0]])
    source_unary = B.source_elimination(qr[:, 0], source_y[qr[:, 1]], rw, n)
    weighted_degree = np.bincount(qq[:, 0], weights=qw, minlength=n)+np.bincount(qq[:, 1], weights=qw, minlength=n)
    require(np.all(weighted_degree <= 7.+1e-12) and np.all(source_unary[:, 2] <= 1.+1e-12),
            'only numerical validation of unchanged edge-mass bounds')
    centered = logits-logits.max(axis=1, keepdims=True)
    prob = np.exp(centered); prob /= prob.sum(axis=1, keepdims=True)
    base = 1.-prob
    strength = np.where(parent == 2, B.UNKNOWN_CHANGE_PRIOR, B.KNOWN_CHANGE_PRIOR)
    prior = strength[:, None]*(np.arange(3)[None, :] != parent[:, None])
    no_parent = base+source_unary
    inference = B.alpha_expansion(no_parent+prior, qq[:, 0], qq[:, 1], qw, parent)
    labels = inference['labels']
    costs = B.local_costs(labels, no_parent, qq[:, 0], qq[:, 1], qw)
    coarse = costs[:, :2].argmin(axis=1).astype(np.int8); row = np.arange(n)
    S = costs[:, :2].min(axis=1)-costs[:, 2]
    counter = costs+np.asarray([B.UNKNOWN_CHANGE_PRIOR, B.UNKNOWN_CHANGE_PRIOR, 0.])[None, :]
    A = np.minimum(counter[row, 1-coarse], counter[:, 2])-counter[row, coarse]
    known = (labels < 2) & (labels == coarse) & (A > 0.)
    raw = (labels == 2) & (S > 0.)
    require(not np.any(known & raw), 'same disjoint positive known/unknown proposals')
    return dict(schema=SCHEMA, labels=labels.astype(np.int8), S=S, A=A, predicted_coarse=coarse,
        known_proposal=known, raw_proposal=raw, local_cost_no_parent=costs,
        local_cost_actual_prior=costs+prior, weak_probabilities=prob, base_unary=base,
        source_unary=source_unary, prior_unary=prior, QQ_left=qq[:, 0], QQ_right=qq[:, 1],
        QQ_probability=pq, QQ_weight=qw, QQ_degree=degree, QQ_weighted_degree=weighted_degree,
        QR_query=qr[:, 0], QR_source_original=source_indices[qr[:, 1]], QR_probability=pr, QR_weight=rw,
        source_anchor_indices=source_indices, excluded_source_anchor_groups=gr[~keep],
        native_QQ_neighbors=q_native, native_QS_neighbors=s_native,
        paper_QQ_euclidean_shortlist=q_shortlist, paper_QS_euclidean_shortlist=s_shortlist,
        paper_QQ_neighbors=q_paper, paper_QS_neighbors=s_paper,
        native_neighbors=np.concatenate((s_native, m+q_native), axis=1),
        paper_euclidean_shortlist=np.concatenate((s_shortlist, m+q_shortlist), axis=1),
        paper_neighbors=np.concatenate((s_paper, m+q_paper), axis=1),
        neighbor_index_convention='combined compatibility arrays: kept source first, then query; independent QQ arrays use query-local indices, QS arrays kept-source-local indices',
        QQ_QS_search_populations_decoupled=True,
        fixed_theta_query_QQ_invariant_to_source_anchor_addition=True,
        native_neighbors_exact_full_search=True, paper_neighbors_are_sparse_shortlist_approximation=True,
        source_anchor_elimination_exact=True, energy_history=inference['energy_history'],
        expansion_moves=inference['moves'], converged=inference['converged'],
        completed_sweeps=inference['completed_sweeps'], accepted_moves=inference['accepted_moves'],
        global_three_label_optimum_claimed=False, inference_seconds=time.perf_counter()-started,
        reused_energy_code=ORIGINAL, new_NN_fits=0, new_HGB_fits=0, new_metric_fits=0,
        source_only_evidence_cannot_certify_known=True, query_parameter_fit=False,
        current_truth_used=False, published=False, final_test_executed=False)


def pure_small_checks():
    """Descriptor and one no-Q-Q graph checks; never calls an estimator fit."""
    metric = lambda left, right: np.linalg.norm(left-right, axis=1)
    widths = {}
    for width in (78, 115):
        left = np.arange(2*width, dtype=np.float64).reshape(2, width)/width
        right = left[:, ::-1].copy()+.25
        zleft = np.asarray([[0., 1.], [2., 3.]])
        zright = np.asarray([[1., 3.], [4., 6.]])
        forward = pair_features(left, right, zleft, zright, [1., 2.], metric)
        reverse = pair_features(right, left, zright, zleft, [1., 2.], metric)
        require(np.array_equal(forward, reverse), 'pair descriptors exactly symmetric')
        require(forward.shape == (2, 6+2*width), 'declared CIC/NSL pair descriptor width')
        widths[str(width)] = forward.shape[1]
    left = np.asarray([[0., 0.], [10., 10.], [0., 0.]])
    right = np.asarray([[1., 0.], [11., 10.], [0., 1.]])
    zleft, zright = np.zeros((3, 1)), np.ones((3, 1))
    descriptors = pair_features(left, right, zleft, zright, [1., 1.], metric)
    require(np.array_equal(descriptors[0, :6], descriptors[1, :6])
            and np.array_equal(descriptors[0, :6], descriptors[2, :6])
            and not np.array_equal(descriptors[0], descriptors[1])
            and not np.array_equal(descriptors[0], descriptors[2]),
            'equal aggregate distances retain distinct midpoint/difference context')

    class ConstantRelation:
        n_features_in_ = 10

        def predict_proba(self, features):
            require(features.shape[1] == self.n_features_in_, 'synthetic field descriptor used')
            return np.tile([.25, .75], (len(features), 1))

    edge = dict(schema=SCHEMA, model=ConstantRelation(), scales=np.ones(2),
                source_groups=np.asarray(['sourceB', 'sourceK']), source_fine=np.asarray([0, 1]),
                native_width=2, metric_width=1)
    result = infer_graph(np.asarray([[0., 0.], [2., 2.]]), np.asarray([[0.], [2.]]),
                         np.asarray([0, 1]), edge['source_groups'], np.asarray([[1., 1.]]),
                         np.asarray([[1.]]), np.asarray(['query']), np.asarray([[.2, .4, .1]]),
                         np.asarray([2]), edge, metric)
    require(not len(result['QQ_left']) and np.all(result['QQ_weighted_degree'] <= 7.)
            and np.all(result['source_unary'][:, 2] <= 1.+1e-12)
            and np.all(result['A'] <= -2.+1e-12), 'noQQ counterfactual margin bound and edge bounds')
    require(all(m['candidate'] < m['before'] for m in result['expansion_moves'] if m['accepted']),
            'unchanged strict floating energy descent')
    return dict(pair_symmetry=True, descriptor_widths=widths,
                equal_distance_distinct_descriptors=True, noQQ_counterfactual_A=result['A'].tolist(),
                source_mass=result['source_unary'][:, 2].tolist(), graph_bounds=True,
                strict_float_energy_descent=True, new_HGB_fits=0, new_NN_fits=0,
                new_metric_fits=0, current_truth_read=False, frozen_neighborhood_code=DECOUPLED,
                frozen_mathematical_code=ORIGINAL,
                old_solver_regression_suite_rerun=False)
