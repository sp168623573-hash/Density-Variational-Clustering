"""BEN-only locally scaled seventh-affinity cover, four fixed NSL views.

Each reference's scale is its actual-index leave-self-out seventh distance.
The query statistic is the seventh smallest distance/reference-scale ratio,
not a global raw-radius envelope. To calibrate fit LOO, remove the query's
actual index from ALL reference scales too (use eighth distances when needed).
Whitening itself remains fit on the whole known group: this is neighbour-scale
jackknife, NOT leave-one-out refitting of the covariance or preprocessing.
Full fit-LOO, actual in-sample fit and protected cal maxima freeze each cutoff. No query labels,
family, IDs, scale refit, seed search or 99% guarantee.
"""
from dataclasses import dataclass
import hashlib
import numpy as np
from scipy.spatial.distance import cdist
from . import known_ben_context_whitened_semantic_views as baseline_views
from .known_ben_context_whitened_fit_loo import KnownContextWhitener, context_keys
from .local_ben_affinity_envelope_guarded import _matrix, _roles
from .dvc import NoveltyOutput

SCHEMA = "known-BEN-four-whitened-local-radius-seventh-cover-full-neighbour-jackknife-v1"
NEIGHBORS, MIN_FIT, MIN_CALIBRATION = 7, 9, 3
RADIUS_FLOOR = 1.e-12
FIELDS = baseline_views.FIELDS


def sha(x): return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()


def reference_radii_and_loo(z):
    """True deletion of fit query i from reference j's local scale as well."""
    z = _matrix(z, "known whitened reference")
    if len(z) < MIN_FIT: raise ValueError("nine references required for seventh scale jackknife")
    distances = cdist(z, z, metric="euclidean")
    np.fill_diagonal(distances, np.inf)
    partitioned = np.partition(distances, (NEIGHBORS-1, NEIGHBORS), axis=1)
    seventh, eighth = partitioned[:, NEIGHBORS-1].copy(), partitioned[:, NEIGHBORS].copy()
    loo = np.empty(len(z), dtype=np.float64)
    for i in range(len(z)):
        # dist(i,j) <= r7(j) means deleting i can alter j's kth scale.
        # Boundary ties are safe: the replacement eighth equals the seventh
        # when enough tied reference rows remain; no zero-distance row is
        # guessed to be the actual source index.
        adjusted = np.where(distances[i] <= seventh, eighth, seventh)
        normalized = distances[i] / np.maximum(adjusted, RADIUS_FLOOR)
        loo[i] = np.partition(normalized, NEIGHBORS-1)[NEIGHBORS-1]
    if not np.isfinite(seventh).all() or not np.isfinite(eighth).all() or not np.isfinite(loo).all():
        raise ValueError("finite local scale/jackknife required")
    return seventh, eighth, loo


def group_statistic(group, rows):
    z = group["metric"].transform(np.asarray(rows, dtype=np.float64))
    scaled = cdist(z, group["reference"], metric="euclidean") / np.maximum(group["seventh"], RADIUS_FLOOR)[None, :]
    values = np.partition(scaled, NEIGHBORS-1, axis=1)[:, NEIGHBORS-1]
    if not np.isfinite(values).all(): raise ValueError("local normalized cover overflow")
    return values


def state_sha(group):
    h = hashlib.sha256(float(group["cutoff"]).hex().encode("ascii"))
    m = group["metric"]
    for v in (m.mean_, m.scale_, m.var_, m.whitener_, m.covariance_, m.active_columns_,
            np.asarray([m.shrinkage_, m.n_features_in_, m.n_samples_seen_]),
            group["reference"], group["seventh"], group["eighth"]):
        a = np.asarray(v, dtype="<f8", order="C")
        h.update(str(a.shape).encode("ascii")); h.update(a.tobytes())
    return h.hexdigest()


@dataclass
class LocalRadiusCover:
    feature_names: tuple
    columns: dict
    nodes: dict
    calibration_ratios: np.ndarray
    manifest: dict


def check(profile):
    m = profile.manifest
    if (m.get("schema_version") != SCHEMA or m.get("frozen_manifest_sha256") != baseline_views._manifest_sha(m)
            or profile.columns != baseline_views.view_columns(profile.feature_names)
            or m.get("query_truth_or_ID_or_family_used") is not False
            or m.get("full_neighbour_scale_jackknife_for_fit_query") is not True
            or m.get("whitener_is_NOT_refit_per_left_out_row") is not True
            or m.get("local_radius_floor") != RADIUS_FLOOR):
        raise ValueError("frozen locally scaled cover policy required")
    declarations = {tuple(r["context"]): r for r in m["nodes"] if r["admitted"]}
    if set(profile.nodes) != set(declarations) or sha(profile.calibration_ratios) != m["calibration_ratio_sha256"]:
        raise ValueError("frozen cover support/calibration reference required")
    ref = profile.calibration_ratios
    if ref.ndim != 1 or not len(ref) or not np.isfinite(ref).all() or np.any(ref < 0) or np.any(ref > 1) or not np.array_equal(ref, np.sort(ref)):
        raise ValueError("known-only sorted finite aggregate ratio reference required")
    for key, groups in profile.nodes.items():
        if tuple(groups) != tuple(profile.columns): raise ValueError("fixed four-view cover required")
        for view, group in groups.items():
            if (state_sha(group) != declarations[key]["views"][view]["state_sha256"]
                    or group["cutoff"] <= 0 or not np.isfinite(group["cutoff"])):
                raise ValueError("frozen local scale/reference/metric changed")


def _ratios(profile, x):
    keys = context_keys(x, profile.feature_names)
    maximum = np.zeros(len(x)); eligible = np.zeros(len(x), dtype=bool)
    for key, groups in profile.nodes.items():
        indices = np.array([i for i, k in enumerate(keys) if k == key], dtype=np.int64)
        if not len(indices): continue
        ratios = [group_statistic(groups[v], x[indices][:, cols])/groups[v]["cutoff"] for v, cols in profile.columns.items()]
        maximum[indices] = np.max(np.stack(ratios), axis=0); eligible[indices] = True
    return maximum, eligible


def fit_profile(fit_features, fit_truth, calibration_features, calibration_truth,
                primary, baseline, feature_names, deep_profile):
    x, cal = _matrix(fit_features, "known fit"), _matrix(calibration_features, "known calibration")
    y, cy = _roles(fit_truth, len(x), "known fit truth"), _roles(calibration_truth, len(cal), "known calibration truth")
    p = _roles(primary, len(cal), "known calibration primary"); b = np.asarray(baseline)
    names = tuple(str(n) for n in feature_names)
    if (x.shape[1] != len(names) or cal.shape[1] != len(names) or b.shape != p.shape
            or b.dtype.kind not in "iu" or not np.isin(b, (0, 1, 2)).all() or np.any((b != p) & (b != 2))
            or set(cy.tolist()) != {0, 1} or deep_profile.feature_names != names):
        raise ValueError("paired known-only physical fit/cal roles required")
    baseline_views.components(deep_profile, cal)
    columns = baseline_views.view_columns(names); fk, ck = context_keys(x, names), context_keys(cal, names)
    protected = (cy == 0) & (p == 0) & (b == 0); nodes, audit = {}, []
    for key in sorted({k for k, label in zip(fk, y) if label == 0}):
        fi = np.array([i for i, k in enumerate(fk) if k == key and y[i] == 0], dtype=np.int64)
        ci = np.array([i for i, k in enumerate(ck) if k == key and protected[i]], dtype=np.int64)
        row = {"context": list(key), "known_BEN_fit_rows": len(fi), "correct_BEN_calibration_rows": len(ci),
            "admitted": len(fi) >= MIN_FIT and len(ci) >= MIN_CALIBRATION}
        if not row["admitted"]: audit.append(row); continue
        groups, views = {}, {}
        for view, cols in columns.items():
            known = x[fi][:, cols]
            known = known[np.lexsort(tuple(known[:, i] for i in range(known.shape[1]-1, -1, -1)))]
            metric = KnownContextWhitener().fit(known); z = metric.transform(known)
            seventh, eighth, loo = reference_radii_and_loo(z)
            group = {"metric": metric, "reference": z, "seventh": seventh, "eighth": eighth}
            cal_scores = group_statistic(group, cal[ci][:, cols])
            in_sample = group_statistic(group, known)
            # Changing reference scales during deletion is not monotone in
            # the usual query statistic; explicitly retain both fit scopes.
            maximum = max(1.e-12, float(loo.max()), float(in_sample.max()), float(cal_scores.max()))
            cutoff = float(maximum+64*np.finfo(np.float64).eps*max(1., maximum))
            group["cutoff"] = cutoff; group["state_sha256"] = state_sha(group); groups[view] = group
            views[view] = {"cutoff": cutoff, "full_neighbour_jackknife_fit_maximum": float(loo.max()),
                "calibration_local_cover_maximum": float(cal_scores.max()), "known_fit_geometry_sha256": sha(known),
                "actual_in_sample_fit_maximum": float(in_sample.max()), "in_sample_scores_sha256": sha(in_sample),
                "seventh_distance_sha256": sha(seventh), "eighth_distance_sha256": sha(eighth),
                "fit_jackknife_scores_sha256": sha(loo), "state_sha256": group["state_sha256"]}
        nodes[key] = groups; audit.append({**row, "views": views})
    if not nodes: raise ValueError("no known context has nine BEN fit and three correct BEN cal")
    profile = LocalRadiusCover(names, columns, nodes, np.empty(0), {})
    ratio, eligible = _ratios(profile, cal); ref = np.sort(ratio[protected & eligible])
    if not len(ref) or np.any(ref > 1): raise AssertionError("known calibration local-cover retention failed")
    profile.calibration_ratios = ref
    manifest = {"schema_version": SCHEMA, "nodes": audit, "view_columns": {k: list(v) for k, v in columns.items()},
        "retained_white_baseline_manifest": deep_profile.manifest,
        "statistic": "seventh smallest query-to-reference Euclidean distance divided by each reference's own leave-self-out seventh radius",
        "minimum_fit": MIN_FIT, "minimum_calibration": MIN_CALIBRATION, "neighbors": NEIGHBORS,
        "local_radius_floor": RADIUS_FLOOR, "full_neighbour_scale_jackknife_for_fit_query": True,
        "whitener_is_NOT_refit_per_left_out_row": True,
        "all_fit_LOO_and_correct_cal_maximum_cutoff": True, "calibration_ratio_sha256": sha(ref),
        "actual_in_sample_fit_maximum_also_retained": True,
        "query_truth_or_ID_or_family_used": False, "known_only_calibration": True,
        "context_minima_are_NOT_Table1_family_or_independent_event_floors": True,
        "unsupported_context_action": "keep baseline and full denominator",
        "retained_baseline_predictions_must_not_be_removed": True, "non_noise_DVC_required": True,
        "historical_development_inspection_precedes_rule_design": True, "new_query_99_NOT_guaranteed": True,
        "status": "FAIL_TARGET99", "published": False, "final_test_executed": False}
    manifest["frozen_manifest_sha256"] = baseline_views._manifest_sha(manifest); profile.manifest = manifest
    check(profile); return profile


def components(profile, features):
    check(profile); x = _matrix(features, "local radius cover query")
    if x.shape[1] != len(profile.feature_names): raise ValueError("full saved model feature width required")
    ratio, eligible = _ratios(profile, x)
    rank = np.zeros(len(x)); ref = profile.calibration_ratios
    rank[eligible] = np.searchsorted(ref, ratio[eligible], side="right")/(len(ref)+1.)
    support_marker = np.where(eligible, 0, -1).astype(np.int64)
    # Five-field interface reused by the paired diagnostic scaffold. Last
    # mask explicitly means local cover support, not hierarchical fallback.
    return ratio, rank, support_marker, eligible, eligible.copy()


def score(profile, features, primary, original):
    ratio, rank, marker, eligible, supported = components(profile, features)
    p = _roles(primary, len(ratio), "query primary")
    if (not isinstance(original, NoveltyOutput) or any(np.asarray(getattr(original, k)).shape != p.shape for k in FIELDS)
            or any(not np.isfinite(getattr(original, k)).all() for k in FIELDS) or np.asarray(original.candidate).dtype != bool):
        raise ValueError("paired finite original novelty required")
    values = {k: np.asarray(getattr(original, k)).copy() for k in FIELDS}; mask = (p == 0) & eligible
    values["score"][mask] = ratio[mask]; values["threshold"][mask] = values["high_threshold"][mask] = 1.
    values["candidate"][mask] = ratio[mask] > 1.; values["feature_knn_percentile"][mask] = rank[mask]
    return NoveltyOutput(**values, score_strategy="known_BEN_whitened_local_radius_cover_"+original.score_strategy), ratio, marker, eligible, supported
