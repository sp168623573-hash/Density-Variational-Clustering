"""Fixed semantic content witness, known-only density profile reused.

Known BEN frontier identified no content-only false alarms among its nine
single-view regressions. The policy therefore admits a content-view witness
without another view; other views still need two-view consensus. No family,
query labels, identity, or source is an input. Non-noise DVC is mandatory.
No full-model LOO, conformal, new-data or literal Eq.9 claim.
"""
import numpy as np
from .known_ben_whitened_local_density_guards import check, context_keys, group_statistic

CONTENT_VIEW = "content_login_activity"
RECIPE = {"schema_version": "known-BEN-content-witness-or-two-view-density-v1",
    "raw_rule": "content_login_activity ratio > 1 OR second largest of four ratios > 1",
    "threshold": 1., "unsupported_context_action": "retain baseline and full denominator",
    "known_only_frontier_design_no_content_view_regressions": True,
    "historical_development_inspection_precedes_design": True,
    "new_admission_requires_raw_candidate_AND_non_noise_DVC": True,
    "query_truth_ID_source_and_family_used": False,
    "published": False, "final_test_executed": False}


def aggregate(ratios, order):
    r = np.asarray(ratios, dtype=np.float64)
    order = tuple(order)
    if (r.ndim != 2 or r.shape[1] != 4 or len(order) != 4 or len(set(order)) != 4
            or CONTENT_VIEW not in order or not np.isfinite(r).all() or np.any(r < 0)):
        raise ValueError("four complete declared nonnegative density ratios required")
    content = r[:, order.index(CONTENT_VIEW)]
    consensus = np.sort(r, axis=1)[:, -2]
    return np.maximum(content, consensus), content, consensus


def evaluate(profile, features, primary):
    check(profile)
    x = np.asarray(features, dtype=np.float64); p = np.asarray(primary)
    if (x.ndim != 2 or x.shape[1] != len(profile.feature_names) or not np.isfinite(x).all()
            or not 0 < len(x) <= 6000 or p.shape != (len(x),) or p.dtype.kind not in "iu"
            or not np.isin(p, (0, 1)).all()):
        raise ValueError("full finite physical model features and protected coarse decisions required")
    order = tuple(profile.columns)
    ratios = np.zeros((len(x), 4), dtype=np.float64); eligible = np.zeros(len(x), dtype=bool)
    keys = context_keys(x, profile.feature_names)
    for key, groups in profile.nodes.items():
        indices = np.asarray([i for i, k in enumerate(keys) if k == key], dtype=np.int64)
        if not len(indices): continue
        eligible[indices] = True
        for j, view in enumerate(order):
            ratios[indices, j] = group_statistic(groups[view], x[indices][:, profile.columns[view]])
    score, content, consensus = aggregate(ratios, order)
    raw = (p == 0) & eligible & (score > 1.)
    return {"score": score, "raw_candidate": raw, "eligible": eligible,
        "per_view_ratio": ratios, "content_ratio": content, "consensus_ratio": consensus}
