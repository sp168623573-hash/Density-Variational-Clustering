from __future__ import annotations

import math
import hashlib
from dataclasses import dataclass
from typing import Any

import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.metrics import calinski_harabasz_score, silhouette_score
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler

from .model import InferenceOutput
from .guarded_kna_rejection import validate_kna_guard


NOVELTY_WEIGHTS = {
    "prototype": 0.30,
    "embedding_knn": 0.25,
    "feature_knn": 0.20,
    "reconstruction": 0.15,
    "uncertainty": 0.10,
}


def _monotone_score_strategies(matrix: np.ndarray) -> dict[str, np.ndarray]:
    """Return a finite frontier of direction-safe novelty scores.

    Every input column is an anomaly percentile where larger means less
    compatible with the known set.  All strategies are monotone in every
    component and therefore cannot cancel a strong anomaly with a negative
    learned coefficient.
    """

    values = np.asarray(matrix, dtype=np.float64)
    if values.ndim != 2 or values.shape[1] != len(NOVELTY_WEIGHTS):
        raise ValueError("novelty percentile matrix has the wrong shape")
    weights = np.asarray(tuple(NOVELTY_WEIGHTS.values()), dtype=np.float64)
    ordered = np.sort(values, axis=1)
    return {
        "paper_nonnegative_weighted_mean": values @ weights,
        "uniform_nonnegative_mean": np.mean(values, axis=1),
        "maximum_component": np.max(values, axis=1),
        "top_two_component_mean": np.mean(ordered[:, -2:], axis=1),
        "geometry_maximum": np.max(values[:, :3], axis=1),
        "feature_knn_only": values[:, 2],
    }


@dataclass
class NoveltyOutput:
    score: np.ndarray
    threshold: np.ndarray
    high_threshold: np.ndarray
    prototype_percentile: np.ndarray
    embedding_knn_percentile: np.ndarray
    feature_knn_percentile: np.ndarray
    reconstruction_percentile: np.ndarray
    uncertainty_percentile: np.ndarray
    candidate: np.ndarray
    score_strategy: str


@dataclass
class DVCOutput:
    final_prediction: np.ndarray
    candidate: np.ndarray
    anchor_candidate: np.ndarray
    novelty_candidate: np.ndarray
    novelty_score_candidate: np.ndarray
    rescued_known: np.ndarray
    protected_stage1_kna: np.ndarray
    known_core_rescue: np.ndarray
    joint_cluster: np.ndarray
    primary_cluster: np.ndarray
    second_cluster: np.ndarray
    dvc_manifest: dict[str, Any]


def _empirical_percentile(reference: np.ndarray, values: np.ndarray) -> np.ndarray:
    sorted_reference = np.sort(np.asarray(reference, dtype=np.float64))
    if len(sorted_reference) == 0:
        raise ValueError("empirical percentile reference is empty")
    ranks = np.searchsorted(sorted_reference, values, side="right")
    return ranks.astype(np.float64) / (len(sorted_reference) + 1.0)


def _quantile(values: np.ndarray, q: float) -> float:
    if len(values) == 0:
        raise ValueError("cannot calculate a quantile from an empty array")
    return float(np.quantile(values, q, method="higher"))


class NoveltyCalibrator:
    """Fit-only known-density calibrator for the paper's DVC candidate route."""

    def __init__(self, *, retention_quantile: float = 0.995, neighbors: int = 7) -> None:
        self.retention_quantile = retention_quantile
        self.neighbors = neighbors

    def fit(
        self,
        x_fit: np.ndarray,
        fit_output: InferenceOutput,
        y_fit_fine: np.ndarray,
        x_validation: np.ndarray,
        validation_output: InferenceOutput,
        y_validation_fine: np.ndarray,
        validation_coarse_prediction: np.ndarray,
    ) -> "NoveltyCalibrator":
        self.embedding_scaler_ = StandardScaler().fit(fit_output.embedding)
        self.feature_scaler_ = StandardScaler().fit(x_fit)
        fit_embedding = self.embedding_scaler_.transform(fit_output.embedding)
        fit_features = self.feature_scaler_.transform(x_fit)
        validation_embedding = self.embedding_scaler_.transform(validation_output.embedding)
        validation_features = self.feature_scaler_.transform(x_validation)

        self.fine_classes_ = tuple(sorted(np.unique(y_fit_fine).tolist()))
        prototypes: list[np.ndarray] = []
        scales: list[np.ndarray] = []
        for fine_class in self.fine_classes_:
            rows = fit_embedding[y_fit_fine == fine_class]
            prototypes.append(np.mean(rows, axis=0))
            scales.append(np.maximum(np.std(rows, axis=0), 0.10))
        self.prototypes_ = np.asarray(prototypes, dtype=np.float64)
        self.prototype_scales_ = np.asarray(scales, dtype=np.float64)

        k = min(self.neighbors, max(1, len(fit_embedding)))
        self.embedding_neighbors_ = NearestNeighbors(
            n_neighbors=k, metric="euclidean", n_jobs=1
        ).fit(
            fit_embedding
        )
        self.feature_neighbors_ = NearestNeighbors(
            n_neighbors=k, metric="euclidean", n_jobs=1
        ).fit(
            fit_features
        )
        self.fit_embedding_ = fit_embedding
        self.fit_features_ = fit_features
        self.fit_fine_ = np.asarray(y_fit_fine, dtype=np.int64)

        validation_components = self._raw_components(
            validation_embedding,
            validation_features,
            validation_output.reconstruction_error,
            validation_output.fine_probability,
        )
        self.component_reference_ = {
            key: np.asarray(value, dtype=np.float64)
            for key, value in validation_components.items()
        }
        # Retained as an explicit compatibility marker: V19 used an
        # unconstrained logistic model here.  V20 selects only from the
        # non-negative monotone frontier below.
        self.score_model_ = None
        lofo_components, lofo_coarse = self._build_lofo_components(
            validation_embedding,
            validation_features,
            validation_output,
            y_validation_fine,
            validation_coarse_prediction,
        )
        validation_matrix = self._percentile_matrix(validation_components)
        strategy_frontier: list[dict[str, Any]] = []
        if lofo_components is not None:
            proxy_matrix = self._percentile_matrix(lofo_components)
            validation_strategies = _monotone_score_strategies(validation_matrix)
            proxy_strategies = _monotone_score_strategies(proxy_matrix)
            for strategy_name, validation_score in validation_strategies.items():
                global_threshold = _quantile(
                    validation_score, self.retention_quantile
                )
                thresholds: dict[int, float] = {}
                known_retention: dict[int, float] = {}
                for coarse_class in (0, 1):
                    values = validation_score[
                        validation_coarse_prediction == coarse_class
                    ]
                    threshold = (
                        global_threshold
                        if len(values) < 10
                        else _quantile(values, self.retention_quantile)
                    )
                    thresholds[coarse_class] = threshold
                    known_retention[coarse_class] = float(
                        np.mean(values <= threshold) if len(values) else 1.0
                    )
                proxy_threshold = np.asarray(
                    [thresholds[int(value)] for value in lofo_coarse],
                    dtype=np.float64,
                )
                proxy_score = proxy_strategies[strategy_name]
                strategy_frontier.append(
                    {
                        "strategy": strategy_name,
                        "proxy_recall": float(
                            np.mean(proxy_score > proxy_threshold)
                        ),
                        "proxy_support": int(len(proxy_score)),
                        "known_retention": known_retention,
                    }
                )
            selected = max(
                strategy_frontier,
                key=lambda item: (
                    item["proxy_recall"],
                    min(item["known_retention"].values()),
                    item["strategy"]
                    == "paper_nonnegative_weighted_mean",
                ),
            )
            self.score_strategy_ = str(selected["strategy"])
            self.lofo_components_ = lofo_components
            self.lofo_coarse_prediction_ = lofo_coarse
        else:
            self.score_strategy_ = "paper_nonnegative_weighted_mean"
            self.lofo_components_ = None
            self.lofo_coarse_prediction_ = np.empty(0, dtype=np.int64)
        self.strategy_frontier_ = strategy_frontier
        validation_score, _ = self._score_from_components(validation_components)
        global_threshold = _quantile(validation_score, self.retention_quantile)
        high_quantile = min(0.999, self.retention_quantile + 0.004)
        global_high = _quantile(validation_score, high_quantile)
        self.threshold_by_coarse_: dict[int, float] = {}
        self.high_threshold_by_coarse_: dict[int, float] = {}
        for coarse_class in (0, 1):
            values = validation_score[validation_coarse_prediction == coarse_class]
            if len(values) < 10:
                self.threshold_by_coarse_[coarse_class] = global_threshold
                self.high_threshold_by_coarse_[coarse_class] = global_high
            else:
                self.threshold_by_coarse_[coarse_class] = _quantile(
                    values, self.retention_quantile
                )
                self.high_threshold_by_coarse_[coarse_class] = _quantile(
                    values, high_quantile
                )
        self.validation_score_ = validation_score
        return self

    def _build_lofo_components(
        self,
        validation_embedding: np.ndarray,
        validation_features: np.ndarray,
        validation_output: InferenceOutput,
        y_validation_fine: np.ndarray,
        validation_coarse_prediction: np.ndarray,
    ) -> tuple[dict[str, np.ndarray] | None, np.ndarray]:
        collected: dict[str, list[np.ndarray]] = {
            key: [] for key in NOVELTY_WEIGHTS
        }
        coarse_parts: list[np.ndarray] = []
        for fine_class in sorted(set(y_validation_fine.tolist())):
            if fine_class == 0:
                continue
            query_mask = y_validation_fine == fine_class
            reference_mask = self.fit_fine_ != fine_class
            if int(np.sum(query_mask)) == 0 or int(np.sum(reference_mask)) < self.neighbors:
                continue
            ref_embedding = self.fit_embedding_[reference_mask]
            ref_features = self.fit_features_[reference_mask]
            embedding_neighbors = NearestNeighbors(
                n_neighbors=min(self.neighbors, len(ref_embedding)), n_jobs=1
            ).fit(ref_embedding)
            feature_neighbors = NearestNeighbors(
                n_neighbors=min(self.neighbors, len(ref_features)), n_jobs=1
            ).fit(ref_features)
            keep_proto = [
                index
                for index, value in enumerate(self.fine_classes_)
                if value != fine_class
            ]
            query_embedding = validation_embedding[query_mask]
            prototype_distances = []
            for index in keep_proto:
                prototype_distances.append(
                    np.sqrt(
                        np.mean(
                            (
                                (query_embedding - self.prototypes_[index])
                                / self.prototype_scales_[index]
                            )
                            ** 2,
                            axis=1,
                        )
                    )
                )
            collected["prototype"].append(
                np.min(np.column_stack(prototype_distances), axis=1)
            )
            collected["embedding_knn"].append(
                embedding_neighbors.kneighbors(
                    query_embedding, return_distance=True
                )[0][:, -1]
            )
            collected["feature_knn"].append(
                feature_neighbors.kneighbors(
                    validation_features[query_mask], return_distance=True
                )[0][:, -1]
            )
            collected["reconstruction"].append(
                validation_output.reconstruction_error[query_mask]
            )
            collected["uncertainty"].append(
                1.0 - np.max(validation_output.fine_probability[query_mask], axis=1)
            )
            coarse_parts.append(validation_coarse_prediction[query_mask])
        if not coarse_parts:
            return None, np.empty(0, dtype=np.int64)
        return (
            {key: np.concatenate(parts) for key, parts in collected.items()},
            np.concatenate(coarse_parts),
        )

    def _prototype_distance(self, embedding: np.ndarray) -> np.ndarray:
        distances = []
        for prototype, scale in zip(
            self.prototypes_, self.prototype_scales_, strict=True
        ):
            distances.append(
                np.sqrt(np.mean(((embedding - prototype) / scale) ** 2, axis=1))
            )
        return np.min(np.column_stack(distances), axis=1)

    def _raw_components(
        self,
        embedding: np.ndarray,
        features: np.ndarray,
        reconstruction_error: np.ndarray,
        fine_probability: np.ndarray,
    ) -> dict[str, np.ndarray]:
        embedding_distance = self.embedding_neighbors_.kneighbors(
            embedding, return_distance=True
        )[0][:, -1]
        feature_distance = self.feature_neighbors_.kneighbors(
            features, return_distance=True
        )[0][:, -1]
        return {
            "prototype": self._prototype_distance(embedding),
            "embedding_knn": embedding_distance,
            "feature_knn": feature_distance,
            "reconstruction": np.asarray(reconstruction_error, dtype=np.float64),
            "uncertainty": 1.0 - np.max(fine_probability, axis=1),
        }

    def _percentiles_from_components(
        self, components: dict[str, np.ndarray]
    ) -> dict[str, np.ndarray]:
        return {
            key: _empirical_percentile(self.component_reference_[key], value)
            for key, value in components.items()
        }

    def _percentile_matrix(self, components: dict[str, np.ndarray]) -> np.ndarray:
        percentiles = self._percentiles_from_components(components)
        return np.column_stack([percentiles[key] for key in NOVELTY_WEIGHTS])

    def _score_from_components(
        self, components: dict[str, np.ndarray]
    ) -> tuple[np.ndarray, dict[str, np.ndarray]]:
        percentiles = self._percentiles_from_components(components)
        matrix = np.column_stack([percentiles[key] for key in NOVELTY_WEIGHTS])
        score = _monotone_score_strategies(matrix)[self.score_strategy_]
        return score, percentiles

    def score_frontier(
        self,
        features: np.ndarray,
        output: InferenceOutput,
    ) -> dict[str, np.ndarray]:
        """Return every predeclared monotone novelty score for a query cohort.

        This public view is used by the isolated external-UNA development
        selector.  It reuses the fit/calibration references already frozen in
        this calibrator and does not fit on, or inspect labels from, the query.
        """

        embedding = self.embedding_scaler_.transform(output.embedding)
        scaled_features = self.feature_scaler_.transform(features)
        components = self._raw_components(
            embedding,
            scaled_features,
            output.reconstruction_error,
            output.fine_probability,
        )
        matrix = self._percentile_matrix(components)
        return {
            name: np.asarray(score, dtype=np.float64)
            for name, score in _monotone_score_strategies(matrix).items()
        }

    def score(
        self,
        features: np.ndarray,
        output: InferenceOutput,
        coarse_prediction: np.ndarray,
    ) -> NoveltyOutput:
        embedding = self.embedding_scaler_.transform(output.embedding)
        scaled_features = self.feature_scaler_.transform(features)
        components = self._raw_components(
            embedding,
            scaled_features,
            output.reconstruction_error,
            output.fine_probability,
        )
        score, percentiles = self._score_from_components(components)
        threshold = np.asarray(
            [self.threshold_by_coarse_[int(value)] for value in coarse_prediction],
            dtype=np.float64,
        )
        high_threshold = np.asarray(
            [self.high_threshold_by_coarse_[int(value)] for value in coarse_prediction],
            dtype=np.float64,
        )
        return NoveltyOutput(
            score=score,
            threshold=threshold,
            high_threshold=high_threshold,
            prototype_percentile=percentiles["prototype"],
            embedding_knn_percentile=percentiles["embedding_knn"],
            feature_knn_percentile=percentiles["feature_knn"],
            reconstruction_percentile=percentiles["reconstruction"],
            uncertainty_percentile=percentiles["uncertainty"],
            candidate=score > threshold,
            score_strategy=self.score_strategy_,
        )

    def lofo_proxy_candidate_recall(
        self,
        x_validation: np.ndarray,
        validation_output: InferenceOutput,
        y_validation_fine: np.ndarray,
        validation_coarse_prediction: np.ndarray,
    ) -> tuple[float | None, int]:
        if self.lofo_components_ is None:
            return None, 0
        score, _ = self._score_from_components(self.lofo_components_)
        threshold = np.asarray(
            [
                self.threshold_by_coarse_[int(value)]
                for value in self.lofo_coarse_prediction_
            ]
        )
        return float(np.mean(score > threshold)), int(len(score))


def _select_dbscan(features: np.ndarray, seed: int) -> tuple[np.ndarray, dict[str, Any]]:
    n_rows = len(features)
    if n_rows < 5:
        return np.full(n_rows, -1, dtype=np.int64), {
            "status": "insufficient_candidates",
            "candidate_rows": n_rows,
        }
    scaled = StandardScaler().fit_transform(features)
    min_samples_values = sorted(
        {
            value
            for value in (
                min(5, n_rows),
                min(10, n_rows),
                min(30, max(2, int(round(math.sqrt(n_rows))))),
            )
            if 2 <= value <= n_rows
        }
    )
    if not min_samples_values:
        return np.full(n_rows, -1, dtype=np.int64), {
            "status": "no_valid_min_samples",
            "candidate_rows": n_rows,
        }
    evaluations: list[dict[str, Any]] = []
    for min_samples in min_samples_values:
        neighbors = NearestNeighbors(n_neighbors=min_samples, n_jobs=1).fit(scaled)
        kth = neighbors.kneighbors(scaled, return_distance=True)[0][:, -1]
        for quantile in (0.70, 0.80, 0.90, 0.95):
            eps = max(float(np.quantile(kth, quantile)), 1.0e-6)
            labels = DBSCAN(eps=eps, min_samples=min_samples, n_jobs=1).fit_predict(scaled)
            clustered = labels >= 0
            cluster_count = len(set(labels[clustered].tolist())) if clustered.any() else 0
            noise_fraction = float(np.mean(~clustered))
            silhouette = None
            ch = None
            quality = -noise_fraction
            if cluster_count >= 2 and int(np.sum(clustered)) >= cluster_count + 2:
                sample_size = min(1000, int(np.sum(clustered)))
                silhouette = float(
                    silhouette_score(
                        scaled[clustered],
                        labels[clustered],
                        sample_size=sample_size,
                        random_state=seed,
                    )
                )
                ch = float(calinski_harabasz_score(scaled[clustered], labels[clustered]))
                quality = silhouette + 0.05 * math.log1p(ch) - 0.20 * noise_fraction
            elif cluster_count == 1:
                quality = 0.05 - 0.20 * noise_fraction
            evaluations.append(
                {
                    "min_samples": min_samples,
                    "eps": eps,
                    "eps_quantile": quantile,
                    "cluster_count": cluster_count,
                    "noise_fraction": noise_fraction,
                    "silhouette": silhouette,
                    "calinski_harabasz": ch,
                    "quality": quality,
                    "labels": labels,
                }
            )
    best = max(
        evaluations,
        key=lambda item: (
            item["quality"],
            item["cluster_count"],
            -item["noise_fraction"],
            -item["eps"],
        ),
    )
    labels = np.asarray(best["labels"], dtype=np.int64)
    serializable = [
        {key: value for key, value in item.items() if key != "labels"}
        for item in evaluations
    ]
    selected = {key: value for key, value in best.items() if key != "labels"}
    return labels, {
        "status": "selected",
        "candidate_rows": n_rows,
        "selected": selected,
        "evaluations": serializable,
    }


def _stable_select_dbscan(
    features: np.ndarray,
    row_ids: np.ndarray | None,
    seed: int,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Run adaptive DBSCAN in a stable order and canonicalize cluster ids."""

    values = np.asarray(features, dtype=np.float64)
    if row_ids is None:
        stable_keys = np.asarray(
            [np.ascontiguousarray(row).tobytes().hex() for row in values],
            dtype=str,
        )
        order_policy = "feature bytes fallback"
    else:
        stable_keys = np.asarray(row_ids, dtype=str)
        if len(stable_keys) != len(values):
            raise ValueError("stable DBSCAN ids do not match feature rows")
        if len(set(stable_keys.tolist())) != len(stable_keys):
            raise ValueError("stable DBSCAN ids must be unique")
        order_policy = "stable sample id"
    stable_order = np.argsort(stable_keys, kind="stable")
    labels_sorted, manifest = _select_dbscan(values[stable_order], seed)
    canonical_map: dict[int, int] = {}
    canonical_sorted = np.full(len(labels_sorted), -1, dtype=np.int64)
    for index, value in enumerate(labels_sorted.tolist()):
        if value < 0:
            continue
        if int(value) not in canonical_map:
            canonical_map[int(value)] = len(canonical_map)
        canonical_sorted[index] = canonical_map[int(value)]
    labels = np.empty(len(canonical_sorted), dtype=np.int64)
    labels[stable_order] = canonical_sorted
    manifest = {
        **manifest,
        "row_order_policy": order_policy,
        "cluster_ids_canonicalized": True,
    }
    return labels, manifest


def _joint_known_anchor_candidates(
    known_reference_features: np.ndarray,
    query_features: np.ndarray,
    known_reference_ids: np.ndarray | None = None,
    query_ids: np.ndarray | None = None,
    *,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Find unlabeled query clusters that contain no known reference anchor.

    Algorithm 2 of the paper is followed at the parameter-selection level:
    minPts/eps candidates are evaluated from k-neighbor distances, silhouette
    and Calinski-Harabasz quality without reading target labels.  Noise is not
    called unknown: only a non-noise, query-only cluster is a candidate.
    """

    reference = np.asarray(known_reference_features, dtype=np.float64)
    query = np.asarray(query_features, dtype=np.float64)
    if reference.ndim != 2 or query.ndim != 2:
        raise ValueError("known reference and query features must be 2-D")
    if reference.shape[1] != query.shape[1]:
        raise ValueError("known reference and query feature dimensions differ")
    if len(reference) == 0:
        raise ValueError("joint known-anchor clustering needs known references")
    if (known_reference_ids is None) != (query_ids is None):
        raise ValueError("known reference ids and query ids must be supplied together")
    if known_reference_ids is not None:
        reference_ids = np.asarray(known_reference_ids, dtype=str)
        open_ids = np.asarray(query_ids, dtype=str)
        if len(reference_ids) != len(reference) or len(open_ids) != len(query):
            raise ValueError("stable clustering ids do not match feature rows")
        if len(set(reference_ids.tolist())) != len(reference_ids):
            raise ValueError("known reference ids must be unique")
        if len(set(open_ids.tolist())) != len(open_ids):
            raise ValueError("query ids must be unique")
        stable_keys = np.concatenate(
            [
                np.char.add("reference::", reference_ids),
                np.char.add("query::", open_ids),
            ]
        )
        order_policy = "role-prefixed stable sample id"
    else:
        # This fallback keeps the public helper usable in tests.  The runner
        # always supplies stable ids.  Identical rows share a key and are
        # exchangeable for density clustering.
        stable_keys = np.asarray(
            [
                f"reference::{np.ascontiguousarray(row).tobytes().hex()}"
                for row in reference
            ]
            + [
                f"query::{np.ascontiguousarray(row).tobytes().hex()}"
                for row in query
            ],
            dtype=str,
        )
        order_policy = "role-prefixed feature bytes fallback"
    if len(query) == 0:
        return (
            np.empty(0, dtype=bool),
            np.empty(0, dtype=np.int64),
            {
                "status": "empty_query",
                "reference_rows": int(len(reference)),
                "query_rows": 0,
            },
        )

    combined = np.vstack([reference, query])
    labels, selection_manifest = _stable_select_dbscan(
        combined,
        stable_keys,
        seed,
    )
    reference_labels = np.asarray(labels[: len(reference)], dtype=np.int64)
    query_labels = np.asarray(labels[len(reference) :], dtype=np.int64)
    anchored_clusters = set(reference_labels[reference_labels >= 0].tolist())
    no_anchor = np.asarray(
        [
            value >= 0 and int(value) not in anchored_clusters
            for value in query_labels
        ],
        dtype=bool,
    )
    clustered_labels = labels[labels >= 0]
    cluster_composition = []
    for cluster in sorted(set(clustered_labels.tolist())):
        reference_count = int(np.sum(reference_labels == cluster))
        query_count = int(np.sum(query_labels == cluster))
        cluster_composition.append(
            {
                "cluster": int(cluster),
                "reference_anchor_rows": reference_count,
                "query_rows": query_count,
                "anchored": bool(reference_count > 0),
            }
        )
    manifest = {
        "status": "paper_algorithm_2_adaptive_joint_known_anchor_dbscan",
        "reference_rows": int(len(reference)),
        "query_rows": int(len(query)),
        "algorithm_class": "sklearn.cluster.DBSCAN",
        "parameter_selection": selection_manifest,
        "parameter_origin": "paper_algorithm_2_unsupervised_kNN_silhouette_CH_frontier",
        "cluster_count": int(len(set(clustered_labels.tolist()))),
        "anchored_cluster_count": int(len(anchored_clusters)),
        "reference_noise_count": int(np.sum(reference_labels < 0)),
        "query_noise_count": int(np.sum(query_labels < 0)),
        "query_no_anchor_count": int(np.sum(no_anchor)),
        "cluster_composition": cluster_composition,
        "count_invariants": {
            "reference_clustered_plus_noise": int(
                np.sum(reference_labels >= 0) + np.sum(reference_labels < 0)
            ),
            "query_clustered_plus_noise": int(
                np.sum(query_labels >= 0) + np.sum(query_labels < 0)
            ),
        },
        "noise_routed_as_unknown": False,
        "target_labels_used": False,
        "unlabeled_query_features_used": True,
        "target_label_based_parameter_search": False,
        "unlabeled_feature_adaptive_parameter_selection": True,
        "row_order_policy": order_policy,
        "cluster_ids_canonicalized": True,
        "reference_feature_sha256": hashlib.sha256(
            np.ascontiguousarray(reference).tobytes()
        ).hexdigest(),
        "query_feature_sha256": hashlib.sha256(
            np.ascontiguousarray(query).tobytes()
        ).hexdigest(),
    }
    return no_anchor, query_labels, manifest


def dvc_route(
    coarse_prediction: np.ndarray,
    inference: InferenceOutput,
    novelty: NoveltyOutput,
    *,
    seed: int,
    known_reference_features: np.ndarray | None = None,
    query_features: np.ndarray | None = None,
    known_reference_ids: np.ndarray | None = None,
    query_ids: np.ndarray | None = None,
    kna_rejection_guard: dict[str, Any] | None = None,
) -> DVCOutput:
    if (known_reference_features is None) != (query_features is None):
        raise ValueError(
            "known_reference_features and query_features must be supplied together"
        )
    if (known_reference_ids is None) != (query_ids is None):
        raise ValueError("known reference ids and query ids must be supplied together")
    if known_reference_ids is not None and known_reference_features is None:
        raise ValueError("stable clustering ids require reference and query features")
    if query_features is not None and len(query_features) != len(coarse_prediction):
        raise ValueError("query feature rows do not match coarse predictions")
    if query_ids is not None and len(query_ids) != len(coarse_prediction):
        raise ValueError("query ids do not match coarse predictions")

    anchor_candidate = np.zeros(len(coarse_prediction), dtype=bool)
    joint_cluster = np.full(len(coarse_prediction), -2, dtype=np.int64)
    primary_cluster = np.full(len(coarse_prediction), -2, dtype=np.int64)
    second_cluster = np.full(len(coarse_prediction), -2, dtype=np.int64)
    if known_reference_features is not None and query_features is not None:
        anchor_candidate, joint_cluster, anchor_manifest = (
            _joint_known_anchor_candidates(
                known_reference_features,
                query_features,
                known_reference_ids,
                query_ids,
                seed=seed,
            )
        )
    else:
        anchor_manifest = {
            "status": "disabled_no_reference_features",
            "target_labels_used": False,
            "unlabeled_query_features_used": False,
        }

    score_candidate_indices = np.flatnonzero(novelty.candidate)
    if len(score_candidate_indices):
        score_candidate_features = np.column_stack(
            [
                inference.embedding[score_candidate_indices],
                novelty.score[score_candidate_indices, None] * 2.0,
            ]
        )
        score_candidate_ids = (
            None
            if query_ids is None
            else np.asarray(query_ids, dtype=str)[score_candidate_indices]
        )
        labels, manifest = _stable_select_dbscan(
            score_candidate_features,
            score_candidate_ids,
            seed + 17,
        )
        primary_cluster[score_candidate_indices] = labels
        noise_local = np.flatnonzero(labels < 0)
        if len(noise_local) >= 5:
            second_ids = (
                None
                if score_candidate_ids is None
                else score_candidate_ids[noise_local]
            )
            second_labels, second_manifest = _stable_select_dbscan(
                score_candidate_features[noise_local],
                second_ids,
                seed + 101,
            )
            second_cluster[score_candidate_indices[noise_local]] = second_labels
        else:
            second_manifest = {
                "status": "insufficient_primary_noise",
                "candidate_rows": int(len(noise_local)),
            }
    else:
        manifest = {"status": "no_candidates", "candidate_rows": 0}
        second_manifest = {"status": "no_candidates", "candidate_rows": 0}

    novelty_dvc_candidate = novelty.candidate & (
        (primary_cluster >= 0) | (second_cluster >= 0)
    )
    combined_candidate = np.asarray(
        anchor_candidate | novelty_dvc_candidate,
        dtype=bool,
    )

    confidence = np.max(inference.fine_probability, axis=1)
    in_known_core = (
        (novelty.prototype_percentile < 0.90)
        & (novelty.embedding_knn_percentile < 0.90)
        & (novelty.feature_knn_percentile < 0.90)
        & (confidence >= 0.95)
    )
    # The legacy route protects Stage-1 KNA unconditionally.  The optional
    # paper-aligned candidate may reject KNA only above a cutoff derived from
    # BEN/KNA-only calibration with an exact integer KNA retention budget.
    # A query-only cluster can route BEN directly; scalar BEN novelty also
    # requires leaving the high-confidence known core.
    anchor_unknown = anchor_candidate & (coarse_prediction == 0)
    novelty_unknown = novelty_dvc_candidate & (coarse_prediction == 0) & ~in_known_core
    if kna_rejection_guard is None:
        kna_unknown = np.zeros(len(coarse_prediction), dtype=bool)
        kna_threshold = None
    else:
        kna_threshold = validate_kna_guard(kna_rejection_guard)
        kna_unknown = (
            combined_candidate
            & (coarse_prediction == 1)
            & (np.asarray(novelty.score, dtype=np.float64) > kna_threshold)
        )
    unknown = anchor_unknown | novelty_unknown | kna_unknown
    protected_stage1_kna = combined_candidate & (coarse_prediction == 1) & ~kna_unknown
    known_core_rescue = (
        novelty_dvc_candidate
        & (coarse_prediction == 0)
        & in_known_core
        & ~anchor_candidate
    )
    rescued_known = protected_stage1_kna | known_core_rescue
    final_prediction = np.asarray(coarse_prediction, dtype=np.int64).copy()
    final_prediction[unknown] = 2

    dvc_manifest = {
        "candidate_definition": "union of an adaptive DBSCAN query-only cluster without a known fit anchor and a known-only novelty candidate retained by adaptive two-pass DVC",
        "score_strategy": novelty.score_strategy,
        "score_weights": NOVELTY_WEIGHTS,
        "known_rescue": {
            "prototype_percentile_lt": 0.90,
            "embedding_knn_percentile_lt": 0.90,
            "feature_knn_percentile_lt": 0.90,
            "fine_confidence_gte": 0.95,
        },
        "novelty_score_candidate_count": int(np.sum(novelty.candidate)),
        "novelty_dvc_candidate_count": int(np.sum(novelty_dvc_candidate)),
        "anchor_candidate_count": int(np.sum(anchor_candidate)),
        "candidate_count": int(np.sum(combined_candidate)),
        "rescued_known_definition": "union of protected Stage-1 KNA predictions and novelty candidates retained by the known core",
        "rescued_known_count": int(np.sum(rescued_known)),
        "protected_stage1_kna_count": int(np.sum(protected_stage1_kna)),
        "guarded_kna_rejected_count": int(np.sum(kna_unknown)),
        "guarded_kna_rejection": {
            "enabled": kna_rejection_guard is not None,
            "known_only_threshold": kna_threshold,
            "known_calibration_kna_support": (
                None if kna_rejection_guard is None else kna_rejection_guard["kna_support"]
            ),
            "known_calibration_remaining_error_budget": (
                None if kna_rejection_guard is None
                else kna_rejection_guard["remaining_kna_error_budget"]
            ),
            "unknown_labels_used_for_threshold": False,
        },
        "known_core_rescue_count": int(np.sum(known_core_rescue)),
        "routed_una_count": int(np.sum(unknown)),
        "routed_una_evidence_partition": {
            "anchor_only": int(np.sum(anchor_unknown & ~novelty_unknown)),
            "novelty_only": int(np.sum(novelty_unknown & ~anchor_unknown)),
            "both": int(np.sum(anchor_unknown & novelty_unknown)),
            "kna_guarded": int(np.sum(kna_unknown)),
            "union": int(np.sum(unknown)),
        },
        "stage1_kna_predictions_protected": kna_rejection_guard is None,
        "decision_effect_count": int(
            np.sum(final_prediction != np.asarray(coarse_prediction, dtype=np.int64))
        ),
        "joint_known_anchor": anchor_manifest,
        "novelty_candidate_dbscan": manifest,
        "novelty_candidate_dbscan_noise_second_pass": second_manifest,
        "target_labels_used": False,
        "unlabeled_query_features_used": bool(query_features is not None),
        "target_label_based_parameter_search": False,
        "unlabeled_feature_adaptive_parameter_selection": True,
    }
    return DVCOutput(
        final_prediction=final_prediction,
        candidate=combined_candidate,
        anchor_candidate=anchor_candidate,
        novelty_candidate=np.asarray(novelty_dvc_candidate, dtype=bool),
        novelty_score_candidate=np.asarray(novelty.candidate, dtype=bool),
        rescued_known=rescued_known,
        protected_stage1_kna=protected_stage1_kna,
        known_core_rescue=known_core_rescue,
        joint_cluster=joint_cluster,
        primary_cluster=primary_cluster,
        second_cluster=second_cluster,
        dvc_manifest=dvc_manifest,
    )
