"""BEN-only single joint whitened-view relative local reachability density.

Every fit query is removed from all neighbours, kth distances and reference
local densities. The whitener itself stays fit on the full known group, so
this is neighbour-graph jackknife, NOT full-model/covariance refitting LOO.
Full jackknife fit, actual in-sample fit and protected known calibration
maxima freeze cutoffs. Unknowns never fit this policy; DVC remains required.
"""
from dataclasses import dataclass
import hashlib
import numpy as np
from scipy.spatial.distance import cdist
from . import known_ben_context_whitened_semantic_views as baseline_views
from .known_ben_context_whitened_fit_loo import KnownContextWhitener, context_keys
from .local_ben_affinity_envelope_guarded import _matrix, _roles
from .dvc import NoveltyOutput

SCHEMA = "known-BEN-single-joint-whitened-relative-local-reachability-full-neighbour-density-jackknife-v1"
NEIGHBORS, MIN_FIT, MIN_CALIBRATION = 7, 9, 3
DENSITY_FLOOR = 1.e-12
FIELDS = baseline_views.FIELDS


def joint_view_columns(feature_names):
    """All four canonical numeric blocks together, not a max of four scores."""
    names = tuple(str(n) for n in feature_names)
    baseline_views.view_columns(names)  # Validate complete declared schema.
    categorical = tuple(i for i, n in enumerate(names)
        if any(n.startswith(f+"_") for f in ("protocol_type", "service", "flag")))
    numeric = tuple(names.index(n) for _, fields in baseline_views.BLOCKS for n in fields if n in names)
    columns = categorical+numeric
    if len(columns) != len(names) or set(columns) != set(range(len(names))):
        raise ValueError("single joint view must cover every selected field exactly once")
    return {"joint_all_canonical_numeric_and_context": columns}


def sha(x): return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()


def rowwise_coordinates(metric, rows):
    """Use the same one-row BLAS shape for references and every query batch."""
    x = np.asarray(rows, dtype=np.float64)
    if x.ndim != 2 or x.shape[1] != metric.n_features_in_:
        raise ValueError("paired fixed-width coordinate rows required")
    if not len(x):
        return np.empty((0, x.shape[1]), dtype=np.float64)
    return np.vstack([metric.transform(row[None, :])[0] for row in x])


def reference_density_and_jackknife(z):
    """Delete actual query index from EVERY reference neighbour/density."""
    z = _matrix(z, "known whitened reference")
    if len(z) < MIN_FIT: raise ValueError("nine references required for full density jackknife")
    distances = cdist(z, z, metric="euclidean")
    np.fill_diagonal(distances, np.inf)
    nearest8 = np.argsort(distances, axis=1, kind="stable")[:, :NEIGHBORS+1]
    nearest = nearest8[:, :NEIGHBORS]
    rows = np.arange(len(z))[:, None]
    kth = distances[np.arange(len(z)), nearest[:, -1]]
    eighth = distances[np.arange(len(z)), nearest8[:, -1]]
    reachability = np.maximum(distances[rows, nearest], kth[nearest]).mean(axis=1)
    density = 1. / np.maximum(reachability, DENSITY_FLOOR)
    jackknife = np.empty(len(z), dtype=np.float64)
    for i in range(len(z)):
        changed = np.any(nearest == i, axis=1)
        kth_without = np.where(changed, eighth, kth)
        # Retain source-distance tie order, skipping actual index i, not a
        # guessed zero row. Eight entries suffice to retain seven after deletion.
        positions = np.arange(NEIGHBORS)[None, :] + np.cumsum(nearest == i, axis=1)
        neighbours_without = np.take_along_axis(nearest8, positions, axis=1)
        if np.any(neighbours_without == i):
            raise AssertionError("deleted query leaked into a reference density")
        reach_without = np.maximum(distances[rows, neighbours_without], kth_without[neighbours_without]).mean(axis=1)
        density_without = 1. / np.maximum(reach_without, DENSITY_FLOOR)
        query_neighbours = nearest[i]
        query_reach = np.maximum(distances[i, query_neighbours], kth_without[query_neighbours]).mean()
        jackknife[i] = density_without[query_neighbours].mean() * max(float(query_reach), DENSITY_FLOOR)
    if any(not np.isfinite(v).all() for v in (kth, density, jackknife)):
        raise ValueError("finite reachability density and full neighbour jackknife required")
    return kth, density, jackknife


def group_statistic(group, rows):
    z = rowwise_coordinates(group["metric"], rows)
    distances = cdist(z, group["reference"], metric="euclidean")
    nearest = np.argsort(distances, axis=1, kind="stable")[:, :NEIGHBORS]
    selected = np.take_along_axis(distances, nearest, axis=1)
    query_reach = np.maximum(selected, group["k_distance"][nearest]).mean(axis=1)
    values = group["local_density"][nearest].mean(axis=1) * np.maximum(query_reach, DENSITY_FLOOR)
    if not np.isfinite(values).all(): raise ValueError("relative local reachability density overflow")
    return values


def state_sha(group):
    h = hashlib.sha256(float(group["cutoff"]).hex().encode("ascii"))
    m = group["metric"]
    for v in (m.mean_, m.scale_, m.var_, m.whitener_, m.covariance_, m.active_columns_,
            np.asarray([m.shrinkage_, m.n_features_in_, m.n_samples_seen_]),
            group["reference"], group["k_distance"], group["local_density"]):
        a = np.asarray(v, dtype="<f8", order="C")
        h.update(str(a.shape).encode("ascii")); h.update(a.tobytes())
    return h.hexdigest()


@dataclass
class JointWhitenedLocalReachability:
    feature_names: tuple
    columns: dict
    nodes: dict
    calibration_ratios: np.ndarray
    manifest: dict


def check(profile):
    m = profile.manifest
    if (m.get("schema_version") != SCHEMA or m.get("frozen_manifest_sha256") != baseline_views._manifest_sha(m)
            or profile.columns != joint_view_columns(profile.feature_names)
            or m.get("query_truth_or_ID_or_family_used") is not False
            or m.get("full_neighbour_density_jackknife_for_fit_query") is not True
            or m.get("whitener_is_NOT_refit_per_left_out_row") is not True
            or m.get("deleted_fit_query_excluded_from_all_reference_neighbours_kdist_and_density") is not True
            or m.get("reference_and_query_whitening_fixed_one_row_operation_shape") is not True
            or m.get("local_density_floor") != DENSITY_FLOOR
            or m.get("all_selected_features_once_in_single_joint_view") is not True):
        raise ValueError("frozen relative local-density policy required")
    declarations = {tuple(r["context"]): r for r in m["nodes"] if r["admitted"]}
    if set(profile.nodes) != set(declarations) or sha(profile.calibration_ratios) != m["calibration_ratio_sha256"]:
        raise ValueError("frozen density support/calibration reference required")
    ref = profile.calibration_ratios
    if ref.ndim != 1 or not len(ref) or not np.isfinite(ref).all() or np.any(ref < 0) or np.any(ref > 1) or not np.array_equal(ref, np.sort(ref)):
        raise ValueError("known-only sorted finite aggregate ratio reference required")
    for key, groups in profile.nodes.items():
        if tuple(groups) != tuple(profile.columns): raise ValueError("fixed single joint-view density required")
        for view, group in groups.items():
            if (state_sha(group) != declarations[key]["views"][view]["state_sha256"]
                    or group["cutoff"] <= 0 or not np.isfinite(group["cutoff"])):
                raise ValueError("frozen local density/reference/metric changed")


def _ratios(profile, x):
    keys = context_keys(x, profile.feature_names)
    maximum = np.zeros(len(x)); eligible = np.zeros(len(x), dtype=bool)
    for key, groups in profile.nodes.items():
        indices = np.array([i for i, k in enumerate(keys) if k == key], dtype=np.int64)
        if not len(indices): continue
        ratios = [group_statistic(groups[v], x[indices][:, cols])/groups[v]["cutoff"] for v, cols in profile.columns.items()]
        maximum[indices] = np.max(np.stack(ratios), axis=0); eligible[indices] = True
    return maximum, eligible


def fit_profile(fit_features, fit_truth, calibration_features, calibration_truth,
                primary, baseline, feature_names, deep_profile):
    x, cal = _matrix(fit_features, "known fit"), _matrix(calibration_features, "known calibration")
    y, cy = _roles(fit_truth, len(x), "known fit truth"), _roles(calibration_truth, len(cal), "known calibration truth")
    p = _roles(primary, len(cal), "known calibration primary"); b = np.asarray(baseline)
    names = tuple(str(n) for n in feature_names)
    if (x.shape[1] != len(names) or cal.shape[1] != len(names) or b.shape != p.shape
            or b.dtype.kind not in "iu" or not np.isin(b, (0, 1, 2)).all() or np.any((b != p) & (b != 2))
            or set(cy.tolist()) != {0, 1} or deep_profile.feature_names != names):
        raise ValueError("paired known-only physical fit/cal roles required")
    baseline_views.components(deep_profile, cal)
    columns = joint_view_columns(names); fk, ck = context_keys(x, names), context_keys(cal, names)
    protected = (cy == 0) & (p == 0) & (b == 0); nodes, audit = {}, []
    for key in sorted({k for k, label in zip(fk, y) if label == 0}):
        fi = np.array([i for i, k in enumerate(fk) if k == key and y[i] == 0], dtype=np.int64)
        ci = np.array([i for i, k in enumerate(ck) if k == key and protected[i]], dtype=np.int64)
        row = {"context": list(key), "known_BEN_fit_rows": len(fi), "correct_BEN_calibration_rows": len(ci),
            "admitted": len(fi) >= MIN_FIT and len(ci) >= MIN_CALIBRATION}
        if not row["admitted"]: audit.append(row); continue
        groups, views = {}, {}
        for view, cols in columns.items():
            known = x[fi][:, cols]
            known = known[np.lexsort(tuple(known[:, i] for i in range(known.shape[1]-1, -1, -1)))]
            metric = KnownContextWhitener().fit(known); z = rowwise_coordinates(metric, known)
            kth, density, loo = reference_density_and_jackknife(z)
            group = {"metric": metric, "reference": z, "k_distance": kth, "local_density": density}
            cal_scores = group_statistic(group, cal[ci][:, cols])
            in_sample = group_statistic(group, known)
            # Changing reference scales during deletion is not monotone in
            # the usual query statistic; explicitly retain both fit scopes.
            maximum = max(1.e-12, float(loo.max()), float(in_sample.max()), float(cal_scores.max()))
            cutoff = float(maximum+64*np.finfo(np.float64).eps*max(1., maximum))
            group["cutoff"] = cutoff; group["state_sha256"] = state_sha(group); groups[view] = group
            views[view] = {"cutoff": cutoff, "full_neighbour_jackknife_fit_maximum": float(loo.max()),
                "calibration_relative_density_maximum": float(cal_scores.max()), "known_fit_geometry_sha256": sha(known),
                "actual_in_sample_fit_maximum": float(in_sample.max()), "in_sample_scores_sha256": sha(in_sample),
                "seventh_distance_sha256": sha(kth), "reference_local_density_sha256": sha(density),
                "fit_jackknife_scores_sha256": sha(loo), "state_sha256": group["state_sha256"]}
        nodes[key] = groups; audit.append({**row, "views": views})
    if not nodes: raise ValueError("no known context has nine BEN fit and three correct BEN cal")
    profile = JointWhitenedLocalReachability(names, columns, nodes, np.empty(0), {})
    ratio, eligible = _ratios(profile, cal); ref = np.sort(ratio[protected & eligible])
    if not len(ref) or np.any(ref > 1): raise AssertionError("known calibration relative local-density retention failed")
    profile.calibration_ratios = ref
    manifest = {"schema_version": SCHEMA, "nodes": audit, "view_columns": {k: list(v) for k, v in columns.items()},
        "retained_white_baseline_manifest": deep_profile.manifest,
        "statistic": "mean local density of seven nearest known references divided by query local reachability density",
        "minimum_fit": MIN_FIT, "minimum_calibration": MIN_CALIBRATION, "neighbors": NEIGHBORS,
        "local_density_floor": DENSITY_FLOOR, "full_neighbour_density_jackknife_for_fit_query": True,
        "all_selected_features_once_in_single_joint_view": True,
        "single_joint_covariance_NOT_union_of_four_view_scores": True,
        "whitener_is_NOT_refit_per_left_out_row": True,
        "deleted_fit_query_excluded_from_all_reference_neighbours_kdist_and_density": True,
        "known_distance_ties_use_stable_numeric_reference_order_NOT_ID": True,
        "reference_and_query_whitening_fixed_one_row_operation_shape": True,
        "all_fit_LOO_and_correct_cal_maximum_cutoff": True, "calibration_ratio_sha256": sha(ref),
        "actual_in_sample_fit_maximum_also_retained": True,
        "query_truth_or_ID_or_family_used": False, "known_only_calibration": True,
        "context_minima_are_NOT_Table1_family_or_independent_event_floors": True,
        "unsupported_context_action": "keep baseline and full denominator",
        "retained_baseline_predictions_must_not_be_removed": True, "non_noise_DVC_required": True,
        "historical_development_inspection_precedes_rule_design": True, "new_query_99_NOT_guaranteed": True,
        "status": "FAIL_TARGET99", "published": False, "final_test_executed": False}
    manifest["frozen_manifest_sha256"] = baseline_views._manifest_sha(manifest); profile.manifest = manifest
    check(profile); return profile


def components(profile, features):
    check(profile); x = _matrix(features, "whitened local reachability query")
    if x.shape[1] != len(profile.feature_names): raise ValueError("full saved model feature width required")
    ratio, eligible = _ratios(profile, x)
    rank = np.zeros(len(x)); ref = profile.calibration_ratios
    rank[eligible] = np.searchsorted(ref, ratio[eligible], side="right")/(len(ref)+1.)
    support_marker = np.where(eligible, 0, -1).astype(np.int64)
    # Five-field interface reused by the paired diagnostic scaffold. Last
    # mask explicitly means local density support, not hierarchical fallback.
    return ratio, rank, support_marker, eligible, eligible.copy()


def score(profile, features, primary, original):
    ratio, rank, marker, eligible, supported = components(profile, features)
    p = _roles(primary, len(ratio), "query primary")
    if (not isinstance(original, NoveltyOutput) or any(np.asarray(getattr(original, k)).shape != p.shape for k in FIELDS)
            or any(not np.isfinite(getattr(original, k)).all() for k in FIELDS) or np.asarray(original.candidate).dtype != bool):
        raise ValueError("paired finite original novelty required")
    values = {k: np.asarray(getattr(original, k)).copy() for k in FIELDS}; mask = (p == 0) & eligible
    values["score"][mask] = ratio[mask]; values["threshold"][mask] = values["high_threshold"][mask] = 1.
    values["candidate"][mask] = ratio[mask] > 1.; values["feature_knn_percentile"][mask] = rank[mask]
    return NoveltyOutput(**values, score_strategy="known_BEN_joint_whitened_local_reachability_"+original.score_strategy), ratio, marker, eligible, supported
