"""Source same-fine relation and bounded Potts query inference.

Only real known source labels train edge weights. Source nodes are exactly
eliminated into unaries. Alpha expansion is not a global three-label solver.
"""
from __future__ import annotations
import hashlib
import time
import networkx as nx
import numpy as np
from scipy.spatial.distance import cdist
from sklearn.ensemble import HistGradientBoostingClassifier

SCHEMA = 'V1023_SOURCE_RELATIONAL_POTTS_GRAPH'
SOURCE_FIT_STATUS = 'SOURCE_PARAMETERS_COMPLETE'
SEED = 20261024
PAIR_COUNT = 8192
K_NATIVE, K_PAPER, PAPER_EUCLIDEAN_SHORTLIST = 7, 7, 32
ALPHA_ORDER, MAX_SWEEPS = (2, 0, 1), 6
UNKNOWN_CHANGE_PRIOR, KNOWN_CHANGE_PRIOR = 4., .25
FEATURE_NAMES = ('native_log1p', 'paper_log1p', 'log_product',
                 'absolute_log_difference', 'native_log_squared', 'paper_log_squared')


def require(ok, message):
    if not bool(ok):
        raise ValueError(message)


def _matrix(x):
    x = np.asarray(x, np.float64)
    require(x.ndim == 2 and x.shape[1] > 0 and np.isfinite(x).all(), 'finite matrix')
    return x


def _labels(y, n, allowed=None):
    y = np.asarray(y)
    require(y.shape == (n,) and np.issubdtype(y.dtype, np.integer), 'aligned integer labels')
    if allowed is not None:
        require(np.isin(y, allowed).all(), 'declared class domain')
    return y.astype(np.int64, copy=False)


def _strings(values, n, name):
    a = np.asarray(values).astype(str)
    require(a.shape == (n,) and np.all(a != '') and len(np.unique(a)) == n,
            name + ' must be unique genuine identifiers')
    return a


def _source_pairs(y, groups, native, z):
    """Distinct source pairs: nearest hard coverage, fine-uniform supplement.

    Label parity and source-view choice use a fixed four-parent cycle, so
    positive/negative label is not confounded with native/Z neighbor view.
    """
    n = len(y); fine = np.unique(y)
    require(len(fine) >= 2 and 0 in fine, 'BEN and actual known attack source families')
    members = {int(f): np.flatnonzero(y == f) for f in fine}
    positive_capacity = sum(len(v)*(len(v)-1)//2 for v in members.values())
    target = PAIR_COUNT//2
    require(positive_capacity >= target and n*(n-1)//2-positive_capacity >= target,
            'enough unique physical pairs; copies do not increase pair support')
    rng = np.random.default_rng(SEED)
    pairs, labels, used = [], [], set(); counts = np.zeros(2, np.int64)

    def add(i, j):
        if i == j:
            return False
        pair = (min(int(i), int(j)), max(int(i), int(j)))
        label = int(y[pair[0]] == y[pair[1]])
        if pair in used or counts[label] >= target:
            return False
        used.add(pair); pairs.append(pair); labels.append(label); counts[label] += 1
        return True

    order = sorted(range(n), key=lambda i: hashlib.sha256(
        (str(SEED)+'|coverage|'+groups[i]).encode()).digest())
    for ordinal, i in enumerate(order):
        done = False
        coordinates = native if (ordinal//2) % 2 == 0 else z
        for label in (ordinal % 2, 1-ordinal % 2):
            if counts[label] >= target:
                continue
            pool = np.flatnonzero((y == y[i]) if label else (y != y[i]))
            pool = pool[pool != i]
            if len(pool):
                distances = cdist(coordinates[i:i+1], coordinates[pool], metric='euclidean')[0]
                nearest = np.lexsort((pool, distances))
                for j in pool[nearest]:
                    if add(i, j):
                        done = True; break
            if done:
                break
        require(done, 'each genuine source parent must get a nonself coverage pair')
    strata = {1: [(int(f), int(f)) for f in fine if len(members[int(f)]) >= 2],
              0: [(int(f), int(h)) for i, f in enumerate(fine) for h in fine[i+1:]]}
    for label in (1, 0):
        active = list(strata[label])
        while counts[label] < target:
            require(active, 'genuine pair stratum capacity exhausted')
            for stratum in [active[i] for i in rng.permutation(len(active))]:
                if counts[label] == target:
                    break
                f, h = stratum; aa, bb = members[f], members[h]; done = False
                for _ in range(32):
                    if add(aa[int(rng.integers(len(aa)))], bb[int(rng.integers(len(bb)))]):
                        done = True; break
                if not done:
                    for i in aa:
                        for j in bb:
                            if add(i, j):
                                done = True; break
                        if done:
                            break
                if not done:
                    active.remove(stratum)
    pair, labels = np.asarray(pairs, np.int64), np.asarray(labels, np.int8)
    require(pair.shape == (PAIR_COUNT, 2) and len(used) == PAIR_COUNT and
            np.array_equal(np.unique(pair), np.arange(n)) and
            np.bincount(labels, minlength=2).tolist() == [4096, 4096],
            'exact8192 unique balanced pairs covering all genuine source parents')
    return pair, labels


def _paired(metric, left, right):
    require(left.shape == right.shape, 'paired metric rows aligned')
    d = np.asarray(metric(left, right), np.float64)
    require(d.shape == (len(left),) and np.isfinite(d).all() and np.all(d >= 0),
            'finite nonnegative original metric paired distances')
    return d


def _features(dn, dm, scales):
    x, y = np.log1p(np.asarray(dn)/scales[0]), np.log1p(np.asarray(dm)/scales[1])
    result = np.column_stack((x, y, x*y, np.abs(x-y), x*x, y*y))
    require(result.shape == (len(x), 6) and np.isfinite(result).all(), 'six symmetric pair features')
    return result


def fit_edge(N_R, Z_R, yfine, g, ids, paired_metric, logical_slots):
    started = time.perf_counter(); native, z = _matrix(N_R), _matrix(Z_R); n = len(native)
    require(n == len(z) and 1 < n <= 6000, 'genuine traffic rows within cap')
    y = _labels(yfine, n); require(np.all(y >= 0), 'known source fine labels only')
    groups, identifiers = _strings(g, n, 'source groups'), _strings(ids, n, 'source IDs')
    slots = np.asarray(logical_slots)
    require(slots.ndim == 1 and np.issubdtype(slots.dtype, np.integer) and n <= len(slots) <= 6000
            and slots.min() >= 0 and slots.max() < n, 'FIT-only source parent map within6000')
    multiplicity = np.bincount(slots, minlength=n)
    require(np.all(multiplicity >= 1) and all(np.sum(y[slots] == f) >= 20 for f in np.unique(y)),
            'all parents retained; present fine floor20 only in FIT loss material')
    pair, binary = _source_pairs(y, groups, native, z)
    dn = np.linalg.norm(native[pair[:, 0]]-native[pair[:, 1]], axis=1)
    dm = _paired(paired_metric, z[pair[:, 0]], z[pair[:, 1]])
    require(np.any(dn > 0) and np.any(dm > 0), 'positive pair support in both distance views')
    scales = np.asarray([np.median(dn[dn > 0]), np.median(dm[dm > 0])], np.float64)
    features = _features(dn, dm, scales)
    weights = np.sqrt(multiplicity[pair[:, 0]]*multiplicity[pair[:, 1]]).astype(np.float64)
    for label in (0, 1):
        use = binary == label; weights[use] /= weights[use].mean()
    model = HistGradientBoostingClassifier(max_iter=80, max_leaf_nodes=15, learning_rate=.05,
        l2_regularization=1., max_bins=64, min_samples_leaf=20, class_weight='balanced',
        early_stopping=False, random_state=SEED)
    tick = time.perf_counter(); model.fit(features, binary, sample_weight=weights)
    seconds = time.perf_counter()-tick
    require(model.classes_.tolist() == [0, 1] and model.n_iter_ == 80, 'actual fixed80 relation HGB')
    family = {}
    for f in np.unique(y):
        genuine = int(np.sum(y == f))
        family[str(int(f))] = dict(genuine_parents=genuine, logical_FIT_rows=int(np.sum(y[slots] == f)),
            unique_positive_pairs=int(np.sum((binary == 1) & (y[pair[:, 0]] == f))),
            unique_negative_pair_involvements=int(np.sum((binary == 0) & ((y[pair[:, 0]] == f) | (y[pair[:, 1]] == f)))),
            independent_positive_status='UNASSESSABLE_SINGLE_PARENT' if genuine < 2 else 'GENUINE_PAIRS_NOT_INDEPENDENT_TRAFFIC')
    return dict(schema=SCHEMA, model=model, scales=scales, feature_names=FEATURE_NAMES,
        pair_indices=pair, pair_labels=binary, pair_weights=weights, source_ids=identifiers,
        source_groups=groups, source_fine=y, native_width=native.shape[1], metric_width=z.shape[1],
        fit_record=dict(genuine_source_parents=n, logical_FIT_rows=len(slots), FIT_slot_parent_indices=slots,
            FIT_parent_multiplicity=multiplicity, pair_count=PAIR_COUNT, binary_pair_counts=[4096, 4096],
            fine_pair_support=family, pair_features_count=6, genuine_pair_uniqueness=True,
            every_source_parent_covered=True, pair_views_are_not_independent_traffic=True,
            hard_coverage_pair_rows=n,
            hard_coverage_label_policy='ordinal%2, fallback only when no valid physical partner of that label',
            hard_coverage_view_policy='(ordinal//2)%2: native,native,Z,Z repeating; nearest unused valid pair',
            remaining_pairs='fixed random fine-uniform stratum cycles; exhausted strata removed',
            reference_resampling=False, HGB_fits=1, HGB_iterations=80, HGB_fit_seconds=seconds,
            total_edge_source_seconds=time.perf_counter()-started, source_only_positive_median_distance_scales=scales,
            pair_weight='sqrt(FIT multiplicity_i*multiplicity_j), mean1 per binary class',
            source_true_UNA_fit=False, query_fit=False), published=False, final_test_executed=False)


def source_elimination(query_nodes, source_classes, weights, n):
    qi, sc, w = np.asarray(query_nodes, np.int64), np.asarray(source_classes, np.int64), np.asarray(weights, np.float64)
    require(qi.shape == sc.shape == w.shape and np.isin(sc, (0, 1)).all(), 'genuine labelled source edges')
    require(np.all(w >= 0) and np.isfinite(w).all(), 'nonnegative source-edge capacities')
    mass = np.zeros((n, 2), np.float64); np.add.at(mass, (qi, sc), w)
    return np.column_stack((mass[:, 1], mass[:, 0], mass.sum(1)))


def potts_energy(labels, unary, left, right, weights):
    labels, u = np.asarray(labels, np.int64), np.asarray(unary, np.float64)
    return float(np.sum(u[np.arange(len(labels)), labels], dtype=np.float64) +
                 np.sum(np.asarray(weights, np.float64)[labels[left] != labels[right]], dtype=np.float64))


def alpha_move(labels, unary, left, right, weights, alpha):
    """Exact binary expansion minimum using floating capacities."""
    labels = np.asarray(labels, np.int64); n = len(labels)
    left, right, w = np.asarray(left, np.int64), np.asarray(right, np.int64), np.asarray(weights, np.float64)
    require(alpha in (0, 1, 2) and np.all(w >= 0), 'valid Potts expansion')
    d0 = np.asarray(unary, np.float64)[np.arange(n), labels].copy()
    d1 = np.asarray(unary, np.float64)[:, alpha].copy()
    e00, e01, e10 = w*(labels[left] != labels[right]), w*(labels[left] != alpha), w*(alpha != labels[right])
    capacity = .5*(e01+e10-e00)
    require(np.all(capacity >= 0), 'submodular Potts expansion')
    np.add.at(d1, left, e10-e00-capacity); np.add.at(d1, right, e01-e00-capacity)
    floor = np.minimum(d0, d1); d0 -= floor; d1 -= floor
    require(np.isfinite(d0).all() and np.isfinite(d1).all() and np.all(d0 >= 0) and np.all(d1 >= 0),
            'finite nonnegative shifted unary capacities')
    source, sink = n, n+1; graph = nx.DiGraph(); graph.add_nodes_from(range(n+2))
    for i in range(n):
        graph.add_edge(source, i, capacity=float(d1[i])); graph.add_edge(i, sink, capacity=float(d0[i]))
    for i, j, value in zip(left, right, capacity):
        if value > 0:
            graph.add_edge(int(i), int(j), capacity=float(value))
            graph.add_edge(int(j), int(i), capacity=float(value))
    _, partition = nx.minimum_cut(graph, source, sink, capacity='capacity', flow_func=nx.algorithms.flow.preflow_push)
    trial = labels.copy(); trial[[int(i) for i in partition[1] if i < n]] = alpha
    return trial


def alpha_expansion(unary, left, right, weights, initial):
    unary = np.asarray(unary, np.float64); labels = _labels(initial, len(unary), (0, 1, 2)).copy()
    require(unary.shape == (len(labels), 3) and np.isfinite(unary).all(), 'finite three-label unaries')
    left, right, weights = np.asarray(left, np.int64), np.asarray(right, np.int64), np.asarray(weights, np.float64)
    require(left.shape == right.shape == weights.shape and np.all(left < right) and np.all(left >= 0)
            and np.all(right < len(labels)) and np.all(weights >= 0), 'ordered nonnegative query edges')
    require(len(set(zip(left.tolist(), right.tolist()))) == len(left), 'one capacity per undirected query edge')
    energy = potts_energy(labels, unary, left, right, weights); history, moves = [energy], []; converged = False
    for sweep in range(MAX_SWEEPS):
        accepted = 0
        for alpha in ALPHA_ORDER:
            trial = alpha_move(labels, unary, left, right, weights, alpha)
            value = potts_energy(trial, unary, left, right, weights)
            take = value < energy
            moves.append(dict(sweep=sweep+1, alpha=alpha, before=energy, candidate=value,
                              accepted=bool(take), changed_nodes=int(np.sum(trial != labels))))
            # No tolerance or integer rounding in production acceptance: tie keeps parent state.
            if take:
                labels, energy = trial, value; history.append(energy); accepted += 1
        if not accepted:
            converged = True; break
    return dict(labels=labels, energy_history=np.asarray(history, np.float64), moves=moves,
                converged=converged, completed_sweeps=sweep+1, accepted_moves=sum(m['accepted'] for m in moves),
                global_three_label_optimum_claimed=False, binary_moves_use_exact_min_cut=True)


def local_costs(labels, unary, left, right, weights):
    result = np.asarray(unary, np.float64).copy()
    for c in range(3):
        np.add.at(result[:, c], left, weights*(labels[right] != c))
        np.add.at(result[:, c], right, weights*(labels[left] != c))
    return result


def _exact_euclidean_neighbors(query, all_rows, own_positions, k):
    """Full-search Euclidean kNN; ties use stable natural ordered-roster index."""
    k = min(k, len(all_rows)-1); require(k >= 0, 'valid neighbor population')
    result = np.empty((len(query), k), np.int64)
    for first in range(0, len(query), 64):
        distance = cdist(query[first:first+64], all_rows, metric='euclidean')
        for at, row in enumerate(distance):
            q = first+at; row[int(own_positions[q])] = np.inf
            if k:
                cutoff = np.partition(row, k-1)[k-1]; eligible = np.flatnonzero(row <= cutoff)
                order = np.lexsort((eligible, row[eligible])); result[q] = eligible[order[:k]]
    return result


def infer_graph(N_R, Z_R, ycoarse, g_R, N_Q, Z_Q, g_Q, threeway_logits,
                parent_group_labels, edge_bundle, paired_metric):
    started = time.perf_counter(); nr, zr, nq, zq = _matrix(N_R), _matrix(Z_R), _matrix(N_Q), _matrix(Z_Q)
    n, r = len(nq), len(nr)
    require(n > 0 and len(zq) == n and len(zr) == r and nr.shape[1] == nq.shape[1]
            and zr.shape[1] == zq.shape[1], 'matched source/query view dimensions')
    gr, gq = _strings(g_R, r, 'source groups'), _strings(g_Q, n, 'canonical query groups')
    yc, parent = _labels(ycoarse, r, (0, 1)), _labels(parent_group_labels, n, (0, 1, 2))
    require(edge_bundle['schema'] == SCHEMA and np.array_equal(gr, edge_bundle['source_groups'])
            and np.array_equal(yc, (edge_bundle['source_fine'] > 0).astype(np.int64)), 'same source relation/boundary roster')
    logits = _matrix(threeway_logits); require(logits.shape == (n, 3), 'continuous threeway weak logits')
    keep = ~np.isin(gr, gq); source_indices = np.flatnonzero(keep); m = len(source_indices)
    all_n, all_z = np.vstack((nr[keep], nq)), np.vstack((zr[keep], zq)); own = m+np.arange(n)
    native_neighbors = _exact_euclidean_neighbors(nq, all_n, own, K_NATIVE)
    shortlist = _exact_euclidean_neighbors(zq, all_z, own, PAPER_EUCLIDEAN_SHORTLIST)
    paper_neighbors = np.empty((n, min(K_PAPER, max(0, len(all_z)-1))), np.int64)
    for first in range(0, n, 128):
        chunk = shortlist[first:first+128]
        if chunk.shape[1]:
            left = np.repeat(zq[first:first+len(chunk)], chunk.shape[1], axis=0)
            distance = _paired(paired_metric, left, all_z[chunk.ravel()]).reshape(chunk.shape)
            for row in range(len(chunk)):
                order = np.lexsort((chunk[row], distance[row])); paper_neighbors[first+row] = chunk[row, order[:paper_neighbors.shape[1]]]
    qq, qr = set(), set()
    for i in range(n):
        for j in np.unique(np.r_[native_neighbors[i], paper_neighbors[i]]):
            if j < m:
                qr.add((i, int(j)))
            else:
                j = int(j)-m; require(j != i, 'self query edge excluded'); qq.add((min(i, j), max(i, j)))
    qq, qr = np.asarray(sorted(qq), np.int64).reshape(-1, 2), np.asarray(sorted(qr), np.int64).reshape(-1, 2)

    def probability(left_n, right_n, left_z, right_z):
        if not len(left_n):
            return np.empty(0, np.float64)
        dn = np.linalg.norm(left_n-right_n, axis=1); dm = _paired(paired_metric, left_z, right_z)
        p = edge_bundle['model'].predict_proba(_features(dn, dm, edge_bundle['scales']))[:, 1]
        require(np.isfinite(p).all() and np.all((p >= 0) & (p <= 1)), 'valid same-fine probabilities')
        return p

    pq = probability(nq[qq[:, 0]], nq[qq[:, 1]], zq[qq[:, 0]], zq[qq[:, 1]])
    pr = probability(nq[qr[:, 0]], all_n[qr[:, 1]], zq[qr[:, 0]], all_z[qr[:, 1]])
    degree = np.bincount(qq.ravel(), minlength=n)
    qw = 7.*pq/np.maximum(7, np.maximum(degree[qq[:, 0]], degree[qq[:, 1]]))
    source_mass = np.bincount(qr[:, 0], weights=pr, minlength=n)
    rw = pr/np.maximum(1., source_mass[qr[:, 0]])
    source_unary = source_elimination(qr[:, 0], yc[keep][qr[:, 1]], rw, n)
    wd = np.bincount(qq[:, 0], weights=qw, minlength=n)+np.bincount(qq[:, 1], weights=qw, minlength=n)
    require(np.all(wd <= 7.+1e-12) and np.all(source_unary[:, 2] <= 1.+1e-12),
            'numerical validation of per-query edge bounds; not an action tolerance')
    centered = logits-logits.max(axis=1, keepdims=True); prob = np.exp(centered); prob /= prob.sum(axis=1, keepdims=True)
    base = 1.-prob; strength = np.where(parent == 2, UNKNOWN_CHANGE_PRIOR, KNOWN_CHANGE_PRIOR)
    prior = strength[:, None]*(np.arange(3)[None, :] != parent[:, None]); no_parent = base+source_unary
    inference = alpha_expansion(no_parent+prior, qq[:, 0], qq[:, 1], qw, parent); labels = inference['labels']
    costs = local_costs(labels, no_parent, qq[:, 0], qq[:, 1], qw)
    coarse = costs[:, :2].argmin(axis=1).astype(np.int8); row = np.arange(n)
    S = costs[:, :2].min(axis=1)-costs[:, 2]
    counter = costs+np.asarray([UNKNOWN_CHANGE_PRIOR, UNKNOWN_CHANGE_PRIOR, 0.])[None, :]
    A = np.minimum(counter[row, 1-coarse], counter[:, 2])-counter[row, coarse]
    known = (labels < 2) & (labels == coarse) & (A > 0.); raw = (labels == 2) & (S > 0.)
    require(not np.any(known & raw), 'graph known/unknown proposals disjoint')
    return dict(schema=SCHEMA, labels=labels.astype(np.int8), S=S, A=A, predicted_coarse=coarse,
        known_proposal=known, raw_proposal=raw, local_cost_no_parent=costs,
        local_cost_actual_prior=costs+prior, weak_probabilities=prob, base_unary=base,
        source_unary=source_unary, prior_unary=prior, QQ_left=qq[:, 0], QQ_right=qq[:, 1],
        QQ_probability=pq, QQ_weight=qw, QQ_degree=degree, QQ_weighted_degree=wd,
        QR_query=qr[:, 0], QR_source_original=source_indices[qr[:, 1]], QR_probability=pr, QR_weight=rw,
        source_anchor_indices=source_indices, excluded_source_anchor_groups=gr[~keep],
        native_neighbors=native_neighbors, paper_euclidean_shortlist=shortlist, paper_neighbors=paper_neighbors,
        neighbor_index_convention='kept source rows then canonical query rows',
        native_neighbors_exact_full_search=True, paper_neighbors_are_sparse_shortlist_approximation=True,
        source_anchor_elimination_exact=True, energy_history=inference['energy_history'],
        expansion_moves=inference['moves'], converged=inference['converged'],
        completed_sweeps=inference['completed_sweeps'], accepted_moves=inference['accepted_moves'],
        global_three_label_optimum_claimed=False, inference_seconds=time.perf_counter()-started,
        source_only_evidence_cannot_certify_known=True, query_parameter_fit=False,
        current_truth_used=False, published=False, final_test_executed=False)
