"""Fixed known-only forest on all saved FIT-encoded NSL2 input columns.

No neural training/inference, OPEN inference or UNA consumption. The original
FIT-only ColumnTransformer is reused without fitting; ANOVA-selected columns
are only a replay check, not the auxiliary forest's input restriction.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import io
import json
from pathlib import Path
import time

import joblib
import numpy as np
import sklearn
from sklearn.ensemble import ExtraTreesClassifier

from . import nsl_setting2_capped_known_training_v1 as original

ROOT = Path(__file__).resolve().parents[1]
BASELINE = 'data/external_dev/processed/nsl_setting2_capped_known_training_20261008_v1/NSL_KDD_Setting2/report.json'
BASELINE_SHA = '8bc198594bbc13af3ea597518cea8f393cbdc8cda8bf0c476d8c05f631f1876a'
OUTPUT = ROOT/'data/external_dev/processed/nsl_setting2_capped_known_forest_blend_20261008_v1/NSL_KDD_Setting2'
WEIGHTS = (0., .25, .5, .75)
FOREST_PARAMETERS = dict(n_estimators=256, max_features=1.0, min_samples_leaf=1,
    max_depth=None, bootstrap=False, class_weight='balanced', n_jobs=2, random_state=20261008)
POLICY = dict(schema_version='NSL2-capped-warm-known-full-encoded-forest-blend-v1',
    setting=original.SETTING, datasets_used=['NSL-KDD'], forest_parameters=FOREST_PARAMETERS,
    fixed_weights=WEIGHTS, FIT_original_rows=3471, FIT_optimizer_rows=3505,
    FIT_optimizer_copies=dict(httptunnel=15,xsnoop=19), CP_rows=1216, CAL_rows=1279,
    training_effective_aggregate=6000, input='complete original FIT-only ColumnTransformer output; no variance/ANOVA removal',
    preprocessing_fit_runs=0, feature_names='complete saved transformer get_feature_names_out in exact order',
    original_NN_selected_feature_replay='FIT/CP/CAL saved input arrays must exactly match frozen selector projection; no NN inference',
    actual_tree_dtype='float32 C-order; overflow/nonfinite rejected',
    fit_targets='9 known fine classes, BEN at0, fixed original FIT optimization index map',
    planned_forest_training_runs=1, planned_forest_inference_roles=['CP','CAL'],
    probability_aggregation='fixed256 estimator order float64 sum/256; fit uses2 jobs',
    formula='(1-w)*saved_NN_attack_probability+w*(1-forest_BEN_probability)',
    null_weight0_preserves_original_float32_bytes=True, nonnull_probability_dtype='float64',
    minimum_NN_contribution=.25,
    selection='CP only: both99 integer gates, then max exact Fraction minimum recall, totalcorrect, then smallerweight',
    threshold='same choose_coarse_threshold for each fixed weight; null original threshold reproduced',
    CAL='one forest inference after model/weight/threshold seal; cached NN CAL probability unopened until selectionseal',
    CP_CAL_warm_controls=True, OPEN_inference=False, OPEN_in_selection=False,
    new_NN_training_runs=0, new_NN_inference_runs=0, cross_setting_weights_transferred=False,
    old8324_weights_used=False, UNA_used=False, DEV_executed=False,
    fine_NN_head_and_embedding_unchanged=True, independent_final_admitted=False,
    status='FAIL_TARGET99', published=False, final_test_executed=False, promotion_status='NOT_PROMOTED')
require, checked, descriptor = original.require, original.checked, original.descriptor
sha, array_descriptor, gates, write_json = original.sha, original.array_descriptor, original.gates, original.write_json


def plain(value):
    if isinstance(value,dict):return {str(k):plain(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):return [plain(v) for v in value]
    if isinstance(value,np.generic):return value.item()
    return value


def digest(value):
    return hashlib.sha256(json.dumps(plain(value),sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def pin_json(path,value,pins):
    item=write_json(path,plain(value));pins[item['path']]=item['sha256'];return item


def save_npz(path,pins,**arrays):
    bound={k:array_descriptor(v) for k,v in arrays.items()}
    require(all(np.asarray(v).dtype.kind!='O' for v in arrays.values()),'no_pickle_arrays')
    np.savez_compressed(path,**arrays)
    item=descriptor(path);pins[item['path']]=item['sha256']
    with np.load(io.BytesIO(checked(item,pins)),allow_pickle=False) as z:
        require(set(z.files)==set(arrays) and len(z.files)==len(arrays)
            and all(array_descriptor(z[k])==bound[k]==array_descriptor(v) for k,v in arrays.items()),'saved_live_presave_array_binding')
    return item


def integrity(pins):
    for path,expected in pins.items():require(sha(path)==expected,'pinned_input_changed:'+path)


def _load_registered(pins):
    report=json.loads(checked({'path':BASELINE,'sha256':BASELINE_SHA},pins))
    require(report['execution_status']=='capped_NSL2_warm_known_training_completed'
        and report['metrics_evaluated'] is True and report['training_runs']==1
        and report['configuration']==plain(original.POLICY)
        and report['OPEN_inference'] is False and report['DEV_executed'] is False
        and report['final_test_executed'] is False and report['published'] is False,
        'completed_registered_capped_NSL2_MHFD')
    for raw,expected in report['input_sha256'].items():
        path=Path(raw);path=(path if path.is_absolute() else ROOT/path).resolve()
        require(path.is_relative_to(ROOT) and sha(path)==expected,'original_NN_dependency_changed:'+str(path))
        pins[str(path)]=expected
    prefit=json.loads(checked(report['files']['prefit'],pins))
    source,arrays,frames=original._load_source(prefit['source_report'],pins)
    prep=joblib.load(io.BytesIO(checked(report['files']['preprocessing'],pins)))
    require(set(prep)=={'transformer','variance_mask','selector','selected_feature_names','family_order','source_feature_columns'}
        and tuple(prep['family_order'])==original.FAMILIES
        and tuple(prep['source_feature_columns'])==original.config.NSL_FEATURE_COLUMNS,
        'complete_original_FIT_preprocessing')
    names=np.asarray(prep['transformer'].get_feature_names_out(),dtype=str)
    require(names.ndim==1 and len(names)>=2 and len(set(names.tolist()))==len(names)
        and prep['variance_mask'].dtype==bool and prep['variance_mask'].shape==names.shape,
        'full_encoded_feature_names_and_variance_schema')
    threshold=json.loads(checked(report['files']['threshold'],pins))
    require(threshold['selection_role']=='CP' and threshold['CAL_labels_used'] is False
        and threshold['OPEN_used'] is False and threshold['threshold']==report['coarse_threshold'],
        'original_CP_threshold_provenance')
    return report,source,arrays,frames,prep,names,threshold


def _encode_role(role,frames,arrays,prep,names,old,pins):
    require(role in ('FIT','CP','CAL'),'no_OPEN_or_unknown_encoding')
    before=array_descriptor(frames[role].to_numpy(dtype=str))
    full=np.asarray(prep['transformer'].transform(frames[role]))
    require(full.ndim==2 and full.shape==(original.ALL_ROLES[role],len(names)) and np.isfinite(full).all(),
        'full_frozen_encoded_feature_matrix')
    with np.errstate(over='ignore',invalid='ignore'):
        full=np.array(full,dtype=np.float32,order='C',copy=True)
    require(np.isfinite(full).all(),'encoded_feature_representable_float32')
    selected=prep['selector'].transform(full[:,prep['variance_mask']]).astype(np.float32)
    # Only this role's sealed members are decoded. In particular no CAL NN
    # prediction is decoded during FIT/CP preparation or CP selection.
    with np.load(io.BytesIO(checked(old['files']['training_inputs'],pins)),allow_pickle=False) as z:
        require(array_descriptor(selected)==array_descriptor(z[role+'_features'])
            and array_descriptor(z[role+'_ids'])==array_descriptor(arrays[role+'_ids'])
            and array_descriptor(z[role+'_y_fine'])==array_descriptor(arrays[role+'_y_fine'])
            and array_descriptor(z[role+'_y_coarse'])==array_descriptor(arrays[role+'_y_coarse']),
            'exact_original_NN_feature_projection_and_identity:'+role)
    require(before==array_descriptor(frames[role].to_numpy(dtype=str)),'source_frame_changed_during_encoding')
    return full


def _cached_role(old,arrays,role,pins):
    require(role in ('CP','CAL'),'only_known_control_cached_predictions')
    with np.load(io.BytesIO(checked(old['files']['predictions'],pins)),allow_pickle=False) as z:
        cached={k:z[role+'_'+k].copy() for k in ('ids','truth','fine_truth','probability','prediction')}
    require(array_descriptor(cached['ids'])==array_descriptor(arrays[role+'_ids'])
        and array_descriptor(cached['truth'])==array_descriptor(arrays[role+'_y_coarse'])
        and array_descriptor(cached['fine_truth'])==array_descriptor(arrays[role+'_y_fine']),
        'cached_NN_control_ID_truth_exact:'+role)
    p=cached['probability'];require(p.dtype==np.float32 and p.shape==(original.ALL_ROLES[role],)
        and np.isfinite(p).all() and np.all((p>=0)&(p<=1)),'cached_NN_probability_float32:'+role)
    pred=(p>=old['coarse_threshold']).astype(np.int64);idx=arrays[role+'_reporting_indices']
    require(array_descriptor(pred)==array_descriptor(cached['prediction'])
        and gates(cached['truth'],pred)==old['known_class_gates'][role]
        and gates(cached['truth'][idx],pred[idx])==old['effective_reporting_class_gates'][role],
        'cached_NN_prediction_both_gate_views_exact:'+role)
    return cached


def _new_forest():return ExtraTreesClassifier(**FOREST_PARAMETERS)


def _forest_state(forest,width):
    require(type(forest) is ExtraTreesClassifier and len(forest.estimators_)==256
        and forest.n_features_in_==width and forest.n_outputs_==1
        and np.array_equal(forest.classes_,np.arange(9,dtype=np.int64)), 'complete_dynamic_width_nine_class_forest')
    require(all(forest.get_params(deep=False)[k]==v for k,v in FOREST_PARAMETERS.items()), 'fixed_forest_recipe')
    trees=[]
    for tree in forest.estimators_:
        state={}
        for k,v in tree.tree_.__getstate__().items():
            state[k]=({field:array_descriptor(v[field]) for field in v.dtype.names} if v.dtype.names
                else array_descriptor(v)) if isinstance(v,np.ndarray) else v
        trees.append(dict(parameters=tree.get_params(deep=False),tree_state=state,
            classes=array_descriptor(tree.classes_),n_classes=int(tree.n_classes_)))
    material=dict(parameters=forest.get_params(deep=False),classes=array_descriptor(forest.classes_),
        n_features=int(forest.n_features_in_),n_outputs=int(forest.n_outputs_),trees=trees)
    return dict(state_sha256=digest(material),parameters=material['parameters'],classes=forest.classes_.tolist(),
        tree_count=len(trees),n_features=width,tree_states_sha256=digest(trees))


def _predict_fine(forest,x):
    require(x.dtype==np.float32 and x.ndim==2 and x.shape[1]==forest.n_features_in_ and np.isfinite(x).all(),
        'forest_full_encoded_input')
    require(np.array_equal(forest.classes_,np.arange(9,dtype=np.int64)) and len(forest.estimators_)==256,
        'forest_BEN0_complete9classes')
    p=np.zeros((len(x),9),dtype=np.float64)
    for tree in forest.estimators_:
        require(np.array_equal(tree.classes_,np.arange(9,dtype=np.int64)),'tree_probability_column_identity')
        contribution=np.asarray(tree.predict_proba(x,check_input=False),dtype=np.float64)
        require(contribution.shape==p.shape and np.isfinite(contribution).all()
            and np.all((contribution>=0)&(contribution<=1)),'valid_tree_probability')
        p+=contribution
    p/=256
    require(np.allclose(p.sum(axis=1),1.,rtol=0,atol=1e-12),'normalized_forest_probability')
    return p


def blend(nn,attack,w):
    require(w in WEIGHTS and nn.dtype==np.float32 and attack.dtype==np.float64 and nn.shape==attack.shape,
        'fixed_blend_precision_and_weight')
    return nn.copy() if w==0 else (1-w)*nn.astype(np.float64)+w*attack


def selection_key(entry):
    g=entry['class_gates']
    return (all(v['passed'] for v in g.values()), min(Fraction(v['correct'],v['support']) for v in g.values()),
        sum(v['correct'] for v in g.values()),-entry['weight'])


def paired_view(y,before,after):
    a,b=gates(y,before),gates(y,after)
    delta={c:b[c]['correct']-a[c]['correct'] for c in a};v=list(delta.values())
    verdict='UP' if min(v)>=0 and max(v)>0 else 'DOWN' if max(v)<=0 and min(v)<0 else 'UNCHANGED' if not any(v) else 'MIXED'
    gain=(before!=y)&(after==y);loss=(before==y)&(after!=y)
    return dict(verdict=verdict,correct_delta=delta,baseline_gates=a,candidate_gates=b,
        gain=int(gain.sum()),loss=int(loss.sum()),
        gained_by_class={name:int(gain[y==i].sum()) for name,i in (('BEN',0),('KNA',1))},
        lost_by_class={name:int(loss[y==i].sum()) for name,i in (('BEN',0),('KNA',1))},
        scope='same warm capped known control IDs/order; UNA not evaluated')


def run_blend(*,output_directory=OUTPUT):
    output=Path(output_directory).resolve();require(output.is_relative_to(ROOT) and output!=ROOT,'new_workspace_child')
    output.mkdir(parents=True,exist_ok=False)
    report=dict(configuration=POLICY,status='FAIL_TARGET99',published=False,final_test_executed=False,
        execution_status='not_completed',metrics_evaluated=False,promotion_status='NOT_PROMOTED',
        accepted_baseline_replaced=False,DEV_executed=False,OPEN_inference=False,
        forest_fit_attempted=False,forest_fit_returned=False,forest_training_runs=0,
        forest_inference_roles_started=[],forest_inference_roles_returned=[],forest_inference_roles_completed=[],
        selection_sealed=False,CAL_cached_probability_read_attempted=False,CAL_cached_probability_read_returned=False,
        new_NN_training_runs=0,new_NN_inference_runs=0,preprocessing_fit_runs=0)
    started,stage,pins=time.perf_counter(),'load_registered_capped_NN',{}
    try:
        old,source,arrays,frames,prep,names,old_threshold=_load_registered(pins)
        for p in (Path(__file__),Path(original.__file__),Path(original.source_code.__file__),Path(original.util.__file__),
                Path(original.model.__file__),Path(original.data.__file__),Path(original.config.__file__)):
            pins[str(p.resolve())]=sha(p)
        cp=_cached_role(old,arrays,'CP',pins)
        null_threshold,_=original.model.choose_coarse_threshold(arrays['CP_y_coarse'],cp['probability'])
        require(null_threshold==old['coarse_threshold']
            and array_descriptor(cp['probability'])==old_threshold['CP_probability'],'exact_original_CP_null_threshold')
        stage='freeze_full_encoded_FIT_and_optimization_material'
        fit_original=_encode_role('FIT',frames,arrays,prep,names,old,pins)
        idx=arrays['FIT_optimization_indices']
        fit_x=np.array(fit_original[idx],dtype=np.float32,order='C',copy=True)
        fit_y=np.array(arrays['FIT_y_fine'][idx],dtype=np.int64,copy=True)
        require(fit_original.shape[0]==3471 and len(fit_x)==len(fit_y)==3505,'exact_original_and_optimizer_FIT_rows')
        fit_archive=save_npz(output/'actual_FIT_material_before_fit.npz',pins,
            FIT_full_encoded=fit_original,FIT_optimizer_X=fit_x,FIT_optimizer_y=fit_y,
            FIT_ids=arrays['FIT_ids'],FIT_optimization_indices=idx,full_feature_names=names)
        forest=_new_forest();width=len(names)
        prefit=pin_json(output/'forest_policy_before_fit.json',dict(configuration=POLICY,
            baseline_report={'path':BASELINE,'sha256':BASELINE_SHA},complete_preprocessing=old['files']['preprocessing'],
            complete_forest_parameters=forest.get_params(deep=False),source_files=source['files'],
            full_feature_names=names.tolist(),full_feature_count=width,
            FIT_material=fit_archive,actual_FIT_X=array_descriptor(fit_x),actual_FIT_y=array_descriptor(fit_y),
            original_FIT_encoded=array_descriptor(fit_original),sklearn_version=sklearn.__version__,input_sha256=dict(pins)),pins)
        report.update(prefit=prefit,FIT_material=fit_archive,full_feature_count=width,full_feature_names=names.tolist())
        before=(array_descriptor(fit_x),array_descriptor(fit_y));integrity(pins)
        sealed_prefit=json.loads(checked(prefit,pins))
        require(before==(sealed_prefit['actual_FIT_X'],sealed_prefit['actual_FIT_y'])
            and array_descriptor(fit_original[idx])==before[0]
            and array_descriptor(arrays['FIT_y_fine'][idx])==before[1], 'live_FIT_optimizer_matches_prefit_seal')
        stage='one_fixed_known_FIT_forest_fit';report.update(forest_fit_attempted=True,forest_training_runs=None)
        fit_start=time.perf_counter();forest.fit(fit_x,fit_y);elapsed=time.perf_counter()-fit_start
        report.update(forest_fit_returned=True,forest_training_runs=1,forest_fit_seconds=float(elapsed))
        require(before==(array_descriptor(fit_x),array_descriptor(fit_y)),'FIT_optimizer_inputs_changed')
        stage='freeze_complete_forest_before_CP'
        state=_forest_state(forest,width);model_path=output/'complete_known_forest.joblib'
        joblib.dump(forest,model_path,compress=3);model_item=descriptor(model_path);pins[model_item['path']]=model_item['sha256']
        loaded=joblib.load(io.BytesIO(checked(model_item,pins)))
        require(_forest_state(loaded,width)==state,'full_forest_state_roundtrip');forest=loaded
        proof=pin_json(output/'actual_forest_training_proof.json',dict(training_runs=1,training_role='FIT_only',
            original_rows=3471,optimizer_rows=3505,role_internal_copies=34,fit_seconds=float(elapsed),
            prefit=prefit,actual_X=before[0],actual_y=before[1],model=model_item,state=state),pins)
        report.update(model=model_item,training_proof=proof)
        stage='one_CP_forest_inference'
        cp_x=_encode_role('CP',frames,arrays,prep,names,old,pins);cp_bound=array_descriptor(cp_x)
        report['forest_inference_roles_started'].append('CP');cp_fine=_predict_fine(forest,cp_x)
        report['forest_inference_roles_returned'].append('CP')
        require(array_descriptor(cp_x)==cp_bound and _forest_state(forest,width)==state,'CP_input_and_forest_frozen')
        cp_attack=1-cp_fine[:,0]
        cp_arrays=dict(CP_ids=arrays['CP_ids'],CP_truth=arrays['CP_y_coarse'],CP_fine_truth=arrays['CP_y_fine'],
            original_NN_probability=cp['probability'],baseline_prediction=cp['prediction'],
            CP_full_encoded=cp_x,forest_fine_probability=cp_fine,forest_attack_probability=cp_attack)
        candidates=[]
        for i,w in enumerate(WEIGHTS):
            probability=blend(cp['probability'],cp_attack,w)
            cutoff,metrics=(old['coarse_threshold'],{}) if w==0 else original.model.choose_coarse_threshold(arrays['CP_y_coarse'],probability)
            pred=(probability>=cutoff).astype(np.int64)
            if w==0:require(array_descriptor(pred)==array_descriptor(cp['prediction']),'exact_null_CP_prediction')
            candidates.append(dict(weight=w,threshold=float(cutoff),class_gates=gates(arrays['CP_y_coarse'],pred),
                threshold_metrics=metrics,probability=array_descriptor(probability),prediction=array_descriptor(pred)))
            cp_arrays[f'w{i}_probability']=probability;cp_arrays[f'w{i}_prediction']=pred
        report['forest_inference_roles_completed'].append('CP')
        selected=max(candidates,key=selection_key)
        cp_archive=save_npz(output/'CP_candidates_before_selection.npz',pins,**cp_arrays)
        stage='seal_selected_weight_and_threshold_before_CAL'
        selection=pin_json(output/'selection_before_CAL.json',dict(configuration=POLICY,candidates=candidates,
            selected=selected,model=model_item,model_state=state,CP_candidates=cp_archive,prefit=prefit,
            CAL_cached_probability_opened=False,CAL_forest_inference_executed=False,input_sha256=dict(pins)),pins)
        report.update(selection_sealed=True,selection=selection,selected=selected,CP_candidates=cp_archive)
        integrity(pins);require(_forest_state(forest,width)==state,'forest_frozen_before_CAL')
        stage='single_warm_CAL_inference_after_selection_seal'
        report['CAL_cached_probability_read_attempted']=True
        cal=_cached_role(old,arrays,'CAL',pins);report['CAL_cached_probability_read_returned']=True
        cal_x=_encode_role('CAL',frames,arrays,prep,names,old,pins);cal_bound=array_descriptor(cal_x)
        report['forest_inference_roles_started'].append('CAL');cal_fine=_predict_fine(forest,cal_x)
        report['forest_inference_roles_returned'].append('CAL')
        require(array_descriptor(cal_x)==cal_bound and _forest_state(forest,width)==state,'CAL_input_and_forest_frozen')
        cal_probability=blend(cal['probability'],1-cal_fine[:,0],selected['weight'])
        cal_pred=(cal_probability>=selected['threshold']).astype(np.int64)
        if selected['weight']==0:require(array_descriptor(cal_pred)==array_descriptor(cal['prediction']),'exact_null_CAL_prediction')
        report['forest_inference_roles_completed'].append('CAL')
        cal_archive=save_npz(output/'CAL_pair_after_selection.npz',pins,CAL_ids=arrays['CAL_ids'],
            CAL_truth=arrays['CAL_y_coarse'],CAL_fine_truth=arrays['CAL_y_fine'],CAL_full_encoded=cal_x,
            original_NN_probability=cal['probability'],baseline_prediction=cal['prediction'],
            forest_fine_probability=cal_fine,candidate_probability=cal_probability,candidate_prediction=cal_pred)
        chosen_cp=cp_arrays[f'w{WEIGHTS.index(selected["weight"])}_prediction']
        pairs={};pair_arrays={}
        for role,before_pred,after_pred in (('CP',cp['prediction'],chosen_cp),('CAL',cal['prediction'],cal_pred)):
            y=arrays[role+'_y_coarse'];report_indices=arrays[role+'_reporting_indices']
            pairs[role]=dict(original=paired_view(y,before_pred,after_pred),
                effective_reporting=paired_view(y[report_indices],before_pred[report_indices],after_pred[report_indices]))
            pair_arrays.update({role+'_ids':arrays[role+'_ids'],role+'_truth':y,role+'_baseline_prediction':before_pred,
                role+'_candidate_prediction':after_pred,role+'_reporting_indices':report_indices,
                role+'_gain':(before_pred!=y)&(after_pred==y),role+'_loss':(before_pred==y)&(after_pred!=y)})
        pair_archive=save_npz(output/'same_capped_NN_known_pair.npz',pins,**pair_arrays)
        stage='final_all_pins_and_complete_forest_state'
        integrity(pins);require(_forest_state(forest,width)==state,'final_forest_state')
        passed={r:all(g['passed'] for v in pairs[r].values() for g in v['candidate_gates'].values()) for r in ('CP','CAL')}
        report.update(execution_status='capped_NSL2_warm_known_forest_blend_completed',metrics_evaluated=True,
            CP_candidate_summaries=candidates,CP_candidates=cp_archive,CAL_predictions=cal_archive,
            same_capped_NN_pair=pair_archive,EffectDelta={r:pairs[r]['original'] for r in pairs},
            effective_reporting_EffectDelta={r:pairs[r]['effective_reporting'] for r in pairs},
            selected_CP_class_gates=selected['class_gates'],CAL_class_gates=gates(arrays['CAL_y_coarse'],cal_pred),
            CP_passed=passed['CP'],CAL_passed=passed['CAL'],forest_inference_roles_count=2,
            outcome='UNCHANGED_NULL_POLICY' if selected['weight']==0 else 'KNOWN_CP_CAL_PASS_NOT_UNA_OR_FINAL'
                if all(passed.values()) else 'NO_GO_KNOWN_CLASS_GATE_FAILED',
            full_preprocessing=old['files']['preprocessing'],original_NN_model_not_loaded=old['files']['model'])
    except Exception as exc:
        report.update(execution_status='protocol_stop' if isinstance(exc,
            (original.util.NativeKnownTrainingStop,original.source_code.KnownSourceExtractStop)) else 'execution_failed',
            failed_stage=stage,error_type=type(exc).__name__,error_message=str(exc),outcome='NOT_EVALUATED')
    report.update(input_sha256=pins,wall_seconds=time.perf_counter()-started)
    write_json(output/'report.json',plain(report));return report


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output-directory',default=OUTPUT,type=Path)
    report=run_blend(output_directory=parser.parse_args(argv).output_directory)
    print(json.dumps({k:report.get(k) for k in ('execution_status','outcome','forest_fit_seconds','selected',
        'CAL_class_gates','failed_stage','error_message')},ensure_ascii=False))
    return 0 if report['metrics_evaluated'] else 2 if report['execution_status']=='protocol_stop' else 1


if __name__=='__main__':raise SystemExit(main())
