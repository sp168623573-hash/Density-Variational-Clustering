"""Frozen NSL1 batch predictor whose only query input is forty model fields.

Every retained branch is recomputed. Historical prediction archives, row IDs,
truth and source metadata never enter prediction. All full-feature DVC routes
use numeric canonical ordering, including every historical ID-ordered route.
This declared ordering repair need not reproduce the warmed 2189
forecast. Unlabeled batch composition still affects transductive clustering.
"""
import ast
import hashlib
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
import torch

from .config import NSL_FEATURE_COLUMNS
from .data import sha256_file
from .dvc_geometry_canonical import dvc_route
from .dependence_candidate_paper_dvc import route as plain_candidate_route
from .known_anchor_candidate_dvc import route as anchored_candidate_route
from .known_auth_context_candidate_dvc import route as context_candidate_route
from .known_ben_context_whitened_semantic_views import score as white_score
from .known_ben_hierarchical_context_fallback import score as hierarchy_score
from .known_ben_local_radius_cover import score as radius_score
from .known_ben_whitened_local_reachability import score as reach_score
from .known_ben_joint_whitened_local_reachability import score as joint_score
from .known_ben_whitened_local_density_consensus import score as consensus_score
from .known_ben_content_density_witness import evaluate as witness_evaluate
from .sparse_known_reference_guards import evaluate as sparse_evaluate
from .greedy_known_reference_guards import evaluate as greedy_evaluate
from .known_auth_context_reference_density import evaluate as auth_evaluate
from .known_auth_quorum_reference_density import evaluate as quorum_evaluate
from .model import infer
from .nsl_frozen_category_vocabulary import FrozenCategoryVocabulary


SCHEMA = "nsl1-frozen-feature-only-complete-retained-pipeline-v1"
STATE_KEYS = {"models", "preprocessing", "thresholds", "seed", "references", "fused_calibrator",
              "baseline_profiles", "witness", "content_anchors", "covering", "conditional", "overlays", "context"}
BASELINE_NAMES = ("white", "hierarchy", "radius", "reach", "joint", "consensus")
OVERLAY_NAMES = ("sparse", "greedy", "auth", "quorum")
SERIALIZED_MODULES = ("dvc", "covering_embedding_density", "class_conditional_embedding_density",
                      "known_role_floor_log_development")


def runtime_versions():
    return dict(numpy=np.__version__, pandas=pd.__version__, sklearn=sklearn.__version__, torch=str(torch.__version__))


def inference_source_paths():
    """Conservative transitive local imports, including serialized callables."""
    package = Path(__file__).resolve().parent
    pending = [Path(__file__).resolve(), *(package / (name + ".py") for name in SERIALIZED_MODULES)]
    found = set()
    while pending:
        path = pending.pop()
        if path in found:
            continue
        if not path.is_file():
            raise ValueError("missing local inference dependency: " + str(path))
        found.add(path)
        tree = ast.parse(path.read_text(encoding="utf8"))
        for node in ast.walk(tree):
            names = []
            if isinstance(node, ast.ImportFrom) and node.level == 1:
                names = [node.module] if node.module else [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and (node.module or "").startswith("paper_open_set."):
                names = [node.module.removeprefix("paper_open_set.")]
            elif isinstance(node, ast.Import):
                names = [alias.name.removeprefix("paper_open_set.") for alias in node.names
                         if alias.name.startswith("paper_open_set.")]
            for name in names:
                candidate = package / (name.replace(".", "/") + ".py")
                if candidate.is_file():
                    pending.append(candidate.resolve())
    return tuple(sorted(found))


def state_fingerprint(state):
    """Stable content digest of preprocessing, policies, references and weights.

    Torch storage pickle IDs are excluded; every tensor and module training
    flag is covered explicitly. No files or query data enter this operation.
    """
    digest = hashlib.sha256()
    remaining = {key: value for key, value in state.items() if key != "models"}
    digest.update(joblib.hash(remaining, hash_name="sha1").encode("ascii"))
    for name, model in sorted(state["models"].items()):
        digest.update(name.encode("utf8"))
        for module_name, module in model.named_modules():
            digest.update(repr((module_name, type(module).__module__, type(module).__qualname__, module.training)).encode("utf8"))
        for tensor_name, tensor in sorted(model.state_dict().items()):
            value = tensor.detach().cpu().contiguous().numpy()
            digest.update(repr((tensor_name, value.dtype.str, value.shape)).encode("utf8"))
            digest.update(value.tobytes())
    return digest.hexdigest()


def checked_frame(frame):
    if (not isinstance(frame, pd.DataFrame) or frame.columns.tolist() != list(NSL_FEATURE_COLUMNS)
            or not 0 < len(frame) <= 6000):
        raise ValueError("exactly forty NSL model fields, no truth/ID/metadata, and 1..6000 query rows required")
    result = frame.reset_index(drop=True).copy()
    for name in NSL_FEATURE_COLUMNS[3:]:
        result[name] = pd.to_numeric(result[name], errors="raise")
        if np.isinf(result[name].to_numpy(dtype=np.float64)).any():
            raise ValueError("infinite query model field: " + name)
    return result


def selected_coordinates(state, frame):
    adapter = FrozenCategoryVocabulary(state["preprocessor"])
    encoded = np.asarray(adapter.transform(frame), dtype=np.float32)
    return np.asarray(state["selector"].transform(encoded[:, state["variance_mask"]]), dtype=np.float32)


def validation_tokens(reference_rows, query_rows):
    """Unique local indices satisfy router checks; numeric sorting ignores IDs."""
    return (np.asarray(["reference-row:" + str(i) for i in range(reference_rows)]),
            np.asarray(["query-row:" + str(i) for i in range(query_rows)]))


class FrozenNSLFeaturePipeline:
    def __init__(self, state, manifest):
        if (not isinstance(state, dict) or set(state) != STATE_KEYS
                or manifest.get("schema_version") != SCHEMA
                or manifest.get("query_prediction_archives_used") is not False
                or manifest.get("query_truth_ID_family_source_used") is not False
                or manifest.get("all_full_feature_DVC_numeric_canonical_ordering") is not True
                or manifest.get("published") is not False
                or set(state["baseline_profiles"]) != set(BASELINE_NAMES)
                or set(state["overlays"]) != set(OVERLAY_NAMES)
                or set(state["models"]) != {"original", "log"}
                or set(state["preprocessing"]) != {"original", "log"}
                or set(state["references"]) != {"original", "log"}
                or set(state["thresholds"]) != {"original", "log"}):
            raise ValueError("complete frozen feature-only NSL1 state contract required")
        for name in ("original", "log"):
            reference = np.asarray(state["references"][name])
            if reference.ndim != 2 or not 20 <= len(reference) <= 6000 or not np.isfinite(reference).all():
                raise ValueError("capped finite real known FIT references required")
        self.state, self.manifest = state, manifest
        self._state_digest = manifest.get("state_sha256")
        if not isinstance(self._state_digest, str) or state_fingerprint(state) != self._state_digest:
            raise ValueError("frozen inference state changed")

    def _check_state(self):
        if state_fingerprint(self.state) != self._state_digest:
            raise ValueError("frozen inference state changed")

    def predict_frame(self, frame):
        frame = checked_frame(frame)
        self._check_state()
        state = self.state
        x = {name: selected_coordinates(state["preprocessing"][name], frame)
             for name in ("original", "log")}
        output = {name: infer(state["models"][name], x[name], device=torch.device("cpu"))
                  for name in ("original", "log")}
        coarse = {name: (output[name].attack_probability >= state["thresholds"][name]).astype(np.int64)
                  for name in ("original", "log")}
        primary = (coarse["original"].astype(bool) & coarse["log"].astype(bool)).astype(np.int64)
        reference_ids = {name: validation_tokens(len(state["references"][name]), len(frame))[0]
                         for name in ("original", "log")}
        query_ids = validation_tokens(1, len(frame))[1]
        trace = {}

        def full_route(novelty, representation="log", stage=None, guard=None):
            return dvc_route(primary if stage is None else stage, output[representation], novelty,
                seed=state["seed"], known_reference_features=state["references"][representation],
                query_features=x[representation], known_reference_ids=reference_ids[representation],
                query_ids=query_ids, kna_rejection_guard=guard)

        def complement(name, baseline, raw, retained, manifest, restrict=True):
            mask = np.asarray(raw, dtype=bool) & np.asarray(retained, dtype=bool)
            if restrict:
                mask &= (primary == 0) & (baseline == 0)
            result = baseline.copy()
            result[mask] = 2
            trace[name] = dict(final=result.copy(), added_UNA=mask & (baseline != 2),
                               admitted=mask, DVC=manifest)
            return result

        original_novelty = state["fused_calibrator"].score(x["log"], output["log"], primary)
        fused = full_route(original_novelty)
        final = fused.final_prediction.copy()
        trace["fused"] = dict(final=final.copy(), raw_candidate=original_novelty.candidate.copy(),
                              DVC=fused.dvc_manifest)
        white_novelty, _, supported = white_score(state["baseline_profiles"]["white"], x["log"], primary, original_novelty)
        white = full_route(white_novelty)
        final = complement("white", final, supported, white.final_prediction == 2, white.dvc_manifest)
        # Each historical local branch uses the retained WHITE novelty template;
        # only its prediction union receives the preceding branches' decisions.
        for name, scorer in (("hierarchy", hierarchy_score), ("radius", radius_score),
                             ("reach", reach_score), ("joint", joint_score), ("consensus", consensus_score)):
            novelty, _, _, eligible, _ = scorer(state["baseline_profiles"][name], x["log"], primary, white_novelty)
            routed = full_route(novelty)
            raw = eligible & novelty.candidate if name == "consensus" else eligible
            final = complement(name, final, raw, routed.final_prediction == 2, routed.dvc_manifest)

        def coordinates(policy, values):
            scaler = policy["scaler"]
            return np.column_stack([scaler.transform(output["log"].embedding) / np.sqrt(scaler.n_features_in_),
                                    2 * np.log1p(values["score"])])

        values = witness_evaluate(state["witness"]["profile"], x["log"], primary)
        coords = coordinates(state["witness"], values)
        witness_route = plain_candidate_route(coords, values["raw_candidate"])
        final = complement("witness", final, values["raw_candidate"], witness_route.retained, witness_route.manifest)
        anchored = anchored_candidate_route(coords, values["raw_candidate"], state["content_anchors"])
        final = complement("content_anchors", final, values["raw_candidate"], anchored.retained, anchored.manifest)

        for name in ("covering", "conditional"):
            policy = state[name]
            template = policy["calibrator"].score(x["original"], output["original"], coarse["original"])
            novelty = policy["density"].score(output["original"].embedding, coarse["original"], template)
            routed = full_route(novelty, "original", coarse["original"], policy["density"].kna_guard)
            final = complement(name, final, np.ones(len(frame), dtype=bool), routed.final_prediction == 2,
                               routed.dvc_manifest, restrict=False)

        for name, evaluator in (("sparse", sparse_evaluate), ("greedy", greedy_evaluate),
                                ("auth", auth_evaluate), ("quorum", quorum_evaluate)):
            policy = state["overlays"][name]
            values = evaluator(policy["profile"], x["log"], primary)
            coords = coordinates(policy, values)
            routed = anchored_candidate_route(coords, values["raw_candidate"], policy["anchors"])
            final = complement(name, final, values["raw_candidate"], routed.retained, routed.manifest)
            trace[name].update(score=values["score"].copy(), raw_candidate=values["raw_candidate"].copy())

        values = quorum_evaluate(state["context"]["profile"], x["log"], primary)
        coords = coordinates(state["context"], values)
        routed = context_candidate_route(coords, values["raw_candidate"], x["log"], state["context"]["anchor_policy"])
        final = complement("context", final, values["raw_candidate"], routed.retained, routed.manifest)
        self._check_state()
        return dict(final=final, stage1=primary, original_stage1=coarse["original"], log_stage1=coarse["log"],
            original_model_features=x["original"], log_model_features=x["log"],
            query_coordinates=coords, context_score=values["score"], context_raw_candidate=values["raw_candidate"],
            context_retained=routed.retained, context_supported=routed.supported,
            context_first_cluster=routed.first, context_second_cluster=routed.second, branches=trace,
            protocol=dict(status="FAIL_TARGET99", published=False, final_test_executed=False,
                query_truth_ID_family_source_used=False, query_prediction_archives_used=False,
                full_chain_recomputed_from_query_model_features=True,
                all_historically_ID_ordered_full_feature_routes_repaired_to_numeric=True,
                covering_and_conditional_ordering_repaired_from_ID_to_numeric=True,
                exact_historical_2189_forecast_reproduction_NOT_guaranteed=True,
                transductive_batch_predictor=True, physical_event_independence_verified=False))


def load_pipeline(directory):
    directory = Path(directory).resolve()
    manifest = json.loads((directory / "manifest.json").read_text(encoding="utf8"))
    bundle = directory / "pipeline.joblib"
    sources = manifest.get("inference_source_sha256")
    expected_paths = {str(path) for path in inference_source_paths()}
    if not isinstance(sources, dict) or set(sources) != expected_paths:
        raise ValueError("complete frozen inference dependency mapping required before loading")
    if manifest.get("runtime_versions") != runtime_versions():
        raise ValueError("frozen numeric runtime versions differ; export/review required before loading")
    if sha256_file(bundle) != manifest.get("pipeline_sha256"):
        raise ValueError("frozen pipeline bundle changed")
    for path, digest in sources.items():
        if sha256_file(Path(path)) != digest:
            raise ValueError("frozen inference implementation changed: " + path)
    state = joblib.load(bundle)
    if sha256_file(bundle) != manifest["pipeline_sha256"]:
        raise ValueError("frozen pipeline bundle changed during loading")
    return FrozenNSLFeaturePipeline(state, manifest)
