"""Recover a historical NSL2 known-only split without numeric unknown decoding.

This is a warm metadata recovery, not an admission certificate or a training run.
The old producer did not archive CP/CAL IDs or its code hash. Current pinned
split code is therefore a reconstruction candidate, accepted only against the
old ordered FIT IDs and every available old role statistic. No dtype search,
source substitution, feature inverse transform or model inference is permitted.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import re
import time

import numpy as np
import pandas as pd

from . import config, data

ROOT = Path(__file__).resolve().parents[1]
SETTING = 'NSL-KDD Setting2'
SPEC = config.get_spec(SETTING)
FAMILIES = ('BEN', *SPEC.known_families)
ROLES = ('fit', 'checkpoint', 'calibration', 'open_known')
SEED = 20260921
SOURCE_REL = 'data/NSL-KDD/KDDTrain_Sample.txt'
SOURCE_SHA = '4b2d7010db2ba7a75055448ca786db645df3f0b9cbae0f548d4feb0291f07e3b'
OLD_BASE = 'NSL-KDD Setting2/run/20260923T172840895306Z-4ef971ace9044f81822532629da3c4b5'
MANIFEST_REL = OLD_BASE + '/manifest.json'
AUDIT_REL = OLD_BASE + '/artifacts/data_audit.json'
REFERENCE_REL = OLD_BASE + '/artifacts/known_fit_reference.npz'
PINS = {
    MANIFEST_REL: '7b2deee40fbcbcaa30a6e4a621e771bf6fde74a6da5c3eab218d16a98a532a16',
    AUDIT_REL: '3481752cd8db4ec5c842e2589a25c162790f103f93af9f5f8c9bf52907d0acdb',
    REFERENCE_REL: 'aa9f8d664b8c920541de985f58913cc94b549678256cea110545f76e560db4cd',
    'paper_open_set/data.py': 'a6274758c3940c0f0d7e32e307183a7deeed05bc67b8203c8f16524bac1a0c5c',
    'paper_open_set/config.py': 'a2b5a95cefc550395ba45004f1d036172a03f8b99542c38b0e3ee5ca64c80972',
    'paper_open_set/known_only_data.py': 'e9d5e138d2e5b3395d00771e44363bea7b5731cc73a64ac9a4befb615ba81f0f',
}
OUTPUT = ROOT/'data/external_dev/processed/nsl_setting2_warm_known_role_recovery_20261008_v1'
SCHEMA = 'NSL2-warm-known-role-recovery-v1'
POLICY = {
    'schema_version': SCHEMA, 'setting': SETTING, 'seed': SEED,
    'source': SOURCE_REL, 'source_sha256': SOURCE_SHA,
    'source_schema': '42 columns: legacy NSL_FEATURE_COLUMNS40 + label + difficulty; no duration',
    'label_routing': 'only cell40 UTF8 decoded on every nonblank row; known cells0:40 parsed afterward',
    'CSV_dialect': 'registered simple unquoted comma-delimited records; quoted/multiline records fail closed',
    'pandas_inference': 'one low_memory=False parse on known-only feature40 bytes; no dtype search or retry',
    'fingerprint': 'pinned data._feature_fingerprint: pandas astype(str) then hash_pandas_object index=False uint64',
    'split': 'pinned data._known_role_mapping; validation .20 and open_known .10; preserve source order',
    'acceptance': 'source SHA; old FIT ordered IDs exact; source/role row counts; all old strata; FIT and open family supports',
    'historical_producer_code_digest_available': False,
    'historical_CP_CAL_ID_archives_available': False,
    'CP_CAL_identity_claim': 'deterministic reconstruction with available cross-checks, not direct comparison to missing historical ID archives',
    'unknown_numeric_values_decoded': False, 'source_test_file_opened': False,
    'difficulty_values_decoded': False, 'known_feature_values_saved': False,
    'models_loaded_or_executed': False, 'training_runs': 0, 'DVC_calls': 0,
    'sample_selection_or_role_reassignment': False,
    'family_floor': 20,
    'floor_copy_rule': 'report-only each role: original order then Table1 family order, cyclic original indices; never cross roles',
    'original_dataset_proportions_claimed_for_legacy_Sample': False,
    'future_training_cap': '6000 minus recovered CP/CAL effective20 supports; no FIT sampling performed here',
    'historical_source_exposure': 'already-observed SampleTrain; all old role rows remain known exposures',
    'warm_development_only': True, 'physical_event_independence_verified': False,
    'fresh_controls_claimed': False, 'independent_final_admitted': False,
    'training_admitted_by_this_receipt': False,
    'status': 'FAIL_TARGET99', 'published': False, 'final_test_executed': False,
}


class KnownRoleRecoveryStop(ValueError):
    def __init__(self, message, evidence=None):
        super().__init__(message)
        self.evidence = evidence or {}


def require(ok, reason, evidence=None):
    if not ok:
        raise KnownRoleRecoveryStop(reason, evidence)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(',', ':'), allow_nan=False).encode('utf8')).hexdigest()


def write_new(path, value):
    with Path(path).open('x', encoding='utf8', newline='\n') as handle:
        json.dump(value, handle, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        handle.write('\n')
    return {'path': Path(path).resolve().relative_to(ROOT).as_posix(), 'sha256': sha(path)}


def verify_pins(pins):
    for rel, expected in pins.items():
        require(sha(ROOT/rel) == expected, 'input_pin_mismatch', {'path': rel})


def route_known_feature_bytes(stream, boundary):
    """Do not UTF8-decode or convert features from UNA/EXCLUDED records.

    The opaque complete source is read for SHA and record framing. Splitting a
    bytes line is not numeric parsing. Only known rows enter the pandas buffer.
    Boundary counters are caller-owned so failures do not pretend nothing read.
    """
    metadata, selected = [], io.BytesIO()
    for physical_line, original in enumerate(stream, 1):
        row = original.rstrip(b'\r\n')
        if physical_line == 1 and row.startswith(b'\xef\xbb\xbf'):
            row = row[3:]
        if not row.strip():
            boundary['blank_physical_lines'] += 1
            continue
        ordinal = boundary['source_records_framed']
        boundary['source_records_framed'] += 1
        fields = row.split(b',')
        require(len(fields) == 42, 'source_CSV_width', {'ordinal': ordinal, 'fields': len(fields)})
        require(b'"' not in row, 'unsupported_quoted_CSV_record', {'ordinal': ordinal})
        try:
            label = fields[40].decode('utf8')
        except UnicodeDecodeError as exc:
            raise KnownRoleRecoveryStop('invalid_label_encoding', {'ordinal': ordinal}) from exc
        boundary['label_cells_decoded'] += 1
        normalized = data._normalize_label(SPEC, label)
        scope = data._assign_scope(SPEC, normalized)
        require(scope != 'UNDECLARED', 'undeclared_source_label', {'ordinal': ordinal, 'label': label})
        boundary['scope_rows'][scope] += 1
        if scope not in ('BEN', 'KNA'):
            continue
        feature_bytes = b','.join(fields[:40])
        selected.write(feature_bytes + b'\n')
        metadata.append({'source_record_ordinal_zero_based': ordinal,
            'source_physical_line_one_based': physical_line,
            'source_raw_line_bytes_sha256': hashlib.sha256(original).hexdigest(),
            'raw_model40_field_bytes_sha256': hashlib.sha256(feature_bytes).hexdigest(),
            'original_label': label, 'family': 'BEN' if scope == 'BEN' else normalized,
            'coarse': 0 if scope == 'BEN' else 1})
    require(bool(metadata), 'empty_known_source')
    selected.seek(0)
    return selected, metadata


def initial_boundary():
    return dict(source_records_framed=0, blank_physical_lines=0, label_cells_decoded=0,
        scope_rows={key:0 for key in ('BEN', 'KNA', 'UNA', 'EXCLUDED')},
        known_numeric_parse_attempted=False, known_numeric_parse_completed=False,
        known_feature_rows_parsed=0, unknown_feature_rows_parsed=0,
        difficulty_cells_decoded=0)


def build_known_identity_frame(feature_bytes, records, boundary):
    boundary['known_numeric_parse_attempted'] = True
    frame = pd.read_csv(feature_bytes, names=config.NSL_FEATURE_COLUMNS, header=None,
        low_memory=False, encoding='utf8')
    require(frame.shape == (len(records), 40), 'known_feature40_shape')
    require(not frame.isna().any().any(), 'known_feature40_missing')
    require(all(pd.api.types.is_numeric_dtype(frame[c]) for c in config.NSL_FEATURE_COLUMNS[3:]),
        'known_numeric_dtype_required')
    values = frame.loc[:, config.NSL_FEATURE_COLUMNS[3:]].to_numpy(dtype=np.float64)
    require(np.isfinite(values).all() and (values >= 0).all(), 'known_numeric_nonnegative_finite')
    fingerprints = data._feature_fingerprint(frame, config.NSL_FEATURE_COLUMNS).astype(str).tolist()
    text = frame.loc[:, config.NSL_FEATURE_COLUMNS].astype(str)
    for i, item in enumerate(records):
        item['legacy_model40_group'] = fingerprints[i]
        item['pandas_string_feature_values_sha256'] = digest(text.iloc[i].tolist())
        item['sample_id'] = f"nsl_kdd:source_train:{item['source_record_ordinal_zero_based']}:{fingerprints[i]}"
    require(len({r['sample_id'] for r in records}) == len(records), 'duplicate_source_ID')
    boundary['known_numeric_parse_completed'] = True
    boundary['known_feature_rows_parsed'] = len(records)
    # Numeric values are deliberately not returned or serialized.
    metadata_frame = pd.DataFrame({'_fine_label':[r['family'] for r in records],
        '_fingerprint':fingerprints, '_sample_id':[r['sample_id'] for r in records]})
    return metadata_frame, {c:str(frame[c].dtype) for c in config.NSL_FEATURE_COLUMNS}


def recover_roles(frame, records):
    require(len(frame) == len(records), 'record_identity_length')
    roles, split = data._known_role_mapping(frame, seed=SEED,
        validation_fraction=.20, open_known_fraction=.10)
    result = {role:[] for role in ROLES}
    for item in records:
        role = roles[item['legacy_model40_group']]
        result[role].append({**item, 'role':role})
    require(all(result.values()), 'empty_reconstructed_role')
    for role in ROLES:
        require(set(r['family'] for r in result[role]) == set(FAMILIES),
            'missing_known_family_in_role', {'role':role})
    for i, a in enumerate(ROLES):
        for b in ROLES[i+1:]:
            require(not ({r['legacy_model40_group'] for r in result[a]} &
                {r['legacy_model40_group'] for r in result[b]}), 'cross_role_exact_feature_group')
    return result, split


def family_counts(records):
    c = Counter(r['family'] for r in records)
    return {f:int(c[f]) for f in FAMILIES}


def validate_historical(roles, split, records, boundary, audit, manifest, fit_ids):
    """Save bounded precise differences rather than selecting another replay."""
    problems = {}
    expected = [str(v) for v in fit_ids]
    require(len(expected) == len(set(expected)), 'historical_fit_IDs_not_unique')
    require(all(re.fullmatch(r'nsl_kdd:source_train:\d+:[0-9a-f]{16}', s) for s in expected),
        'historical_fit_ID_schema')
    actual = [r['sample_id'] for r in roles['fit']]
    mismatches = [{'index':i, 'expected':a, 'actual':b}
        for i, (a, b) in enumerate(zip(expected, actual)) if a != b]
    if actual != expected:
        problems['FIT_ordered_IDs'] = {'expected_rows':len(expected), 'actual_rows':len(actual),
            'different_aligned_positions':len(mismatches), 'first_differences':mismatches[:20],
            'expected_only_count':len(set(expected)-set(actual)),
            'actual_only_count':len(set(actual)-set(expected))}
    source_map = {r['source_record_ordinal_zero_based']:r['sample_id'] for r in records}
    source_diffs = [{'expected':s, 'actual':source_map.get(int(s.split(':')[2]))}
        for s in expected if source_map.get(int(s.split(':')[2])) != s]
    if source_diffs:
        problems['FIT_source_fingerprint'] = {'count':len(source_diffs), 'first_differences':source_diffs[:20]}
    observed = {'role_rows':{k:len(v) for k, v in roles.items()},
        'fit_families':family_counts(roles['fit']),
        'source_train_rows':boundary['source_records_framed'],
        'source_train_una_rows_excluded':boundary['scope_rows']['UNA']}
    for key, value in observed.items():
        if value != audit.get(key):
            problems[key] = {'expected':audit.get(key), 'actual':value}
    prior_split = audit['known_role_split']
    for key in ('seed', 'policy', 'fractions', 'strata'):
        if split.get(key) != prior_split.get(key):
            problems['split_'+key] = {'expected':prior_split.get(key), 'actual':split.get(key)}
    open_expected = {f:manifest['known_open_control_family'][f]['support'] for f in FAMILIES}
    if family_counts(roles['open_known']) != open_expected:
        problems['open_known_family_support'] = {'expected':open_expected, 'actual':family_counts(roles['open_known'])}
    require(not problems, 'historical_recovery_mismatch', problems)
    return {'FIT_ordered_IDs_exact':True, 'FIT_source_fingerprints_exact':True,
        'all_available_historical_split_statistics_exact':True,
        'reconstructed_CP_CAL_IDs_independently_compared_to_historical_archive':False,
        'historical_CP_CAL_ID_archive_absent':True,
        'reconstruction_not_proof_of_fresh_physical_independence':True}


def floor_view(records):
    indices = list(range(len(records)))
    counts = family_counts(records)
    copies = {}
    for family in FAMILIES:
        parents = [i for i, r in enumerate(records) if r['family'] == family]
        require(parents, 'no_parent_for_family_floor', {'family':family})
        copies[family] = max(0, 20-len(parents))
        indices.extend(parents[i % len(parents)] for i in range(copies[family]))
    return {'indices':indices, 'original_rows':len(records), 'effective_rows':len(indices),
        'original_family_support':counts, 'copies_by_family':copies,
        'effective_family_support':{f:counts[f]+copies[f] for f in FAMILIES},
        'report_only':True, 'copies_enter_model_or_density':False}


def run(*, output_directory=OUTPUT):
    output = Path(output_directory).resolve()
    require(output.is_relative_to(ROOT/'data/external_dev/processed'), 'output_outside_processed')
    output.mkdir(parents=True, exist_ok=False)
    report = {'schema_version':SCHEMA, **{k:POLICY[k] for k in (
        'setting', 'status', 'published', 'final_test_executed', 'warm_development_only')},
        'execution_status':'started', 'recovery_completed':False,
        'stage':'validate_fixed_inputs', 'boundary':initial_boundary(), 'files':{},
        'source_opaque_hash_completed':False, 'source_record_stream_opened':False,
        'training_runs':0, 'model_inference_runs':0, 'DVC_calls':0,
        'independent_final_admitted':False, 'training_admitted_by_this_receipt':False}
    start = time.perf_counter()
    try:
        pins = {**PINS, Path(__file__).resolve().relative_to(ROOT).as_posix():sha(__file__)}
        verify_pins(pins)
        audit = json.loads((ROOT/AUDIT_REL).read_text(encoding='utf8'))
        manifest = json.loads((ROOT/MANIFEST_REL).read_text(encoding='utf8'))
        require(manifest['setting'] == SETTING and manifest['seed'] == SEED, 'old_run_identity')
        require(audit['source_train_sha256'] == SOURCE_SHA, 'old_source_authority')
        require(audit['role_rows'] == dict(fit=8324, checkpoint=1216, calibration=1279, open_known=1209),
            'registered_old_role_counts')
        with np.load(ROOT/REFERENCE_REL, allow_pickle=False) as z:
            require(set(z.files) == {'x_fit', 'fit_ids'}, 'known_reference_schema')
            fit_ids = z['fit_ids']  # Do not load the old numeric x_fit member.
        require(fit_ids.ndim == 1 and fit_ids.dtype.kind == 'U', 'fit_ID_array_schema')
        require(sha(ROOT/SOURCE_REL) == SOURCE_SHA, 'source_SHA_mismatch')
        report['source_opaque_hash_completed'] = True
        pins[SOURCE_REL] = SOURCE_SHA
        report['input_sha256'] = pins
        report['files']['policy_before_source_records'] = write_new(output/'policy_before_source_records.json',
            {**POLICY, 'input_sha256':pins, 'runtime_versions':{'numpy':np.__version__, 'pandas':pd.__version__},
             'historical_fit_ID_sequence_sha256':digest(fit_ids.tolist())})
        report['stage'] = 'stream_label_route_and_known_identity_parse'
        report['source_record_stream_opened'] = True
        with (ROOT/SOURCE_REL).open('rb') as handle:
            selected, records = route_known_feature_bytes(handle, report['boundary'])
        frame, dtypes = build_known_identity_frame(selected, records, report['boundary'])
        report['known_pandas_dtypes'] = dtypes
        report['stage'] = 'reconstruct_and_compare_historical_roles'
        roles, split = recover_roles(frame, records)
        report['reconstruction_checks'] = validate_historical(roles, split, records,
            report['boundary'], audit, manifest, fit_ids)
        views = {role:floor_view(rows) for role, rows in roles.items()}
        budget = 6000-views['checkpoint']['effective_rows']-views['calibration']['effective_rows']
        require(budget >= len(FAMILIES)*20, 'fixed_controls_leave_no_minimum_FIT_budget')
        payload = {'schema_version':'NSL2-recovered-ordered-warm-known-role-records-v1',
            'source_path':SOURCE_REL, 'source_sha256':SOURCE_SHA, 'known_roles':roles,
            'feature_columns':list(config.NSL_FEATURE_COLUMNS), 'known_role_split':split,
            'floor20_report_views':views, 'historical_known_exposures_all_roles':True,
            'CP_CAL_ID_evidence':'deterministic replay; no separately stored historical CP/CAL ID archive',
            'independent_final_admitted':False, 'known_feature_values_saved':False}
        report['stage'] = 'seal_recovered_metadata_and_recheck_inputs'
        item = write_new(output/'known_source_records.json', payload)
        require(digest(json.loads((ROOT/item['path']).read_text(encoding='utf8'))) == digest(payload),
            'metadata_saved_readback_mismatch')
        report['files']['known_source_records'] = item
        verify_pins(pins)
        report.update(recovery_completed=True, execution_status='known_role_metadata_recovery_completed',
            stage='complete', role_rows={k:len(v) for k,v in roles.items()},
            family_support={k:family_counts(v) for k,v in roles.items()},
            role_unique_groups={k:len({r['legacy_model40_group'] for r in v}) for k,v in roles.items()},
            role_floor20_effective_rows={k:v['effective_rows'] for k,v in views.items()},
            fixed_CP_CAL_effective_rows=6000-budget, maximum_future_effective_FIT_rows=budget,
            current_old_training_aggregate_with_fixed_controls=len(roles['fit'])+6000-budget,
            old_FIT_already_meets_new_cap=False,
            new_FIT_selection_performed=False,
            original_source_proportional_new_FIT_plan_still_required=True,
            final_input_pins_unchanged=True)
    except Exception as exc:
        report['execution_status'] = 'protocol_stop' if isinstance(exc, KnownRoleRecoveryStop) else 'execution_failed'
        report['error'] = {'type':type(exc).__name__, 'message':str(exc)}
        if isinstance(exc, KnownRoleRecoveryStop):
            report['error']['evidence'] = exc.evidence
    report['wall_seconds'] = time.perf_counter()-start
    write_new(output/'report.json', report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-directory', type=Path, default=OUTPUT)
    args = parser.parse_args()
    report = run(output_directory=args.output_directory)
    print(json.dumps({k:report.get(k) for k in ('execution_status','stage','recovery_completed',
        'role_rows','role_floor20_effective_rows','maximum_future_effective_FIT_rows','error')},
        ensure_ascii=False, indent=2))
    return 0 if report['recovery_completed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
