"""Warm metadata-only NSL2 FIT cap with three recovered controls unchanged.

Weights describe the registered legacy Sample known rows, not official physical
event proportions. Unique feature-group capacities limit proportional quotas;
only a family with fewer than20 FIT groups receives optimization copies. The
planner reads no source feature bytes, model, prediction or error information.
"""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import time

from . import nsl_setting2_warm_known_role_recovery_v1 as old

ROOT, SETTING, FAMILIES, ROLES = old.ROOT, old.SETTING, old.FAMILIES, old.ROLES
NAMESPACE = 'nsl-setting2-capped-known-fit-v1-20261008'
CONTROL_ROLES = ('checkpoint', 'calibration', 'open_known')
OLD_BASE = 'data/external_dev/processed/nsl_setting2_warm_known_role_recovery_20261008_v1'
REPORT_REL, RECORDS_REL = OLD_BASE+'/report.json', OLD_BASE+'/known_source_records.json'
OLD_POLICY_REL = OLD_BASE+'/policy_before_source_records.json'
PINS = {
    REPORT_REL:'96a88cc54b9e9175c8868b3109daa8b7b1ae9f456e24383abb4a8c817df09176',
    RECORDS_REL:'d124a52cf842920f6655ce2e5feb38dd8101234afc415e0f2e38cccb0f2491a9',
    OLD_POLICY_REL:'3937ecc9bd4d7fb57dcbfe71160b7aa2e2c798e2ce205e7dbab8ca10bcfc2654',
    'paper_open_set/nsl_setting2_warm_known_role_recovery_v1.py':'be03fd9782dbec4b418b3f4cc156b8966e2cf856771fd25d15fd75170152d2da',
    'paper_open_set/config.py':old.PINS['paper_open_set/config.py'],
}
EXPECTED_WEIGHTS = dict(BEN=9065, httptunnel=236, ipsweep=261, neptune=595,
    nmap=261, portsweep=261, smurf=595, teardrop=595, xsnoop=159)
EXPECTED_FIT_GROUPS = dict(BEN=5554, httptunnel=5, ipsweep=157, neptune=351,
    nmap=157, portsweep=122, smurf=351, teardrop=351, xsnoop=1)
EXPECTED_ROLE_ROWS = dict(fit=8324, checkpoint=1216, calibration=1279, open_known=1209)
OUTPUT = ROOT/'data/external_dev/processed/nsl_setting2_capped_known_fit_plan_20261008_v1'
POLICY = dict(schema_version='NSL2-fixed-controls-capped-known-FIT-plan-v1', setting=SETTING,
    namespace=NAMESPACE, family_order=FAMILIES, aggregate_training_cap=6000,
    fixed_control_effective_rows=dict(checkpoint=1216, calibration=1279),
    FIT_effective_budget=3505, minimum_effective_family_support=20,
    proportion_weights='all12028 registered legacy Sample known rows by family; not official physical-event proportions',
    allocation='exact-rational bounded waterfill with family lower20, upper=max(20,oldFIT unique groups), then largest remainder; ties Table1 family order',
    group_identity='legacy uint64 pandas group plus mandatory equal pandas_string_feature_values_sha256 within every legacy group',
    representative='minimum source_record_ordinal_zero_based within each old FIT group',
    selection='lowest SHA256(namespace + NUL + family + NUL + legacy group); ties group string',
    selected_FIT_order='original source ordinal order of selected group representatives',
    copies='only within FIT for families with fewer20 available groups; cycle selected original indices in source order',
    controls='entire checkpoint/calibration/open_known entries, order and report-floor maps unchanged',
    density='separate earliest-ordinal representative index per group in every role; no optimization/report copy enters density',
    all_old_FIT_and_known_rows_remain_historically_exposed=True,
    discarded_rows_or_groups_reassigned_to_unknown_or_final=False,
    raw_source_opened_or_hashed=False, source_numeric_or_new_label_decoding=False,
    model_predictions_or_errors_accepted=False, training_runs=0, DVC_calls=0,
    historical_CP_CAL_ids_directly_compared_with_old_archive=False,
    warm_development_only=True, fresh_controls_claimed=False,
    physical_independence_verified=False, training_admitted_by_plan_alone=False,
    independent_final_admitted=False, final_test_executed=False,
    status='FAIL_TARGET99', published=False)
sha, digest, write_new = old.sha, old.digest, old.write_new


class CappedKnownFitPlanStop(ValueError):
    pass


def require(ok, reason):
    if not ok:
        raise CappedKnownFitPlanStop(reason)


def fraction(value):
    value = Fraction(value)
    return {'numerator':value.numerator, 'denominator':value.denominator}


def rank(family, group):
    return hashlib.sha256((NAMESPACE+'\0'+family+'\0'+group).encode('utf8')).hexdigest()


def bounded_quotas(weights, capacities, budget):
    """Solve sum clip(lambda*w,20,capacity)=budget exactly, then round."""
    require(set(weights) == set(capacities) == set(FAMILIES), 'exact_known_family_weights_and_capacities')
    require(type(budget) is int and all(type(weights[f]) is int and weights[f] > 0
        and type(capacities[f]) is int and capacities[f] > 0 for f in FAMILIES), 'positive_integer_allocation_inputs')
    lower = {f:20 for f in FAMILIES}
    upper = {f:max(20, capacities[f]) for f in FAMILIES}
    require(sum(lower.values()) <= budget <= sum(upper.values()), 'infeasible_effective_budget')
    def targets_at(lam):
        return {f:min(Fraction(upper[f]), max(Fraction(lower[f]), lam*weights[f])) for f in FAMILIES}
    points = sorted({Fraction(0), *(Fraction(lower[f], weights[f]) for f in FAMILIES),
        *(Fraction(upper[f], weights[f]) for f in FAMILIES)})
    targets = None
    for i, point in enumerate(points):
        current = targets_at(point)
        total = sum(current.values())
        if total == budget:
            targets = current
            break
        if i+1 < len(points) and total < budget < sum(targets_at(points[i+1]).values()):
            midpoint = (point+points[i+1])/2
            active = [f for f in FAMILIES if lower[f] < midpoint*weights[f] < upper[f]]
            fixed = sum(v for f,v in targets_at(midpoint).items() if f not in active)
            lam = (Fraction(budget)-fixed)/sum(weights[f] for f in active)
            targets = targets_at(lam)
            break
    require(targets is not None and sum(targets.values()) == budget, 'exact_waterfill_solution')
    quotas = {f:targets[f].numerator//targets[f].denominator for f in FAMILIES}
    order = sorted(FAMILIES, key=lambda f:(-(targets[f]-quotas[f]), FAMILIES.index(f)))
    for f in order[:budget-sum(quotas.values())]:
        quotas[f] += 1
    require(sum(quotas.values()) == budget and all(lower[f] <= quotas[f] <= upper[f] for f in FAMILIES),
        'bounded_rounding_invariant')
    total_weight = sum(weights.values())
    return {'effective_rows':budget, 'quotas':quotas,
        'per_family':{f:{'legacy_source_known_rows':weights[f], 'available_old_FIT_feature_groups':capacities[f],
            'lower_effective':lower[f], 'upper_effective':upper[f],
            'unconstrained_proportional_ideal':fraction(Fraction(budget*weights[f], total_weight)),
            'bounded_target':fraction(targets[f]), 'effective_quota':quotas[f],
            'selected_group_count':min(capacities[f], quotas[f]),
            'optimization_copies':max(0, quotas[f]-capacities[f]),
            'quota_minus_unconstrained_ideal':fraction(Fraction(quotas[f])-Fraction(budget*weights[f],total_weight)),
            'percentage_point_deviation':fraction(100*(Fraction(quotas[f],budget)-Fraction(weights[f],total_weight)))}
            for f in FAMILIES}}


def control_bindings(recovered):
    return {r:{'ordered_records_sha256':digest(recovered['known_roles'][r]),
        'floor20_report_view_sha256':digest(recovered['floor20_report_views'][r])} for r in CONTROL_ROLES}


def validate_recovered(recovered):
    require(recovered.get('schema_version') == 'NSL2-recovered-ordered-warm-known-role-records-v1'
        and recovered.get('source_path') == old.SOURCE_REL
        and recovered.get('source_sha256') == old.SOURCE_SHA
        and tuple(recovered.get('feature_columns', ())) == old.config.NSL_FEATURE_COLUMNS
        and recovered.get('known_feature_values_saved') is False
        and recovered.get('independent_final_admitted') is False,
        'recovered_source_contract')
    require(set(recovered['known_roles']) == set(ROLES), 'exact_four_roles')
    seen_ids, seen_ordinals, group_role, group_strong, group_family = set(), set(), {}, {}, {}
    for role in ROLES:
        rows = recovered['known_roles'][role]
        require(bool(rows), 'empty_recovered_role')
        previous = -1
        for row in rows:
            ordinal, group, family = row['source_record_ordinal_zero_based'], row['legacy_model40_group'], row['family']
            strong = row['pandas_string_feature_values_sha256']
            require(type(ordinal) is int and ordinal > previous and ordinal not in seen_ordinals
                and row['role'] == role and family in FAMILIES
                and type(row['coarse']) is int and row['coarse'] == int(family != 'BEN')
                and re.fullmatch('[0-9a-f]{16}', group) is not None
                and re.fullmatch('[0-9a-f]{64}', strong) is not None,
                'source_order_role_family_or_identity_schema')
            require(row['sample_id'] == f'nsl_kdd:source_train:{ordinal}:{group}'
                and row['sample_id'] not in seen_ids, 'source_sample_ID_binding')
            require(group_role.setdefault(group, role) == role, 'old_cross_role_group_overlap')
            require(group_strong.setdefault(group, strong) == strong, 'legacy_group_has_conflicting_strong_feature_hash')
            require(group_family.setdefault(group, family) == family, 'legacy_group_has_conflicting_known_family')
            seen_ids.add(row['sample_id']); seen_ordinals.add(ordinal); previous = ordinal
        require(set(row['family'] for row in rows) == set(FAMILIES), 'role_missing_declared_known_family')
        require(recovered['floor20_report_views'][role] == old.floor_view(rows), 'original_floor_view_binding')
    return group_strong


def density_indices(rows):
    seen, result = set(), []
    for i, row in enumerate(rows):
        group = row['legacy_model40_group']
        if group not in seen:
            seen.add(group); result.append(i)
    return result


def build_plan(recovered):
    """Pure metadata operation; no source/model/score interfaces are accepted."""
    all_group_strong = validate_recovered(recovered)
    controls_before = control_bindings(recovered)
    old_roles = recovered['known_roles']
    weights_counter = Counter(row['family'] for rows in old_roles.values() for row in rows)
    weights = {f:int(weights_counter[f]) for f in FAMILIES}
    budget = 6000-sum(recovered['floor20_report_views'][r]['effective_rows']
        for r in ('checkpoint','calibration'))
    representatives = {}
    for row in old_roles['fit']:
        representatives.setdefault(row['legacy_model40_group'], row)
    capacities = {f:sum(row['family'] == f for row in representatives.values()) for f in FAMILIES}
    allocation = bounded_quotas(weights, capacities, budget)
    selected = []
    for f in FAMILIES:
        candidates = sorted((row for row in representatives.values() if row['family'] == f),
            key=lambda r:(rank(f,r['legacy_model40_group']),r['legacy_model40_group']))
        selected.extend(candidates[:allocation['per_family'][f]['selected_group_count']])
    selected.sort(key=lambda r:r['source_record_ordinal_zero_based'])
    selected = deepcopy(selected)
    new_roles = {'fit':selected, **{r:deepcopy(old_roles[r]) for r in CONTROL_ROLES}}
    new_views = {'fit':old.floor_view(selected),
        **{r:deepcopy(recovered['floor20_report_views'][r]) for r in CONTROL_ROLES}}
    require(new_views['fit']['effective_rows'] == budget
        and new_views['fit']['effective_family_support'] == allocation['quotas'], 'FIT_effective_allocation_copy_binding')
    plan_view = {'known_roles':new_roles, 'floor20_report_views':new_views}
    require(control_bindings(plan_view) == controls_before, 'fixed_controls_changed')
    densities = {r:density_indices(rows) for r, rows in new_roles.items()}
    fit_ids = {row['sample_id'] for row in selected}
    fit_groups = {row['legacy_model40_group'] for row in selected}
    old_fit_groups = {row['legacy_model40_group'] for row in old_roles['fit']}
    historical_ids = sorted(row['sample_id'] for rows in old_roles.values() for row in rows)
    unselected = [row['sample_id'] for row in old_roles['fit'] if row['sample_id'] not in fit_ids]
    return {'schema_version':'NSL2-fixed-controls-capped-known-FIT-role-plan-v1',
        'configuration':deepcopy(POLICY), 'source_path':recovered['source_path'],
        'source_sha256':recovered['source_sha256'], 'feature_columns':deepcopy(recovered['feature_columns']),
        'family_order':list(FAMILIES), 'known_roles':new_roles, 'floor20_report_views':new_views,
        'legacy_known_source_row_weights':weights, 'allocation':allocation,
        'fit_optimization_indices':deepcopy(new_views['fit']['indices']),
        'fit_reporting_indices':deepcopy(new_views['fit']['indices']),
        'role_density_representative_indices':densities,
        'density_uses_optimization_or_report_copies':False,
        'role_summary':{r:{'source_records':len(rows),
            'unique_feature_groups':len(densities[r]), 'effective_reporting_rows':new_views[r]['effective_rows'],
            'source_family_support':old.family_counts(rows),
            'unique_family_support':old.family_counts([rows[i] for i in densities[r]]),
            'report_copy_count':new_views[r]['effective_rows']-len(rows)} for r,rows in new_roles.items()},
        'controls_before':controls_before, 'controls_after':control_bindings(plan_view),
        'selected_FIT_group_ranks':{r['legacy_model40_group']:rank(r['family'],r['legacy_model40_group']) for r in selected},
        'selected_FIT_group_count':len(fit_groups), 'FIT_optimization_rows':budget,
        'training_effective_aggregate':budget+sum(new_views[r]['effective_rows'] for r in ('checkpoint','calibration')),
        'old_FIT_source_rows':len(old_roles['fit']), 'old_FIT_feature_groups':len(old_fit_groups),
        'unselected_old_FIT_source_IDs_still_exposed':unselected,
        'unselected_old_FIT_groups_still_exposed':sorted(old_fit_groups-fit_groups),
        'historical_all_known_source_IDs':historical_ids,
        'historical_all_known_source_IDs_sha256':digest(historical_ids),
        'historical_all_known_groups_with_strong_hash':dict(sorted(all_group_strong.items())),
        'historical_exposure_count':len(historical_ids),
        'CP_CAL_ID_evidence':recovered['CP_CAL_ID_evidence'],
        'source_record_numeric_extraction_performed':False, 'training_admitted_by_plan_alone':False,
        'warm_development_only':True, 'independent_final_admitted':False,
        'status':'FAIL_TARGET99', 'published':False, 'final_test_executed':False}


def run(*, output_directory=OUTPUT):
    output = Path(output_directory).resolve()
    require(output.is_relative_to(ROOT/'data/external_dev/processed'), 'output_outside_processed')
    output.mkdir(parents=True, exist_ok=False)
    report = {'schema_version':POLICY['schema_version'], 'setting':SETTING,
        'status':'FAIL_TARGET99', 'published':False, 'final_test_executed':False,
        'warm_development_only':True, 'planning_completed':False, 'execution_status':'started',
        'stage':'verify_fixed_metadata', 'files':{}, 'raw_source_opened_or_hashed':False,
        'training_runs':0, 'model_inference_runs':0, 'DVC_calls':0,
        'source_numeric_extraction_performed':False, 'training_admitted_by_plan_alone':False,
        'independent_final_admitted':False}
    started = time.perf_counter()
    try:
        pins = {**PINS, Path(__file__).resolve().relative_to(ROOT).as_posix():sha(__file__)}
        for path, expected in pins.items():
            require(sha(ROOT/path) == expected, 'fixed_input_pin_mismatch:'+path)
        previous = json.loads((ROOT/REPORT_REL).read_text(encoding='utf8'))
        recovered = json.loads((ROOT/RECORDS_REL).read_text(encoding='utf8'))
        require(previous['recovery_completed'] is True and previous['final_input_pins_unchanged'] is True
            and previous['reconstruction_checks']['FIT_ordered_IDs_exact'] is True
            and previous['role_rows'] == EXPECTED_ROLE_ROWS
            and previous['files']['known_source_records'] == {'path':RECORDS_REL,'sha256':PINS[RECORDS_REL]},
            'successful_registered_recovery_required')
        report['input_sha256'] = pins
        report['inherited_source_sha256_not_rehashed'] = {old.SOURCE_REL:old.SOURCE_SHA}
        report['files']['policy_before_group_selection'] = write_new(output/'policy_before_group_selection.json',
            {**POLICY, 'input_sha256':pins, 'expected_legacy_weights':EXPECTED_WEIGHTS,
                'expected_old_FIT_group_capacities':EXPECTED_FIT_GROUPS})
        report['stage'] = 'plan_fixed_controls_and_capped_FIT_groups'
        plan = build_plan(recovered)
        require(plan['legacy_known_source_row_weights'] == EXPECTED_WEIGHTS
            and {f:plan['allocation']['per_family'][f]['available_old_FIT_feature_groups'] for f in FAMILIES} == EXPECTED_FIT_GROUPS,
            'registered_known_weight_and_capacity_binding')
        require(plan['FIT_optimization_rows'] == 3505 and plan['selected_FIT_group_count'] == 3471
            and plan['training_effective_aggregate'] == 6000 and plan['historical_exposure_count'] == 12028
            and plan['floor20_report_views']['fit']['copies_by_family'] == {f:15 if f=='httptunnel' else 19 if f=='xsnoop' else 0 for f in FAMILIES},
            'anticipated_cap_and_copy_counts_required')
        report['stage'] = 'seal_plan_and_verify_metadata_stability'
        descriptor = write_new(output/'known_role_plan.json', plan)
        require(digest(json.loads((ROOT/descriptor['path']).read_text(encoding='utf8'))) == digest(plan),
            'saved_plan_value_binding')
        report['files']['known_role_plan'] = descriptor
        for path, expected in pins.items():
            require(sha(ROOT/path) == expected, 'final_input_pin_mismatch:'+path)
        report.update(planning_completed=True, execution_status='capped_known_FIT_metadata_plan_completed',
            stage='complete', final_input_pins_unchanged=True, role_summary=plan['role_summary'],
            allocation=plan['allocation'], selected_FIT_group_count=3471,
            FIT_optimization_rows=3505, FIT_optimization_copies=34, training_effective_aggregate=6000,
            known_open_original_rows=1209, known_open_reporting_rows=1213,
            historical_all_known_rows_still_exposed=12028,
            unselected_old_FIT_source_rows_still_exposed=len(plan['unselected_old_FIT_source_IDs_still_exposed']),
            unselected_old_FIT_groups_still_exposed=len(plan['unselected_old_FIT_groups_still_exposed']),
            controls_exactly_preserved=True)
    except Exception as exc:
        report['execution_status'] = 'protocol_stop' if isinstance(exc, CappedKnownFitPlanStop) else 'execution_failed'
        report['error'] = {'type':type(exc).__name__, 'message':str(exc)}
    report['wall_seconds'] = time.perf_counter()-started
    write_new(output/'report.json', report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-directory', type=Path, default=OUTPUT)
    args = parser.parse_args()
    report = run(output_directory=args.output_directory)
    print(json.dumps({k:report.get(k) for k in ('execution_status','planning_completed','stage',
        'selected_FIT_group_count','FIT_optimization_rows','training_effective_aggregate','error')}, ensure_ascii=False, indent=2))
    return 0 if report['planning_completed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
