"""ROOT-only projected149 cached-geometry increment above immutable2596.

One new known-only residual projection/owned Eq9/10 state, reference/R7 and
CAL cuts. Existing117 weights, embedding units, raw149 geometry and genuine
MAIN35e coarse/fine outputs are immutable. No NN inference is repeated.
Known654 paired zero loss and integer99 gate precede one current cached
score/DVC. Prediction seal precedes truth; no independent/final claim.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import time
import numpy as np
from . import nsl1_expandedaux149_entry_v1 as vanilla
from . import nsl1_projection149_pair_metric_v1 as learned

files,ROOT,producer,owned_dvc,paper_route = vanilla.files,vanilla.ROOT,vanilla.producer,vanilla.owned_dvc,vanilla.paper_route
archive,descriptor,metric_kwargs = vanilla.archive,vanilla.descriptor,vanilla.metric_kwargs
make_reference,fit_radii,scores,route_once,merge,delta = vanilla.make_reference,vanilla.fit_radii,vanilla.scores,vanilla.route_once,vanilla.merge,vanilla.delta
SCHEMA='NSL1-preserved2596-FIT6000-projected149-cached-geometry-v1'
BASE=ROOT/'data/external_dev/processed/nsl1_projection149_20261010_v1'
CONTROL_PREPARED=dict(path=str(vanilla.BASE/'prepare/report.json'),sha256='0aca0bf765b86e0db55b4c612eb65085967c68f0187a2060054348e6f023f3d3')
CONTROL_KNOWN=dict(path=str(vanilla.BASE/'known/report.json'),sha256='81f5718a360775e16dac5c87db44d92f20e7c691786574c254e05e7b21837605')
CONTROL_CURRENT=dict(path=str(vanilla.BASE/'current/report.json'),sha256='408cc7997fb75d7720b287d43e6ca527c1a6cea571bf940f673735bdb0a696c4')

def recipe():
    return dict(schema_version=SCHEMA,setting='NSL-KDD Setting1',width=149,FIT_original_rows=6000,
        inherited_geometry='same real frozen117 embedding32/full encoded117, existing FIT embedding units',
        primary='same genuine cached MAIN35e predictedfine/coarse for CAL,known and current',
        intervention='FIT-only rank16 identity-residual projection before otherwise identical Eq9/10 distance',
        projection='A=I+UV^T; initial U zero, V independently seeded thin QR; exact constant FIT residual rows masked0, identity axis retained',
        objective='same known pair loss/margin2 + .01||A-I||_F^2, no /d and no triplet',
        policy_before_any_fit=True,new_old_metric_state_loaded=False,unit_refit=0,new_NN_training=0,new_NN_inference=0,
        parameter_fit_roles=['FIT'],CAL='one known656 PRIMARY-coarse finite99 strictgreater',
        R7='new same-fine other unique FIT radius under same new projected149 metric',
        DVC='same new projected149 candidate/centre/secondary distances; original affinity/noise',
        raw_geometry_projected_in_entry=False,projection_applied_once_inside_metric=True,
        known_gate='supplement immutable2596 known-prefix; zero paired BEN/KNA loss and integer99 before current scoring',
        merge='copy complete2596; own current raw AND own same-metric DVC-retained =>UNA only',
        extension_not_exact_original_coordinate_formula=True,current_scope='already observed original3598 DEV',
        row_or_label_selection_by_DEV=False,unknown_in_parameter_fit=False,
        original2579_and2596_immutable=True,arbitrary_new_final_asset_reads=False,
        published=False,final_test_executed=False,independent_final=False,accepted_baseline_replaced=False,status='FAIL_TARGET99')

def freeze():
    pins={}
    prepared,known,current=(files.js(a,pins) for a in (CONTROL_PREPARED,CONTROL_KNOWN,CONTROL_CURRENT))
    vr=files.js(current['registry'],pins)
    files.require(prepared['registry']==known['registry']==current['registry']
        and known['known_gate_passed'] is True
        and current['EffectDelta']['verdict']=='UNCHANGED'
        and current['original_class_gates']['UNA']['correct']==2596
        and current['prediction_sealed'] is True,'completed vanilla149 controlled unchanged scope')
    assets=dict(prepared_material=prepared['prepared_material'],reused_units=prepared['files']['units'],
        query_geometry=current['files']['actual_current149_geometry_before_score'],
        baseline_and_truth_after_seal=vr['assets']['baseline_and_truth_after_seal'],
        known_truth_after_seal=vr['assets']['known_truth_after_seal'])
    headers={name:producer.metadata_headers(a,pins) for name,a in assets.items() if Path(a['path']).suffix=='.npz'}
    files.require(headers['prepared_material']['fit_Z149']['shape']==[6000,149]
        and headers['prepared_material']['calibration_Z149']['shape']==[656,149]
        and headers['prepared_material']['open_known_Z149']['shape']==[654,149]
        and headers['query_geometry']['Z149']['shape']==[3598,149]
        and headers['query_geometry']['predicted_fine']['shape']==[3598], 'exact same real cached149 geometry headers')
    for a in assets.values():files.read(a,pins)
    sources={Path(m.__file__).name:files.item(m.__file__) for m in
        (vanilla,learned,learned.inherited,producer,owned_dvc,paper_route,paper_route.sealed,files)}
    sources['caller']=files.item(__file__)
    files.require(sources[Path(learned.inherited.__file__).name]['sha256']==learned.MATH_SOURCE_SHA256,
        'unchanged unprojected numerical provenance; no fitted old metric load')
    for a in vr['sources'].values():files.read(a,pins)
    reg=dict(schema_version=SCHEMA+'-registry',policy=recipe(),assets=assets,headers=headers,sources=sources,
        controlled_prepared=CONTROL_PREPARED,controlled_known=CONTROL_KNOWN,controlled_current=CONTROL_CURRENT,
        controlled_registry=current['registry'],controlled_material_descriptors=prepared['material_descriptors'],
        reused_unit_state_sha256=prepared['unit_state_sha256'],
        output={p:str(BASE/p) for p in ('prepare','known','current')},
        input_sha256=pins,published=False,final_test_executed=False,status='FAIL_TARGET99')
    reg['registry_sha256']=files.digest(reg)
    out=ROOT/'tmp/nsl1_projection149_20261010_v1';out.mkdir(exist_ok=True)
    return files.write(out/'registry_before_projected_known_parameters.json',reg)

def bind(path, sha, pins):
    a = dict(path=str(Path(path).resolve()),sha256=sha)
    reg = files.js(a,pins);unsigned = dict(reg); signature = unsigned.pop('registry_sha256')
    files.require(signature == files.digest(unsigned) and reg['policy'] == recipe()
        and reg['sources']['caller'] == files.item(__file__), 'own new149 registry/source/recipe')
    for item in reg['sources'].values(): files.read(item,pins)
    for p,h in reg['input_sha256'].items(): files.read(dict(path=p,sha256=h),pins)
    return a,reg

def start(reg, phase, registry):
    out = Path(reg['output'][phase])
    files.require(out == BASE/phase and not out.exists(),'fresh once-only new149 phase:'+phase)
    out.mkdir(parents=True)
    report = dict(schema_version=SCHEMA,phase=phase,registry=registry,policy=recipe(),files={},
        counts=dict(NN_retraining=0,primary_forward=0,auxiliary_unknown_forward=0,
            unit_fit=0,metric_fit=0,FIT_radius_fit=0,CAL_score=0,CAL_fit=0,query_score=0,DVC_calls=0),
        execution_status='not_completed',prediction_sealed=False,known_truth_opened=False,
        unknown_truth_opened=False,accepted_baseline_replaced=False,
        published=False,final_test_executed=False,source_admitted=False,status='FAIL_TARGET99')
    return out,report

def save(out,report,name,values):
    return producer.save(out,name,values,report)

def finish(out,report,pins,started):
    for p,h in pins.items(): files.require(files.item(p)['sha256'] == h,'all frozen source/input bytes unchanged')
    report['input_sha256'] = pins;report['wall_seconds'] = time.perf_counter()-started
    return files.write(out/'report.json',report)

def prepare(path,sha):
    started,pins=time.perf_counter(),{}
    registry,reg=bind(path,sha,pins);out,report=start(reg,'prepare',registry)
    try:
        material=archive(reg['assets']['prepared_material'],tuple(reg['controlled_material_descriptors']),pins)
        save(out,report,'cached_unprojected_known149_before_new_prefit',material)
        files.require({k:descriptor(v) for k,v in material.items()}==reg['controlled_material_descriptors'],
            'same byte-value known geometry; projection not pre-applied')
        prefit=learned.prefit_descriptor(material['fit_Z149'],material['fit_fine'],**metric_kwargs(material))
        pfa=files.write(out/'projection149_FIT_only_pair_plan_before_parameter_fit.json',prefit)
        report['files']['metric_prefit']=pfa;report['files']['units']=reg['assets']['reused_units']
        seal=files.write(out/'cached149_reused_unit_new_projection_prefit_seal.json',dict(registry=registry,
            material=reg['assets']['prepared_material'],units=reg['assets']['reused_units'],new_prefit=pfa,
            metric_fit_executed=False,unknown_geometry_in_plan=False,old_metric_state_loaded=False))
        report.update(execution_status='new_projection149_cached_known_material_prefit_sealed',
            prepared_material=reg['assets']['prepared_material'],material_descriptors=reg['controlled_material_descriptors'],
            metric_prefit_sha256=prefit['prefit_sha256'],transform_seal=seal,
            reused_unit_state_sha256=reg['reused_unit_state_sha256'],new_units_fit=0)
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally: result=finish(out,report,pins,started)
    return result

def load_prepared(registry,reg,path,sha,pins):
    a = dict(path=str(Path(path).resolve()),sha256=sha);prepared = files.js(a,pins)
    files.require(a['path'] == str(Path(reg['output']['prepare'])/'report.json')
        and prepared['registry'] == registry and prepared['execution_status'] == 'new_projection149_cached_known_material_prefit_sealed',
        'exact new149 external known preparation')
    material = archive(prepared['prepared_material'],tuple(prepared['material_descriptors']),pins)
    files.require({k:descriptor(v) for k,v in material.items()} == prepared['material_descriptors'],'unchanged externally prepared known149')
    return a,prepared,material

def known(path,sha,preparation_path,preparation_sha):
    started,pins = time.perf_counter(),{}
    registry,reg = bind(path,sha,pins);pa,prepared,material = load_prepared(registry,reg,preparation_path,preparation_sha,pins)
    out,report = start(reg,'known',registry);report['preparation'] = pa
    before_runtime=producer.capture_runtime_flags();report['runtime_before']=before_runtime
    try:
        pfa = prepared['files']['metric_prefit'];prefit = files.js(pfa,pins)
        report['counts']['metric_fit'] = 1
        metric = learned.fit_known_metric(material['fit_Z149'],material['fit_fine'],expected_prefit_sha256=prefit['prefit_sha256'],**metric_kwargs(material))
        met_a = files.write(out/'owned149_metric_state_before_CAL_or_query.json',metric.to_state());report['files']['metric'] = met_a
        metric = learned.PaperVariationalPairMetric.from_state(files.js(met_a,pins))
        files.require(metric.dimension == 149 and metric.to_state()['prefit_descriptor'] == prefit,'new149 persisted FIT-only metric, no old state')
        reference = make_reference(material);ref_a = save(out,report,'unique_genuine_FIT149_reference_before_radius',reference)
        report['files']['reference'] = ref_a;report['counts']['FIT_radius_fit'] = 1
        radii = fit_radii(metric,reference,lambda label,v:save(out,report,'FIT_fine'+str(label)+'_returned_distances',v))
        rad_a = save(out,report,'FIT149_radii_before_CAL',dict(radii=radii));report['files']['radii'] = rad_a
        radseal = files.write(out/'FIT149_reference_radius_seal_before_CAL.json',dict(metric=met_a,reference=ref_a,radii=rad_a,FIT_only=True,query_used=False))
        report['files']['radius_seal'] = radseal
        report['counts']['CAL_score'] = 1
        cal_score = scores(metric,material['calibration_Z149'],material['calibration_predicted_fine'],reference,radii,
            lambda label,v:save(out,report,'CAL_fine'+str(label)+'_returned_distances',v))
        save(out,report,'CAL149_scores_before_cutoffs',dict(score=cal_score,stage1=material['calibration_stage1']))
        cut = paper_route.calibrate_known_cutoffs(cal_score,material['calibration_stage1'])
        cut_a = files.write(out/'knownCAL656_149_cutoffs_before_OPEN654.json',dict(cutoffs=cut,radius_seal=radseal,query_used=False,original_CAL_rows=656))
        report['files']['calibration'] = cut_a;cut = files.js(cut_a,pins)['cutoffs'];report['counts']['CAL_fit'] = 1
        query = dict(Z149=material['open_known_Z149'],groups=material['open_known_groups'],stage1=material['open_known_stage1'])
        report['counts']['query_score'] = 1
        score = scores(metric,query['Z149'],material['open_known_predicted_fine'],reference,radii,
            lambda label,v:save(out,report,'OPEN_fine'+str(label)+'_returned_distances',v))
        raw = paper_route.candidate_mask(score,query['stage1'],cut)
        save(out,report,'known654_scores_raw_before_DVC',dict(score=score,raw=raw,stage1=query['stage1']))
        def sink(name,v,manifest):
            save(out,report,'known654_'+name+'_DVC_before_guard',v)
            report['files']['route_'+name] = files.write(out/('known654_'+name+'_DVC_manifest.json'),manifest)
        report['counts']['DVC_calls'] = 1
        route,_ = route_once(metric,query,raw,sink)
        # Fixed original prefix is bound by custody IDs, not by label lookup.
        ids = archive(reg['assets']['query_geometry'],('ids',),pins)['ids']
        files.require(np.array_equal(ids[:654],material['open_known_ids']),'original654 known prefix before numerical query features')
        baseline = archive(reg['assets']['baseline_and_truth_after_seal'],('fresh_increment',),pins)['fresh_increment'][:654]
        prediction = merge(baseline,raw,route['retained'])
        pred_a = save(out,report,'complete_known654_increment_before_truth',dict(ids=material['open_known_ids'],prediction=prediction,baseline=baseline,raw=raw,retained=route['retained']))
        seal = files.write(out/'known654_prediction_seal_before_truth.json',dict(prediction=pred_a,registry=registry,metric=met_a,CAL=cut_a,truth_opened=False))
        report['files']['prediction_seal'] = seal;files.js(seal,pins);report['prediction_sealed'] = True
        truth = archive(reg['assets']['known_truth_after_seal'],('open_known_ids','open_known_known_coarse'),pins)
        report['known_truth_opened'] = True
        files.require(np.array_equal(truth['open_known_ids'],material['open_known_ids']),'same original known654 truth custody')
        y = truth['open_known_known_coarse'];effect,current,prior = delta(y,prediction,baseline)
        paired_ok = all(effect['gain_loss'][name]['loss'] == 0 for name in ('BEN','KNA'))
        integer_ok = all(v['passed'] for v in current.values())
        save(out,report,'postseal_known654_comparison',dict(ids=material['open_known_ids'],truth=y,prediction=prediction,baseline=baseline,raw=raw,retained=route['retained']))
        report.update(execution_status='new_projection149_known_no_loss_gate_evaluated',original_class_gates=current,
            baseline_class_gates=prior,EffectDelta=effect,paired_known_no_loss=paired_ok,known_integer99_passed=integer_ok,
            known_gate_passed=paired_ok and integer_ok,known_raw=int(raw.sum()),known_retained=int(route['retained'].sum()),
            metric_state_sha256=metric.state_sha256,current_unknown_feature_decodes=0,unknown_inference=0,
            parameter_fit_scope='new true FIT6000 and knownCAL656 only',primary_classification_unchanged=True)
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        restored=producer.restore_runtime_flags(before_runtime)
        report['runtime_restoration']=dict(before=before_runtime,after=restored,all_flags_restored=restored==before_runtime)
        result = finish(out,report,pins,started)
    return result

def current(path,sha,known_path,known_sha):
    started,pins=time.perf_counter(),{}
    registry,reg=bind(path,sha,pins)
    ka=dict(path=str(Path(known_path).resolve()),sha256=known_sha);kr=files.js(ka,pins)
    files.require(ka['path']==str(Path(reg['output']['known'])/'report.json') and kr['registry']==registry
        and kr['execution_status']=='new_projection149_known_no_loss_gate_evaluated'
        and kr['known_gate_passed'] is True,'known integer99 and zero loss before current cached score')
    _,_,material=load_prepared(registry,reg,kr['preparation']['path'],kr['preparation']['sha256'],pins)
    out,report=start(reg,'current',registry);report['known_report']=ka
    before_runtime=producer.capture_runtime_flags();report['runtime_before']=before_runtime
    try:
        query=archive(reg['assets']['query_geometry'],('ids','groups','Z149','stage1','predicted_fine'),pins)
        save(out,report,'same_cached_original3598_raw149_before_new_metric_score',query)
        files.require(query['Z149'].shape==(3598,149) and len(set(query['ids'].tolist()))==3598
            and np.array_equal(query['ids'][:654],material['open_known_ids'])
            and np.array_equal(query['Z149'][:654],material['open_known_Z149'])
            and np.array_equal(query['stage1'][:654],material['open_known_stage1'])
            and np.array_equal(query['predicted_fine'][:654],material['open_known_predicted_fine']),
            'same immutable real149 known prefix and original MAIN semantics')
        metric=learned.PaperVariationalPairMetric.from_state(files.js(kr['files']['metric'],pins))
        reference=archive(kr['files']['reference'],('Z149','known_fine_membership','ids','groups','original_indices'),pins)
        radii=archive(kr['files']['radii'],('radii',),pins)['radii'];cut=files.js(kr['files']['calibration'],pins)['cutoffs']
        report['counts']['query_score']=1
        score=scores(metric,query['Z149'],query['predicted_fine'],reference,radii,
            lambda label,v:save(out,report,'current_fine'+str(label)+'_new_projected_distances',v))
        raw=paper_route.candidate_mask(score,query['stage1'],cut)
        save(out,report,'projected149_current_scores_raw_before_DVC',dict(score=score,raw=raw,stage1=query['stage1']))
        def sink(name,v,manifest):
            save(out,report,'projected_current3598_'+name+'_DVC_before_guard',v)
            report['files']['route_'+name]=files.write(out/('projected_current3598_'+name+'_DVC_manifest.json'),manifest)
        report['counts']['DVC_calls']=1;route,_=route_once(metric,query,raw,sink)
        baseline=archive(reg['assets']['baseline_and_truth_after_seal'],('fresh_increment',),pins)['fresh_increment']
        prediction=merge(baseline,raw,route['retained'])
        pred_a=save(out,report,'complete_projected149_increment_before_truth',
            dict(ids=query['ids'],prediction=prediction,baseline=baseline,raw=raw,retained=route['retained']))
        seal=files.write(out/'projected149_prediction_seal_before_truth.json',dict(prediction=pred_a,registry=registry,
            metric=kr['files']['metric'],CAL=kr['files']['calibration'],known_gate_report=ka,truth_opened=False))
        report['files']['prediction_seal']=seal;files.js(seal,pins);report['prediction_sealed']=True
        truth=archive(reg['assets']['baseline_and_truth_after_seal'],('ids','truth'),pins)
        report['unknown_truth_opened']=True
        files.require(np.array_equal(truth['ids'],query['ids']),'same original3598 truth custody after prediction seal')
        effect,new_gates,prior=delta(truth['truth'],prediction,baseline,full=True)
        save(out,report,'postseal_projected149_same3598_comparison',dict(**truth,prediction=prediction,baseline=baseline,raw=raw,retained=route['retained']))
        paired_ok=all(effect['gain_loss'][name]['loss']==0 for name in ('BEN','KNA'))
        report.update(execution_status='projected149_preserved2596_current3598_evaluated',original_class_gates=new_gates,
            baseline_class_gates=prior,EffectDelta=effect,paired_known_no_loss=paired_ok,
            all_three_integer99_passed=all(v['passed'] for v in new_gates.values()),
            DEV_review_eligible=effect['verdict']=='UP' and paired_ok,
            known_raw=int(raw[:654].sum()),known_retained=int(route['retained'][:654].sum()),
            unknown_raw=int(raw[654:].sum()),unknown_retained=int(route['retained'][654:].sum()),
            metric_state_sha256=metric.state_sha256,new_parameter_fit_in_current=0,
            NN_replay=0,raw_geometry_preprojected=False,independent_unknown_DEV_measured=False)
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        restored=producer.restore_runtime_flags(before_runtime)
        report['runtime_restoration']=dict(before=before_runtime,after=restored,all_flags_restored=restored==before_runtime)
        result=finish(out,report,pins,started)
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=('freeze','prepare','known','current'),required=True)
    parser.add_argument('--registry');parser.add_argument('--registry-sha256')
    parser.add_argument('--preparation-report');parser.add_argument('--preparation-sha256')
    parser.add_argument('--known-report');parser.add_argument('--known-sha256');args=parser.parse_args()
    if args.phase=='freeze':result=freeze()
    elif args.phase=='prepare':result=prepare(args.registry,args.registry_sha256)
    elif args.phase=='known':result=known(args.registry,args.registry_sha256,args.preparation_report,args.preparation_sha256)
    else:result=current(args.registry,args.registry_sha256,args.known_report,args.known_sha256)
    print(json.dumps(result))
