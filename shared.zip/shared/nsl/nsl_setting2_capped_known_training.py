"""One capped NSL2 known-only MHFD run; historical warm controls, no OPEN inference."""
from __future__ import annotations

import argparse
from collections import Counter
import io
import json
import os
from pathlib import Path
import time

import joblib
import numpy as np
from sklearn.feature_selection import SelectKBest, f_classif
import torch

from . import config, data, model
from . import nsl_setting2_capped_known_source_extract_v1 as source_code
from . import cic2017_setting2_known_fit_coverage_training_v1 as util

ROOT = Path(__file__).resolve().parents[1]
SETTING = 'NSL-KDD Setting2'
SPEC = config.get_spec(SETTING)
FAMILIES = ('BEN', *SPEC.known_families)
ALL_ROLES = {'FIT': 3471, 'CP': 1216, 'CAL': 1279, 'OPEN': 1209}
MODEL_ROLES = ('FIT', 'CP', 'CAL')
SEED, EPOCHS = 20261008, 80
FIT_QUOTA = dict(BEN=2700, httptunnel=20, ipsweep=78, neptune=177, nmap=78,
                 portsweep=78, smurf=177, teardrop=177, xsnoop=20)
require, sha, descriptor = util.require, util.sha, util.descriptor
checked, write_json, array_descriptor, gates = util._checked, util._write, util.array_descriptor, util._gates
POLICY = dict(schema_version='NSL2-capped-warm-known-MHFD-v1', setting=SETTING,
    datasets_used=['NSL-KDD'], source_schema='legacy40 without duration',
    original_role_rows=ALL_ROLES, FIT_optimizer_rows=3505, training_side_effective_total=6000,
    original_FIT_groups=3471, FIT_copies=34, copies_by_family={'httptunnel':15,'xsnoop':19},
    minimum_effective_family_support=20, source_proportions='registered Sample known rows with unique-group capacity floors; deviations in plan',
    physical_original_dataset_proportions_claimed=False,
    preprocessing='FIT original3471 only: original categorical encoder/numeric imputer/scaler; variance and ANOVA top50',
    model='unchanged MHFDNetwork/train_model', epochs=EPOCHS, seed=SEED,
    checkpoint='1216 original CP only; known coarse/fine checkpoint selection',
    threshold='same1216 CP only, sealed before CAL inference', CAL_rows=1279,
    OPEN_inference=False, OPEN_rows_in_fit_or_selection=0, UNA_rows_in_fit_or_selection=0,
    density_copy_rows=0, historical_parent_flow_authority_resolved=False,
    warm_development_only=True, old_CP_CAL_ID_evidence='deterministic reconstruction; old explicit ID archive absent',
    new_model_from_seed=True, weights_transferred=False, independent_final_admitted=False,
    training_runs_planned=1, final_test_executed=False, published=False)


def _check_indices(arrays, role):
    n = ALL_ROLES[role]
    fine = arrays[role+'_y_fine']
    expected = list(range(n))
    for fi in range(len(FAMILIES)):
        parents = np.flatnonzero(fine == fi).tolist()
        require(parents, 'positive_family_parent:'+role)
        expected.extend(parents[i % len(parents)] for i in range(max(0, 20-len(parents))))
    index = arrays[role+'_reporting_indices']
    require(index.dtype == np.int64 and np.array_equal(index, np.asarray(expected, np.int64)),
            'exact_role_internal_reporting_copies:'+role)
    if role == 'FIT':
        require(np.array_equal(index, arrays['FIT_optimization_indices']) and len(index) == 3505,
                'FIT_3471_plus34_optimizer_mapping')
        require(Counter(arrays['FIT_families'][index].tolist()) == FIT_QUOTA, 'exact_FIT_effective_family_quota')
    else:
        require(len(index) == n + (4 if role == 'OPEN' else 0), 'fixed_control_report_rows:'+role)


def _validate(arrays, records, schema):
    require(set(arrays) == source_code.expected_members(), 'exact49_known_source_arrays')
    require(records['schema_version'] == 'NSL2-capped-warm-ordered-known-source-records-v1'
        and records['setting'] == SETTING and tuple(records['family_order']) == FAMILIES
        and records['warm_development_only'] is True
        and records['physical_parent_flow_authority_resolved'] is False
        and set(records['roles']) == set(ALL_ROLES), 'declared_warm_known_records')
    require(schema['role_original_rows'] == ALL_ROLES and tuple(schema['feature_columns']) == config.NSL_FEATURE_COLUMNS,
            'exact_legacy40_role_schema')
    seen_ids, seen_groups = set(), set()
    for role, n in ALL_ROLES.items():
        ids, groups = arrays[role+'_ids'], arrays[role+'_groups']
        fine, coarse = arrays[role+'_y_fine'], arrays[role+'_y_coarse']
        require(ids.shape == groups.shape == fine.shape == coarse.shape == (n,)
            and ids.dtype.kind == groups.dtype.kind == 'U'
            and fine.dtype == coarse.dtype == np.int64
            and np.all((fine >= 0) & (fine < len(FAMILIES)))
            and np.array_equal(coarse, (fine != 0).astype(np.int64)), 'typed_known_role:'+role)
        require(len(set(ids.tolist())) == n and not seen_ids.intersection(ids.tolist())
            and not seen_groups.intersection(groups.tolist()), 'cross_role_identity_or_group_leakage:'+role)
        seen_ids.update(ids.tolist()); seen_groups.update(groups.tolist())
        rows = records['roles'][role]
        require(len(rows) == n, 'ordered_record_count:'+role)
        for i, row in enumerate(rows):
            require(row['sample_id'] == ids[i] and row['legacy_model40_group'] == groups[i]
                and row['family'] == FAMILIES[int(fine[i])] == arrays[role+'_families'][i]
                and row['coarse'] == coarse[i]
                and row['pandas_string_feature_values_sha256'] == arrays[role+'_strong_feature_sha256'][i]
                and row['source_record_ordinal_zero_based'] == arrays[role+'_source_ordinals'][i],
                'ordered_source_identity_label_binding:'+role)
        expected_density = []
        local = set()
        for i, group in enumerate(groups):
            if str(group) not in local:
                expected_density.append(i); local.add(str(group))
        require(np.array_equal(arrays[role+'_density_representative_indices'], np.asarray(expected_density, np.int64)),
                'first_group_representative_density_indices:'+role)
        if role == 'FIT':
            require(len(local) == n, 'FIT_originals_are_unique_groups')
        _check_indices(arrays, role)
    require(len(arrays['FIT_optimization_indices']) + ALL_ROLES['CP'] + ALL_ROLES['CAL'] == 6000,
            'effective_training_side_cap')


def _load_source(item, pins):
    report = json.loads(checked(item, pins))
    require(report.get('schema_version') == 'NSL2-capped-warm-known-source-extract-v1'
        and report.get('execution_status') == 'known_source_extraction_completed'
        and report.get('source_extraction_completed') is True
        and report.get('all_input_pins_stable') is True
        and report.get('warm_development_only') is True
        and report['boundary']['unknown_feature_rows_parsed'] == 0
        and report.get('status') == 'FAIL_TARGET99' and report.get('published') is False
        and report.get('final_test_executed') is False, 'completed_capped_warm_known_source_required')
    for raw, expected in report['input_sha256'].items():
        path = Path(raw)
        path = (path if path.is_absolute() else ROOT/path).resolve()
        require(path.is_relative_to(ROOT) and sha(path) == expected, 'source_dependency_changed:'+str(path))
        pins[str(path)] = expected
    files = report['files']
    with np.load(io.BytesIO(checked(files['known_roles_archive'], pins)), allow_pickle=False) as z:
        arrays = {k:z[k].copy() for k in z.files}
    records = json.loads(checked(files['ordered_source_records'], pins))
    schema = json.loads(checked(files['feature_schema'], pins))
    _validate(arrays, records, schema)
    frames = {}
    for role in MODEL_ROLES:
        frames[role] = source_code.restore_frame(arrays, role, schema)
        source_code.verify_role_frame(frames[role], records['roles'][role])
    return report, arrays, frames


def _prepare(arrays, frames):
    require(set(frames) == set(MODEL_ROLES), 'no_OPEN_or_unknown_preprocessing')
    transformer = data._build_preprocessor(SPEC)
    x = {'FIT':np.asarray(transformer.fit_transform(frames['FIT']), dtype=np.float32)}
    for role in ('CP','CAL'):
        x[role] = np.asarray(transformer.transform(frames[role]), dtype=np.float32)
    variance = np.var(x['FIT'], axis=0) > 0
    require(int(variance.sum()) >= 2, 'nonconstant_known_FIT_features')
    selector = SelectKBest(f_classif, k=min(50, int(variance.sum())))
    features = {'FIT':selector.fit_transform(x['FIT'][:,variance], arrays['FIT_y_fine']).astype(np.float32)}
    for role in ('CP','CAL'):
        features[role] = selector.transform(x[role][:,variance]).astype(np.float32)
    require(all(np.isfinite(v).all() and len(v) == ALL_ROLES[r] for r,v in features.items()), 'finite_known_features')
    names = np.asarray(transformer.get_feature_names_out())[variance][selector.get_support()].tolist()
    return features, dict(transformer=transformer, variance_mask=variance, selector=selector,
        selected_feature_names=names, family_order=FAMILIES, source_feature_columns=config.NSL_FEATURE_COLUMNS)


def run_training(*, source_report, output_directory):
    out = Path(output_directory).resolve()
    require(out.is_relative_to(ROOT) and out != ROOT, 'workspace_child_output')
    out.mkdir(parents=True, exist_ok=False)
    start, stage, pins = time.perf_counter(), 'validate_known_source', {}
    report = dict(configuration=POLICY, status='FAIL_TARGET99', published=False, final_test_executed=False,
        training_started=False, training_completed=False, training_runs=0, metrics_evaluated=False,
        OPEN_inference=False, DEV_executed=False, accepted_baseline_replaced=False,
        runtime_environment={'CUBLAS_WORKSPACE_CONFIG':os.environ.get('CUBLAS_WORKSPACE_CONFIG')},
        known_inference_roles_started=[], known_inference_roles_returned=[], coarse_threshold_sealed=False,
        EffectDelta={'verdict':'NOT_COMPARABLE','reason':'first capped model; no historical ordered prediction archive'})
    try:
        source, arrays, frames = _load_source(source_report, pins)
        for path in (Path(__file__), Path(source_code.__file__), Path(util.__file__), Path(model.__file__), Path(data.__file__), Path(config.__file__)):
            pins[str(path.resolve())] = sha(path)
        stage = 'original_FIT_only_preprocessing'
        features, prep = _prepare(arrays, frames)
        prep_path = out/'complete_FIT_preprocessing.joblib'
        joblib.dump(prep, prep_path, compress=3)
        prep_item = descriptor(prep_path); pins[prep_item['path']] = prep_item['sha256']
        loaded = joblib.load(io.BytesIO(checked(prep_item, pins)))
        for role in MODEL_ROLES:
            x = np.asarray(loaded['transformer'].transform(frames[role]), dtype=np.float32)
            replay = loaded['selector'].transform(x[:,loaded['variance_mask']]).astype(np.float32)
            require(array_descriptor(replay) == array_descriptor(features[role]), 'complete_preprocessing_roundtrip:'+role)
        material = {r+'_features':x for r,x in features.items()}
        material.update({r+'_'+k:arrays[r+'_'+k] for r in MODEL_ROLES for k in ('ids','y_coarse','y_fine','reporting_indices')})
        material['FIT_optimization_indices'] = arrays['FIT_optimization_indices']
        material_bound = {k:array_descriptor(v) for k,v in material.items()}
        input_path = out/'exact_known_inputs_before_fit.npz'
        np.savez_compressed(input_path, **material)
        input_item = descriptor(input_path); pins[input_item['path']] = input_item['sha256']
        with np.load(io.BytesIO(checked(input_item,pins)), allow_pickle=False) as z:
            require(set(z.files) == set(material) and all(array_descriptor(z[k]) == material_bound[k]
                and array_descriptor(v) == material_bound[k] for k,v in material.items()),
                    'saved_live_training_material_binding')
        prefit = write_json(out/'training_policy_before_fit.json', dict(configuration=POLICY,
            source_report=source_report, preprocessing=prep_item, known_inputs=input_item,
            runtime_environment=report['runtime_environment'], feature_descriptors={r:array_descriptor(x) for r,x in features.items()},
            selected_feature_names=prep['selected_feature_names'], input_sha256=dict(pins),
            optimizer_X=array_descriptor(features['FIT'][arrays['FIT_optimization_indices']]),
            CP_rows=1216, CAL_used_for_selection=False, OPEN_features_used=False))
        pins[prefit['path']] = prefit['sha256']
        stage = 'one_known_MHFD_training'
        torch.set_num_threads(4); index = arrays['FIT_optimization_indices']
        report.update(training_started=True, training_runs=None)
        result = model.train_model(features['FIT'][index], arrays['FIT_y_coarse'][index], arrays['FIT_y_fine'][index],
            features['CP'], arrays['CP_y_coarse'], fine_class_count=len(FAMILIES), epochs=EPOCHS, seed=SEED,
            progress_label='NSL2 capped known', checkpoint_fine_labels=arrays['CP_y_fine'])
        report.update(training_completed=True, training_runs=1, training_seconds=float(result.training_seconds),
            selected_epoch=int(result.selected_epoch), device=result.device)
        stage = 'freeze_selected_model'
        state = {k:v.detach().cpu() for k,v in result.model.state_dict().items()}
        model_path = out/'selected_MHFD_state.pt'
        torch.save(dict(state_dict=state, input_dim=features['FIT'].shape[1], fine_class_count=len(FAMILIES),
            selected_epoch=result.selected_epoch, seed=SEED), model_path)
        restored = torch.load(model_path, map_location='cpu', weights_only=True)
        require(set(restored['state_dict']) == set(state) and all(torch.equal(v,restored['state_dict'][k]) for k,v in state.items()),
                'selected_model_exact_roundtrip')
        model_item = descriptor(model_path); pins[model_item['path']] = model_item['sha256']
        outputs = {}
        for role in ('FIT','CP','CAL'):
            stage = 'known_inference_'+role
            if role == 'CAL':
                threshold, metrics = model.choose_coarse_threshold(arrays['CP_y_coarse'], outputs['CP'].attack_probability)
                threshold_item = write_json(out/'coarse_threshold_from_known_CP.json', dict(threshold=float(threshold),
                    selection_role='CP', model=model_item, CP_probability=array_descriptor(outputs['CP'].attack_probability),
                    metrics=metrics, CAL_labels_used=False, OPEN_used=False))
                pins[threshold_item['path']] = threshold_item['sha256']; report['coarse_threshold_sealed'] = True
            report['known_inference_roles_started'].append(role)
            outputs[role] = model.infer(result.model, features[role], device=torch.device(result.device))
            report['known_inference_roles_returned'].append(role)
        stage = 'sealed_known_predictions_and_integer_gates'
        pred_arrays, original_gates, reporting_gates = {}, {}, {}
        for role, values in outputs.items():
            n = ALL_ROLES[role]; probability = values.attack_probability
            require(probability.shape == (n,) and np.isfinite(probability).all() and np.all((probability>=0)&(probability<=1))
                and values.fine_probability.shape == (n,len(FAMILIES)) and np.isfinite(values.fine_probability).all()
                and values.embedding.shape[0] == n and np.isfinite(values.embedding).all()
                and values.reconstruction_error.shape == (n,) and np.isfinite(values.reconstruction_error).all(), 'finite_known_outputs:'+role)
            pred = (probability >= threshold).astype(np.int64)
            original_gates[role] = gates(arrays[role+'_y_coarse'], pred)
            index = arrays[role+'_reporting_indices']
            reporting_gates[role] = gates(arrays[role+'_y_coarse'][index], pred[index])
            pred_arrays.update({role+'_ids':arrays[role+'_ids'], role+'_truth':arrays[role+'_y_coarse'],
                role+'_fine_truth':arrays[role+'_y_fine'], role+'_prediction':pred,
                role+'_probability':probability, role+'_fine_probability':values.fine_probability,
                role+'_embedding':values.embedding, role+'_reconstruction_error':values.reconstruction_error})
        pred_bound = {k:array_descriptor(v) for k,v in pred_arrays.items()}
        pred_path = out/'post_training_known_predictions.npz'; np.savez_compressed(pred_path, **pred_arrays)
        predictions = descriptor(pred_path); pins[predictions['path']] = predictions['sha256']
        with np.load(io.BytesIO(checked(predictions,pins)), allow_pickle=False) as z:
            require(set(z.files) == set(pred_arrays) and all(array_descriptor(z[k]) == pred_bound[k]
                and array_descriptor(v) == pred_bound[k] for k,v in pred_arrays.items()), 'sealed_prediction_archive_live_binding')
        history = write_json(out/'training_history.json', result.history); pins[history['path']] = history['sha256']
        stage = 'final_input_and_output_pins'
        for path, expected in pins.items():
            require(sha(path) == expected, 'pinned_input_changed:'+path)
        report.update(execution_status='capped_NSL2_warm_known_training_completed', metrics_evaluated=True,
            known_class_gates=original_gates, effective_reporting_class_gates=reporting_gates,
            coarse_threshold=float(threshold), CP_CAL_passed=all(g['passed'] for view in (original_gates,reporting_gates)
                for role in ('CP','CAL') for g in view[role].values()),
            files=dict(prefit=prefit, preprocessing=prep_item, training_inputs=input_item, model=model_item,
                threshold=threshold_item, predictions=predictions, history=history))
    except Exception as exc:
        report.update(execution_status='protocol_stop' if isinstance(exc,(util.NativeKnownTrainingStop,source_code.KnownSourceExtractStop)) else 'execution_failed',
            failed_stage=stage, error_type=type(exc).__name__, error_message=str(exc))
    report.update(input_sha256=pins, wall_seconds=time.perf_counter()-start)
    write_json(out/'report.json',report)
    return report


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-report', required=True); p.add_argument('--source-report-sha256', required=True)
    p.add_argument('--output-directory', required=True)
    a = p.parse_args(argv)
    r = run_training(source_report={'path':a.source_report,'sha256':a.source_report_sha256}, output_directory=a.output_directory)
    print(json.dumps({k:r.get(k) for k in ('execution_status','training_seconds','known_class_gates','failed_stage','error_message')},ensure_ascii=False))
    return 0 if r['metrics_evaluated'] else 2 if r['execution_status']=='protocol_stop' else 1


if __name__ == '__main__':
    raise SystemExit(main())
