from pathlib import Path
import os,sys,importlib.util
for k in('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='2'
os.environ['CUDA_VISIBLE_DEVICES']='-1'
import numpy as np
import torch
torch.set_num_threads(2)
H=Path(__file__).resolve().parent;I=H.parents[1];ROOT=I.parent;R18=I/'candidate_flow_20261031_r18/nsl2'
s=importlib.util.spec_from_file_location('r21_R18',R18/'common.py');Base=importlib.util.module_from_spec(s);sys.modules[s.name]=Base;s.loader.exec_module(Base)
M=Base.M;STATUS=M.STATUS;A=Base.A
Clean=M.mod(I/'paper_core_continuation_20261030_r12/materialize_clean_inputs.py','r21_inputs')
Adapter=M.mod(I/'target99_v950_20261023/nsl2/nsl2_adapter_v950.py','r21_original_nn')

def save(p,**kw):
    with Path(p).open('xb')as f:np.savez_compressed(f,**{k:v for k,v in kw.items()if isinstance(v,np.ndarray)and not v.dtype.hasobject})
    return M.desc(p)

def role_data(role):
    q=Base.role_data(role);p=R18/'actual_once/restored_risk'/(role+'-predict/prediction_before_truth.npz')
    with np.load(p,allow_pickle=False)as a:assert np.array_equal(a['ids'],q['ids']);q['parent']=a['prediction']
    q['R18_parent_ref']=M.desc(p);q['role']=role
    source=Base.R10/'actual_once'/('current-predict' if role=='current' else 'known-predict')/(role+'_scores.npz')
    with np.load(source,allow_pickle=False) as a:
        assert np.array_equal(a['ids'],q['ids'])
        q['head_unknown']=a['head_certificate'];q['hard_OOD']=a['tangent_hard_OOD']
    return q
