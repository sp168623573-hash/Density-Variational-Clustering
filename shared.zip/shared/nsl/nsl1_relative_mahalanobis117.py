"""One canonical knownfine Relative Mahalanobis cue on actualall41 native117.

RMD = min_fine MDwithin - MDbackground. Exactexisting149 geometry/DVC reused.
"""
import argparse,inspect,json,sys,time
from pathlib import Path
import numpy as np
import sklearn
from sklearn.covariance import OAS
from threadpoolctl import threadpool_limits
from . import nsl1_nativecell_clean149_v62 as old
from . import artifact_api_preflight_v52 as preflight

ROOT,files,base=old.ROOT,old.files,old.base
MODULE='paper_open_set.nsl1_relative_mahalanobis117_v80'
BASE=ROOT/'data/external_dev/processed/nsl1_relative_mahalanobis117_20261012_v80'
REG=ROOT/'tmp/nsl1_relative_mahalanobis117_20261012_v80/registry_before_RMD117_known.json'
OLD_KNOWN=dict(path=str(old.BASE/'known/report.json'),sha256='08474405119159398012fe694aec6478ec2b3295a231825da9f576c99e92e333')
BASELINE=dict(path=str(old.BASE/'current/report.json'),sha256='eb3a15953d98d0e5a142cca0b3504b4683f546d225301f63491374783299f0da')

def policy():
    return dict(schema_version='NSL1-singlefine9-relativeMahalanobis-native117-matching149-v80',hypotheses=1,
        formula='min actualknownfine0..8 (x-meanfine)^T tiedWithinOAS_precision(x-meanfine) minus globalOAS backgroundMD; high meansunknown, raw signedscore not clipped',
        reference='Ren et al 2021 A Simple Fix to Mahalanobis Distance for Improving Near-OOD Detection Eq3',source='https://www.gatsby.ucl.ac.uk/~balaji/udl2021/accepted-papers/UDL2021-paper-007.pdf',
        coordinates='All117 frozen nativeencoding columns covering41 originalfields includingduration and3fullcategoricalgroups+UNSEEN; same as exactV62 matching149 final117columns, no fieldselection or newscaling',
        FIT='Fulloriginal6000 trueBEN/KNA sourceIDs eachfine>=20, native5999 representativeevents exactlyonce instats; no optimizer/modelretrain/copyevents',
        dualgroup='Oneactual nativegroup hasfine2/4 source memberships; companionmetadata preservesboth, canonical singlelabel stats uses actual lexicographicallychosen representative originalsource fine, not fabricatedquerylabel. Oneevent countedonce.',
        statistics='Nine trueknownfine means; OAS assume_centeredTrue on eachgenuineevent minus ownrepresentativefine mean, OAS assume_centeredFalse on allgenuineevents background; sklearn analyticshrinkage, no jitter/epsilon or target labels',
        candidate='minall9 fine−background fixed; queryfine/coarse neverselects gaussiancomponent; originalstage1 onlyselects trueknownCAL finite99cut',
        CAL='All656 trueknownCAL once finite99 strictgreater; no class/direction/cut/grid sweep',
        geometry='ExactfrozenV62 real149 (encoded117+typedmaskMHFD32) and8192/80 Eq9/10 metric unchanged, no ViM174 reuse or newmetricfit',
        DVC='Currentraw OR whole2618 oldUNA, nativegroup dedup, originalowned149 knee/SC/CH/affinity/reconstruction/localdensity/secondarynoise; no BENrescue',
        merge='Copy complete2618 and append ownraw+retainedUNA only; preserveallold2601/2605/2618, samewholelossfreeUP required',
        gate='Known654 BEN/KNA exactinteger99 androwwiseoldcorrectloss0 beforeunique current3598 evaluation, predictionsealedbeforelabels',
        prior_NN_ancestry_seconds=1261.1884094000561,prior_old_metric_seconds=6.321081299975049,
        timing='AllfullFITdecode/representatives/mean/OAS andCAL numeric includednewprep; pureknown/currentscoreDVC separate, no programmedtimebound',
        realUNA_fit=False,query_fit=False,parameter_grid=False,NN_fit=0,NN_forward=0,metric_fit=0,
        sklearn_version=sklearn.__version__,independent_final_unproven=True,status='FAIL_TARGET99',published=False,final_test_executed=False)

def archive(a,keys,pins):return base.archive(a,keys,pins)
def persist(out,r,name,v):return base.save(out,r,name,v)

def fit_state(x,fine):
    files.require(x.shape==(5999,117)and np.isfinite(x).all()and np.array_equal(np.unique(fine),np.arange(9)),'genuine5999 all117/nine trueknownfine classes')
    means=np.stack([x[fine==j].mean(axis=0)for j in range(9)])
    with threadpool_limits(limits=2):within=OAS(assume_centered=True).fit(x-means[fine]);background=OAS(assume_centered=False).fit(x)
    files.require(within.shrinkage_>0 and background.shrinkage_>0,'positive analytical OAS shrinkage, no customfallback')
    state=dict(mean=means,within_covariance=within.covariance_,within_precision=within.precision_,background_mean=background.location_,background_covariance=background.covariance_,background_precision=background.precision_,shrinkage=np.asarray([within.shrinkage_,background.shrinkage_]))
    files.require(all(np.isfinite(v).all()for v in state.values()),'finite actualsinglefine/global OAS state');return state

def signals(x,state):
    within=np.column_stack([np.einsum('ni,ij,nj->n',x-m,state['within_precision'],x-m,optimize=True)for m in state['mean']]);d=x-state['background_mean'];background=np.einsum('ni,ij,nj->n',d,state['background_precision'],d,optimize=True);score=within.min(axis=1)-background
    files.require(np.isfinite(within).all()and np.isfinite(background).all()and np.isfinite(score).all(),'finite all9 relativeMD signedscore no clipping');return dict(score=score,foreground_MD9=within,background_MD=background)

def closure():
    result={}
    for m in list(sys.modules.values()):
        p=getattr(m,'__file__',None)
        if p:
            q=Path(p).resolve()
            if q.suffix=='.py'and q.is_relative_to(ROOT/'paper_open_set'):result[str(q)]=files.item(q)
    result['caller']=files.item(__file__);return result

def synthetic():
    s=dict(mean=np.asarray([[0.,0.],[2.,0.]]),within_precision=np.eye(2),background_mean=np.asarray([1.,0.]),background_precision=np.eye(2));x=np.asarray([[0.,3.],[1.,5.],[2.,-8.]]);a=signals(x,s)['score'];b=signals(x*np.asarray([1.,0.]),s)['score'];files.require(np.array_equal(a,b),'exactcommoncoordinate cancellation synthetic');files.require(np.array_equal(signals(x[::-1],s)['score'],a[::-1]),'syntheticquery order');files.require('fine'not in inspect.signature(signals).parameters and 'truth'not in inspect.signature(signals).parameters,'RMDquery API has no fine/truth');return dict(cancellation=True,queryorder=True,no_querylabel=True,realtraffic_decoded=0,OAS_fit=0)

def freeze():
    pins={};k=files.js(OLD_KNOWN,pins);b=files.js(BASELINE,pins);kr=files.js(k['registry'],pins)
    files.require(k['known_gate_passed']and b['prediction_sealed']and b['original_class_gates']['UNA']['correct']==2618,'actualwhole2618 baseline known gate')
    a=dict(encoded=kr['assets']['encoded'],material=k['files']['material'],reference=k['files']['reference'],metric=k['files']['metric'],current_context=b['files']['actual_query_nativecell_clean149_before_scores'],baseline=b['files']['postseal_comparison']);headers={n:old.masked.previous.metadata_headers(v,pins)for n,v in a.items()if Path(v['path']).suffix=='.npz'}
    files.require(headers['encoded']['fit_features']['shape']==[6000,117]and headers['material']['fit_Z149']['shape']==[6000,149]and headers['material']['calibration_Z149']['shape']==[656,149]and headers['material']['open_known_Z149']['shape']==[654,149]and headers['reference']['Z149']['shape']==[5999,149]and headers['current_context']['Z149']['shape']==[3598,149],'actualall117 role117/149 shapes')
    files.require('assume_centered'in inspect.signature(OAS).parameters,'actual sklearn OAS API');check=preflight.preflight(api_contracts=[dict(module_name=MODULE,function_name='fit_state',required_parameters=['x','fine'],source_sha256=files.item(__file__)['sha256']),dict(module_name=base.__name__,function_name='route_once',required_parameters=['metric','query','raw','sink'],source_sha256=files.item(base.__file__)['sha256']),dict(module_name=base.paper_route.__name__,function_name='calibrate_known_cutoffs',required_parameters=['score','predicted_coarse'],source_sha256=files.item(base.paper_route.__file__)['sha256'])]);src=closure()
    for v in [*a.values(),*src.values()]:files.read(v,pins)
    files.require(not REG.exists()and not BASE.exists(),'fresh uniqueRMD117singlefine namespace')
    value=dict(policy=policy(),assets=a,headers=headers,sources=src,API_preflight=check,synthetic_contract=synthetic(),old_known_report=OLD_KNOWN,baseline_report=BASELINE,input_sha256=pins);value['registry_sha256']=files.digest(value);REG.parent.mkdir(parents=True,exist_ok=False);return files.write(REG,value)

def bind(desc,pins):
    r=files.js(desc,pins);u=dict(r);h=u.pop('registry_sha256');files.require(h==files.digest(u)and r['policy']==policy()and r['sources']['caller']==files.item(__file__),'ownfrozenRMD117 source/API/policy')
    for v in r['sources'].values():files.read(v,pins)
    return r

def run(phase,desc,known_desc=None):
    started,pins=time.perf_counter(),{};reg=bind(desc,pins)
    if phase=='current':
        known=files.js(known_desc,pins);files.require(known['registry']==desc and known['known_gate_passed']and known['prediction_sealed']and not known['unknown_numeric_decoded'],'strictknown beforecurrentvalues')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False);r=dict(policy=policy(),registry=desc,phase=phase,files={},NN_fit=0,NN_forward=0,metric_fit=0,OAS_fit=0,CAL_fit=0,DVC=0,prediction_sealed=False,truth_opened=False,unknown_numeric_decoded=False,accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        a=reg['assets']
        if phase=='known':
            prep=time.perf_counter();encoded=archive(a['encoded'],('fit_features','fit_ids','fit_known_fine','calibration_features','calibration_ids','calibration_known_coarse','open_known_features','open_known_ids'),pins);mat=archive(a['material'],('fit_ids','fit_groups','fit_fine','fit_Z149','calibration_Z149','calibration_ids','calibration_stage1','open_known_Z149','open_known_ids','open_known_groups','open_known_stage1','open_known_predicted_fine'),pins);ref=archive(a['reference'],('ids','groups','original_indices','known_fine_membership'),pins);selected=ref['original_indices'];files.require(np.array_equal(encoded['fit_ids'],mat['fit_ids'])and np.array_equal(encoded['fit_known_fine'],mat['fit_fine'])and len(np.unique(encoded['fit_ids']))==6000 and min(np.bincount(mat['fit_fine'],minlength=9))>=20 and len(selected)==5999==len(np.unique(mat['fit_groups'])),'fullsource6000 floor20/genuine5999no fakecopies')
            files.require(np.array_equal(encoded['fit_features'].astype(np.float64),mat['fit_Z149'][:,32:])and np.array_equal(encoded['calibration_features'].astype(np.float64),mat['calibration_Z149'][:,32:])and np.array_equal(encoded['open_known_features'].astype(np.float64),mat['open_known_Z149'][:,32:]),'samefrozen149 native117 whole coordinates')
            x=encoded['fit_features'][selected].astype(np.float64);fine=mat['fit_fine'][selected];files.require(np.array_equal(ref['ids'],mat['fit_ids'][selected])and np.array_equal(ref['groups'],mat['fit_groups'][selected]),'exact original lexrepresentativegenuine parent IDs')
            persist(out,r,'genuine5999_singlelabel_andall_membership_before_RMDfit',dict(ids=ref['ids'],groups=ref['groups'],original_indices=selected,canonical_truefine=fine,all_actualfine_membership=ref['known_fine_membership'],X117=x));t=time.perf_counter();state=fit_state(x,fine);r['OAS_fit']=2;r['OAS_statistics_seconds']=time.perf_counter()-t;r['files']['state']=persist(out,r,'genuine5999_native117_knownfine9_tiedOAS_andglobal_background',state);cal=signals(encoded['calibration_features'].astype(np.float64),state);persist(out,r,'allCAL656_RMD_before_rule',dict(ids=encoded['calibration_ids'],truecoarse=encoded['calibration_known_coarse'],**cal));rule=base.paper_route.calibrate_known_cutoffs(cal['score'],encoded['calibration_known_coarse']);r['CAL_fit']=1;r['files']['rule']=files.write(out/'alltrueknownCAL656_once_RMDfinite99.json',rule);r['training_preparation_seconds']=time.perf_counter()-prep
            query=dict(ids=mat['open_known_ids'],groups=mat['open_known_groups'],Z149=mat['open_known_Z149'],stage1=mat['open_known_stage1'],predicted_fine=mat['open_known_predicted_fine']);native=encoded['open_known_features'].astype(np.float64)
        else:
            r['known_report']=known_desc;state=archive(known['files']['state'],('mean','within_precision','background_mean','background_precision'),pins);rule=files.js(known['files']['rule'],pins);r['files'].update(state=known['files']['state'],rule=known['files']['rule']);query=archive(a['current_context'],('ids','groups','Z149','stage1','predicted_fine'),pins);r['unknown_numeric_decoded']=True;native=query['Z149'][:,32:]
        t=time.perf_counter();cue=signals(native,state);r['query_score_seconds']=time.perf_counter()-t;persist(out,r,'RMD_actualnative117_scores_before_DVC',dict(ids=query['ids'],**cue));persist(out,r,'actualsame149_query_before_DVC',query);raw=base.paper_route.candidate_mask(cue['score'],query['stage1'],rule);baseline=old.parent.previous.prefix_archive(a['baseline'],('prediction',),654,pins)['prediction']if phase=='known'else archive(a['baseline'],('prediction',),pins)['prediction'];density=raw|(baseline==2);persist(out,r,'RMD_raw_density_before_DVC',dict(ids=query['ids'],score=cue['score'],raw=raw,density=density,stage1=query['stage1']));metric=old.learned.PaperVariationalPairMetric.from_state(files.js(a['metric'],pins));r['files']['metric']=a['metric'];t=time.perf_counter()
        def sink(name,v,m):persist(out,r,name+'_owned149_DVC_before_truth',v);r['files'][name+'_DVC_manifest']=files.write(out/(name+'_owned149_DVC_manifest.json'),m)
        route,_=base.route_once(metric,query,density,sink);r['DVC']=1;r['query_DVC_seconds']=time.perf_counter()-t;retained=raw&route['retained'];pred=base.merge(baseline,raw,retained);v=dict(ids=query['ids'],prediction=pred,baseline=baseline,raw=raw,retained=retained,density=density);p=persist(out,r,'complete_prediction_before_truth',v);r['files']['seal']=files.write(out/'prediction_seal_before_truth.json',dict(predictions=p,registry=desc,state=r['files']['state'],metric=a['metric'],CAL=r['files']['rule'],truth_used=False));r['prediction_sealed']=True;truth=old.parent.previous.prefix_archive(a['baseline'],('ids','truth'),654,pins)if phase=='known'else archive(a['baseline'],('ids','truth'),pins);files.require(np.array_equal(truth['ids'],query['ids']),'sameordered postsealtruth');r['truth_opened']=True;effect,g,_=base.delta(truth['truth'],pred,baseline,full=phase=='current');free=all(q['loss']==0 for q in effect['gain_loss'].values());binaryloss=int((((baseline!=0)==(truth['truth']!=0))&((pred!=0)!=(truth['truth']!=0))).sum());r.update(execution_status='singlefine_relativeMahalanobis117_'+phase+'_evaluated',EffectDelta=effect,original_class_gates=g,all_oldcorrect_loss_free=free,binary_oldcorrect_loss=binaryloss,known_gate_passed=phase=='known'and free and binaryloss==0 and all(q['passed']for q in g.values()),candidate_accepted_for_retention=phase=='current'and free and binaryloss==0 and effect['verdict']=='UP',class_raw={n:int((raw&(truth['truth']==i)).sum())for i,n in enumerate(g)});r['files']['postseal_comparison']=persist(out,r,'postseal_original_comparison',dict(**v,truth=truth['truth']))
        if phase=='current':extra=int(((truth['truth']==2)&(baseline!=2)&raw).sum());r.update(newraw_UNA=extra,perfect_raw_retention_UNA_ceiling=2618+extra)
    except Exception as err:r.update(execution_status='execution_failed',error_type=type(err).__name__,error=str(err));raise
    finally:
        for p,h in pins.items():files.require(files.item(p)['sha256']==h,'all frozenRMD inputs/source unchanged '+p)
        r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for n in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+n)
    a=p.parse_args();desc=dict(path=str(Path(a.registry).resolve()),sha256=a.registry_sha256)if a.phase!='freeze'else None;value=freeze()if a.phase=='freeze'else run(a.phase,desc,None if a.phase=='known'else dict(path=str(Path(a.known_report).resolve()),sha256=a.known_sha256));print(json.dumps(value,ensure_ascii=False))
