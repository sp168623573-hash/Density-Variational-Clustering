"""Known-only materialization and one new MHFD after corrupt duplicate exclusion.

Registered lossless known FIT/CP/CAL arrays supply the original40 values.
No raw unknown record or OPEN numeric member is decoded. The new source and
weights are separate from f7; known-dev gates are not three-class/final proof.
"""
import argparse
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import time
import joblib
import numpy as np
import torch
from . import nsl_setting2_warm_fit_coverage_training_v2 as old
from . import nsl35e_aux7_scoped_dev_admission_v1 as files

ROOT = files.ROOT
SCHEMA = 'NSL2-clean-known-protocol-valid-fixed80-MHFD-v1'
require = old.require
BASE = ROOT / 'data/external_dev/processed/nsl2_clean_known_material_training_20261009_v1'


def validate_protocols(frames):
    counts = {}
    for role, frame in frames.items():
        require(frame['protocol_type'].isin(('tcp', 'udp', 'icmp')).all(),
                'retained_protocols_must_be_genuine_tcp_udp_icmp:' + role)
        counts[role] = dict(Counter(frame['protocol_type'].tolist()))
    return counts


def freeze():
    pins = {}
    plan = dict(path=str(ROOT / 'data/external_dev/processed/nsl2_clean_protocol_duplicate_plan_20261009_v2/known_clean_role_plan.json'),
        sha256='349878e1337abdb593c08fe4762212f6fbcfa75787408c9d338bae489df045c6')
    clean = files.js(plan, pins)
    baseline = dict(path=str(ROOT / 'data/external_dev/processed/nsl_setting2_warm_fit_coverage_training_20261009_v2/NSL_KDD_Setting2/report.json'),
        sha256='dabfb50eb7922a085d2fb923b5fc24dcd54bce6f10a9fd405eab901b2e7f96ea')
    previous = files.js(baseline, pins)
    require(clean['new_training_executed'] is False and clean['new_known_effective_rows'] == 5798,
            'audited clean plan and effective cap')
    sources = {Path(m.__file__).name: files.item(m.__file__) for m in
        (old, old.planner, old.parent, old.parent.source_code, old.parent.model,
         old.parent.data, old.parent.config, old.seal, files)}
    sources['caller'] = files.item(__file__)
    policy = dict(schema_version=SCHEMA, training_classes=['BEN', 'KNA'],
        original_rows=5766, FIT_original=4487, optimizer_rows=4519, effective_known_rows=5798,
        copies=32, copies_in_density=0, source_schema='audited registered legacy40 without duration',
        preprocessing='new FIT-only categorical/numeric transformer, variance, ANOVA top50',
        model='unchanged paper MHFDNetwork attention, gate, position, CNN, BiLSTM and known heads',
        loss=old.POLICY['losses'], optimizer=old.POLICY['optimizer'], seed=old.SEED, epochs=80,
        checkpoint='fixed final epoch80; no CAL/DEV per-epoch inference',
        threshold='knownCAL only, sealed before DEV inference',
        unknown_training_or_source_reads=False, independent_holdout_claim=False,
        old_f7_and_source_modified=False, timeout_coded=False)
    reg = dict(schema_version=SCHEMA + '-registry', policy=policy, sources=sources, clean_plan=plan,
        old_known_records=old.planner.RECORDS, old_known_source_report=old.planner.SOURCE_REPORT,
        prior_known_report=baseline, prior_known_predictions=previous['files']['predictions'],
        outputs={p: str(BASE / p) for p in ('material', 'train')},
        source_admitted=False, independent_final_admitted=False, published=False, final_test_executed=False)
    reg['registry_sha256'] = files.digest(reg)
    directory = ROOT / 'tmp/nsl2_clean_known_material_training_20261009_v1'
    directory.mkdir(exist_ok=True)
    return files.write(directory / 'registry_before_actual.json', reg)


def archive(asset, keys, pins):
    with np.load(io.BytesIO(files.read(asset, pins)), allow_pickle=False) as z:
        return {k: z[k].copy() for k in keys}


def persist(out, name, values, report):
    path = out / (name + '.npz'); np.savez_compressed(path, **values)
    a = files.item(path); report['files'][name] = a
    return a


def state_digest(net):
    h = hashlib.sha256()
    for name, value in sorted(net.state_dict().items()):
        a = value.detach().cpu().numpy()
        h.update(name.encode()); h.update(a.dtype.str.encode())
        h.update(json.dumps(list(a.shape)).encode()); h.update(np.ascontiguousarray(a).tobytes())
    return h.hexdigest()


def infer_once(net, x, device, role, out, report):
    """Persist each returned tensor batch and complete output before guards."""
    captures = {name: [] for name in ('coarse_logits', 'fine_logits', 'reconstruction')}
    handles = []
    for name, module in (('coarse_logits', net.coarse_head), ('fine_logits', net.fine_head), ('reconstruction', net.decoder)):
        def hook(mod, args, value, name=name):
            a = value.detach().float().cpu().numpy().copy()
            index = len(captures[name]); captures[name].append(a)
            persist(out, role + '_' + name + '_batch' + str(index) + '_before_guard', {'value': a}, report)
        handles.append(module.register_forward_hook(hook))
    report['counts']['known_infer_attempts'] += 1
    try:
        result = old.parent.model.infer(net, x, device=torch.device(device), batch_size=2048)
        report['counts']['known_infer_returns'] += 1
    finally:
        for handle in handles: handle.remove()
    tensors = {name: np.concatenate(parts) for name, parts in captures.items()}
    values = dict(attack_probability=result.attack_probability, fine_probability=result.fine_probability,
        embedding32=result.embedding, reconstruction_error=result.reconstruction_error,
        **tensors)
    persist(out, role + '_complete_infer_before_guard', values, report)
    require(all(v.shape[0] == len(x) and np.isfinite(v).all() for v in values.values()),
            'complete finite clean known inference outputs')
    require(tensors['reconstruction'].shape == x.shape, 'actual complete decoder coordinates')
    require(all(len(v) == (len(x) + 2047) // 2048 for v in captures.values()), 'one hook result per actual2048 batch')
    report['counts']['known_forward_batches'] += (len(x) + 2047) // 2048
    return result, values


def run(phase, path, sha, material_path=None, material_sha=None):
    started = time.perf_counter(); pins = {}
    reg_a = dict(path=str(Path(path).resolve()), sha256=sha)
    reg = files.js(reg_a, pins); unsigned = dict(reg); sig = unsigned.pop('registry_sha256')
    require(sig == files.digest(unsigned) and reg['schema_version'] == SCHEMA + '-registry', 'frozen clean known experiment')
    for a in reg['sources'].values(): files.read(a, pins)
    require(reg['sources']['caller'] == files.item(__file__), 'this exact new caller')
    out = Path(reg['outputs'][phase]); require(out.is_relative_to(ROOT) and not out.exists(), 'fresh phase output')
    out.mkdir(parents=True)
    stage = 'known input binding'
    report = dict(schema_version=SCHEMA, phase=phase, registry=reg_a, policy=reg['policy'], files={},
        execution_status='not_completed', counts=dict(training_runs=0, preprocessing_fit=0,
        known_infer_attempts=0, known_infer_returns=0, known_forward_batches=0, unknown_infer=0),
        source_admitted=False, independent_final_admitted=False, published=False, final_test_executed=False,
        accepted_baseline_replaced=False, unknown_numeric_members_decoded=False, status='FAIL_TARGET99')
    try:
        plan = files.js(reg['clean_plan'], pins)
        require(plan['schema_version'].endswith('-v2') and plan['new_known_original_rows'] == 5766
            and plan['training_effective_aggregate'] == 5798 and plan['new_training_executed'] is False,
            'actual corrected source plan, no old f7 identity promotion')
        if phase == 'material':
            records = json.loads(old.checked(reg['old_known_records'], pins))
            require(reg['old_known_source_report'] == old.planner.SOURCE_REPORT, 'same registered lossless known cache producer')
            original, frames = old._load_known_values(pins, records)
            arrays, frames = old._reallocate(plan, original, frames)
            protocols = validate_protocols(frames)
            require(sum(len(x) for x in frames.values()) == 5766, 'all retained original known rows validated')
            require(all('\\tcp' not in x['protocol_type'].tolist() for x in frames.values()), 'corrupt category absent')
            stage = 'new knownFIT preprocessing'
            report['counts']['preprocessing_fit'] = 1
            features, prep = old._prepare(arrays, frames)
            path = out / 'new_knownFIT_preprocessing.joblib'; joblib.dump(prep, path, compress=3)
            preprocessor = files.item(path); report['files']['preprocessing'] = preprocessor
            material = {**arrays, **{r + '_features': features[r] for r in old.MODEL_ROLES}}
            # Also retain original lossless feature blocks, not a float32-only source.
            dtypes = {c: str(frames['FIT'][c].dtype) for c in frames['FIT']}
            categories = [c for c, t in dtypes.items() if t == 'object']
            integers = [c for c, t in dtypes.items() if t == 'int64']
            floating = [c for c, t in dtypes.items() if t == 'float64']
            require(len(categories) + len(integers) + len(floating) == 40, 'complete registered lossless column schema')
            for role, frame in frames.items():
                material[role + '_categorical40'] = frame[categories].to_numpy(dtype=str)
                material[role + '_integer40'] = frame[integers].to_numpy(dtype=np.int64)
                material[role + '_float40'] = frame[floating].to_numpy(dtype=np.float64)
            a = persist(out, 'clean_known_material_before_fit', material, report)
            prefit = dict(policy=reg['policy'], clean_plan=reg['clean_plan'], inputs=a, preprocessing=preprocessor,
                protocols=protocols, original_rows_by_role={r: len(frames[r]) for r in frames},
                original_known_rows=5766, effective_known_rows=5798,
                selected_feature_names=prep['selected_feature_names'],
                lossless_columns=dict(pandas_dtypes=dtypes, categorical=categories, integer=integers, floating=floating),
                role_summary=plan['role_summary'], known_true_labels_only=True,
                unknown_numeric_members_decoded=False, source_admitted=False, final_test_executed=False)
            report['files']['prefit'] = files.write(out / 'new_clean_known_prefit_before_training.json', prefit)
            require(not any('\\tcp' in n for n in prep['selected_feature_names']), 'no learned corrupt category feature')
            require(all(np.isfinite(x).all() and x.dtype == np.float32 for x in features.values()), 'actual finite transformed known features')
            report.update(execution_status='clean_known_material_and_prefit_frozen',
                protocol_counts=protocols, known_rows=5766, effective_known_rows=5798,
                FIT_original=4487, optimizer_rows=4519, selected_feature_count=features['FIT'].shape[1])
        else:
            require(material_path and material_sha, 'completed material phase before training')
            material = files.js(dict(path=str(Path(material_path).resolve()), sha256=material_sha), pins)
            require(material['execution_status'] == 'clean_known_material_and_prefit_frozen'
                and material['registry'] == reg_a, 'exact validated source and prefit recipe')
            keys = ['FIT_optimization_indices']
            for role in old.MODEL_ROLES:
                keys += [role + '_' + k for k in ('features', 'ids', 'density_indices')]
                if role != 'DEV': keys += [role + '_' + k for k in ('y_fine', 'y_coarse')]
            arrays = archive(material['files']['clean_known_material_before_fit'], tuple(keys), pins)
            ix = arrays['FIT_optimization_indices']; x = arrays['FIT_features'][ix]
            require(len(ix) == 4519 and len(x) + len(arrays['CAL_ids']) + len(arrays['DEV_ids']) == 5798 <= 6000,
                    'effective caps before optimization')
            stage = 'one new clean known-only fixed80 MHFD'
            torch.set_num_threads(4); report['counts']['training_runs'] = 1
            result = old._fit_fixed_final(x, arrays['FIT_y_coarse'][ix], arrays['FIT_y_fine'][ix])
            report.update(training_seconds=float(result.training_seconds), training_device=result.device, epochs_completed=80)
            require(result.selected_epoch == 80 and len(result.history) == 80, 'all fixed final80 epochs')
            net = result.model
            checkpoint = out / 'new_clean_known_fixed80_MHFD.pt'
            torch.save(dict(state_dict={k: v.detach().cpu() for k, v in net.state_dict().items()},
                model_class='MHFDNetwork', input_dim=x.shape[1], fine_classes=list(old.FAMILIES),
                epochs_completed=80, seed=old.SEED, model_state_sha256=state_digest(net)), checkpoint)
            model_a = files.item(checkpoint); report['files']['model'] = model_a
            report['files']['history'] = files.write(out / 'actual_training_history80.json', result.history)
            known_outputs = {}
            for role in ('FIT', 'CAL'):
                stage = 'actual_known_' + role
                output, values = infer_once(net, arrays[role + '_features'], result.device, role, out, report)
                known_outputs[role] = output
            threshold, metrics = old.parent.model.choose_coarse_threshold(arrays['CAL_y_coarse'], known_outputs['CAL'].attack_probability)
            report['files']['threshold'] = files.write(out / 'knownCAL_threshold_before_DEV.json',
                dict(threshold=float(threshold), CAL_ids=old.array_descriptor(arrays['CAL_ids']),
                    model=model_a, calibration_metrics=metrics, DEV_labels_used=False))
            stage = 'actual_known_DEV_once_after_threshold_seal'
            output, values = infer_once(net, arrays['DEV_features'], result.device, 'DEV', out, report)
            known_outputs['DEV'] = output
            predictions = {role + '_prediction': (known_outputs[role].attack_probability >= threshold).astype(np.int64)
                for role in old.MODEL_ROLES}
            predictions.update({role + '_ids': arrays[role + '_ids'] for role in old.MODEL_ROLES})
            pred_a = persist(out, 'complete_known_predictions_before_DEV_truth', predictions, report)
            report['files']['prediction_seal'] = files.write(out / 'known_predictions_seal_before_DEV_truth_and_prior.json',
                dict(model=model_a, predictions=pred_a, threshold=report['files']['threshold'],
                    DEV_truth_opened=False, prior_forecasts_opened=False))
            truth = archive(material['files']['clean_known_material_before_fit'], ('DEV_y_coarse',), pins)['DEV_y_coarse']
            arrays['DEV_y_coarse'] = truth
            g = {r: old.gates(arrays[r + '_y_coarse'], predictions[r + '_prediction']) for r in old.MODEL_ROLES}
            # CAL and DEV IDs are unchanged, making their measured change comparable.
            prior = archive(reg['prior_known_predictions'], tuple(r + '_' + k
                for r in ('CAL', 'DEV') for k in ('ids', 'prediction')), pins)
            delta = {}
            for role in ('CAL', 'DEV'):
                require(np.array_equal(arrays[role + '_ids'], prior[role + '_ids']), 'same known control identity order')
                y = arrays[role + '_y_coarse']; previous = old.gates(y, prior[role + '_prediction'])
                d = {name: g[role][name]['correct'] - previous[name]['correct'] for name in ('BEN', 'KNA')}
                verdict = ('UP' if all(v >= 0 for v in d.values()) and any(d.values()) else
                    'DOWN' if all(v <= 0 for v in d.values()) and any(d.values()) else
                    'UNCHANGED' if not any(d.values()) else 'MIXED')
                delta[role] = dict(verdict=verdict, correct_count_delta=d, prior=previous)
            report.update(execution_status='new_clean_known_MHFD_CAL_DEV_evaluated', known_class_gates=g,
                EffectDelta=delta, coarse_threshold=float(threshold),
                CAL_DEV_original_gate_passed=all(v['passed'] for r in ('CAL', 'DEV') for v in g[r].values()),
                new_model_state_sha256=state_digest(net), UNA_performance_measured=False,
                known_family_effective_floor20=True, effective_known_rows=5798, density_copy_rows=0)
        for p, h in pins.items(): require(old.sha(p) == h, 'bound inputs/producer sources unchanged')
    except Exception as error:
        report.update(execution_status='execution_failed', failed_stage=stage, error_type=type(error).__name__, error=str(error))
        raise
    finally:
        report['input_sha256'] = pins; report['wall_seconds'] = time.perf_counter() - started
        files.write(out / 'report.json', report)
    return files.item(out / 'report.json')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--phase', choices=('freeze', 'material', 'train'), required=True)
    for name in ('registry', 'registry-sha256', 'material', 'material-sha'): p.add_argument('--' + name)
    a = p.parse_args()
    print(json.dumps(freeze() if a.phase == 'freeze' else run(a.phase, a.registry, a.registry_sha256, a.material, a.material_sha)))
