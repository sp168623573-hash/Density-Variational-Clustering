"""Extract capped NSL2 warm known source inputs with lossless column dtypes.

Label routing precedes every feature conversion. Integers and floating values
are stored separately, so neither pickle objects nor an early float32/float64
conversion of integer columns can alter source identities. No model is loaded.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import time

import numpy as np
import pandas as pd

from . import nsl_setting2_capped_known_fit_plan_v1 as planner
from . import nsl_setting2_warm_known_role_recovery_v1 as recovery

ROOT, SETTING, FAMILIES = planner.ROOT, planner.SETTING, planner.FAMILIES
ROLE_MAP = {'FIT':'fit', 'CP':'checkpoint', 'CAL':'calibration', 'OPEN':'open_known'}
ROLE_ROWS = {'FIT':3471, 'CP':1216, 'CAL':1279, 'OPEN':1209}
REPORT_ROWS = {'FIT':3505, 'CP':1216, 'CAL':1279, 'OPEN':1213}
BASE = 'data/external_dev/processed/nsl_setting2_capped_known_fit_plan_20261008_v1'
PLAN_REL, PLAN_REPORT_REL = BASE+'/known_role_plan.json', BASE+'/report.json'
PINS = {**planner.PINS,
    PLAN_REL:'b467a6866c165d195f21dcdaef18c6ef8dfcf1ab9a8e03d8839578781de42f85',
    PLAN_REPORT_REL:'5f10fb4751e490c2f88ec827e2930052d336b7a6967b06265da9d7b3c5fd3df5',
    BASE+'/policy_before_group_selection.json':'11493f96aa15e29d4f02d3284fe9e796f3d68870753b62354ac280dedeaf5259',
    'paper_open_set/nsl_setting2_capped_known_fit_plan_v1.py':'e98a1ecec2331b327e8eb5d0e2d37d647714401d501cd274f419ea70968028bf',
    'paper_open_set/data.py':recovery.PINS['paper_open_set/data.py'],
}
OUTPUT = ROOT/'data/external_dev/processed/nsl_setting2_capped_known_source_extract_20261008_v1'
SCHEMA = 'NSL2-capped-warm-known-source-extract-v1'
POLICY = dict(schema_version=SCHEMA, setting=SETTING,
    source_path=recovery.SOURCE_REL, source_sha256=recovery.SOURCE_SHA,
    source_schema='legacy Sample40 + label + difficulty; duration is not present',
    selection='exact already-sealed capped FIT3471 and unchanged CP1216 CAL1279 OPEN1209 original records',
    input_storage='three categorical Unicode columns; original int64 and float64 columns in separate arrays; no float32 conversion',
    original_column_dtype_authority='successful fixed recovery report known_pandas_dtypes',
    known_identity='same legacy pandas64 group plus strong pandas-string40 SHA, raw-row SHA and exact source ordinal',
    source_processing='fixed SHA before stream; only UTF8 label cell40 for routing every record; known40 only enter pandas',
    unknown_feature_rows_decoded=0, difficulty_cells_decoded=0,
    source_Test_file_opened=False, model_or_preprocessor_loaded=False,
    training_runs=0, model_inference_runs=0, DVC_calls=0,
    copy_rules='FIT34 optimizer copies through3505 indices; CP/CAL no new copies; OPEN4 httptunnel copies report-only',
    density='separate representative indices from capped plan; optimization/report copies never enter density',
    training_effective_aggregate=6000, warm_development_only=True,
    rare_family_parent_physical_flow_authority_resolved=False,
    legacy_Sample_duplicates_are_not_independent_flows=True,
    all_previous_known_exposure_preserved=True,
    original_dataset_physical_proportions_claimed=False,
    historical_CP_CAL_ID_direct_archive_comparison_available=False,
    independent_final_admitted=False, final_test_executed=False,
    status='FAIL_TARGET99', published=False)
sha, digest, write_new = recovery.sha, recovery.digest, recovery.write_new


class KnownSourceExtractStop(ValueError):
    pass


def require(ok, reason):
    if not ok:
        raise KnownSourceExtractStop(reason)


def array_descriptor(value):
    x = np.asarray(value)
    require(x.dtype.kind != 'O', 'object_arrays_forbidden')
    return {'shape':list(x.shape), 'dtype':x.dtype.str,
        'sha256':hashlib.sha256(x.tobytes(order='C')).hexdigest()}


def feature_schema(dtypes, role_rows):
    columns = recovery.config.NSL_FEATURE_COLUMNS
    require(set(dtypes) == set(columns) and all(dtypes[c] == 'object' for c in columns[:3])
        and all(dtypes[c] in ('int64','float64') for c in columns[3:]), 'registered_feature_dtype_schema')
    require(set(role_rows) == set(ROLE_MAP) and all(type(v) is int and v > 0 for v in role_rows.values()),
        'positive_four_role_sizes')
    return dict(schema_version='NSL2-lossless-legacy40-feature-schema-v1',
        feature_columns=list(columns), categorical_columns=list(columns[:3]),
        integer_columns=[c for c in columns[3:] if dtypes[c] == 'int64'],
        float_columns=[c for c in columns[3:] if dtypes[c] == 'float64'],
        pandas_dtypes=dict(dtypes), family_order=list(FAMILIES), role_map=dict(ROLE_MAP),
        role_original_rows=dict(role_rows), categorical_dtype='Unicode',
        integer_dtype='int64', float_dtype='float64', object_pickle_permitted=False,
        numeric_float32_conversion_performed=False)


def decode_known_frame(buffer, records, boundary, expected_dtypes):
    """One known-only pandas parse; unknown bytes never enter this buffer."""
    boundary['known_numeric_parse_attempted'] = True
    frame = pd.read_csv(buffer, header=None, names=recovery.config.NSL_FEATURE_COLUMNS,
        low_memory=False, encoding='utf8')
    require(frame.shape == (len(records),40) and not frame.isna().any().any(), 'known40_shape_or_missing')
    actual = {c:str(frame[c].dtype) for c in recovery.config.NSL_FEATURE_COLUMNS}
    require(actual == expected_dtypes, 'known_column_dtype_differs_from_registered_recovery')
    schema = feature_schema(actual, {r:1 for r in ROLE_MAP})
    for columns in (schema['integer_columns'], schema['float_columns']):
        values = frame.loc[:, columns].to_numpy(copy=False)
        require(np.isfinite(values).all() and (values >= 0).all(), 'known_numeric_nonnegative_finite')
    require(all(isinstance(v,str) for c in schema['categorical_columns'] for v in frame[c]),
        'categorical_strings_required')
    fingerprints = recovery.data._feature_fingerprint(frame, recovery.config.NSL_FEATURE_COLUMNS).astype(str).tolist()
    strings = frame.loc[:, recovery.config.NSL_FEATURE_COLUMNS].astype(str)
    for i, item in enumerate(records):
        item['legacy_model40_group'] = fingerprints[i]
        item['pandas_string_feature_values_sha256'] = digest(strings.iloc[i].tolist())
        item['sample_id'] = f"nsl_kdd:source_train:{item['source_record_ordinal_zero_based']}:{fingerprints[i]}"
    boundary['known_numeric_parse_completed'] = True
    boundary['known_feature_rows_parsed'] = len(records)
    return frame


def check_all_known_records(actual, recovered):
    expected = sorted((r for rows in recovered['known_roles'].values() for r in rows),
        key=lambda r:r['source_record_ordinal_zero_based'])
    require(len(actual) == len(expected), 'complete_known_source_record_count')
    for row, prior in zip(actual, expected):
        require({**row, 'role':prior['role']} == prior, 'known_source_record_changed_at_ordinal:'+str(prior['source_record_ordinal_zero_based']))
    return {r['source_record_ordinal_zero_based']:i for i,r in enumerate(actual)}


def restore_frame(arrays, role, schema):
    """Rebuild the original pandas column types without inference or fitting."""
    require(role in ROLE_MAP and schema.get('schema_version') == 'NSL2-lossless-legacy40-feature-schema-v1',
        'restore_registered_schema')
    expected = feature_schema(schema['pandas_dtypes'], schema['role_original_rows'])
    require(schema == expected, 'exact_feature_schema_required')
    rows = schema['role_original_rows'][role]
    blocks = [('categorical', schema['categorical_columns'], 'U'),
        ('integer_numeric', schema['integer_columns'], 'i'),
        ('float_numeric', schema['float_columns'], 'f')]
    columns = {}
    for suffix, names, kind in blocks:
        x = np.asarray(arrays[role+'_'+suffix])
        require(x.shape == (rows,len(names)) and x.dtype.kind == kind, 'restore_block_shape_or_dtype:'+suffix)
        if kind == 'i':
            require(x.dtype == np.dtype('int64') and (x>=0).all(), 'restore_int64_required')
        elif kind == 'f':
            require(x.dtype == np.dtype('float64') and np.isfinite(x).all() and (x>=0).all(), 'restore_float64_finite_required')
        for j,name in enumerate(names):
            columns[name] = pd.Series(x[:,j].copy(), dtype='object' if kind=='U' else schema['pandas_dtypes'][name])
    frame = pd.DataFrame(columns).loc[:, schema['feature_columns']]
    require({c:str(frame[c].dtype) for c in frame} == schema['pandas_dtypes'], 'restored_pandas_dtypes')
    return frame


def verify_role_frame(frame, rows):
    require(len(frame) == len(rows), 'restored_role_length')
    groups = recovery.data._feature_fingerprint(frame, recovery.config.NSL_FEATURE_COLUMNS).astype(str).tolist()
    strings = frame.astype(str)
    for i,row in enumerate(rows):
        require(groups[i] == row['legacy_model40_group']
            and digest(strings.iloc[i].tolist()) == row['pandas_string_feature_values_sha256'],
            'restored_model40_identity_mismatch:'+str(i))


def build_role_arrays(frame, actual_records, recovered, plan, dtypes):
    index = check_all_known_records(actual_records, recovered)
    sizes = {r:len(plan['known_roles'][lower]) for r,lower in ROLE_MAP.items()}
    schema = feature_schema(dtypes, sizes)
    arrays, records = {}, {}
    for role, lower in ROLE_MAP.items():
        rows = plan['known_roles'][lower]
        positions = []
        for row in rows:
            ordinal = row['source_record_ordinal_zero_based']
            require(ordinal in index and {**actual_records[index[ordinal]], 'role':lower} == row,
                'selected_ordered_source_identity_binding')
            positions.append(index[ordinal])
        selected = frame.iloc[positions].reset_index(drop=True)
        records[role] = deepcopy(rows)
        arrays[role+'_categorical'] = np.ascontiguousarray(selected.loc[:,schema['categorical_columns']].to_numpy(dtype=str))
        arrays[role+'_integer_numeric'] = np.ascontiguousarray(selected.loc[:,schema['integer_columns']].to_numpy(dtype=np.int64))
        arrays[role+'_float_numeric'] = np.ascontiguousarray(selected.loc[:,schema['float_columns']].to_numpy(dtype=np.float64))
        arrays[role+'_ids'] = np.asarray([r['sample_id'] for r in rows], dtype=str)
        arrays[role+'_families'] = np.asarray([r['family'] for r in rows], dtype=str)
        arrays[role+'_groups'] = np.asarray([r['legacy_model40_group'] for r in rows], dtype='U16')
        arrays[role+'_strong_feature_sha256'] = np.asarray([r['pandas_string_feature_values_sha256'] for r in rows], dtype='U64')
        arrays[role+'_y_fine'] = np.asarray([FAMILIES.index(r['family']) for r in rows], dtype=np.int64)
        arrays[role+'_y_coarse'] = np.asarray([r['coarse'] for r in rows], dtype=np.int64)
        arrays[role+'_source_ordinals'] = np.asarray([r['source_record_ordinal_zero_based'] for r in rows], dtype=np.int64)
        arrays[role+'_density_representative_indices'] = np.asarray(plan['role_density_representative_indices'][lower], dtype=np.int64)
        arrays[role+'_reporting_indices'] = np.asarray(plan['floor20_report_views'][lower]['indices'], dtype=np.int64)
        require(arrays[role+'_density_representative_indices'].tolist() == planner.density_indices(rows), 'density_representative_binding')
        require(plan['floor20_report_views'][lower] == recovery.floor_view(rows), 'role_report_floor_binding')
        verify_role_frame(restore_frame(arrays, role, schema), rows)
    arrays['FIT_optimization_indices'] = np.asarray(plan['fit_optimization_indices'], dtype=np.int64)
    require(np.array_equal(arrays['FIT_optimization_indices'], arrays['FIT_reporting_indices']), 'FIT_optimizer_index_binding')
    for x in arrays.values():
        x.setflags(write=False)
    return arrays, schema, {'schema_version':'NSL2-capped-warm-ordered-known-source-records-v1',
        'setting':SETTING, 'source_path':recovery.SOURCE_REL, 'source_sha256':recovery.SOURCE_SHA,
        'roles':records, 'family_order':list(FAMILIES), 'role_map':dict(ROLE_MAP),
        'role_summary':deepcopy(plan['role_summary']),
        'all_original_12028_known_exposures_remain_in_parent_plan':True,
        'physical_parent_flow_authority_resolved':False, 'warm_development_only':True,
        'independent_final_admitted':False, 'copies_in_original_feature_arrays':0}


def expected_members():
    return {r+'_'+suffix for r in ROLE_MAP for suffix in ('categorical','integer_numeric','float_numeric',
        'ids','families','groups','strong_feature_sha256','y_fine','y_coarse','source_ordinals',
        'density_representative_indices','reporting_indices')} | {'FIT_optimization_indices'}


def verify_saved_archive(path, arrays, bound, schema, records):
    require(set(arrays) == set(bound) == expected_members(), 'exact49_archive_members')
    with np.load(path, allow_pickle=False) as stored:
        require(set(stored.files) == expected_members() and len(stored.files) == len(expected_members()), 'saved_archive_members')
        for key,value in arrays.items():
            require(array_descriptor(value) == bound[key], 'live_array_changed_after_presave:'+key)
            require(array_descriptor(stored[key]) == bound[key], 'saved_array_binding:'+key)
        for role in ROLE_MAP:
            verify_role_frame(restore_frame(stored, role, schema), records['roles'][role])


def load_registered_metadata(pins):
    for rel, expected in pins.items():
        require(sha(ROOT/rel) == expected, 'input_pin_mismatch:'+rel)
    report = json.loads((ROOT/PLAN_REPORT_REL).read_text(encoding='utf8'))
    plan = json.loads((ROOT/PLAN_REL).read_text(encoding='utf8'))
    recovered = json.loads((ROOT/planner.RECORDS_REL).read_text(encoding='utf8'))
    recovered_report = json.loads((ROOT/planner.REPORT_REL).read_text(encoding='utf8'))
    require(report['planning_completed'] is True and report['final_input_pins_unchanged'] is True
        and report['files']['known_role_plan'] == {'path':PLAN_REL,'sha256':PINS[PLAN_REL]}
        and plan['configuration'] == json.loads(json.dumps(planner.POLICY)), 'successful_registered_plan')
    planner.validate_recovered(recovered)
    require({role:len(plan['known_roles'][lower]) for role,lower in ROLE_MAP.items()} == ROLE_ROWS
        and plan['controls_before'] == plan['controls_after'] == planner.control_bindings(recovered),
        'fixed_selected_roles_and_control_bindings')
    require(planner.control_bindings(plan) == planner.control_bindings(recovered), 'actual_control_entries_maps_unchanged')
    require(plan['fit_optimization_indices'] == plan['floor20_report_views']['fit']['indices']
        and plan['FIT_optimization_rows'] == 3505 and plan['training_effective_aggregate'] == 6000,
        'optimizer_and_aggregate_budget')
    return plan, recovered, recovered_report


def run(*, output_directory=OUTPUT):
    output = Path(output_directory).resolve()
    require(output.is_relative_to(ROOT/'data/external_dev/processed'), 'output_outside_processed')
    output.mkdir(parents=True, exist_ok=False)
    report = {**POLICY, 'execution_status':'started', 'stage':'verify_registered_metadata',
        'source_extraction_completed':False, 'all_input_pins_stable':False, 'files':{},
        'boundary':recovery.initial_boundary(), 'source_record_stream_opened':False,
        'source_opaque_hash_completed':False, 'source_feature_values_saved':False}
    start = time.perf_counter()
    try:
        pins = {**PINS, Path(__file__).resolve().relative_to(ROOT).as_posix():sha(__file__)}
        plan, recovered, recovered_report = load_registered_metadata(pins)
        report['stage'] = 'verify_source_SHA_before_any_record_decoding'
        require(sha(ROOT/recovery.SOURCE_REL) == recovery.SOURCE_SHA, 'registered_source_SHA_mismatch')
        report['source_opaque_hash_completed'] = True
        pins[recovery.SOURCE_REL] = recovery.SOURCE_SHA
        report['input_sha256'] = dict(pins)
        expected_dtypes = recovered_report['known_pandas_dtypes']
        schema = feature_schema(expected_dtypes, ROLE_ROWS)
        report['files']['policy_before_source_scan'] = write_new(output/'policy_before_source_scan.json',
            {**POLICY, 'input_sha256':pins, 'feature_schema':schema,
                'selected_role_counts':ROLE_ROWS, 'effective_report_counts':REPORT_ROWS,
                'runtime_versions':{'pandas':pd.__version__, 'numpy':np.__version__}})
        report['stage'] = 'label_route_known_features_and_complete_source_identity_check'
        report['source_record_stream_opened'] = None
        with (ROOT/recovery.SOURCE_REL).open('rb') as stream:
            report['source_record_stream_opened'] = True
            buffer, actual_records = recovery.route_known_feature_bytes(stream, report['boundary'])
        frame = decode_known_frame(buffer, actual_records, report['boundary'], expected_dtypes)
        require(report['boundary']['scope_rows'] == recovered_report['boundary']['scope_rows']
            and report['boundary']['source_records_framed'] == recovered_report['boundary']['source_records_framed'],
            'source_scope_row_counts')
        report['stage'] = 'selected_role_arrays_and_exact_dataframe_roundtrip'
        arrays, actual_schema, records = build_role_arrays(frame, actual_records, recovered, plan, expected_dtypes)
        require(actual_schema == schema and {r:len(arrays[r+'_ids']) for r in ROLE_MAP} == ROLE_ROWS
            and {r:len(arrays[r+'_reporting_indices']) for r in ROLE_MAP} == REPORT_ROWS,
            'fixed_original_and_effective_array_counts')
        require(len(arrays['FIT_optimization_indices'])+len(arrays['CP_ids'])+len(arrays['CAL_ids']) == 6000,
            'training_side6000_cap')
        report['stage'] = 'seal_inputs_and_verify_saved_live_bindings'
        bound = {k:array_descriptor(v) for k,v in arrays.items()}
        record_bound, schema_bound = digest(records), digest(schema)
        archive_path = output/'known_roles.npz'
        with archive_path.open('xb') as handle:
            np.savez_compressed(handle, **arrays)
        report['source_feature_values_saved'] = True
        verify_saved_archive(archive_path, arrays, bound, schema, records)
        report['files']['known_roles_archive'] = {'path':archive_path.relative_to(ROOT).as_posix(),'sha256':sha(archive_path)}
        report['files']['feature_schema'] = write_new(output/'feature_schema.json', schema)
        report['files']['ordered_source_records'] = write_new(output/'ordered_source_records.json', records)
        require(digest(records) == record_bound and digest(schema) == schema_bound
            and digest(json.loads((output/'ordered_source_records.json').read_text(encoding='utf8'))) == record_bound
            and digest(json.loads((output/'feature_schema.json').read_text(encoding='utf8'))) == schema_bound,
            'schema_or_record_save_binding')
        report['stage'] = 'final_source_code_metadata_and_output_integrity'
        for rel, expected in {**pins, **{d['path']:d['sha256'] for d in report['files'].values()}}.items():
            require(sha(ROOT/rel) == expected, 'final_input_or_output_pin_mismatch:'+rel)
        verify_saved_archive(archive_path, arrays, bound, schema, records)
        report.update(execution_status='known_source_extraction_completed', stage='complete',
            source_extraction_completed=True, all_input_pins_stable=True, array_descriptors=bound,
            ordered_record_content_sha256=record_bound, feature_schema_content_sha256=schema_bound,
            role_rows=ROLE_ROWS, role_report_rows=REPORT_ROWS,
            role_summary=deepcopy(plan['role_summary']), original_feature_records=7175,
            FIT_original_feature_groups=3471, FIT_optimization_rows=3505,
            FIT_optimization_copies=34, OPEN_report_only_copies=4,
            density_uses_copies=False, all_12028_known_source_identity_records_exact=True,
            selected_source_identity_and_dataframe_hashes_exact=True,
            training_input_extraction_completed=True)
    except Exception as exc:
        report['execution_status'] = 'protocol_stop' if isinstance(exc,
            (KnownSourceExtractStop, recovery.KnownRoleRecoveryStop, planner.CappedKnownFitPlanStop)) else 'execution_failed'
        report['error'] = {'type':type(exc).__name__, 'message':str(exc)}
        if isinstance(exc,recovery.KnownRoleRecoveryStop):
            report['error']['evidence'] = exc.evidence
    report['wall_seconds'] = time.perf_counter()-start
    write_new(output/'report.json', report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-directory',type=Path,default=OUTPUT)
    args = parser.parse_args()
    report = run(output_directory=args.output_directory)
    print(json.dumps({k:report.get(k) for k in ('execution_status','stage','source_extraction_completed',
        'role_rows','role_report_rows','FIT_optimization_rows','error')},ensure_ascii=False,indent=2))
    return 0 if report['source_extraction_completed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
