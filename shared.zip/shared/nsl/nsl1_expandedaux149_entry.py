"""ROOT-only new FIT6000/encoder117 auxiliary149 incremental development view.

The primary35e coarse/fine outputs and complete2579/2596 base are preserved.
The new117 classifier failed the BEN gate and supplies embedding32 only.
The new metric, reference/R7 and CAL cuts are learned from registered known
roles only. Current3598 is the already-observed development cohort; no new
final asset, label-selected row or independent-final assertion is accepted.

freeze is metadata/header-only. prepare fits new FIT embedding units and
seals the149 known-only pair plan. known fits one owned149 metric and checks
paired original654 BEN/KNA loss before current may open native query values.
current reuses the real new117 OPEN654 cache and runs unknown2944 once,
then scores/routes the complete current3598 and seals before truth.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import time

import numpy as np
import torch

from . import nsl1_expanded_fit6000_all41_v2 as producer
from . import nsl1_expanded_fit6000_all41_v1 as encoding
from . import nsl1_expandedaux149_pair_metric_v1 as learned
from . import nsl1_expandedaux149_dvc_v1 as owned_dvc
from . import nsl_mhfd_paper_metric_warm_v1 as paper_route

files, ROOT, model = producer.files, producer.ROOT, producer.model
SCHEMA = 'NSL1-preserved2596-new-FIT6000-MHFD117-auxiliary149-v1'
BASE = ROOT / 'data/external_dev/processed/nsl1_expandedaux149_20261009_v1'
WIDTH, ENCODED_WIDTH, N_QUERY, N_KNOWN = 149, 117, 3598, 654
ROLES = dict(fit=6000, checkpoint=656, calibration=656, open_known=654)
TRAIN = dict(path=str(producer.BASE / 'train/report.json'),
    sha256='33f3e60c9c76bd6c17e201f9a1cb3ab520977b5d26a2598746eaf59e7691c7ff')
PRIMARY = dict(path=str(ROOT / 'data/external_dev/processed/nsl_MHFD_whole_field_mask_known80_20261009_v1/NSL_KDD_Setting1/report.json'),
    sha256='9b3e14629a6a9b1add35fc9855a14eeafa0d81c86a799249a05737628dd1e7af')
PRIMARY_REGISTRY = dict(path=str(ROOT / 'tmp/nsl_MHFD_whole_field_mask_design_20261009_v1/known80_registry_before_actual.json'),
    sha256='b5d8babceaf3c103bc0f9b45dbecb0b2090bb554b832ad2678eda7429f619552')
BASELINE = dict(path=str(ROOT / 'data/external_dev/processed/nsl2579_incremental147_feature_currentcrop_20261009_v1/report.json'),
    sha256='936e210c297407ae3fd2fbeebe68e40f98d264efa6691610efcb57f7ec3442f7')
MODEL_SHA = '566dc4cb60f70645efdf936faeab402cbf461538bbe235f7c414e1e8b6ed4d5f'
PRIMARY_SHA = '35e030de1d72b4d594ef9b8923a267dd20e0bb1c72e0def19c5fdf3ce768409e'
COMPLETE_KEYS = ('attack_probability','fine_probability','embedding','reconstruction_error','gate_mean',
    'coarse_attack_probability','fine_attack_probability','embedding32',
    'raw_coarse_logits','raw_fine_logits','raw_embedding','raw_reconstruction','raw_gate_mean')


def recipe():
    return dict(schema_version=SCHEMA, setting='NSL-KDD Setting1', roles=ROLES,
        geometry='new actual FIT6000 MHFD117 embedding32 / new unique-native41 FIT column RMS + complete new encoded117',
        width=149, encoded_width=117, embedding_width=32,
        classifier='frozen PRIMARY35e cached genuine predicted coarse/fine for CAL656, OPEN654 and current3598; no additional1966 primary inference needed',
        auxiliary_heads_used_for_decisions=False, auxiliary_classifier_BEN_failed=True,
        auxiliary_model_state_sha256=MODEL_SHA, primary_model_state_sha256=PRIMARY_SHA,
        new_metric='owned149 Eq9/10 copied numerical recipe, FIT6000 only; no old147 or115 metric/unit signatures',
        reference='unique genuine native41 FIT groups; preserve all true known fine memberships',
        score='nearest PRIMARY-predicted fine reference, max-radius tie, stable d^2/(d^2+r^2)',
        local_radius='same-fine min(7,n-1)th other genuine FIT group; self excluded',
        calibration='same original MAIN-predicted coarse CAL656; finite99 strictgreater once',
        DVC='same new149 learned distance, native41 group density, primary/secondary affinity and noise',
        known_gate='only supplementary raw&retained applied to preserved2596 prefix; zero paired BEN/KNA loss plus integer99',
        merge='preserve full2596 vector; only own current raw AND own current DVC-retained become UNA',
        current_scope='already-observed original3598 feature development cohort, not independent or final',
        current_inference='new117 saved real known654 prefix plus one2944 unknown forward (2048+896), same producer runtime',
        parameter_fit_uses_unknown=False, additional_primary_inference=0, NN_retraining=0,
        original2579_preserved=True, retained2596_preserved=True, row_or_label_selection_by_DEV=False,
        arbitrary_new_final_asset_reads=False, accepted_baseline_replaced=False, report_copies_in_density=0,
        published=False, final_test_executed=False, source_admitted=False, status='FAIL_TARGET99')


def archive(asset, keys, pins):
    return producer.archive(asset, keys, pins)


def descriptor(value):
    a = np.asarray(value)
    return dict(shape=list(a.shape),dtype=a.dtype.str,
        sha256=hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest())


def group_hashes(native):
    a = np.asarray(native)
    files.require(a.ndim == 2 and a.shape[1] == 41 and a.dtype.kind == 'U','genuine native41 field rows')
    return np.asarray([hashlib.sha256(json.dumps(row.tolist(),ensure_ascii=False,separators=(',',':')).encode('utf8')).hexdigest()
        for row in a],dtype='U64')


def representatives(ids, groups):
    files.require(len(ids) == len(groups) and len(set(ids.tolist())) == len(ids),'unique identity metadata')
    members = {}
    for i,g in enumerate(groups.tolist()): members.setdefault(g,[]).append(i)
    ordered = sorted(members)
    selected = np.asarray([min(members[g],key=lambda i:str(ids[i])) for g in ordered],np.int64)
    return selected, [members[g] for g in ordered]


def freeze():
    pins = {}
    train, primary, primary_registry, baseline = (files.js(a,pins) for a in (TRAIN,PRIMARY,PRIMARY_REGISTRY,BASELINE))
    mat = files.js(train['material'],pins)
    training_registry = files.js(train['registry'],pins)
    files.require(train['execution_status'] == 'expandedFIT6000_MHFD_final80_known_evaluated'
        and train['epochs_completed'] == 80 and train['input_width'] == mat['input_width'] == 117
        and train['model_state_sha256'] == MODEL_SHA and train['counts']['unknown_forward'] == 0
        and train['runtime_restoration']['all_flags_restored'] is True,
        'actual completed new117 producer, including failed classifier BEN evidence')
    files.require(primary['updated_model_state_sha256'] == PRIMARY_SHA
        and primary['known_classifier_passed'] is True and primary['clean_classifier_threshold'] == .13647180795669556
        and train['policy']['classes'] == primary_registry['known_fine_classes'] == list(producer.FAMILIES),
        'exact frozen MAIN35e nine fine classes and order')
    files.require(baseline['execution_status'] == 'complete_native41_fresh2579_plus147_current3598_evaluated'
        and baseline['prediction_sealed'] is True and baseline['original_class_gates']['UNA']['correct'] == 2596,
        'preserved full genuine feature-derived2596 observed development producer')
    assets = dict(known_inputs=mat['encoded_inputs'],known_native=mat['known_source'],encoder=mat['encoder'],
        new_model=train['files']['model'],main_known=primary['updated_clean_material'],
        main_current=baseline['files']['147_same_fresh_main35e_outputs_before_guard'],
        current_native=baseline['files']['actual_native41_and_custody_before_guard'],
        baseline_and_truth_after_seal=baseline['comparison'],
        known_truth_after_seal=training_registry['assets']['original_encoded_labels'])
    for role in ('fit','calibration','open_known'):
        assets[role+'_auxiliary'] = train['files'][role+'_complete_all7_raw5_before_caller_guard']
    headers = {name:producer.metadata_headers(a,pins) for name,a in assets.items() if Path(a['path']).suffix == '.npz'}
    for role,n in ROLES.items():
        files.require(headers['known_inputs'][role+'_features']['shape'] == [n,117]
            and headers['known_native'][role+'_native41']['shape'] == [n,41]
            and headers['known_inputs'][role+'_ids'] == headers['known_native'][role+'_ids'], 'new7966 role headers:'+role)
    for role,n in (('fit',6000),('calibration',656),('open_known',654)):
        files.require(headers[role+'_auxiliary']['embedding32']['shape'] == [n,32]
            and set(COMPLETE_KEYS) == set(headers[role+'_auxiliary']), 'actual all7/raw5 new117 '+role)
    files.require(headers['current_native']['native41']['shape'] == [3598,41]
        and headers['current_native']['sample_id']['shape'] == [3598]
        and headers['main_current']['fine_probability']['shape'] == [3598,9], 'fixed original3598 current header')
    encoder = files.js(assets['encoder'],pins)
    columns = [c for g in encoder['original_field_groups'] for c in g['selected_columns']]
    files.require(columns == list(range(117)) and len(encoder['fields']) == 41,
        'actual full117 metadata order and all41 retained fields')
    for a in assets.values(): files.read(a,pins)
    sources = {Path(m.__file__).name:files.item(m.__file__) for m in
        (producer,encoding,learned,owned_dvc,model,producer.config,files,paper_route,paper_route.sealed)}
    sources['caller'] = files.item(__file__)
    for name,path in dict(pair_origin=learned.MATH_SOURCE_MODULE,DVC_origin=owned_dvc.DVC_SOURCE_MODULE,
        knee_math=owned_dvc.KNEE_SOURCE_MODULE,route_guards='paper_open_set/nsl_auth2188_frozen_conditional_blocks_warm_pair_v2.py').items():
        sources[name] = files.item(ROOT/path)
    files.require(sources['pair_origin']['sha256'] == learned.MATH_SOURCE_SHA256
        and sources['DVC_origin']['sha256'] == owned_dvc.DVC_SOURCE_SHA256
        and sources['knee_math']['sha256'] == owned_dvc.KNEE_SOURCE_SHA256,'unchanged inherited numerical provenance')
    reg = dict(schema_version=SCHEMA+'-registry',policy=recipe(),assets=assets,headers=headers,sources=sources,
        producer_report=TRAIN,material_report=train['material'],primary_report=PRIMARY,primary_registry=PRIMARY_REGISTRY,
        baseline_report=BASELINE,encoder_state_sha256=encoder['state_sha256'],
        primary_threshold=primary['clean_classifier_threshold'],
        auxiliary_inference_runtime=train['runtime_during_training'],
        producer_torch_version=files.js(train['files']['prefit'],pins)['runtime_environment']['torch_version'],
        producer_device=train['device'],output={phase:str(BASE/phase) for phase in ('prepare','known','current')},
        input_sha256=pins,actual_array_decodes=0,published=False,final_test_executed=False,status='FAIL_TARGET99')
    reg['registry_sha256'] = files.digest(reg)
    directory = ROOT/'tmp/nsl1_expandedaux149_20261009_v1';directory.mkdir(exist_ok=True)
    return files.write(directory/'registry_before_new_known149_parameters.json',reg)


def bind(path, sha, pins):
    a = dict(path=str(Path(path).resolve()),sha256=sha)
    reg = files.js(a,pins);unsigned = dict(reg); signature = unsigned.pop('registry_sha256')
    files.require(signature == files.digest(unsigned) and reg['policy'] == recipe()
        and reg['sources']['caller'] == files.item(__file__), 'own new149 registry/source/recipe')
    for item in reg['sources'].values(): files.read(item,pins)
    for p,h in reg['input_sha256'].items(): files.read(dict(path=p,sha256=h),pins)
    return a,reg


def start(reg, phase, registry):
    out = Path(reg['output'][phase])
    files.require(out == BASE/phase and not out.exists(),'fresh once-only new149 phase:'+phase)
    out.mkdir(parents=True)
    report = dict(schema_version=SCHEMA,phase=phase,registry=registry,policy=recipe(),files={},
        counts=dict(NN_retraining=0,primary_forward=0,auxiliary_unknown_forward=0,
            unit_fit=0,metric_fit=0,FIT_radius_fit=0,CAL_score=0,CAL_fit=0,query_score=0,DVC_calls=0),
        execution_status='not_completed',prediction_sealed=False,known_truth_opened=False,
        unknown_truth_opened=False,accepted_baseline_replaced=False,
        published=False,final_test_executed=False,source_admitted=False,status='FAIL_TARGET99')
    return out,report


def save(out,report,name,values):
    return producer.save(out,name,values,report)


def finish(out,report,pins,started):
    for p,h in pins.items(): files.require(files.item(p)['sha256'] == h,'all frozen source/input bytes unchanged')
    report['input_sha256'] = pins;report['wall_seconds'] = time.perf_counter()-started
    return files.write(out/'report.json',report)


def fit_units(embedding, selected, prefit_sha):
    a = np.asarray(embedding,np.float64)[selected]
    files.require(a.ndim == 2 and a.shape[1] == 32 and np.isfinite(a).all(),'finite unique FIT embedding32')
    largest = np.abs(a).max(axis=0);scale = np.ones(32,np.float64); nz = largest > 0
    scale[nz] = largest[nz]*np.sqrt(np.mean(np.square(a[:,nz]/largest[nz]),axis=0))
    state = dict(schema_version=SCHEMA+'-FIT-embedding32-units',scale=scale.tolist(),
        exactzero_columns=np.flatnonzero(~nz).tolist(),prefit_sha256=prefit_sha,
        FIT_unique_rows=len(selected),CAL_or_query_fit=False)
    state['state_sha256'] = files.digest(state)
    return state


def transform149(embedding, encoded, units):
    e,x = np.asarray(embedding),np.asarray(encoded)
    files.require(e.shape == (len(x),32) and x.shape == (len(x),117)
        and e.dtype.kind == x.dtype.kind == 'f' and np.isfinite(e).all() and np.isfinite(x).all(), 'new117+embedding32 coordinates')
    unsigned = dict(units);state_sha = unsigned.pop('state_sha256')
    files.require(files.digest(unsigned) == state_sha,'own FIT embedding-unit state digest')
    z = np.concatenate((e.astype(np.float64)/np.asarray(units['scale'],np.float64),x.astype(np.float64)),axis=1)
    files.require(z.shape == (len(x),149) and np.isfinite(z).all(),'finite exact149, no coordinate dropped')
    return z


def metric_kwargs(material):
    return dict(known_fine_labels=list(range(9)),fit_ids=material['fit_ids'].tolist(),
        fit_group_ids=material['fit_groups'].tolist(),fit_roles=['FIT']*len(material['fit_ids']))


def prepare(path,sha):
    started,pins = time.perf_counter(),{}
    registry,reg = bind(path,sha,pins);out,report = start(reg,'prepare',registry)
    try:
        a = reg['assets']
        inputs = archive(a['known_inputs'],tuple(r+'_'+k for r in ROLES for k in ('features','ids'))+('fit_known_fine',),pins)
        native = archive(a['known_native'],tuple(r+'_'+k for r in ROLES for k in ('native41','ids')),pins)
        main = archive(a['main_known'],tuple(r+'_'+k for r in ('calibration','open_known')
            for k in ('ids','attack_probability','fine_probability','predicted_coarse')),pins)
        embeddings = {r:archive(a[r+'_auxiliary'],('embedding32',),pins)['embedding32'] for r in ('fit','calibration','open_known')}
        save(out,report,'new_known_inputs_before_binding_guard',inputs)
        save(out,report,'new_known_native_before_binding_guard',native)
        save(out,report,'PRIMARY_known_outputs_before_binding_guard',main)
        save(out,report,'new117_known_embeddings_before_binding_guard',embeddings)
        material = dict(fit_fine=inputs['fit_known_fine'])
        for r,n in ROLES.items():
            files.require(inputs[r+'_features'].shape == (n,117) and native[r+'_native41'].shape == (n,41)
                and np.array_equal(inputs[r+'_ids'],native[r+'_ids']),'separate immutable new known role:'+r)
            if r in embeddings:
                material[r+'_ids'] = inputs[r+'_ids'];material[r+'_groups'] = group_hashes(native[r+'_native41'])
        for r in ('calibration','open_known'):
            files.require(np.array_equal(main[r+'_ids'],material[r+'_ids'])
                and np.array_equal(main[r+'_predicted_coarse'],(main[r+'_attack_probability'] >= reg['primary_threshold']).astype(np.int64)),
                'frozen original MAIN coarse and known role order:'+r)
            material[r+'_stage1'] = main[r+'_predicted_coarse']
            material[r+'_predicted_fine'] = main[r+'_fine_probability'].argmax(axis=1).astype(np.int64)
        selected,_ = representatives(material['fit_ids'],material['fit_groups'])
        plan = dict(schema_version=SCHEMA+'-embedding-unit-prefit',FIT_embedding=descriptor(embeddings['fit']),
            FIT_ids=descriptor(material['fit_ids']),FIT_groups=descriptor(material['fit_groups']),
            unique_FIT_representatives=selected.tolist(),unknown_used=False,CAL_used=False,only_original_FIT=True)
        plan['prefit_sha256'] = files.digest(plan)
        pa = files.write(out/'own_FIT_embedding_units_prefit_before_RMS.json',plan);report['files']['unit_prefit'] = pa
        plan = files.js(pa,pins);report['counts']['unit_fit'] = 1
        units = fit_units(embeddings['fit'],selected,plan['prefit_sha256'])
        ua = files.write(out/'new_unique_FIT_embedding32_units_before_metric.json',units);report['files']['units'] = ua
        units = files.js(ua,pins)
        for r in embeddings: material[r+'_Z149'] = transform149(embeddings[r],inputs[r+'_features'],units)
        ma = save(out,report,'prepared_new_known149_before_pair_prefit',material)
        prefit = learned.prefit_descriptor(material['fit_Z149'],material['fit_fine'],**metric_kwargs(material))
        pfa = files.write(out/'owned149_knownFIT_pair_prefit_before_metric_training.json',prefit)
        report['files']['metric_prefit'] = pfa
        seal = files.write(out/'known149_transform_units_pair_plan_seal.json',dict(registry=registry,
            material=ma,units=ua,pair_prefit=pfa,unknown_values_used=False,metric_fit_executed=False))
        report.update(execution_status='new_expandedaux149_known_material_prefit_sealed',
            prepared_material=ma,material_descriptors={k:descriptor(v) for k,v in material.items()},
            metric_prefit_sha256=prefit['prefit_sha256'],unit_state_sha256=units['state_sha256'],transform_seal=seal)
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally: result = finish(out,report,pins,started)
    return result


def make_reference(material):
    selected,members = representatives(material['fit_ids'],material['fit_groups'])
    membership = np.asarray([[np.any(material['fit_fine'][indices] == label) for label in range(9)] for indices in members],bool)
    files.require(membership.any(axis=0).all(),'all true known fine memberships retained')
    return dict(Z149=material['fit_Z149'][selected],known_fine_membership=membership,
        ids=material['fit_ids'][selected],groups=material['fit_groups'][selected],original_indices=selected)


def fit_radii(metric,reference,sink):
    radii = np.zeros(reference['known_fine_membership'].shape,np.float64)
    for label in range(9):
        selected = np.flatnonzero(reference['known_fine_membership'][:,label])
        files.require(len(selected) >= 2,'two genuine samefine FIT groups')
        d = metric.pairwise_distances(reference['Z149'][selected])
        sink(label,dict(reference_indices=selected,distances=d))
        files.require(np.isfinite(d).all() and np.all(d >= 0),'finite saved FIT distances')
        np.fill_diagonal(d,np.inf);k = min(7,len(selected)-1)
        radii[selected,label] = np.partition(d,k-1,axis=1)[:,k-1]
    files.require(np.isfinite(radii).all() and np.all(radii >= 0),'natural FIT-only R7')
    return radii


def scores(metric,z,predicted_fine,reference,radii,sink):
    result = np.empty(len(z),np.float64)
    files.require(metric.dimension == 149 and z.shape == (len(predicted_fine),149)
        and np.isin(predicted_fine,range(9)).all(),'new149 distance and genuine MAIN fine decisions')
    for label in np.unique(predicted_fine):
        rows = np.flatnonzero(predicted_fine == label)
        selected = np.flatnonzero(reference['known_fine_membership'][:,label])
        d = metric.pairwise_distances(z[rows],reference['Z149'][selected])
        sink(int(label),dict(query_indices=rows,reference_indices=selected,distances=d))
        files.require(np.isfinite(d).all() and np.all(d >= 0),'saved finite query/reference distances')
        nearest = d.min(axis=1)
        radius = np.max(np.where(d == nearest[:,None],radii[selected,label][None,:],-1),axis=1)
        scale = np.maximum(nearest,radius);nz = scale > 0;value = np.zeros(len(rows),np.float64)
        left,right = nearest[nz]/scale[nz],radius[nz]/scale[nz]
        value[nz] = left*left/(left*left+right*right);result[rows] = value
    files.require(np.isfinite(result).all() and np.all((result >= 0)&(result <= 1)),'finite natural local-radius scores')
    return result


def route_once(metric,query,raw,sink):
    members = {}
    for i,g in enumerate(query['groups'].tolist()): members.setdefault(g,[]).append(i)
    selected = np.asarray([next((i for i in indices if raw[i]),indices[0]) for indices in members.values()],np.int64)
    number = {g:i for i,g in enumerate(members)}
    inverse = np.asarray([number[g] for g in query['groups'].tolist()],np.int64)
    reduced = owned_dvc.route_current_candidates(metric,query['Z149'][selected],raw[selected],seed=20261009)
    sink('representatives',{k:v for k,v in reduced.items() if k != 'manifest'},reduced['manifest'])
    route = {}
    for key in ('first','second','suspected','reconstruction','density','anomaly'):
        v = np.asarray(reduced[key])[inverse].copy();v[~raw] = -2 if key in ('first','second') else 0;route[key] = v
    route.update(retained=raw & reduced['retained'][inverse],density_representative_indices=selected,
        original_to_density_representative=inverse)
    manifest = dict(reduced['manifest'],schema_version=SCHEMA+'-DVC',metric_dimension=149,
        original_query_flows=len(raw),original_raw_flows=int(raw.sum()),original_retained_flows=int(route['retained'].sum()),
        native41_density_groups=len(selected),duplicates_excluded_from_density=len(raw)-len(selected),report_copies_in_density=0)
    sink('original_flows',route,manifest)
    return route,manifest


def merge(baseline,raw,retained):
    b,r,k = map(np.asarray,(baseline,raw,retained))
    files.require(b.ndim == 1 and b.dtype.kind in 'iu' and np.isin(b,(0,1,2)).all()
        and b.shape == r.shape == k.shape and r.dtype == k.dtype == bool and np.all(~k|r), 'same-row baseline and own supplementary outputs')
    p = b.copy();p[r&k] = 2
    files.require(np.all(p[b == 2] == 2) and np.array_equal(p[~(r&k)],b[~(r&k)]),'preserve complete old baseline')
    return p


def gates(y,p,full=False):
    names = ('BEN','KNA','UNA') if full else ('BEN','KNA')
    expected = (319,335,2944) if full else (319,335)
    result = {}
    for label,(name,n) in enumerate(zip(names,expected)):
        support = int((y == label).sum());correct = int(((y == label)&(p == label)).sum())
        files.require(support == n,'fixed original support:'+name)
        required = (99*support+99)//100
        result[name] = dict(correct=correct,support=support,required=required,passed=correct >= required)
    return result


def delta(y,p,b,full=False):
    current,prior = gates(y,p,full),gates(y,b,full)
    changes = {name:current[name]['correct']-prior[name]['correct'] for name in current}
    verdict = ('UP' if all(v >= 0 for v in changes.values()) and any(changes.values()) else
        'DOWN' if all(v <= 0 for v in changes.values()) and any(changes.values()) else
        'UNCHANGED' if not any(changes.values()) else 'MIXED')
    gain_loss = {name:dict(gain=int(((y == label)&(b != label)&(p == label)).sum()),
        loss=int(((y == label)&(b == label)&(p != label)).sum())) for label,name in enumerate(current)}
    return dict(verdict=verdict,correct_count_delta=changes,gain_loss=gain_loss,
        baseline_used_for_prediction=True,truth_used_for_prediction=False,same_ID_order=True),current,prior


def load_prepared(registry,reg,path,sha,pins):
    a = dict(path=str(Path(path).resolve()),sha256=sha);prepared = files.js(a,pins)
    files.require(a['path'] == str(Path(reg['output']['prepare'])/'report.json')
        and prepared['registry'] == registry and prepared['execution_status'] == 'new_expandedaux149_known_material_prefit_sealed',
        'exact new149 external known preparation')
    material = archive(prepared['prepared_material'],tuple(prepared['material_descriptors']),pins)
    files.require({k:descriptor(v) for k,v in material.items()} == prepared['material_descriptors'],'unchanged externally prepared known149')
    return a,prepared,material


def known(path,sha,preparation_path,preparation_sha):
    started,pins = time.perf_counter(),{}
    registry,reg = bind(path,sha,pins);pa,prepared,material = load_prepared(registry,reg,preparation_path,preparation_sha,pins)
    out,report = start(reg,'known',registry);report['preparation'] = pa
    try:
        pfa = prepared['files']['metric_prefit'];prefit = files.js(pfa,pins)
        report['counts']['metric_fit'] = 1
        metric = learned.fit_known_metric(material['fit_Z149'],material['fit_fine'],expected_prefit_sha256=prefit['prefit_sha256'],**metric_kwargs(material))
        met_a = files.write(out/'owned149_metric_state_before_CAL_or_query.json',metric.to_state());report['files']['metric'] = met_a
        metric = learned.PaperVariationalPairMetric.from_state(files.js(met_a,pins))
        files.require(metric.dimension == 149 and metric.to_state()['prefit_descriptor'] == prefit,'new149 persisted FIT-only metric, no old state')
        reference = make_reference(material);ref_a = save(out,report,'unique_genuine_FIT149_reference_before_radius',reference)
        report['files']['reference'] = ref_a;report['counts']['FIT_radius_fit'] = 1
        radii = fit_radii(metric,reference,lambda label,v:save(out,report,'FIT_fine'+str(label)+'_returned_distances',v))
        rad_a = save(out,report,'FIT149_radii_before_CAL',dict(radii=radii));report['files']['radii'] = rad_a
        radseal = files.write(out/'FIT149_reference_radius_seal_before_CAL.json',dict(metric=met_a,reference=ref_a,radii=rad_a,FIT_only=True,query_used=False))
        report['files']['radius_seal'] = radseal
        report['counts']['CAL_score'] = 1
        cal_score = scores(metric,material['calibration_Z149'],material['calibration_predicted_fine'],reference,radii,
            lambda label,v:save(out,report,'CAL_fine'+str(label)+'_returned_distances',v))
        save(out,report,'CAL149_scores_before_cutoffs',dict(score=cal_score,stage1=material['calibration_stage1']))
        cut = paper_route.calibrate_known_cutoffs(cal_score,material['calibration_stage1'])
        cut_a = files.write(out/'knownCAL656_149_cutoffs_before_OPEN654.json',dict(cutoffs=cut,radius_seal=radseal,query_used=False,original_CAL_rows=656))
        report['files']['calibration'] = cut_a;cut = files.js(cut_a,pins)['cutoffs'];report['counts']['CAL_fit'] = 1
        query = dict(Z149=material['open_known_Z149'],groups=material['open_known_groups'],stage1=material['open_known_stage1'])
        report['counts']['query_score'] = 1
        score = scores(metric,query['Z149'],material['open_known_predicted_fine'],reference,radii,
            lambda label,v:save(out,report,'OPEN_fine'+str(label)+'_returned_distances',v))
        raw = paper_route.candidate_mask(score,query['stage1'],cut)
        save(out,report,'known654_scores_raw_before_DVC',dict(score=score,raw=raw,stage1=query['stage1']))
        def sink(name,v,manifest):
            save(out,report,'known654_'+name+'_DVC_before_guard',v)
            report['files']['route_'+name] = files.write(out/('known654_'+name+'_DVC_manifest.json'),manifest)
        report['counts']['DVC_calls'] = 1
        route,_ = route_once(metric,query,raw,sink)
        # Fixed original prefix is bound by custody IDs, not by label lookup.
        ids = archive(reg['assets']['current_native'],('sample_id',),pins)['sample_id']
        files.require(np.array_equal(ids[:654],material['open_known_ids']),'original654 known prefix before numerical query features')
        baseline = archive(reg['assets']['baseline_and_truth_after_seal'],('fresh_increment',),pins)['fresh_increment'][:654]
        prediction = merge(baseline,raw,route['retained'])
        pred_a = save(out,report,'complete_known654_increment_before_truth',dict(ids=material['open_known_ids'],prediction=prediction,baseline=baseline,raw=raw,retained=route['retained']))
        seal = files.write(out/'known654_prediction_seal_before_truth.json',dict(prediction=pred_a,registry=registry,metric=met_a,CAL=cut_a,truth_opened=False))
        report['files']['prediction_seal'] = seal;files.js(seal,pins);report['prediction_sealed'] = True
        truth = archive(reg['assets']['known_truth_after_seal'],('open_known_ids','open_known_known_coarse'),pins)
        report['known_truth_opened'] = True
        files.require(np.array_equal(truth['open_known_ids'],material['open_known_ids']),'same original known654 truth custody')
        y = truth['open_known_known_coarse'];effect,current,prior = delta(y,prediction,baseline)
        paired_ok = all(effect['gain_loss'][name]['loss'] == 0 for name in ('BEN','KNA'))
        integer_ok = all(v['passed'] for v in current.values())
        save(out,report,'postseal_known654_comparison',dict(ids=material['open_known_ids'],truth=y,prediction=prediction,baseline=baseline,raw=raw,retained=route['retained']))
        report.update(execution_status='new_expandedaux149_known_no_loss_gate_evaluated',original_class_gates=current,
            baseline_class_gates=prior,EffectDelta=effect,paired_known_no_loss=paired_ok,known_integer99_passed=integer_ok,
            known_gate_passed=paired_ok and integer_ok,known_raw=int(raw.sum()),known_retained=int(route['retained'].sum()),
            metric_state_sha256=metric.state_sha256,current_unknown_feature_decodes=0,unknown_inference=0,
            parameter_fit_scope='new true FIT6000 and knownCAL656 only',primary_classification_unchanged=True)
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally: result = finish(out,report,pins,started)
    return result


def infer_unknown_once(net,encoded,out,report):
    captured=[];before=producer.output_io.state_digest(net);flags={n:p.requires_grad for n,p in net.named_parameters()}
    def hook(module,args,returned):
        arrays={k:v.detach().float().cpu().numpy().copy() for k,v in returned.items()}
        save(out,report,'unknown2944_raw5_batch'+str(len(captured))+'_before_caller_guard',arrays);captured.append(arrays)
    handle=net.register_forward_hook(hook);report['counts']['auxiliary_unknown_forward']=1
    try: result=model.infer(net,encoded,device=next(net.parameters()).device,batch_size=2048)
    finally: handle.remove()
    values={k:np.asarray(v).copy() for k,v in vars(result).items()};values['embedding32']=values['embedding'].copy()
    for key in producer.RAW_FIELDS:values['raw_'+key]=np.concatenate([a[key] for a in captured])
    save(out,report,'unknown2944_complete_all7_raw5_before_caller_guard',values)
    files.require(set(values)==set(COMPLETE_KEYS) and len(captured)==2
        and all(set(a)==producer.RAW_FIELDS for a in captured)
        and all(len(v)==len(encoded) and np.isfinite(v).all() for v in values.values())
        and flags=={n:p.requires_grad for n,p in net.named_parameters()}
        and producer.output_io.state_digest(net)==before and net.training is False,
        'actual unknown-only real117 outputs complete, weights and flags unchanged')
    report['auxiliary_unknown_batch_lengths']=[len(a['embedding']) for a in captured]
    return values


def current(path,sha,known_path,known_sha):
    started,pins=time.perf_counter(),{}
    registry,reg=bind(path,sha,pins)
    ka=dict(path=str(Path(known_path).resolve()),sha256=known_sha);kr=files.js(ka,pins)
    files.require(ka['path']==str(Path(reg['output']['known'])/'report.json') and kr['registry']==registry
        and kr['execution_status']=='new_expandedaux149_known_no_loss_gate_evaluated'
        and kr['known_gate_passed'] is True,'known integer99 and zero-loss gate before current unknown features or NN')
    pa,prepared,material=load_prepared(registry,reg,kr['preparation']['path'],kr['preparation']['sha256'],pins)
    out,report=start(reg,'current',registry);report['known_report']=ka
    before_runtime=producer.capture_runtime_flags();report['runtime_before']=before_runtime
    try:
        a=reg['assets'];native=archive(a['current_native'],('native41','sample_id'),pins)
        save(out,report,'actual_original3598_native41_and_IDs_before_guard',native)
        x,ids=native['native41'],native['sample_id']
        files.require(x.shape==(3598,41) and x.dtype.kind==ids.dtype.kind=='U'
            and len(set(ids.tolist()))==3598 and np.array_equal(ids[:654],material['open_known_ids']),
            'fixed original3598 native rows and identity custody only')
        encoder=files.js(a['encoder'],pins);units=files.js(prepared['files']['units'],pins)
        encoded=encoding.encode_native(x,encoder)
        save(out,report,'actual_current_encoded117_before_new_inference',dict(encoded117=encoded))
        inputs=archive(a['known_inputs'],('open_known_features',),pins)
        files.require(encoder['state_sha256']==reg['encoder_state_sha256'] and encoded.shape==(3598,117)
            and np.array_equal(encoded[:654],inputs['open_known_features']), 'same new117 encoder and exact known654 input prefix')
        runtime=reg['auxiliary_inference_runtime']
        files.require(before_runtime['CUBLAS_WORKSPACE_CONFIG']==runtime['CUBLAS_WORKSPACE_CONFIG']==':4096:8'
            and str(torch.__version__)==reg['producer_torch_version'] and reg['producer_device']=='cuda'
            and torch.cuda.is_available(),'same actual new117 CUDA producer environment; no CPU fallback')
        torch.set_num_threads(4);model.set_seed(producer.SEED)
        torch.set_float32_matmul_precision(runtime['float32_matmul_precision'])
        torch.backends.cuda.matmul.allow_tf32=runtime['cuda_matmul_allow_tf32']
        torch.backends.cudnn.allow_tf32=runtime['cudnn_allow_tf32']
        during=producer.capture_runtime_flags();report['runtime_during_inference']=during
        files.require(all(during[k]==runtime[k] for k in runtime),
            'same deterministic/cuDNN/TF32 producer conditions')
        checkpoint=torch.load(io.BytesIO(files.read(a['new_model'],pins)),map_location='cpu',weights_only=True)
        files.require(checkpoint['input_dim']==117 and checkpoint['fine_classes']==list(producer.FAMILIES)
            and checkpoint['epochs_completed']==80 and checkpoint['model_state_sha256']==MODEL_SHA,'new117 checkpoint identity')
        net=model.MHFDNetwork(117,9).to(torch.device('cuda'));net.load_state_dict(checkpoint['state_dict'],strict=True);net.eval()
        files.require(producer.output_io.state_digest(net)==MODEL_SHA and all(p.requires_grad for p in net.parameters()),
            'new117 unchanged real trained state and original grad flags')
        unknown=infer_unknown_once(net,encoded[654:],out,report)
        cached=archive(a['open_known_auxiliary'],COMPLETE_KEYS,pins)
        full={k:np.concatenate((cached[k],unknown[k]),axis=0) for k in COMPLETE_KEYS}
        save(out,report,'complete_original3598_new117_all7_raw5_before_geometry',full)
        main=archive(a['main_current'],('attack_probability','fine_probability','stage1'),pins)
        save(out,report,'frozen_PRIMARY_current_outputs_before_guard',main)
        stage1,predicted_fine=main['stage1'],main['fine_probability'].argmax(axis=1).astype(np.int64)
        files.require(np.array_equal(stage1,(main['attack_probability']>=reg['primary_threshold']).astype(np.int64))
            and np.array_equal(stage1[:654],material['open_known_stage1'])
            and np.array_equal(predicted_fine[:654],material['open_known_predicted_fine']),
            'same genuine MAIN fine/coarse semantics for CAL,known and current; auxiliary heads never replace MAIN')
        query=dict(ids=ids,groups=group_hashes(x),Z149=transform149(full['embedding32'],encoded,units),
            stage1=stage1,predicted_fine=predicted_fine)
        save(out,report,'actual_current149_geometry_before_score',query)
        files.require(np.array_equal(query['Z149'][:654],material['open_known_Z149']),'same cached real new117 known654 geometry prefix')
        metric=learned.PaperVariationalPairMetric.from_state(files.js(kr['files']['metric'],pins))
        reference=archive(kr['files']['reference'],('Z149','known_fine_membership','ids','groups','original_indices'),pins)
        radii=archive(kr['files']['radii'],('radii',),pins)['radii'];cut=files.js(kr['files']['calibration'],pins)['cutoffs']
        report['counts']['query_score']=1
        score=scores(metric,query['Z149'],predicted_fine,reference,radii,
            lambda label,v:save(out,report,'current_fine'+str(label)+'_returned_distances',v))
        raw=paper_route.candidate_mask(score,stage1,cut)
        save(out,report,'actual_current149_scores_raw_before_DVC',dict(score=score,raw=raw,stage1=stage1))
        def sink(name,v,manifest):
            save(out,report,'current3598_'+name+'_DVC_before_guard',v)
            report['files']['route_'+name]=files.write(out/('current3598_'+name+'_DVC_manifest.json'),manifest)
        report['counts']['DVC_calls']=1;route,_=route_once(metric,query,raw,sink)
        baseline=archive(a['baseline_and_truth_after_seal'],('fresh_increment',),pins)['fresh_increment']
        prediction=merge(baseline,raw,route['retained'])
        pred_a=save(out,report,'complete_current3598_increment_before_truth',
            dict(ids=ids,prediction=prediction,baseline=baseline,raw=raw,retained=route['retained']))
        seal=files.write(out/'complete_current3598_prediction_seal_before_truth.json',dict(prediction=pred_a,registry=registry,
            metric=kr['files']['metric'],CAL=kr['files']['calibration'],known_gate_report=ka,truth_opened=False))
        report['files']['prediction_seal']=seal;files.js(seal,pins);report['prediction_sealed']=True
        truth=archive(a['baseline_and_truth_after_seal'],('ids','truth'),pins);report['unknown_truth_opened']=True
        files.require(np.array_equal(truth['ids'],ids),'unchanged original3598 truth ID order after seal')
        effect,current_gates,prior=delta(truth['truth'],prediction,baseline,full=True)
        save(out,report,'postseal_same3598_incremental_comparison',dict(**truth,prediction=prediction,baseline=baseline,raw=raw,retained=route['retained']))
        paired_ok=all(effect['gain_loss'][name]['loss']==0 for name in ('BEN','KNA'))
        report.update(execution_status='new_expandedaux149_preserved2596_current3598_evaluated',
            original_class_gates=current_gates,baseline_class_gates=prior,EffectDelta=effect,
            paired_known_no_loss=paired_ok,all_three_integer99_passed=all(v['passed'] for v in current_gates.values()),
            DEV_review_eligible=effect['verdict']=='UP' and paired_ok,
            known_raw=int(raw[:654].sum()),known_retained=int(route['retained'][:654].sum()),
            unknown_raw=int(raw[654:].sum()),unknown_retained=int(route['retained'][654:].sum()),
            metric_state_sha256=metric.state_sha256,auxiliary_classifier_used=False,
            new_parameter_fit_in_current=0,independent_unknown_DEV_measured=False)
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        restored=producer.restore_runtime_flags(before_runtime)
        report['runtime_restoration']=dict(before=before_runtime,after=restored,all_flags_restored=before_runtime==restored)
        result=finish(out,report,pins,started)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=('freeze','prepare','known','current'),required=True)
    parser.add_argument('--registry');parser.add_argument('--registry-sha256')
    parser.add_argument('--preparation-report');parser.add_argument('--preparation-sha256')
    parser.add_argument('--known-report');parser.add_argument('--known-sha256');args=parser.parse_args()
    if args.phase=='freeze':result=freeze()
    elif args.phase=='prepare':result=prepare(args.registry,args.registry_sha256)
    elif args.phase=='known':result=known(args.registry,args.registry_sha256,args.preparation_report,args.preparation_sha256)
    else:result=current(args.registry,args.registry_sha256,args.known_report,args.known_sha256)
    print(json.dumps(result))
