"""One exact original-field point-mass support candidate beside NSL1 2604.

Only genuine knownFIT6000 whole-field constants are fitted. Originalfloat32
encoded values are compared exactly, with no epsilon. Known attack support is
the union of all eight true-known-fine profiles. Density uses own candidates
plus prior predicted UNA; only own retained candidates can extend the baseline.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import time
import numpy as np
from . import nsl1_known_gmm117_residual_v47 as previous_candidate
from .paired_integer_gate_status_v1 import gate_status

ROOT,files,previous = previous_candidate.ROOT,previous_candidate.files,previous_candidate.previous
BASE = ROOT/'data/external_dev/processed/nsl1_constant_support_20261011_v47'
REGISTRY = ROOT/'tmp/nsl1_constant_support_20261011_v47/registry_before_known_constant_support_fit.json'
PARENT = dict(path=str(previous_candidate.BASE/'current/report.json'),sha256='21320fb06a2ddeed1a799bfb40d4b0c25d43cfc61da52be667d485d393e5c244')
SCHEMA = 'NSL1-preserved2604-exact-original41-field-constant-support-union-v47'


def recipe():
    return dict(schema_version=SCHEMA,setting='NSL-KDD Setting1',FIT_original=6000,FIT_copies=0,
        input='original complete117 float32 encoded native41; all field groups from sealed encoder',
        profile='each true known fine requires >=20 genuineFIT rows; whole field constant iff every encoded column is identical in all classFIT rows',
        violation='integer count of whole constant fields with any encoded coordinate exactly unequal to its FIT pattern',
        coarse_BEN='use knownBENfine0 violation count',coarse_KNA='minimum violation count across all eight knownattackfine profiles, known class support union',
        query_fine_or_truth_or_ID_in_score=False,epsilon_or_tolerance=False,score_clamp=False,
        CAL='one knownCAL656 original MAIN-predictedcoarse finite99 strictgreater on integer field-count score; tie/disabled state disclosed',
        density_members='own raw OR complete baseline2604 predictedUNA, native group deduplication with original149 route; no family copies',
        DVC='unchanged frozen learned149 metric, candidate/centre/secondary affinity and noise',
        merge='copy complete2604; append UNA only for own raw AND own same-query DVC-retained',
        known_gate='actual current654 numeric prefix only; BEN/KNA exact integer99 and zero paired correct losses before unknown geometry tail decode',
        original2601_2602_2604_immutable=True,NN_forward=0,NN_training=0,PCA_fit=0,GMM_fit=0,metric_fit=0,
        reference_fit=0,units_fit=0,query_profile_or_cutoff_fit=False,formula_count=1,threshold_grid=False,
        exact_original_paper_pointmass_formula_claim=False,current_scope='original3598 already observed development',
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)


def field_groups(encoder):
    unsigned = dict(encoder);signature = unsigned.pop('state_sha256')
    files.require(signature == files.digest(unsigned) and encoder['input_width'] == 117
        and encoder['no_variance_pruning'] and encoder['no_target_fit'],'exact sealed original all117 encoder')
    groups = encoder['original_field_groups']
    columns = [c for g in groups for c in g['selected_columns']]
    files.require(len(groups) == 41 and [g['field'] for g in groups] == encoder['fields']
        and sorted(columns) == list(range(117)) and all(g['selected_columns'] for g in groups),
        'exact whole41 field partition, every encoded117 coordinate once')
    return groups


def freeze():
    pins = {};parent = files.js(PARENT,pins);old = files.js(parent['registry'],pins)
    files.require(parent['known_gate_passed'] and parent['prediction_sealed'] and parent['EffectDelta']['verdict'] == 'UP'
        and parent['original_class_gates']['BEN']['correct'] == 317
        and parent['original_class_gates']['KNA']['correct'] == 335
        and parent['original_class_gates']['UNA']['correct'] == 2604,'completed full2604 baseline with known zero loss')
    assets = {k:old['assets'][k] for k in ('encoded','encoder','prepared','query_geometry','metric')}
    assets['baseline'] = parent['files']['postseal_comparison']
    groups = field_groups(files.js(assets['encoder'],pins))
    headers = {k:previous_candidate.latent.producer.metadata_headers(a,pins) for k,a in assets.items() if Path(a['path']).suffix == '.npz'}
    files.require(headers['encoded']['fit_features']['shape'] == [6000,117]
        and headers['encoded']['fit_features']['dtype'] == '<f4'
        and headers['encoded']['calibration_features']['shape'] == [656,117]
        and headers['query_geometry']['Z149']['shape'] == [3598,149]
        and headers['baseline']['prediction']['shape'] == [3598],'explicit original encoded/known/query/baseline headers')
    for a in assets.values():files.read(a,pins)
    sources = dict(old['sources']);sources['previous_residual_caller'] = files.item(previous_candidate.__file__);sources['caller'] = files.item(__file__)
    for a in sources.values():files.read(a,pins)
    reg = dict(schema_version=SCHEMA+'-registry',policy=recipe(),sources=sources,assets=assets,
        parent2604_report=PARENT,headers=headers,groups=groups,material_descriptors=old['material_descriptors'],
        metric_state_sha256=previous.METRIC_STATE_SHA,fine_order=old['fine_order'],
        output={p:str(BASE/p) for p in ('known','current')},input_sha256=pins,numeric_array_decodes=0,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    reg['registry_sha256'] = files.digest(reg);REGISTRY.parent.mkdir(exist_ok=True)
    files.require(not REGISTRY.exists(),'fresh once-only constant support registration');return files.write(REGISTRY,reg)


def bind(path,sha,pins):
    ref = dict(path=str(Path(path).resolve()),sha256=sha);reg = files.js(ref,pins)
    unsigned = dict(reg);signature = unsigned.pop('registry_sha256')
    files.require(signature == files.digest(unsigned) and reg['policy'] == recipe()
        and reg['sources']['caller'] == files.item(__file__),'one frozen exact constant support recipe/source')
    for a in reg['sources'].values():files.read(a,pins)
    for p,h in reg['input_sha256'].items():files.read(dict(path=p,sha256=h),pins)
    return ref,reg


def original_float32(x):
    values = np.asarray(x);cast = np.asarray(values,np.float32)
    files.require(values.ndim == 2 and values.shape[1] == 117 and np.isfinite(values).all()
        and np.array_equal(cast.astype(values.dtype),values),'exact originalfloat32 encoded117, no rounding repair')
    return cast


def fit_profiles(x,y,groups):
    x = original_float32(x);y = np.asarray(y)
    files.require(x.shape == (6000,117) and y.shape == (6000,) and set(y.tolist()) == set(range(9)),
        'all nine trueknown originalFIT6000 profiles')
    constant = np.zeros((9,41),bool);patterns = np.empty((9,117),np.float32);support = np.empty(9,np.int64)
    summaries = {}
    for label in range(9):
        rows = x[y == label];support[label] = len(rows)
        files.require(len(rows) >= 20,'genuine trueknownfine support >=20:'+str(label))
        patterns[label] = rows[0]
        for field,g in enumerate(groups):
            cols = g['selected_columns'];constant[label,field] = np.all(rows[:,cols] == rows[:1,cols])
        summaries[str(label)] = dict(trueFIT_rows=len(rows),whole_constant_fields=int(constant[label].sum()),
            constant_field_names=[g['field'] for field,g in enumerate(groups) if constant[label,field]])
    return dict(constant_fields=constant,patterns=patterns,class_support=support),summaries


def score(profile,x,coarse,groups):
    x = original_float32(x);coarse = np.asarray(coarse)
    files.require(coarse.shape == (len(x),) and np.isin(coarse,(0,1)).all(),'original MAIN coarse decision only')
    violations = np.zeros((len(x),9),np.int64)
    for label in range(9):
        for field,g in enumerate(groups):
            if profile['constant_fields'][label,field]:
                cols = g['selected_columns']
                violations[:,label] += np.any(x[:,cols] != profile['patterns'][label,cols],axis=1)
    result = np.where(coarse == 0,violations[:,0],violations[:,1:].min(axis=1))
    files.require(result.dtype == np.int64 and np.all((result >= 0)&(result <= 41)),'finite exact integer wholefield count')
    return dict(score=result,all_known_fine_violations=violations)


def save(out,report,name,value):return previous.save(out,report,name,value)


def run(phase,path,sha,known_path=None,known_sha=None):
    started,pins = time.perf_counter(),{};ref,reg = bind(path,sha,pins)
    if phase == 'current':
        kref = dict(path=str(Path(known_path).resolve()),sha256=known_sha);kr = files.js(kref,pins)
        files.require(kref['path'] == str(BASE/'known/report.json') and kr['registry'] == ref
            and kr['known_gate_passed'] and kr['unknown_query_numeric_rows_decoded'] == 0,'new exact known gate before full query')
    out = Path(reg['output'][phase]);files.require(not out.exists(),'fresh once-only constant support phase');out.mkdir(parents=True)
    report = dict(schema_version=SCHEMA,phase=phase,registry=ref,policy=recipe(),files={},
        counts=dict(constant_profile_fit=0,CAL_fit=0,query_score=0,DVC=0,NN_forward=0,NN_training=0,PCA_fit=0,GMM_fit=0,metric_fit=0,reference_fit=0,units_fit=0),
        prediction_sealed=False,known_truth_opened=False,unknown_truth_opened=False,unknown_query_numeric_rows_decoded=0,
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        prepared = previous.archive(reg['assets']['prepared'],tuple(reg['material_descriptors']),pins)
        files.require({k:previous.descriptor(v) for k,v in prepared.items()} == reg['material_descriptors'],'frozen genuine149 known geometry')
        groups = field_groups(files.js(reg['assets']['encoder'],pins));files.require(groups == reg['groups'],'original41 group recipe unchanged')
        if phase == 'known':
            encoded = previous.archive(reg['assets']['encoded'],('fit_features','fit_known_fine','fit_ids','calibration_features','calibration_ids'),pins)
            files.require(len(set(encoded['fit_ids'].tolist())) == 6000 and np.array_equal(encoded['fit_ids'],prepared['fit_ids'])
                and np.array_equal(encoded['fit_known_fine'],prepared['fit_fine']) and np.array_equal(encoded['fit_features'],prepared['fit_Z149'][:,32:])
                and np.array_equal(encoded['calibration_ids'],prepared['calibration_ids'])
                and np.array_equal(encoded['calibration_features'],prepared['calibration_Z149'][:,32:]),'unique original trueFIT6000 and CAL656 exact context')
            query = previous.prefix_archive(reg['assets']['query_geometry'],('ids','groups','Z149','stage1','predicted_fine'),654,pins)
            files.require(np.array_equal(query['ids'],prepared['open_known_ids']) and np.array_equal(query['Z149'],prepared['open_known_Z149'])
                and np.array_equal(query['groups'],prepared['open_known_groups']) and np.array_equal(query['stage1'],prepared['open_known_stage1']),
                'actual currentknown654 exact prefix only')
            profile,summaries = fit_profiles(encoded['fit_features'],encoded['fit_known_fine'],groups)
            report['counts']['constant_profile_fit'] = 1;report['profile_fit_summary'] = summaries;report['profile_state_members'] = list(profile)
            report['FIT_original_rows'] = 6000;report['FIT_copies'] = 0
            state_asset = save(out,report,'FIT_only_whole41_constant_profiles_before_CAL',profile);report['files']['profile_state'] = state_asset
            report['files']['FIT_profile_seal'] = files.write(out/'FIT_only_constant_profile_seal_before_CAL.json',dict(profile=state_asset,registry=ref,FIT_only=True,CAL_used=False,query_used=False))
            cal = score(profile,encoded['calibration_features'],prepared['calibration_stage1'],groups)
            save(out,report,'CAL656_constant_field_counts_before_cutoff',dict(**cal,stage1=prepared['calibration_stage1']))
            cut = previous.paper_route.calibrate_known_cutoffs(cal['score'],prepared['calibration_stage1'])
            report['files']['calibration'] = files.write(out/'knownCAL656_integer_constant_field_cutoff_before_known654.json',dict(cutoffs=cut,query_used=False,original_CAL_rows=656,registry=ref,profile=state_asset))
            report['counts']['CAL_fit'] = 1;save(out,report,'actual_current_known654_geometry_before_score',query)
        else:
            query = previous.archive(reg['assets']['query_geometry'],('ids','groups','Z149','stage1','predicted_fine'),pins);report['unknown_query_numeric_rows_decoded'] = 2944
            saved = previous.archive(kr['files']['actual_current_known654_geometry_before_score'],('ids','groups','Z149','stage1','predicted_fine'),pins)
            files.require(query['Z149'].shape == (3598,149) and len(set(query['ids'].tolist())) == 3598
                and all(np.array_equal(query[k][:654],saved[k]) for k in saved),'same original3598 IDs and exact actualknown prefix')
            profile = previous.archive(kr['files']['profile_state'],tuple(kr['profile_state_members']),pins)
            report['files']['profile_state'] = kr['files']['profile_state'];report['profile_state_members'] = kr['profile_state_members']
            report['known_report'] = kref;report['files']['calibration'] = kr['files']['calibration']
            cut = files.js(kr['files']['calibration'],pins)['cutoffs'];save(out,report,'actual_current3598_geometry_before_score',query)
        baseline = previous.prefix_archive(reg['assets']['baseline'],('prediction',),654,pins)['prediction'] if phase == 'known' else previous.archive(reg['assets']['baseline'],('prediction',),pins)['prediction']
        live = score(profile,query['Z149'][:,32:],query['stage1'],groups)
        raw = previous.paper_route.candidate_mask(live['score'],query['stage1'],cut);density = raw|(baseline == 2)
        report['counts']['query_score'] = 1;save(out,report,'new_integer_constant_field_candidates_before_DVC',dict(**live,raw=raw,density=density,stage1=query['stage1']))
        metric = previous.load_metric(reg,pins)
        def sink(name,value,manifest):
            save(out,report,name+'_DVC_result',value);report['files'][name+'_DVC_manifest'] = files.write(out/(name+'_DVC_manifest.json'),manifest)
        report['counts']['DVC'] = 1;route,_ = previous.route_once(metric,query,density,sink);own_retained = raw&route['retained']
        pred = previous.merge(baseline,raw,own_retained)
        pa = save(out,report,'prediction_before_truth',dict(ids=query['ids'],prediction=pred,baseline=baseline,raw=raw,density=density,retained=own_retained,density_retained=route['retained']))
        report['files']['prediction_seal'] = files.write(out/'prediction_seal_before_truth.json',dict(prediction=pa,registry=ref,metric=reg['assets']['metric'],profile=report['files']['profile_state'],CAL=report['files']['calibration'],truth_opened=False));report['prediction_sealed'] = True
        truth = previous.prefix_archive(reg['assets']['baseline'],('ids','truth'),654,pins) if phase == 'known' else previous.archive(reg['assets']['baseline'],('ids','truth'),pins)
        report['known_truth_opened'] = True;report['unknown_truth_opened'] = phase == 'current';files.require(np.array_equal(truth['ids'],query['ids']),'same true labels after prediction seal')
        effect,gates,prior = previous.delta(truth['truth'],pred,baseline,full=phase == 'current')
        save(out,report,'postseal_comparison',dict(**truth,prediction=pred,baseline=baseline,raw=raw,density=density,retained=own_retained,density_retained=route['retained']))
        zero_loss = all(effect['gain_loss'][n]['loss'] == 0 for n in ('BEN','KNA'))
        report.update(execution_status='constant_wholefield_support_'+phase+'_evaluated',original_class_gates=gates,baseline_class_gates=prior,
            EffectDelta=effect,paired_known_no_loss=zero_loss,known_gate_passed=zero_loss and all(gates[n]['passed'] for n in ('BEN','KNA')),
            all_three_integer99_passed=phase == 'current' and all(v['passed'] for v in gates.values()),
            DEV_review_eligible=phase == 'current' and effect['verdict'] == 'UP' and zero_loss,
            known_raw=int(raw[:654].sum()),known_retained=int(own_retained[:654].sum()),
            unknown_raw=int(raw[654:].sum()),unknown_retained=int(own_retained[654:].sum()),density_members=int(density.sum()),
            metric_state_sha256=metric.state_sha256,baseline2604_UNA_predictions_preserved=True,primary_classification_unchanged=True,
            cutoffs=cut,score_integer_min=int(live['score'].min()),score_integer_max=int(live['score'].max()))
        report['explicit_gate_status'] = gate_status(gates,{n:effect['gain_loss'][n]['loss'] for n in ('BEN','KNA')})
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        for p,h in pins.items():files.require(files.item(p)['sha256'] == h,'all constant support frozen input/source bytes unchanged')
        report['input_sha256'] = pins;report['wall_seconds'] = time.perf_counter()-started;files.write(out/'report.json',report)
    return files.item(out/'report.json')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for n in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+n)
    a = p.parse_args();print(json.dumps(freeze() if a.phase == 'freeze' else run(a.phase,a.registry,a.registry_sha256,a.known_report,a.known_sha256)))
