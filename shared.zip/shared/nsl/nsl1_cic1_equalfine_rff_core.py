"""Fixed equal-known-family nonlinear support on all native117/native78 fields.

Every genuine FIT event contributes once, with statistical weight1/(9*Nfine).
This explicitly changes a statistical prior, never the number of source flows.
Only true BEN+KNA FIT data sets the covariance, bandwidth and random basis.
"""
import numpy as np
from scipy.linalg import solve_triangular
from scipy.spatial.distance import pdist
from sklearn.covariance import OAS
SEED,WIDTH,RANK,SAMPLE=20261012,256,128,512
def require(ok,text):
    if not ok:raise ValueError(text)
def fine_weights(fine):
    fine=np.asarray(fine);require(fine.ndim==1 and fine.dtype.kind in 'iu' and np.array_equal(np.unique(fine),np.arange(9)),'all nine actual known representative fine labels')
    count=np.bincount(fine,minlength=9);weight=1/(9*count[fine]);require(np.isfinite(weight).all() and np.all(weight>0) and np.isclose(weight.sum(),1,rtol=0,atol=1e-14),'equal-fine weight mathematical mass one')
    return weight,count
def whiten(x,L):
    x=np.asarray(x,np.float64);L=np.asarray(L,np.float64);require(x.ndim==2 and x.shape[1] in (78,117) and L.shape==(x.shape[1],x.shape[1]) and np.isfinite(x).all() and np.isfinite(L).all() and np.array_equal(L,np.tril(L)) and np.all(np.diag(L)>0),'complete actual native width and true frozen lower Cholesky')
    q=solve_triangular(L,x.T,lower=True,check_finite=True).T;require(np.isfinite(q).all(),'finite allfield covariance whitened inputs');return q
def transform(x,state):
    q=whiten(x,state['L']);W,b=state['W'],state['b'];require(W.shape==(q.shape[1],WIDTH) and b.shape==(WIDTH,) and float(state['gamma'])>0,'fixed full256 RFF known state')
    phi=np.sqrt(2/WIDTH)*np.cos(np.sqrt(2*float(state['gamma']))*(q@W)+b);require(np.isfinite(phi).all(),'finite full256 nonlinear features no clipping');return q,phi
def fit_state(x,groups,fine,within_covariance=None):
    x=np.asarray(x,np.float64);groups=np.asarray(groups);fine=np.asarray(fine);require(x.ndim==2 and x.shape[1] in (78,117) and groups.shape==fine.shape==(len(x),) and len(np.unique(groups))==len(x) and np.isfinite(x).all(),'all genuine known native events no copies/query')
    weight,count=fine_weights(fine);means=np.stack([x[fine==f].mean(axis=0) for f in range(9)])
    if within_covariance is None:
        model=OAS(assume_centered=True).fit(x-means[fine]);cov=np.asarray(model.covariance_,np.float64);shrinkage=float(model.shrinkage_);require(shrinkage>0,'analytic positive OAS shrinkage, no decision jitter')
    else:cov=np.asarray(within_covariance,np.float64);shrinkage=None
    L=np.linalg.cholesky(cov);white=whiten(x,L);order=np.argsort(groups,kind='stable');sample=order[np.linspace(0,len(x)-1,min(SAMPLE,len(x))).astype(np.int64)]
    distances=pdist(white[sample],metric='sqeuclidean');positive=distances[distances>0];require(len(positive)>0 and np.isfinite(positive).all(),'positive nonself genuine known bandwidth pairs')
    h2=float(np.median(positive));gamma=1/(2*h2);rng=np.random.default_rng(SEED);W=rng.standard_normal((x.shape[1],WIDTH));b=rng.uniform(0,2*np.pi,WIDTH);phi=np.sqrt(2/WIDTH)*np.cos(np.sqrt(2*gamma)*(white@W)+b)
    mean=np.sum(weight[:,None]*phi,axis=0);delta=phi-mean;weighted_cov=(delta*weight[:,None]).T@delta;eigenvalues,eigenvectors=np.linalg.eigh(weighted_cov)
    require(np.isfinite(eigenvalues).all() and np.isfinite(eigenvectors).all(),'complete weighted known covariance eigensystem no rank search or clip')
    state=dict(L=L,native_known_fine_means=means,native_within_covariance=cov,W=W,b=b,gamma=np.asarray(gamma),h2=np.asarray(h2),mean=mean,weighted_covariance=weighted_cov,eigenvalues=eigenvalues,eigenvectors=eigenvectors,sample_indices=sample,sample_groups=groups[sample],positive_nonself_pair_count=np.asarray(len(positive)),event_statistical_weights=weight,genuine_fine_counts=count,fine_weight_mass=np.bincount(fine,weights=weight,minlength=9),measured_statistical_weight_sum=np.asarray(weight.sum()))
    return state,dict(white=white,features256=phi),shrinkage
def signals(x,state):
    _,phi=transform(x,state);delta=phi-state['mean'];low=delta@state['eigenvectors'][:,:WIDTH-RANK];score=np.einsum('ij,ij->i',low,low)
    require(score.shape==(len(x),) and np.isfinite(score).all() and np.all(score>=0),'fixed remaining128 squared residual high unknown')
    return dict(score=score,features256=phi,residual128=low,full_centered_energy=np.einsum('ij,ij->i',delta,delta))
