"""V990 input boundary: whole V9803124 parent, original admitted known source.

No model fitting/readout or truth loads on import. Current truth is not exposed.
Cached source/role features keep their original coordinate/state ownership.
"""
from pathlib import Path
import hashlib,importlib.util,io,json,sys
import numpy as np
H=Path(__file__).resolve().parent;MANIFEST=H/'INPUT_MANIFEST_V990.json'

def require(v,s):
    if not bool(v):raise ValueError(s)

def descriptor(path):
    p=Path(path).resolve(strict=True);return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def raw(d):
    b=Path(d['path']).read_bytes();require(hashlib.sha256(b).hexdigest()==d['sha256'],'immutable '+d['path']);return b

def js(d):return json.loads(raw(d).decode('utf-8-sig'))

def arrays(d,keys):
    with np.load(io.BytesIO(raw(d)),allow_pickle=False)as a:return{k:a[k]for k in keys}

def module(d,prefix):
    raw(d);name=prefix+'_'+d['sha256'];sp=importlib.util.spec_from_file_location(name,d['path']);m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m

def manifest():return json.loads(MANIFEST.read_text(encoding='utf8'))

def inherited_inputs(m=None):
    m=manifest()if m is None else m;return module(m['original_inputs'],'V990_original_native_source_inputs')

def source(m=None):
    m=manifest()if m is None else m;s=inherited_inputs(m).load_source()
    z=arrays(m['V980_source_geometry'],('ids','groups','fine','Z'))
    require(np.array_equal(s['ids'],z['ids'])and np.array_equal(s['groups'],z['groups'])and np.array_equal(s['fine'],z['fine']),
            'same genuine5967 known source and original fine order')
    require(z['Z'].shape==(5967,359)and s['X'].shape==(5967,228)and len(s['logical_X'])==5999,'actual source/logical geometry contracts')
    return dict(s,Z359=z['Z'],NN_fit=0,NN_readout=0,current_truth_decodes=0,
                source_parameter_roles_only=['BEN','KNA'],source_origin_unchanged=True)

def role(role,m=None):
    require(role in('CAL','CP','current'),'declared role')
    m=manifest()if m is None else m;q=inherited_inputs(m).load_role(role);cfg=m['roles'][role]
    seal=js(cfg['parent_seal']);require(seal['prediction']==cfg['parent_prediction']and seal['current_truth_used'] is False,'whole V980 parent pretruth seal')
    p=arrays(cfg['parent_prediction'],('ids','prediction'))
    require(np.array_equal(q['ids'],p['ids'])and len(p['ids'])==len(np.unique(p['ids']))==cfg['rows'],'exact complete V980 role IDs')
    q['parent2963_prediction']=q['parent_prediction'];q['parent_prediction']=p['prediction']
    q['parent_version']='V980_complete3124'
    return q

def role_scores980(role,m=None):
    m=manifest()if m is None else m;cfg=m['roles'][role];keys=cfg['score_array_fields']
    v=arrays(cfg['V980_scores'],keys);p=arrays(cfg['parent_prediction'],('ids',))
    require(np.array_equal(v['ids'],p['ids']),'frozen V980 numeric scores exact wholeparent ordering')
    require(v['Z'].shape==(cfg['rows'],359),'same V980 source-fitted359 metric coordinates')
    return v

def role_prior980(role,m=None):
    """Label-free original whole ancestor/raw/decision trace for arbitration."""
    m=manifest()if m is None else m;cfg=m['roles'][role]
    return arrays(cfg['parent_prediction'],('ids','prediction','parent_prediction','new_raw','native_novelty_reject','conditional_dual_reject'))

def known_labels(role,m=None):
    require(role in('CAL','CP'),'only known calibration/control, no current truth loader')
    return inherited_inputs(m).load_known_labels(role)

def readouts_original(role,m=None):
    require(role in('source','CAL','CP','current'),'declared original readout')
    m=manifest()if m is None else m;a=arrays(m['original_best_readouts'][role],('ids','groups','embedding32','field_mse','field_signed','coarse_logits','fine_logits'))
    if role=='source':
        x=arrays(m['V980_source_geometry'],('ids','groups'))
    else:x=role_reference_inventory(role,m)
    require(np.array_equal(a['ids'],x['ids'])and np.array_equal(a['groups'],x['groups']),'original NN cache exact own role IDs and physicalgroups')
    return a

def role_reference_inventory(role,m=None):
    m=manifest()if m is None else m;q=inherited_inputs(m).load_role(role)
    return dict(ids=q['ids'],groups=q['groups'])

def parameter_bundle(which,m=None):
    import joblib
    m=manifest()if m is None else m;require(which in('auditor','conditional'),'declared inherited source-only bundle')
    return joblib.load(io.BytesIO(raw(m['inherited_parameters'][which])))
