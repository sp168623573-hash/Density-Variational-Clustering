"""Whole149 query-density contrast cue, preserving whole2760 and old149 DVC."""
import argparse,json,sys,time,types
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from . import nsl1_query7_contrast_core_v164 as core
from . import nsl1_reference_absence_critic305_v153 as previous
ROOT,files,require=previous.ROOT,previous.files,previous.require
old,nsl=previous.old,previous.nsl;MODULE='paper_open_set.nsl1_query7_contrast149_v164'
DIR=ROOT/'tmp/nsl1_query7_contrast149_20261013_v164';BASE=ROOT/'data/external_dev/processed/nsl1_query7_contrast149_20261013_v164';REG=DIR/'registry_before_known.json'
def policy():
    return dict(schema_version='NSL1-allknown-nearest_vs_queryother7-full149-v164',hypotheses=1,
        statistic='d²/(d²+q²), d=nearestall5999genuineknownFIT, q=querycanonicalgenuine selfexcluded7th distance; stablemaxscale bothzero0',
        fieldspace='completeoriginal149 masked32+native117 and originallearnedmetric; no changedembedding/field/referencefine selector',
        cohort='wholeownrole CAL656/known654/current3598 canonicalnativegroupsonce; no truecoarse/family/subset choosesqueryneighbors',
        history='different from NSL1V72Weibull20, V73FITsamefine_R7normalization, domain31hypergeom and V120/148conditional FITball counts; NSL2clean147state neverborrowed',
        CAL='all656trueknown oncefinite99, actualoriginalstage1bank; currentfeatures onlyunlabelledinference, not CAL or criticfit',
        DVC='ownnewraw OR allwhole2760pred2 background, sameoriginal149 densityaffinity/noise canonicalpointonce',
        merge='copywhole317/335/2760 allold2 includingerrors, ownrawretained append2; preserve original2757 andfailedversions',
        score_not_unknown_probability=True,NN_fit=0,NN_forward=0,metric_fit=0,main_R7_refit=0,critic_fit=0,query_fit=False,trueUNA_fit=False,parameter_grid=False,timecap_coded=False,
        extension_not_verbatim_paper=True,status='FAIL_TARGET99',published=False,final_test_executed=False)
def closure():
    found={};seen=set();todo=[sys.modules[__name__]]
    while todo:
        m=todo.pop()
        if m is None or id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if not p or not Path(p).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        found[MODULE if m is sys.modules[__name__] else m.__name__]=files.item(p)
        for v in vars(m).values():
            child=v if isinstance(v,types.ModuleType) else sys.modules.get(getattr(v,'__module__',''))
            if child is not None:todo.append(child)
    return found
def archive(a,keys,pins):return old.archive(a,keys,pins)
def save(out,r,key,value):return old.save(out,r,key,value)
def freeze():
    started=time.perf_counter();pins={};pr=files.item(previous.REG);p=files.js(pr,pins);kr=files.item(previous.BASE/'known/report.json');cr=files.item(previous.BASE/'current/report.json');k=files.js(kr,pins);c=files.js(cr,pins)
    require(k['known_gate_passed'] and c['prediction_sealed'] and c['original_class_gates']['UNA']['correct']==2760,'actualpositivewhole2760 sourcepretruthprediction')
    a=dict(p['assets']);a.update(merge_known=k['files']['complete_proxycriticprediction_beforetruth'],merge_current=c['files']['complete_proxycriticprediction_beforetruth'])
    close_ref=files.item(previous.DIR/'NSL1_V153_REFERENCE_ABSENCE_HGB305_2760_UP_COMPLETED_CLOSEOUT.json');close=files.js(close_ref,pins)
    src=closure();contract=core.synthetic_contract()
    for item in [*a.values(),*src.values()]:files.read(item,pins)
    require(not REG.exists() and not BASE.exists(),'exclusivefixedquerydensitycontrast namespace')
    DIR.mkdir(parents=True,exist_ok=True)
    return files.write(REG,dict(policy=policy(),assets=a,sources=src,synthetic_contract=contract,previous_registry=pr,previous_known=kr,previous_current=cr,ancestry_closeout=close_ref,
        prior_necessary_preparation_seconds=close['actual_preparation']['necessary_allprep_plus_ancestry_seconds'],freeze_seconds=time.perf_counter()-started,input_sha256=pins,current_numeric_decodes=0))
def bind(ref,pins):
    r=files.js(ref,pins);require(r['policy']==policy() and r['sources']==closure(),'exactfrozenqueryR7contrast recipe/source')
    for p,s in r['input_sha256'].items():files.read(dict(path=p,sha256=s),pins)
    return r
def collapse(q):
    groups,rep,inv=np.unique(q['groups'],return_index=True,return_inverse=True)
    require(np.array_equal(q['Z149'][:,32:],q['Z149'][rep,32:][inv]),'native117 groups physicalcopies agree; originalfirst32 variations preservedfirstrepresentative')
    return rep,inv
def cue_role(metric,reference,q,out,r,role):
    rep,inv=collapse(q);start=time.perf_counter();cue=core.score(metric,reference['Z149'],q['Z149'][rep]);r['ratio_seconds'][role]=time.perf_counter()-start
    r['files'][role+'_cue']=save(out,r,role+'_same149_nearestknown_queryother7_beforecut',dict(ids=q['ids'],groups=q['groups'],Z149=q['Z149'],stage1=q['stage1'],representatives=rep,inverse=inv,score_rows=cue['score'][inv],**cue))
    return cue['score'][inv]
def run(phase,ref,knownref=None):
    started=time.perf_counter();pins={};reg=bind(ref,pins);control=None
    if phase=='current':control=files.js(knownref,pins);require(control['known_gate_passed'] and control['prediction_sealed'] and control['registry']==ref,'knownintegercontrol beforecurrentratio')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False);r=dict(policy=policy(),phase=phase,registry=ref,files={},ratio_seconds={},NN_fit=0,NN_forward=0,metric_fit=0,main_R7_refit=0,critic_fit=0,CAL_fit=0,DVC=0,current_numeric_decodes=0,prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        with threadpool_limits(limits=4):
            a=reg['assets'];metric=nsl.learned.PaperVariationalPairMetric.from_state(files.js(a['metric'],pins));reference=archive(a['reference'],('ids','groups','Z149','original_indices','known_fine_membership'),pins)
            require(metric.dimension==149 and len(reference['ids'])==len(np.unique(reference['groups']))==5999,'actualsame149 andgenuineallknown5999reference')
            r['files']['metric']=a['metric'];r['files']['reference']=a['reference']
            if phase=='known':
                mat=archive(a['material'],('fit_Z149','calibration_ids','calibration_groups','calibration_Z149','calibration_stage1'),pins);require(metric.to_state()['prefit_descriptor']['FIT_MHFD_Z']==nsl.base.descriptor(mat['fit_Z149']),'originalmain149 FIT descriptor byteowned')
                cal={key:mat['calibration_'+key] for key in ('ids','groups','Z149','stage1')};cal_score=cue_role(metric,reference,cal,out,r,'CAL');labels=archive(a['encoded'],('calibration_ids','calibration_known_coarse'),pins);require(np.array_equal(cal['ids'],labels['calibration_ids']),'alltrueknownCAL656 sameidentity')
                rule=nsl.base.paper_route.calibrate_known_cutoffs(cal_score,labels['calibration_known_coarse']);r['CAL_fit']=1;r['files']['rule']=files.write(out/'all656_trueknown_oncefinite99_nearest_queryR7.json',rule)
            else:rule=files.js(control['files']['rule'],pins);r['files']['rule']=control['files']['rule'];r['known_report']=knownref
            q,_,_=old.query('NSL1',phase,a,pins);merge=archive(a['merge_known' if phase=='known' else 'merge_current'],('ids','prediction'),pins);require(np.array_equal(q['ids'],merge['ids']),'completewhole2760 orderedbaseline separatefromstatistic')
            baseline=merge['prediction'];role='CP' if phase=='known' else 'current';r['current_numeric_decodes']=len(q['ids']) if phase=='current' else 0;score=cue_role(metric,reference,q,out,r,role)
            raw=(baseline!=2)&nsl.base.paper_route.candidate_mask(score,q['stage1'],rule);density=raw|(baseline==2)
            def sink(name,value,manifest):save(out,r,name+'_DVC_beforetruth',value);r['files'][name+'_DVC_manifest']=files.write(out/(name+'_DVC_manifest.json'),manifest)
            routed,_=nsl.base.route_once(metric,q,density,sink);r['DVC']=1;retained=raw&routed['retained'];pred=baseline.copy();pred[retained]=2;require(np.all(pred[baseline==2]==2),'allold2760pred2 intact')
            values=dict(ids=q['ids'],prediction=pred,baseline=baseline,score=score,raw=raw,density=density,retained=retained);sealed=save(out,r,'complete_query7prediction_beforetruth',values)
            r['files']['seal']=files.write(out/'complete_query7prediction_seal_beforetruth.json',dict(predictions=sealed,registry=ref,reference=a['reference'],rule=r['files']['rule'],metric=a['metric'],querytruth_used=False));r['prediction_sealed']=True
            truth=nsl.parent.previous.prefix_archive(a['baseline'],('ids','truth'),654,pins) if phase=='known' else archive(a['baseline'],('ids','truth'),pins);require(np.array_equal(truth['ids'],q['ids']),'truequery onlyaftercomplete newpredictionseal');y=truth['truth'];r['truth_opened']=True
            gates,delta,binary=previous.previous.previous.helpers.metrics(y,baseline,pred);r.update(execution_status='NSL1_allknown_queryother7_149_'+phase+'_completed',original_class_gates=gates,EffectDelta=delta,binary_attack_detection=binary,known_gate_passed=all(gates[n]['passed'] for n in ('BEN','KNA')),candidate_accepted_for_retention=False,
                raw_by_trueclass={name:int(((y==c)&raw).sum()) for c,name in enumerate(('BEN','KNA','UNA'))},retained_by_trueclass={name:int(((y==c)&retained).sum()) for c,name in enumerate(('BEN','KNA','UNA'))})
            save(out,r,'postseal_complete_query7_pair',dict(**values,truth=y))
            if phase=='current':r['perfect_query7_raw_UNA_ceiling']=int(((y==2)&((baseline==2)|raw)).sum())
        for p,s in pins.items():require(files.item(p)['sha256']==s,'alloriginal frozenNN/metric/reference/role/source/2760versions unchanged')
    except Exception as error:r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for key in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+key)
    a=p.parse_args();ref=None if a.registry is None else dict(path=str(Path(a.registry).resolve()),sha256=a.registry_sha256);k=None if a.known_report is None else dict(path=str(Path(a.known_report).resolve()),sha256=a.known_sha256)
    print(json.dumps(freeze() if a.phase=='freeze' else run(a.phase,ref,k)))
