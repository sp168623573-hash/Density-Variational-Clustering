"""Fixed BEN-context collective continuous density ratio, owned149 DVC.

Negative CAL population is explicitly true known BEN. Deployment query
population uses old predicted BEN only, never query truth. Zero new NN/metric.
"""
import argparse,json,sys,time,types
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from . import nsl1_cic1_equalfine_RFF_candidates_v92 as old
from . import nsl1_context_local_density_ratio_core_v120 as core
from . import nsl1_nativecell_Student3_typedmask_v60 as fields_source
ROOT,files,require=old.ROOT,old.files,old.require
nsl,helpers=old.nsl,old.helpers
MODULE='paper_open_set.nsl1_context_local_density_ratio149_v120'
DIR=ROOT/'tmp/nsl1_context_local_density_ratio149_20261012_v120'
BASE=ROOT/'data/external_dev/processed/nsl1_context_local_density_ratio149_20261012_v120'

def registry_path(setting):return DIR/(setting+'_registry_before_known_context_density_ratio.json')
def policy(setting):
    require(setting=='NSL1','single existing setting')
    return dict(schema_version='NSL1-BEN-full3context-original149-R7-local-collective-density-ratio-v120',hypotheses=1,
        FIT='only genuine5999 canonicalknownfine0 BEN3240 original149; optimizer6000 BEN+KNA family20 unchanged, copies excluded',
        context='all three complete real protocol/service/flag wholefields including UNSEEN; no chosen context/field subset',
        geometry='same original V62 masked32+native117=149 owner/ref/scales/weights/R7; complete numeric continuous/constants preserved',
        support='NF_BEN_context>=20 and activeNQ_context>=7 fixed; otherwise score0 and eligiblefalse failclosed',
        radius='query to samecontext genuineBEN seventh nearest learned-distance reference; complete closed ball includes all exact ties',
        score='log((nQ_ball_excluding_self+1)/NQctx)-log((nF_BEN_ball+1)/(NFctx+1)); fixed countingprior1, no epsilon/clipping',
        population='CAL trueknownBEN only explicitly labelled negative calibration; known/current oldbaselineBEN0 only; nativegroups once, no querytruth',
        representatives='np.unique originalnativegroups firstoriginalrow, unchanged original149 embedding values; duplicate native117 and active/context agree; scatter samegroup',
        CAL='all656 trueknownCAL oncefinite99 pertruecoarse; nonBEN score0 placeholder; query actualoriginalstage1 choosesbank; eligiblemask prevents unavailable0 crossingnegativecut',
        framework='MHFD -> additional collective candidate -> owned149 Eq9/10 density affinity -> reconstruction/localdensity/secondary noise; no large oldUNA graphbackground',
        merge='preserve originalwhole2618 oldKNA1/UNA2; newraw only baselineBEN0 withscorestrictgreaterownCALcut AND eligible; raw-only DVC retained append2',
        comparison='whole original317/335/2618 and failed285/335/2925 and failed298/335/2837 preserved; no numerator splicing',
        assumptions='within a real context normal continuous joint behavior density is stable; excess unresolved collective occupancy may indicate novel pattern, benign workload shifts may trigger and unknown sharingBENgeometry may escape',
        history='not firstoccupancy: NSL2V72 allknown232R20 no categorical conditioning; old authcontext reference pointdensity/jackknife/greedy normalprotection differs from query-to-FIT occupancy ratio',
        NN_fit=0,NN_forward=0,metric_fit=0,R7_fit=0,query_label_training=False,query_cut_fit=False,cohort_features_used_for_inference=True,
        parameter_grid=False,field_selection=False,timecap_coded=False,extension_not_verbatim_paper=True,warm_development_only=True,
        status='FAIL_TARGET99',published=False,final_test_executed=False)

def closure():
    pending=[sys.modules[__name__]];seen=set();result={}
    while pending:
        m=pending.pop()
        if m is None or id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if not p or not Path(p).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        result[MODULE if m is sys.modules[__name__] else m.__name__]=files.item(p)
        for value in vars(m).values():
            child=value if isinstance(value,types.ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            if child is not None:pending.append(child)
    require(all(m.__name__ in result for m in (old,core,nsl,helpers,fields_source)),'actual source closure')
    return result

def metadata(setting,pins):
    require(setting=='NSL1','single scope')
    a,ancestry,refs=old.metadata(setting,pins)
    a['actual_encoder']=fields_source.ENCODER
    mapping=fields_source.field_map_state(files.js(a['actual_encoder'],pins))['groups']
    v118ref=files.item(ROOT/'tmp/nsl1_collective_discrete_guard149_20261012_v118/NSL1_V118_DISCRETE_GUARD_2837_MIXED_COMPLETED_CLOSEOUT.json')
    prior=files.js(v118ref,pins)
    ancestry['priorfailed_andcompleted_attempts']=prior['timing_seconds']['conservative_allprep_plus_ancestry']-sum(ancestry.values())
    # Bound the preceding actual metadata/header Python subprocess at 12s.
    # No real traffic numeric/query arrays were decoded by that probe.
    ancestry['thisbranch_metadata_header_probe_conservative']=12.0
    refs['allattempt_time_evidence']=v118ref
    for tag,ref in [('failed2925',files.item(ROOT/'tmp/nsl1_collective_categorical_profile149_20261012_v116b/NSL1_V116B_COLLECTIVE_PROFILE_2925_MIXED_COMPLETED_CLOSEOUT.json')),('failed2837',v118ref)]:
        report=files.js(files.js(ref,pins)['current_report'],pins)
        a[tag+'_current_pair']=report['files']['postseal_paired_comparison'];refs[tag+'_closeout']=ref
    core.contexts_core.categorical_mapping(mapping)
    return a,ancestry,refs,mapping

def freeze(setting):
    start=time.perf_counter();pins={};a,ancestry,refs,mapping=metadata(setting,pins)
    sources=closure()
    for d in [*a.values(),*sources.values()]:files.read(d,pins)
    require(not registry_path(setting).exists() and not (BASE/setting).exists(),'fresh fixed V120 branch')
    contract=files.item(DIR/'PREFLIGHT_BEFORE_FREEZE_V120.json');test=files.js(contract,pins)
    require(test['all_passed'] and test['real_traffic_numeric_decoded']==0 and test['current_truth_members_decoded']==0,'actual contracts before freeze')
    contract_process=files.item(DIR/'ACTUAL_PREFLIGHT_PROCESS_V120b.json')
    process=files.js(contract_process,pins)
    require(process['exit_code']==0 and process['preflight']==contract,'actual contract subprocess and exact receipt')
    ancestry['thisbranch_actual_contract_process']=process['wall_seconds']
    failed_contract_process=files.item(DIR/'ACTUAL_PREFLIGHT_PROCESS_V120.json')
    failed=files.js(failed_contract_process,pins)
    require(failed['exit_code']!=0,'preserved first synthetic string-concatenation contract failure')
    ancestry['thisbranch_failed_synthetic_contract_process']=failed['wall_seconds']
    return files.write(registry_path(setting),dict(policy=policy(setting),assets=a,sources=sources,
        ancestry_seconds=ancestry,necessary_ancestry_seconds=sum(ancestry.values()),references=refs,groups=mapping,
        metadata_preparation_seconds=time.perf_counter()-start,input_sha256=pins,preflight=contract,preflight_process=contract_process,current_numeric_rows_decoded=0))

def bind(setting,desc,pins):
    reg=files.js(desc,pins)
    require(Path(desc['path']).resolve()==registry_path(setting).resolve() and reg['policy']==policy(setting) and reg['sources']==closure(),'frozen own roles/source/recipe')
    for p,s in reg['input_sha256'].items():files.read(dict(path=p,sha256=s),pins)
    return reg

def save(out,r,name,value):return old.save(out,r,name,value)
def archive(a,keys,pins):return old.archive(a,keys,pins)
def save_cue(out,r,prefix,cue,detail,ids,z,groups):
    save(out,r,prefix,dict(ids=ids,Z149=z,groups=groups,**cue))
    for j,value in enumerate(detail):save(out,r,prefix+'_context'+str(j)+'_actual_distances',value)

def run(setting,phase,desc,known_desc=None):
    started=time.perf_counter();pins={};reg=bind(setting,desc,pins);known=None
    if phase=='current':
        known=files.js(known_desc,pins)
        require(known['registry']==desc and known['prediction_sealed'] and known['known_gate_passed'],'exactknown gates before current decoding')
    out=BASE/setting/phase;out.mkdir(parents=True,exist_ok=False)
    r=dict(policy=policy(setting),registry=desc,phase=phase,files={},NN_fit=0,NN_forward=0,metric_fit=0,R7_fit=0,
           BEN_background_fit=0,CAL_fit=0,DVC=0,current_numeric_rows_decoded=0,prediction_sealed=False,truth_opened=False,
           accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        with threadpool_limits(limits=4):
            a=reg['assets'];metric=nsl.learned.PaperVariationalPairMetric.from_state(files.js(a['metric'],pins));r['files']['metric']=a['metric']
            if phase=='known':
                prep=time.perf_counter();g=old.fit_material(setting,a,pins)
                ref=archive(a['reference'],('Z149','ids','groups','original_indices','known_fine_membership'),pins)
                require(np.array_equal(ref['ids'],g['ids']) and np.array_equal(ref['groups'],g['groups']) and np.array_equal(ref['Z149'][:,32:],g['x']),'exact originalgenuine5999/full149 roster')
                fitstart=time.perf_counter();background=core.fit_background(ref['Z149'],g['groups'],g['fine'],reg['groups'])
                require(int(background['genuine_BEN_groups'])==3240,'actualgenuineBEN count')
                r['BEN_background_fit']=1;r['BEN_background_fit_seconds']=time.perf_counter()-fitstart
                save(out,r,'genuine5999_original149_known_before_BEN_reference',dict(**ref,fine=g['fine']))
                r['files']['state']=save(out,r,'genuineBEN3240_context149_reference_before_CAL',background)
                cal=archive(a['material'],('calibration_ids','calibration_groups','calibration_Z149','calibration_stage1'),pins)
                require(np.array_equal(cal['calibration_ids'],g['CAL_ids']) and np.array_equal(cal['calibration_Z149'][:,32:],g['CAL_x']),'actualallCAL656 identity/completegeometry')
                # Only labelled known-negative CAL labels select the population;
                # this mask is never taken from evaluation query truth.
                active=g['CAL_coarse']==0;cs=time.perf_counter()
                cue,detail=core.infer(metric,cal['calibration_Z149'],cal['calibration_groups'],active,background,reg['groups'])
                r['CAL_population_stat_seconds']=time.perf_counter()-cs
                save_cue(out,r,'alltrueknown_CAL656_context_density_ratio_before_cut',cue,detail,g['CAL_ids'],cal['calibration_Z149'],cal['calibration_groups'])
                save(out,r,'alltrueknown_CAL656_negativepopulation_labels_before_cut',dict(ids=g['CAL_ids'],truecoarse=g['CAL_coarse'],active=active))
                rule=nsl.base.paper_route.calibrate_known_cutoffs(cue['score'],g['CAL_coarse']);r['CAL_fit']=1
                r['files']['rule']=files.write(out/'alltrueknown_CAL656_oncefinite99_context_density_ratio.json',rule)
                r['training_preparation_seconds']=time.perf_counter()-prep
            else:
                background=archive(known['files']['state'],('Z149','groups','original_genuine_indices','contexts3','vocabulary3','context_counts','genuine_BEN_groups'),pins)
                rule=files.js(known['files']['rule'],pins);r['files'].update(state=known['files']['state'],rule=known['files']['rule']);r['known_report']=known_desc
            q,baseline,native=old.query(setting,phase,a,pins)
            r['current_numeric_rows_decoded']=len(q['ids']) if phase=='current' else 0
            statstart=time.perf_counter();cue,detail=core.infer(metric,q['Z149'],q['groups'],baseline==0,background,reg['groups']);r['query_population_stat_seconds']=time.perf_counter()-statstart
            raw=nsl.base.paper_route.candidate_mask(cue['score'],q['stage1'],rule)&cue['eligible']&(baseline==0)
            save_cue(out,r,'unresolvedBEN_context_population_before_DVC',cue,detail,q['ids'],q['Z149'],q['groups'])
            save(out,r,'unchanged_originalgeometry_before_DVC',q)
            ds=time.perf_counter()
            def sink(name,value,manifest):
                save(out,r,name+'_DVC_before_truth',value)
                r['files'][name+'_DVC_manifest']=files.write(out/(name+'_DVC_manifest.json'),manifest)
            route,_=nsl.base.route_once(metric,q,raw,sink);r['DVC']=1;r['query_DVC_inference_seconds']=time.perf_counter()-ds
            retained=raw&route['retained'];prediction=baseline.copy();prediction[retained]=2
            require(np.array_equal(prediction[baseline!=0],baseline[baseline!=0]),'old completeKNA1/UNA2 preserved')
            value=dict(ids=q['ids'],prediction=prediction,baseline=baseline,raw=raw,density=raw,retained=retained,density_retained=route['retained'])
            sealed=save(out,r,'complete_prediction_before_truth',value)
            r['files']['seal']=files.write(out/'prediction_seal_before_truth.json',dict(predictions=sealed,registry=desc,state=r['files']['state'],rule=r['files']['rule'],metric=a['metric'],truth_used=False));r['prediction_sealed']=True
            truth=nsl.parent.previous.prefix_archive(a['baseline'],('ids','truth'),654,pins) if phase=='known' else archive(a['baseline'],('ids','truth'),pins)
            require(np.array_equal(truth['ids'],q['ids']),'truth only aftersealedwholeprediction')
            y=truth['truth'];r['truth_opened']=True;gates,delta,binary=helpers.metrics(y,baseline,prediction)
            knownpass=all(gates[n]['passed'] for n in ('BEN','KNA'))
            r.update(execution_status='NSL1_context_local_density_ratio_'+phase+'_completed',original_class_gates=gates,EffectDelta=delta,binary_attack_detection=binary,
                known_gate_passed=knownpass,all_three_integer99_passed=bool(phase=='current' and all(g['passed'] for g in gates.values())),
                candidate_accepted_for_retention=bool(phase=='current' and knownpass and delta['correct_count_delta']['UNA']>0),
                raw_by_true_class={n:int(((y==c)&raw).sum()) for c,n in enumerate(('BEN','KNA','UNA'))},
                retained_by_true_class={n:int(((y==c)&retained).sum()) for c,n in enumerate(('BEN','KNA','UNA'))})
            save(out,r,'postseal_paired_comparison',dict(**value,truth=y))
            if phase=='current':
                for tag in ('failed2925','failed2837'):
                    oldpair=archive(a[tag+'_current_pair'],('ids','truth','prediction'),pins)
                    require(np.array_equal(oldpair['ids'],q['ids']) and np.array_equal(oldpair['truth'],y),'same orderedwhole comparison afterseal')
                    cg,ce,cb=helpers.metrics(y,oldpair['prediction'],prediction)
                    r['comparison_to_'+tag]=dict(class_gates=cg,EffectDelta=ce,binary_attack_detection=cb)
                    save(out,r,'postseal_paired_against_'+tag,dict(ids=q['ids'],truth=y,prediction=prediction,previous=oldpair['prediction']))
                r['perfect_raw_retention_UNA_ceiling']=int(((y==2)&(baseline==2)).sum()+((y==2)&raw).sum())
        for p,s in pins.items():require(files.item(p)['sha256']==s,'frozen bytes unchanged')
    except Exception as error:
        r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started)
        if phase=='known':r['conservative_preparation_seconds']=reg['necessary_ancestry_seconds']+reg['metadata_preparation_seconds']+r['wall_seconds']
        files.write(out/'report.json',r)
    return files.item(out/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--setting',choices=('NSL1',),required=True);p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for n in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+n)
    args=p.parse_args();d=None if not args.registry else dict(path=str(Path(args.registry).resolve()),sha256=args.registry_sha256)
    k=None if not args.known_report else dict(path=str(Path(args.known_report).resolve()),sha256=args.known_sha256)
    print(json.dumps(freeze(args.setting) if args.phase=='freeze' else run(args.setting,args.phase,d,k)))
