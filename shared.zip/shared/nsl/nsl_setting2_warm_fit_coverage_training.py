"""One fixed-final-checkpoint MHFD on a predeclared warm known-role union.

Known FIT/CP supervision is legitimately enlarged, with an explicit development
role change. Neither this experiment nor its exact known-class counts admit a
final test. Saved OPEN numeric members are not decoded by this runner.
"""
from __future__ import annotations

import argparse
from collections import Counter
import io
import json
import os
from pathlib import Path
import time
from types import SimpleNamespace

import joblib
import numpy as np
import pandas as pd
from sklearn.feature_selection import SelectKBest, f_classif
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler

from . import nsl_setting2_warm_fit_coverage_plan_v2 as planner
from . import nsl_setting2_capped_known_training_v1 as parent
from . import nsl_setting2_capped_known_forest_blend_v1 as seal

ROOT, SETTING, FAMILIES = parent.ROOT, parent.SETTING, parent.FAMILIES
MODEL_ROLES, EPOCHS, SEED = planner.ROLES, 80, planner.SEED
BASELINE = dict(path=seal.BASELINE, sha256=seal.BASELINE_SHA)
OUTPUT = ROOT/'data/external_dev/processed/nsl_setting2_warm_fit_coverage_training_20261009_v2/NSL_KDD_Setting2'
POLICY = dict(schema_version='NSL2-warm-known-FIT-coverage-fixed-final-MHFD-v2', setting=SETTING,
    datasets_used=['NSL-KDD'], source_schema='registered legacy40 without duration',
    role_plan='predeclared metadata old-FIT+CP known supervision, original-CAL family/group half split',
    training_side_cap=6000, minimum_effective_training_family_support=20,
    no_mandatory_CAL_or_DEV_family_floor=True,
    preprocessing='all new FIT original group representatives only; original ColumnTransformer, variance, ANOVA top50',
    model='unchanged MHFDNetwork attention/gate/CNN/BiLSTM/coarse/fine/reconstruction',
    losses='unchanged coarse CE + .35 fine CE(smoothing .01) + .03 SmoothL1 reconstruction',
    optimizer='unchanged AdamW lr .001 weight_decay .0002; cosine80 eta_min .0001; hierarchical family sampler; clip5',
    epochs=EPOCHS, seed=SEED, checkpoint='fixed final epoch80; no validation-driven checkpoint selection',
    threshold='new CAL known coarse truth only, once after model freeze; original choose_coarse_threshold',
    DEV='known-only original old-CAL subset, one MHFD inference after model/threshold seals',
    copies='only FIT optimization floor20; no CAL/DEV extra report copies; density uses originals once per feature group',
    OPEN_numeric_members_decoded=False, OPEN_inference=False, UNA_used=False,
    raw_source_opened_or_hashed=False, inherited_source_SHA_only=True,
    physical_original_dataset_proportions_claimed=False, fresh_holdouts_claimed=False,
    original_12028_known_exposure_preserved=True, planned_training_runs=1,
    warm_development_only=True, independent_final_admitted=False,
    status='FAIL_TARGET99', published=False, final_test_executed=False, promotion_status='NOT_PROMOTED')
require, checked, descriptor = parent.require, parent.checked, parent.descriptor
sha, array_descriptor, gates, write_json = parent.sha, parent.array_descriptor, parent.gates, parent.write_json


def _load_plan(item, pins):
    report = json.loads(checked(item,pins))
    require(report.get('planning_completed') is True and report.get('final_input_pins_unchanged') is True
        and report.get('execution_status') == 'warm_known_role_reallocation_plan_completed'
        and report.get('configuration') == seal.plain(planner.POLICY)
        and report.get('warm_development_only') is True and report.get('independent_final_admitted') is False
        and report.get('status') == 'FAIL_TARGET99' and report.get('published') is False
        and report.get('final_test_executed') is False, 'completed_known_reallocation_plan_required')
    plan = json.loads(checked(report['files']['known_role_plan'],pins))
    records = json.loads(checked(planner.RECORDS,pins))
    require(planner.digest(plan) == planner.digest(planner.build_plan(records)), 'exact_predeclared_metadata_reallocation')
    require(plan['training_effective_aggregate'] <= 6000 and plan['formal_training_admitted'] is False,
        'capped_warm_not_formal_plan')
    for raw, expected in report['input_sha256'].items():
        path = Path(raw); path = (path if path.is_absolute() else ROOT/path).resolve()
        require(path.is_relative_to(ROOT) and sha(path) == expected,'plan_dependency_changed:'+str(path))
        pins[str(path)] = expected
    return plan, records


def _load_known_values(pins, records):
    """Decode saved old FIT/CP/CAL only, never a raw file or OPEN member."""
    source = json.loads(checked(planner.SOURCE_REPORT,pins))
    require(source['source_extraction_completed'] is True and source['all_input_pins_stable'] is True
        and source['boundary']['unknown_feature_rows_parsed'] == 0
        and source['files']['ordered_source_records'] == planner.RECORDS,
        'completed_capped_known_source_required')
    schema = json.loads(checked(source['files']['feature_schema'],pins))
    require(schema['role_original_rows'] == parent.ALL_ROLES and tuple(schema['family_order']) == FAMILIES,
        'original_saved_known_role_schema')
    old_roles = ('FIT','CP','CAL')
    names = {k for k in parent.source_code.expected_members() if any(k.startswith(r+'_') for r in old_roles)}
    arrays = {}
    with np.load(io.BytesIO(checked(source['files']['known_roles_archive'],pins)),allow_pickle=False) as stored:
        require(set(stored.files) == parent.source_code.expected_members(), 'fixed_saved_archive_members')
        for key in sorted(names):
            arrays[key] = stored[key].copy()
            require(parent.source_code.array_descriptor(arrays[key]) == source['array_descriptors'][key], 'known_member_binding:'+key)
    frames = {}
    for role in old_roles:
        rows = records['roles'][role]
        require(len(rows) == parent.ALL_ROLES[role] == len(arrays[role+'_ids']), 'known_role_count:'+role)
        frames[role] = parent.source_code.restore_frame(arrays,role,schema)
        parent.source_code.verify_role_frame(frames[role],rows)
        for i,row in enumerate(rows):
            require(row['sample_id'] == arrays[role+'_ids'][i]
                and row['family'] == arrays[role+'_families'][i] == FAMILIES[int(arrays[role+'_y_fine'][i])]
                and row['coarse'] == arrays[role+'_y_coarse'][i]
                and row['source_record_ordinal_zero_based'] == arrays[role+'_source_ordinals'][i]
                and row['legacy_model40_group'] == arrays[role+'_groups'][i]
                and row['pandas_string_feature_values_sha256'] == arrays[role+'_strong_feature_sha256'][i],
                'original_known_record_feature_label_identity:'+role)
    require(not any(k.startswith('OPEN_') for k in arrays), 'no_OPEN_numeric_members')
    return arrays, frames


def _reallocate(plan, old_arrays, old_frames):
    frames, arrays = {}, {}
    for role in MODEL_ROLES:
        rows = plan['roles'][role]
        pieces = []
        for row in rows:
            origin, i = row['origin_role'], row['origin_position']
            require(origin in ('FIT','CP') if role == 'FIT' else origin == 'CAL', 'legitimate_known_origin_only')
            require(type(i) is int and 0 <= i < len(old_frames[origin])
                and row['sample_id'] == old_arrays[origin+'_ids'][i], 'parent_position_identity')
            pieces.append(old_frames[origin].iloc[[i]])
        frames[role] = pd.concat(pieces,ignore_index=True)
        parent.source_code.verify_role_frame(frames[role],rows)
        arrays[role+'_ids'] = np.asarray([r['sample_id'] for r in rows],dtype=str)
        arrays[role+'_groups'] = np.asarray([r['legacy_model40_group'] for r in rows],dtype='U16')
        arrays[role+'_families'] = np.asarray([r['family'] for r in rows],dtype=str)
        arrays[role+'_y_fine'] = np.asarray([FAMILIES.index(r['family']) for r in rows],dtype=np.int64)
        arrays[role+'_y_coarse'] = np.asarray([r['coarse'] for r in rows],dtype=np.int64)
        arrays[role+'_density_indices'] = np.asarray(plan['role_density_representative_indices'][role],dtype=np.int64)
    arrays['FIT_optimization_indices'] = np.asarray(plan['FIT_optimization_indices'],dtype=np.int64)
    idx = arrays['FIT_optimization_indices']
    require(len(idx) + len(arrays['CAL_ids']) + len(arrays['DEV_ids']) == plan['training_effective_aggregate'] <= 6000,
        'reallocated_effective_cap')
    require(all(n >= 20 for n in Counter(arrays['FIT_families'][idx].tolist()).values())
        and set(arrays['FIT_families'][idx].tolist()) == set(FAMILIES), 'each_known_training_family_floor20')
    return arrays, frames


def _prepare(arrays,frames):
    require(set(frames) == set(MODEL_ROLES), 'known_FIT_CAL_DEV_only')
    transformer = parent.data._build_preprocessor(parent.SPEC)
    encoded = {'FIT':np.asarray(transformer.fit_transform(frames['FIT']),dtype=np.float32)}
    for role in ('CAL','DEV'):
        encoded[role] = np.asarray(transformer.transform(frames[role]),dtype=np.float32)
    variance = np.var(encoded['FIT'],axis=0) > 0
    require(int(variance.sum()) >= 2, 'positive_known_FIT_variance')
    selector = SelectKBest(f_classif,k=min(50,int(variance.sum())))
    features = {'FIT':selector.fit_transform(encoded['FIT'][:,variance],arrays['FIT_y_fine']).astype(np.float32)}
    for role in ('CAL','DEV'):
        features[role] = selector.transform(encoded[role][:,variance]).astype(np.float32)
    require(all(np.isfinite(x).all() and len(x) == len(arrays[r+'_ids']) for r,x in features.items()), 'finite_known_features')
    names = np.asarray(transformer.get_feature_names_out())[variance][selector.get_support()].tolist()
    return features, dict(transformer=transformer,variance_mask=variance,selector=selector,
        selected_feature_names=names,family_order=FAMILIES,source_feature_columns=parent.config.NSL_FEATURE_COLUMNS)


def _fit_fixed_final(x_fit,y_coarse,y_fine):
    """Same MHFD loss/optimizer; fixed final epoch80, no validation interfaces."""
    parent.model.set_seed(SEED)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net = parent.model.MHFDNetwork(x_fit.shape[1],len(FAMILIES)).to(device)
    weights = parent.model._hierarchical_sample_weights(y_fine)
    sampler = WeightedRandomSampler(weights,num_samples=len(x_fit),replacement=True,
        generator=torch.Generator().manual_seed(SEED))
    loader = DataLoader(TensorDataset(torch.from_numpy(x_fit.astype(np.float32,copy=False)),
        torch.from_numpy(y_coarse),torch.from_numpy(y_fine)),
        batch_size=512 if len(x_fit)>=4000 else 256,sampler=sampler,num_workers=0,pin_memory=device.type=='cuda')
    optimizer = torch.optim.AdamW(net.parameters(),lr=1e-3,weight_decay=2e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=EPOCHS,eta_min=1e-4)
    coarse, fine, reconstruction = nn.CrossEntropyLoss(), nn.CrossEntropyLoss(label_smoothing=.01), nn.SmoothL1Loss()
    scaler = torch.amp.GradScaler('cuda',enabled=device.type=='cuda')
    start, history = time.perf_counter(), []
    for epoch in range(1,EPOCHS+1):
        net.train(); total, count = 0., 0
        for x,c,f in loader:
            x,c,f = x.to(device,non_blocking=True),c.to(device,non_blocking=True),f.to(device,non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=device.type=='cuda'):
                output = net(x)
                loss = coarse(output['coarse_logits'],c) + .35*fine(output['fine_logits'],f) + .03*reconstruction(output['reconstruction'],x)
            scaler.scale(loss).backward(); scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(net.parameters(),max_norm=5.)
            scaler.step(optimizer); scaler.update()
            total += float(loss.detach().cpu())*len(x); count += len(x)
        lr = float(optimizer.param_groups[0]['lr']); scheduler.step()
        history.append(dict(Epochs=epoch,Known_FIT_Loss=total/count,Learning_Rate=lr,Observed_Optimizer_Rows=count,
            validation_inference=False,checkpoint_selection=False))
        if epoch == 1 or epoch % 10 == 0:
            print(f'[NSL2 known union fixed final] epoch={epoch}/{EPOCHS} loss={total/count:.6f} elapsed={time.perf_counter()-start:.1f}s',flush=True)
    return SimpleNamespace(model=net,device=str(device),history=history,selected_epoch=EPOCHS,
        training_seconds=time.perf_counter()-start)


def _known_output_arrays(role,values,arrays,threshold):
    n = len(arrays[role+'_ids']); p = values.attack_probability
    require(p.shape == (n,) and p.dtype.kind == 'f' and np.isfinite(p).all() and np.all((p>=0)&(p<=1))
        and values.fine_probability.shape == (n,len(FAMILIES)) and np.isfinite(values.fine_probability).all()
        and values.embedding.shape[0] == n and np.isfinite(values.embedding).all()
        and values.reconstruction_error.shape == (n,) and np.isfinite(values.reconstruction_error).all(), 'finite_MHFD_known_output:'+role)
    pred = (p >= threshold).astype(np.int64)
    return {role+'_ids':arrays[role+'_ids'],role+'_truth':arrays[role+'_y_coarse'],role+'_fine_truth':arrays[role+'_y_fine'],
        role+'_prediction':pred,role+'_probability':p,role+'_fine_probability':values.fine_probability,
        role+'_embedding':values.embedding,role+'_reconstruction_error':values.reconstruction_error}


def _paired_baseline_known_control(arrays,predictions,pins):
    old = json.loads(checked(BASELINE,pins))
    require(old['execution_status'] == 'capped_NSL2_warm_known_training_completed' and old['metrics_evaluated'] is True
        and old['published'] is False and old['final_test_executed'] is False, 'frozen_known_baseline_required')
    with np.load(io.BytesIO(checked(old['files']['predictions'],pins)),allow_pickle=False) as z:
        ids, truth, pred = z['CAL_ids'].copy(), z['CAL_truth'].copy(), z['CAL_prediction'].copy()
    require(len(ids) == len(set(ids.tolist())) and len(ids) == len(truth) == len(pred), 'baseline_old_CAL_ordered_IDs')
    index = {str(v):i for i,v in enumerate(ids)}
    pairs = {}
    for role in ('CAL','DEV'):
        require(all(str(v) in index for v in arrays[role+'_ids']), 'new_control_must_be_old_CAL_subset')
        take = np.asarray([index[str(v)] for v in arrays[role+'_ids']],dtype=np.int64)
        require(np.array_equal(truth[take],arrays[role+'_y_coarse']), 'paired_control_truth_binding')
        candidate = predictions[role+'_prediction']; y = arrays[role+'_y_coarse']
        pairs[role] = dict(exact_same_ordered_ids=array_descriptor(arrays[role+'_ids']),
            baseline=gates(y,pred[take]),candidate=gates(y,candidate),
            correct_delta={name:int(np.sum((y==label)&(candidate==label))-np.sum((y==label)&(pred[take]==label))) for label,name in enumerate(('BEN','KNA'))},
            descriptive_warm_pair_only=True, causal_data_only_improvement_claimed=False)
    return pairs


def run_training(*,plan_report,output_directory=OUTPUT):
    out = Path(output_directory).resolve()
    require(out.is_relative_to(ROOT/'data/external_dev/processed'), 'processed_child_output_required')
    out.mkdir(parents=True,exist_ok=False)
    start, stage, pins = time.perf_counter(), 'validate_metadata_plan', {}
    report = dict(configuration=POLICY,status='FAIL_TARGET99',published=False,final_test_executed=False,
        training_started=False,training_completed=False,training_runs=0,metrics_evaluated=False,
        known_inference_roles_started=[],known_inference_roles_returned=[],coarse_threshold_sealed=False,
        DEV_executed=False,OPEN_numeric_members_decoded=False,OPEN_inference=False,raw_source_opened_or_hashed=False,
        accepted_baseline_replaced=False,EffectDelta={'verdict':'NOT_COMPARABLE','reason':'known supervised roles changed; old CP enters FIT'},files={})
    try:
        plan,records = _load_plan(plan_report,pins)
        old_arrays,old_frames = _load_known_values(pins,records)
        arrays,frames = _reallocate(plan,old_arrays,old_frames)
        for module in (planner,parent,parent.source_code,parent.model,parent.data,parent.config,seal):
            pins[str(Path(module.__file__).resolve())] = sha(module.__file__)
        pins[str(Path(__file__).resolve())] = sha(__file__)
        stage = 'FIT_original_group_only_preprocessing'
        features,prep = _prepare(arrays,frames)
        prep_path = out/'complete_FIT_preprocessing.joblib'; joblib.dump(prep,prep_path,compress=3)
        prep_item = descriptor(prep_path); pins[prep_item['path']] = prep_item['sha256']
        loaded = joblib.load(io.BytesIO(checked(prep_item,pins)))
        for role in MODEL_ROLES:
            x = np.asarray(loaded['transformer'].transform(frames[role]),dtype=np.float32)
            replay = loaded['selector'].transform(x[:,loaded['variance_mask']]).astype(np.float32)
            require(array_descriptor(replay) == array_descriptor(features[role]), 'preprocessing_roundtrip:'+role)
        material = {**arrays,**{r+'_features':features[r] for r in MODEL_ROLES}}
        material_bound = {k:array_descriptor(v) for k,v in material.items()}
        input_item = seal.save_npz(out/'exact_known_inputs_before_fit.npz',pins,**material)
        require(all(array_descriptor(v) == material_bound[k] for k,v in material.items()), 'live_material_changed_after_save')
        index = arrays['FIT_optimization_indices']
        report['files'].update(preprocessing=prep_item,training_inputs=input_item)
        prefit = seal.pin_json(out/'training_policy_before_fit.json',dict(configuration=POLICY,plan_report=plan_report,
            input_sha256=dict(pins),preprocessing=prep_item,known_inputs=input_item,
            role_summary=plan['role_summary'],training_effective_aggregate=plan['training_effective_aggregate'],
            optimizer_X=array_descriptor(features['FIT'][index]),optimizer_y_fine=array_descriptor(arrays['FIT_y_fine'][index]),
            optimizer_y_coarse=array_descriptor(arrays['FIT_y_coarse'][index]),runtime_environment={'CUBLAS_WORKSPACE_CONFIG':os.environ.get('CUBLAS_WORKSPACE_CONFIG')},
            CAL_DEV_used_for_checkpoint_selection=False,OPEN_numeric_members_decoded=False),pins)
        report['files']['prefit'] = prefit
        stage = 'one_fixed_final_known_MHFD_training'
        require(all(array_descriptor(v) == material_bound[k] for k,v in material.items()), 'live_material_changed_before_fit')
        with np.load(io.BytesIO(checked(input_item,pins)),allow_pickle=False) as stored:
            require(set(stored.files) == set(material_bound)
                and all(array_descriptor(stored[k]) == material_bound[k] for k in stored.files), 'saved_material_changed_before_fit')
        torch.set_num_threads(4); report.update(training_started=True,training_runs=None)
        result = _fit_fixed_final(features['FIT'][index],arrays['FIT_y_coarse'][index],arrays['FIT_y_fine'][index])
        require(result.selected_epoch == EPOCHS and [h['Epochs'] for h in result.history] == list(range(1,EPOCHS+1)), 'all80_fixed_final_epochs_required')
        report.update(training_completed=True,training_runs=1,training_seconds=float(result.training_seconds),selected_epoch=EPOCHS,device=result.device)
        stage = 'freeze_final_MHFD'
        state = {k:v.detach().cpu() for k,v in result.model.state_dict().items()}
        model_path = out/'fixed_epoch80_MHFD_state.pt'
        torch.save(dict(state_dict=state,input_dim=features['FIT'].shape[1],fine_class_count=len(FAMILIES),selected_epoch=EPOCHS,seed=SEED),model_path)
        saved = torch.load(model_path,map_location='cpu',weights_only=True)
        require(set(saved['state_dict']) == set(state) and all(torch.equal(v,saved['state_dict'][k]) for k,v in state.items()), 'fixed_model_roundtrip')
        model_item = descriptor(model_path); pins[model_item['path']] = model_item['sha256']; report['files']['model'] = model_item
        outputs = {}
        for role in ('FIT','CAL','DEV'):
            stage = 'known_inference_'+role
            if role == 'DEV':
                threshold,metrics = parent.model.choose_coarse_threshold(arrays['CAL_y_coarse'],outputs['CAL'].attack_probability)
                threshold_item = seal.pin_json(out/'coarse_threshold_from_known_CAL.json',dict(threshold=float(threshold),
                    selection_role='CAL',CAL_ids=array_descriptor(arrays['CAL_ids']),CAL_probability=array_descriptor(outputs['CAL'].attack_probability),
                    metrics=metrics,DEV_labels_used=False,model=model_item),pins)
                report['files']['threshold'] = threshold_item; report['coarse_threshold_sealed'] = True
            report['known_inference_roles_started'].append(role)
            outputs[role] = parent.model.infer(result.model,features[role],device=torch.device(result.device))
            report['known_inference_roles_returned'].append(role)
        stage = 'seal_known_predictions_before_paired_baseline'
        pred_arrays = {}
        original_gates, unique_gates = {}, {}
        for role in MODEL_ROLES:
            current = _known_output_arrays(role,outputs[role],arrays,threshold); pred_arrays.update(current)
            pred = current[role+'_prediction']; truth = arrays[role+'_y_coarse']; unique = arrays[role+'_density_indices']
            original_gates[role] = gates(truth,pred)
            unique_gates[role] = gates(truth[unique],pred[unique])
        predictions = seal.save_npz(out/'sealed_known_predictions.npz',pins,**pred_arrays)
        report['files']['predictions'] = predictions
        report['files']['history'] = seal.pin_json(out/'training_history.json',result.history,pins)
        stage = 'saved_baseline_same_ID_known_control_pair'
        pairs = _paired_baseline_known_control(arrays,pred_arrays,pins)
        report['files']['paired_known_controls'] = seal.pin_json(out/'paired_known_controls.json',pairs,pins)
        seal.integrity(pins)
        report.update(execution_status='warm_known_FIT_coverage_fixed_final_training_completed',metrics_evaluated=True,DEV_executed=True,
            known_class_gates=original_gates,unique_group_class_gates=unique_gates,paired_known_controls=pairs,
            coarse_threshold=float(threshold),role_summary=plan['role_summary'],training_effective_aggregate=plan['training_effective_aggregate'],
            CAL_DEV_passed=all(g['passed'] for view in (original_gates,unique_gates) for role in ('CAL','DEV') for g in view[role].values()),
            candidate_ready_for_warm_UNA_review=False,independent_final_admitted=False,final_input_pins_unchanged=True)
    except Exception as exc:
        report.update(execution_status='protocol_stop' if isinstance(exc,(parent.util.NativeKnownTrainingStop,parent.source_code.KnownSourceExtractStop)) else 'execution_failed',
            failed_stage=stage,error_type=type(exc).__name__,error_message=str(exc))
    report.update(input_sha256=pins,wall_seconds=time.perf_counter()-start)
    write_json(out/'report.json',report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-report',required=True); parser.add_argument('--plan-report-sha256',required=True)
    parser.add_argument('--output-directory',type=Path,default=OUTPUT)
    args = parser.parse_args(argv)
    report = run_training(plan_report={'path':args.plan_report,'sha256':args.plan_report_sha256},output_directory=args.output_directory)
    print(json.dumps({k:report.get(k) for k in ('execution_status','training_seconds','known_class_gates','unique_group_class_gates','failed_stage','error_message')},ensure_ascii=False))
    return 0 if report['metrics_evaluated'] else 2 if report['execution_status'] == 'protocol_stop' else 1


if __name__ == '__main__':
    raise SystemExit(main())
