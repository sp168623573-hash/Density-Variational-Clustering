"""Same exact149 K7; compute each unordered seed/candidate pair once."""
import hashlib, importlib, importlib.metadata, time
from fractions import Fraction
from pathlib import Path
import numpy as np
import scipy.spatial.distance as distance
from scipy.spatial.distance import cdist
from . import nsl1_source_hub_holding_core_v716 as holding

K=7
PREFETCH=8*K
PAIR_CHUNK=16384
EPS=np.finfo(np.float64).eps
M=2*149+8
GAMMA=M*EPS/(1.-M*EPS)

def numerical_proof():
    u=Fraction(1,2**53);g=151*u/(1-151*u);ratio=(1-g)/(1+g)
    f=float(1.-4*GAMMA);margin=ratio-Fraction(f)*(1+u)
    require(margin>0 and f.hex()=='0x1.ffffffffff670p-1' and .5<f<1.,'exact rational shrink factor dominates both phi rounding paths including product')
    return dict(unit_roundoff=str(u),g151u=str(g),phi_ratio_lower=str(ratio),
                m=M,eps=EPS,gamma=GAMMA,shrink_factor=f,shrink_factor_hex=f.hex(),
                strict_margin_exact=str(margin),strict_margin_float=float(margin),
                direct_difference_square_sum=True,postscale_float64_same_inputs=True,
                required_normal='Every nonzero coordinate difference/square, cumulative positive sum and phi*f finite normal; source minpositivegap>=sqrt(16*tiny) and safe maxabs prove these with margin.',
                zero_phi='Always retain all nonself phi0 candidates.',
                fallback='If normal certificate or finite row fails, evaluate all nonself source candidates.',
                actual_metric_lower='Frozen mu>=0 and nonnegative omega*squared imply computed d_actual>=sqrt(phi_original).')

def require(ok,text):
    if not bool(ok):raise ValueError(text)

def runtime_pins():
    py=Path(distance.__file__).resolve();binary=Path(importlib.import_module('scipy.spatial._distance_pybind').__file__).resolve()
    result=dict(scipy_version=importlib.metadata.version('scipy'),python_distance=dict(path=str(py),sha256=hashlib.sha256(py.read_bytes()).hexdigest()),binary=dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
    require(result['scipy_version']=='1.13.1' and result['binary']['sha256']=='e578bf0791c94f1b6868fb5d74664d9317a3c97682e55ce19dceef231627c522' and result['python_distance']['sha256']=='16a0edd0bc084685419dad610a5836476f813354a0ee95c8b160b29253caae81','pinned direct difference-square cdist implementation version/binary')
    func=distance._METRIC_ALIAS['sqeuclidean'].cdist_func
    require(func.__module__=='scipy.spatial._distance_pybind' and func.__name__=='cdist_sqeuclidean','actual cdist sqeuclidean direct difference kernel binding')
    return result

def aligned_original_distance(scaled,qix,rix,W,mu):
    """Same float64 expression/last-axis order as frozen149 pairwise_distances."""
    result=np.empty(len(qix),np.float64)
    for start in range(0,len(qix),PAIR_CHUNK):
        stop=min(start+PAIR_CHUNK,len(qix));delta=np.abs(scaled[qix[start:stop]]-scaled[rix[start:stop]])
        squared=delta**2;logits=delta*W[:,0]+squared*W[:,1]
        logits-=logits.max(axis=1,keepdims=True);omega=np.exp(logits);omega/=omega.sum(axis=1,keepdims=True)
        result[start:stop]=np.sqrt(squared.sum(axis=1)+mu*(omega*squared).sum(axis=1))
    require(np.isfinite(result).all()and np.all(result>=0),'finite original149 Eq9/10 actual distances')
    return result

def source_graph(metric,z):
    started=time.perf_counter();stage=[]
    def tick(name):
        nonlocal started
        now=time.perf_counter();stage.append((name,now-started));started=now
    runtime_pins();numerical_proof();metric._check()
    z=np.asarray(z,np.float64);require(z.shape==(5999,149)and metric.dimension==149,'original all5999 source149 unchanged')
    scaled=np.asarray(z,np.float64)/metric.scale;W=np.asarray(metric.W,np.float64);mu=float(metric.mu);n=len(z)
    require(np.isfinite(scaled).all()and np.isfinite(W).all()and np.all(W>=0)and np.isfinite(mu)and mu>=0,'original positive metric correction and finite postscale source')
    min_gap=np.full(149,np.inf);max_gap=np.zeros(149);maxabs=np.abs(scaled).max(0)
    for j in range(149):
        v=np.unique(scaled[:,j]);gaps=np.diff(v)
        if len(gaps):min_gap[j]=gaps.min();max_gap[j]=v[-1]-v[0]
    # These margins are arithmetic proof premises, never classification epsilons.
    normal_small=np.all(min_gap[np.isfinite(min_gap)]>=np.sqrt(16*np.finfo(float).tiny))
    normal_large=float(maxabs.max())<=np.sqrt(np.finfo(float).max/(16*(149+mu+1)))
    safe_logits=np.isfinite(float(max_gap.max())*float(W[:,0].max())+float(max_gap.max())**2*float(W[:,1].max()))
    normal_shrunken_product=bool(normal_small and (1.-4*GAMMA)>.5)
    certificate_ok=bool(normal_small and normal_large and normal_shrunken_product and safe_logits and 4*GAMMA<.25)
    tick('owner_scale_and_normal_certificate')
    # Finite arithmetic identity check only, not a fitted or selected model.
    probe=metric.pairwise_distances(z[:8],z[:9])
    aligned=aligned_original_distance(scaled,np.repeat(np.arange(8),9),np.tile(np.arange(9),8),W,mu).reshape(8,9)
    require(np.array_equal(probe,aligned),'aligned original149 formula exactly matches frozen public operator on registered source-prefix arithmetic contract')
    reverse=aligned_original_distance(scaled,np.tile(np.arange(9),8),np.repeat(np.arange(8),9),W,mu).reshape(8,9)
    require(np.array_equal(probe,reverse),'original149 distance exact byte symmetry including signed-zero abs')
    tick('public_aligned_and_symmetry_contract')
    constant=np.all(scaled==scaled[0],axis=0);active=~constant
    require(np.array_equal(scaled[:,constant],np.broadcast_to(scaled[0,constant],(n,int(constant.sum())))),
            'cold source exact constant columns have strictly zero pair delta; never epsilon selection')
    phi=cdist(scaled[:,active],scaled[:,active],metric='sqeuclidean') if active.any() else np.zeros((n,n))
    np.fill_diagonal(phi,np.inf)
    tick('allsource_cdist_lowerbounds')
    prefetch_count=min(PREFETCH,n-1);prefetch=np.empty((n,prefetch_count),np.int64)
    for i in range(n):
        row=phi[i];pivot=np.partition(row,prefetch_count-1)[prefetch_count-1]
        less=np.flatnonzero(row<pivot);ties=np.flatnonzero(row==pivot);choose=np.r_[less,ties[:prefetch_count-len(less)]]
        require(len(choose)==prefetch_count and i not in choose,'fixed56 distinct nonself algorithmic prefetch candidates')
        prefetch[i]=choose[np.lexsort((choose,row[choose]))]
    tick('stable_phi_prefetch56_selection')
    seedq=np.repeat(np.arange(n),prefetch_count);seedr=prefetch.ravel()
    seedkeys=np.minimum(seedq,seedr)*n+np.maximum(seedq,seedr)
    unique_seed,seed_inverse=np.unique(seedkeys,return_inverse=True)
    seed_values=aligned_original_distance(scaled,unique_seed//n,unique_seed%n,W,mu)
    prefetch_distance=seed_values[seed_inverse].reshape(n,prefetch_count)
    chosen=np.lexsort((prefetch,prefetch_distance),axis=1)[:,:K]
    seed=np.take_along_axis(prefetch,chosen,axis=1);seed_distance=np.take_along_axis(prefetch_distance,chosen,axis=1)
    upper=seed_distance[:,-1]
    tick('unique_prefetch_actual149_and_top7_upper')
    offsets=[0];parts=[];fallback=np.zeros(n,bool);lower_min_discarded=np.full(n,np.inf)
    for i in range(n):
        row=phi[i]
        if not certificate_ok or not(np.all(np.isfinite(row[np.arange(n)!=i]))and np.all(row>=0)):
            selected=np.flatnonzero(np.arange(n)!=i);fallback[i]=True
        else:
            lower=np.nextafter(np.sqrt(row*(1.-4*GAMMA)),0.)
            lower[row==0]=0.;lower[i]=np.inf
            selected=np.union1d(np.flatnonzero(lower<=upper[i]),seed[i])
            selected=selected[selected!=i]
            discarded=np.ones(n,bool);discarded[selected]=False;discarded[i]=False
            if discarded.any():lower_min_discarded[i]=lower[discarded].min()
            require(not discarded.any()or lower_min_discarded[i]>upper[i],'every discarded pair certified strictly beyond seed upperbound; ties included')
        require(len(selected)>=K and not np.any(selected==i),'full nonself candidate coverage including allnear/zero ties')
        parts.append(selected.astype(np.int64));offsets.append(offsets[-1]+len(selected))
    del phi
    offsets=np.asarray(offsets,np.int64);candidates=np.concatenate(parts);pair_q=np.repeat(np.arange(n),np.diff(offsets));del parts
    tick('full_candidate_CSR')
    keys=np.minimum(pair_q,candidates)*n+np.maximum(pair_q,candidates)
    unique_candidate,candidate_inverse=np.unique(keys,return_inverse=True)
    seedpos=np.searchsorted(unique_seed,unique_candidate);from_seed=seedpos<len(unique_seed)
    at=np.flatnonzero(from_seed);from_seed[at]=unique_seed[seedpos[at]]==unique_candidate[at]
    unique_values=np.empty(len(unique_candidate),np.float64);unique_values[from_seed]=seed_values[seedpos[from_seed]]
    missing=unique_candidate[~from_seed]
    require(np.all(np.diff(offsets)>=K),'all certified row candidate populations contain the true-top7 upper witnesses')
    tick('unordered_unique_sort_and_seed_lookup')
    unique_values[~from_seed]=aligned_original_distance(scaled,missing//n,missing%n,W,mu)
    tick('new_unique_candidate_actual149')
    actual=unique_values[candidate_inverse]
    tick('restore_original_ordered_CSR_distances')
    nearest=np.empty((n,K),np.int64);nearest_distance=np.empty((n,K))
    for i in range(n):
        start,stop=offsets[i:i+2];order=np.lexsort((candidates[start:stop],actual[start:stop]))[:K]
        nearest[i]=candidates[start:stop][order];nearest_distance[i]=actual[start:stop][order]
    sigma,weights=holding.gaussian_weights(nearest_distance)
    indegree=np.bincount(nearest.ravel(),weights=weights.ravel(),minlength=n)
    tick('stable_K7_Gaussian_indegree')
    metric._check()
    tick('final_original_owner_check')
    return dict(source_neighbors7=nearest,source_neighbor_distances7=nearest_distance,source_sigma7=sigma,
      source_row_normalized_weights7=weights,source_weighted_indegree=indegree,
      exact_unordered_source_pairs=np.asarray(n*(n-1)//2,np.int64),
      seed_neighbors7=seed,seed_actual_distances7=seed_distance,seed_upperbound=upper,
      prefetch_neighbors56=prefetch,prefetch_actual_distances56=prefetch_distance,
      seed_top7_prefetch_positions=chosen,prefetch_neighbor_count=np.asarray(prefetch_count,np.int64),
      candidate_offsets=offsets,candidate_source_indices=candidates,candidate_actual_distances=actual,
      unique_prefetch_unordered_keys=unique_seed,unique_prefetch_distances=seed_values,prefetch_to_unique=seed_inverse,
      unique_candidate_unordered_keys=unique_candidate,unique_candidate_distances=unique_values,
      candidate_to_unique=candidate_inverse,unique_candidate_reused_seed=from_seed,
      fallback_rows=fallback,smallest_discarded_certified_lower=lower_min_discarded,
      postscale_min_positive_gap149=min_gap,postscale_max_gap149=max_gap,postscale_maxabs149=maxabs,
      lower_bound_m=np.asarray(M,np.int64),lower_bound_gamma=np.asarray(GAMMA),
      lower_bound_factor=np.asarray(1.-4*GAMMA),normal_certificate_passed=np.asarray(certificate_ok),
      normal_small_gap_passed=np.asarray(normal_small),normal_large_range_passed=np.asarray(normal_large),
      normal_shrunken_product_passed=np.asarray(normal_shrunken_product),
      safe_logit_products_passed=np.asarray(safe_logits),actual_metric_seed_pairs=np.asarray(len(unique_seed),np.int64),
      logical_seed_ordered_pairs=np.asarray(n*K,np.int64),
      logical_prefetch_ordered_pairs=np.asarray(n*prefetch_count,np.int64),
      aligned_public_prefix_contract_passed=np.asarray(True),
      exact_symmetry_prefix_contract_passed=np.asarray(True),
      actual_metric_candidate_pairs=np.asarray(len(missing),np.int64),
      logical_candidate_ordered_pairs=np.asarray(len(candidates),np.int64),
      all_nonself_lowerbounds_evaluated=np.asarray(n*(n-1),np.int64),
      computation_stage_labels=np.asarray([x[0]for x in stage]),
      computation_stage_seconds=np.asarray([x[1]for x in stage]),
      cheap_bound_source_constant_mask149=constant,
      cheap_bound_source_first_values149=scaled[0],
      cheap_bound_source_nonconstant_fields=np.flatnonzero(active),
      actual_metric_full_width=np.asarray(149,np.int64))

def synthetic():
    # A positive correction can reverse the phi ordering; seed U must not be
    # confused with the base-distance radius, and equality must stay included.
    phi=np.asarray([0.,1.,4.,9.]);actual=np.asarray([0.,10.,2.,3.]);U=actual[[1,2]].max()
    lower=np.nextafter(np.sqrt(phi*(1.-4*GAMMA)),0.);kept=lower<=U
    require(kept[2]and kept[3]and np.all(lower<=actual),'hand constructed order reversal retains all possible actual nearest')
    tie=np.nextafter(np.sqrt(np.asarray([4.])*(1.-4*GAMMA)),0.)
    require(tie[0]<=2. and lower[0]==0.,'near/equal/zero bounds are conservative and included')
    # Registered physical-domain extremes: true Gaussian7 weights, source5999,
    # empty seeds, unit seeds, alternating seeds, source-heavy and query-only.
    anchors=5999;queries=9;D=np.ones(anchors)
    for source_heavy in (False,True):
        nbr=np.empty((queries,7),np.int64)
        for i in range(queries):
            others=[anchors+j for j in range(queries)if j!=i]
            nbr[i]=([0,1,2,3,4]+others[:2])if source_heavy else others[:7]
        for sigma in (0.,1e-150,1.):
            dist=np.zeros((queries,7))if sigma==0 else np.tile(np.linspace(0,sigma,7),(queries,1))
            _,weights=holding.gaussian_weights(dist)
            for seed in (np.zeros(queries,bool),np.ones(queries,bool),np.arange(queries)%2==0):
                value=holding.holding_diffusion(nbr,weights,seed,D)
                require(np.all(value['trajectory']<=1)and np.all(value['trajectory']>=value['original_trajectory']),
                        'Gaussian physical-domain boundary roundoff fixtures stay bounded and monotone')
    return dict(synthetic_only=True,positive_correction_order_reversal=True,zero_tie_inclusion=True,
                direct_difference_square_cdist=True,gamma_m=M,float64_eps=EPS,
                gamma=GAMMA,factor=1.-4*GAMMA,paired_kernel_last_axis149=True,
                proof_failure_full_evaluation=True,Gaussian_boundary_fixtures=18,
                algorithmic_prefetch_count=56,final_K_unchanged=7,
                any_subset_top7_upperbounds_global_top7=True,
                prefetch_not_a_model_parameter=True)
