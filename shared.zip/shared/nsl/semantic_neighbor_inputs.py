from pathlib import Path
import os,sys,importlib.util
for k in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='2'
os.environ['CUDA_VISIBLE_DEVICES']='-1'
import numpy as np
import torch
torch.set_num_threads(2)
H=Path(__file__).resolve().parent;I=H.parents[1];ROOT=I.parent;R24=I/'neighbor_evidence_20261031_r24/nsl2';R21=I/'source_coverage_20261031_r21/nsl2'
s=importlib.util.spec_from_file_location('r25_parent_inputs',R21/'common.py');P=importlib.util.module_from_spec(s);sys.modules[s.name]=P;s.loader.exec_module(P)
M=P.M;A=P.A;Clean=P.Clean;Adapter=P.Adapter;Base=P.Base;STATUS=P.STATUS;save=P.save
Pair=M.mod(R24/'pair_affinity.py','r25_pair')
def role_data(role):
    q=P.role_data(role);seed=R21/'hard_ben_once/detect_only'/(role+'-predict/prediction_before_truth.npz')
    with np.load(seed,allow_pickle=False) as a:assert np.array_equal(a['ids'],q['ids']);q['seed_parent']=a['prediction']
    q['seed_parent_ref']=M.desc(seed)
    p=I/'source_enrichment_20261101_r32/nsl2/refreshed_once/KNA_return_only'/(role+'-predict/prediction_before_truth.npz')
    with np.load(p,allow_pickle=False) as a:assert np.array_equal(a['ids'],q['ids']);q['parent']=a['prediction']
    q['parent_ref']=M.desc(p);return q
