"""Known-FIT-only rank16 identity-residual projection before owned Eq9/10.

New117 cached embedding/direct geometry is unchanged. A=I+UV^T acts on
the frozen knownFIT scalar-normalized149 coordinates. U starts at zero;
V uses a separately seeded thin QR basis. Exact constant FIT axes have
zero residual factor rows and retain their original identity passthrough.
All U,V,W,mu learn from the original known-fine pair contrastive objective;
the sole added penalty is .01||A-I||_F^2 (no dimensional division).
This is a declared feature-interaction extension, not exact reproduction
of the manuscript original-coordinate formula. No import-time asset reads.
"""
from __future__ import annotations
import copy
from pathlib import Path
import time
from typing import Any
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from . import nsl1_expandedaux149_pair_metric_v1 as inherited

SCHEMA='NSL1-FIT6000-projected149-owned-Eq9-10-lowrank16-v1'
MATH_SOURCE_MODULE='paper_open_set/nsl1_expandedaux149_pair_metric_v1.py'
MATH_SOURCE_SHA256='0b8a74f662a78e14df4f59c38cd1e849bfaee96de4d1f76fdaa8b6c0413636bd'
SEED, EPOCHS, PAIR_COUNT = inherited.SEED, inherited.EPOCHS, inherited.PAIR_COUNT
PROJECTION_RANK, PROJECTION_SEED, PROJECTION_REGULARIZATION = 16, 20261009, .01
_require, _digest, _immutable = inherited._require, inherited._digest, inherited._immutable
_array_descriptor, _matrix, _json_state, _summary = inherited._array_descriptor, inherited._matrix, inherited._json_state, inherited._summary
PairMetricProtocolStop=inherited.PairMetricProtocolStop

def training_recipe(dimension: int) -> dict:
    result=inherited.training_recipe(dimension)
    result.update(schema_version=SCHEMA,
        distance='owned Eq9/10 on A*(Z/FIT_RMS), A=I+UV^T; raw149 passed once through A',
        original_coordinate_L2_lower_bound=False, projected_coordinate_L2_lower_bound=True,
        projection=dict(rank=min(PROJECTION_RANK,dimension),seed=PROJECTION_SEED,
            initial_U='exact zero',initial_V='seeded thin QR, exact constant FIT rows zero',
            regularization='.01*||UV^T||_F^2, no dimension division',
            constant_axis_rule='exact zero range across unique FIT groups => residual rows zero; identity passthrough remains',
            trained_roles=['FIT'],query_used=False),
        no_triplet_or_margin_change=True, extension_not_original_coordinate_formula=True)
    return result

def active_axes(z: np.ndarray) -> np.ndarray:
    a=np.asarray(z,np.float64)
    _require(a.ndim==2 and len(a)>0 and np.isfinite(a).all(),'finite unique scaled FIT')
    return np.any(a != a[0],axis=0)

def _prepare(z_fit: Any,y_fit_fine: Any,**kwargs):
    z,pairs,same,weights,previous=inherited._prepare(z_fit,y_fit_fine,**kwargs)
    prefit=copy.deepcopy(previous)
    previous_sha=prefit.pop('prefit_sha256')
    prefit.update(schema_version=SCHEMA+'-before-fit',recipe=training_recipe(z.shape[1]),
        projection_active_axes=active_axes(z).tolist(),inherited_unprojected_pair_plan_sha256=previous_sha,
        projection_pair_mining='same original149 FIT pair plan; no projected re-mining or query mining')
    prefit['prefit_sha256']=_digest(prefit)
    return z,pairs,same,weights,prefit

def prefit_descriptor(z_fit: Any,y_fit_fine: Any,**kwargs) -> dict:
    return _prepare(z_fit,y_fit_fine,**kwargs)[-1]

class VariationalPairNetwork(inherited.VariationalPairNetwork):
    def __init__(self,dimension: int,active):
        super().__init__(dimension)
        mask=torch.as_tensor(active,dtype=torch.float64,device='cpu')
        _require(mask.shape==(dimension,) and bool(torch.any(mask>0)),'FIT-identified projection axes')
        self.register_buffer('active_mask',mask)
        rank=min(PROJECTION_RANK,dimension)
        generator=torch.Generator(device='cpu').manual_seed(PROJECTION_SEED)
        q,_=torch.linalg.qr(torch.randn(dimension,rank,dtype=torch.float64,generator=generator),mode='reduced')
        self.raw_U=nn.Parameter(torch.zeros(dimension,rank,dtype=torch.float64))
        self.raw_V=nn.Parameter(q*mask[:,None])

    def projected_factors(self):
        return self.raw_U*self.active_mask[:,None],self.raw_V*self.active_mask[:,None]

    def project_scaled(self,value):
        u,v=self.projected_factors()
        return value+(value@v)@u.T

    def projection_regularizer(self):
        u,v=self.projected_factors()
        return (u@v.T).square().sum()

    def squared_distance(self,left,right):
        return super().squared_distance(self.project_scaled(left),self.project_scaled(right))


def _train(z: np.ndarray, pairs: np.ndarray, same: np.ndarray,
           weights: np.ndarray) -> dict:
    previous_threads = torch.get_num_threads()
    previous_deterministic = torch.are_deterministic_algorithms_enabled()
    previous_warn_only = torch.is_deterministic_algorithms_warn_only_enabled()
    try:
        torch.set_num_threads(4)
        torch.use_deterministic_algorithms(True)
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(SEED)
            model = VariationalPairNetwork(z.shape[1], active_axes(z))
            optimizer = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=1e-6)
            generator = torch.Generator().manual_seed(SEED)
            values = torch.from_numpy(np.array(z, copy=True))
            index = torch.from_numpy(pairs.copy())
            is_same = torch.from_numpy(same.copy())
            importance = torch.from_numpy(weights.copy())
            with torch.no_grad():
                before = model(values[index[:, 0]], values[index[:, 1]]).numpy()
            history = []
            started = time.perf_counter()
            for epoch in range(1, EPOCHS + 1):
                epoch_loss = 0.0; max_gradient = 0.0; epoch_contrastive = 0.0; epoch_penalty = 0.0
                for selection in torch.randperm(len(index), generator=generator).split(256):
                    optimizer.zero_grad(set_to_none=True)
                    part = index[selection]
                    distance = model(values[part[:, 0]], values[part[:, 1]])
                    row_loss = torch.where(is_same[selection], distance.square(),
                                           torch.relu(2.0 - distance).square())
                    contrastive = (row_loss * importance[selection]).sum() * len(index) / len(selection)
                    penalty = model.projection_regularizer()
                    loss = contrastive + PROJECTION_REGULARIZATION * penalty
                    _require(bool(torch.isfinite(loss)), "nonfinite_known_pair_loss")
                    loss.backward()
                    _require(all(p.grad is not None and bool(torch.isfinite(p.grad).all())
                                 for p in model.parameters()), "nonfinite_known_pair_gradient")
                    gradient = float(torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0))
                    optimizer.step()
                    _require(all(bool(torch.isfinite(p).all()) for p in model.parameters()),
                             "nonfinite_learned_known_pair_parameters")
                    max_gradient = max(max_gradient, gradient)
                    epoch_loss += float(loss.detach()) * len(selection) / len(index)
                    epoch_contrastive += float(contrastive.detach()) * len(selection) / len(index)
                    epoch_penalty += float(penalty.detach()) * len(selection) / len(index)
                history.append({"epoch": epoch, "weighted_loss": epoch_loss,
                                "mu": float(F.softplus(model.raw_mu).detach()),
                                "max_gradient_norm_before_clip": max_gradient, "weighted_contrastive_loss": epoch_contrastive, "projection_squared_Frobenius": epoch_penalty})
            seconds = time.perf_counter() - started
            with torch.no_grad():
                after = model(values[index[:, 0]], values[index[:, 1]]).numpy()
                raw_mu = float(model.raw_mu)
                raw_w = model.raw_W.numpy().copy()
                mu = float(F.softplus(model.raw_mu))
                w = F.softplus(model.raw_W).numpy().copy()
            base = np.sqrt(np.sum((z[pairs[:, 0]] - z[pairs[:, 1]]) ** 2, axis=1))
            return {"raw_mu": raw_mu, "raw_W": raw_w.tolist(), "mu": mu, "W": w.tolist(),
                    "projection_U": model.projected_factors()[0].detach().numpy().tolist(),
                    "projection_V": model.projected_factors()[1].detach().numpy().tolist(),
                    "active_axes": model.active_mask.bool().numpy().tolist(),
                    "history": history, "training_seconds": seconds,
                    "optimizer_state": _json_state(optimizer.state_dict()),
                    "pair_distance_audit": {
                        "base_positive": _summary(base[same]), "base_negative": _summary(base[~same]),
                        "initial_positive": _summary(before[same]), "initial_negative": _summary(before[~same]),
                        "trained_positive": _summary(after[same]), "trained_negative": _summary(after[~same]),
                        "mu_changed": mu != float(z.shape[1]), "mu_initial": float(z.shape[1]),
                        "mu_final": mu, "W_min": float(w.min()), "W_max": float(w.max()),
                        "learned_mu_near_zero_1e_minus8": mu <= 1e-8,
                    }}
    finally:
        torch.set_num_threads(previous_threads)
        torch.use_deterministic_algorithms(previous_deterministic, warn_only=previous_warn_only)

class PaperVariationalPairMetric:
    """Frozen serializable dissimilarity; inference never fits or mutates state."""
    def __init__(self, state: dict):
        state = copy.deepcopy(state)
        supplied = state.pop("state_sha256", None)
        _require(supplied == _digest(state), "serialized_pair_metric_state_digest_mismatch")
        _require(state.get("schema_version") == SCHEMA, "unexpected_pair_metric_schema")
        prefit = state["prefit_descriptor"]
        dimension = prefit["recipe"]["embedding_dimension"]
        _require(prefit["recipe"] == training_recipe(dimension), "pair_metric_recipe_drift")
        check_prefit = dict(prefit); stored_prefit_digest = check_prefit.pop("prefit_sha256")
        _require(stored_prefit_digest == _digest(check_prefit), "pair_metric_prefit_digest_mismatch")
        self.dimension = dimension
        self.scale = float(prefit["frozen_FIT_RMS_scale"])
        self.mu = float(state["trained"]["mu"])
        self.W = _immutable(state["trained"]["W"])
        self.active_axes = _immutable(prefit['projection_active_axes'], dtype=np.bool_)
        self.U = _immutable(state['trained']['projection_U'])
        self.V = _immutable(state['trained']['projection_V'])
        rank = min(PROJECTION_RANK, dimension)
        _require(self.active_axes.shape == (dimension,) and self.active_axes.any()
                 and self.U.shape == self.V.shape == (dimension, rank)
                 and np.isfinite(self.U).all() and np.isfinite(self.V).all()
                 and np.array_equal(self.active_axes, state['trained']['active_axes'])
                 and np.all(self.U[~self.active_axes] == 0) and np.all(self.V[~self.active_axes] == 0),
                 'FIT-identified masked finite projection factors, no random constant-axis interactions')
        _require(np.isfinite(self.scale) and self.scale > 0 and np.isfinite(self.mu) and self.mu >= 0
                 and self.W.shape == (dimension, 2) and np.isfinite(self.W).all()
                 and np.all(self.W >= 0), "finite_nonnegative_frozen_pair_parameters_required")
        trained = state["trained"]
        raw_w = np.asarray(trained["raw_W"], np.float64)
        raw_mu = float(trained["raw_mu"])
        _require(raw_w.shape == (dimension, 2) and np.isfinite(raw_w).all()
                 and np.isfinite(raw_mu), "finite_complete_raw_pair_parameters_required")
        with torch.no_grad():
            expected_w = F.softplus(torch.from_numpy(raw_w)).numpy()
            expected_mu = float(F.softplus(torch.tensor(raw_mu, dtype=torch.float64)))
        _require(np.array_equal(expected_w, self.W) and expected_mu == self.mu,
                 "serialized_raw_positive_pair_parameters_disagree")
        _require(len(trained["history"]) == EPOCHS
                 and [v["epoch"] for v in trained["history"]] == list(range(1, EPOCHS + 1))
                 and all(np.isfinite(v[k]) and v[k] >= 0 for v in trained["history"]
                         for k in ("weighted_loss", "mu", "max_gradient_norm_before_clip"))
                 and np.isfinite(state["trained"]["training_seconds"])
                 and state["trained"]["training_seconds"] >= 0,
                 "complete_fixed_epoch_pair_training_required")
        self._state = state
        self.state_sha256 = supplied

    def _check(self) -> None:
        _require(self.state_sha256 == _digest(self._state)
                 and self.dimension == self._state["prefit_descriptor"]["recipe"]["embedding_dimension"]
                 and self.scale == self._state["prefit_descriptor"]["frozen_FIT_RMS_scale"]
                 and self.mu == self._state["trained"]["mu"]
                 and np.array_equal(self.W, self._state["trained"]["W"])
                 and np.array_equal(self.U, self._state['trained']['projection_U'])
                 and np.array_equal(self.V, self._state['trained']['projection_V'])
                 and np.array_equal(self.active_axes, self._state['prefit_descriptor']['projection_active_axes']),
                 "frozen_pair_metric_state_changed")

    def to_state(self) -> dict:
        self._check()
        return dict(copy.deepcopy(self._state), state_sha256=self.state_sha256)

    @classmethod
    def from_state(cls, state: dict) -> "PaperVariationalPairMetric":
        return cls(state)

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.to_state(), ensure_ascii=False,
                                        sort_keys=True, allow_nan=False), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "PaperVariationalPairMetric":
        return cls.from_state(json.loads(Path(path).read_text(encoding="utf-8")))

    def project_scaled(self, value: np.ndarray) -> np.ndarray:
        self._check()
        a = np.asarray(value, np.float64)
        _require(a.ndim == 2 and a.shape[1] == self.dimension and np.isfinite(a).all(), 'finite scaled projection input')
        result = a + (a @ self.V) @ self.U.T
        _require(np.isfinite(result).all(), 'finite FIT-trained residual projection')
        return result

    def projection_matrix(self) -> np.ndarray:
        self._check()
        return np.eye(self.dimension, dtype=np.float64) + self.U @ self.V.T

    def pairwise_distances(self, z_query: Any, z_reference: Any | None = None,
                           *, block_size: int = 128) -> np.ndarray:
        self._check()
        query = _matrix(z_query, width=self.dimension)
        reference = query if z_reference is None else _matrix(z_reference, width=self.dimension)
        _require(type(block_size) is int and 1 <= block_size <= 256, "block_size_1_to_256_required")
        with np.errstate(over="raise", invalid="raise", divide="raise"):
            try:
                left, right = np.asarray(query, np.float64) / self.scale, np.asarray(reference, np.float64) / self.scale
            except FloatingPointError as exc:
                raise PairMetricProtocolStop("frozen_FIT_scaling_overflow") from exc
        _require(np.isfinite(left).all() and np.isfinite(right).all(), "nonfinite_frozen_scaled_query")
        # The inherited blockwise Eq9/10 body below is unchanged after A.
        left = self.project_scaled(left)
        right = left if z_reference is None else self.project_scaled(right)
        result = np.empty((len(left), len(right)), np.float64)
        square = z_reference is None
        for i in range(0, len(left), block_size):
            for j in range(i if square else 0, len(right), block_size):
                try:
                    with np.errstate(over="raise", invalid="raise", divide="raise"):
                        delta = np.abs(left[i:i + block_size, None, :] - right[None, j:j + block_size, :])
                        squared = delta ** 2
                        logits = delta * self.W[:, 0] + squared * self.W[:, 1]
                        logits -= logits.max(axis=2, keepdims=True)
                        omega = np.exp(logits); omega /= omega.sum(axis=2, keepdims=True)
                        distances = np.sqrt(squared.sum(axis=2) + self.mu * (omega * squared).sum(axis=2))
                except FloatingPointError as exc:
                    raise PairMetricProtocolStop("learned_pair_distance_overflow") from exc
                _require(np.isfinite(distances).all() and np.all(distances >= 0), "nonfinite_learned_pair_distance")
                result[i:i + len(distances), j:j + distances.shape[1]] = distances
                if square and j != i:
                    result[j:j + distances.shape[1], i:i + len(distances)] = distances.T
        if square:
            np.fill_diagonal(result, 0.0)
        self._check()
        return result

def fit_known_metric(z_fit: Any, y_fit_fine: Any, *, expected_prefit_sha256: str,
                     known_fine_labels: Any, fit_ids: Any,
                     fit_group_ids: Any, fit_roles: Any) -> PaperVariationalPairMetric:
    """One fixed FIT-only training run, pinned to a caller-frozen prefit plan."""
    kwargs = dict(known_fine_labels=known_fine_labels, fit_ids=fit_ids,
                  fit_group_ids=fit_group_ids, fit_roles=fit_roles)
    z, pairs, same, weights, prefit = _prepare(z_fit, y_fit_fine, **kwargs)
    _require(type(expected_prefit_sha256) is str and expected_prefit_sha256 == prefit["prefit_sha256"],
             "caller_frozen_prefit_plan_mismatch_before_optimization")
    trained = _train(z, pairs, same, weights)
    _require(_array_descriptor(np.asarray(z_fit)) == prefit["FIT_MHFD_Z"]
             and _array_descriptor(np.asarray(y_fit_fine)) == prefit["FIT_known_fine"],
             "FIT_material_changed_during_metric_optimization")
    state = {"schema_version": SCHEMA, "prefit_descriptor": prefit, "trained": trained,
             "target99_status": "FAIL_TARGET99", "published": False, "final_test_executed": False,
             "new_final_source_authority": False}
    state["state_sha256"] = _digest(state)
    return PaperVariationalPairMetric.from_state(state)
