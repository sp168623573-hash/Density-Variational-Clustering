"""Equal-known-fine RFF candidates preserve the original149/126 paper chain.

NSL1 actual native117 is the final117 of149; CIC1 actual native78 is the first78
of126. The fixed nonlinear support module feeds additional candidates into
the existing matching Eq9/10 density/affinity/noise defense. BEN/KNA exact99
gates now govern admission; every old correct loss and gain remains explicit.
"""
import argparse,inspect,json,sys,time,types
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from . import nsl1_cic1_equalfine_RFF_core_v92 as core
from . import nsl1_relative_mahalanobis117_v80 as nsl_cov
from . import nsl1_cic1_gradnorm_cache_context_v85 as helpers
nsl,cic=helpers.nsl,helpers.cic
ROOT,files,require=nsl.ROOT,nsl.files,nsl.files.require
MODULE='paper_open_set.nsl1_cic1_equalfine_RFF_candidates_v92'
DIR=ROOT/'tmp/knownfine_equal_RFF_candidates_20261012_v92'
BASE=ROOT/'data/external_dev/processed/knownfine_equal_RFF_candidates_20261012_v92'
def registry_path(setting):return DIR/(setting+'_registry_before_known_RFF_fit.json')
def policy(setting):
    require(setting in ('NSL1','CIC1'),'declared two existing settings only')
    return dict(schema_version=setting+'-genuine-equalknownfine-RFF256-PCA128-originalgeometry-v92',setting=setting,hypotheses=1,
        coordinates='NSL1 original149[:,32:] complete117 inclduration' if setting=='NSL1' else 'CIC1 original126[:,:78] complete native78 originalFIT normalization',
        fit='all genuine5999 actuallexrepresentative nativegroups' if setting=='NSL1' else 'all6000 genuineknown FIT nativegroups',
        fine_prior='realrepresentative truefine9, eachfine total1/9, eventweight1/(9*Nfine), weightedmean andweightedcov; not empirical frequency/new flows',
        covariance='same verifiedV80 native117 withinOAS reused andowned Cholesky' if setting=='NSL1' else 'newgenuineFIT fine9 mean residual pooledOAS assumeCenteredTrue analyticshrinkage thenCholesky',
        bandwidth='nativegroup SHA lexsort,512 floorlinspace onlyfor scale; positive nonself squaredEuclidean pdist medianh2; gamma1/(2h2)',
        random_features='seed20261012 WstandardNormal widthx256/bUniform0..2pi, sqrt(2/256)*cos(sqrt(2gamma)*white@W+b)',
        residual='complete weighted256 covariance eigh, fixedtop128 preserved/low128 squaredresidual highunknown; no kernel/rank/fine/field/seed sweep',
        calibration='all trueknown656 oncefinite99' if setting=='NSL1' else 'alltrueknown900 oncefinite99',
        query='original frozenstage1 choosescutbank only; no true/predfine choosesnonlinear basis or covariance',
        geometry='unchanged owned149 Eq9/10 DVC' if setting=='NSL1' else 'unchanged owned126 Eq9/10 DVC',
        baseline='whole2618' if setting=='NSL1' else 'whole2399',
        merge='ownnewraw OR baselinepredictedUNA densitybackground, appendnewraw retained2; preserve originalwholeversions',
        acceptance='known BEN/KNA each exactinteger99 only; fullBEN/KNA each exact99 AND netUNApositive eligible additionalDEV; all gain/loss/binary changes reported, no hardzero-loss rule',
        optimizer='original6000BEN+KNA perknownfamily20 presentations unchanged;5999NSL1 genuinegroups, duplicate/mixedknown-memberships preserve evidence; random basis/512 sample not newtrainingtraffic',
        architecture='originalMHFD -> declared additional nonlinear knownsupport candidate -> same matchedmetric densityaffinity/reconstruction/localdensity/secondarynoise',
        NN_fit=0,NN_forward=0,metric_fit=0,R7_fit=0,trueUNA_fit=False,query_fit=False,parameter_grid=False,timecap_coded=False,
        extension_not_verbatim_paper=True,warm_development_only=True,status='FAIL_TARGET99',published=False,final_test_executed=False)
def closure():
    found={};todo=[sys.modules[__name__]];seen=set()
    while todo:
        mod=todo.pop()
        if mod is None or id(mod) in seen:continue
        seen.add(id(mod));path=getattr(mod,'__file__',None)
        if not path or not Path(path).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        found[MODULE if mod is sys.modules[__name__] else mod.__name__]=files.item(path)
        for value in vars(mod).values():
            child=value if isinstance(value,types.ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            if child is not None:todo.append(child)
    found[MODULE]=files.item(__file__);require(all(m.__name__ in found for m in (core,nsl_cov,nsl,cic,helpers)),'directrecursive actual covariance geometry andhelper producer closure');return found
def archive(asset,keys,pins):return nsl.base.archive(asset,keys,pins)
def save(out,r,name,value):return nsl.base.save(out,r,name,value)
def metadata(setting,pins):
    if setting=='NSL1':
        k=files.js(nsl_cov.OLD_KNOWN,pins);current=files.js(nsl_cov.BASELINE,pins);reg=files.js(k['registry'],pins);covref=files.item(nsl_cov.BASE/'known/report.json');cov=files.js(covref,pins)
        require(current['original_class_gates']['UNA']['correct']==2618 and cov['prediction_sealed'],'actualwhole2618 andsaved nativecov')
        a=dict(encoded=reg['assets']['encoded'],material=k['files']['material'],reference=k['files']['reference'],metric=k['files']['metric'],current_context=current['files']['actual_query_nativecell_clean149_before_scores'],baseline=current['files']['postseal_comparison'],within_covariance=cov['files']['state'],genuine_covariance_roster=cov['files']['genuine5999_singlelabel_andall_membership_before_RMDfit'])
        ancestry=dict(primary_typedmasked_NN=1261.1884094000561,original149_metric_extra_conservative_already_inside_wholeknown=6.321081299975049,original149_wholeknown=k['wall_seconds'],prior_native117_covariance_wholeknown=cov['wall_seconds'])
        refs=dict(original_known=nsl_cov.OLD_KNOWN,baseline_report=nsl_cov.BASELINE,covariance_producer=covref)
    else:
        kr=files.item(cic.BASE/'known/report.json');cr=files.item(cic.BASE/'current/report.json');k=files.js(kr,pins);current=files.js(cr,pins);reg=files.js(k['registry'],pins);train=files.js(current['train_report'],pins)
        prior_ref=files.item(ROOT/'tmp/cic1_primary_head_vim120_execution_20261012_v76/CIC1_V76_REALHEAD_ViM120_COMPLETED_CLOSEOUT.json');prior=files.js(prior_ref,pins)
        require(current['original_class_gates']['UNA']['correct']==2399 and current['prediction_sealed'],'actualcomplete2399 baseline')
        a=dict(material=k['files']['native78_preserved32_radial16_allrole126_before_metric'],current_context=current['files']['whole4056_native32_radial16_Z126_before_score'],metric=k['files']['metric'],known_baseline=k['files']['complete_prediction_before_truth'],baseline=current['files']['complete_prediction_before_truth'],known_truth=reg['assets']['known110'],truth=reg['assets']['truth'],native_known=reg['assets']['native_known'])
        ancestry=dict(original_NN=prior['training_and_execution_time']['ancestor_conservative_seconds'],original126_wholetrain=train['wall_seconds'],original126_wholeknown=k['wall_seconds']);refs=dict(original_known=kr,baseline_report=cr,train_report=current['train_report'],prior_ancestry_evidence=prior_ref)
    return a,ancestry,refs
def freeze(setting):
    started=time.perf_counter();pins={};a,ancestry,refs=metadata(setting,pins);sources=closure()
    for v in [*a.values(),*sources.values()]:files.read(v,pins)
    require(not registry_path(setting).exists() and not (BASE/setting).exists(),'fresh fixed equalfine branch')
    DIR.mkdir(parents=True,exist_ok=True);return files.write(registry_path(setting),dict(policy=policy(setting),assets=a,sources=sources,ancestry_seconds=ancestry,necessary_ancestry_seconds=sum(ancestry.values()),references=refs,metadata_preparation_seconds=time.perf_counter()-started,input_sha256=pins,real_current_numeric_decodes=0))
def bind(setting,item,pins):
    reg=files.js(item,pins);require(Path(item['path']).resolve()==registry_path(setting).resolve() and reg['policy']==policy(setting) and reg['sources']==closure(),'own frozenpolicy/source role binder')
    for p,s in reg['input_sha256'].items():files.read(dict(path=p,sha256=s),pins)
    return reg
def fit_material(setting,a,pins):
    if setting=='NSL1':
        e=archive(a['encoded'],('fit_features','fit_ids','fit_known_fine','calibration_features','calibration_ids','calibration_known_coarse','open_known_features','open_known_ids'),pins);mat=archive(a['material'],('fit_ids','fit_groups','fit_fine','fit_Z149','calibration_Z149','calibration_ids','open_known_Z149','open_known_ids','open_known_groups','open_known_stage1','open_known_predicted_fine'),pins);ref=archive(a['reference'],('ids','groups','original_indices','known_fine_membership'),pins);ix=ref['original_indices'];cov=archive(a['within_covariance'],('within_covariance',),pins);proof=archive(a['genuine_covariance_roster'],('ids','groups','canonical_truefine','X117','all_actualfine_membership'),pins)
        require(len(e['fit_ids'])==6000 and min(np.bincount(mat['fit_fine'],minlength=9))>=20 and len(ix)==5999 and np.array_equal(e['fit_ids'],mat['fit_ids']) and np.array_equal(e['fit_known_fine'],mat['fit_fine']),'alloriginal6000known floor20')
        require(np.array_equal(e['fit_features'].astype(np.float64),mat['fit_Z149'][:,32:]) and np.array_equal(e['calibration_features'].astype(np.float64),mat['calibration_Z149'][:,32:]) and np.array_equal(e['open_known_features'].astype(np.float64),mat['open_known_Z149'][:,32:]),'actual117 is last117 of149, no guessedprefix')
        x=e['fit_features'][ix].astype(np.float64);fine=mat['fit_fine'][ix];require(np.array_equal(proof['ids'],ref['ids']) and np.array_equal(proof['groups'],ref['groups']) and np.array_equal(proof['canonical_truefine'],fine) and np.array_equal(proof['X117'],x) and np.array_equal(proof['all_actualfine_membership'],ref['known_fine_membership']),'sameverified canonical genuinegroup/covariance coordinates andactual mixedmembership')
        return dict(ids=ref['ids'],groups=ref['groups'],fine=fine,x=x,covariance=cov['within_covariance'],all_actualfine_membership=ref['known_fine_membership'],CAL_ids=e['calibration_ids'],CAL_x=e['calibration_features'].astype(np.float64),CAL_coarse=e['calibration_known_coarse'])
    mat=archive(a['material'],('FIT_ids','FIT_groups','FIT_fine','FIT_Z126','CAL_ids','CAL_Z126'),pins);label=archive(a['native_known'],('FIT_ids','FIT_y_fine','CAL_ids','CAL_y_coarse'),pins);require(len(mat['FIT_ids'])==6000==len(np.unique(mat['FIT_groups'])) and np.array_equal(mat['FIT_ids'],label['FIT_ids']) and np.array_equal(mat['FIT_fine'],label['FIT_y_fine']) and np.bincount(mat['FIT_fine'],minlength=9).min()>=20 and np.array_equal(mat['CAL_ids'],label['CAL_ids']),'CIC1 allgenuine6000 knownfloor20/exactCAL900')
    return dict(ids=mat['FIT_ids'],groups=mat['FIT_groups'],fine=mat['FIT_fine'],x=mat['FIT_Z126'][:,:78],covariance=None,CAL_ids=mat['CAL_ids'],CAL_x=mat['CAL_Z126'][:,:78],CAL_coarse=label['CAL_y_coarse'])
def query(setting,phase,a,pins):
    if setting=='NSL1':
        if phase=='known':
            mat=archive(a['material'],tuple('open_known_'+k for k in ('ids','groups','stage1','predicted_fine','Z149')),pins);q={k:mat['open_known_'+k] for k in ('ids','groups','stage1','predicted_fine','Z149')};baseline=nsl.parent.previous.prefix_archive(a['baseline'],('ids','prediction'),654,pins)
        else:q=archive(a['current_context'],('ids','groups','stage1','predicted_fine','Z149'),pins);baseline=archive(a['baseline'],('ids','prediction'),pins)
        native=q['Z149'][:,32:]
    else:
        if phase=='known':
            mat=archive(a['material'],tuple('CP_'+k for k in ('ids','groups','stage1','predicted_fine','Z126')),pins);q={k:mat['CP_'+k] for k in ('ids','groups','stage1','predicted_fine','Z126')};baseline=archive(a['known_baseline'],('ids','prediction'),pins)
        else:q=archive(a['current_context'],('ids','groups','stage1','predicted_fine','Z126'),pins);baseline=archive(a['baseline'],('ids','prediction'),pins)
        native=q['Z126'][:,:78]
    require(np.array_equal(q['ids'],baseline['ids']),'samecompletebaseline originalrole IDs');return q,baseline['prediction'],native
def run(setting,phase,item,known_desc=None):
    started=time.perf_counter();pins={};reg=bind(setting,item,pins);control=None
    if phase=='current':control=files.js(known_desc,pins);require(control['known_gate_passed'] and control['registry']==item and control['prediction_sealed'],'new exact99 knownbeforecurrent')
    out=BASE/setting/phase;out.mkdir(parents=True,exist_ok=False);r=dict(policy=policy(setting),registry=item,files={},NN_fit=0,NN_forward=0,metric_fit=0,R7_fit=0,OAS_fit=0,RFF_fit=0,PCA_fit=0,CAL_fit=0,DVC=0,current_numeric_rows_decoded=0,prediction_sealed=False,truth_opened=False,accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        with threadpool_limits(limits=4):
            a=reg['assets']
            if phase=='known':
                prep=time.perf_counter();f=fit_material(setting,a,pins);save(out,r,'genuineFIT_native_coordinates_andrealrepresentative_labels_beforefit',{k:v for k,v in f.items() if k not in ('covariance','CAL_ids','CAL_x','CAL_coarse')});fit=time.perf_counter();state,features,shrink=core.fit_state(f['x'],f['groups'],f['fine'],f['covariance']);r['RFF_weightedPCA_and_OAS_seconds']=time.perf_counter()-fit;r['OAS_fit']=int(f['covariance'] is None);r['OAS_shrinkage']=shrink;r['RFF_fit']=r['PCA_fit']=1;r['files']['state']=save(out,r,'genuineFIT_equalfine_RFF256_PCA128_state_before_CAL',dict(ids=f['ids'],groups=f['groups'],fine=f['fine'],**state));save(out,r,'genuineFIT_white_andRFF_features_before_CAL',dict(ids=f['ids'],groups=f['groups'],**features));cal=core.signals(f['CAL_x'],state);save(out,r,'alltrueknown_CAL_native_RFF_scores_before_rule',dict(ids=f['CAL_ids'],native=f['CAL_x'],truecoarse=f['CAL_coarse'],**cal));rule=nsl.base.paper_route.calibrate_known_cutoffs(cal['score'],f['CAL_coarse']);r['CAL_fit']=1;r['files']['rule']=files.write(out/'alltrueknown_once_equalfine_RFF_finite99.json',rule);r['training_preparation_seconds']=time.perf_counter()-prep
            else:state=archive(control['files']['state'],('L','W','b','gamma','mean','eigenvectors'),pins);rule=files.js(control['files']['rule'],pins);r['files'].update(state=control['files']['state'],rule=control['files']['rule']);r['known_report']=known_desc
            q,baseline,native=query(setting,phase,a,pins);r['current_numeric_rows_decoded']=len(q['ids']) if phase=='current' else 0;ss=time.perf_counter();cue=core.signals(native,state);r['query_score_seconds']=time.perf_counter()-ss;raw=nsl.base.paper_route.candidate_mask(cue['score'],q['stage1'],rule);density=raw|(baseline==2);save(out,r,'nonlinear_equalfine_RFF_candidate_before_DVC',dict(ids=q['ids'],native=native,stage1=q['stage1'],raw=raw,density=density,**cue));save(out,r,'unchanged_original_geometry_before_DVC',q)
            payload=files.js(a['metric'],pins);metric=(nsl.learned if setting=='NSL1' else cic.learned).PaperVariationalPairMetric.from_state(payload if setting=='NSL1' else payload['metric_payload']);r['files']['metric']=a['metric'];ds=time.perf_counter()
            if setting=='NSL1':
                def sink(name,value,manifest):save(out,r,name+'_DVC_before_truth',value);r['files'][name+'_DVC_manifest']=files.write(out/(name+'_DVC_manifest.json'),manifest)
                routed,_=nsl.base.route_once(metric,q,density,sink)
            else:
                routed=cic.dvc.route_current_candidates(metric,q['Z126'],density,seed=20261009);save(out,r,'original126_DVC_before_truth',{k:v for k,v in routed.items() if k!='manifest'});r['files']['DVC_manifest']=files.write(out/'original126_DVC_manifest.json',routed['manifest'])
            r['DVC']=1;r['query_DVC_inference_seconds']=time.perf_counter()-ds;retained=raw&routed['retained'];prediction=baseline.copy();prediction[retained]=2;v=dict(ids=q['ids'],prediction=prediction,baseline=baseline,raw=raw,density=density,retained=retained,density_retained=routed['retained']);sealed=save(out,r,'complete_prediction_before_truth',v);r['files']['seal']=files.write(out/'prediction_seal_before_truth.json',dict(predictions=sealed,registry=item,state=r['files']['state'],rule=r['files']['rule'],metric=a['metric'],truth_used=False));r['prediction_sealed']=True
            if setting=='NSL1':t=nsl.parent.previous.prefix_archive(a['baseline'],('ids','truth'),654,pins) if phase=='known' else archive(a['baseline'],('ids','truth'),pins);require(np.array_equal(q['ids'],t['ids']),'sameoriginaltruth afterpredictionseal');y=t['truth']
            elif phase=='known':y=archive(a['known_truth'],('CP_truth',),pins)['CP_truth']
            else:t=archive(a['truth'],('ids','truth'),pins);require(np.array_equal(q['ids'],t['ids']),'sameoriginaltruth afterpredictionseal');y=t['truth']
            r['truth_opened']=True;g,e,binary=helpers.metrics(y,baseline,prediction);knownpass=all(g[n]['passed'] for n in ('BEN','KNA'));eligible=bool(phase=='current' and knownpass and e['correct_count_delta']['UNA']>0)
            r.update(execution_status='equalfine_RFF_'+setting+'_'+phase+'_completed',original_class_gates=g,EffectDelta=e,binary_attack_detection=binary,known_gate_passed=knownpass,all_old_correct_loss_free=all(z['loss']==0 for z in e['gain_loss'].values()),candidate_accepted_for_retention=eligible,eligible_exact99_DEV_route=eligible,all_three_integer99_passed=phase=='current' and all(z['passed'] for z in g.values()),raw_by_true_class={n:int(((y==c)&raw).sum()) for c,n in enumerate(('BEN','KNA','UNA'))},new_external_raw_by_true_class={n:int(((y==c)&raw&(baseline!=2)).sum()) for c,n in enumerate(('BEN','KNA','UNA'))})
            save(out,r,'postseal_paired_comparison',dict(**v,truth=y))
            if phase=='current':r['perfect_raw_retention_UNA_ceiling']=int(((y==2)&(baseline==2)).sum()+((y==2)&raw&(baseline!=2)).sum())
    except Exception as exc:r.update(execution_status='execution_failed',error_type=type(exc).__name__,error=str(exc));raise
    finally:r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--setting',choices=('NSL1','CIC1'),required=True);p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for n in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+n)
    args=p.parse_args();item=None if not args.registry else dict(path=str(Path(args.registry).resolve()),sha256=args.registry_sha256);known=None if not args.known_report else dict(path=str(Path(args.known_report).resolve()),sha256=args.known_sha256)
    print(json.dumps(freeze(args.setting) if args.phase=='freeze' else run(args.setting,args.phase,item,known)))
