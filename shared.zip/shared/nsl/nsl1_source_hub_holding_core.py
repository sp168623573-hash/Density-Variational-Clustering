"""A capacity/holding correction of the existing seven-edge diffusion operator."""
import numpy as np

K=7
ALPHA=.9
ITERATIONS=20
FLOOR=.5

def require(ok,text):
    if not bool(ok):raise ValueError(text)

def gaussian_weights(distance):
    sigma=distance[:,-1];positive=sigma>0;weights=np.empty_like(distance)
    weights[positive]=np.exp(-.5*(distance[positive]/sigma[positive,None])**2)
    weights[~positive]=(distance[~positive]==0).astype(float)
    weights/=weights.sum(1,keepdims=True)
    return sigma,weights

def source_graph(metric,z):
    """All exact source pairs, upper triangle streamed into stable true top7."""
    z=np.asarray(z,np.float64);n=len(z)
    require(n==5999 and z.shape==(5999,149) and metric.dimension==149,'unchanged full5999 source149 owner')
    neighbors=np.full((n,K),n,np.int64);distance=np.full((n,K),np.inf);pairs=0
    def update(rows,cols,d):
        indices=np.broadcast_to(cols,(len(rows),len(cols)))
        di=np.concatenate((distance[rows],d),axis=1);ix=np.concatenate((neighbors[rows],indices),axis=1)
        order=np.lexsort((ix,di),axis=1)[:,:K]
        distance[rows]=np.take_along_axis(di,order,axis=1);neighbors[rows]=np.take_along_axis(ix,order,axis=1)
    for begin in range(0,n,128):
        rows=np.arange(begin,min(begin+128,n))
        for start in range(begin,n,128):
            cols=np.arange(start,min(start+128,n));d=metric.pairwise_distances(z[rows],z[cols])
            require(d.shape==(len(rows),len(cols)) and np.isfinite(d).all(),'exact existing149 metric source block')
            if start==begin:
                require(np.array_equal(d,d.T),'actual diagonal source block symmetry')
                np.fill_diagonal(d,np.inf);pairs+=len(rows)*(len(rows)-1)//2
                update(rows,cols,d)
            else:
                pairs+=len(rows)*len(cols);update(rows,cols,d);update(cols,rows,d.T)
    require(pairs==n*(n-1)//2 and np.isfinite(distance).all() and
            np.all(neighbors!=np.arange(n)[:,None]) and np.all(neighbors<n),'allsource exact nearest7 selfexcluded')
    sigma,weights=gaussian_weights(distance)
    indegree=np.bincount(neighbors.ravel(),weights=weights.ravel(),minlength=n)
    require(np.isfinite(indegree).all() and np.all(indegree>=0),'finite weighted source indegree')
    return dict(source_neighbors7=neighbors,source_neighbor_distances7=distance,
                source_sigma7=sigma,source_row_normalized_weights7=weights,
                source_weighted_indegree=indegree,
                exact_unordered_source_pairs=np.asarray(pairs,np.int64))

def holding_diffusion(neighbors,original_weights,initial,indegree,unlimited=False):
    neighbors=np.asarray(neighbors,np.int64);weights=np.asarray(original_weights,np.float64)
    raw=np.asarray(initial,bool);n=len(raw);anchors=len(indegree)
    require(neighbors.shape==weights.shape==(n,K) and np.isfinite(weights).all() and
            np.all(weights>=0) and np.all(neighbors>=0) and np.all(neighbors<anchors+n) and
            np.all(neighbors!=anchors+np.arange(n)[:,None]),
            'unchanged exact canonical nearest7 graph with zero source anchors')
    source=neighbors<anchors;incoming=np.bincount(neighbors[source],weights=weights[source],minlength=anchors)
    capacity=(n/anchors)*(1.+np.asarray(indegree,np.float64))
    if unlimited:capacity=np.full(anchors,np.inf)
    scale=np.ones(anchors);positive=incoming>0;scale[positive]=np.minimum(1.,capacity[positive]/incoming[positive])
    multiplier=np.ones_like(weights);multiplier[source]=scale[neighbors[source]]
    capped=weights*multiplier
    holding=np.sum(weights*(1.-multiplier),axis=1)
    mass=weights.sum(1)
    incoming_after=np.bincount(neighbors[source],weights=capped[source],minlength=anchors)
    initial_score=raw.astype(float);score=initial_score.copy();history=[];baseline=initial_score.copy();oldhistory=[]
    for _ in range(ITERATIONS):
        allscore=np.concatenate((np.zeros(anchors),score))
        # Keep the original denominator.  The removed source-edge mass is a
        # holding loop, not a new neighbor, and is never renormalized away.
        update=ALPHA*np.sum(capped*allscore[neighbors],axis=1)/mass+(1.-ALPHA)*initial_score
        score=update+ALPHA*holding*score/mass;history.append(score.copy())
        oldall=np.concatenate((np.zeros(anchors),baseline))
        baseline=ALPHA*np.sum(weights*oldall[neighbors],axis=1)/mass+(1.-ALPHA)*initial_score
        oldhistory.append(baseline.copy())
    history,oldhistory=np.stack(history),np.stack(oldhistory)
    require(np.isfinite(history).all() and np.all((history>=0)&(history<=1)) and
            np.all(history>=oldhistory),'bounded support monotonic at every round')
    require(np.allclose(capped.sum(1)+holding,mass,rtol=0,atol=8*np.finfo(float).eps),
            'source loss transferred only to holding; original row mass conserved')
    finite=np.isfinite(capacity)
    terms=np.bincount(neighbors[source],minlength=anchors)
    gamma=terms*np.finfo(float).eps/(1.-terms*np.finfo(float).eps)
    rounding_bound=(gamma+8*np.finfo(float).eps)*np.maximum(1.,capacity)
    require(np.all(incoming_after[finite]<=capacity[finite]+rounding_bound[finite]),
            'source column capacity with explicit finite-sum roundoff bound, no decision epsilon')
    return dict(support_score=score,trajectory=history,original_trajectory=oldhistory,
                neighbors=neighbors,original_weights=weights,weights=capped,
                original_row_mass=mass,holding_self_mass=holding,
                source_incoming_original=incoming,source_capacity=capacity,
                source_capacity_scale=scale,source_incoming_capped=incoming_after,
                source_cap_floating_error_bound=rounding_bound,
                initial_raw=raw,anchors_zero=np.zeros(anchors),
                row_mass_roundoff=capped.sum(1)+holding-mass,
                source_capacity_roundoff=incoming_after-capacity)

def synthetic():
    # Each row has seven distinct original neighbors: five anchors, two queries.
    near=np.asarray([[0,1,2,3,4,11,12],[0,1,2,3,4,10,12],[0,1,2,3,4,10,11]])
    weights=np.tile(np.asarray([.6,.05,.05,.05,.05,.1,.1]),(3,1))
    seed=np.ones(3,bool);indegree=np.ones(10)
    v=holding_diffusion(near,weights,seed,indegree)
    require(np.allclose(v['holding_self_mass'],.4,rtol=0,atol=2e-16) and
            np.allclose(v['trajectory'][0],.64,rtol=0,atol=2e-16) and
            np.allclose(v['original_trajectory'][0],.28,rtol=0,atol=2e-16),
            'hand-computed overloaded hub: removed .4 held locally, first score .64 versus .28')
    noop=holding_diffusion(near,weights,seed,indegree,unlimited=True)
    require(np.array_equal(noop['trajectory'],noop['original_trajectory']) and
            not noop['holding_self_mass'].any() and np.array_equal(noop['weights'],weights),
            'unlimited capacity/h0 exact old update every round')
    zero=holding_diffusion(near,weights,np.zeros(3,bool),indegree)
    require(not zero['trajectory'].any(),'zero seeds remain zero without role shortcut')
    require(np.array_equal(v['weights'][near>=10],weights[near>=10]),'all original query edges exactly unchanged')
    return dict(synthetic_only=True,sevendistinct_original_neighbors=True,hand_calculated_holding=True,
                no_cap_exact_noop=True,zero_seed_exact=True,query_edges_unchanged=True,
                source_column_capacity=True,row_mass_conserved=True,support_monotonic=True,
                holding_not_independent_neighbor=True)
