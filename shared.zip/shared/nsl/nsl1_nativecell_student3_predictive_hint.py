"""Actual all41 conditional NLL beside unchanged original NSL1 2605.

Known6000 heteroscedastic mask-MHFD supplies CE/GaussianNLL, averaged per
original field. KnownCAL true coarse sets one finite99 cut; actual primary
coarse selects its query cut. Original projected149 DVC supplies density.
"""
from __future__ import annotations
import argparse,io,json,time
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
from . import nsl1_nativecell_Student3_typedmask_v60 as masked
from . import nsl1_constant_support_v47 as parent
from . import nsl1_projected149_entropy_joint_v2 as original
from . import artifact_api_preflight_v52 as preflight
from .paired_integer_gate_status_v1 import gate_status

ROOT,files=parent.ROOT,parent.files
BASE=ROOT/'data/external_dev/processed/nsl1_nativecell_Student3_predictive_hint_20261011_v60'
REGISTRY=ROOT/'tmp/nsl1_nativecell_Student3_predictive_hint_20261011_v60/registry_before_trueknown_CAL_NLL.json'
PARENT=dict(path=str(parent.BASE/'current/report.json'),sha256='c01e0f8544e103074ab236d6b9a3ca7dc0a2e996acf7397490886f4af2af3b57')
SCHEMA='NSL1-preserved2605-nativecell-covered-Student3-all41-conditional-NLL-hint-v60'
BATCH=512

def policy():
    return dict(schema_version=SCHEMA,hypotheses=1,model='actual warm known6000 masked MHFD117 plus maskedembedding32 MLP64 variance117, newfixed30 native-cell coverage cost-sensitive masked objective, not natural-frequency MLE',
        score='arithmetic mean of all41 original-field conditional NLL, numeric Student3 .5log(variance/3)+2log1p(residual2/variance), variance=softplusfloat32+1e-4; wholecategorical CE',
        numeric_NLL_may_be_negative=True,variance_floor=masked.VARIANCE_FLOOR,variance_floor_is_declared_model_parameter=True,
        loss_coordinate_clamp_or_field_selection=False,all38numeric_and3categorical=True,full117_encoder_preserved=True,
        CAL='all656 genuine knownCAL rows grouped by known truecoarse; finite99 ceil(.99*(n+1)); strictgreater; no row removal, no quantile change',
        query='original primary35e predictedcoarse selectscut; no query class truth, family or ID scoring',
        DVC='unchanged successful frozen projected149 learned metric on original149 geometry, native group dedup, candidates/centres/affinity/reconstruction/localdensity/secondarynoise',
        density='ownraw OR completebaseline2605 predictedUNA; copies not additional events',
        merge='copy complete2605; append ownraw and same-run DVCretained UNA only',
        known_gate='known654 BEN/KNA exact99 and pairedcorrectloss0 before any unknown numeric/decoder forward; no thisbranch exploration on loss',
        masked_inference='explicit CPUfloat32 eval context for all41 fields across CAL/known/unknown, original CUDA-trained tensors; batch512; mean/variance complete raw outputs sealed before NLL reduction',
        neural_fit=0,primary_forward=0,geometry_metric_fit=0,reference_or_radius_fit=0,unit_refit=0,
        observed_warm_development=True,independent_final=False,unknown_labels_fit=False,query_parameter_fit=False,
        published=False,final_test_executed=False,status='FAIL_TARGET99',accepted_baseline_replaced=False)

def sources():
    modules=(masked,masked.warm,masked.mask_core,masked.model,masked.output_io,parent,original,original.projected,original.learned,original.paper_route,preflight,files)
    return {Path(m.__file__).name:files.item(m.__file__) for m in modules}|{'caller':files.item(__file__)}

def freeze():
    pins={};train_asset=files.item(masked.BASE/'train/report.json');train=files.js(train_asset,pins);tr=files.js(train['registry'],pins)
    prior=files.js(PARENT,pins);old=files.js(prior['registry'],pins)
    files.require(train['epochs_completed']==30 and train['unknown_numeric_decodes']==0 and train['policy']==masked.recipe()
        and train['execution_status']=='warm_nativecell_Student3_full117_typed41_known_evaluated'
        and prior['original_class_gates']['UNA']['correct']==2605 and prior['prediction_sealed'],'actual new known-only fullvariance producer and retained2605')
    check=preflight.preflight(json_contracts=[dict(asset=train_asset,paths=[['files','model'],['model_state_sha256'],['explicit_new_variance_parameters'],['runtime_during_training'],['device']])],api_contracts=[dict(module_name=masked.__name__,function_name='load_checkpoint',required_parameters=['checkpoint','reg','field_map','device'],source_sha256=files.item(masked.__file__)['sha256'])])
    assets={k:old['assets'][k] for k in ('encoded','encoder','prepared','query_geometry','metric')}
    assets.update(model=train['files']['model'],field_map=tr['assets']['field_map'],baseline=prior['files']['postseal_comparison'])
    headers={k:masked.previous.metadata_headers(a,pins) for k,a in assets.items() if Path(a['path']).suffix=='.npz'}
    files.require(headers['encoded']['calibration_features']['shape']==[656,117]
        and headers['encoded']['calibration_known_coarse']['shape']==[656]
        and headers['query_geometry']['Z149']['shape']==[3598,149], 'actual knownCAL labels and immutable full149 metadata')
    for a in assets.values():files.read(a,pins)
    for a in sources().values():files.read(a,pins)
    files.require(not REGISTRY.exists() and not BASE.exists(),'fresh variance-NLL recipe')
    reg=dict(schema_version=SCHEMA+'-registry',policy=policy(),sources=sources(),assets=assets,producer=train_asset,masked_registry=train['registry'],
        model_state_sha256=train['model_state_sha256'],producer_runtime=train['runtime_during_training'],producer_device=train['device'],
        material_descriptors=old['material_descriptors'],headers=headers,artifact_API_preflight=check,
        outputs={p:str(BASE/p) for p in ('known','current')},input_sha256=pins)
    reg['registry_sha256']=files.digest(reg);REGISTRY.parent.mkdir(parents=True,exist_ok=False);return files.write(REGISTRY,reg)

def bind(path,sha,pins):
    ref=dict(path=str(Path(path).resolve()),sha256=sha);reg=files.js(ref,pins);unsigned=dict(reg);signature=unsigned.pop('registry_sha256')
    files.require(signature==files.digest(unsigned) and reg['policy']==policy() and reg['sources']==sources(),'exact fixed newvariance NLL recipe')
    for p,h in reg['input_sha256'].items():files.read(dict(path=p,sha256=h),pins)
    return ref,reg

def save(out,report,name,value):return original.save(out,report,name,value)

def network(reg,pins):
    runtime=reg['producer_runtime'];before=masked.capture_runtime_flags()
    files.require(before['CUBLAS_WORKSPACE_CONFIG']==runtime['CUBLAS_WORKSPACE_CONFIG']==':4096:8'
        and reg['producer_device']=='cuda','registered trained model provenance and explicit new CPU likelihood context')
    torch.set_num_threads(4);masked.model.set_seed(masked.SEED)
    torch.set_float32_matmul_precision(runtime['float32_matmul_precision'])
    torch.backends.cuda.matmul.allow_tf32=runtime['cuda_matmul_allow_tf32'];torch.backends.cudnn.allow_tf32=runtime['cudnn_allow_tf32']
    during=masked.capture_runtime_flags();files.require(all(during[k]==runtime[k] for k in runtime),'registered deterministic runtime flags; decoder deployment uses CPUfloat32')
    tr=files.js(reg['masked_registry'],pins);mapping=masked.field_map_from_state(files.js(reg['assets']['field_map'],pins))
    checkpoint=torch.load(io.BytesIO(files.read(reg['assets']['model'],pins)),map_location='cpu',weights_only=True)
    net=masked.load_checkpoint(checkpoint,tr,mapping,device=torch.device('cpu'))
    files.require(masked.output_io.state_digest(net)==reg['model_state_sha256'],'complete mean,variance,mask tokens and fieldmap state')
    return net

def conditional_NLL41(net,x,role,out,report):
    files.require(x.dtype==np.float32 and x.shape==(len(x),117) and len(x)>0 and np.isfinite(x).all(),'all117 observed original field values')
    values=np.empty((len(x),41),np.float64);device=next(net.parameters()).device;state=masked.output_io.state_digest(net)
    with torch.no_grad():
        for field,group in enumerate(net.field_map.groups):
            columns=group['selected_columns']
            for start in range(0,len(x),BATCH):
                stop=min(start+BATCH,len(x));target=torch.from_numpy(x[start:stop].copy()).to(device);fields=torch.full((len(target),),field,dtype=torch.int64,device=device)
                returned=net.forward_masked(target,fields)
                raw={k:v.detach().cpu().numpy().copy() if v.dtype==torch.bool else v.detach().float().cpu().numpy().copy() for k,v in returned.items()}
                save(out,report,role+'_field'+str(field)+'_batch'+str(start)+'_actual_mean_variance_masked_before_NLL',raw)
                report['counts']['masked_forward_batches']+=1
                files.require(set(raw)==masked.RAW_FIELDS|{'masked_columns','raw_variance'} and all(np.isfinite(v).all() for v in raw.values()),'actual complete mean+variance raw captures')
                mean=returned['reconstruction'][:,columns].float();truth=target[:,columns].detach().float()
                if group['kind']=='categorical':
                    files.require(bool(((truth==0)|(truth==1)).all()) and bool((truth.sum(dim=1)==1).all()),'entire onehot including UNSEEN observed field target')
                    loss=F.cross_entropy(mean,truth.argmax(dim=1),reduction='none')
                else:
                    files.require(group['kind']=='numeric','known original field kind')
                    variance=F.softplus(returned['raw_variance'][:,columns].float())+masked.VARIANCE_FLOOR
                    loss=(.5*torch.log(variance/3.)+2.*torch.log1p((mean-truth).square()/variance)).mean(dim=1)
                values[start:stop,field]=loss.detach().cpu().numpy().astype(np.float64)
    files.require(np.isfinite(values).all() and masked.output_io.state_digest(net)==state,'all41 finite true NLL; negative numeric values retained')
    report['files'][role+'_NLL41']=save(out,report,role+'_complete41_conditional_NLL_before_mean',dict(conditional_NLL41=values))
    return values

def run(phase,path,sha,known_path=None,known_sha=None):
    started,pins=time.perf_counter(),{};ref,reg=bind(path,sha,pins)
    if phase=='current':
        kr=files.js(dict(path=str(Path(known_path).resolve()),sha256=known_sha),pins)
        files.require(kr['registry']==ref and kr['known_gate_passed'] and kr['prediction_sealed'],'known positive-support integer99 precedes any unknown decoder forward')
    out=Path(reg['outputs'][phase]);files.require(not out.exists(),'fresh once-only directNLL '+phase);out.mkdir(parents=True)
    before=masked.capture_runtime_flags();r=dict(schema_version=SCHEMA,phase=phase,registry=ref,policy=policy(),files={},
        counts=dict(model_fit=0,primary_forward=0,metric_fit=0,units_fit=0,CAL_fit=0,masked_forward_batches=0,query_score=0,DVC=0),
        unknown_numeric_rows_decoded=0,prediction_sealed=False,truth_opened=False,known_control_exploration_only=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False,accepted_baseline_replaced=False)
    try:
        net=network(reg,pins);prepared=original.archive(reg['assets']['prepared'],tuple(reg['material_descriptors']),pins)
        if phase=='known':
            encoded=original.archive(reg['assets']['encoded'],('calibration_ids','calibration_features','calibration_known_coarse','open_known_ids','open_known_features'),pins)
            files.require(np.array_equal(encoded['calibration_ids'],prepared['calibration_ids']) and np.array_equal(encoded['open_known_ids'],prepared['open_known_ids']),'known trueCAL and exact current654 IDs')
            cal_fields=conditional_NLL41(net,encoded['calibration_features'],'CAL656',out,r);cal_score=cal_fields.mean(axis=1)
            cut=original.paper_route.calibrate_known_cutoffs(cal_score,encoded['calibration_known_coarse']);r['counts']['CAL_fit']=1
            r['files']['calibration']=files.write(out/'all656_trueknowncoarse_finite99_before_known654.json',dict(cutoffs=cut,trueknown_coarse=original.descriptor(encoded['calibration_known_coarse']),CAL_ids=original.descriptor(encoded['calibration_ids']),score=original.descriptor(cal_score),query_used=False,CAL_rows_excluded=0,quantile=.99))
            save(out,r,'CAL656_trueclass_NLL_before_cut',dict(ids=encoded['calibration_ids'],score=cal_score,truecoarse=encoded['calibration_known_coarse'],predictedcoarse=prepared['calibration_stage1']))
            query=original.prefix_archive(reg['assets']['query_geometry'],('ids','groups','Z149','stage1','predicted_fine'),654,pins)
            files.require(np.array_equal(query['ids'],encoded['open_known_ids'])
                and np.array_equal(query['Z149'][:,32:],encoded['open_known_features'].astype(np.float64)),
                'known654 original input bytes match exact route geometry context')
            save(out,r,'known654_actual_context_before_decoder',query)
            fields=conditional_NLL41(net,encoded['open_known_features'],'known654',out,r)
        else:
            r['known_report']=dict(path=str(Path(known_path).resolve()),sha256=known_sha);r['known_control_exploration_only']=not kr['paired_known_no_loss']
            cut=files.js(kr['files']['calibration'],pins)['cutoffs'];r['files']['calibration']=kr['files']['calibration']
            query=original.archive(reg['assets']['query_geometry'],('ids','groups','Z149','stage1','predicted_fine'),pins);r['unknown_numeric_rows_decoded']=2944
            encoded=np.asarray(query['Z149'][:,32:],np.float32);files.require(np.array_equal(encoded.astype(np.float64),query['Z149'][:,32:]),'exact original117 input without rounding repair')
            known_context=original.archive(kr['files']['known654_actual_context_before_decoder'],tuple(query),pins)
            files.require(all(np.array_equal(query[key][:654],known_context[key]) for key in query),
                'original current known654 prefix geometry, stage/fine and IDs exactly match decoder context')
            cached=original.archive(kr['files']['known654_NLL41'],('conditional_NLL41',),pins)['conditional_NLL41']
            fields=np.concatenate((cached,conditional_NLL41(net,encoded[654:],'unknown2944',out,r)),axis=0)
        score=fields.mean(axis=1);raw=original.paper_route.candidate_mask(score,query['stage1'],cut);r['counts']['query_score']=1
        baseline=original.prefix_archive(reg['assets']['baseline'],('prediction',),654,pins)['prediction'] if phase=='known' else original.archive(reg['assets']['baseline'],('prediction',),pins)['prediction']
        density=raw|(baseline==2);save(out,r,'direct41_NLL_candidates_before_DVC',dict(ids=query['ids'],score=score,raw=raw,density=density,stage1=query['stage1']))
        metric=original.learned.PaperVariationalPairMetric.from_state(files.js(reg['assets']['metric'],pins))
        def sink(name,value,manifest):
            save(out,r,name+'_DVC_result',value);r['files'][name+'_manifest']=files.write(out/(name+'_DVC_manifest.json'),manifest)
        route,_=original.route_once(metric,query,density,sink);r['counts']['DVC']=1
        retained=raw&route['retained'];prediction=original.merge(baseline,raw,retained)
        values=dict(ids=query['ids'],prediction=prediction,baseline=baseline,raw=raw,density=density,retained=retained,density_retained=route['retained'])
        pa=save(out,r,'prediction_before_truth',values);r['files']['prediction_seal']=files.write(out/'direct_NLL_prediction_seal_before_truth.json',dict(prediction=pa,model=reg['assets']['model'],CAL=r['files']['calibration'],query_truth_used=False));r['prediction_sealed']=True
        truth=original.prefix_archive(reg['assets']['baseline'],('ids','truth'),654,pins) if phase=='known' else original.archive(reg['assets']['baseline'],('ids','truth'),pins)
        files.require(np.array_equal(truth['ids'],query['ids']),'same original truth after prediction seal');r['truth_opened']=True
        effect,gates,prior=original.delta(truth['truth'],prediction,baseline,full=phase=='current');save(out,r,'postseal_comparison',dict(**values,truth=truth['truth']))
        no_loss=all(effect['gain_loss'][name]['loss']==0 for name in ('BEN','KNA'));integer=all(gates[name]['passed'] for name in ('BEN','KNA'))
        r.update(execution_status='nativecell_Student3_NLL_'+phase+'_evaluated',EffectDelta=effect,original_class_gates=gates,baseline_class_gates=prior,
            known_gate_passed=integer and no_loss,known_integer_gates_passed=integer,paired_known_no_loss=no_loss,
            known_raw=int(raw[:654].sum()),known_retained=int(retained[:654].sum()),unknown_raw=int(raw[654:].sum()),unknown_retained=int(retained[654:].sum()),
            DEV_review_eligible=phase=='current' and effect['verdict']=='UP' and no_loss and not r['known_control_exploration_only'],
            all_three_integer99_passed=phase=='current' and all(g['passed'] for g in gates.values()),explicit_gate_status=gate_status(gates,{n:effect['gain_loss'][n]['loss'] for n in ('BEN','KNA')}))
    except Exception as error:r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        after=masked.restore_runtime_flags(before);r['runtime_restoration']=dict(before=before,after=after,all_flags_restored=before==after)
        for p,h in pins.items():files.require(files.item(p)['sha256']==h,'frozen model/source/input changed '+p)
        r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for name in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+name)
    a=p.parse_args();print(json.dumps(freeze() if a.phase=='freeze' else run(a.phase,a.registry,a.registry_sha256,a.known_report,a.known_sha256)))
