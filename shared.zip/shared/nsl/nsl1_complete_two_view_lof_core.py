"""Known-only genuine two full-view reachability novelty, fixed k=7."""
import numpy as np
from scipy.spatial.distance import cdist
K=7

def require(v,why):
    if not v:raise ValueError(why)

def nearest(distances,selfexcluded=False):
    d=np.asarray(distances,np.float64)
    if selfexcluded:
        d=d.copy();np.fill_diagonal(d,np.inf)
    # Exact distance ties are stable in genuine reference order.
    ix=np.argsort(d,axis=1,kind='stable')[:,:K]
    return ix,np.take_along_axis(d,ix,axis=1)

def fit_view(reference):
    f=np.asarray(reference,np.float64);require(f.ndim==2 and len(f)>K and np.isfinite(f).all(),'genuine complete finite known references')
    d=cdist(f,f,'euclidean');ix,near=nearest(d,True);radius=near[:,-1]
    reach=np.maximum(near,radius[ix]).mean(1)
    require(np.isfinite(reach).all() and np.all(reach>=0),'natural finite reference local reachability')
    return dict(neighbors=ix,neighbor_distances=near,k_distance=radius,mean_reach=reach)

def query_view(reference,query,state):
    d=cdist(np.asarray(query,np.float64),np.asarray(reference,np.float64),'euclidean');ix,near=nearest(d)
    reach=np.maximum(near,state['k_distance'][ix]).mean(1)
    denominator=state['mean_reach'][ix];ratios=np.empty_like(denominator)
    positive=denominator>0;np.divide(reach[:,None],denominator,out=ratios,where=positive)
    ratios[~positive]=np.broadcast_to(np.where(reach==0,1.,np.inf)[:,None],ratios.shape)[~positive]
    lof=ratios.mean(1);bounded=np.ones_like(lof);finite=np.isfinite(lof);bounded[finite]=lof[finite]/(1+lof[finite])
    require(np.all((bounded>=0)&(bounded<=1)) and np.isfinite(bounded).all(),'bounded LOF handles all genuine zero cases without epsilon')
    return dict(neighbors=ix,neighbor_distances=near,mean_reach=reach,neighbor_reach=denominator,bounded_LOF=bounded)

def fit(reference):
    f=np.asarray(reference,np.float64);require(f.shape[1]==149,'all original149 and all physical117')
    return dict(native117=fit_view(f[:,32:]),whole149=fit_view(f))

def score(reference,query,state):
    f=np.asarray(reference,np.float64);q=np.asarray(query,np.float64)
    require(f.shape[1]==q.shape[1]==149 and np.isfinite(q).all(),'whole query149 unchanged')
    native=query_view(f[:,32:],q[:,32:],state['native117']);whole=query_view(f,q,state['whole149'])
    return np.sqrt(native['bounded_LOF']*whole['bounded_LOF']),dict(native117=native,whole149=whole)

def synthetic_contract():
    f=np.zeros((9,149));f[:,32]=np.arange(9)/10
    state=fit(f);q=np.zeros((2,149));q[0,32]=.4;q[1,32]=10
    value,proof=score(f,q,state);require(value[1]>value[0],'remote native and wholeview reachability novelty exceeds in-support query')
    z=np.zeros((9,149));zs=fit(z);zv,_=score(z,z[:1],zs);require(zv.tolist()==[.5],'natural genuine duplicatezero LOF=1 and bounded=.5')
    require(np.all(state['native117']['neighbors']!=np.arange(9)[:,None]),'FIT self excluded')
    return dict(synthetic_only=True,realtraffic=0,complete117=True,complete149=True,genuine_fit_selfexcluded=True,natural_zero=True,K=K,no_query_fit=True,no_critic_fit=True)
