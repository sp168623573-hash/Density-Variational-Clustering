"""V192 original chain; only source hub capacity/holding diffusion is added."""
import argparse,json,sys,time,types
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from . import nsl1_complete_two_view_query_reach149_v186 as previous
from . import nsl1_native117_query7_soft_core_v178 as softcore
from . import nsl1_collective_categorical_profile149_v116b as frequency
from . import nsl1_query7_contrast149_v164 as cached
from . import nsl1_source_hub_holding_core_v716 as capacity
from . import nsl1_complete_frequency_negative_soft149_v192 as original
from . import nsl1_exact149_source_knn_pruning_v716c as source_compute
ROOT,files,require=previous.ROOT,previous.files,previous.require
old,nsl=previous.old,previous.nsl;MODULE='paper_open_set.nsl1_complete_frequency_negative_soft149_v716c'
DIR=ROOT/'tmp/nsl1_complete_frequency_negative_soft149_20261016_v716c';BASE=ROOT/'data/external_dev/processed/nsl1_complete_frequency_negative_soft149_20261016_v716c';REG=DIR/'registry_before_ANY_source_hub_stat_or_known.json'
def policy():
    return dict(schema_version='NSL1-original-v192-same-source-hub-holding-exact-computation-only-v716c',hypotheses=1,
        initial='all savedpretruth V116b raw candidates includingknown falsepositives OR all retainedwhole2855 pred2; no actualUNA/UID/fine/sample-selected seed',
        graph='complete genuine sourceowned learned149 cachedV164 query-to-all5999known and selfzero query-query distances, canonicalnative physicalgroupsonce; OR seeds group, allknownanchors0, exactnearest7 stableanchorfirstties Gaussian sigma7, .9 diffusion20 steps noqueryhardclamp',
        graph_patch='Only source sinkcapacity: source exact all5999 nearest7 selfexcluded using unchanged149metric and stable originalsourceorder; Gaussian sigma7/rowweights define D_j weightedindegree. Role Q canonical C_j=(Q/5999)*(1+D_j), L_j originalincoming, c=min(1,C/L),L0c1. Originalsourceedges W*c; removedsum W*(1-c) held as queryselfloop. All originalqueryedges and originalrowdenominator unchanged; no postcap renormalization. 20updates oldalpha.9 plus alpha*h_i*oldscore_i/originalmass. Holding is not newneighbor.',
        threshold='reuse exact alltrueknown V116 original CAL oncefinite99 only; soft strict>fixed.5 engineeringfloor, no new graphcut/refit/grid; score not unknownprobability',
        CAL_background_limitation='no complete old2855 CAL prediction asset exists; CAL descriptivegraph uses old V116 score-derived labelblind stage1BENscope raw only, does not invent old2855 CAL prediction2. CP/current use saved complete2855 includingerrors. Graphfloor not CAL-fitted, knownCP gate tests full combined initial recipe.',
        CAL_known_authority='all656 genuine trueknown IDs/coarse used only toverify originalonce99 rule; no truecoarse enters seed, graph, scope, anchor or node assignment',
        DVC='raw=fullV116braw AND newsoft>.5 AND old2855!=2; unchanged149 DVC candidates raw OR entire2855pred2 background. Whole original2860 copy and newretained append2. Allold2860pred2 preserved; no newprimary or correctlabel branch selector.',
        nonduplicate='Finite source grep found no equivalent weightedsourceindegree capacity/holding/Sinkhorn patch. V192 chain itself is parent, not a newrepresentation/network. No711/712/713learned parameters or code dependency.',
        source_cost='Complete original2860 ancestry1732.3263457996632 plus entire newsource stat/serialization/CAL/CP actualwall. Exact same149 K7 via allsource directdifference cdist certifiedlowerbounds; fixed56 phi-prefetch original149 actualtop7 gives safeU; all lower<=U selfexcluded/tieszero included. Unordered seed/candidate keys each evaluated once with original149 formula, no trueR7 productioninput. RawNPZ all auditarrays retained, internaltimers no hardtime stop. Slow/Bfailedtime historical, no freeparameter/statcache.',
        known_contract='Inherited CAL656 is descriptivegraph and exactoldcut verification only; no full2855CALvector, CAL_full_gate_passed is null. Complete654CP sealed integerBEN/KNA99 must pass plus sourcefee<1800 before oncecurrent. Empty/newinactive risk is not a zerorisk claim.',
        risk='transductive batchdensity and legacyDEV labels repeatedly observed, mixedBEN316 zero margin; knownpass alone not finalproof',
        NN_fit=0,NN_forward=0,metric_fit=0,main_R7_refit=0,critic_fit=0,query_fit=False,trueUNA_fit=False,parameter_grid=False,timecap_coded=False,extension_not_verbatim_paper=True,status='FAIL_TARGET99',published=False,final_test_executed=False)
def closure():
    found={};seen=set();todo=[sys.modules[__name__]]
    while todo:
        m=todo.pop()
        if m is None or id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if not p or not Path(p).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        found[MODULE if m is sys.modules[__name__] else m.__name__]=files.item(p)
        for value in vars(m).values():
            child=value if isinstance(value,types.ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            if child is not None:todo.append(child)
    return found
archive=previous.archive
def save(out,r,key,value):
    path=out/(key+'.npz')
    with path.open('xb')as fp:np.savez(fp,**value)
    d=files.item(path);r['files'][key]=d;return d
def freeze():
    started=time.perf_counter();pins={};pr=files.item(original.REG);p=files.js(pr,pins)
    kr=files.item(original.BASE/'known/report.json');cr=files.item(original.BASE/'current/report.json');k=files.js(kr,pins);c=files.js(cr,pins)
    require(k['known_gate_passed'] and k['prediction_sealed'] and c['prediction_sealed'],'original complete2860 source known and pretruthassets')
    require(not REG.exists() and not BASE.exists(),'exclusive fixed716 namespace');DIR.mkdir(parents=True,exist_ok=True)
    a=dict(p['assets']);a.update(parent2860_known=kr,parent2860_current=cr)
    src=closure();snapshots=[];snap=DIR/'source_bytes_before_ANY_new_source_capacity';snap.mkdir()
    for name,item in src.items():
        path=snap/(name.replace('.','_')+'.py');path.write_bytes(files.read(item,pins));snapshots.append(dict(module=name,original=item,snapshot=files.item(path)))
    return files.write(REG,dict(policy=policy(),assets=a,sources=src,source_snapshots=snapshots,
        synthetic_contract=capacity.synthetic(),source_acceleration_contract=source_compute.synthetic(),source_computation_runtime_pins=source_compute.runtime_pins(),source_acceleration_rational_proof=source_compute.numerical_proof(),source_pruning_proof=files.item(DIR/'V716C_PRE_REGISTERED_EXACT_COMPUTATION_PROOF_AND_SCOPE.json'),source_constant_bound_addendum=files.item(DIR/'V716C_PREFREEZE_CONSTANT_COLUMN_LOWERBOUND_ADDENDUM.json'),original_soft_contract=softcore.synthetic_contract(),
        original_v192_registry=pr,original_v192_known=kr,original_v192_current=cr,
        prior_necessary_preparation_seconds=1732.3263457996632,freeze_seconds=time.perf_counter()-started,input_sha256=pins,
        original_metric_unchanged=a['metric'],original_reference_unchanged=a['reference'],original_frequency_rule_unchanged=a['frequency_rule'],
        original_v192_to_increment_diff=files.item(DIR/'V716C_FINAL_REGISTERED_V192_TO_INCREMENT_UNIFIED_DIFF.patch'),
        no_complete2855_CAL_asset=True,CAL_full_gate_passed=None,current_numeric_decodes=0,current_truth_decodes=0))

def source_stat(ref):
    started=time.perf_counter();pins={};reg=bind(ref,pins);a=reg['assets'];bind_seconds=time.perf_counter()-started;read_start=time.perf_counter()
    metric=nsl.learned.PaperVariationalPairMetric.from_state(files.js(a['metric'],pins));source=archive(a['reference'],('ids','groups','Z149'),pins)
    require(len(source['ids'])==len(np.unique(source['groups']))==5999,'all5999 actualsource groups not trainingcopies')
    read_seconds=time.perf_counter()-read_start
    out=BASE/'source_capacity';out.mkdir(parents=True,exist_ok=False);r=dict(registry=ref,files={},source_rows=5999,new_NN_fit=0,new_metric_fit=0,new_R7_fit=0,current_numeric_decodes=0,current_truth_decodes=0)
    calc_start=time.perf_counter();value=source_compute.source_graph(metric,source['Z149']);calc_seconds=time.perf_counter()-calc_start
    serialize_start=time.perf_counter();save(out,r,'actual5999_exactsource_nearest7_Gaussian_indegree',dict(ids=source['ids'],groups=source['groups'],**value));serialize_seconds=time.perf_counter()-serialize_start
    r.update(execution_status='V716C_FULL5999_COLD_EXACT_UNORDERED_SOURCE_HUB_STAT_COMPLETE',metric=a['metric'],reference=a['reference'],all_unordered_pairs_logical_population=int(value['exact_unordered_source_pairs']),actual_metric_prefetch_unique_pairs=int(value['actual_metric_seed_pairs']),actual_metric_new_candidate_unique_pairs=int(value['actual_metric_candidate_pairs']),logical_candidate_ordered_pairs=int(value['logical_candidate_ordered_pairs']),source_compute_stage_seconds={str(k):float(v)for k,v in zip(value['computation_stage_labels'],value['computation_stage_seconds'])},source_bind_seconds=bind_seconds,source_reference_metric_read_seconds=read_seconds,source_compute_seconds=calc_seconds,source_rawNPZ_serialize_and_SHA_seconds=serialize_seconds,source_row_mass_sum=float(value['source_row_normalized_weights7'].sum()),source_indegree_sum=float(value['source_weighted_indegree'].sum()),input_sha256=pins,wall_seconds=time.perf_counter()-started,status='FAIL_TARGET99',published=False,final_test_executed=False)
    return files.write(out/'report.json',r)
def bind(ref,pins):
    r=files.js(ref,pins);require(r['policy']==policy() and r['sources']==closure(),'fixed fullfrequencynegativegraph frozen source');
    for path,sha in r['input_sha256'].items():files.read(dict(path=path,sha256=sha),pins)
    return r
def graph(q,seed,a,out,r,role,pins):
    start=time.perf_counter();prior=files.js(a['parent2860_current'] if role=='current' else a['parent2860_known'],pins)
    oldref=prior['files'][role+'_graph'];d=archive(oldref,('ids','groups','representatives','inverse','initial_rows','initial_raw','support_rows','support_score','neighbors','neighbor_distances','sigma','weights','trajectory','anchors_zero'),pins)
    require(np.array_equal(q['ids'],d['ids']) and np.array_equal(q['groups'],d['groups']),'exact originalV192 fullgraph roleframe');rep,inv=cached.collapse(q)
    require(np.array_equal(rep,d['representatives']) and np.array_equal(inv,d['inverse']),'unchanged actualcanonical149 groups')
    canonical=np.zeros(len(rep),bool);np.logical_or.at(canonical,inv,seed)
    require(np.array_equal(seed,d['initial_rows']) and np.array_equal(canonical,d['initial_raw']) and len(d['anchors_zero'])==5999,'same original frequency/2855 seeds and5999 sourceanchors')
    sigma,weights=capacity.gaussian_weights(d['neighbor_distances']);require(np.array_equal(sigma,d['sigma']) and np.array_equal(weights,d['weights']),'original sigma7 Gaussian rowweights exactly unchanged')
    sr=files.js(files.item(BASE/'source_capacity/report.json'),pins);cap=archive(sr['files']['actual5999_exactsource_nearest7_Gaussian_indegree'],('ids','groups','source_weighted_indegree'),pins)
    reference=archive(a['reference'],('ids','groups'),pins);require(np.array_equal(cap['ids'],reference['ids']) and np.array_equal(cap['groups'],reference['groups']),'capacity actualsource order owner unchanged')
    g=capacity.holding_diffusion(d['neighbors'],d['weights'],canonical,cap['source_weighted_indegree'])
    noop=capacity.holding_diffusion(d['neighbors'],d['weights'],canonical,cap['source_weighted_indegree'],unlimited=True)
    require(np.array_equal(noop['trajectory'],d['trajectory']) and np.array_equal(g['original_trajectory'],d['trajectory']) and np.array_equal(noop['support_score'],d['support_score']),'h0/unlimited cap all20 originalgraph values exact noop')
    require(np.all(g['trajectory']>=d['trajectory']),'capacity holding does not lower any old graph support')
    r['graph_seconds'][role]=time.perf_counter()-start;r.setdefault('graph_contracts',{})[role]=dict(canonical_queries=len(rep),source_anchors=5999,source_native_intersection_count=int(np.intersect1d(q['groups'][rep],reference['groups']).size),h0_exact_all20_noop=True,all20_support_monotonic=True,changed_source_columns=int((g['source_capacity_scale']<1).sum()),holding_rows=int((g['holding_self_mass']>0).sum()),max_rowmass_roundoff=float(np.abs(g['row_mass_roundoff']).max()),max_source_cap_excess_roundoff=float(np.maximum(g['source_capacity_roundoff'],0).max()),original_graph=oldref,source_hub_stat=files.item(BASE/'source_capacity/report.json'))
    r['files'][role+'_graph']=save(out,r,role+'_fullfrequency_knownnegative149_beforetruth',dict(ids=q['ids'],groups=q['groups'],representatives=rep,inverse=inv,initial_rows=seed,support_rows=g['support_score'][inv],neighbor_distances=d['neighbor_distances'],sigma=d['sigma'],**g));return g['support_score'][inv]
def run(phase,ref,knownref=None):
    started=time.perf_counter();pins={};reg=bind(ref,pins);control=None
    if phase=='current':
        control=files.js(knownref,pins);fee=files.js(files.item(DIR/'ACTUAL_SOURCE_AND_FULLKNOWN_RESOURCE_QUALIFICATION_BEFORE_CURRENT.json'),pins)
        require(control['known_gate_passed'] and control['prediction_sealed'] and control['registry']==ref and fee['within_user_resource_contract'],'knownintegergate and complete sourcefee beforecurrentvalue')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False);r=dict(policy=policy(),phase=phase,registry=ref,files={},graph_seconds={},NN_fit=0,NN_forward=0,metric_fit=0,main_R7_refit=0,critic_fit=0,CAL_fit=0,DVC=0,CAL_full_gate_passed=None,CAL_descriptive_only=True,known_gate_passed=False,current_numeric_decodes=0,current_truth_decodes=0,prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        with threadpool_limits(limits=4):
            a=reg['assets'];metric=nsl.learned.PaperVariationalPairMetric.from_state(files.js(a['metric'],pins));reference=archive(a['reference'],('ids','groups','Z149'),pins);require(len(reference['ids'])==len(np.unique(reference['groups']))==5999 and metric.dimension==149,'samegenuine5999 and source149');r['files'].update(metric=a['metric'],reference=a['reference'],rule=a['frequency_rule']);rule=files.js(a['frequency_rule'],pins)
            if phase=='known':
                mat=archive(a['material'],('calibration_ids','calibration_groups','calibration_Z149','calibration_stage1'),pins);cal={key:mat['calibration_'+key] for key in ('ids','groups','Z149','stage1')};f=archive(a['frequency_CAL'],('ids','score'),pins);require(np.array_equal(cal['ids'],f['ids']),'all656 CALscore sourceauthority');labels=archive(a['encoded'],('calibration_ids','calibration_known_coarse'),pins);require(np.array_equal(cal['ids'],labels['calibration_ids']) and rule==nsl.base.paper_route.calibrate_known_cutoffs(f['score'],labels['calibration_known_coarse']),'originalexact oncealltrueknown99 rule unchanged');initial=nsl.base.paper_route.candidate_mask(f['score'],cal['stage1'],rule)&(cal['stage1']==0);graph(cal,initial,a,out,r,'CAL',pins)
            else:r['known_report']=knownref
            q,_,_=old.query('NSL1',phase,a,pins);merge=archive(a['merge_known' if phase=='known' else 'merge_current'],('ids','prediction'),pins);f=archive(a['frequency_'+phase],('ids','raw','prediction'),pins);prior=files.js(a['parent2860_'+phase],pins);whole=archive(prior['files']['complete_frequency_soft_prediction_beforetruth'],('ids','prediction','baseline','frequency_raw','raw','density','retained'),pins)
            require(np.array_equal(q['ids'],merge['ids']) and np.array_equal(q['ids'],f['ids']) and np.array_equal(q['ids'],whole['ids']) and np.array_equal(whole['baseline'],merge['prediction']) and np.array_equal(whole['frequency_raw'],f['raw']),'exact original whole2860/old2855 and V116b allrows')
            baseline=whole['prediction'];old2855=merge['prediction'];seed=f['raw']|(old2855==2);r['current_numeric_decodes']=len(q['ids']) if phase=='current' else 0;support=graph(q,seed,a,out,r,'CP' if phase=='known' else 'current',pins);raw=f['raw']&(support>softcore.FLOOR)&(old2855!=2);density=raw|(old2855==2)
            require(np.all(raw[whole['raw']]) and np.all(density[baseline==2]),'old5 still raw/background by support monotonicity; whole2860 protected')
            oldrole='CP' if phase=='known' else 'current';oldgraph=archive(prior['files'][oldrole+'_graph'],('support_rows',),pins)
            noopraw=f['raw']&(oldgraph['support_rows']>softcore.FLOOR)&(old2855!=2);noop=old2855.copy();noop[noopraw&whole['retained']]=2
            require(np.array_equal(noopraw,whole['raw']) and np.array_equal(noop,baseline) and np.array_equal(noopraw|(old2855==2),whole['density']),'h0 original149 DVC complete2860 exact output noop without extra DVC/model trial')
            r['h0_complete_original2860_prediction_exact']=True
            def sink(name,value,manifest):save(out,r,name+'_DVC_beforetruth',value);r['files'][name+'_DVC_manifest']=files.write(out/(name+'_DVC_manifest.json'),manifest)
            routed,_=nsl.base.route_once(metric,q,density,sink);r['DVC']=1;retained=raw&routed['retained'];prediction=baseline.copy();prediction[retained]=2;require(np.all(prediction[baseline==2]==2),'complete original2860 old2 protected');values=dict(ids=q['ids'],prediction=prediction,baseline=baseline,old2855_prediction=old2855,frequency_raw=f['raw'],seed=seed,support=support,raw=raw,density=density,retained=retained);sealed=save(out,r,'complete_frequency_soft_prediction_beforetruth',values);r['files']['seal']=files.write(out/'complete_frequency_soft_prediction_seal_beforetruth.json',dict(predictions=sealed,registry=ref,metric=a['metric'],rule=a['frequency_rule'],original2860=prior['files']['complete_frequency_soft_prediction_beforetruth'],source_capacity=files.item(BASE/'source_capacity/report.json'),querytruth_used=False));r['prediction_sealed']=True
            truth=nsl.parent.previous.prefix_archive(a['baseline'],('ids','truth'),654,pins) if phase=='known' else archive(a['baseline'],('ids','truth'),pins);require(np.array_equal(truth['ids'],q['ids']),'newfullfrequencyvector sealed beforetruth');y=truth['truth'];r['truth_opened']=True;gates,delta,binary=old.helpers.metrics(y,baseline,prediction);r.update(execution_status='NSL1_fullfrequency_negativegraph_original149_'+phase+'_completed',original_class_gates=gates,EffectDelta=delta,binary_attack_detection=binary,known_gate_passed=all(gates[name]['passed'] for name in ('BEN','KNA')),candidate_accepted_for_retention=False,raw_by_trueclass={name:int(((y==c)&raw).sum()) for c,name in enumerate(('BEN','KNA','UNA'))},retained_by_trueclass={name:int(((y==c)&retained).sum()) for c,name in enumerate(('BEN','KNA','UNA'))});save(out,r,'postseal_complete_frequency_soft_pair',dict(**values,truth=y))
            if phase=='current':r['perfect_frequency_soft_raw_UNA_ceiling']=int(((y==2)&((baseline==2)|raw)).sum());r['current_truth_decodes']=len(y)
        for path,sha in pins.items():require(files.item(path)['sha256']==sha,'all parentcompletevectors, frequency/cache, sourceown149 unchanged')
    except Exception as error:r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('prepare_source','known','current'),required=True)
    for key in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+key)
    args=p.parse_args();ref=None if args.registry is None else dict(path=str(Path(args.registry).resolve()),sha256=args.registry_sha256);known=None if args.known_report is None else dict(path=str(Path(args.known_report).resolve()),sha256=args.known_sha256)
    with threadpool_limits(limits=4):
        if args.phase=='prepare_source':ref=freeze();result=source_stat(ref)
        else:result=run(args.phase,ref,known)
    print(json.dumps(result),flush=True)
