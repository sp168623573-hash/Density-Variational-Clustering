"""One actual field-mask-trained clean149 geometry beside preserved NSL1 2605.

New CPUfloat32 clean V60 native-targetcell Student3 MHFD outputs; no cache/device substitution.
Own unprojected149 paper Eq9/10 metric, true-fine R7 and CAL finite99 supply
new candidates. Original primary35e and all baseline UNA remain preserved.
"""
from __future__ import annotations
import argparse
import io
import json
from pathlib import Path
import time
import numpy as np
import torch
from . import nsl1_mask117_predictive_hint_v2 as maskhint
from . import nsl1_nativecell_Student3_typedmask_v60 as masked
from . import nsl1_nativecell_Student3_predictive_hint_v60 as direct
from . import artifact_api_preflight_v52 as preflight
from . import nsl1_expandedaux149_entry_v1 as base
from . import nsl1_constant_support_v47 as parent
from . import nsl1_nativecell_clean149_pair_metric_v62 as learned
from .paired_integer_gate_status_v1 import gate_status

ROOT,files=parent.ROOT,parent.files
BASE=ROOT/'data/external_dev/processed/nsl1_nativecell_clean149_20261011_v62'
REGISTRY=ROOT/'tmp/nsl1_nativecell_clean149_20261011_v62/registry_before_clean149_known.json'
TRAIN_PATH=masked.BASE/"train/report.json"
PARENT=dict(path=str(parent.BASE/'current/report.json'),sha256='c01e0f8544e103074ab236d6b9a3ca7dc0a2e996acf7397490886f4af2af3b57')

SCHEMA='NSL1-preserved2605-nativecell-Student3-clean149-CPUfloat32-owned-distance-v62'
BATCH=512


def policy():
    return dict(schema_version=SCHEMA,setting='NSL-KDD Setting1',hypotheses=1,
        model='actual fixedfinal30 V60 native-targetcell-balanced Student3 full117 MHFD; clean embedding32 directly consumed; original primary35e classifier unchanged',
        geometry='new CPUfloat32 clean embedding32 / genuine unique-native41 FIT RMS plus complete encoded117; all roles same CPUfloat32 batch512; no old CUDA clean cache reused',
        classifier='original primary35e saved coarse/fine exact inherited known/current lineage; auxiliary heads never used for class decisions',
        FIT='6000 genuine registered known source rows incl original primary4034 IDs; unique native41 group representatives for metric/reference/radii; all truefine memberships',
        metric='new dedicated149 Eq9/10 numeric recipe8192 fine-balanced pairs fixed80 CPUepochs; no other checkpoint geometry or old metric state',
        reference='truefine min(7,n-1)th other genuine reference learned distances; nearest ties maxR7; natural zeros retained',
        score='nearest original-primary-predicted fine d2/(d2+r2); bothzero0',
        CAL='all original known656 predicted original-primary-coarse finite99 strictgreater once; fixed before known654 query score and unknown inference',
        density='own raw OR complete2605 predictedUNA; one native41 group point; own149 learned distance candidates/centres/affinity/reconstruction/localdensity/secondarynoise',
        merge='copy complete2605 vector; append only ownraw AND own same-query DVCretained UNA; preserved2601/2605 do not substitute unknown labels',
        known_gate='known654 exact BEN/KNA integer99 AND zero paired oldcorrect losses before unknown2944 numeric decode/forward',
        inference='new explicitly CPUfloat32 eval batch512 for FIT6000,CAL656,known654; unknown2944 only after gate; raw5 and returned7 sealed before numerical guards; never claim equivalence to prior CUDAfloat16 cache',
        NN_retraining=0,primary_forward=0,legacy_CUDA_clean_cache_used=False,
        unknown_label_fit=False,query_parameter_fit=False,threshold_grid=False,formula_count=1,
        current_scope='existing previously observed3598 warm development; independent final not proven',
        exact_original_paper_extra_clean_geometry_claim=False,accepted_baseline_replaced=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)


def sources():
    modules=(maskhint,masked,direct,base,base.owned_dvc,base.paper_route,learned,masked.model,masked.mask_core,parent,files,preflight)
    return {Path(m.__file__).name:files.item(m.__file__) for m in modules}|{'caller':files.item(__file__)}


def freeze():
    pins={};TRAIN=files.item(TRAIN_PATH);train=files.js(TRAIN,pins);tr=files.js(train['registry'],pins);material=files.js(train['material'],pins)
    files.require(train['execution_status']=='warm_nativecell_Student3_full117_typed41_known_evaluated'
        and train['policy']==masked.recipe() and tr['sources']['caller']==files.item(masked.__file__)
        and train['counts']['training_runs']==1 and train['epochs_completed']==30
        and train['unknown_numeric_decodes']==0 and tr['warm_train']==masked.WARM_TRAIN,
        'authentic final30 V60 producer, not V53 or V57 model')
    check=preflight.preflight(json_contracts=[dict(asset=TRAIN,paths=[['epochs_completed'],['model_state_sha256'],['files','model'],['runtime_during_training'],['device']])],
        api_contracts=[dict(module_name=masked.__name__,function_name='load_checkpoint',required_parameters=['checkpoint','reg','field_map','device'],source_sha256=files.item(masked.__file__)['sha256']),
            dict(module_name=direct.__name__,function_name='network',required_parameters=['reg','pins'],source_sha256=files.item(direct.__file__)['sha256']),
            dict(module_name=learned.__name__,function_name='fit_known_metric',required_parameters=['z_fit','y_fit_fine'],source_sha256=files.item(learned.__file__)['sha256']),
            dict(module_name=base.paper_route.__name__,function_name='calibrate_known_cutoffs',required_parameters=['score','predicted_coarse'],source_sha256=files.item(base.paper_route.__file__)['sha256']),
            dict(module_name=base.__name__,function_name='route_once',required_parameters=['metric','query','raw','sink'],source_sha256=files.item(base.__file__)['sha256'])])
    prior=files.js(PARENT,pins);old=files.js(prior['registry'],pins);primary=files.js(base.PRIMARY,pins)
    files.require(prior['original_class_gates']['UNA']['correct']==2605 and prior['prediction_sealed'], 'frozen2605 whole-vector baseline')
    files.require(material['encoded_inputs']==old['assets']['encoded'] and material['encoder']==old['assets']['encoder'],
        'same117 complete encoder and genuineFIT6000 source; no preprocessing replay')
    assets={k:old['assets'][k] for k in ('encoded','encoder','prepared','query_geometry')}
    assets.update(model=train['files']['model'],field_map=tr['assets']['field_map'],baseline=prior['files']['postseal_comparison'],primary_known=primary['updated_clean_material'])
    headers={k:masked.previous.metadata_headers(a,pins) for k,a in assets.items() if Path(a['path']).suffix=='.npz'}
    for role,n in (('fit',6000),('calibration',656),('open_known',654)):
        files.require(headers['encoded'][role+'_features']['shape']==[n,117] and headers['encoded'][role+'_ids']['shape']==[n], 'actual encoded role metadata:'+role)
    files.require(headers['query_geometry']['Z149']['shape']==[3598,149]
        and all(k in headers['query_geometry'] for k in ('ids','groups','stage1','predicted_fine'))
        and all(k in headers['prepared'] for k in old['material_descriptors'])
        and set(('ids','truth','prediction')).issubset(headers['baseline']), 'exact NPZ members before any numeric execution')
    for a in assets.values():files.read(a,pins)
    for a in sources().values():files.read(a,pins)
    files.require(not REGISTRY.exists() and not BASE.exists(),'fresh once-only V62 CPU clean149')
    REGISTRY.parent.mkdir(parents=True,exist_ok=False)
    reg=dict(schema_version=SCHEMA+'-registry',policy=policy(),sources=sources(),assets=assets,train_report=TRAIN,
        masked_registry=train['registry'],parent_report=PARENT,primary_report=base.PRIMARY,
        material_descriptors=old['material_descriptors'],headers=headers,model_state_sha256=train['model_state_sha256'],
        metric_recipe=learned.training_recipe(149),producer_runtime=train['runtime_during_training'],producer_device=train['device'],artifact_API_preflight=check,
        original_primary_classifier_state=base.PRIMARY_SHA,legacy_CUDA_clean_cache_used=False,
        new_deployment_context=dict(device='cpu',dtype='float32',batch_size=BATCH,autocast=False),
        output={p:str(BASE/p) for p in ('known','current')},input_sha256=pins,numeric_decodes=0,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    reg['registry_sha256']=files.digest(reg);return files.write(REGISTRY,reg)


def bind(path,sha,pins):
    ref=dict(path=str(Path(path).resolve()),sha256=sha);reg=files.js(ref,pins)
    unsigned=dict(reg);signature=unsigned.pop('registry_sha256')
    files.require(signature==files.digest(unsigned) and reg['policy']==policy() and reg['sources']==sources()
        and reg['metric_recipe']==learned.training_recipe(149),'exact new maskclean149 registry/source/recipe')
    for p,h in reg['input_sha256'].items():files.read(dict(path=p,sha256=h),pins)
    return ref,reg


def save(out,report,name,values):return base.save(out,report,name,values)


def load(asset,keys,pins):return base.archive(asset,keys,pins)


def infer_cpu_once(net,x,role,out,report):
    files.require(x.dtype==np.float32 and x.shape==(len(x),117) and np.isfinite(x).all()
        and next(net.parameters()).device.type=='cpu','explicit new CPUfloat32 full117 deployment')
    began=time.perf_counter();captured=[];state=masked.output_io.state_digest(net)
    flags={n:p.requires_grad for n,p in net.named_parameters()}
    def hook(module,args,output):
        values={name:part.detach().float().cpu().numpy().copy() for name,part in output.items()}
        save(out,report,role+'_CPU_raw5_batch'+str(len(captured))+'_before_guard',values);captured.append(values)
    handle=net.register_forward_hook(hook)
    try:
        with torch.no_grad():result=masked.model.infer(net,x,device=torch.device('cpu'),batch_size=BATCH)
    finally:handle.remove()
    values={key:np.asarray(value).copy() for key,value in vars(result).items()}
    for key in masked.RAW_FIELDS:values['raw_'+key]=np.concatenate([batch[key] for batch in captured])
    values['embedding32']=values['embedding'].copy()
    asset=save(out,report,role+'_CPU_complete_all7_raw5_before_guard',values)
    report['files'][role+'_clean']=asset
    report['counts']['CPU_clean_forward_batches']+=len(captured)
    report['CPU_inference_seconds_by_role'][role]=time.perf_counter()-began
    files.require(set(values)==set(base.COMPLETE_KEYS) and all(set(batch)==masked.RAW_FIELDS for batch in captured)
        and len(captured)==(len(x)+BATCH-1)//BATCH and len(vars(result))==7
        and all(len(v)==len(x) and np.isfinite(v).all() for v in values.values())
        and flags=={n:p.requires_grad for n,p in net.named_parameters()}
        and masked.output_io.state_digest(net)==state, 'complete frozen real CPUfloat32 inference raw5/all7')
    return values


def run(phase,path,sha,known_path=None,known_sha=None):
    started,pins=time.perf_counter(),{};registry,reg=bind(path,sha,pins)
    if phase=='current':
        ka=dict(path=str(Path(known_path).resolve()),sha256=known_sha);known=files.js(ka,pins)
        files.require(known['registry']==registry and known['known_gate_passed'] and known['prediction_sealed']
            and known['unknown_numeric_rows_decoded']==0,'new exact known gate precedes unknown numeric rows')
    out=Path(reg['output'][phase]);files.require(not out.exists(),'fresh once-only maskclean149 '+phase);out.mkdir(parents=True)
    report=dict(schema_version=SCHEMA,phase=phase,registry=registry,policy=policy(),files={},
        counts=dict(NN_retraining=0,primary_forward=0,known_auxiliary_forward=0,auxiliary_unknown_forward=0,
            unit_fit=0,metric_fit=0,FIT_radius_fit=0,CAL_fit=0,query_score=0,DVC_calls=0,CPU_clean_forward_batches=0),
        CPU_inference_seconds_by_role={},
        training_seconds=0.0,prediction_sealed=False,truth_opened=False,unknown_numeric_rows_decoded=0,
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    runtime_before=masked.capture_runtime_flags()
    try:
        inherited=load(reg['assets']['prepared'],tuple(reg['material_descriptors']),pins)
        files.require({k:base.descriptor(v) for k,v in inherited.items()}==reg['material_descriptors'],'original primary149 known material byte descriptors')
        if phase=='known':
            encoded=load(reg['assets']['encoded'],('fit_features','fit_ids','fit_known_fine','calibration_features','calibration_ids','open_known_features','open_known_ids'),pins)
            files.require(len(np.unique(encoded['fit_ids']))==6000 and np.array_equal(encoded['fit_ids'],inherited['fit_ids'])
                and np.array_equal(encoded['fit_known_fine'],inherited['fit_fine']) and np.all(np.bincount(inherited['fit_fine'],minlength=9)>=20),
                'genuineFIT6000 IDs/knownfine, no traffic copies')
            primary=load(reg['assets']['primary_known'],('fit_ids','fit_known_fine'),pins)
            lookup={sample:i for i,sample in enumerate(encoded['fit_ids'].tolist())}
            files.require(len(np.unique(primary['fit_ids']))==4034 and set(primary['fit_ids'].tolist()).issubset(lookup),
                'original primary4034 unique IDs contained in union6000')
            selected=np.asarray([lookup[sample] for sample in primary['fit_ids'].tolist()],np.int64)
            files.require(np.array_equal(encoded['fit_known_fine'][selected],primary['fit_known_fine']), 'original primary truefine order and labels contained exactly')
            report['original_primary_uniqueFIT4034_subset_of_shared6000']=True
            net=direct.network(reg,pins)
            embeddings={r:infer_cpu_once(net,encoded[r+'_features'],r,out,report)['embedding32'] for r in ('fit','calibration','open_known')}
            representatives,_=base.representatives(inherited['fit_ids'],inherited['fit_groups'])
            plan=dict(FIT_embedding=base.descriptor(embeddings['fit']),FIT_ids=base.descriptor(inherited['fit_ids']),FIT_group_representatives=representatives.tolist(),query_used=False)
            plan['prefit_sha256']=files.digest(plan);report['files']['unit_prefit']=files.write(out/'maskclean_embedding_RMS_prefit_before_units.json',plan)
            units=base.fit_units(embeddings['fit'],representatives,plan['prefit_sha256']);report['counts']['unit_fit']=1
            units.pop('state_sha256');units['schema_version']=SCHEMA+'-FIT-maskclean-embedding32-units';units['state_sha256']=files.digest(units)
            report['files']['units']=files.write(out/'FIT_only_maskclean_embedding32_units_before_metric.json',units)
            material={k:inherited[k] for k in inherited if not k.endswith('_Z149')}
            for role in embeddings:
                files.require(np.array_equal(encoded[role+'_ids'],inherited[role+'_ids']), 'same genuine saved role IDs:'+role)
                material[role+'_Z149']=base.transform149(embeddings[role],encoded[role+'_features'],units)
            report['files']['material']=save(out,report,'genuine_known_maskclean149_before_metric',material)
            kwargs=base.metric_kwargs(material);prefit=learned.prefit_descriptor(material['fit_Z149'],material['fit_fine'],**kwargs)
            report['files']['metric_prefit']=files.write(out/'maskclean149_FIT_only_pair_plan_before_metric_fit.json',prefit)
            metric=learned.fit_known_metric(material['fit_Z149'],material['fit_fine'],expected_prefit_sha256=prefit['prefit_sha256'],**kwargs);report['counts']['metric_fit']=1
            report['training_seconds']=metric.to_state()['trained']['training_seconds']
            report['files']['metric']=files.write(out/'own_maskclean149_metric_before_CAL.json',metric.to_state())
            reference=base.make_reference(material)
            report['files']['reference']=save(out,report,'genuine_maskclean149_reference_before_R7',reference)
            radii=base.fit_radii(metric,reference,lambda label,v:save(out,report,'FIT_fine'+str(label)+'_returned_distances',v));report['counts']['FIT_radius_fit']=1
            report['files']['radii']=save(out,report,'FIT_only_maskclean149_R7_before_CAL',dict(radii=radii))
            cal_score=base.scores(metric,material['calibration_Z149'],material['calibration_predicted_fine'],reference,radii,
                lambda label,v:save(out,report,'CAL_fine'+str(label)+'_returned_distances',v))
            save(out,report,'knownCAL656_scores_before_cutoff',dict(score=cal_score,stage1=material['calibration_stage1']))
            cut=base.paper_route.calibrate_known_cutoffs(cal_score,material['calibration_stage1']);report['counts']['CAL_fit']=1
            report['files']['calibration']=files.write(out/'one_knownCAL656_before_OPEN654.json',dict(cutoffs=cut,query_used=False,truth_used=False))
            query=dict(ids=material['open_known_ids'],groups=material['open_known_groups'],Z149=material['open_known_Z149'],
                stage1=material['open_known_stage1'],predicted_fine=material['open_known_predicted_fine'])
            original=parent.previous.prefix_archive(reg['assets']['query_geometry'],('ids','groups','stage1','predicted_fine'),654,pins)
            files.require(all(np.array_equal(query[k],original[k]) for k in original),'exact original primary known654 stage/fine/IDs/groups')
        else:
            report['known_report']=ka
            material=load(known['files']['material'],tuple(inherited),pins)
            units=files.js(known['files']['units'],pins);metric=learned.PaperVariationalPairMetric.from_state(files.js(known['files']['metric'],pins))
            reference=load(known['files']['reference'],('Z149','known_fine_membership','ids','groups','original_indices'),pins)
            radii=load(known['files']['radii'],('radii',),pins)['radii'];cut=files.js(known['files']['calibration'],pins)['cutoffs']
            for name in ('units','material','metric','reference','radii','calibration'):report['files'][name]=known['files'][name]
            original=load(reg['assets']['query_geometry'],('ids','groups','Z149','stage1','predicted_fine'),pins);report['unknown_numeric_rows_decoded']=2944
            encoded=np.asarray(original['Z149'][:,32:],np.float32)
            files.require(np.array_equal(encoded.astype(np.float64),original['Z149'][:,32:])
                and np.array_equal(encoded[:654],load(reg['assets']['encoded'],('open_known_features',),pins)['open_known_features']),
                'exact original encoded117 current and known654 prefix, no rounding repair')
            net=direct.network(reg,pins)
            unknown=infer_cpu_once(net,encoded[654:],'unknown2944',out,report)
            report['counts']['auxiliary_unknown_forward']=1
            cached=load(known['files']['open_known_clean'],base.COMPLETE_KEYS,pins)
            embedding=np.concatenate((cached['embedding32'],unknown['embedding32']),axis=0)
            query=dict(ids=original['ids'],groups=original['groups'],stage1=original['stage1'],predicted_fine=original['predicted_fine'],
                Z149=base.transform149(embedding,encoded,units))
            files.require(np.array_equal(query['Z149'][:654],material['open_known_Z149']), 'same saved authentic maskclean known654 geometry, no known NN replay')
            save(out,report,'all3598_maskclean_embedding_before_geometry',dict(embedding32=embedding))
        save(out,report,'actual_query_nativecell_clean149_before_scores',query)
        baseline=parent.previous.prefix_archive(reg['assets']['baseline'],('prediction',),654,pins)['prediction'] if phase=='known' else load(reg['assets']['baseline'],('prediction',),pins)['prediction']
        score=base.scores(metric,query['Z149'],query['predicted_fine'],reference,radii,
            lambda label,v:save(out,report,'query_fine'+str(label)+'_returned_distances',v));report['counts']['query_score']=1
        raw=base.paper_route.candidate_mask(score,query['stage1'],cut);density=raw|(baseline==2)
        save(out,report,'new_maskclean149_candidates_before_DVC',dict(score=score,raw=raw,density=density,stage1=query['stage1']))
        def sink(name,value,manifest):
            manifest=dict(manifest,schema_version=SCHEMA+'-DVC')
            save(out,report,name+'_DVC_result',value);report['files'][name+'_DVC_manifest']=files.write(out/(name+'_DVC_manifest.json'),manifest)
        route,_=base.route_once(metric,query,density,sink);report['counts']['DVC_calls']=1
        own_retained=raw&route['retained'];prediction=base.merge(baseline,raw,own_retained)
        before=dict(ids=query['ids'],prediction=prediction,baseline=baseline,raw=raw,density=density,retained=own_retained,density_retained=route['retained'])
        pa=save(out,report,'prediction_before_truth',before)
        report['files']['prediction_seal']=files.write(out/'prediction_seal_before_truth.json',dict(predictions=pa,registry=registry,metric=report['files']['metric'],CAL=report['files']['calibration'],truth_opened=False));report['prediction_sealed']=True
        truth=parent.previous.prefix_archive(reg['assets']['baseline'],('ids','truth'),654,pins) if phase=='known' else load(reg['assets']['baseline'],('ids','truth'),pins)
        files.require(np.array_equal(query['ids'],truth['ids']),'exact same original truth IDs only after seal');report['truth_opened']=True
        effect,gates,prior=base.delta(truth['truth'],prediction,baseline,full=phase=='current')
        save(out,report,'postseal_comparison',dict(**before,truth=truth['truth']))
        zero_loss=all(effect['gain_loss'][n]['loss']==0 for n in ('BEN','KNA'))
        report.update(execution_status='nativecell_CPUclean149_'+phase+'_evaluated',original_class_gates=gates,baseline_class_gates=prior,EffectDelta=effect,
            known_gate_passed=zero_loss and all(gates[n]['passed'] for n in ('BEN','KNA')),paired_known_no_loss=zero_loss,
            all_three_integer99_passed=phase=='current' and all(g['passed'] for g in gates.values()),DEV_review_eligible=phase=='current' and effect['verdict']=='UP' and zero_loss,
            known_raw=int(raw[:654].sum()),known_retained=int(own_retained[:654].sum()),unknown_raw=int(raw[654:].sum()),unknown_retained=int(own_retained[654:].sum()),
            density_members=int(density.sum()),cutoffs=cut,metric_state_sha256=metric.state_sha256,baseline2605_UNA_preserved=True,primary_classifier_unchanged=True)
        report['explicit_gate_status']=gate_status(gates,{n:effect['gain_loss'][n]['loss'] for n in ('BEN','KNA')})
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        if runtime_before is not None:
            restored=masked.restore_runtime_flags(runtime_before);report['runtime_restoration']=dict(before=runtime_before,after=restored,all_flags_restored=restored==runtime_before)
        for p,h in pins.items():files.require(files.item(p)['sha256']==h,'frozen maskclean149 source/model/input unchanged:'+p)
        report.update(input_sha256=pins,wall_seconds=time.perf_counter()-started,NN_training_seconds=0.0,CPU_inference_seconds=sum(report['CPU_inference_seconds_by_role'].values()));files.write(out/'report.json',report)
    return files.item(out/'report.json')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for name in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+name)
    a=p.parse_args();print(json.dumps(freeze() if a.phase=='freeze' else run(a.phase,a.registry,a.registry_sha256,a.known_report,a.known_sha256)))
