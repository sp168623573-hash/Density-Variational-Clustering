"""One fixed GradNorm cue reuses authenticated V76 real-head cache packets.

NSL1 uses the real full117 typed-masked auxiliary fine head, not primary35e;
the original primary35e decisions remain. CIC1 uses the real primary fine head.
Only known CAL calibrates the fixed cue. No neural/model/metric fitting or
forward occurs here. Unchanged original149/126 geometry owns each DVC route.
Old whole2618/2399 predictions are preserved and new raw plus DVC-retained UNA
may be appended. This is warm development, not independent final testing.
"""
from __future__ import annotations
import argparse
import io
import json
from pathlib import Path
import sys
import time
import types
import numpy as np
import torch
from threadpoolctl import threadpool_limits
from . import fine_head_gradnorm_v84 as core
from . import nsl1_classifier_ViM174_v76 as nsl_head_source
from . import nsl1_nativecell_clean149_v62 as nsl
from . import cic1_primary_head_vim120_v76 as cic_head_source
from . import cic1_known_domain_radial_flow126_v69 as cic

ROOT, files, require = nsl.ROOT, nsl.files, nsl.files.require
MODULE = 'paper_open_set.nsl1_cic1_gradnorm_candidates_v84'
BUILD = ROOT / 'tmp/framework_and_gradnorm_20261012_v84'
BASE = ROOT / 'data/external_dev/processed/known_head_GradNorm_20261012_v84'


def policy(setting):
    require(setting in ('NSL1','CIC1'), 'only declared NSL1/CIC1')
    return dict(schema_version=setting+'-actualhead-GradNorm-originalgeometry-v84',
        setting=setting, hypotheses=1, cue=core.recipe(),
        actual_head='authentic V60 known-only full117 typed-masked MHFD fine_head; extension, not primary35e' if setting=='NSL1' else 'authentic frozen selected67 primary50 MHFD fine_head',
        decisions='original whole2618' if setting=='NSL1' else 'original whole2399',
        calibration='alltrueknown CAL656' if setting=='NSL1' else 'alltrueknown CAL900',
        calibration_rule='finite99 per trueknown coarse once; original query stage1 chooses cutoff only',
        geometry='exact original149' if setting=='NSL1' else 'exact original126',
        DVC='same owned Eq9/10 metric, affinity/reconstruction/local density, secondary-noise; no120/174 geometry or metric consumed',
        merge='whole retained prediction copy; only own newraw AND matching DVC retained set UNA; prior predictedUNA preserved',
        known_gate='exact BEN/KNA integer99 and rowwise alloldcorrect loss0 before current real arrays',
        retention_gate='complete same IDs/support; allthree correct rowloss0, binary attack correct rowloss0 and at least one gain',
        query_truth_input=False, trueUNA_fit=False, candidate_fit=False, NN_fit=0,
        backbone_forward=0, head_forward=0, metric_fit=0, field_selection=False,
        timecap_coded=False, extension_not_verbatim_paper=True, warm_development_only=True,
        status='FAIL_TARGET99', published=False, final_test_executed=False)


def closure():
    pending=[sys.modules[__name__],core,nsl_head_source,nsl,cic_head_source,cic]
    result={}
    while pending:
        m=pending.pop()
        name=MODULE if m.__name__=='__main__' else m.__name__
        if not name.startswith('paper_open_set.') or name in result:
            continue
        result[name]=files.item(m.__file__)
        for v in vars(m).values():
            child=v if isinstance(v,types.ModuleType) else sys.modules.get(getattr(v,'__module__',''))
            if child is not None and child.__name__.startswith('paper_open_set.'):
                pending.append(child)
    return result


def archive(asset, keys, pins):
    return nsl.base.archive(asset, keys, pins)


def registry_path(setting):
    return BUILD / (setting+'_GradNorm_registry_before_known_v84.json')


def save(out, report, name, values):
    return nsl.base.save(out, report, name, values)


def metadata_assets(setting,pins):
    if setting=='NSL1':
        old_known_ref=nsl_head_source.OLD_KNOWN; base_ref=nsl_head_source.BASELINE
        old_known=files.js(old_known_ref,pins); current=files.js(base_ref,pins)
        head_ref=files.item(nsl_head_source.BASE/'known/report.json'); head=files.js(head_ref,pins)
        head_current_ref=files.item(nsl_head_source.BASE/'current/report.json'); hc=files.js(head_current_ref,pins)
        producer_registry=files.js(head['registry'],pins)
        ownreg=files.js(old_known['registry'],pins)
        assets=dict(model=producer_registry['assets']['model'],head_weights=head['files']['ViM_stats'],
            CAL_head=head['files']['CAL656_actualwhole_head32_fine9_proof'],
            known_head=head['files']['known654_actualwhole_head32_fine9_proof'],
            current_head=hc['files']['current3598_trueknown654_unknown2944_realhead_inputs_logits_residuals'],
            known_context=old_known['files']['actual_query_nativecell_clean149_before_scores'],
            current_context=current['files']['actual_query_nativecell_clean149_before_scores'],
            metric=old_known['files']['metric'],material=old_known['files']['material'],
            encoded=ownreg['assets']['encoded'],baseline=current['files']['postseal_comparison'],
            CAL_original_cache=producer_registry['assets']['CAL_clean'],
            known_original_cache=producer_registry['assets']['known_clean'])
        proof=files.item(ROOT/'tmp/nsl1_ViM174_20261012_v76_build/NSL1_V76_ACTUAL_HEAD_ViM174_SAVED_AUDIT.json')
        audit=files.js(proof,pins)
        require(audit['all_checks_passed'] and audit['actual_head_W_from_checkpoint_checked'], 'audited real typedmasked head, not guessedembedding32')
        require(current['original_class_gates']['UNA']['correct']==2618 and head['prediction_sealed'] and hc['prediction_sealed'],'whole2618 plus sealed authenticated head packets')
        ancestry=dict(primary_and_typedmasked_NN=1261.1884094000561,
            original149_wholeknown=old_known['wall_seconds'],
            cached_head_V76_wholeknown=head['wall_seconds'])
    else:
        old_known_ref=files.item(cic.BASE/'known/report.json'); base_ref=files.item(cic.BASE/'current/report.json')
        old_known=files.js(old_known_ref,pins); current=files.js(base_ref,pins)
        head_ref=files.item(cic_head_source.BASE/'known/report.json'); head=files.js(head_ref,pins)
        head_current_ref=files.item(cic_head_source.BASE/'current/report.json'); hc=files.js(head_current_ref,pins)
        producer_registry=files.js(head['registry'],pins)
        ownreg=files.js(old_known['registry'],pins)
        assets=dict(model=producer_registry['assets']['primary_model'],head_weights=head['files']['actual_head_weights'],
            CAL_head=head['files']['CAL_whole_actual_primary_head_before_ViM'],
            known_head=head['files']['CP_whole_actual_primary_head_before_ViM'],
            current_head=hc['files']['current4056_whole_actual_primary_head_before_ViM'],
            material=old_known['files']['native78_preserved32_radial16_allrole126_before_metric'],
            current_context=current['files']['whole4056_native32_radial16_Z126_before_score'],
            metric=old_known['files']['metric'],native_known=ownreg['assets']['native_known'],
            known_baseline=old_known['files']['complete_prediction_before_truth'],
            baseline=current['files']['complete_prediction_before_truth'],
            known_truth=ownreg['assets']['known110'],truth=ownreg['assets']['truth'])
        proof=files.item(ROOT/'tmp/cic1_primary_head_vim120_execution_20261012_v76/CIC1_V76_REALHEAD_ViM120_FULL_SAVED_AUDIT.json')
        audit=files.js(proof,pins)
        supplementary=files.item(ROOT/'tmp/cic1_primary_head_vim120_execution_20261012_v76/CIC1_V76_CURRENT4056_EXACT_GEOMETRY_LINKAGE_SUPPLEMENT.json')
        require(audit['all_passed'] and files.js(supplementary,pins)['all_passed'],'real primary head packet/checkpoint/prefix linkage saved audit')
        assets['current_geometry_linkage_supplement']=supplementary
        require(current['original_class_gates']['UNA']['correct']==2399 and head['prediction_sealed'] and hc['prediction_sealed'],'whole2399 and authenticated primary head packets')
        v76close=files.js(files.item(ROOT/'tmp/cic1_primary_head_vim120_execution_20261012_v76/CIC1_V76_REALHEAD_ViM120_COMPLETED_CLOSEOUT.json'),pins)
        original_training=files.js(current['train_report'],pins)
        times=v76close['training_and_execution_time']
        ancestry=dict(original_NN=times['ancestor_conservative_seconds'],
            original126_wholetrain=original_training['wall_seconds'],original126_wholeknown=old_known['wall_seconds'],
            cached_primaryhead_V76_wholeknown=head['wall_seconds'],
            cached_primaryhead_preflight=times['preflight_actualFIT512_forward_seconds'])
    return dict(assets=assets,original_known=old_known_ref,baseline_report=base_ref,
        head_known_report=head_ref,head_current_report=head_current_ref,
        cached_producer_registry=head['registry'],original_geometry_registry=old_known['registry'],
        head_proof=proof,ancestry_seconds=ancestry,
        cached_producer_sources=producer_registry['sources'],original_geometry_sources=ownreg['sources'])


def flatten_sources(value):
    found={}
    def walk(v):
        if isinstance(v,dict):
            if 'path' in v and 'sha256' in v and str(v['path']).endswith('.py'):
                found[str(Path(v['path']).resolve())]=dict(path=str(Path(v['path']).resolve()),sha256=v['sha256'])
            else:
                for child in v.values():walk(child)
        elif isinstance(v,list):
            for child in v:walk(child)
    walk(value)
    return found


def freeze(setting):
    began=time.perf_counter();pins={};refs=metadata_assets(setting,pins)
    sources=closure();cached=flatten_sources([refs['cached_producer_sources'],refs['original_geometry_sources']])
    for a in [*refs['assets'].values(),*sources.values(),*cached.values()]:files.read(a,pins)
    contract=core.synthetic_contract()
    require(not registry_path(setting).exists() and not (BASE/setting).exists(),'fresh once-only GradNorm branch')
    r=dict(policy=policy(setting),sources=sources,cached_sources=cached,**refs,
        synthetic_contract=contract,metadata_preparation_seconds=time.perf_counter()-began,
        real_current_numeric_decodes=0,real_truth_decodes=0,input_sha256=pins)
    return files.write(registry_path(setting),r)


def bind(setting,desc,pins):
    reg=files.js(desc,pins)
    require(reg['policy']==policy(setting) and reg['sources'][MODULE]==files.item(__file__) and reg['sources']==closure(), 'exact fixed own full runtime recursive closure')
    for a in [*reg['sources'].values(),*reg['cached_sources'].values()]:files.read(a,pins)
    return reg


def bind_head(setting,reg,pins):
    a=reg['assets'];checkpoint=torch.load(io.BytesIO(files.read(a['model'],pins)),map_location='cpu',weights_only=True)
    state=checkpoint['state_dict'];W=state['fine_head.weight'].detach().cpu().numpy();b=state['fine_head.bias'].detach().cpu().numpy()
    require(W.dtype==b.dtype==np.float32 and W.shape==(9,32) and b.shape==(9,),'authentic checkpoint full fine head shape32/9')
    if setting=='NSL1':
        saved=archive(a['head_weights'],('actualfineW','actualfinebias'),pins)
        require(np.array_equal(W.astype(np.float64),saved['actualfineW']) and np.array_equal(b.astype(np.float64),saved['actualfinebias']),'same authentic typedmasked head used by saved V76 packets')
    else:
        saved=archive(a['head_weights'],('W','b'),pins)
        require(checkpoint['input_dim']==50 and checkpoint['fine_class_count']==9 and checkpoint['selected_epoch']==67 and np.array_equal(W,saved['W']) and np.array_equal(b,saved['b']),'same actual primary50 selected67 head used by cached packets')
    return dict(checkpoint_asset=a['model'],cached_head_asset=a['head_weights'],actual_W_shape=list(W.shape),actual_b_shape=list(b.shape),
        W_and_b_equal_checkpoint=True,no_model_instantiation=True,no_NN_or_head_forward=True)


def packet(setting,asset,pins):
    if setting=='NSL1':
        p=archive(asset,('input32','actual_logits9'),pins)
        return p['input32'],p['actual_logits9'],None
    p=archive(asset,('ids','head_input32','raw_fine_logits9'),pins)
    return p['head_input32'],p['raw_fine_logits9'],p['ids']


def load_query(setting,phase,reg,pins):
    a=reg['assets']
    if setting=='NSL1':
        q=archive(a[phase+'_context'],('ids','groups','stage1','predicted_fine','Z149'),pins)
        if phase=='known':b=nsl.parent.previous.prefix_archive(a['baseline'],('ids','prediction'),654,pins)
        else:b=archive(a['baseline'],('ids','prediction'),pins)
        h,z,_=packet(setting,a[phase+'_head'],pins)
        if phase=='known':
            original=archive(a['known_original_cache'],('raw_embedding','raw_fine_logits'),pins)
            require(np.array_equal(h,original['raw_embedding']) and np.array_equal(z,original['raw_fine_logits']),'NSL1 head cache lineage exact original known packet')
        else:
            known_h,known_z,_=packet(setting,a['known_head'],pins)
            known_q=archive(a['known_context'],('ids','groups','stage1','Z149'),pins)
            require(np.array_equal(h[:654],known_h) and np.array_equal(z[:654],known_z)
                and all(np.array_equal(q[k][:654],known_q[k]) for k in ('ids','groups','stage1','Z149')),'current known654 prefix exact head and unchanged149')
    else:
        if phase=='known':
            p=archive(a['material'],('CP_ids','CP_groups','CP_stage1','CP_predicted_fine','CP_Z126'),pins)
            q={k:p['CP_'+k] for k in ('ids','groups','stage1','predicted_fine','Z126')}
            b=archive(a['known_baseline'],('ids','prediction'),pins)
        else:
            q=archive(a['current_context'],('ids','groups','stage1','predicted_fine','Z126'),pins)
            b=archive(a['baseline'],('ids','prediction'),pins)
        h,z,ids=packet(setting,a[phase+'_head'],pins)
        require(np.array_equal(ids,q['ids']),'CIC1 actualhead packet IDs exactly original126 query')
        if phase=='current':
            kh,kz,kids=packet(setting,a['known_head'],pins)
            p=archive(a['material'],('CP_ids','CP_groups','CP_stage1','CP_Z126'),pins)
            require(np.array_equal(kids,p['CP_ids']) and np.array_equal(h[:900],kh) and np.array_equal(z[:900],kz)
                and all(np.array_equal(q[k][:900],p['CP_'+k]) for k in ('ids','groups','stage1','Z126')),'CIC1 current known900 prefix exact existing full126 and primaryhead')
    width=149 if setting=='NSL1' else 126
    require(q['Z'+str(width)].shape==(len(q['ids']),width) and len(h)==len(q['ids']) and np.array_equal(q['ids'],b['ids']), 'same original width, row order, IDs and whole baseline')
    return q,b['prediction'],h,z


def metrics(y,b,p):
    names=('BEN','KNA','UNA');gates={};gl={}
    for c,n in enumerate(names):
        support=int((y==c).sum());correct=int(((y==c)&(p==c)).sum());required=(99*support+99)//100
        gates[n]=dict(correct=correct,support=support,required_correct=required,passed=support>0 and correct>=required,gap=max(0,required-correct))
        gl[n]=dict(gain=int(((y==c)&(b!=c)&(p==c)).sum()),loss=int(((y==c)&(b==c)&(p!=c)).sum()))
    delta={n:v['gain']-v['loss'] for n,v in gl.items()};pos=any(v>0 for v in delta.values());neg=any(v<0 for v in delta.values())
    old_binary=(b!=0)==(y!=0);new_binary=(p!=0)==(y!=0)
    binary=dict(gain=int((~old_binary&new_binary).sum()),loss=int((old_binary&~new_binary).sum()),
        old_correct=int(old_binary.sum()),new_correct=int(new_binary.sum()),support=len(y))
    return gates,dict(verdict='MIXED' if pos and neg else 'UP' if pos else 'DOWN' if neg else 'UNCHANGED',
        correct_count_delta=delta,gain_loss=gl,same_original_ID_order=True,accepted_baseline_replaced=False),binary


def run(setting,phase,desc,known_desc=None):
    started=time.perf_counter();pins={};reg=bind(setting,desc,pins)
    if phase=='current':
        known=files.js(known_desc,pins)
        require(known['registry']==desc and known['known_gate_passed'] and known['prediction_sealed'] and known['current_numeric_rows_decoded']==0,'strict same-source known admission before current arrays')
    out=BASE/setting/phase;out.mkdir(parents=True,exist_ok=False)
    r=dict(policy=policy(setting),registry=desc,phase=phase,files={},NN_fit=0,NN_forward=0,head_forward=0,
        metric_fit=0,statistics_fit=0,CAL_fit=0,DVC=0,current_numeric_rows_decoded=0,
        prediction_sealed=False,truth_opened=False,accepted_baseline_replaced=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    oldthreads=torch.get_num_threads()
    try:
        torch.set_num_threads(2)
        with threadpool_limits(limits=2):
            if phase=='known':
                prep=time.perf_counter();r['head_binding']=bind_head(setting,reg,pins)
                h,z,ids=packet(setting,reg['assets']['CAL_head'],pins)
                if setting=='NSL1':
                    label=archive(reg['assets']['encoded'],('calibration_ids','calibration_known_coarse'),pins)
                    ids=label['calibration_ids'];coarse=label['calibration_known_coarse']
                    original=archive(reg['assets']['CAL_original_cache'],('raw_embedding','raw_fine_logits'),pins)
                    require(np.array_equal(h,original['raw_embedding']) and np.array_equal(z,original['raw_fine_logits']),'authenticated NSL1 CAL head exactly original clean cache')
                else:
                    label=archive(reg['assets']['native_known'],('CAL_ids','CAL_y_coarse'),pins)
                    require(np.array_equal(ids,label['CAL_ids']),'all actual900 trueknown CAL IDs exactly cachedhead')
                    coarse=label['CAL_y_coarse']
                require(len(h)==(656 if setting=='NSL1' else 900) and np.isin(coarse,(0,1)).all(),'all declared trueknown CAL rows; no UNA')
                cs,detail=core.scores(h,z)
                save(out,r,'alltrueknown_CAL_GradNorm_before_cut',dict(ids=ids,truecoarse=coarse,score=cs,**detail))
                cut=nsl.base.paper_route.calibrate_known_cutoffs(cs,coarse)
                r['CAL_fit']=1;r['files']['cutoffs']=files.write(out/'alltrueknown_once_GradNorm_finite99.json',cut)
                r['training_preparation_seconds']=time.perf_counter()-prep
            else:
                cut=files.js(known['files']['cutoffs'],pins);r['files']['cutoffs']=known['files']['cutoffs'];r['known_report']=known_desc
                r['training_preparation_seconds']=0.0
            query,b,h,z=load_query(setting,phase,reg,pins)
            if phase=='current':r['current_numeric_rows_decoded']=len(h)
            ss=time.perf_counter();score,detail=core.scores(h,z);r['query_score_seconds']=time.perf_counter()-ss
            raw=nsl.base.paper_route.candidate_mask(score,query['stage1'],cut);density=raw|(b==2)
            save(out,r,'actualhead_GradNorm_score_raw_before_DVC',dict(ids=query['ids'],score=score,raw=raw,density=density,stage1=query['stage1'],**detail))
            width=149 if setting=='NSL1' else 126
            payload=files.js(reg['assets']['metric'],pins)
            if setting=='CIC1':payload=payload['metric_payload']
            metric=(nsl.learned if setting=='NSL1' else cic.learned).PaperVariationalPairMetric.from_state(payload)
            r['files']['metric']=reg['assets']['metric']
            save(out,r,'unchanged_original'+str(width)+'_query_before_DVC',query)
            ds=time.perf_counter()
            if setting=='NSL1':
                def sink(name,values,manifest):
                    save(out,r,name+'_DVC_before_truth',values)
                    r['files'][name+'_DVC_manifest']=files.write(out/(name+'_DVC_manifest.json'),manifest)
                route,_=nsl.base.route_once(metric,query,density,sink)
            else:
                route=cic.dvc.route_current_candidates(metric,query['Z126'],density,seed=20261009)
                save(out,r,'original126_DVC_before_truth',{k:v for k,v in route.items() if k!='manifest'})
                r['files']['DVC_manifest']=files.write(out/'original126_DVC_manifest.json',route['manifest'])
            r['DVC']=1;r['query_DVC_inference_seconds']=time.perf_counter()-ds
            retained=raw&route['retained'];p=b.copy();p[retained]=2
            require(np.all(p[b==2]==2) and np.array_equal(p[~retained],b[~retained]),'old wholeUNA preserved and own retained increment only')
            values=dict(ids=query['ids'],prediction=p,baseline=b,raw=raw,density=density,retained=retained,density_retained=route['retained'])
            sealed=save(out,r,'complete_prediction_before_truth',values)
            r['files']['seal']=files.write(out/'prediction_seal_before_truth.json',dict(predictions=sealed,registry=desc,metric=reg['assets']['metric'],cutoffs=r['files']['cutoffs'],truth_used=False))
            r['prediction_sealed']=True
            if setting=='NSL1':
                truth=nsl.parent.previous.prefix_archive(reg['assets']['baseline'],('ids','truth'),654,pins) if phase=='known' else archive(reg['assets']['baseline'],('ids','truth'),pins)
                require(np.array_equal(truth['ids'],query['ids']),'same NSL1 truth after complete seal')
                y=truth['truth']
            elif phase=='known':y=archive(reg['assets']['known_truth'],('CP_truth',),pins)['CP_truth']
            else:
                truth=archive(reg['assets']['truth'],('ids','truth'),pins)
                require(np.array_equal(truth['ids'],query['ids']),'same CIC1 truth after complete seal');y=truth['truth']
            r['truth_opened']=True;gates,effect,binary=metrics(y,b,p)
            save(out,r,'postseal_paired_comparison',dict(**values,truth=y))
            loss={n:effect['gain_loss'][n]['loss'] for n in ('BEN','KNA')}
            r.update(execution_status='GradNorm_original'+str(width)+'_'+phase+'_evaluated',original_class_gates=gates,
                EffectDelta=effect,binary_attack_detection=binary,known_correct_loss=loss,
                known_gate_passed=all(gates[n]['passed'] and loss[n]==0 for n in ('BEN','KNA')),
                raw_by_true_class={n:int(((y==c)&raw).sum()) for c,n in enumerate(('BEN','KNA','UNA'))},
                new_external_raw_by_true_class={n:int(((y==c)&raw&(b!=2)).sum()) for c,n in enumerate(('BEN','KNA','UNA'))},
                all_old_correct_loss_free=all(x['loss']==0 for x in effect['gain_loss'].values()),
                candidate_accepted_for_retention=phase=='current' and effect['verdict']=='UP' and all(x['loss']==0 for x in effect['gain_loss'].values()) and binary['loss']==0,
                all_three_integer99_passed=phase=='current' and all(x['passed'] for x in gates.values()))
        for path,sha in pins.items():require(files.item(path)['sha256']==sha,'all old saved bytes preserved')
    except Exception as error:
        r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        torch.set_num_threads(oldthreads);r.update(threads_restored=torch.get_num_threads()==oldthreads,
            input_sha256=pins,wall_seconds=time.perf_counter()-started)
        if phase=='known':
            r['conservative_preparation_seconds']=sum(reg['ancestry_seconds'].values())+reg['metadata_preparation_seconds']+r['wall_seconds']
            r['ancestry_components_seconds']=reg['ancestry_seconds']
            r['conservative_preparation_minutes']=r['conservative_preparation_seconds']/60
        files.write(out/'report.json',r)
    return files.item(out/'report.json')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--setting',choices=('NSL1','CIC1'),required=True)
    p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for name in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+name)
    a=p.parse_args()
    if a.phase=='freeze':print(json.dumps(freeze(a.setting)))
    else:
        descriptor=dict(path=str(Path(a.registry).resolve()),sha256=a.registry_sha256)
        known_desc=dict(path=str(Path(a.known_report).resolve()),sha256=a.known_sha256) if a.known_report else None
        print(json.dumps(run(a.setting,a.phase,descriptor,known_desc)))
