"""R996 no-new-NN/no-newmetric source and whole3124 role boundary."""
from pathlib import Path
import hashlib,importlib.util,io,json,sys
import numpy as np
H=Path(__file__).resolve().parent;MANIFEST=H/'INPUT_MANIFEST_V996.json'

def require(v,s):
    if not bool(v):raise ValueError(s)

def descriptor(path):
    p=Path(path).resolve(strict=True);return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def raw(d):
    b=Path(d['path']).read_bytes();require(hashlib.sha256(b).hexdigest()==d['sha256'],'immutable '+d['path']);return b

def js(d):return json.loads(raw(d).decode('utf-8-sig'))

def arrays(d,keys):
    with np.load(io.BytesIO(raw(d)),allow_pickle=False)as a:return{k:a[k]for k in keys}

def module(d,prefix):
    raw(d);sp=importlib.util.spec_from_file_location(prefix+'_'+d['sha256'],d['path']);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m);return m

def manifest():return json.loads(MANIFEST.read_text(encoding='utf8'))

def original():return module(manifest()['inherited_inputs'],'V996_original3124_inputs')

def load_source():
    a=original();s=a.source();m=manifest();fm=js(m['fieldmap_manifest'])['field_map']['groups'];columns=[g['selected_columns']for g in fm]
    require(s['native115'].shape==(5967,115)and s['Z359'].shape==(5967,359)and len(columns)==40,'original complete native40/115 and source359 geometry')
    require(len(np.unique(s['ids']))==len(np.unique(s['groups']))==5967 and np.array_equal(np.unique(s['fine']),np.arange(9)),'same original known physical source fine9')
    return dict(ids=s['ids'],groups=s['groups'],fine=s['fine'],native=s['native115'],native115=s['native115'],Z359=s['Z359'],field_columns=columns,
        logical_X=s['logical_X'],logical_fine=s['logical_training_fine'],logical_groups=s['logical_parent_ids'],optimizer_indices=s['optimizer_indices'],
        source_trace=dict(genuine_source_rows=5967,logical_source_rows=5999,original_parentmap_unchanged=True),NN_fit=0,NN_readout=0,newmetricfit=0)

def load_role(role):
    require(role in('CAL','CP','current'),'declared complete role')
    a=original();q=a.role(role);scores=a.role_scores980(role);p=a.role_prior980(role)
    require(np.array_equal(q['ids'],scores['ids'])and np.array_equal(q['ids'],p['ids'])and np.array_equal(q['parent_prediction'],p['prediction']),'whole3124 scores and complete prediction aligned')
    return dict(ids=q['ids'],groups=q['groups'],native=q['native115'],native115=q['native115'],Z359=scores['Z'],
        parent_prediction=q['parent_prediction'],ancestor2963_prediction=p['parent_prediction'],base_raw=p['new_raw'],
        old_scores=scores,role=role,NN_fit=0,NN_readout=0,newmetricfit=0,current_truth_decodes=0)

def load_known_labels(role):
    require(role in('CAL','CP'),'CAL fitting or separately sealed CP only; no current truth API')
    return original().known_labels(role)

def fixed_metric():
    m=manifest();M=module(m['metric_code'],'V996_original359_metric_class');metric=M.PaperVariationalPairMetric.from_state(js(m['metric_state']))
    require(metric.dimension==359,'exact inherited source-fitted359 metric only')
    return metric

def prepare_manifest():
    h=Path('E:/Experiment/software transcition/target99_v990_20261024/nsl2_iofix_r1');a=module(descriptor(h/'inputs_v990.py'),'V996_source_manifest_parent_adapter');m=a.manifest();c=js(m['base_source_contract'])
    value=dict(schema='V996_SOURCE_CONTEXT_OBJECT_ROUTER_INPUTS',setting='NSL-KDD Setting2',parent='V980_complete3124',
        inherited_inputs=descriptor(h/'inputs_v990.py'),inherited_input_manifest=descriptor(a.MANIFEST),
        metric_code=c['code']['metric'],metric_state=m['V980_metric_state'],fieldmap_manifest=m['original_legacy_fieldmap'],
        original_source359=m['V980_source_geometry'],roles=m['roles'],source_genuine_rows=5967,logical_source_rows=5999,
        native_encoded_width=115,original_field_groups=40,density_geometry_dimension=359,
        current_truth_authority=m['current_truth_authority'],current_support=[1604,589,3393],
        current_CP721_not_full_subset=True,current_CP_partial_ID_overlap=72,source_training_only=['BEN','KNA'],
        newNNfit=0,newNNreadout=0,newmetricfit=0,all_original_wholeversions_preserved=True,
        parent_correct_integer_counts=[1511,582,3124],required_correct_integer_counts=[1588,584,3360],necessary_new_correct_minimum=[77,2,236],
        pretruth_capacity='upper_c=parentcorrect_c+count(parentpred!=c and childpred==c); insufficient any class stops unscored',
        no_current_truth_read_during_preparation=True,status='FAIL_TARGET99',published=False,final_test_executed=False)
    with MANIFEST.open('x',encoding='utf8')as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
    return descriptor(MANIFEST)

if __name__=='__main__':print(json.dumps(prepare_manifest(),ensure_ascii=False))
