"""Nearest genuine known reference versus owncohort seventh other distance."""
import numpy as np
K=7
def require(v,why):
    if not v:raise ValueError(why)
def ratio(d,q):
    s=np.maximum(d,q);out=np.zeros_like(d);nonzero=s>0;a=d[nonzero]/s[nonzero];b=q[nonzero]/s[nonzero];out[nonzero]=a*a/(a*a+b*b);return out
def score(metric,reference,query):
    f=np.asarray(reference,np.float64);q=np.asarray(query,np.float64)
    require(metric.dimension==149 and f.shape==(len(f),149) and q.shape==(len(q),149) and len(q)>K and len(f)>0 and np.isfinite(f).all() and np.isfinite(q).all(),'ownedwhole149 genuine references/queryother7')
    known=metric.pairwise_distances(q,f);nearest=known.min(1);qq=metric.pairwise_distances(q)
    require(np.array_equal(np.diag(qq),np.zeros(len(q))) and np.isfinite(qq).all(),'actualownedselfzero finitequerymatrix')
    other=qq.copy();np.fill_diagonal(other,np.inf);r7=np.partition(other,K-1,axis=1)[:,K-1];value=ratio(nearest,r7)
    require(np.isfinite(value).all() and np.all((value>=0)&(value<=1)),'closedratio without epsilon naturalbothzero0')
    return dict(score=value,nearest_allknown_distance=nearest,query_other_R7=r7,query_to_allknown_distances=known,query_pair_distances=qq)
def synthetic_contract():
    class M:
        dimension=149
        def pairwise_distances(self,q,r=None):
            r=q if r is None else r;return np.sqrt(np.square(q[:,None]-r[None]).sum(2))
    q=np.zeros((9,149));q[:,0]=np.arange(9);f=np.zeros((2,149));f[1,0]=10;r=score(M(),f,q)
    expected=np.abs(np.arange(9)[:,None]-np.arange(9)[None]).astype(float);np.fill_diagonal(expected,np.inf)
    require(np.array_equal(r['query_other_R7'],np.sort(expected,axis=1)[:,6]),'seventhother excludesactualself independentofFITradius')
    require(r['score'][0]==0 and ratio(np.array([0.,1.,0.]),np.array([0.,0.,1.])).tolist()==[0.,1.,0.],'allnaturalzero conventions exact')
    return dict(synthetic_only=True,realtraffic=0,query_other7_selfexcluded=True,no_reference_radius_or_queryfine=True,naturalzero_noepsilon=True)
