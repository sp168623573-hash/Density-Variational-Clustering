"""Owned NSL1 5999/6000 -> N117/Z149 bridge. No reads or forwards on import."""
from pathlib import Path
import hashlib,importlib.util,io,json,sys
import numpy as np
H=Path(__file__).resolve().parent
MANIFEST=H/'INPUT_MANIFEST_DRAFT_V1060.json'

def require(x,message):
    if not bool(x):raise ValueError(message)
def descriptor(path):
    p=Path(path);return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def raw(reference):
    data=Path(reference['path']).read_bytes();require(hashlib.sha256(data).hexdigest()==reference['sha256'],'frozen bytes changed');return data
def js(reference):return json.loads(raw(reference).decode('utf-8-sig'))
def manifest():return json.loads(MANIFEST.read_text(encoding='utf-8'))
def arrays(reference,keys):
    require(keys and isinstance(keys,(list,tuple)),'explicit array whitelist')
    with np.load(io.BytesIO(raw(reference)),allow_pickle=False)as a:return{k:a[k]for k in keys}
def module(reference,tag):
    raw(reference);name=tag+'_'+reference['sha256']
    if name not in sys.modules:
        sp=importlib.util.spec_from_file_location(name,reference['path']);m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m)
    return sys.modules[name]

def load_source():
    m=manifest();p=arrays(m['source_plan'],('ids','groups','canonical_fine','reordered117','representatives','permutation117','logical6000_ids','all_actual_fine_memberships'))
    f=arrays(m['known149_frame'],('fit_ids','fit_groups','fit_fine','fit_Z149'));r=p['representatives'];perm=p['permutation117']
    require(len(p['ids'])==5999 and len(f['fit_ids'])==6000 and len(np.unique(r))==5999 and r.min()>=0 and r.max()<6000,'exact genuine/registered logical source bridge')
    require(np.array_equal(p['ids'],f['fit_ids'][r])and np.array_equal(p['groups'],f['fit_groups'][r])and np.array_equal(p['canonical_fine'],f['fit_fine'][r]),'original source representative identity/fine alignment')
    require(np.array_equal(np.sort(perm),np.arange(117))and np.array_equal(p['reordered117'],f['fit_Z149'][r,32:][:,perm]),'original149 BACK117 permutation, no new codec')
    require(np.array_equal(p['logical6000_ids'],f['fit_ids']),'provided logical roster, no invented optimizer rows')
    index={str(g):i for i,g in enumerate(p['groups'])};back=np.asarray([index[str(g)]for g in f['fit_groups']],np.int64)
    require(np.all(p['all_actual_fine_memberships'][back,f['fit_fine']]),'logical fine aliases must be original registered memberships')
    roles=js(m['source_roles'])['roles'];role_indices={}
    for name in('R','V','Qcal','Qaudit'):
        value=roles[name];at=np.asarray(value['indices'],np.int64)
        require(np.array_equal(p['ids'][at],value['ids'])and np.array_equal(p['groups'][at],value['groups']),'exact source role IDs/groups: '+name);role_indices[name]=at
    require([len(role_indices[k])for k in('R','V','Qcal','Qaudit')]==[3595,1197,602,605]and len(np.unique(np.concatenate(list(role_indices.values()))))==5999,'source roles exact disjoint partition')
    return dict(ids=p['ids'],groups=p['groups'],fine=p['canonical_fine'],N=p['reordered117'],Z=f['fit_Z149'][r],roles=role_indices,
                logical_to_genuine=back,logical_original_fine=f['fit_fine'],permutation117=perm,
                fine_alias_rows=int(np.sum(p['canonical_fine'][back]!=f['fit_fine'])),NN_forward_calls=0)

def retained_R(source,held=None):
    R=source['roles']['R'];R=R if held is None else R[source['fine'][R]!=held]
    local=np.full(len(source['ids']),-1,np.int64);local[R]=np.arange(len(R));slots=local[source['logical_to_genuine']];slots=slots[slots>=0]
    require(len(R)<=len(slots)and len(slots)+600<=6000 and all(np.sum(source['fine'][R][slots]==f)>=20 for f in np.unique(source['fine'][R])),'provided real FIT map and family floor20 within6000 including600 virtual views')
    return R,slots

def load_role(role):
    m=manifest();require(role in('CAL','CP','current'),'declared role');cfg=m['roles'][role];mapping=cfg['frame_fields'];a=arrays(cfg['frame'],tuple(mapping.values()));q={k:a[v]for k,v in mapping.items()}
    parent=arrays(cfg['parent_prediction'],('ids','prediction','density'));seal=js(cfg['parent_seal'])
    require(seal['prediction']==cfg['parent_prediction']and seal['query_truth_used']is False and np.array_equal(q['ids'],parent['ids'])and len(q['ids'])==cfg['rows'],'accepted complete2864 prediction, IDs and original context')
    perm=arrays(m['source_plan'],('permutation117',))['permutation117'];N=q['Z149'][:,32:][:,perm]
    require(q['Z149'].shape==(cfg['rows'],149)and N.shape==(cfg['rows'],117)and np.isfinite(N).all(),'whole original149 role; no readout')
    return dict(q,N=N,Z=q['Z149'],parent_prediction=parent['prediction'],parent_density=parent['density'],role=role,query_truth_reads=0)

def load_known_labels(role):
    require(role in('CAL','CP'),'current truth has separate postseal ROOT authority');cfg=manifest()['roles'][role]['label_authority'];v=arrays(cfg['asset'],(cfg['ids_key'],cfg['truth_key']))
    return dict(ids=v[cfg['ids_key']],truth=v[cfg['truth_key']])

def original149_route(query,context,sink):
    """Same registered149 API; no query truth fields or new metric fitting."""
    m=manifest();sys.path.insert(0,m['original_project_root'])
    from paper_open_set import nsl1_complete_frequency_negative_soft149_v716c as old
    metric=old.nsl.learned.PaperVariationalPairMetric.from_state(js(m['original_metric149']))
    require(metric.dimension==149,'never substitute failed R960 M115')
    return old.nsl.base.route_once(metric,dict(ids=query['ids'],groups=query['groups'],Z149=query['Z'],stage1=query['stage1']),np.asarray(context,bool),sink)
