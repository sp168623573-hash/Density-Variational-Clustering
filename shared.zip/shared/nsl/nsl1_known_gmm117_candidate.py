"""Fixed known-only multivariate density candidate beside immutable NSL1 2601.

The new cue is class-conditional mixture density in a FIT-only PCA of all117
encoded native41 coordinates. Frozen MAIN classification and learned149 DVC
remain unchanged. Only the known prefix is decoded before its zero-loss gate.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import numpy as np
from scipy.special import logsumexp
from sklearn.decomposition import PCA
from sklearn.mixture import GaussianMixture
from threadpoolctl import threadpool_limits

from . import nsl1_expanded_fit6000_all41_v2 as producer
from . import nsl1_projected149_entropy_joint_v2 as previous
from . import nsl1_typedmask_predictive_hint_v1 as typed
from .paired_integer_gate_status_v1 import gate_status

ROOT, files = previous.ROOT, previous.files
BASE = ROOT/'data/external_dev/processed/nsl1_known_gmm117_candidate_20261011_v47'
REGISTRY = ROOT/'tmp/nsl1_known_gmm117_candidate_20261011_v47/registry_before_known_GMM_fit.json'
SCHEMA = 'NSL1-preserved2601-FIT-only-classconditional-GMM117-v47'
GEOMETRY_REGISTRY = ROOT/'tmp/nsl1_projected149_entropy_joint_20261010_v2/registry_before_actual_prefix_entropy_known_gate.json'


def recipe():
    return dict(schema_version=SCHEMA, setting='NSL-KDD Setting1', FIT_original_cap=6000,
        input='all117 frozen encoded native41 coordinates; unique original FIT IDs, no report copies',
        projection='FIT6000-only centered PCA16, full solver, whitened by FIT eigenvalues; complete117 input',
        density='one true-known-fine GaussianMixture per each of nine classes; full covariance',
        components='min(9,max(1,floor(trueFITclass_count/20)))', seed=20261011,
        GMM=dict(covariance_type='full', reg_covar=.001, n_init=1, max_iter=200, tol=.001, init_params='kmeans'),
        score='predicted-MAIN-fine negative log mixture density, centered by trueFITclass median and divided by trueFITclass IQR; zero IQR uses1',
        calibration='one knownCAL656 predicted-MAIN-coarse finite99 strictgreater cutoff',
        consistency='candidate only where MAIN fine0 agrees coarse0 or fine1..8 agrees coarse1',
        classifier='frozen MAIN35e coarse/fine cached values; no classification replacement',
        DVC='same frozen learned149 coordinates, metric, candidate-centre-secondary affinity and noise',
        merge='copy full retained2601 predictions; only own raw and DVC-retained become UNA',
        known_gate='same actual current654 prefix; BEN/KNA integer99 and zero correct paired loss before any unknown query numeric decode',
        query_or_CAL_density_fit=False, unknown_label_fit=False, unknown_query_before_known_gate=False,
        neural_training=0, CUDA_use=False, CPU_threads=2, formula_count=1, parameter_grid=False,
        exact_original_paper_density_formula_claim=False, accepted_baseline_replaced=False,
        current_scope='already observed original3598 development IDs; no independent final assertion',
        status='FAIL_TARGET99', published=False, final_test_executed=False)


def freeze():
    pins = {}
    material = files.js(producer.REUSABLE_MATERIAL, pins)
    # The exact saved geometry registration is itself pinned before array decode.
    geometry_asset = files.item(GEOMETRY_REGISTRY)
    geometry = files.js(geometry_asset, pins)
    unsigned = dict(geometry); signature = unsigned.pop('registry_sha256')
    files.require(signature == files.digest(unsigned), 'saved projected149 registry signature')
    old = files.js(typed.BASELINE, pins)
    files.require(material['FIT_original'] == 6000 and material['input_width'] == 117
        and material['preprocessor_fit_roles'] == ['fit'] and material['unknown_numeric_decodes'] == 0
        and old['original_class_gates']['BEN']['correct'] == 317
        and old['original_class_gates']['KNA']['correct'] == 335
        and old['original_class_gates']['UNA']['correct'] == 2601,
        'genuine reusable knownFIT6000 and immutable complete2601 baseline')
    assets = dict(encoded=material['encoded_inputs'], encoder=material['encoder'],
        prepared=geometry['assets']['prepared_material'], query_geometry=geometry['assets']['query_geometry'],
        main_known=geometry['assets']['main_known'], main_current=geometry['assets']['main_current'],
        metric=geometry['assets']['metric'], baseline=old['files']['postseal_comparison'])
    headers = {n:producer.metadata_headers(a,pins) for n,a in assets.items() if Path(a['path']).suffix == '.npz'}
    files.require(headers['encoded']['fit_features']['shape'] == [6000,117]
        and headers['encoded']['calibration_features']['shape'] == [656,117]
        and headers['encoded']['open_known_features']['shape'] == [654,117]
        and headers['prepared']['fit_Z149']['shape'] == [6000,149]
        and headers['query_geometry']['Z149']['shape'] == [3598,149]
        and headers['baseline']['prediction']['shape'] == [3598], 'explicit saved member headers')
    for a in assets.values(): files.read(a,pins)
    modules = (producer, previous, previous.projected, previous.learned,
        previous.projected.vanilla, previous.projected.owned_dvc, previous.paper_route, files)
    sources = {Path(m.__file__).name:files.item(m.__file__) for m in modules}
    sources['caller'] = files.item(__file__)
    reg = dict(schema_version=SCHEMA+'-registry', policy=recipe(), assets=assets, sources=sources,
        material_report=producer.REUSABLE_MATERIAL, baseline_report=typed.BASELINE,
        geometry_registry=geometry_asset, headers=headers,
        material_descriptors=geometry['material_descriptors'],
        metric_state_sha256=previous.METRIC_STATE_SHA,
        fine_order=list(producer.FAMILIES), output={p:str(BASE/p) for p in ('known','current')},
        input_sha256=pins, numeric_array_decodes=0, status='FAIL_TARGET99', published=False, final_test_executed=False)
    reg['registry_sha256'] = files.digest(reg)
    REGISTRY.parent.mkdir(exist_ok=True)
    files.require(not REGISTRY.exists(), 'fresh once-only V47 registration')
    return files.write(REGISTRY,reg)


def bind(path,sha,pins):
    ref = dict(path=str(Path(path).resolve()),sha256=sha); reg = files.js(ref,pins)
    unsigned = dict(reg); signature = unsigned.pop('registry_sha256')
    files.require(signature == files.digest(unsigned) and reg['policy'] == recipe()
        and reg['sources']['caller'] == files.item(__file__), 'one sealed V47 source and recipe')
    for a in reg['sources'].values(): files.read(a,pins)
    for p,h in reg['input_sha256'].items(): files.read(dict(path=p,sha256=h),pins)
    return ref,reg


def save(out,report,name,value):
    return previous.save(out,report,name,value)


def project(state,x):
    x = np.asarray(x,np.float64)
    files.require(x.ndim == 2 and x.shape[1] == 117 and np.isfinite(x).all(), 'complete finite encoded117')
    return ((x-state['pca_mean']) @ state['pca_components'].T)/state['pca_whiten_scale']


def negative_density(state,z,label):
    means, chol, weights = (state['fine'+str(label)+'_'+n] for n in ('means','precision_cholesky','weights'))
    terms = np.empty((len(z),len(weights)),np.float64)
    for k in range(len(weights)):
        residual = (z-means[k]) @ chol[k]
        terms[:,k] = np.log(weights[k])+np.log(np.diag(chol[k])).sum()-.5*(16*np.log(2*np.pi)+np.square(residual).sum(axis=1))
    return -logsumexp(terms,axis=1)


def fit_density(x,y):
    files.require(x.shape == (6000,117) and y.shape == (6000,) and set(y.tolist()) == set(range(9)), 'trueknownFIT6000 allnine support')
    fit = np.asarray(x,np.float64)
    pca = PCA(n_components=16,svd_solver='full',whiten=True).fit(fit)
    state = dict(pca_mean=pca.mean_,pca_components=pca.components_,pca_whiten_scale=np.sqrt(pca.explained_variance_))
    files.require(np.all(state['pca_whiten_scale'] > 0), 'positive FIT-only PCA16 axes')
    z = project(state,fit); summaries = {}
    state['density_units'] = np.empty((9,2),np.float64)
    for label in range(9):
        rows = z[y == label]; n = len(rows); k = min(9,max(1,n//20))
        gm = GaussianMixture(n_components=k,covariance_type='full',reg_covar=.001,n_init=1,
            max_iter=200,tol=.001,init_params='kmeans',random_state=20261011+label).fit(rows)
        files.require(gm.converged_, 'fixed class GMM converged:'+str(label))
        for name,v in (('means',gm.means_),('precision_cholesky',gm.precisions_cholesky_),('weights',gm.weights_),('covariances',gm.covariances_)):
            state['fine'+str(label)+'_'+name] = v.copy()
        nll = negative_density(state,rows,label)
        q25,median,q75 = np.quantile(nll,[.25,.5,.75]); width = q75-q25
        state['density_units'][label] = (median,width if width > 0 else 1.)
        summaries[str(label)] = dict(trueFIT_rows=n,components=k,converged=bool(gm.converged_),iterations=int(gm.n_iter_),
            lower_bound=float(gm.lower_bound_),median=float(median),IQR=float(width),zero_IQR_unit1=bool(width == 0))
    return state,summaries


def score(state,x,fine,coarse):
    z = project(state,x); fine = np.asarray(fine); coarse = np.asarray(coarse)
    files.require(fine.shape == coarse.shape == (len(z),) and np.isin(fine,range(9)).all()
        and np.isin(coarse,(0,1)).all(), 'original MAIN fine/coarse labels only')
    nll = np.empty(len(z),np.float64)
    for label in range(9):
        rows = fine == label
        if rows.any(): nll[rows] = negative_density(state,z[rows],label)
    normalized = (nll-state['density_units'][fine,0])/state['density_units'][fine,1]
    consistent = ((fine == 0)&(coarse == 0))|((fine > 0)&(coarse == 1))
    files.require(np.isfinite(normalized).all(), 'finite fixed classconditional density score')
    return dict(score=normalized,negative_log_density=nll,coarse_fine_consistent=consistent)


def run(phase,path,sha,known_path=None,known_sha=None):
    started,pins = time.perf_counter(),{}
    ref,reg = bind(path,sha,pins)
    if phase == 'current':
        kref = dict(path=str(Path(known_path).resolve()),sha256=known_sha); kr = files.js(kref,pins)
        files.require(kref['path'] == str(BASE/'known/report.json') and kr['registry'] == ref
            and kr['known_gate_passed'] is True and kr['unknown_query_numeric_rows_decoded'] == 0,
            'new known654 exact integer99 zero correct-loss gate before full cached query')
    out = Path(reg['output'][phase]); files.require(not out.exists(), 'fresh once-only V47 phase'); out.mkdir(parents=True)
    report = dict(schema_version=SCHEMA,phase=phase,registry=ref,policy=recipe(),files={},
        counts=dict(density_fit=0,PCA_fit=0,CAL_fit=0,query_score=0,DVC=0,NN_training=0,NN_forward=0,metric_fit=0),
        prediction_sealed=False,known_truth_opened=False,unknown_truth_opened=False,
        unknown_query_numeric_rows_decoded=0,accepted_baseline_replaced=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        prepared = previous.archive(reg['assets']['prepared'],tuple(reg['material_descriptors']),pins)
        files.require({k:previous.descriptor(v) for k,v in prepared.items()} == reg['material_descriptors'], 'same frozen genuine149 known geometry')
        if phase == 'known':
            encoded = previous.archive(reg['assets']['encoded'],('fit_features','fit_known_fine','fit_ids','calibration_features','calibration_ids','open_known_features','open_known_ids'),pins)
            files.require(len(set(encoded['fit_ids'].tolist())) == 6000
                and np.array_equal(encoded['fit_ids'],prepared['fit_ids'])
                and np.array_equal(encoded['fit_known_fine'],prepared['fit_fine'])
                and np.array_equal(encoded['fit_features'],prepared['fit_Z149'][:,32:]), 'true known FIT rows and all117 coordinate identity')
            for role in ('calibration','open_known'):
                files.require(np.array_equal(encoded[role+'_ids'],prepared[role+'_ids'])
                    and np.array_equal(encoded[role+'_features'],prepared[role+'_Z149'][:,32:]), 'immutable heldout all117 identity:'+role)
            # Exact current654 prefix is used; the unknown geometry tail stays opaque.
            query = previous.prefix_archive(reg['assets']['query_geometry'],('ids','groups','Z149','stage1','predicted_fine'),654,pins)
            files.require(np.array_equal(query['ids'],prepared['open_known_ids'])
                and np.array_equal(query['Z149'],prepared['open_known_Z149'])
                and np.array_equal(query['groups'],prepared['open_known_groups'])
                and np.array_equal(query['stage1'],prepared['open_known_stage1'])
                and np.array_equal(query['predicted_fine'],prepared['open_known_predicted_fine']), 'actual currentknown654 exact input context')
            main = previous.archive(reg['assets']['main_known'],('calibration_ids','calibration_fine_probability','calibration_predicted_coarse'),pins)
            files.require(np.array_equal(main['calibration_ids'],prepared['calibration_ids'])
                and np.array_equal(main['calibration_fine_probability'].argmax(axis=1),prepared['calibration_predicted_fine'])
                and np.array_equal(main['calibration_predicted_coarse'],prepared['calibration_stage1']), 'frozen original MAIN CAL predictions')
            with threadpool_limits(limits=2): state,summaries = fit_density(encoded['fit_features'],encoded['fit_known_fine'])
            report['counts'].update(density_fit=9,PCA_fit=1)
            sa = save(out,report,'FIT_only_PCA16_truefine_GMM_state_before_CAL',state)
            report['files']['density_state'] = sa
            report['density_fit_summary'] = summaries; report['FIT_original_rows'] = 6000; report['FIT_copies'] = 0
            report['files']['FIT_state_seal'] = files.write(out/'FIT_only_density_seal_before_CAL.json',dict(state=sa,registry=ref,query_used=False,CAL_used=False,unknown_used=False))
            cal = score(state,encoded['calibration_features'],prepared['calibration_predicted_fine'],prepared['calibration_stage1'])
            save(out,report,'CAL656_density_scores_before_cutoffs',dict(**cal,stage1=prepared['calibration_stage1']))
            cut = previous.paper_route.calibrate_known_cutoffs(cal['score'],prepared['calibration_stage1'])
            report['files']['calibration'] = files.write(out/'knownCAL656_density_cutoffs_before_known654.json',dict(cutoffs=cut,query_used=False,original_CAL_rows=656,registry=ref,density_state=sa))
            report['counts']['CAL_fit'] = 1
            save(out,report,'actual_current_known654_geometry_before_score',query)
        else:
            query = previous.archive(reg['assets']['query_geometry'],('ids','groups','Z149','stage1','predicted_fine'),pins)
            report['unknown_query_numeric_rows_decoded'] = 2944
            saved = previous.archive(kr['files']['actual_current_known654_geometry_before_score'],('ids','groups','Z149','stage1','predicted_fine'),pins)
            files.require(query['Z149'].shape == (3598,149) and len(set(query['ids'].tolist())) == 3598
                and all(np.array_equal(query[k][:654],saved[k]) for k in saved), 'exact current3598 ID/order and actual known-prefix equality')
            state = previous.archive(kr['files']['density_state'],tuple(kr['density_state_members']),pins)
            report['files']['density_state'] = kr['files']['density_state']; report['known_report'] = kref
            cut = files.js(kr['files']['calibration'],pins)['cutoffs']; report['files']['calibration'] = kr['files']['calibration']
            save(out,report,'actual_current3598_geometry_before_score',query)
        report['density_state_members'] = list(state)
        live = score(state,query['Z149'][:,32:],query['predicted_fine'],query['stage1'])
        raw = previous.paper_route.candidate_mask(live['score'],query['stage1'],cut)&live['coarse_fine_consistent']
        report['counts']['query_score'] = 1
        save(out,report,'new_classconditional_density_before_DVC',dict(**live,raw=raw,stage1=query['stage1'],predicted_fine=query['predicted_fine']))
        metric = previous.load_metric(reg,pins)
        def sink(name,value,manifest):
            save(out,report,name+'_DVC_result',value)
            report['files'][name+'_DVC_manifest'] = files.write(out/(name+'_DVC_manifest.json'),manifest)
        report['counts']['DVC'] = 1; route,_ = previous.route_once(metric,query,raw,sink)
        if phase == 'known':
            baseline = previous.prefix_archive(reg['assets']['baseline'],('prediction',),654,pins)['prediction']
        else:
            baseline = previous.archive(reg['assets']['baseline'],('prediction',),pins)['prediction']
        pred = previous.merge(baseline,raw,route['retained'])
        pa = save(out,report,'prediction_before_truth',dict(ids=query['ids'],prediction=pred,baseline=baseline,raw=raw,retained=route['retained']))
        report['files']['prediction_seal'] = files.write(out/'prediction_seal_before_truth.json',dict(prediction=pa,registry=ref,metric=reg['assets']['metric'],density_state=report['files']['density_state'],CAL=report['files']['calibration'],truth_opened=False))
        report['prediction_sealed'] = True
        if phase == 'known':
            truth = previous.prefix_archive(reg['assets']['baseline'],('ids','truth'),654,pins)
        else:
            truth = previous.archive(reg['assets']['baseline'],('ids','truth'),pins); report['unknown_truth_opened'] = True
        report['known_truth_opened'] = True
        files.require(np.array_equal(truth['ids'],query['ids']), 'same original query truth custody after prediction seal')
        effect,gates,prior = previous.delta(truth['truth'],pred,baseline,full=phase == 'current')
        save(out,report,'postseal_comparison',dict(**truth,prediction=pred,baseline=baseline,raw=raw,retained=route['retained']))
        zero_loss = all(effect['gain_loss'][name]['loss'] == 0 for name in ('BEN','KNA'))
        report.update(execution_status='classconditional_GMM117_'+phase+'_evaluated',original_class_gates=gates,
            baseline_class_gates=prior,EffectDelta=effect,paired_known_no_loss=zero_loss,
            known_gate_passed=zero_loss and all(gates[n]['passed'] for n in ('BEN','KNA')),
            all_three_integer99_passed=phase == 'current' and all(v['passed'] for v in gates.values()),
            DEV_review_eligible=phase == 'current' and effect['verdict'] == 'UP' and zero_loss,
            known_raw=int(raw[:654].sum()),known_retained=int(route['retained'][:654].sum()),
            unknown_raw=int(raw[654:].sum()),unknown_retained=int(route['retained'][654:].sum()),
            metric_state_sha256=metric.state_sha256,baseline_UNA_predictions_preserved=True,
            primary_classification_unchanged=True)
        report['explicit_gate_status'] = gate_status(gates,{n:effect['gain_loss'][n]['loss'] for n in ('BEN','KNA')})
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error)); raise
    finally:
        for p,h in pins.items(): files.require(files.item(p)['sha256'] == h, 'all V47 frozen input/source bytes unchanged')
        report['input_sha256'] = pins; report['wall_seconds'] = time.perf_counter()-started
        files.write(out/'report.json',report)
    return files.item(out/'report.json')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for name in ('registry','registry-sha256','known-report','known-sha256'): p.add_argument('--'+name)
    a = p.parse_args()
    print(json.dumps(freeze() if a.phase == 'freeze' else run(a.phase,a.registry,a.registry_sha256,a.known_report,a.known_sha256)))
