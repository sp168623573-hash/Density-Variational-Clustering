"""Known-only expanded FIT6000 auxiliary MHFD with preserved heldout roles.

The original2579/2596 classifier pipelines are never modified. V2 reuses the externally sealed V1 all41 material without encoding replay
and trains one fresh final80 model. V1 failed outputs stay unchanged. No unknown
feature archive is opened, and heldout OPEN labels are read after its seal.
Training time is recorded, never used as a programmed stopping criterion.
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import io
import json
import os
from pathlib import Path
import time
import zipfile

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler

from . import config, model
from . import nsl1_all_native41_material_v1 as old_material
from . import nsl1_all_native41_known80_v1 as old_training
from . import nsl2_clean_known_material_training_v1 as output_io

files, ROOT = old_material.files, old_material.ROOT
BASE = ROOT/'data/external_dev/processed/nsl1_expanded_FIT6000_all41_20261009_v2'
SCHEMA = 'NSL1-expanded-FIT6000-original-all41-MHFD-final80-v2'
ROLES = dict(fit=6000,checkpoint=656,calibration=656,open_known=654)
FAMILIES = ('BEN',*config.get_spec('NSL-KDD Setting1').known_families)
EPOCHS, SEED = 80, 20261009
OLD = dict(path=str(ROOT/'data/external_dev/processed/nsl1_all_native41_material_20261009_v1/report.json'),sha256='35f0839ac457d46d05345131a3ae2afe676807d7c8f5b56163476522cda09e87')
ADDITIONS = dict(path=str(ROOT/'data/external_dev/processed/NSL_FIT_additions6000_20261009_v1/report.json'),sha256='1204960e84e6ca05c5edb4f64478b83904ede1995a9c602a0e554d9eb29f0f7b')
PROTOCOL = dict(path=str(ROOT/'tmp/currentdata_expansion_budget_20261009_v1/four_setting_expansion_protocol_v2.json'),sha256='6c53b19221d8221b066a6eba96d8026b047c43aac8bac93d957029c274b93cdc')
RAW_FIELDS = {'coarse_logits','fine_logits','embedding','reconstruction','gate_mean'}
REUSABLE_MATERIAL = dict(path=str(ROOT/'data/external_dev/processed/nsl1_expanded_FIT6000_all41_20261009_v1/material/report.json'),
    sha256='4acff85b7a4ef7fe8e9f2832c69f439d2bdf69b2e779ddd4fa64f39490e4f468')
REUSABLE_MATERIAL_REGISTRY = dict(path=str(ROOT/'tmp/nsl1_expanded_FIT6000_all41_20261009_v1/registry_before_material_and_training.json'),
    sha256='effea814ab1d82121d43c449f37a95ef93b0c65c1ebbc08225c23ba2632f43bc')
PRESERVED_V1_SOURCE = dict(path=str(ROOT/'paper_open_set/nsl1_expanded_fit6000_all41_v1.py'),
    sha256='97b08db2c83cae19809c59bcc8f78e450168a69a8b8a8518777df92851445f80')


def archive(asset,keys,pins):
    with np.load(io.BytesIO(files.read(asset,pins)),allow_pickle=False) as z:
        return {key:z[key].copy() for key in keys}


def save(out,name,values,report):
    path=out/(name+'.npz')
    with path.open('xb') as stream:
        np.savez_compressed(stream,**values)
    asset=files.item(path);report['files'][name]=asset
    return asset


def recipe():
    return dict(schema_version=SCHEMA,setting='NSL-KDD Setting1',classes=list(FAMILIES),
        FIT_original=6000,FIT_optimizer=6000,FIT_copies=0,roles=ROLES,
        encoder='new unique knownFIT log1p/RMS; complete all41, full FIT categorical vocabulary+UNSEEN; no feature pruning',
        model='unchanged MHFDNetwork attention/gate/position/CNN/BiLSTM/known heads/decoder',
        loss='coarseCE + .35 fineCE(smoothing.01) + .03 cleanSmoothL1',
        optimizer='AdamW .001 wd.0002 cosine80 min.0001 clip5',
        epochs=EPOCHS,batch_size=128,seed=SEED,CPU_threads=4,
        checkpoint='final80; no per-epoch heldout scoring',
        CAL='one calibration656 threshold, sealed before OPEN654',
        auxiliary_candidate_only=True,prior2579_and2596_unchanged=True,
        unknown_training_or_feature_reads=False,old_weights_transferred=False,
        independent_final_admitted=False,published=False,final_test_executed=False,status='FAIL_TARGET99')


def metadata_headers(asset,pins):
    """Opaque byte pin plus NPY headers; never decode numerical members."""
    result={}
    with zipfile.ZipFile(io.BytesIO(files.read(asset,pins))) as archive:
        for name in archive.namelist():
            files.require(name.endswith('.npy') and '/' not in name,'closed NPY member')
            with archive.open(name) as stream:
                version=np.lib.format.read_magic(stream)
                shape,fortran,dtype=np.lib.format._read_array_header(stream,version)
                files.require(not dtype.hasobject,'no pickled NPY member')
                result[name[:-4]]=dict(shape=list(shape),dtype=dtype.str,fortran_order=fortran)
    return result


def require_reusable_material(asset,mat,reg):
    files.require(asset==reg['reusable_material']['report']
        and mat['registry']==reg['reusable_material']['material_registry']
        and mat['execution_status']=='expandedFIT6000_all41_known_material_encoded'
        and mat['FIT_original']==6000 and mat['heldout_rows']==1966
        and mat['total_known_material_rows']==7966 and mat['preprocessor_fit_roles']==['fit']
        and mat['unknown_numeric_decodes']==mat['model_fit']==mat['inference']==0
        and mat['original_FIT_prefix4034_preserved'] is True
        and mat['original_holdout_values_and_IDs_preserved'] is True,
        'exact reusable external V1 material and its original registry')


def freeze():
    pins={};mat=files.js(REUSABLE_MATERIAL,pins);old_reg=files.js(REUSABLE_MATERIAL_REGISTRY,pins)
    unsigned=dict(old_reg);signature=unsigned.pop('registry_sha256')
    files.require(signature==files.digest(unsigned) and old_reg['sources']['caller']==PRESERVED_V1_SOURCE,
        'preserved original material registration and producer source')
    files.read(PRESERVED_V1_SOURCE,pins)
    files.require({k:v for k,v in old_reg['policy'].items() if k!='schema_version'}
        =={k:v for k,v in recipe().items() if k!='schema_version'},'unchanged numeric80 training recipe')
    protocol=files.js(PROTOCOL,pins)
    files.require(protocol['test_total_cap'] is None and protocol['actual_FIT_optimizer_cap']==6000,
        'latest user training budget and immutable heldouts')
    reusable=dict(report=REUSABLE_MATERIAL,material_registry=REUSABLE_MATERIAL_REGISTRY,
        producer_source=PRESERVED_V1_SOURCE,preprocessor_replay=False)
    require_reusable_material(REUSABLE_MATERIAL,mat,dict(reusable_material=reusable))
    for path,wanted in mat['input_sha256'].items(): files.read(dict(path=path,sha256=wanted),pins)
    for name in ('encoded_inputs','known_source','encoder'): files.read(mat[name],pins)
    headers=metadata_headers(mat['encoded_inputs'],pins)
    native_headers=metadata_headers(mat['known_source'],pins)
    for role,n in ROLES.items():
        files.require(headers[role+'_features']['shape']==[n,mat['input_width']]
            and native_headers[role+'_native41']['shape']==[n,41]
            and headers[role+'_ids']==native_headers[role+'_ids'], 'reused role/header contract:'+role)
    encoder=files.js(mat['encoder'],pins)
    files.require(encoder['input_width']==mat['input_width']==117
        and len(encoder['fields'])==41, 'actual reused all41 width117, not guessed115')
    reg=dict(schema_version=SCHEMA+'-registry',policy=recipe(),assets=old_reg['assets'],
        reusable_material=reusable,material_headers=headers,native_headers=native_headers,
        input_width=mat['input_width'],protocol=PROTOCOL,
        sources={Path(module.__file__).name:files.item(module.__file__) for module in
            (old_material,old_training,model,config,output_io,files)},
        outputs=dict(train=str(BASE/'train')),input_sha256=pins,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    reg['sources']['caller']=files.item(__file__);reg['registry_sha256']=files.digest(reg)
    directory=ROOT/'tmp/nsl1_expanded_FIT6000_all41_20261009_v2';directory.mkdir(exist_ok=True)
    return files.write(directory/'registry_before_training_from_reusable_material.json',reg)


def bind(registry,sha,pins):
    reg=files.js(dict(path=str(Path(registry).resolve()),sha256=sha),pins)
    unsigned=dict(reg);signature=unsigned.pop('registry_sha256')
    files.require(signature==files.digest(unsigned) and reg['policy']==recipe()
        and reg['sources']['caller']==files.item(__file__),'frozen own expandedFIT contract')
    for asset in reg['sources'].values():files.read(asset,pins)
    return reg


def capture_runtime_flags():
    return dict(intraop_threads=torch.get_num_threads(),interop_threads=torch.get_num_interop_threads(),
        deterministic_algorithms=torch.are_deterministic_algorithms_enabled(),
        deterministic_warn_only=torch.is_deterministic_algorithms_warn_only_enabled(),
        cudnn_deterministic=torch.backends.cudnn.deterministic,cudnn_benchmark=torch.backends.cudnn.benchmark,
        cuda_matmul_allow_tf32=torch.backends.cuda.matmul.allow_tf32,
        cudnn_allow_tf32=torch.backends.cudnn.allow_tf32,
        float32_matmul_precision=torch.get_float32_matmul_precision(),
        CUBLAS_WORKSPACE_CONFIG=os.environ.get('CUBLAS_WORKSPACE_CONFIG'))


def restore_runtime_flags(before):
    torch.set_num_threads(before['intraop_threads'])
    torch.use_deterministic_algorithms(before['deterministic_algorithms'],warn_only=before['deterministic_warn_only'])
    torch.backends.cudnn.deterministic=before['cudnn_deterministic']
    torch.backends.cudnn.benchmark=before['cudnn_benchmark']
    torch.set_float32_matmul_precision(before['float32_matmul_precision'])
    torch.backends.cuda.matmul.allow_tf32=before['cuda_matmul_allow_tf32']
    torch.backends.cudnn.allow_tf32=before['cudnn_allow_tf32']
    if before['CUBLAS_WORKSPACE_CONFIG'] is None: os.environ.pop('CUBLAS_WORKSPACE_CONFIG',None)
    else: os.environ['CUBLAS_WORKSPACE_CONFIG']=before['CUBLAS_WORKSPACE_CONFIG']
    after=capture_runtime_flags()
    files.require(after==before,'complete deterministic/cuDNN/TF32/threads/environment restoration')
    return after


def save_epoch_history(out,history,epoch,report):
    files.require(type(epoch) is int and 1<=epoch<=EPOCHS and len(history)==epoch
        and history[-1]['epoch']==epoch,'completed actual epoch history')
    name='history_through_epoch'+format(epoch,'03d')
    asset=files.write(out/(name+'.json'),history)
    report['files'][name]=asset
    report['files']['history_latest']=asset
    return asset


def infer_once(net,x,role,out,report):
    captured=[];state=output_io.state_digest(net);flags={n:p.requires_grad for n,p in net.named_parameters()}
    def hook(module,args,output):
        value={name:part.detach().float().cpu().numpy().copy() for name,part in output.items()}
        save(out,role+'_raw5_batch'+str(len(captured))+'_before_caller_guard',value,report)
        captured.append(value)
    handle=net.register_forward_hook(hook);report['counts']['known_infer_attempts']+=1
    try:
        result=model.infer(net,x,device=next(net.parameters()).device,batch_size=2048)
        report['counts']['known_infer_returns']+=1
    finally:handle.remove()
    values={key:np.asarray(value).copy() for key,value in vars(result).items()}
    for key in RAW_FIELDS:values['raw_'+key]=np.concatenate([batch[key] for batch in captured])
    values['embedding32']=values['embedding'].copy()
    save(out,role+'_complete_all7_raw5_before_caller_guard',values,report)
    files.require(all(set(batch)==RAW_FIELDS for batch in captured) and len(captured)==(len(x)+2047)//2048
        and len(vars(result))==7 and all(len(v)==len(x) and np.isfinite(v).all() for v in values.values())
        and flags=={n:p.requires_grad for n,p in net.named_parameters()}
        and output_io.state_digest(net)==state,'complete frozen real known inference outputs')
    report['counts']['known_forward_batches']+=len(captured)
    return values


def train(registry,sha,material_report,material_sha):
    started=time.perf_counter();pins={};reg=bind(registry,sha,pins)
    ma=dict(path=str(Path(material_report).resolve()),sha256=material_sha);mat=files.js(ma,pins)
    require_reusable_material(ma,mat,reg)
    out=Path(reg['outputs']['train']);files.require(out==BASE/'train' and not out.exists(),'fresh once-only expandedFIT training');out.mkdir(parents=True)
    before_runtime=capture_runtime_flags();prior_threads=before_runtime['intraop_threads'];prior_env=before_runtime['CUBLAS_WORKSPACE_CONFIG']
    report=dict(schema_version=SCHEMA,registry=dict(path=str(Path(registry).resolve()),sha256=sha),material=ma,
        policy=recipe(),files={},counts=dict(training_runs=0,known_infer_attempts=0,known_infer_returns=0,known_forward_batches=0,unknown_forward=0),
        unknown_numeric_decodes=0,OPEN_truth_opened=False,accepted_baseline_replaced=False,
        published=False,final_test_executed=False,status='FAIL_TARGET99',input_width=mat['input_width'],runtime_before=before_runtime,preprocessor_replay=False)
    try:
        data=archive(mat['encoded_inputs'],tuple(role+'_'+key for role in ROLES for key in ('features','ids'))
            +tuple(role+'_'+key for role in ('fit','calibration') for key in ('known_fine','known_coarse')),pins)
        counts=Counter(data['fit_known_fine'].tolist())
        files.require(set(counts)==set(range(9)) and min(counts.values())>=20
            and data['fit_features'].shape==(6000,mat['input_width']),'all9 genuine training families and cap6000')
        report['files']['prefit']=files.write(out/'training_recipe_before_model_fit.json',dict(policy=recipe(),material=ma,
            input_width=mat['input_width'],optimizer_original_rows=6000,copies=0,
            runtime_environment=dict(CUBLAS_WORKSPACE_CONFIG=prior_env,torch_version=torch.__version__),
            old_model_transfer=False,unknown_and_OPEN_labels_used_in_fit=False))
        torch.set_num_threads(4);model.set_seed(SEED)
        report['runtime_during_training']=capture_runtime_flags()
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        net=model.MHFDNetwork(mat['input_width'],9).to(device)
        sampler=WeightedRandomSampler(model._hierarchical_sample_weights(data['fit_known_fine']),num_samples=6000,replacement=True,
            generator=torch.Generator().manual_seed(SEED))
        loader=DataLoader(TensorDataset(torch.from_numpy(data['fit_features']),torch.from_numpy(data['fit_known_coarse']),
            torch.from_numpy(data['fit_known_fine'])),batch_size=128,sampler=sampler,num_workers=0,pin_memory=device.type=='cuda')
        optimizer=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.0002)
        scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=80,eta_min=.0001)
        scaler=torch.amp.GradScaler('cuda',enabled=device.type=='cuda')
        cc=nn.CrossEntropyLoss();cf=nn.CrossEntropyLoss(label_smoothing=.01);cr=nn.SmoothL1Loss()
        history=[];training_start=time.perf_counter();report['counts']['training_runs']=1
        for epoch in range(1,81):
            net.train();total=0.;seen=0
            for xb,cb,fb in loader:
                xb,cb,fb=xb.to(device),cb.to(device),fb.to(device);optimizer.zero_grad(set_to_none=True)
                with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=device.type=='cuda'):
                    outputs=net(xb);loss=cc(outputs['coarse_logits'],cb)+.35*cf(outputs['fine_logits'],fb)+.03*cr(outputs['reconstruction'],xb)
                files.require(torch.isfinite(loss).item(),'finite actual expandedFIT loss')
                scaler.scale(loss).backward();scaler.unscale_(optimizer);nn.utils.clip_grad_norm_(net.parameters(),5.)
                scaler.step(optimizer);scaler.update();total+=float(loss.detach())*len(xb);seen+=len(xb)
            scheduler.step();history.append(dict(epoch=epoch,loss=total/seen,learning_rate=scheduler.get_last_lr()[0]))
            save_epoch_history(out,history,epoch,report)
            if epoch==1 or epoch%10==0:print(f'[NSL1 expanded FIT6000] epoch={epoch}/80 loss={total/seen:.6f} elapsed={time.perf_counter()-training_start:.1f}s',flush=True)
        report['files']['history']=files.write(out/'actual_history_completed_epochs.json',history)
        report.update(training_seconds=time.perf_counter()-training_start,epochs_completed=80,device=str(device))
        state=output_io.state_digest(net);checkpoint=out/'expanded_FIT6000_MHFD_all41_final80.pt'
        torch.save(dict(state_dict={n:p.detach().cpu() for n,p in net.state_dict().items()},input_dim=mat['input_width'],
            fine_classes=list(FAMILIES),epochs_completed=80,model_state_sha256=state,seed=SEED),checkpoint)
        report['files']['model']=files.item(checkpoint);report['model_state_sha256']=state;net.eval()
        outputs={role:infer_once(net,data[role+'_features'],role,out,report) for role in ('fit','checkpoint','calibration')}
        theta,metrics=model.choose_coarse_threshold(data['calibration_known_coarse'],outputs['calibration']['attack_probability'])
        report['files']['threshold']=files.write(out/'CAL656_threshold_sealed_before_OPEN654.json',dict(threshold=float(theta),
            CAL_IDs=old_training.array_descriptor(data['calibration_ids']),calibration_metrics=metrics,
            model=report['files']['model'],OPEN_truth_used=False))
        outputs['open_known']=infer_once(net,data['open_known_features'],'open_known',out,report)
        predictions={role+'_prediction':(values['attack_probability']>=theta).astype(np.int64) for role,values in outputs.items()}
        predictions.update({role+'_ids':data[role+'_ids'] for role in outputs})
        pa=save(out,'complete_known_predictions_before_OPEN_truth',predictions,report)
        report['files']['prediction_seal']=files.write(out/'known_predictions_sealed_before_OPEN_truth.json',dict(predictions=pa,
            model=report['files']['model'],threshold=report['files']['threshold'],OPEN_truth_opened=False))
        truth=archive(reg['assets']['original_encoded_labels'],('open_known_ids','open_known_known_coarse'),pins)
        report['OPEN_truth_opened']=True
        files.require(np.array_equal(truth['open_known_ids'],data['open_known_ids']),'fixed654 comparison IDs')
        gs={role:old_training.bridge_gates(data[role+'_known_coarse'],predictions[role+'_prediction']) for role in ('fit','calibration')}
        gs['open_known']=old_training.bridge_gates(truth['open_known_known_coarse'],predictions['open_known_prediction'])
        report.update(execution_status='expandedFIT6000_MHFD_final80_known_evaluated',coarse_threshold=float(theta),known_class_gates=gs,
            known654_passed=all(n['passed'] for n in gs['open_known'].values()),unknown_performance_measured=False,
            training_and_FIT_encoding_changes_joint=True,auxiliary_geometry_requires_new_known_only_metric_and_CAL=True)
        files.require(output_io.state_digest(net)==state,'weights unchanged during heldout inference')
        for path,wanted in pins.items():files.require(files.item(path)['sha256']==wanted,'training source/data unchanged')
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        restored_runtime=restore_runtime_flags(before_runtime)
        report['runtime_restoration']=dict(before=before_runtime,after=restored_runtime,
            all_flags_restored=restored_runtime==before_runtime,
            intraop_threads=torch.get_num_threads(),CUBLAS_WORKSPACE_CONFIG=os.environ.get('CUBLAS_WORKSPACE_CONFIG'),
            unchanged_environment=os.environ.get('CUBLAS_WORKSPACE_CONFIG')==prior_env)
        report['wall_seconds']=time.perf_counter()-started;report['input_sha256']=pins;files.write(out/'report.json',report)
    return files.item(out/'report.json')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=('freeze','train'),required=True)
    parser.add_argument('--registry');parser.add_argument('--registry-sha256')
    parser.add_argument('--material-report');parser.add_argument('--material-sha256')
    args=parser.parse_args()
    result=freeze() if args.phase=='freeze' else train(args.registry,args.registry_sha256,args.material_report,args.material_sha256)
    print(json.dumps(result))
