"""New whole117 physical cue; unchanged owned149 paper DVC; whole2844 preserved."""
import argparse,json,sys,time,types
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from . import nsl1_native117_query7_soft_core_v178 as core
from . import nsl1_query7_contrast149_v164 as previous
ROOT,files,require=previous.ROOT,previous.files,previous.require
old,nsl=previous.old,previous.nsl;MODULE='paper_open_set.nsl1_native117_query7_soft149_v178'
DIR=ROOT/'tmp/nsl1_native117_query7_soft149_20261013_v178';BASE=ROOT/'data/external_dev/processed/nsl1_native117_query7_soft149_20261013_v178';REG=DIR/'registry_before_known.json'
def policy():
    return dict(schema_version='NSL1-completephysical117-query7-plus-fixednegativegraph-original149-v178',hypotheses=1,
        source='actualV62 Z149=wholemasked32/RMS+completeoriginalencoded117; nativeview=all149[:,32:] no newscaling/fieldpruning',
        auxiliary='SciPy Euclidean117 nearestall5999genuineknownFIT d vs wholeownrole canonicalother7 q, d²/(d²+q²) naturalbothzero0; not paperEq9/10 metric',
        CAL='all656trueknown originalCAL oncefinite99 nativecontrast pertruecoarse; sameoriginalstage1 candidates everyrole, not queryfine/targetUID/heldfamily',
        corroboration='same newnativecontrast raw function allCAL/CP/current with allrawfalsepositives included; canonical ORcollapse once no copyamplification; all5999real knownanchors0 onlyanchorsfixed; 7 exactnearest anchor+query selfexcluded, Gaussian sigma7, stableanchorfirstties, 20 synchronous .9P*s+.1*initial, no hardquery/rawclamp',
        support='strict>fixedengineeringfloor.5 only, no secondgraph CALcut fitting/targetselection; support not unknownprobability',
        candidate='nativecontrast strict>onceknownCALcut AND negativesoftsupport>.5 AND whole2844baseline!=2',
        DVC='newraw OR allwhole2844pred2 includingerrors in unchanged149 originaldensityaffinity/reconstruction/localdensity/secondarynoise; wholeold2protected',
        BEN_risk='retainedcurrent316 equals integergate316 zero margin; smallknownbatchpass does not guarantee mixedcurrent protection',
        nonduplicate='V164useslearnedfull149 geometry notnative117; V73uses referenceFITR7 not queryother7; NSL2clean147state notused; knownnegativegraph fixedpriorCIC parameters only',
        NN_fit=0,NN_forward=0,metric_fit=0,main_R7_refit=0,critic_fit=0,query_fit=False,trueUNA_fit=False,parameter_grid=False,timecap_coded=False,extension_not_verbatim_paper=True,status='FAIL_TARGET99',published=False,final_test_executed=False)
def closure():
    found={};seen=set();todo=[sys.modules[__name__]]
    while todo:
        m=todo.pop()
        if m is None or id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if not p or not Path(p).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        found[MODULE if m is sys.modules[__name__] else m.__name__]=files.item(p)
        for value in vars(m).values():
            child=value if isinstance(value,types.ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            if child is not None:todo.append(child)
    return found
def archive(a,keys,pins):return old.archive(a,keys,pins)
def save(out,r,key,value):return old.save(out,r,key,value)
def freeze():
    started=time.perf_counter();pins={};pr=files.item(previous.REG);p=files.js(pr,pins);kr=files.item(previous.BASE/'known/report.json');cr=files.item(previous.BASE/'current/report.json');k=files.js(kr,pins);c=files.js(cr,pins)
    require(k['known_gate_passed'] and c['prediction_sealed'] and c['original_class_gates']['UNA']['correct']==2844,'actualwhole2844 uniformpretruthbaseline')
    a=dict(p['assets']);a.update(merge_known=k['files']['complete_query7prediction_beforetruth'],merge_current=c['files']['complete_query7prediction_beforetruth'])
    close_ref=files.item(previous.DIR/'NSL1_V164_QUERYOTHER7_FULL149_COMPLETED_CLOSEOUT.json');close=files.js(close_ref,pins);review=files.item(ROOT/'tmp/root_saved_review_20261012_v172/NSL1_V164_INDEPENDENT_QUERY7_COMPLETE_2844_REVIEW.json');files.read(review,pins)
    for value in [*a.values(),*closure().values()]:files.read(value,pins)
    require(not REG.exists() and not BASE.exists(),'exclusive newphysical117 softcue namespace');DIR.mkdir(parents=True,exist_ok=True)
    return files.write(REG,dict(policy=policy(),assets=a,sources=closure(),synthetic_contract=core.synthetic_contract(),previous_registry=pr,previous_known=kr,previous_current=cr,ancestry_closeout=close_ref,ancestry_independent_review=review,prior_necessary_preparation_seconds=close['actual_preparation']['necessary_allprep_plus_ancestry_seconds'],freeze_seconds=time.perf_counter()-started,input_sha256=pins,current_numeric_decodes=0))
def bind(ref,pins):
    r=files.js(ref,pins);require(r['policy']==policy() and r['sources']==closure(),'exactfrozencomplete117 softrecipe unchanged')
    for path,sha in r['input_sha256'].items():files.read(dict(path=path,sha256=sha),pins)
    return r
def population(reference,q,out,r,role):
    rep,inv=previous.collapse(q);start=time.perf_counter();cue=core.population(reference['Z149'][:,32:],q['Z149'][rep,32:]);r['native_ratio_seconds'][role]=time.perf_counter()-start
    r['files'][role+'_cue']=save(out,r,role+'_native117_population_beforecut',dict(ids=q['ids'],groups=q['groups'],Z149=q['Z149'],stage1=q['stage1'],representatives=rep,inverse=inv,score_rows=cue['score'][inv],**cue));return cue,rep,inv
def soft(cue,rep,inv,q,rule,out,r,role):
    initial_rows=nsl.base.paper_route.candidate_mask(cue['score'][inv],q['stage1'],rule);initial=np.zeros(len(rep),bool);np.logical_or.at(initial,inv,initial_rows);start=time.perf_counter();graph=core.diffusion(cue['query_to_allknown_distances'],cue['query_pair_distances'],initial);r['soft_seconds'][role]=time.perf_counter()-start
    r['files'][role+'_soft']=save(out,r,role+'_native117_negative_softsupport_beforetruth',dict(ids=q['ids'],groups=q['groups'],representatives=rep,inverse=inv,initial_rows=initial_rows,support_score_rows=graph['support_score'][inv],**graph));return initial_rows,graph['support_score'][inv]
def run(phase,ref,knownref=None):
    started=time.perf_counter();pins={};reg=bind(ref,pins);control=None
    if phase=='current':control=files.js(knownref,pins);require(control['known_gate_passed'] and control['prediction_sealed'] and control['registry']==ref,'knownintegercontrol before new117current values')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False);r=dict(policy=policy(),phase=phase,registry=ref,files={},native_ratio_seconds={},soft_seconds={},NN_fit=0,NN_forward=0,metric_fit=0,main_R7_refit=0,critic_fit=0,CAL_fit=0,DVC=0,current_numeric_decodes=0,prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        with threadpool_limits(limits=4):
            a=reg['assets'];metric=nsl.learned.PaperVariationalPairMetric.from_state(files.js(a['metric'],pins));reference=archive(a['reference'],('ids','groups','Z149','original_indices','known_fine_membership'),pins);require(metric.dimension==149 and len(reference['ids'])==len(np.unique(reference['groups']))==5999,'genuineallknown5999 and main149 unchanged');r['files'].update(metric=a['metric'],reference=a['reference'])
            if phase=='known':
                mat=archive(a['material'],('fit_Z149','calibration_ids','calibration_groups','calibration_Z149','calibration_stage1'),pins);require(metric.to_state()['prefit_descriptor']['FIT_MHFD_Z']==nsl.base.descriptor(mat['fit_Z149']),'original149 native117 fullFIT owner');cal={key:mat['calibration_'+key] for key in ('ids','groups','Z149','stage1')};cue,rep,inv=population(reference,cal,out,r,'CAL');labels=archive(a['encoded'],('calibration_ids','calibration_known_coarse'),pins);require(np.array_equal(cal['ids'],labels['calibration_ids']),'all656trueknown exactCALauthority');rule=nsl.base.paper_route.calibrate_known_cutoffs(cue['score'][inv],labels['calibration_known_coarse']);r['CAL_fit']=1;r['files']['rule']=files.write(out/'all656_trueknown_oncefinite99_native117_queryR7.json',rule);soft(cue,rep,inv,cal,rule,out,r,'CAL')
            else:rule=files.js(control['files']['rule'],pins);r['files']['rule']=control['files']['rule'];r['known_report']=knownref
            q,_,_=old.query('NSL1',phase,a,pins);merge=archive(a['merge_known' if phase=='known' else 'merge_current'],('ids','prediction'),pins);require(np.array_equal(q['ids'],merge['ids']),'samewhole2844 orderedmerge baseline');baseline=merge['prediction'];role='CP' if phase=='known' else 'current';r['current_numeric_decodes']=len(q['ids']) if phase=='current' else 0;cue,rep,inv=population(reference,q,out,r,role);initial,support=soft(cue,rep,inv,q,rule,out,r,role);raw=initial&(support>core.FLOOR)&(baseline!=2);density=raw|(baseline==2)
            def sink(name,value,manifest):save(out,r,name+'_DVC_beforetruth',value);r['files'][name+'_DVC_manifest']=files.write(out/(name+'_DVC_manifest.json'),manifest)
            routed,_=nsl.base.route_once(metric,q,density,sink);r['DVC']=1;retained=raw&routed['retained'];prediction=baseline.copy();prediction[retained]=2;require(np.all(prediction[baseline==2]==2),'allold2844 wholepred2 protected')
            values=dict(ids=q['ids'],prediction=prediction,baseline=baseline,ratio_score=cue['score'][inv],support_score=support,initial_raw=initial,raw=raw,density=density,retained=retained);sealed=save(out,r,'complete_native117prediction_beforetruth',values);r['files']['seal']=files.write(out/'complete_native117prediction_seal_beforetruth.json',dict(predictions=sealed,registry=ref,reference=a['reference'],rule=r['files']['rule'],metric=a['metric'],querytruth_used=False));r['prediction_sealed']=True
            truth=nsl.parent.previous.prefix_archive(a['baseline'],('ids','truth'),654,pins) if phase=='known' else archive(a['baseline'],('ids','truth'),pins);require(np.array_equal(truth['ids'],q['ids']),'new117 wholeprediction sealed beforequerytruth');y=truth['truth'];r['truth_opened']=True;gates,delta,binary=old.helpers.metrics(y,baseline,prediction)
            r.update(execution_status='NSL1_complete117query7_negativesoft_original149_'+phase+'_completed',original_class_gates=gates,EffectDelta=delta,binary_attack_detection=binary,known_gate_passed=all(gates[name]['passed'] for name in ('BEN','KNA')),candidate_accepted_for_retention=False,initial_by_trueclass={name:int(((y==c)&initial&(baseline!=2)).sum()) for c,name in enumerate(('BEN','KNA','UNA'))},raw_by_trueclass={name:int(((y==c)&raw).sum()) for c,name in enumerate(('BEN','KNA','UNA'))},retained_by_trueclass={name:int(((y==c)&retained).sum()) for c,name in enumerate(('BEN','KNA','UNA'))});save(out,r,'postseal_complete_native117_pair',dict(**values,truth=y))
            if phase=='current':r['perfect_native117_raw_UNA_ceiling']=int(((y==2)&((baseline==2)|raw)).sum())
        for path,sha in pins.items():require(files.item(path)['sha256']==sha,'originalsource/NN/metric/roles/ref/2844+2760+2757 snapshots unchanged')
    except Exception as error:r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for key in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+key)
    args=p.parse_args();ref=None if args.registry is None else dict(path=str(Path(args.registry).resolve()),sha256=args.registry_sha256);known=None if args.known_report is None else dict(path=str(Path(args.known_report).resolve()),sha256=args.known_sha256);print(json.dumps(freeze() if args.phase=='freeze' else run(args.phase,ref,known)),flush=True)
