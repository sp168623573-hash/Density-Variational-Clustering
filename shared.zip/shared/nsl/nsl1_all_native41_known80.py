"""Own NSL1 known-only MHFD115 with all41 fields and fixed final epoch80.

No unknown values, old model parameters or validation-driven checkpoints are
used. Constants remain real input fields; UNSEEN one-hot slots do not create
traffic. Duration originates from verified native41 parents, never a fill.
"""
import argparse
from collections import Counter
import io
import json
import os
from pathlib import Path
import time
from types import SimpleNamespace
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler
from . import model, config
from . import nsl1_all_native41_material_v1 as material_code
from . import nsl2_clean_known_material_training_v1 as output_io

files, ROOT = material_code.files, material_code.ROOT
FAMILIES = ('BEN', *config.get_spec('NSL-KDD Setting1').known_families)
SCHEMA = 'NSL1-all-native41-MHFD115-known-only-fixed80-v1'
EPOCHS, SEED = 80, 20261009


def archive(asset,keys,pins):
    with np.load(io.BytesIO(files.read(asset,pins)),allow_pickle=False) as z:return {k:z[k].copy() for k in keys}


def array_descriptor(value):
    a=np.asarray(value)
    import hashlib
    return dict(shape=list(a.shape),dtype=a.dtype.str,sha256=hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest())


def complete_known_infer(net,x,device,role,out,report):
    captures={k:[] for k in ('coarse_logits','fine_logits','reconstruction')};handles=[]
    for name,module in (('coarse_logits',net.coarse_head),('fine_logits',net.fine_head),('reconstruction',net.decoder)):
        def hook(module,args,tensor,name=name):
            value=tensor.detach().float().cpu().numpy().copy();i=len(captures[name]);captures[name].append(value)
            output_io.persist(out,role+'_'+name+'_batch'+str(i)+'_actual_before_guard',dict(value=value),report)
        handles.append(module.register_forward_hook(hook))
    report['counts']['known_infer_attempts']+=1
    try:
        result=model.infer(net,x,device=torch.device(device),batch_size=2048)
        report['counts']['known_infer_returns']+=1
    finally:
        for handle in handles:handle.remove()
    # Persist every returned dataclass field, not merely values used by one scorer.
    values={name:np.asarray(value).copy() for name,value in vars(result).items()}
    values['embedding32']=values['embedding'].copy()
    values.update({name:np.concatenate(parts) for name,parts in captures.items()})
    output_io.persist(out,role+'_complete_infer_before_guard',values,report)
    files.require(all(len(value)==len(x) and np.isfinite(value).all() for value in values.values()),'actual complete inference outputs saved before guards')
    files.require(values['reconstruction'].shape==x.shape and all(len(parts)==(len(x)+2047)//2048 for parts in captures.values()),'one complete raw output per actual inference batch')
    report['counts']['known_forward_batches']+=(len(x)+2047)//2048
    return result,values


def freeze():
    pins = {}
    material_a = dict(path=str(ROOT / 'data/external_dev/processed/nsl1_all_native41_material_20261009_v1/report.json'),
        sha256='35f0839ac457d46d05345131a3ae2afe676807d7c8f5b56163476522cda09e87')
    source = files.js(material_a, pins)
    policy = dict(schema_version=SCHEMA, setting='NSL-KDD Setting1', classes=list(FAMILIES),
        input_width=115, original_fields=41, train_role='fit', roles=dict(fit=4034, checkpoint=656, calibration=656, open_known=654),
        source_encoding='genuine all41, knownFIT log1p/RMS, no known-constant variance drop, explicit unseen categorical coordinates',
        model='MHFDNetwork attention/gate/position/CNN/BiLSTM/coarse/fine/decoder',
        loss='coarseCE +0.35fineCE(label_smoothing0.01) +0.03cleanSmoothL1',
        optimizer='AdamW lr0.001 weight_decay0.0002; cosine80 eta_min0.0001; clip5',
        batch_size=128, CPU_threads=4, epochs=80, seed=SEED,
        checkpoint='fixed final epoch80; no per-epoch CP/CAL/known-query forward',
        threshold='original calibration656 only, frozen before known-query654',
        unknown_values_read=False, unknown_training=False, old_checkpoint_transferred=False,
        auxiliary_mask_loss_used=False, source_or_training_isolated_causal_claim=False)
    prior = dict(path=str(ROOT / 'data/external_dev/processed/nsl_MHFD_whole_field_mask_known80_20261009_v1/NSL_KDD_Setting1/report.json'),
        sha256='9b3e14629a6a9b1add35fc9855a14eeafa0d81c86a799249a05737628dd1e7af')
    previous = files.js(prior,pins)
    reg = dict(schema_version=SCHEMA+'-registry', policy=policy, material=material_a,
        known_inputs=source['encoded_inputs'], new_model_prefit=source['model_prefit'], encoder=source['encoder'],
        prior_known_report=prior, prior_known_prediction_material=previous['updated_clean_material'],
        sources={Path(m.__file__).name: files.item(m.__file__) for m in (model,config,material_code,output_io,files)},
        output=str(ROOT/'data/external_dev/processed/nsl1_all_native41_known80_20261009_v1'),
        source_admitted=False,published=False,final_test_executed=False)
    reg['sources']['caller']=files.item(__file__);reg['registry_sha256']=files.digest(reg)
    directory=ROOT/'tmp/nsl1_all_native41_known80_20261009_v1';directory.mkdir(exist_ok=True)
    return files.write(directory/'registry_before_actual.json',reg)


def fit_fixed80(x, coarse, fine):
    """Own NSL1 namespace; no inherited NSL2 family/role globals."""
    model.set_seed(SEED);device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net=model.MHFDNetwork(115,len(FAMILIES)).to(device)
    sampler=WeightedRandomSampler(model._hierarchical_sample_weights(fine),num_samples=len(x),replacement=True,
        generator=torch.Generator().manual_seed(SEED))
    loader=DataLoader(TensorDataset(torch.from_numpy(x),torch.from_numpy(coarse),torch.from_numpy(fine)),
        batch_size=128,sampler=sampler,num_workers=0,pin_memory=device.type=='cuda')
    optimizer=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.0002)
    scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=80,eta_min=.0001)
    scaler=torch.amp.GradScaler('cuda',enabled=device.type=='cuda')
    criterion_c=nn.CrossEntropyLoss();criterion_f=nn.CrossEntropyLoss(label_smoothing=.01);criterion_r=nn.SmoothL1Loss()
    history=[];start=time.perf_counter()
    for epoch in range(1,81):
        net.train();total=0.;rows=0
        for xb,cb,fb in loader:
            xb,cb,fb=xb.to(device),cb.to(device),fb.to(device);optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=device.type=='cuda'):
                output=net(xb)
                loss=criterion_c(output['coarse_logits'],cb)+.35*criterion_f(output['fine_logits'],fb)+.03*criterion_r(output['reconstruction'],xb)
            files.require(torch.isfinite(loss).item(),'finite actual NSL1 known loss')
            scaler.scale(loss).backward();scaler.unscale_(optimizer);nn.utils.clip_grad_norm_(net.parameters(),5.)
            scaler.step(optimizer);scaler.update();total+=float(loss.detach())*len(xb);rows+=len(xb)
        scheduler.step();history.append(dict(epoch=epoch,loss=total/rows,learning_rate=scheduler.get_last_lr()[0]))
        if epoch==1 or epoch%10==0:
            print(f'[NSL1 all41 fixed80] epoch={epoch}/80 loss={total/rows:.6f} elapsed={time.perf_counter()-start:.1f}s',flush=True)
    return SimpleNamespace(model=net,device=str(device),history=history,training_seconds=time.perf_counter()-start)


def run(path,sha):
    pins={};started=time.perf_counter();reg_a=dict(path=str(Path(path).resolve()),sha256=sha)
    reg=files.js(reg_a,pins);unsigned=dict(reg);signature=unsigned.pop('registry_sha256')
    files.require(signature==files.digest(unsigned) and reg['schema_version']==SCHEMA+'-registry','frozen own NSL1 all41 known run')
    for a in reg['sources'].values():files.read(a,pins)
    files.require(reg['sources']['caller']==files.item(__file__),'exact caller source')
    out=Path(reg['output']);files.require(out.is_relative_to(ROOT) and not out.exists(),'fresh all41 model output');out.mkdir(parents=True)
    report=dict(schema_version=SCHEMA,registry=reg_a,policy=reg['policy'],files={},execution_status='not_completed',
        counts=dict(training_runs=0,known_infer_attempts=0,known_infer_returns=0,known_forward_batches=0,unknown_forward=0),
        unknown_numeric_decodes=0,accepted_baseline_replaced=False,published=False,final_test_executed=False,source_admitted=False,
        status='FAIL_TARGET99',runtime_environment=dict(CUBLAS_WORKSPACE_CONFIG=os.environ.get('CUBLAS_WORKSPACE_CONFIG'),torch_version=torch.__version__))
    stage='bind exact original known roles'
    try:
        prefit=files.js(reg['new_model_prefit'],pins);roles=reg['policy']['roles']
        keys=tuple(r+'_'+k for r in roles for k in ('features','ids','known_fine','known_coarse'))
        data=archive(reg['known_inputs'],keys,pins)
        all_ids=[]
        for r,n in roles.items():
            x,f,c,ids=(data[r+'_'+k] for k in ('features','known_fine','known_coarse','ids'))
            files.require(x.shape==(n,115) and x.dtype==np.float32 and np.isfinite(x).all()
                and f.dtype==c.dtype==np.int64 and np.isin(f,range(9)).all() and np.array_equal(c,(f!=0).astype(np.int64)),
                'typed genuine NSL1 known role:'+r)
            all_ids.extend(ids.tolist())
        files.require(len(all_ids)==len(set(all_ids))==6000 and len(FAMILIES)==9,'unique known6000 and complete NSL1 family order')
        family_counts=Counter(data['fit_known_fine'].tolist());files.require(set(family_counts)==set(range(9)) and min(family_counts.values())>=20,'real knownFIT family floor20')
        report['files']['training_prefit']=files.write(out/'all41_training_policy_before_fit.json',dict(policy=reg['policy'],
            known_inputs=reg['known_inputs'],encoder=reg['encoder'],source_prefit=reg['new_model_prefit'],input_sha256=pins,
            actual_fit_family_counts={FAMILIES[k]:v for k,v in family_counts.items()},
            no_unknown_or_CAL_DEV_fit=True,runtime_environment=report['runtime_environment']))
        stage='one own NSL1 known-only115 fixed80 training';torch.set_num_threads(4);report['counts']['training_runs']=1
        fitted=fit_fixed80(data['fit_features'],data['fit_known_coarse'],data['fit_known_fine'])
        report.update(training_seconds=fitted.training_seconds,training_device=fitted.device,epochs_completed=80)
        state_hash=output_io.state_digest(fitted.model)
        checkpoint=out/'new_all41_known_fixed80_MHFD115.pt'
        torch.save(dict(state_dict={k:v.detach().cpu() for k,v in fitted.model.state_dict().items()},model_class='MHFDNetwork',
            input_dim=115,fine_classes=list(FAMILIES),epochs_completed=80,seed=SEED,model_state_sha256=state_hash),checkpoint)
        report['files']['model']=files.item(checkpoint);report['files']['history']=files.write(out/'actual_training_history80.json',fitted.history)
        outputs={}
        for r in ('fit','calibration'):
            stage='one actual known inference:'+r
            output,values=complete_known_infer(fitted.model,data[r+'_features'],fitted.device,r,out,report);outputs[r]=output
        threshold,metrics=model.choose_coarse_threshold(data['calibration_known_coarse'],outputs['calibration'].attack_probability)
        report['files']['threshold']=files.write(out/'knownCAL_threshold_before_known654.json',dict(threshold=float(threshold),
            calibration_IDs_array_descriptor=array_descriptor(data['calibration_ids']),calibration_metrics=metrics,known654_labels_used=False,model=report['files']['model']))
        stage='one actual known654 inference after threshold seal'
        output,values=complete_known_infer(fitted.model,data['open_known_features'],fitted.device,'open_known',out,report);outputs['open_known']=output
        predictions={r+'_prediction':(v.attack_probability>=threshold).astype(np.int64) for r,v in outputs.items()}
        predictions.update({r+'_ids':data[r+'_ids'] for r in outputs})
        pa=output_io.persist(out,'complete_known_predictions_before_prior',predictions,report)
        report['files']['prediction_seal']=files.write(out/'known_prediction_seal_before_prior_comparison.json',dict(model=report['files']['model'],
            threshold=report['files']['threshold'],predictions=pa,prior_forecast_opened=False))
        gs={r:bridge_gates(data[r+'_known_coarse'],predictions[r+'_prediction']) for r in outputs}
        prior=archive(reg['prior_known_prediction_material'],('open_known_ids','open_known_predicted_coarse'),pins)
        files.require(np.array_equal(prior['open_known_ids'],data['open_known_ids']),'same known654 IDs comparison only')
        oldg=bridge_gates(data['open_known_known_coarse'],prior['open_known_predicted_coarse'])
        delta={n:gs['open_known'][n]['correct']-oldg[n]['correct'] for n in ('BEN','KNA')}
        direction='UP' if all(v>=0 for v in delta.values()) and any(delta.values()) else 'DOWN' if all(v<=0 for v in delta.values()) and any(delta.values()) else 'UNCHANGED' if not any(delta.values()) else 'MIXED'
        files.require(output_io.state_digest(fitted.model)==state_hash,'actual model remains frozen during inference')
        report.update(execution_status='all41_MHFD115_known80_CAL_known654_evaluated',model_state_sha256=state_hash,
            known_class_gates=gs,known654_passed=all(v['passed'] for v in gs['open_known'].values()),
            CAL_passed=all(v['passed'] for v in gs['calibration'].values()),coarse_threshold=float(threshold),
            EffectDelta=dict(verdict=direction,correct_count_delta=delta,prior35e_classifier_gates=oldg),
            unknown_performance_measured=False,representation_and_training_changes_confounded=True)
        for p,h in pins.items():files.require(files.item(p)['sha256']==h,'bound source and data preserved')
    except Exception as error:
        report.update(execution_status='execution_failed',failed_stage=stage,error_type=type(error).__name__,error=str(error));raise
    finally:
        report['input_sha256']=pins;report['wall_seconds']=time.perf_counter()-started;files.write(out/'report.json',report)
    return files.item(out/'report.json')


def bridge_gates(y,p):
    return {n:dict(correct=int(((y==i)&(p==i)).sum()),support=int((y==i).sum()),required=(99*int((y==i).sum())+99)//100,
        passed=bool((y==i).sum() and 100*((y==i)&(p==i)).sum()>=99*(y==i).sum())) for i,n in enumerate(('BEN','KNA'))}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--freeze',action='store_true');p.add_argument('--registry');p.add_argument('--registry-sha256')
    a=p.parse_args();print(json.dumps(freeze() if a.freeze else run(a.registry,a.registry_sha256)))
