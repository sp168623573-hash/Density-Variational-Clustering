"""One actual-classifier ViM D16 cue and matching174 learned paper geometry.

Cached real MHFD features are passed through the actual frozen fine_head with
input/output hooks; no backbone feature extraction or synthetic logits.
"""
import argparse,io,json,sys,time
from pathlib import Path
import numpy as np
import torch
from scipy.special import logsumexp
from . import nsl1_nativecell_clean149_v62 as old
from . import nsl1_ViM174_pair_metric_v76 as learned
from . import nsl1_ViM174_dvc_v76 as dvc
from . import artifact_api_preflight_v52 as preflight

ROOT,files,base=old.ROOT,old.files,old.base
MODULE='paper_open_set.nsl1_classifier_ViM174_v76'
BASE=ROOT/'data/external_dev/processed/nsl1_classifier_ViM174_20261012_v76'
REG=ROOT/'tmp/nsl1_classifier_ViM174_20261012_v76/registry_before_classifier_ViM_known.json'
OLD_KNOWN=dict(path=str(old.BASE/'known/report.json'),sha256='08474405119159398012fe694aec6478ec2b3295a231825da9f576c99e92e333')
BASELINE=dict(path=str(old.BASE/'current/report.json'),sha256='eb3a15953d98d0e5a142cca0b3504b4683f546d225301f63491374783299f0da')
D,BATCH=16,512

def policy():
    return dict(schema_version='NSL1-actualFineHead32-ViM-D16-matching174-v76',hypotheses=1,
        evidence='RealV60 full117 typedmasked knownFIT MHFD final30 checkpoint and actualV62 CPUfloat32 raw_embedding32/rawfine_logits caches; original35e classifier decisions unchanged',
        head='Load authenticcomplete masked checkpoint; call actual net.fine_head only with pre/post hooks, input32/output9/weight9x32/bias9; exactlysame role batch512 andcurrent known654/unknown2944segmentation; requirebitexact cachedrawfine logits',
        no_backbone_feature_extraction=True,no_synthetic_logits_or_weights=True,
        origin='o=-pinv(actualfineW)b in float64, rcond=32*machineeps numerical rank only; no jitter or covarianceepsilon',
        PCA='genuine5999 FIT input32 around classifierorigin uncentered secondmoment, eigh32, top16 principal/rest16 residual, each eigenvector sign largestabscoordinatepositive(firsttie); savedfixedbasis reused allroles',
        alpha='genuineFIT mean max actualfine9logit / genuineFIT mean residual16norm; denominator>0 andalpha>0 strictly required elseprotocol_stop; no abs/sign changes',
        score='alpha*L2norm(signedresidual16)-logsumexp(actualfine9); rawsignednegative scores retained, no probabilityclipping; originalquerycoarse onlyselects CALrule',
        geometry='Alloriginalencoded117 + actualfine_head input32/genuineFIT RMS + signedViMresidual16/genuineFIT RMS + actualfine9logits/genuineFIT RMS=174; orientation fixed, actualcontinuouslogits not querytruth/fineonehot',
        FIT='6000 trueknown originalsourceIDs, everyfine>=20; genuine5999 native41group representatives for covariance/alpha/RMS/reference/density; dualfine2/4group memberships retained',
        metric='Freshmatching174 Eq9/10, explicitly8192finebalancedpairs/fixed80; ASTwhitelist numericdimension guard only, no accidentalpaircount substringchange',
        CAL='alltrueknownCAL656 once finite99 strictgreater bytrueknowncoarse, queryoriginalstage1 selects cutoff; no D/alpha/cut/field/orientation scan',
        DVC='same newlylearned174 forprimary+secondary knee/SC/CH/affinity/reconstruction/localdensity/secondarynoise; rawORold2618UNA, one nativegroup event',
        merge='Copy whole2618 andappend onlynewrawANDnewDVCretainedUNA; old2601/2605/2618 preserved; actualall3oldcorrectloss0+UP for additionalDEVretention',
        gate='known654 BEN/KNA exactinteger99 andalloldcorrectloss0 before anycurrent3598values/headcalls',
        source='https://arxiv.org/abs/2203.10807',extension_not_verbatim_paper=True,realUNA_fit=False,query_fit=False,parameter_grid=False,
        budget='FIT headprobe/realWb/SVD/eigh/alpha/RMS/firstpair/metricprep all counted, no Rkfit needed forViMscore; priorNN1261.1884094000561+oldmetric6.321081299975049 retained; pureCAL/known/current headscore+DVC separate; no codedtimebound',
        prior_NN_ancestry_seconds=1261.1884094000561,prior_old_metric_seconds=6.321081299975049,
        independent_final_unproven=True,status='FAIL_TARGET99',published=False,final_test_executed=False)

def closure():
    result={}
    for m in list(sys.modules.values()):
        p=getattr(m,'__file__',None)
        if p:
            q=Path(p).resolve()
            if q.suffix=='.py'and q.is_relative_to(ROOT/'paper_open_set'):result[str(q)]=files.item(q)
    result['caller']=files.item(__file__);return result

def archive(a,keys,pins):return base.archive(a,keys,pins)
def persist(out,r,name,v):return base.save(out,r,name,v)

def freeze():
    pins={};k=files.js(OLD_KNOWN,pins);b=files.js(BASELINE,pins);kr=files.js(k['registry'],pins);tr=files.js(kr['train_report'],pins)
    files.require(k['known_gate_passed']and b['prediction_sealed']and b['original_class_gates']['UNA']['correct']==2618 and tr['epochs_completed']==30,'authenticV62known/whole2618 andrealV60final30 checkpoint')
    assets=dict(encoded=kr['assets']['encoded'],material=k['files']['material'],model=kr['assets']['model'],field_map=kr['assets']['field_map'],FIT_clean=k['files']['fit_clean'],CAL_clean=k['files']['calibration_clean'],known_clean=k['files']['open_known_clean'],unknown_clean=b['files']['unknown2944_clean'],current_context=b['files']['actual_query_nativecell_clean149_before_scores'],baseline=b['files']['postseal_comparison'])
    headers={n:old.masked.previous.metadata_headers(a,pins)for n,a in assets.items()if Path(a['path']).suffix=='.npz'}
    for name,n in [('FIT_clean',6000),('CAL_clean',656),('known_clean',654),('unknown_clean',2944)]:
        files.require(headers[name]['raw_embedding']['shape']==[n,32]and headers[name]['embedding32']['shape']==[n,32]and headers[name]['raw_fine_logits']['shape']==[n,9],'actualsavedwhole rawMHFDhead input32/fine9 packetheaders')
    files.require(headers['encoded']['fit_features']['shape']==[6000,117]and headers['current_context']['Z149']['shape']==[3598,149]and learned.MAX_DIMENSION==174 and learned.PAIR_COUNT==8192 and dvc.WIDTH==174,'complete117/native149/own174 actual8192dimensions')
    check=preflight.preflight(api_contracts=[dict(module_name=old.masked.__name__,function_name='load_checkpoint',required_parameters=['checkpoint','reg','field_map','device'],source_sha256=files.item(old.masked.__file__)['sha256']),dict(module_name=learned.__name__,function_name='fit_known_metric',required_parameters=['z_fit','y_fit_fine'],source_sha256=files.item(learned.__file__)['sha256']),dict(module_name=dvc.__name__,function_name='route_current_candidates',required_parameters=['metric','Z','raw','seed'],source_sha256=files.item(dvc.__file__)['sha256'])])
    src=closure()
    for a in [*assets.values(),*src.values()]:files.read(a,pins)
    files.require(not REG.exists()and not BASE.exists(),'fresh onceonlyclassifierViM174')
    value=dict(policy=policy(),sources=src,assets=assets,headers=headers,actual_API=check,V60_train_report=kr['train_report'],V60_registry=tr['registry'],model_state_sha256=tr['model_state_sha256'],old_known_report=OLD_KNOWN,baseline_report=BASELINE,actual_metric_recipe=learned.training_recipe(174),input_sha256=pins)
    value['registry_sha256']=files.digest(value);REG.parent.mkdir(parents=True,exist_ok=False);return files.write(REG,value)

def bind(desc,pins):
    reg=files.js(desc,pins);u=dict(reg);h=u.pop('registry_sha256');files.require(h==files.digest(u)and reg['policy']==policy()and reg['sources']['caller']==files.item(__file__)and reg['actual_metric_recipe']==learned.training_recipe(174),'exact source/recipe/8192pair binder')
    for a in reg['sources'].values():files.read(a,pins)
    return reg

def network(reg,pins):
    tr=files.js(reg['V60_registry'],pins);mapping=old.masked.field_map_from_state(files.js(reg['assets']['field_map'],pins));ck=torch.load(io.BytesIO(files.read(reg['assets']['model'],pins)),map_location='cpu',weights_only=True);net=old.masked.load_checkpoint(ck,tr,mapping,device=torch.device('cpu'));net.eval();files.require(isinstance(net.fine_head,torch.nn.Linear)and net.fine_head.in_features==32 and net.fine_head.out_features==9 and old.masked.output_io.state_digest(net)==reg['model_state_sha256'],'actual complete checkpoint finehead Linear32→9, exactfrozen modelstate');return net

@torch.no_grad()
def head_probe(net,cache,role,out,r):
    x=cache['raw_embedding'];files.require(x.dtype==np.float32 and x.shape==(len(x),32)and np.array_equal(x,cache['embedding32']),'actualraw unscaledMHFD32 headinput cache')
    state=old.masked.output_io.state_digest(net);outputs=[];captured={};t=time.perf_counter()
    def pre(module,args):captured['actual_head_input']=args[0].detach().cpu().numpy().copy()
    def post(module,args,result):captured['actual_fine_logits']=result.detach().cpu().numpy().copy()
    before=net.fine_head.register_forward_pre_hook(pre);after=net.fine_head.register_forward_hook(post)
    try:
        for first in range(0,len(x),512):
            stop=min(first+512,len(x));captured.clear();returned=net.fine_head(torch.from_numpy(x[first:stop].copy()));actual={k:v.copy()for k,v in captured.items()};persist(out,r,role+'_actual_finehead_hooks_batch'+str(first),actual);files.require(np.array_equal(actual['actual_head_input'],x[first:stop])and np.array_equal(actual['actual_fine_logits'],returned.cpu().numpy())and np.array_equal(actual['actual_fine_logits'],cache['raw_fine_logits'][first:stop]),'realhead inputhook andcachedlogits exact withoutsynthetics');outputs.append(actual['actual_fine_logits']);r['actual_head_forward_batches']+=1
    finally:before.remove();after.remove()
    logits=np.concatenate(outputs);persist(out,r,role+'_actualwhole_head32_fine9_proof',dict(input32=x,actual_logits9=logits,cached_logits9=cache['raw_fine_logits']));files.require(old.masked.output_io.state_digest(net)==state and not net.training,'headprobes do not mutatefrozen model');r['head_inference_seconds'][role]=time.perf_counter()-t;return x,logits

def rim(x,selected):
    a=np.asarray(x,np.float64)[selected];v=np.sqrt(np.mean(np.square(a),axis=0));v[v==0]=1.;return v

def vim(x,logits,stats):
    residual=(x.astype(np.float64)-stats['origin'][None,:])@stats['residual_basis'];norm=np.linalg.norm(residual,axis=1);score=stats['alpha'][0]*norm-logsumexp(logits.astype(np.float64),axis=1);files.require(np.isfinite(residual).all()and np.isfinite(score).all(),'finite actual signedViM residual16/score no clipping');return residual,score

def geometry(encoded,x,logits,residual,units):
    return np.concatenate((encoded.astype(np.float64),x.astype(np.float64)/units['head_input_RMS'],residual/units['residual_RMS'],logits.astype(np.float64)/units['logit_RMS']),axis=1)

def route174(metric,query,density,out,r):
    members={}
    for i,g in enumerate(query['groups'].tolist()):members.setdefault(g,[]).append(i)
    reps=np.asarray([next((i for i in rows if density[i]),rows[0])for rows in members.values()],np.int64);mapping={g:i for i,g in enumerate(members)};inverse=np.asarray([mapping[g]for g in query['groups'].tolist()]);q=dvc.route_current_candidates(metric,query['Z174'][reps],density[reps],seed=20261009);route={n:np.asarray(q[n])[inverse]for n in ('first','second','suspected','reconstruction','density','anomaly')};route.update(retained=density&q['retained'][inverse],representatives=reps,inverse=inverse);persist(out,r,'owned174_DVC_before_truth',route);r['files']['DVC_manifest']=files.write(out/'owned174_DVC_manifest.json',dict(q['manifest'],dimension=174,original_rows=len(density),native_density_groups=len(reps),copies_in_density=0));return route

def run(phase,desc,known_desc=None):
    started,pins=time.perf_counter(),{};reg=bind(desc,pins)
    if phase=='current':
        k=files.js(known_desc,pins);files.require(k['registry']==desc and k['known_gate_passed']and k['prediction_sealed']and not k['unknown_numeric_decoded'],'strictknowngate beforeunknown numeric/head')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False);before=old.masked.capture_runtime_flags();r=dict(policy=policy(),registry=desc,phase=phase,files={},head_inference_seconds={},actual_head_forward_batches=0,NN_fit=0,backbone_forward=0,metric_fit=0,CAL_fit=0,DVC=0,prediction_sealed=False,truth_opened=False,unknown_numeric_decoded=False,accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        torch.set_num_threads(4);torch.set_float32_matmul_precision('highest');torch.backends.cuda.matmul.allow_tf32=False
        a=reg['assets']
        if phase=='known':
            prep=time.perf_counter();net=network(reg,pins);encoded=archive(a['encoded'],('fit_features','fit_ids','fit_known_fine','calibration_features','calibration_ids','calibration_known_coarse','open_known_features','open_known_ids'),pins);mat=archive(a['material'],('fit_ids','fit_groups','fit_fine','calibration_ids','calibration_groups','calibration_stage1','calibration_predicted_fine','open_known_ids','open_known_groups','open_known_stage1','open_known_predicted_fine'),pins);files.require(np.array_equal(encoded['fit_ids'],mat['fit_ids'])and np.array_equal(encoded['fit_known_fine'],mat['fit_fine'])and len(np.unique(mat['fit_ids']))==6000 and min(np.bincount(mat['fit_fine'],minlength=9))>=20,'completetrueknown6000/finefloor')
            fx,fl=head_probe(net,archive(a['FIT_clean'],('raw_embedding','embedding32','raw_fine_logits'),pins),'FIT6000',out,r);selected,members=base.representatives(mat['fit_ids'],mat['fit_groups']);files.require(len(selected)==5999,'genuine5999 covarianceevents');W=net.fine_head.weight.detach().cpu().numpy().astype(np.float64);b=net.fine_head.bias.detach().cpu().numpy().astype(np.float64);origin=-np.linalg.pinv(W,rcond=32*np.finfo(np.float64).eps)@b;centre=fx[selected].astype(np.float64)-origin;cov=centre.T@centre/len(selected);eigenvalue,eigenvectors=np.linalg.eigh(cov)
            for j in range(32):
                maximum=int(np.argmax(np.abs(eigenvectors[:,j])));
                if eigenvectors[maximum,j]<0:eigenvectors[:,j]*=-1
            basis=eigenvectors[:,:16];norm=np.linalg.norm(centre@basis,axis=1);den=float(norm.mean());numer=float(fl[selected].max(axis=1).mean());files.require(den>0 and numer/den>0,'positiveViMdenominator_andalpha_required_nosignfallback');alpha=numer/den;stats=dict(origin=origin,residual_basis=basis,principal_basis=eigenvectors[:,16:],eigenvalues=eigenvalue,alpha=np.asarray([alpha]),denominator=np.asarray([den]),numerator=np.asarray([numer]),actualfineW=W,actualfinebias=b,genuine_representatives=selected)
            r['files']['ViM_stats']=persist(out,r,'genuine5999_actual_classifier_ViM_origin_basis_alpha_before_CAL',stats);residual,score=vim(fx,fl,stats);persist(out,r,'FIT6000_signedresidual16_andscore',dict(residual16=residual,score=score));units=dict(head_input_RMS=rim(fx,selected),residual_RMS=rim(residual,selected),logit_RMS=rim(fl,selected));r['files']['units']=persist(out,r,'genuine5999_actual174_block_RMS',units);z=geometry(encoded['fit_features'],fx,fl,residual,units);r['files']['FIT174']=persist(out,r,'actualFIT6000_native117_input32_residual16_logits9_before_metric',dict(ids=mat['fit_ids'],groups=mat['fit_groups'],fine=mat['fit_fine'],Z174=z));kw=dict(known_fine_labels=list(range(9)),fit_ids=mat['fit_ids'].tolist(),fit_group_ids=mat['fit_groups'].tolist(),fit_roles=['FIT']*6000);t=time.perf_counter();plan=learned.prefit_descriptor(z,mat['fit_fine'],**kw);r['first_pair_preparation_seconds']=time.perf_counter()-t;r['files']['prefit']=files.write(out/'actual8192pairs_known6000_native5999_prefit.json',plan);t=time.perf_counter();metric=learned.fit_known_metric(z,mat['fit_fine'],expected_prefit_sha256=plan['prefit_sha256'],**kw);r['metric_fit_preparation_seconds']=time.perf_counter()-t;r['metric_gradient_seconds']=metric.to_state()['trained']['training_seconds'];r['metric_fit']=1;r['files']['metric']=files.write(out/'newmatching174_Eq9_10_before_CAL.json',metric.to_state());r['training_preparation_seconds']=time.perf_counter()-prep
            cx,cl=head_probe(net,archive(a['CAL_clean'],('raw_embedding','embedding32','raw_fine_logits'),pins),'CAL656',out,r);cr,cs=vim(cx,cl,stats);cut=base.paper_route.calibrate_known_cutoffs(cs,encoded['calibration_known_coarse']);r['CAL_fit']=1;r['files']['CAL_rule']=files.write(out/'alltrueknownCAL656_once_ViMfinite99.json',cut);persist(out,r,'allCAL656_actualViM_before_rule',dict(ids=encoded['calibration_ids'],residual16=cr,score=cs,truecoarse=encoded['calibration_known_coarse']));qx,ql=head_probe(net,archive(a['known_clean'],('raw_embedding','embedding32','raw_fine_logits'),pins),'known654',out,r);qr,score=vim(qx,ql,stats);query=dict(ids=mat['open_known_ids'],groups=mat['open_known_groups'],stage1=mat['open_known_stage1'],predicted_fine=mat['open_known_predicted_fine'],Z174=geometry(encoded['open_known_features'],qx,ql,qr,units))
        else:
            r['known_report']=known_desc;stats=archive(k['files']['ViM_stats'],('origin','residual_basis','alpha'),pins);units=archive(k['files']['units'],('head_input_RMS','residual_RMS','logit_RMS'),pins);cut=files.js(k['files']['CAL_rule'],pins);metric=learned.PaperVariationalPairMetric.from_state(files.js(k['files']['metric'],pins));r['files'].update({n:k['files'][n]for n in ('ViM_stats','units','metric','CAL_rule')});net=network(reg,pins);knownpacket=archive(k['files']['known654_actualwhole_head32_fine9_proof'],('input32','actual_logits9'),pins);unknowncache=archive(a['unknown_clean'],('raw_embedding','embedding32','raw_fine_logits'),pins);r['unknown_numeric_decoded']=True;ux,ul=head_probe(net,unknowncache,'unknown2944',out,r);qx=np.concatenate((knownpacket['input32'],ux));ql=np.concatenate((knownpacket['actual_logits9'],ul));qr,score=vim(qx,ql,stats);persist(out,r,'current3598_trueknown654_unknown2944_realhead_inputs_logits_residuals',dict(input32=qx,actual_logits9=ql,residual16=qr,score=score));context=archive(a['current_context'],('ids','groups','Z149','stage1','predicted_fine'),pins);encoded=np.asarray(context['Z149'][:,32:],np.float32);files.require(np.array_equal(encoded.astype(np.float64),context['Z149'][:,32:]),'actualcurrent117 columns exactnoinverse repair');query=dict(ids=context['ids'],groups=context['groups'],stage1=context['stage1'],predicted_fine=context['predicted_fine'],Z174=geometry(encoded,qx,ql,qr,units))
        persist(out,r,'actualquery174_before_ViM_DVC',query);raw=base.paper_route.candidate_mask(score,query['stage1'],cut);baseline=old.parent.previous.prefix_archive(a['baseline'],('prediction',),654,pins)['prediction']if phase=='known'else archive(a['baseline'],('prediction',),pins)['prediction'];density=raw|(baseline==2);persist(out,r,'ViM_score_raw_before_DVC',dict(ids=query['ids'],score=score,raw=raw,density=density,stage1=query['stage1']));t=time.perf_counter();route=route174(metric,query,density,out,r);r['DVC']=1;r['query_DVC_seconds']=time.perf_counter()-t;retained=raw&route['retained'];pred=base.merge(baseline,raw,retained);v=dict(ids=query['ids'],prediction=pred,baseline=baseline,raw=raw,retained=retained,density=density);p=persist(out,r,'complete_prediction_before_truth',v);r['files']['seal']=files.write(out/'prediction_seal_before_truth.json',dict(predictions=p,registry=desc,metric=r['files']['metric'],ViMstats=r['files']['ViM_stats'],CAL=r['files']['CAL_rule'],truth_used=False));r['prediction_sealed']=True;truth=old.parent.previous.prefix_archive(a['baseline'],('ids','truth'),654,pins)if phase=='known'else archive(a['baseline'],('ids','truth'),pins);files.require(np.array_equal(truth['ids'],query['ids']),'postseal sameorderedtruth');r['truth_opened']=True;effect,g,_=base.delta(truth['truth'],pred,baseline,full=phase=='current');free=all(v['loss']==0 for v in effect['gain_loss'].values());r.update(execution_status='classifier_ViM174_'+phase+'_evaluated',EffectDelta=effect,original_class_gates=g,all_oldcorrect_loss_free=free,known_gate_passed=phase=='known'and free and all(q['passed']for q in g.values()),candidate_accepted_for_retention=phase=='current'and free and effect['verdict']=='UP',class_raw={n:int((raw&(truth['truth']==i)).sum())for i,n in enumerate(g)});r['files']['postseal_comparison']=persist(out,r,'postseal_same_original_comparison',dict(**v,truth=truth['truth']))
        if phase=='current':extra=int(((truth['truth']==2)&(baseline!=2)&raw).sum());r.update(newraw_UNA=extra,perfect_raw_retention_UNA_ceiling=2618+extra)
    except Exception as err:r.update(execution_status='execution_failed',error_type=type(err).__name__,error=str(err));raise
    finally:
        old.masked.restore_runtime_flags(before)
        for p,h in pins.items():files.require(files.item(p)['sha256']==h,'allfrozen bytes preserved '+p)
        r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for n in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+n)
    a=p.parse_args();desc=dict(path=str(Path(a.registry).resolve()),sha256=a.registry_sha256)if a.phase!='freeze'else None;value=freeze()if a.phase=='freeze'else run(a.phase,desc,None if a.phase=='known'else dict(path=str(Path(a.known_report).resolve()),sha256=a.known_sha256));print(json.dumps(value,ensure_ascii=False))
