"""V950 NSL2 owned115 / full2963 incremental adapter. No implicit execution.

Preparation reads JSON metadata. Numeric sources, NN weights and known labels
are opened only by separately invoked APIs. Current truth has no loading API.
"""
from __future__ import annotations
import hashlib
import io
import json
import sys
from pathlib import Path
import numpy as np
import torch

ROOT=Path('F:/shenpeng/Experiments/Chinese Science')
HOME=Path(__file__).resolve().parent
OLD=Path('E:/Experiment/software transcition/target99_v920_20261023/nsl2_parentUNA_return_runtime_v928')
TRAIN_REPORT=ROOT/'data/external_dev/processed/nsl2_fresh_full115_mhfd_20261012_v136d/train/report.json'
TRAIN_REGISTRY=ROOT/'tmp/nsl2_fresh_full115_mhfd_20261012_v136d/registry_before_fresh_original115_MHFD.json'
ENCODER_PRODUCER_REPORT=ROOT/'data/external_dev/processed/nsl2_fresh_field40_mhfd_20261012_v136/train/report.json'
OLD_REGISTRY=OLD/'v928_directional262_frontier_prediction/registry_before_any_new_known_prediction.json'
OLD_KNOWN_REPORT=OLD/'v928_directional262_frontier_prediction/known/report.json'
OLD_CURRENT_REPORT=OLD/'v928_directional262_frontier_prediction/current/report.json'
MANIFEST=HOME/'NSL2_SOURCE_ONLY_OWNED_ADAPTER_MANIFEST_V950.json'


def require(ok,reason):
    if not bool(ok):raise ValueError(reason)


def item(path):
    p=Path(path);return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())


def js(path):return json.loads(read(path))if isinstance(path,dict)else json.loads(Path(path).read_text(encoding='utf-8-sig'))


def read(descriptor):
    raw=Path(descriptor['path']).read_bytes();require(hashlib.sha256(raw).hexdigest()==descriptor['sha256'],'exact owned source bytes '+descriptor['path']);return raw


def arrays(descriptor,names):
    with np.load(io.BytesIO(read(descriptor)),allow_pickle=False)as a:return {k:a[k].copy()for k in names}


descriptor=item
raw=read


def manifest():
    m=js(MANIFEST)
    return dict(m,warm_owner=dict(checkpoint=m['checkpoint']),fixed_pair_metric_state=m['original_metric'])


def source_manifest():
    """JSON descriptors only: no new FIT/query numerical arrays or NN loads."""
    train,reg,old=js(TRAIN_REPORT),js(TRAIN_REGISTRY),js(OLD_REGISTRY)
    known,current=js(OLD_KNOWN_REPORT),js(OLD_CURRENT_REPORT)
    require(train['NN_fit']==1 and train['epochs_completed']==80 and train['policy']['trueUNA_fit']is False,'actual original own80 owner report')
    roles={}
    for role,cfg in old['role_providers'].items():
        p=current['files']['current_complete_prediction_before_truth']if role=='current'else known['files'][role+'_complete_prediction_before_truth']
        roles[role]=dict(original_frame=cfg['original_frame'],parent2963=p,source_owner=cfg['source_owner_key'])
    encoding_report=js(ENCODER_PRODUCER_REPORT)
    value=dict(schema='V950_NSL2_SOURCE_ONLY_INTEGRATION_ADAPTER',setting='NSL-KDD Setting2',
        original_fine_mapping_unchanged=True,native_fields=40,native_width=115,embedding_width=32,new_feature_dimension=147,
        new_layout='native115 unchanged + warm cleanembedding32/new genuine-source RMS',embedding_start=115,
        checkpoint=train['files']['model'],encoding=reg['assets']['encoding'],field_map=reg['field_map'],
        FIT_inputs=reg['assets']['FIT_inputs'],admitted=reg['assets']['admitted'],raw_material=reg['assets']['raw_material'],
        known_label_authority=old['known_label_authority'],original_metric=old['original147_metric'],
        roles=roles,source_frames=old['genuine_source147_frame'],
        owned_training_report=item(TRAIN_REPORT),owned_registry=item(TRAIN_REGISTRY),
        encoder_producer_report=item(ENCODER_PRODUCER_REPORT),
        resource=dict(prior_NN80_complete_report_wall_seconds=train['wall_seconds'],
            prior_encoder_producer_conservative_whole_wall_seconds=encoding_report['wall_seconds'],
            two_prior_nodes_conservative_upper_seconds=train['wall_seconds']+encoding_report['wall_seconds'],
            encoder_upper_contains_unused_group40_model=True,
            full2963_fallback_existing_ancestor_upper_seconds=1799.8606535584672,
            fallback_ancestor_direct_DAG_not_yet_reclosed=True,
            new_warm12_gradient_and_source_readout_support_RMS_CAL_costs='must measure after root resource admission',
            resource_qualified=False,training_authorized=False),
        source_only_preparation=True,neural_forward_executed=False,new_fit_executed=False,
        unknown_truth_loading_API=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    return value


def prepare_source_only():
    value=source_manifest();require(not MANIFEST.exists(),'one source-only manifest; preserve previous')
    HOME.mkdir(parents=True,exist_ok=True);MANIFEST.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');return item(MANIFEST)


def restore_warm(manifest=None):
    m=manifest or js(MANIFEST)
    if str(ROOT)not in sys.path:sys.path.insert(0,str(ROOT))
    from paper_open_set import nsl1_expanded_fit6000_maskaux_v1 as architecture
    encoder=json.loads(read(m['encoding']))
    require(encoder['width']==115 and encoder['genuine_stat_rows']==5967 and encoder['groups']==m['field_map']['groups'],'same own FIT encoder115/original40 field order, no duration insertion')
    ck=torch.load(io.BytesIO(read(m['checkpoint'])),map_location='cpu',weights_only=True)
    require(ck['epochs']==80 and ck['input_width']==115 and ck['field_map']==m['field_map'],'NSL2 own80 f602 field40 owner unchanged')
    fm=architecture.field_map_from_state(ck['field_map']);net=architecture.ExpandedWholeFieldMaskedMHFD(fm,9).cpu()
    net.load_state_dict(ck['state_dict'],strict=True);net.eval()
    return dict(net=net,field_columns=[g['selected_columns']for g in fm.groups],architecture=architecture,
        field_map=m['field_map'],checkpoint=m['checkpoint'],encoding=m['encoding'],cpu_threads=4)


def load_fit(manifest=None):
    m=manifest or js(MANIFEST);fit=arrays(m['FIT_inputs'],('ids','groups','fine','coarse','optimizer','x'))
    require(fit['x'].dtype==np.float32 and fit['x'].shape[1]==115 and np.isfinite(fit['x']).all(),'actual own native115 without duration or old embedding')
    require(np.array_equal(fit['coarse'],(fit['fine']>0).astype(np.int64))and np.array_equal(np.unique(fit['fine']),np.arange(9)),'original fine9 source map unchanged')
    index=fit['optimizer'];require(index.dtype.kind in'iu'and len(index)<=6000 and np.bincount(fit['fine'][index],minlength=9).min()>=20,'same original logical FIT cap/floor')
    require(len(np.unique(fit['groups']))==5967,'genuine5967; no copies as new statistics')
    # Lexicographic original ID selects one real representative per physical group.
    reps=[]
    for group in np.unique(fit['groups']):
        members=np.flatnonzero(fit['groups']==group);i=int(min(members,key=lambda j:str(fit['ids'][j])))
        require(np.all(fit['fine'][members]==fit['fine'][i])and np.array_equal(fit['x'][members],np.repeat(fit['x'][i:i+1],len(members),axis=0)),'same genuine parent native/fine across logical copies')
        reps.append(i)
    reps=np.asarray(reps,np.int64)
    genuine_index={str(fit['groups'][j]):i for i,j in enumerate(reps)}
    logical_to_genuine=np.asarray([genuine_index[str(g)]for g in fit['groups']],np.int64)
    return dict(training=dict(x=fit['x'],coarse=fit['coarse'],fine=fit['fine'],ids=fit['ids'],parent_ids=fit['groups'],optimizer_indices=index,logical_to_genuine=logical_to_genuine),
        source=dict(x=fit['x'][reps],fine=fit['fine'][reps],ids=fit['ids'][reps],groups=fit['groups'][reps]),
        trace=dict(logical_optimizer_count=len(index),genuine_count=len(reps),genuine_fine_counts=np.bincount(fit['fine'][reps],minlength=9).tolist(),logical_fine_counts=np.bincount(fit['fine'][index],minlength=9).tolist()))


def load_role(role,manifest=None):
    m=manifest or js(MANIFEST);key='known'if role=='CP'else role;cfg=m['roles'][key]
    frame=arrays(cfg['original_frame'],('ids','groups','representatives','inverse','original147'))
    parent=arrays(cfg['parent2963'],('ids','prediction','baseline2954'))
    require(np.array_equal(frame['ids'],parent['ids'])and len(np.unique(frame['ids']))==len(frame['ids']),'whole own2963 role IDs exact order')
    native=frame['original147'][frame['inverse'],:115]
    require(np.array_equal(native,native.astype(np.float32).astype(np.float64)),'original native115 exactly representable as owned NN float32')
    return dict(x=native.astype(np.float32),ids=frame['ids'],groups=frame['groups'],parent_prediction=parent['prediction'],comparison_prediction2954=parent['baseline2954'],
        representatives=frame['representatives'],inverse=frame['inverse'],role=role,
        native_first=True,embedding_start=115,source_owner=cfg['source_owner'])


def load_known_truth(role,manifest=None):
    """CAL fitting / late CP control only. No current or shadow-background labels."""
    require(role in ('CAL','known','CP'),'only actual CAL558 or CP721 known authority')
    m=manifest or js(MANIFEST);prefix='CAL'if role=='CAL'else'DEV'
    a=arrays(m['known_label_authority'],(prefix+'_ids',prefix+'_y_coarse'))
    return dict(ids=a[prefix+'_ids'],truth=a[prefix+'_y_coarse'])


def load_known_labels(role):
    out=load_known_truth(role)
    return dict(ids=out['ids'],coarse=out['truth'])


def fixed_pair_metric(manifest=None):
    m=manifest or js(MANIFEST)
    if str(ROOT)not in sys.path:sys.path.insert(0,str(ROOT))
    from paper_open_set.nsl2_fresh147_pair_metric_v136 import PaperVariationalPairMetric
    state=json.loads(read(m['original_metric']));metric=PaperVariationalPairMetric.from_state(state)
    require(metric.dimension==147,'original paid Eq9/10 dimension147 fixed prior')
    return metric


def make_dvc_callback(groups):
    """Original full147 DVC body on one physical feature group per row."""
    if str(ROOT)not in sys.path:sys.path.insert(0,str(ROOT))
    from paper_open_set.nsl2_fresh147_dvc_v136 import route_current_candidates
    groups=np.asarray(groups)
    def route(metric,new_features,candidates):
        z=np.asarray(new_features,np.float64);raw=np.asarray(candidates)
        require(z.shape==(len(groups),147)and raw.shape==(len(groups),)and raw.dtype==bool,'whole new147 DVC same rows')
        _,reps,inverse=np.unique(groups,return_index=True,return_inverse=True)
        require(np.array_equal(z,z[reps][inverse])and np.array_equal(raw,raw[reps][inverse]),'one physical group same new coordinates and evidence')
        reduced=route_current_candidates(metric,z[reps],raw[reps],seed=20261008)
        result={k:(v[inverse]if isinstance(v,np.ndarray)and v.shape==(len(reps),)else v)for k,v in reduced.items()}
        result['manifest']=dict(reduced['manifest'],same_new_geometry_source_metric=True,physical_groups=len(reps),flow_rows=len(groups),old_U_anchors_used=False,new_prior_metric_effect_unknown=True)
        return result
    return route


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--prepare-source-only',action='store_true');args=p.parse_args()
    require(args.prepare_source_only,'no training CLI before root full recipe/resource freeze')
    print(json.dumps(prepare_source_only(),ensure_ascii=False))
