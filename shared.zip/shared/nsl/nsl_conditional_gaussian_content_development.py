"""Two predeclared known-only Gaussian controls on the same pure NSL1 parent.

Known fit/calibration freeze before known-open preflight; rejection stops
before unknown query reconstruction. Full 3598-row development inference
recomputes the frozen parent from raw40 features. Historical oracle and truth
are reporting evidence only, opened after new forecasts are saved.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import time

import joblib
import numpy as np
import pandas as pd
import torch

from .config import NSL_FEATURE_COLUMNS, get_spec
from .data import sha256_file
from .model import infer
from .nsl_frozen_feature_pipeline import load_pipeline, checked_frame, selected_coordinates
from .known_ben_conditional_gaussian_content import MODES, fit, evaluate, coordinates, fit_anchors, route, check
from .replay_nsl_frozen_feature_pipeline import (reconstruct_query, forbid_inference_io, integer_gates,
    paired_delta, load_truth_after_save, align_oracle)
from .reporting import write_json, _open_matrix_text
from .compile_nsl_frozen_feature_pipeline import formal_snapshot


ROOT = Path(__file__).resolve().parents[1]
PARENT = ROOT / 'NSL-KDD Setting1/run/frozen_feature_pipeline_replay_recovered_20261004_v3'
SOURCE_SHA = '1b86d2f957b33082081bba410fe129b475efebcc13c9014c3f447c8271aadf95'
ROLE_SHA = '17b5a2f93ecb3475b237176fef9311b9e36efae58b1bd6406325199aff490c3b'


def known_frame(source, ids, *, read_truth):
    """Decode model cells; only known fit/cal truth is interpreted before fit."""
    ids = np.asarray(ids, dtype=str)
    prefix = 'nsl_kdd:original-source-train:'+SOURCE_SHA+':'
    rows = []
    for identifier in ids:
        parts = identifier.removeprefix(prefix).split(':')
        if not identifier.startswith(prefix) or len(parts) != 2 or not parts[0].isdigit():
            raise ValueError('exact original known-role IDs required')
        rows.append(int(parts[0]))
    if len(set(rows)) != len(rows) or not 20 <= len(rows) <= 6000:
        raise ValueError('unique capped original known source rows required')
    selected, wanted, observed = {}, set(rows), 0
    with Path(source).open('rb') as handle:
        for ordinal, line in enumerate(handle):
            observed += 1
            if ordinal not in wanted:
                continue
            cells = line.decode('utf8').strip().split(',')
            if len(cells) != 43:
                raise ValueError('exact original NSL43 source width required')
            selected[ordinal] = (cells[1:41], cells[41].strip().casefold().removesuffix('.') if read_truth else None)
    if observed != 125973 or len(selected) != len(rows):
        raise ValueError('bound original source row count differs')
    frame = checked_frame(pd.DataFrame([selected[row][0] for row in rows], columns=NSL_FEATURE_COLUMNS))
    if not read_truth:
        return frame, None, None
    families = np.asarray([selected[row][1] for row in rows], dtype=str)
    allowed = {'normal', *get_spec('NSL-KDD Setting1').known_families}
    counts = Counter(families.tolist())
    if set(counts) != allowed or any(counts[family] < 20 for family in allowed):
        raise ValueError('known-role BEN and every KNA family floor of twenty required')
    return frame, (families != 'normal').astype(np.int64), dict(sorted(counts.items()))


def stage_and_embedding(pipeline, frame):
    x = {name: selected_coordinates(pipeline.state['preprocessing'][name], frame) for name in ('original', 'log')}
    output = {name: infer(pipeline.state['models'][name], x[name], device=torch.device('cpu')) for name in x}
    stage = np.logical_and(*[output[name].attack_probability >= pipeline.state['thresholds'][name] for name in x]).astype(np.int64)
    return x, output['log'].embedding, stage


def extension(profile, anchors, embedding_scaler, features, embedding, stage, baseline):
    values = evaluate(profile, features, stage)
    q = coordinates(embedding, embedding_scaler, values['score'])
    dvc = route(profile, anchors, features, q, values['raw_candidate'])
    extra = (stage == 0)&(baseline == 0)&values['raw_candidate']&dvc['retained']
    final = baseline.copy()
    final[extra] = 2
    return dict(final=final, added_UNA=extra, score=values['score'], raw_score=values['raw_score'],
        raw_candidate=values['raw_candidate'], conditional_node=np.asarray([json.dumps(key) for key in values['nodes']], dtype=str),
        query_coordinates=q, **dvc)


def saved_arrays(result):
    return {name: value for name, value in result.items() if name != 'manifest'}


def compact_arm_summary(arms):
    """Keep complete DVC manifests in the saved report, outside terminal output."""
    result = {}
    for mode, arm in arms.items():
        effect = arm.get('EffectDelta', 'NOT_COMPARABLE')
        item = dict(status=arm['status'], EffectDelta=effect.get('EffectDelta') if isinstance(effect, dict) else effect,
            known_preflight_passed=arm.get('known_preflight_passed', False),
            reverse_exact=arm.get('extension_score_and_DVC_reverse_with_frozen_embeddings_exact', False))
        if isinstance(effect, dict):
            item['correct_count_delta_same_IDs'] = effect['correct_count_delta_same_IDs']
        if 'observed_development_gates' in arm:
            item['integer_gates'] = {label: {name: gate[name] for name in
                ('correct', 'support', 'required_for_99pct', 'passed_on_observed_rows_only')}
                for label, gate in arm['observed_development_gates'].items()}
        result[mode] = item
    return result


def run(compiled_directory, output_directory):
    compiled, output = Path(compiled_directory).resolve(), Path(output_directory).resolve()
    if ROOT not in compiled.parents or ROOT not in output.parents or output.exists():
        raise ValueError('contained frozen parent and fresh contained output required')
    started = time.perf_counter()
    formal, pins = formal_snapshot(ROOT), {}
    output.mkdir(parents=True, exist_ok=False)
    common = dict(status='FAIL_TARGET99', published=False, final_test_executed=False,
        independent_final_admitted=False, physical_event_independence_verified=False,
        accepted_baseline_replaced=False, new_neural_epochs=0, new_qualified_independent_Table1_flows=0,
        scope='fixed conditional and joint Gaussian controls on warmed same-lineage development, NOT independent final')

    def pin(path, expected=None):
        path = Path(path).resolve()
        digest = sha256_file(path)
        if expected is not None and digest != expected:
            raise ValueError('bound frozen input changed: '+str(path))
        pins[str(path)] = digest
        return path

    phase = 'bind_pure_parent_and_known_fit_calibration_only'
    try:
        manifest = json.loads(pin(compiled/'manifest.json').read_text(encoding='utf8'))
        pin(compiled/'pipeline.joblib', manifest['pipeline_sha256'])
        for path, digest in manifest['inference_source_sha256'].items():
            pin(path, digest)
        parent = json.loads(pin(PARENT/'report.json').read_text(encoding='utf8'))
        if (parent.get('verification_status') != 'PASS_RECOVERED_FEATURE_ONLY_REPLAY'
                or parent.get('published') is not False or parent.get('final_test_executed') is not False
                or not parent.get('exact_historical_2189_predictions_reproduced')):
            raise ValueError('verified full pure-feature 2189 parent required')
        for name in ('known_ben_conditional_gaussian_content.py', 'nsl_conditional_gaussian_content_development.py',
                     'test_known_ben_conditional_gaussian_content.py', 'replay_nsl_frozen_feature_pipeline.py'):
            pin(ROOT/'paper_open_set'/name)
        roles_path = pin(ROOT/'NSL-KDD Setting1/run/role_floor_original_train_20261002_v1/frozen_role_ids.npz', ROLE_SHA)
        with np.load(roles_path, allow_pickle=False) as archive:
            ids = {name: archive[name].astype(str).copy() for name in ('fit', 'calibration', 'open_known')}
        source = pin(ROOT/'data/external_dev/raw/nsl_kdd_full_github_jmnwong/KDDTrain+.txt', SOURCE_SHA)
        frames, truths, counts = {}, {}, {}
        for name in ('fit', 'calibration'):
            frames[name], truths[name], counts[name] = known_frame(source, ids[name], read_truth=True)
        pipeline = load_pipeline(compiled)
        representation, embeddings, stages = {}, {}, {}
        for name in ('fit', 'calibration'):
            representation[name], embeddings[name], stages[name] = stage_and_embedding(pipeline, frames[name])
        for name in ('original', 'log'):
            np.testing.assert_array_equal(representation['fit'][name], pipeline.state['references'][name])
        frozen_context = pipeline.state['context']['profile']
        fit_started = time.perf_counter()
        scaler = pipeline.state['context']['scaler']
        states, fit_failures = {}, {}
        for mode in MODES:
            try:
                profile = fit(frozen_context.feature_names, frozen_context.auth_splits,
                    representation['fit']['log'], truths['fit'], representation['calibration']['log'], truths['calibration'], mode=mode)
            except ValueError as error:
                if 'known BEN calibration order statistic' not in str(error) and 'known BEN conditional residual cutoff' not in str(error):
                    raise
                fit_failures[mode] = str(error)
                continue
            anchors = fit_anchors(profile, representation['fit']['log'], truths['fit'], embeddings['fit'],
                representation['calibration']['log'], truths['calibration'], embeddings['calibration'], scaler)
            states[mode] = dict(profile=profile, anchors=anchors)
        state = dict(arms=states, threshold_failures=fit_failures, embedding_scaler=scaler)
        joblib.dump(state, output/'known_only_conditional_policy.joblib', compress=3)
        policy_sha = sha256_file(output/'known_only_conditional_policy.joblib')
        np.savez_compressed(output/'known_source_coordinates_frozen_before_query.npz',
            fit_features=representation['fit']['log'], fit_truth=truths['fit'], fit_embedding=embeddings['fit'],
            calibration_features=representation['calibration']['log'], calibration_truth=truths['calibration'],
            calibration_embedding=embeddings['calibration'])
        known_source_sha = sha256_file(output/'known_source_coordinates_frozen_before_query.npz')
        write_json(output/'policy_frozen_before_query.json', dict(**common,
            fixed_comparison_plan=dict(arms=list(MODES), same_parent_and_every_query_row=True,
                conditional='C|P residual quadratic / C dimension',
                joint='P marginal quadratic + C|P residual quadratic, unit weights / joint dimension; exactly full joint OAS',
                threshold='separate single global knownBEN cutoff at ceil(.99*(m+1)); strict > cutoff',
                arm_or_context_or_threshold_chosen_from_unknown_scores=False,
                per_flow_or_per_family_variant_selection=False,
                known_gate_failure='do not score that arm on unknown development; retain NOT_COMPARABLE',
                comparison='each predeclared arm relative to same verified2189 parent; no mixed promotion'),
            profiles={mode: value['profile'].manifest for mode, value in states.items()},
            anchors={mode: value['anchors']['manifest'] for mode, value in states.items()},
            known_only_threshold_failures=fit_failures, known_role_family_counts=counts, policy_sha256=policy_sha,
            known_source_coordinates_sha256=known_source_sha, input_sha256=pins.copy(),
            fitting_seconds=time.perf_counter()-fit_started, known_calibration_all_BEN_used=True,
            held_known_open_or_unknown_features_used_for_fit=False, threshold_or_model_tuned_from_query=False,
            full_fit_LOO_or_max_neighbor_threshold_used=False, baseline_recomputed_from_raw40_features=True,
            frozen_parent_manifest_sha256=sha256_file(compiled/'manifest.json'),
            historical_development_inspection_precedes_design=True))

        phase = 'known_open_preflight_after_policy_freeze_before_unknown_reconstruction'
        if not states:
            result = dict(**common, execution_status='complete', experiment_status='ALL_FIXED_ARMS_REJECTED_KNOWN_CALIBRATION_THRESHOLD',
                arms={mode: dict(status='KNOWN_CALIBRATION_THRESHOLD_REJECTED', error=fit_failures[mode],
                    EffectDelta='NOT_COMPARABLE', unknown_development_scored=False) for mode in MODES},
                policy_sha256=policy_sha, input_sha256=pins, formal_outputs_sha256_unchanged=formal,
                wall_seconds=time.perf_counter()-started)
            if formal_snapshot(ROOT) != formal or any(sha256_file(Path(path)) != digest for path, digest in pins.items()):
                raise ValueError('frozen source/formal outputs changed during threshold rejection')
            write_json(output/'report.json', result); write_json(output/'status.json', result)
            print(json.dumps({key: result[key] for key in ('experiment_status', 'arms', 'wall_seconds')}), flush=True)
            return result
        known, _, _ = known_frame(source, ids['open_known'], read_truth=False)
        with forbid_inference_io() as attempts:
            base = pipeline.predict_frame(known)
            _, embedding, _ = stage_and_embedding(pipeline, known)
            known_results = {mode: extension(value['profile'], value['anchors'], scaler, base['log_model_features'], embedding, base['stage1'], base['final'])
                             for mode, value in states.items()}
        if attempts:
            raise ValueError('hidden file access during feature-only known preflight')
        known_arrays = {mode+'_'+name: value for mode, result in known_results.items() for name, value in saved_arrays(result).items()}
        np.savez_compressed(output/'known_open_predictions_before_truth.npz', sample_id=ids['open_known'],
            stage1=base['stage1'], baseline=base['final'], **known_arrays)
        _, known_truth, known_counts = known_frame(source, ids['open_known'], read_truth=True)
        baseline_gates = integer_gates(known_truth, base['final'])
        known_gates = {mode: integer_gates(known_truth, result['final']) for mode, result in known_results.items()}
        admitted = [mode for mode, gates in known_gates.items() if gates['BEN']['passed_on_observed_rows_only'] and gates['KNA']['passed_on_observed_rows_only']]
        known_effects = {mode: paired_delta(known_truth, base['final'], result['final']) for mode, result in known_results.items()}
        preflight = dict(**common, baseline_gates=baseline_gates, known_gates=known_gates,
            known_family_counts=known_counts, paired_known_only_effect=known_effects, known_admitted_arms=admitted,
            UNA_unevaluated=True, unknown_development_read=False,
            DVC={mode: result['manifest'] for mode, result in known_results.items()})
        write_json(output/'known_open_preflight.json', preflight)
        if not admitted:
            result = dict(**common, execution_status='complete', experiment_status='KNOWN_CONTROL_REJECTED_BEFORE_UNKNOWN_QUERY',
                observed_known_control_gates=known_gates, EffectDelta='NOT_COMPARABLE',
                paired_known_only_effect=known_effects, known_only_threshold_failures=fit_failures, policy_sha256=policy_sha,
                unknown_development_scored=False, input_sha256=pins, formal_outputs_sha256_unchanged=formal,
                wall_seconds=time.perf_counter()-started)
            if (formal_snapshot(ROOT) != formal or sha256_file(output/'known_only_conditional_policy.joblib') != policy_sha
                    or any(sha256_file(Path(path)) != digest for path, digest in pins.items())):
                raise ValueError('frozen outputs changed during known-only rejection')
            write_json(output/'report.json', result); write_json(output/'status.json', result)
            print(json.dumps({key: result[key] for key in ('experiment_status', 'observed_known_control_gates', 'wall_seconds')}), flush=True)
            return result

        phase = 'full_3598_row_feature_only_parent_and_conditional_query'
        query = reconstruct_query(ROOT, pin)
        if len(query['frame']) != 3598 or len(query['known_ids']) != 654:
            raise ValueError('all original 654 known +2944 unknown development rows required')
        with forbid_inference_io() as attempts:
            base = pipeline.predict_frame(query['frame'])
            _, embedding, stage = stage_and_embedding(pipeline, query['frame'])
            np.testing.assert_array_equal(stage, base['stage1'])
            candidates = {mode: extension(states[mode]['profile'], states[mode]['anchors'], scaler,
                base['log_model_features'], embedding, stage, base['final']) for mode in admitted}
        if attempts:
            raise ValueError('hidden I/O during complete current feature-only query prediction')
        predictions = output/'predictions_frozen_before_counting.npz'
        arrays = {mode+'_'+name: value for mode, result in candidates.items() for name, value in saved_arrays(result).items()}
        np.savez_compressed(predictions, sample_id=query['sample_id'].astype(str), stage1=stage, baseline=base['final'],
            model_query_features=base['log_model_features'], **arrays)
        prediction_sha = sha256_file(predictions)
        write_json(output/'prediction_seal_before_truth.json', dict(**common, predictions_sha256=prediction_sha,
            first_parent_and_candidate_predictions_recomputed_from_current_features=True,
            current_query_truth_or_historical_predictions_used=False, all_denominator_rows_preserved=True,
            all_known_policy_assets_and_thresholds_frozen_before_query=True))
        # This tests the new scorer/DVC on identical frozen embeddings. The
        # parent neural reverse proof is inherited from its verified receipt.
        with forbid_inference_io() as attempts:
            reverse = {mode: extension(states[mode]['profile'], states[mode]['anchors'], scaler,
                base['log_model_features'][::-1], embedding[::-1], stage[::-1], base['final'][::-1]) for mode in admitted}
        if attempts:
            raise ValueError('hidden I/O during extension reverse check')
        reverse_checks = {mode: {name: bool(np.array_equal(value, reverse[mode][name][::-1]))
            for name, value in saved_arrays(result).items()} for mode, result in candidates.items()}

        phase = 'count_held_truth_and_compare_parent_only_after_prediction_seal'
        truth, coverage = load_truth_after_save(query, predictions)
        historical_ids_path = pin(PARENT/'source_verified_report_identity_map.npz', parent['identity_recovery']['identity_map_sha256'])
        with np.load(historical_ids_path, allow_pickle=False) as archive:
            historical_ids = archive['historical_source_derived_sample_id'].copy()
        with np.load(pin(parent['original_prediction_archive'], parent['predictions_sha256']), allow_pickle=False) as archive:
            historical = align_oracle(query['sample_id'], historical_ids, archive['final'])
        np.testing.assert_array_equal(historical, base['final'])
        parent_gates = integer_gates(truth, historical)
        if parent_gates != parent['observed_development_gates']:
            raise ValueError('verified complete parent counts changed')
        gates = {mode: integer_gates(truth, result['final']) for mode, result in candidates.items()}
        for value in states.values(): check(value['profile'])
        if (sha256_file(predictions) != prediction_sha or sha256_file(output/'known_only_conditional_policy.joblib') != policy_sha
                or sha256_file(output/'known_source_coordinates_frozen_before_query.npz') != known_source_sha
                or formal_snapshot(ROOT) != formal or any(sha256_file(Path(path)) != digest for path, digest in pins.items())):
            raise ValueError('known policy, source, prediction seal or formal outputs changed')
        arms = {}
        for mode in MODES:
            if mode not in candidates:
                arms[mode] = dict(status='KNOWN_CALIBRATION_THRESHOLD_REJECTED' if mode in fit_failures else 'KNOWN_CONTROL_REJECTED',
                    EffectDelta='NOT_COMPARABLE', unknown_development_scored=False, known_gates=known_gates.get(mode),
                    threshold_error=fit_failures.get(mode), paired_known_only_effect=known_effects.get(mode))
                continue
            candidate = candidates[mode]
            matrix = np.bincount(3*candidate['final']+truth, minlength=9).reshape(3, 3)
            (output/(mode+'_Matrix.txt')).write_text('同谱系开发实验，非独立最终测试；FAIL_TARGET99; published=false\n'+_open_matrix_text(matrix), encoding='utf8')
            arms[mode] = dict(status='DEVELOPMENT_EVALUATED_NOT_FINAL', observed_development_gates=gates[mode],
                EffectDelta=paired_delta(truth, historical, candidate['final']), known_gates=known_gates[mode],
                known_preflight_passed=True, unknown_development_scored=True,
                extension_score_and_DVC_reverse_with_frozen_embeddings_exact=all(reverse_checks[mode].values()),
                DVC=candidate['manifest'])
        result = dict(**common, execution_status='complete', experiment_status='DEVELOPMENT_EVALUATED_NOT_FINAL',
            arms=arms, retained_parent_development_gates=parent_gates, all_query_denominator_rows_preserved=True,
            current_parent_predictions_exact_verified_pure_feature_parent=True,
            fixed_two_arm_plan_frozen_before_any_query=True, per_flow_or_family_variant_selection=False,
            extension_reverse_checks=reverse_checks, parent_full_pipeline_reverse_reexecuted_for_this_candidate=False,
            parent_reverse_receipt_inherited_NOT_reexecuted=True, coverage=coverage,
            policy_sha256=policy_sha, predictions_sha256=prediction_sha,
            known_source_coordinates_sha256=known_source_sha, new_covariance_fitted_known_BEN_only=True,
            threshold_fixed_from_all_known_BEN_calibration_only=True, no_query_threshold_or_context_search=True,
            historical_development_inspection_precedes_design=True,
            input_sha256=pins, formal_outputs_sha256_unchanged=formal, wall_seconds=time.perf_counter()-started)
        write_json(output/'report.json', result); write_json(output/'status.json', result)
        print(json.dumps(dict(arms=compact_arm_summary(arms), wall_seconds=result['wall_seconds'])), flush=True)
        return result
    except Exception as error:
        result = dict(**common, execution_status='execution_failed', failed_phase=phase, error=repr(error),
            input_sha256=pins, formal_outputs_unchanged=formal_snapshot(ROOT) == formal, wall_seconds=time.perf_counter()-started)
        write_json(output/'status.json', result)
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compiled-directory', required=True)
    parser.add_argument('--output-directory', required=True)
    arguments = parser.parse_args()
    run(arguments.compiled_directory, arguments.output_directory)
