"""Complete two-view query-vs-known reachability auxiliary, original149 DVC."""
import argparse,json,sys,time,types
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from . import nsl1_complete_two_view_query_reach_core_v186 as core
from . import nsl1_complete_two_view_lof149_v185 as previous
ROOT,files,require=previous.ROOT,previous.files,previous.require
old,nsl=previous.old,previous.nsl;MODULE='paper_open_set.nsl1_complete_two_view_query_reach149_v186'
DIR=ROOT/'tmp/nsl1_complete_two_view_query_reach149_20261012_v186';BASE=ROOT/'data/external_dev/processed/nsl1_complete_two_view_query_reach149_20261012_v186';REG=DIR/'registry_before_known.json'

def policy():
    return dict(schema_version='NSL1-allcomplete117-and149-query_vs_known_reachability-v186',hypotheses=1,
        geometry='Euclidean complete original149 FIT-scaled masked32+native117, and complete149[:,32:] native117; auxiliary only, main learned149 metric unchanged',
        reference='all5999 genuineBEN+KNA state exactly reused from fixedV185; selfexcluded true7 R7 remains without refit',
        novelty='known query reach=mean(max(query-known distance,R7 knownneighbor)); ownrole canonicalquery reach=mean(max(query-other distance,R7 queryneighbor)); bounded knownReach/(knownReach+queryReach) naturalbothzero0; complete117/149 geometricmean',
        canonical='same truephysicalnative groups once using earliestrow representative, no optimizer/copydensity amplification; allownrole CAL/CP/current nodes without family/truth masks; native117 equality verified, originalsemantic149 variations follow original canonicalmainrule',
        CAL='all656 trueknown oncefinite99 by coarse authority; same queryoriginalstage1 choosesbank, CP/current never cutoff/fit labels',
        DVC='newraw OR allV1782855 prediction2 includingerrors; original149 densityaffinity/reconstruction/secondarynoise unchanged; old2 protected complete merge',
        nonduplicate='V164/V178 use nearestknown vs seventhquery distance, V185 LOF only FIT neighborhood; V186 averages both7 reachabilities using neighbor-local R7 and complete two-view agreement; no contextual/scalar-only reuse',
        risk='batch transductive density, zeroBEN margin requires fullmixedcurrentgate',
        NN_fit=0,NN_forward=0,metric_fit=0,main_R7_refit=0,critic_fit=0,auxiliary_known_density_fit=0,query_fit=False,query_density_inference=True,trueUNA_fit=False,parameter_grid=False,timecap_coded=False,extension_not_verbatim_paper=True,status='FAIL_TARGET99',published=False,final_test_executed=False)

def closure():
    found={};seen=set();todo=[sys.modules[__name__]]
    while todo:
        m=todo.pop()
        if m is None or id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if not p or not Path(p).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        found[MODULE if m is sys.modules[__name__] else m.__name__]=files.item(p)
        for value in vars(m).values():
            child=value if isinstance(value,types.ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            if child is not None:todo.append(child)
    return found

def archive(a,keys,pins):return old.archive(a,keys,pins)
def save(out,r,key,value):return old.save(out,r,key,value)

def freeze():
    started=time.perf_counter();pins={};pr=files.item(previous.REG);p=files.js(pr,pins);kr=files.item(previous.BASE/'known/report.json');cr=files.item(previous.BASE/'current/report.json');k=files.js(kr,pins);c=files.js(cr,pins)
    require(k['known_gate_passed'] and c['prediction_sealed'] and c['original_class_gates']['UNA']['correct']==2855,'actualwhole2855 sourcepretruth sealedbaseline')
    a=dict(p['assets']);a.update(merge_known=k['files']['complete_dualLOF_prediction_beforetruth'],merge_current=c['files']['complete_dualLOF_prediction_beforetruth'],auxiliary_state=k['files']['state'])
    close_ref=files.item(previous.DIR/'NSL1_V185_COMPLETE_TWO_VIEW_LOF_COMPLETE_CLOSEOUT.json');close=files.js(close_ref,pins);review=p['ancestry_independent_review'];files.read(review,pins)
    for value in [*a.values(),*closure().values()]:files.read(value,pins)
    require(not REG.exists() and not BASE.exists(),'exclusive complete two_view_queryreach namespace');DIR.mkdir(parents=True,exist_ok=True)
    return files.write(REG,dict(policy=policy(),assets=a,sources=closure(),synthetic_contract=core.synthetic_contract(),previous_registry=pr,previous_known=kr,previous_current=cr,ancestry_closeout=close_ref,ancestry_independent_review=review,prior_necessary_preparation_seconds=close['actual_preparation']['necessary_allprep_plus_ancestry_seconds'],freeze_seconds=time.perf_counter()-started,input_sha256=pins,current_numeric_decodes=0))

def bind(ref,pins):
    r=files.js(ref,pins);require(r['policy']==policy() and r['sources']==closure(),'exact frozen complete two_view_queryreach recipe/source')
    for path,sha in r['input_sha256'].items():files.read(dict(path=path,sha256=sha),pins)
    return r

def pack_state(state):return {view+'_'+key:value for view,entry in state.items() for key,value in entry.items()}
def unpack_state(state):return {view:{key[len(view)+1:]:value for key,value in state.items() if key.startswith(view+'_')} for view in ('native117','whole149')}

def cue(reference,q,state,out,r,role):
    started=time.perf_counter();rep,inv=previous.previous.previous.collapse(q);score,proof=core.score(reference['Z149'],q['Z149'][rep],state);r['LOF_seconds'][role]=time.perf_counter()-started
    values=dict(ids=q['ids'],groups=q['groups'],Z149=q['Z149'],stage1=q['stage1'],representatives=rep,inverse=inv,score=score[inv],score_canonical=score,**pack_state(proof))
    r['files'][role+'_cue']=save(out,r,role+'_complete_two_view_queryreach_beforecut',values);return score[inv]

def run(phase,ref,knownref=None):
    started=time.perf_counter();pins={};reg=bind(ref,pins);control=None
    if phase=='current':
        control=files.js(knownref,pins);require(control['known_gate_passed'] and control['prediction_sealed'] and control['registry']==ref,'known integer control before current LOF features')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False);r=dict(policy=policy(),phase=phase,registry=ref,files={},LOF_seconds={},NN_fit=0,NN_forward=0,metric_fit=0,main_R7_refit=0,critic_fit=0,auxiliary_known_density_fit=0,CAL_fit=0,DVC=0,current_numeric_decodes=0,prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        with threadpool_limits(limits=4):
            a=reg['assets'];metric=nsl.learned.PaperVariationalPairMetric.from_state(files.js(a['metric'],pins));reference=archive(a['reference'],('ids','groups','Z149','original_indices','known_fine_membership'),pins)
            require(metric.dimension==149 and len(reference['ids'])==len(np.unique(reference['groups']))==5999,'genuine allknown5999 and unchanged main149');r['files'].update(metric=a['metric'],reference=a['reference'])
            if phase=='known':
                r['files']['state']=a['auxiliary_state'];loaded=archive(r['files']['state'],tuple(['ids','groups']+[view+'_'+key for view in ('native117','whole149') for key in ('neighbors','neighbor_distances','k_distance','mean_reach')]),pins);require(np.array_equal(loaded['ids'],reference['ids']),'exact genuineFIT savedreference order');state=unpack_state(loaded)
                mat=archive(a['material'],('fit_Z149','calibration_ids','calibration_groups','calibration_Z149','calibration_stage1'),pins);require(metric.to_state()['prefit_descriptor']['FIT_MHFD_Z']==nsl.base.descriptor(mat['fit_Z149']),'original149 complete FIT descriptor')
                cal={key:mat['calibration_'+key] for key in ('ids','groups','Z149','stage1')};score=cue(reference,cal,state,out,r,'CAL');labels=archive(a['encoded'],('calibration_ids','calibration_known_coarse'),pins);require(np.array_equal(cal['ids'],labels['calibration_ids']),'all656 trueknown exact CAL authority');rule=nsl.base.paper_route.calibrate_known_cutoffs(score,labels['calibration_known_coarse']);r['CAL_fit']=1;r['files']['rule']=files.write(out/'all656_trueknown_oncefinite99_two_view_queryreach.json',rule)
            else:
                r['files']['state']=control['files']['state'];loaded=archive(r['files']['state'],tuple(['ids','groups']+[view+'_'+key for view in ('native117','whole149') for key in ('neighbors','neighbor_distances','k_distance','mean_reach')]),pins);require(np.array_equal(loaded['ids'],reference['ids']),'actual samegenuine reference state order');state=unpack_state(loaded);rule=files.js(control['files']['rule'],pins);r['files']['rule']=control['files']['rule'];r['known_report']=knownref
            q,_,_=old.query('NSL1',phase,a,pins);merge=archive(a['merge_known' if phase=='known' else 'merge_current'],('ids','prediction'),pins);require(np.array_equal(q['ids'],merge['ids']),'samewhole2855 orderedmerge baseline');baseline=merge['prediction'];role='CP' if phase=='known' else 'current';r['current_numeric_decodes']=len(q['ids']) if phase=='current' else 0;score=cue(reference,q,state,out,r,role);raw=(baseline!=2)&nsl.base.paper_route.candidate_mask(score,q['stage1'],rule);density=raw|(baseline==2)
            def sink(name,value,manifest):save(out,r,name+'_DVC_beforetruth',value);r['files'][name+'_DVC_manifest']=files.write(out/(name+'_DVC_manifest.json'),manifest)
            routed,_=nsl.base.route_once(metric,q,density,sink);r['DVC']=1;retained=raw&routed['retained'];prediction=baseline.copy();prediction[retained]=2;require(np.all(prediction[baseline==2]==2),'allold2855 wholepred2 protected')
            values=dict(ids=q['ids'],prediction=prediction,baseline=baseline,score=score,raw=raw,density=density,retained=retained);sealed=save(out,r,'complete_two_view_queryreach_prediction_beforetruth',values);r['files']['seal']=files.write(out/'complete_two_view_queryreach_prediction_seal_beforetruth.json',dict(predictions=sealed,registry=ref,reference=a['reference'],rule=r['files']['rule'],metric=a['metric'],state=r['files']['state'],querytruth_used=False));r['prediction_sealed']=True
            truth=nsl.parent.previous.prefix_archive(a['baseline'],('ids','truth'),654,pins) if phase=='known' else archive(a['baseline'],('ids','truth'),pins);require(np.array_equal(truth['ids'],q['ids']),'complete two_view_queryreach prediction sealed before querytruth');y=truth['truth'];r['truth_opened']=True;gates,delta,binary=old.helpers.metrics(y,baseline,prediction)
            r.update(execution_status='NSL1_complete_two_view_queryreach_original149_'+phase+'_completed',original_class_gates=gates,EffectDelta=delta,binary_attack_detection=binary,known_gate_passed=all(gates[name]['passed'] for name in ('BEN','KNA')),candidate_accepted_for_retention=False,raw_by_trueclass={name:int(((y==c)&raw).sum()) for c,name in enumerate(('BEN','KNA','UNA'))},retained_by_trueclass={name:int(((y==c)&retained).sum()) for c,name in enumerate(('BEN','KNA','UNA'))});save(out,r,'postseal_complete_two_view_queryreach_pair',dict(**values,truth=y))
            if phase=='current':r['perfect_two_view_queryreach_raw_UNA_ceiling']=int(((y==2)&((baseline==2)|raw)).sum())
        for path,sha in pins.items():require(files.item(path)['sha256']==sha,'all frozen original assets and2855 wholeversions unchanged')
    except Exception as error:r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for key in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+key)
    args=p.parse_args();ref=None if args.registry is None else dict(path=str(Path(args.registry).resolve()),sha256=args.registry_sha256);known=None if args.known_report is None else dict(path=str(Path(args.known_report).resolve()),sha256=args.known_sha256)
    print(json.dumps(freeze() if args.phase=='freeze' else run(args.phase,ref,known)),flush=True)
