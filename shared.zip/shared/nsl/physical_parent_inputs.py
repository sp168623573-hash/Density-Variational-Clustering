"""Exact inherited physical data and whole parent; no fitting on import."""
from pathlib import Path
import importlib.util,hashlib,json,sys
INHERITED_INPUTS={'path': 'E:\\Experiment\\software transcition\\target99_v996_20261024\\nsl2\\inputs_v996.py', 'sha256': 'd0f9c9641f54053b8048ab9256333d51328cbb0a33023c3f66076079cf3bbea2'}
H=Path(__file__).resolve().parent;MANIFEST=H/'INPUT_MANIFEST_V1051.json'
if hashlib.sha256(Path(INHERITED_INPUTS['path']).read_bytes()).hexdigest()!=INHERITED_INPUTS['sha256']:raise ValueError('immutable input adapter')
sp=importlib.util.spec_from_file_location('V1051_original_data_'+INHERITED_INPUTS['sha256'],INHERITED_INPUTS['path']);O=importlib.util.module_from_spec(sp);sys.modules[sp.name]=O;sp.loader.exec_module(O)
require=O.require;descriptor=O.descriptor;raw=O.raw;js=O.js;arrays=O.arrays;module=O.module
def manifest():return json.loads(MANIFEST.read_text(encoding='utf-8'))
def load_source():
    s=O.load_source()
    return dict(s,native=s['native115'],Z=s['Z359'])
def load_role(role):
    q=O.load_role(role)
    return dict(q,native=q['native115'],Z=q['Z359'])
load_known_labels=O.load_known_labels;fixed_metric=O.fixed_metric
