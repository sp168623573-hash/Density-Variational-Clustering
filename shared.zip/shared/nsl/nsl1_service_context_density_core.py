"""BEN service reference balls vs unlabelled unresolved cohort occupancy.

Whole original149 learned distance is supplied by its frozen owner. This is
collective inference, not a BEN identity certificate or target-trained model.
"""
import numpy as np
from . import nsl1_collective_categorical_profile_core_v116 as contexts_core

MIN_FIT_CONTEXT = 20
MIN_QUERY_CONTEXT = 7
RADIUS_K = 7
COUNT_PRIOR = 1

def require(ok,reason):
    if not ok:raise ValueError(reason)

def service_contexts(x,mapping):
    x=np.asarray(x,np.float64)
    require(x.ndim==2 and x.shape[1]==117 and np.isfinite(x).all(),'complete native117, no protocol/flag deletion')
    # Validate full real encoder coverage; use only complete service block to
    # define application context. Other fields stay inside full149 distance.
    fields=contexts_core.categorical_mapping(mapping)
    service=[g for g in fields if g['field']=='service']
    require(len(service)==1,'one actual service field in encoder metadata')
    block=x[:,service[0]['selected_columns']]
    require(np.isin(block,(0,1)).all() and np.all(block.sum(1)==1),'full service onehot inclUNSEEN, no argmax repair')
    return block.argmax(1).astype(np.int64)[:,None]

def fit_background(z,groups,fine,mapping):
    z=np.asarray(z,np.float64);groups=np.asarray(groups);fine=np.asarray(fine)
    require(z.ndim==2 and z.shape[1]==149 and len(z)==len(groups)==len(fine),
            'genuine original149 group and known-fine identity')
    require(np.isfinite(z).all() and len(groups)==len(np.unique(groups)) and np.isin(fine,np.arange(9)).all(),
            'genuine known groups once, no optimizer-copy support or UNA')
    selected=np.flatnonzero(fine==0)
    context=service_contexts(z[selected,32:],mapping)
    vocabulary,code=np.unique(context,axis=0,return_inverse=True)
    counts=np.bincount(code,minlength=len(vocabulary))
    return dict(Z149=z[selected],groups=groups[selected],original_genuine_indices=selected,
                contexts1=context,vocabulary1=vocabulary,context_counts=counts,
                genuine_BEN_groups=np.asarray(len(selected)))

def infer(metric,z,groups,active,background,mapping):
    z=np.asarray(z,np.float64);groups=np.asarray(groups);active=np.asarray(active)
    require(z.ndim==2 and z.shape[1]==149 and np.isfinite(z).all()
            and groups.shape==active.shape==(len(z),) and active.dtype==bool,
            'complete149 query and label-blind active population')
    contexts=service_contexts(z[:,32:],mapping)
    unique,rep,inverse=np.unique(groups,return_index=True,return_inverse=True)
    require(np.array_equal(contexts,contexts[rep][inverse])
            and np.array_equal(z[:,32:],z[rep,32:][inverse])
            and np.array_equal(active,active[rep][inverse]),
            'same original nativegroup feature/context/scope; copies do not inflate')
    # np.unique chooses original first representative. All copied native117 are
    # equal; frozen embedding32 can contain harmless original producer role
    # arithmetic variation and is not recomputed, averaged or rounded here.
    n=len(rep);score=np.zeros(n);eligible=np.zeros(n,bool)
    radius=np.zeros(n);nfit=np.zeros(n,np.int64);nquery=np.zeros(n,np.int64)
    nfctx=np.zeros(n,np.int64);nqctx=np.zeros(n,np.int64)
    detail=[]
    for context,nf in zip(background['vocabulary1'],background['context_counts']):
        qix=np.flatnonzero(active[rep]&np.all(contexts[rep]==context,axis=1))
        fi=np.flatnonzero(np.all(background['contexts1']==context,axis=1))
        require(len(fi)==int(nf),'actual BEN context count')
        nfctx[qix]=len(fi);nqctx[qix]=len(qix)
        if len(fi)<MIN_FIT_CONTEXT or len(qix)<MIN_QUERY_CONTEXT:continue
        qz=z[rep[qix]];fz=background['Z149'][fi]
        distances=metric.pairwise_distances(qz,fz)
        ball=np.partition(distances,RADIUS_K-1,axis=1)[:,RADIUS_K-1]
        fitcount=(distances<=ball[:,None]).sum(axis=1)
        querydist=metric.pairwise_distances(qz)
        require(np.array_equal(np.diag(querydist),np.zeros(len(qix))),
                'owned distance actual self zero')
        othercount=(querydist<=ball[:,None]).sum(axis=1)-1
        require(np.all(fitcount>=RADIUS_K) and np.all(othercount>=0)
                and np.all(othercount<len(qix)),'all closed-ball ties/self excluded')
        local=np.log((othercount+COUNT_PRIOR)/len(qix))-np.log((fitcount+COUNT_PRIOR)/(len(fi)+COUNT_PRIOR))
        require(np.isfinite(local).all(),'finite actual count ratio, no decision epsilon')
        score[qix]=local;eligible[qix]=True;radius[qix]=ball
        nfit[qix]=fitcount;nquery[qix]=othercount
        detail.append(dict(contexts1=context,query_genuine_indices=qix,
                           query_original_indices=rep[qix],FIT_BEN_indices=fi,
                           query_to_FIT_distances=distances,query_pair_distances=querydist))
    result=dict(score=score[inverse],eligible=eligible[inverse],contexts1=contexts,
        nativegroup_representatives=rep,original_to_representative=inverse,
        genuine_score=score,genuine_eligible=eligible,radius=radius[inverse],
        FIT_ball_count=nfit[inverse],query_other_ball_count=nquery[inverse],
        FIT_context_count=nfctx[inverse],query_context_count=nqctx[inverse],
        active=active,genuine_nativegroups=np.asarray(len(unique)))
    return result,detail
