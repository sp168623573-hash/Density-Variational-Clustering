"""Frozen conditional-block overlay on the deprecated warm auth2188 cohort.

Only registered cached intermediate features, a frozen known-only profile and
one direct native41 feature read are consumed. No old2244 final predictions,
parameter fit, NN inference, fresh-data claim, or final-test admission.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
from pathlib import Path
import time
import zipfile
import joblib
import numpy as np
import pandas as pd
from . import known_ben_native40_conditional_blocks_v1 as core
from . import external_dev, nsl_frozen_category_vocabulary as vocabulary
from . import nsl_log_saved_state_loader as saved_log
from . import paper_scope
from .config import NSL_FEATURE_COLUMNS

ROOT=Path(__file__).resolve().parents[1]
RUN='NSL-KDD Setting1/run/'
AUTH=RUN+'auth_context_known_reference_guard_20261003_v1/'
WITNESS=RUN+'retained_BEN_content_density_witness_20261003_v1/'
NEW=RUN+'native40_conditional_blocks_known_fit_20261007_v1/'
KNOWN=RUN+'native40_conditional_blocks_known_parent_integration_20261007_v1/'
EMBED=RUN+'known_BEN_native41_mixture_nll_control_20261004_v2/'
CSV='data/external_dev/processed/nsl_all_table1_setting1/setting1_all_unknown.csv'
MANIFEST='data/external_dev/processed/nsl_all_table1_setting1/setting1_all_unknown.manifest.json'
RECORDS='tmp/target99_continuation_20261004_v6/actual_known_record_training_verification.json'
ROLES=RUN+'role_floor_log_numeric_20261002_v1/frozen_role_ids.npz'
PREPROCESSOR=RUN+'role_floor_log_numeric_20261002_v1/preprocessing_and_calibrator.joblib'
PINS={
 AUTH+'report.json':'48198bc0fd428d817d492dff03ff53f70e64f7c044f053324c5b7970aad89c74',
 AUTH+'predictions_frozen_before_counting.npz':'16d50c5abec52a362b2d310a3184152ae27a13771e6f9d21d9e3da4d1250396a',
 AUTH+'known_only_policy.joblib':'bc76a24843751e2aeb96f126a18132c2105fbeeb942ac510219214afb21cb0c8',
 WITNESS+'predictions_frozen_before_counting.npz':'1ee74aca1f48f1cd0745df837945f6fefaaf5152b550c3b842412f9ea782820d',
 WITNESS+'known_only_policy.joblib':'6d32a93d4ae22b6ef7f4fbbb8db632d85db6887c13a4d4d8189106602a3a4a5b',
 NEW+'report.json':'f757026b39442f7acb72276078f918db48313bbaa9c8da8e9844c973f941ec46',
 NEW+'conditional_blocks_policy_frozen_before_known_sanity.joblib':'6b34677fccc20cb0ded7006d98be74a3d12a510c07e50be27afbd6cb549fc211',
 KNOWN+'report.json':'d7e714026bd04e73a6d680af69422370c5066736124fc6737f457d3bc70572b9',
 KNOWN+'paired_known_predictions_before_truth.npz':'07574d3d9242898dd8d501cb726b5c81e35cfca0a2963e97135db8e900410e6a',
 EMBED+'predictions_frozen_before_counting.npz':'7811b9f313e9c055468a20f74f389cb02dcf81670aec31656e997624278f7861',
 CSV:'ccc2f709158403c8095b70a9e66e939ea41ba15d79b7880c02e4136967e53433',
 MANIFEST:'2b63f8ff7787059b45b17884fdf1b2082b5f2a31de468433742104df08cea2cb',
 RECORDS:'37028c26add68feec4ebbc1c037a5dc7b4bc9f31522f1c89c317abae93cb1b46',
 ROLES:'17b5a2f93ecb3475b237176fef9311b9e36efae58b1bd6406325199aff490c3b',
 PREPROCESSOR:'051e1c03eff48ea0e0f5bebc73e957955301ccd694470b6771058cf52a4a6a76',
 'paper_open_set/known_ben_native40_conditional_blocks_v1.py':'8544d4bf72614f7449a164251e44797bac6788e0a477cd3baaeb510fb292e30a',
}
FEATURE_MEMBERS=('sample_id','stage1','model_query_features','log_embedding')
KNOWN_MEMBERS=('sample_id','parent_stage1','new_block_score','new_score','new_signed_block_score',
 'new_raw_candidate','new_query_coordinates','new_retained','new_supported','new_first','new_second',
 'new_primary_anchor_free','new_secondary_anchor_free','new_suspected')
TRACE=('retained','supported','first','second','primary_anchor_free','secondary_anchor_free','suspected')
EXECUTED_CODE=('known_anchor_candidate_dvc.py','dependence_candidate_paper_dvc.py',
 'density_affinity_noise_revision.py','known_ben_conditional_gaussian_content.py',
 'known_ben_duration_response_gaussian.py','known_role_floor_log_development.py','config.py','data.py')
NATIVE_COLUMNS=('duration',)+NSL_FEATURE_COLUMNS
FAMILIES=paper_scope._COMPLETE_ROLES['NSL-KDD Setting1'][1]
CONFIG=dict(schema_version='NSL1-auth2188-frozen-conditional-blocks-warm-pair-v2',
 setting='NSL-KDD Setting1',query_rows=3598,known_rows=654,unknown_rows=2944,
 parent='exact auth2188 sealed final; never parent2244',
 score='unchanged frozen native35 four Schur conditional-block OAS profile and cutoff',
 coordinates='core.coordinates on sealed actual log_embedding; same float64 formula as frozen anchors',
 known_coordinate_branch='reuse frozen known DVC only if exact coordinates; otherwise one known654 DVC with cached raw/signed; fail before unknown numeric if known gates fail',
 warm_unknown_evaluate_calls=1,full_mixed_core_route_calls=1,NN_runs=0,fit_runs=0,threshold_search=False,
 semantic_parity='direct native41 -> frozen vocabulary/preprocessor/selector must exactly equal cached selected107; never inverse-transform107',
 overlay='authparent copy; only stage0 & authparent0 & newraw & retained become2',
 copied_rows_in_model_or_DVC=0,report_only_family_floor=20,
 report_copy_rule='after prediction seal, paper family order then original row/ID order; cycle original parents, no selection by correctness; zero-source families stay0',
 report_copy_rows=34,report_query_rows=3632,report_unknown_rows=2978,declared_unknown_families=list(FAMILIES),
 deprecated_warm_development=True,prior_truth_already_observed=True,fresh_blind_claim=False,
 official_Test_content_ancestry=True,zero_target_Test_ancestry_claim=False,
 formal_source_admission_changed=False,final_test_executed=False,full_Table1=False,published=False)

class WarmConditionalProtocolStop(ValueError):pass

def require(value,reason):
    if not value:raise WarmConditionalProtocolStop(reason)

def sha(value):return hashlib.sha256(value).hexdigest()
def array_descriptor(a):
    a=np.asarray(a);require(not a.dtype.hasobject,'object_array_forbidden')
    return dict(shape=list(a.shape),dtype=a.dtype.str,sha256=sha(np.ascontiguousarray(a).tobytes()))
def same(a,b,reason):require(array_descriptor(a)==array_descriptor(b),reason)
def same_ids(a,b,reason):
    """Source ID identity is independent of Unicode container padding width."""
    a,b=np.asarray(a),np.asarray(b)
    require(a.dtype.kind in 'US' and b.dtype.kind in 'US' and a.shape==b.shape
        and np.array_equal(a.astype(str),b.astype(str)),reason)
def checked(path,pins,expected=None):
    p=Path(path);p=(p if p.is_absolute() else ROOT/p).resolve()
    require(p.is_relative_to(ROOT) and p!=ROOT,'contained_registered_artifact')
    raw=p.read_bytes();h=sha(raw);wanted=expected or pins.get(str(p))
    require(wanted is not None and h==wanted,'artifact_pin_changed:'+str(p))
    require(pins.get(str(p),h)==h,'conflicting_pin');pins[str(p)]=h;return raw
def read_json(path,pins):return json.loads(checked(path,pins))
def descriptor(p):return dict(path=str(p),sha256=sha(p.read_bytes()))
def write_json(path,value,pins):
    require(not path.exists(),'fresh_output_required')
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    d=descriptor(path);pins[str(path)]=d['sha256'];return d
def archive(path,pins,keys):
    with np.load(io.BytesIO(checked(path,pins)),allow_pickle=False) as z:return {k:z[k].copy() for k in keys}
def prefix(path,pins,keys,rows=654,total=3598):
    """Decode only known rows from C/F NPY members; skip other numeric bytes."""
    result={}
    with zipfile.ZipFile(io.BytesIO(checked(path,pins))) as z:
        for key in keys:
            with z.open(key+'.npy') as f:
                version=np.lib.format.read_magic(f);shape,order,dtype=np.lib.format._read_array_header(f,version)
                require(len(shape) in (1,2) and shape[0]==total and rows<=total
                    and not dtype.hasobject and dtype.kind in 'Uifb','restricted_known_prefix_member')
                width=1 if len(shape)==1 else shape[1];size=dtype.itemsize
                if order and len(shape)==2:
                    a=np.empty((rows,width),dtype=dtype,order='F')
                    for col in range(width):
                        a[:,col]=np.frombuffer(f.read(rows*size),dtype=dtype,count=rows)
                        f.seek((total-rows)*size,1)
                else:
                    a=np.frombuffer(f.read(rows*width*size),dtype=dtype,count=rows*width).copy()
                    if len(shape)==2:a=a.reshape(rows,width)
                result[key]=a
    return result
def bind(values):return {k:array_descriptor(v) for k,v in values.items()}
def check_arrays(values,binding):require(bind(values)==binding,'sealed_live_array_changed')
def save_arrays(path,pins,values):
    before=bind(values)
    with path.open('xb') as f:np.savez_compressed(f,**values)
    d=descriptor(path);pins[str(path)]=d['sha256']
    check_arrays(values,before);check_arrays(archive(path,pins,tuple(values)),before)
    return d,before
def integrity(pins):
    for p,h in tuple(pins.items()):checked(p,pins,h)

def _gates(y,p):
    return {name:dict(correct=int(((y==c)&(p==c)).sum()),support=int((y==c).sum()),
        required=(99*int((y==c).sum())+99)//100,
        passed=bool((y==c).any() and 100*int(((y==c)&(p==c)).sum())>=99*int((y==c).sum())))
        for c,name in enumerate(('BEN','KNA','UNA'))}
def _effect(y,old,new):
    a,b=_gates(y,old),_gates(y,new);delta={k:b[k]['correct']-a[k]['correct'] for k in a};v=list(delta.values())
    direction='UP' if min(v)>=0 and max(v)>0 else 'DOWN' if max(v)<=0 and min(v)<0 else 'UNCHANGED' if not any(v) else 'MIXED'
    return dict(direction=direction,correct_count_delta=delta,same_complete3598_warm_cohort=True)
def _state_check(ctx,pins):
    core.check(ctx['state']['profile']);core._check_anchors(ctx['state']['profile'],ctx['state']['anchors'],ctx['state']['embedding_scaler'])
    require(joblib.hash((ctx['state'],ctx['auth_state'],ctx['preprocessor']))==ctx['state_hash'],'frozen_state_changed')
    integrity(pins)
def _read_metadata(pins):
    frame=pd.read_csv(io.BytesIO(checked(CSV,pins)),usecols=['raw_row_sha256','model_feature_sha256','role'],dtype=str)
    require(len(frame)==2944 and not frame.isna().any().any() and (frame.role=='external_unknown_dev').all(),'fixed2944_role_metadata')
    require(frame.raw_row_sha256.str.fullmatch('[0-9a-f]{64}').all()
        and frame.model_feature_sha256.str.fullmatch('[0-9a-f]{64}').all()
        and frame.raw_row_sha256.is_unique and frame.model_feature_sha256.is_unique,'unique_metadata_hashes')
    return frame
def _known_truth(ids,pins):
    r=read_json(RECORDS,pins);rows=r['known_record_inventory'];require(len(rows)==6000,'full_known_metadata6000')
    lookup={v['sample_id']:v for v in rows};require(len(lookup)==6000,'unique_known_record_inventory')
    found=[lookup[s] for s in ids];require(all(v['role']=='open_known' for v in found),'only_known_open_truth')
    allowed=set(paper_scope._COMPLETE_ROLES['NSL-KDD Setting1'][0])|{'BEN'}
    require(all(v['source_native_family'] in allowed for v in found),'only_registered_known_truth')
    require(all(v['original_label']==('normal' if v['source_native_family']=='BEN' else v['source_native_family'])
        for v in found),'registered_family_original_label_consistency')
    return np.asarray([int(v['source_native_family']!='BEN') for v in found],np.int64)

def _prepare(pins):
    for p,h in PINS.items():checked(p,pins,h)
    old=read_json(AUTH+'report.json',pins);fit=read_json(NEW+'report.json',pins);known=read_json(KNOWN+'report.json',pins)
    require(old['final_test_executed'] is False and old['published'] is False
        and [(old['observed_development_gates'][k]['correct'],old['observed_development_gates'][k]['support']) for k in ('BEN','KNA','UNA')]==[(316,319),(335,335),(2188,2944)],'exact_auth2188_parent')
    require(fit['execution_status']=='complete' and fit['fit_rows']==4034 and fit['calibration_rows']==656
        and fit['new_unknown_DEV_or_originalTest_or_checkpoint_decodes']==0 and fit['new_neural_training_epochs']==0,'frozen_known_only_fit_receipt')
    require(known['execution_status']=='complete' and known['known_rows']==654 and known['raw_candidates']==4
        and known['DVC_retained']==0 and known['unknown_or_Test_or_checkpoint_rows_decoded']==0,'known_only_integration_receipt')
    state=joblib.load(io.BytesIO(checked(NEW+'conditional_blocks_policy_frozen_before_known_sanity.joblib',pins)))
    auth=joblib.load(io.BytesIO(checked(AUTH+'known_only_policy.joblib',pins)))
    witness=joblib.load(io.BytesIO(checked(WITNESS+'known_only_policy.joblib',pins)))
    require(set(state)=={'profile','anchors','embedding_scaler'},'fixed_three_key_policy')
    require(joblib.hash(state['embedding_scaler'])==joblib.hash(auth['scaler'])==joblib.hash(witness['scaler']),'same_original_embedding_scaler')
    require(state['profile'].feature_names==auth['profile'].feature_names and state['profile'].auth_splits==auth['profile'].auth_splits,'same_selected107_and_auth_semantics')
    prep=saved_log.load_saved_log_state(ROOT/PREPROCESSOR)
    names=tuple(np.asarray(prep['preprocessor'].get_feature_names_out(),dtype=str)[prep['variance_mask']][prep['selector'].get_support()])
    require(names==state['profile'].feature_names,'same_frozen_preprocessor_selected_names')
    k=archive(KNOWN+'paired_known_predictions_before_truth.npz',pins,KNOWN_MEMBERS)
    w=prefix(WITNESS+'predictions_frozen_before_counting.npz',pins,('sample_id','stage1','model_query_features'))
    e=prefix(EMBED+'predictions_frozen_before_counting.npz',pins,FEATURE_MEMBERS)
    a=prefix(AUTH+'predictions_frozen_before_counting.npz',pins,('sample_id','final'))
    roles=archive(ROLES,pins,('open_known',))
    for value in (w['sample_id'],e['sample_id'],a['sample_id'],roles['open_known']):same(k['sample_id'],value,'same_known654_ID_order')
    same(k['parent_stage1'],w['stage1'],'same_known_stage');same(e['stage1'],w['stage1'],'same_feature_cache_stage')
    same(e['model_query_features'],w['model_query_features'],'same_known_selected107')
    require(k['new_score'].shape==(654,) and k['new_signed_block_score'].shape==(654,4)
        and k['new_query_coordinates'].shape==(654,36) and np.isfinite(k['new_score']).all(),'complete_known_score_cache')
    same(k['new_score'],k['new_signed_block_score'].max(axis=1),'known_signed_max_score')
    same(k['new_raw_candidate'],(w['stage1']==0)&(k['new_score']>state['profile'].cutoff),'known_fixed_raw_formula')
    require(int(k['new_raw_candidate'].sum())==4 and not k['new_retained'].any(),'known_raw4_retained0')
    y=_known_truth(k['sample_id'].tolist(),pins);require([(int((y==c).sum())) for c in (0,1)]==[319,335],'old_known_support')
    ctx=dict(state=state,auth_state=auth,preprocessor=prep,known=k,known_features=w,known_embedding=e,
        known_parent=a['final'],known_truth=y,old_report=old,metadata=_read_metadata(pins))
    ctx['state_hash']=joblib.hash((state,auth,prep));_state_check(ctx,pins);return ctx

def _native_features(ctx,pins):
    # pandas usecols never materializes source label/difficulty columns.
    frame=pd.read_csv(io.BytesIO(checked(CSV,pins)),usecols=list(NATIVE_COLUMNS),low_memory=False)
    frame=core.checked_native41(frame.loc[:,list(NATIVE_COLUMNS)])
    require(len(frame)==2944,'exact_native2944')
    actual=external_dev.normalized_feature_fingerprints(frame,NSL_FEATURE_COLUMNS).to_numpy(dtype=str)
    same(actual,ctx['metadata'].model_feature_sha256.to_numpy(dtype=str),'native40_metadata_hash_semantics')
    adapter=vocabulary.FrozenCategoryVocabulary(ctx['preprocessor']['preprocessor'])
    encoded=np.asarray(adapter.transform(frame),dtype=np.float32)
    selected=np.asarray(ctx['preprocessor']['selector'].transform(encoded[:,ctx['preprocessor']['variance_mask']]),dtype=np.float32)
    return frame,selected
def _truth_after_seal(ctx,ids,pins):
    meta=pd.read_csv(io.BytesIO(checked(CSV,pins)),usecols=['raw_row_sha256','paper_target_family','role'],dtype=str)
    same_ids(('dev:'+meta.raw_row_sha256).to_numpy(dtype=str),ids[654:],'truth_unknown_ID_order')
    require((meta.role=='external_unknown_dev').all() and set(meta.paper_target_family)<=set(FAMILIES),'registered_partial_UNA_family_scope')
    return np.r_[ctx['known_truth'],np.full(2944,2,np.int64)],meta.paper_target_family.to_numpy(dtype=str)
def _report_copies(families):
    rows=list(range(3598))
    for family in FAMILIES:
        parent=np.flatnonzero(families==family)+654
        if len(parent):rows.extend(int(parent[j%len(parent)]) for j in range(max(0,20-len(parent))))
    require(len(rows)==3632,'fixed34_report_only_copy_rows')
    return np.asarray(rows,np.int64)
def _validate_route(route,raw,rows):
    for k in TRACE:require(np.asarray(route[k]).shape==(rows,),'aligned_route_'+k)
    expected=raw&route['supported']&((~route['suspected']&route['primary_anchor_free'])|
        (route['suspected']&(route['primary_anchor_free']|(route['first']<0))&route['secondary_anchor_free']))
    same(expected,route['retained'],'original_anchored_retention_formula')

def run_warm_pair(*,output_directory):
    out=Path(output_directory).resolve();require(out.is_relative_to(ROOT) and out!=ROOT,'new_workspace_child')
    out.mkdir(parents=True,exist_ok=False);start=time.perf_counter();pins={};stage='load_frozen_known_states_and_known_prefix_only'
    r=dict(configuration=CONFIG,status='FAIL_TARGET99',published=False,final_test_executed=False,full_Table1=False,
        accepted_baseline_replaced=False,promotion_status='NOT_PROMOTED',execution_status='not_completed',metrics_evaluated=False,
        deprecated_warm_development=True,unknown_numeric_open_attempted=False,unknown_numeric_opened=False,
        unknown_evaluate_started=False,unknown_evaluate_returned=False,known_DVC_calls=0,full_DVC_started=False,
        full_DVC_returned=False,predictions_sealed=False,unknown_truth_open_attempted=False,unknown_truth_opened=False,
        NN_runs=0,fit_runs=0,threshold_search=False)
    try:
        ctx=_prepare(pins)
        for module in (core,external_dev,vocabulary,saved_log,paper_scope):
            p=Path(module.__file__).resolve();pins[str(p)]=sha(p.read_bytes())
        for name in EXECUTED_CODE:
            p=Path(__file__).with_name(name).resolve();pins[str(p)]=sha(p.read_bytes())
        p=Path(__file__).resolve();pins[str(p)]=sha(p.read_bytes())
        policy=write_json(out/'policy_before_unknown_numeric.json',dict(configuration=CONFIG,profile_manifest=ctx['state']['profile'].manifest,
            anchors_manifest=ctx['state']['anchors']['manifest'],frozen_state_hash=ctx['state_hash'],input_sha256=dict(pins),
            legacy_data_code_pin_drift='Old receipt data.py pin is not asserted current; no prepare_data or old role-floor bundle is called. Current data.py is pinned only for the saved-state loader hash utility.',
            historical_higher_warm_UNA=dict(correct=2244,support=2944,used_as_parent=False,prediction_array_read=False)),pins)
        r['policy']=policy;stage='known654_coordinate_parity_or_new_known_DVC'
        k=ctx['known'];state=ctx['state'];q=core.coordinates(ctx['known_embedding']['log_embedding'],state['embedding_scaler'],k['new_signed_block_score'])
        known_values=dict(ids=k['sample_id'],selected=ctx['known_features']['model_query_features'],coordinates=q,
            raw=k['new_raw_candidate'],signed=k['new_signed_block_score'],score=k['new_score'],parent=ctx['known_parent'])
        known_input,kbind=save_arrays(out/'known_context_before_optional_DVC.npz',pins,known_values)
        exact=array_descriptor(q)==array_descriptor(k['new_query_coordinates'])
        if exact:
            route={key:k['new_'+key].copy() for key in TRACE};route['manifest']=dict(reused_known_integration=True)
        else:
            _state_check(ctx,pins);check_arrays(known_values,kbind)
            r['known_DVC_calls']=1
            route=core.route(state['profile'],state['anchors'],known_values['selected'],q,k['new_raw_candidate'])
        check_arrays(known_values,kbind);_validate_route(route,k['new_raw_candidate'],654)
        kp=ctx['known_parent'].copy();kp[(ctx['known_features']['stage1']==0)&(kp==0)&k['new_raw_candidate']&route['retained']]=2
        gates=_gates(ctx['known_truth'],kp);passed=all(gates[n]['passed'] for n in ('BEN','KNA'))
        known_decisions,_=save_arrays(out/'known_predictions_before_unknown.npz',pins,dict(ids=k['sample_id'],prediction=kp,**{key:route[key] for key in TRACE}))
        receipt=write_json(out/'known_preflight.json',dict(exact_old_known_coordinates=exact,known_DVC_calls=r['known_DVC_calls'],
            context=known_input,predictions=known_decisions,gates=gates,passed=passed,DVC=route['manifest']),pins)
        r.update(known_preflight=receipt,known_gates=gates,known_passed=passed,known_coordinate_cache_exact=exact)
        require(passed,'known_preflight_failed_unknown_unopened');_state_check(ctx,pins)
        stage='open_fixed_warm_features_after_policy_and_known_gate'
        r.update(unknown_numeric_open_attempted=True,unknown_numeric_opened=None)
        w=archive(WITNESS+'predictions_frozen_before_counting.npz',pins,('sample_id','stage1','model_query_features'))
        e=archive(EMBED+'predictions_frozen_before_counting.npz',pins,FEATURE_MEMBERS)
        a=archive(AUTH+'predictions_frozen_before_counting.npz',pins,('sample_id','final'))
        same(w['sample_id'],e['sample_id'],'full_cached_ID_order');same(w['sample_id'],a['sample_id'],'auth_cached_ID_order')
        same(w['model_query_features'],e['model_query_features'],'full_selected107_parity');same(w['stage1'],e['stage1'],'full_stage_parity')
        same(w['sample_id'][:654],k['sample_id'],'known_prefix_order')
        same_ids(w['sample_id'][654:],('dev:'+ctx['metadata'].raw_row_sha256).to_numpy(dtype=str),'registered2944_metadata_order')
        require(w['model_query_features'].shape==(3598,107) and e['log_embedding'].shape==(3598,32)
            and len(set(w['sample_id'].tolist()))==3598,'complete3598_feature_cache')
        native,forward=_native_features(ctx,pins)
        same(forward,w['model_query_features'][654:],'native41_forward_exact_cached107')
        r['unknown_numeric_opened']=True
        stage='single_unknown_evaluate_frozen_conditional_blocks';r['unknown_evaluate_started']=True
        values=core.evaluate(state['profile'],w['model_query_features'][654:],native,w['stage1'][654:]);r['unknown_evaluate_returned']=True
        score=np.r_[k['new_score'],values['score']];signed=np.vstack([k['new_signed_block_score'],values['signed_block_score']])
        raw=np.r_[k['new_raw_candidate'],values['raw_candidate']];blocks=np.vstack([k['new_block_score'],values['block_score']])
        same(raw,(w['stage1']==0)&(score>state['profile'].cutoff),'complete_fixed_candidate_formula')
        same(score,signed.max(axis=1),'complete_signed_score_formula')
        coordinates=core.coordinates(e['log_embedding'],state['embedding_scaler'],signed)
        same(coordinates[:654],q,'same_known_geometry_in_full_query')
        live=dict(ids=w['sample_id'],selected=w['model_query_features'],embedding=e['log_embedding'],stage1=w['stage1'],
            parent=a['final'],coordinates=coordinates,score=score,signed=signed,block_score=blocks,raw=raw)
        stage='seal_actual_full_query_before_single_DVC'
        query,bound=save_arrays(out/'full_query_before_DVC.npz',pins,live)
        r['query_inputs']=query;_state_check(ctx,pins);check_arrays(live,bound)
        stage='single_full3598_conditional_DVC';r['full_DVC_started']=True
        route=core.route(state['profile'],state['anchors'],live['selected'],live['coordinates'],live['raw']);r['full_DVC_returned']=True
        check_arrays(live,bound);_validate_route(route,raw,3598)
        added=(live['stage1']==0)&(live['parent']==0)&raw&route['retained'];final=live['parent'].copy();final[added]=2
        stage='seal_predictions_before_unknown_truth'
        pred,_=save_arrays(out/'paired_predictions_before_truth.npz',pins,dict(ids=live['ids'],baseline=live['parent'],candidate=final,added=added,**{key:route[key] for key in TRACE}))
        seal=write_json(out/'prediction_seal_before_truth.json',dict(predictions=pred,query=query,policy=policy,
            known_receipt=receipt,DVC=route['manifest'],unknown_truth_opened_this_run=False,input_sha256=dict(pins)),pins)
        r.update(predictions_sealed=True,predictions=pred,prediction_seal=seal,DVC=route['manifest'])
        stage='open_reused_truth_after_seal';r.update(unknown_truth_open_attempted=True,unknown_truth_opened=None)
        truth,families=_truth_after_seal(ctx,live['ids'],pins);r['unknown_truth_opened']=True
        stage='evaluate_original_and_report_only_copies'
        before,after=_gates(truth,live['parent']),_gates(truth,final)
        require([(before[k]['correct'],before[k]['support']) for k in ('BEN','KNA','UNA')]==[(316,319),(335,335),(2188,2944)],'exact_auth2188_baseline_metric')
        copies=_report_copies(families)
        evaluation,_=save_arrays(out/'evaluation_and_report_only_copy_mapping.npz',pins,dict(ids=live['ids'],truth=truth,unknown_family=families,reporting_indices=copies))
        _state_check(ctx,pins);check_arrays(live,bound)
        r.update(execution_status='auth2188_frozen_conditional_blocks_warm_pair_completed',metrics_evaluated=True,
            original_class_gates=dict(baseline=before,candidate=after),EffectDelta=_effect(truth,live['parent'],final),
            historical_higher_warm_UNA=2244,candidate_exceeds_historical_2244=bool(after['UNA']['correct']>2244),
            candidate_minus_historical_2244=int(after['UNA']['correct']-2244),original_UNA_target99_required=2915,
            reporting_with_family_min20_gates=dict(baseline=_gates(truth[copies],live['parent'][copies]),candidate=_gates(truth[copies],final[copies])),
            evaluation=evaluation,raw_candidates=int(raw.sum()),unknown_raw_candidates=int(raw[654:].sum()),
            unknown_never_raw=int((~raw[654:]).sum()),retained=int(route['retained'].sum()),added_UNA=int(added.sum()),
            original_rows=3598,original_UNA_rows=2944,reporting_rows=3632,reporting_UNA_rows=2978,report_only_copies=34,density_copies=0,
            per_family={f:dict(support=int((families==f).sum()),raw=int((raw[654:]&(families==f)).sum()),
                baseline_correct=int(((live['parent'][654:]==2)&(families==f)).sum()),candidate_correct=int(((final[654:]==2)&(families==f)).sum())) for f in FAMILIES},
            missing_unknown_families=[f for f in FAMILIES if not np.any(families==f)],unknown_evaluate_calls=1,full_core_route_calls=1,
            native_new889_and_CIC_comparisons='NOT_COMPARABLE',outcome='DEPRECATED_WARM_PARTIAL_DEV_NOT_FINAL')
    except Exception as error:
        r.update(execution_status='protocol_stop' if isinstance(error,(WarmConditionalProtocolStop,ValueError)) else 'execution_failed',
            failed_stage=stage,error_type=type(error).__name__,error_message=str(error),metrics_evaluated=False,outcome='NOT_EVALUATED')
    r.update(input_sha256=dict(pins),wall_seconds=time.perf_counter()-start)
    write_json(out/'report.json',r,{});return r

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output-directory',required=True)
    r=run_warm_pair(output_directory=p.parse_args(argv).output_directory)
    print(json.dumps({k:r.get(k) for k in ('execution_status','original_class_gates','EffectDelta','unknown_raw_candidates','failed_stage','error_message')},ensure_ascii=False))
    return 0 if r['metrics_evaluated'] else 2 if r['execution_status']=='protocol_stop' else 1

if __name__=='__main__':raise SystemExit(main())
