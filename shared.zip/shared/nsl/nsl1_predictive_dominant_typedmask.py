"""Warm known FIT6000 MHFD with predictive-dominant typed41 reconstruction.

Reuse the completed all41 encoder/material, without preprocessing replay.
Warm the separately preserved typed41 shared encoder/decoder on clean classification and masked-only
reconstruction, respecting the original field kind. Clean forward is the original MHFD forward; the fine head is
auxiliary. All old primary classifiers and accepted development results stay
outside this module. No unknown archive, novelty score, metric or DVC is used.
"""
from __future__ import annotations

import argparse
from collections import Counter
import copy
import hashlib
import json
import io
import os
from pathlib import Path
import time

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import WeightedRandomSampler

from . import config, model
from . import whole_field_mask_mhfd_v1 as mask_core
from . import nsl1_expanded_fit6000_all41_v2 as previous
from . import nsl1_expanded_fit6000_typedmask_v1 as warm
from . import artifact_api_preflight_v52 as preflight
from . import nsl1_all_native41_known80_v1 as known_checks
from . import nsl2_clean_known_material_training_v1 as output_io

files, ROOT = previous.files, previous.ROOT
SCHEMA = 'NSL1-known6000-warm-predictive-dominant-typed41-full117-final80-v53'
BASE = ROOT/'data/external_dev/processed/nsl1_predictive_dominant_typedmask_20261011_v53'
REGDIR = ROOT/'tmp/nsl1_predictive_dominant_typedmask_20261011_v53'
ROLES = dict(previous.ROLES)
FAMILIES = previous.FAMILIES
EPOCHS, SEED, BATCH = 80, 20261011, 128
WARM_TRAIN=dict(path=str(warm.BASE/"train/report.json"),sha256="eb12bf83b1f1667983ba84dc9e45d3d60b9da674b36eb1317317782f146edf87")
MATERIAL = dict(previous.REUSABLE_MATERIAL)
ENCODER = dict(path=str(ROOT/'data/external_dev/processed/nsl1_expanded_FIT6000_all41_20261009_v1/material/new_unique_FIT6000_all41_encoder_before_training.json'),
    sha256='a21c148d34efa77307160c03c341ebb80440c5c33354fe2655c1a8b2b53e6781')
RAW_FIELDS = set(previous.RAW_FIELDS)


def recipe():
    return dict(schema_version=SCHEMA, setting='NSL-KDD Setting1', classes=list(FAMILIES),
        FIT_original=6000, FIT_optimizer_draws_per_epoch=6000, introduced_traffic_copies=0,
        roles=ROLES, input_width=117, original_fields=41,
        material_reused=MATERIAL, encoder_reused=ENCODER, preprocessing_replay=False,
        model='original MHFD attention/gate/position/CNN/BiLSTM/embedding/known heads/single decoder plus41 learned field-mask tokens',
        loss='0.1 clean coarseCE + .035 clean fineCE(smoothing.01) + 1.0 typed masked-only loss: categorical whole-field CE / numeric SmoothL1',
        fine_head='known-only auxiliary head; no fine-derived primary classification',
        mask='one balanced uniformly scheduled original field per optimizer draw; its entire categorical onehot including UNSEEN is hidden',
        masked_target_units='all encoded-coordinate units1; original numeric log1p/RMS units are reused from sealed encoder; no new target-unit fit',
        masked_reduction='per-draw categorical CE across exactly one original categorical group, numeric mean SmoothL1 inside one original numeric field; then optimizer draw mean',
        shared_mask_gradient='attention/gate/position/CNN/BiLSTM/embedding/single decoder and mask tokens',
        optimizer='AdamW .001 wd.0002 cosine80 min.0001 clip5', sampling='existing hierarchical weights, replacement, exactly6000 optimizer draws per epoch',
        epochs=EPOCHS, batch_size=BATCH, seed=SEED, CPU_threads=4,
        checkpoint='fixed final80; no per-epoch heldout forward or checkpoint selection',
        objective_comparison='warm sealed typedmask6000 full state; predictive dominant balanced whole41 objective seed20261011, fixed80 final epoch; all original weights preserved separately',
        warm_train=WARM_TRAIN, old_weights_transferred=True,
        clean_inference='exact original MHFD forward; raw5 and original returned7 persisted before caller guards',
        CAL='only known calibration656 labels; one coarse_head diagnostic threshold, sealed before OPEN654; never main decision or policy tuning',
        OPEN='fixed original654 IDs; labels opened only after complete prediction seal',
        CUBLAS_WORKSPACE_CONFIG=':4096:8 supplied before ROOT Python process starts',
        primary_baseline_replaced=False, auxiliary_candidate_only=True,
        prior2579_2596_2598_2601_unchanged=True, unknown_numeric_reads=False,
        novelty_score_fit_or_DVC=False, fresh_masked_objective=False, warm_predictive_dominant_objective=True, original_MHFD_spine=True,
        new_paper_formula_claim=False, independent_final_admitted=False,
        status='FAIL_TARGET99', published=False, final_test_executed=False)


def field_map_state(encoder):
    """Convert sealed original-field metadata; never infer groups from width."""
    unsigned=copy.deepcopy(encoder); signature=unsigned.pop('state_sha256')
    files.require(signature==files.digest(unsigned), 'sealed encoder state signature')
    names, groups = encoder['encoded_feature_names'], encoder['original_field_groups']
    files.require(encoder['input_width']==len(names)==117 and len(groups)==len(encoder['fields'])==41
        and [g['field'] for g in groups]==encoder['fields']
        and encoder['no_variance_pruning'] is True and encoder['no_target_fit'] is True,
        'actual complete117 and original41 encoder field metadata')
    mapping=[]
    for group in groups:
        for column in group['selected_columns']:
            mapping.append(dict(selected_index=column, encoded_name=names[column], original_field=group['field']))
    mapping.sort(key=lambda row:row['selected_index'])
    return dict(schema_version=mask_core.FIELD_SCHEMA, selected_width=117, nonempty_group_count=41,
        groups=copy.deepcopy(groups), selected_column_mapping=mapping,
        encoder_file=ENCODER, encoder_state_sha256=signature,
        target_units=[1.0]*117, target_units_fit=False,
        status='FAIL_TARGET99', published=False, final_test_executed=False)


def field_map_from_state(state):
    raw=json.dumps(state,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    return mask_core.FrozenFieldMap(raw,expected_file_sha256=hashlib.sha256(raw).hexdigest())


def balanced_schedule(rows, field_count, *, epoch):
    files.require(type(rows) is int and 0<rows<=6000 and type(field_count) is int and field_count>=2
        and type(epoch) is int and 0<=epoch<EPOCHS, 'fixed80 balanced original-field schedule')
    rng=np.random.default_rng(np.random.SeedSequence([SEED,epoch]))
    names=rng.permutation(field_count)
    return names[np.arange(rows)%field_count][rng.permutation(rows)].astype(np.int64)


class ExpandedWholeFieldMaskedMHFD(mask_core.WholeFieldMaskedMHFD):
    """Full mask state is required; ordinary MHFD checkpoints cannot load."""
    def _query_features(self,features):
        files.require(isinstance(features,torch.Tensor) and features.dtype==torch.float32
            and features.ndim==2 and features.shape[1]==self.feature_count and len(features)>0
            and bool(torch.isfinite(features).all()), 'finite query coordinates; no total query row cap')

    def forward(self,features):
        self._query_features(features);self._map_check()
        return model.MHFDNetwork.forward(self,features)

    def masked_tokens(self,features,fields):
        self._query_features(features)
        hidden=self.masked_columns(fields,len(features),features.device)
        visible=torch.where(hidden,torch.zeros_like(features),features)
        tokens=visible.unsqueeze(-1)*self.feature_weight.unsqueeze(0)+self.feature_bias.unsqueeze(0)+self.position.unsqueeze(0)
        missing=self.field_mask_tokens[fields.to(features.device)].unsqueeze(1)+self.position.unsqueeze(0)
        return torch.where(hidden.unsqueeze(-1),missing,tokens),hidden

    def load_state_dict(self,state_dict,strict=True,assign=False):
        files.require(strict is True and {'field_mask_tokens','field_column_membership'}<=set(state_dict),
            'full masked network state with41 field tokens and membership required')
        result=super().load_state_dict(state_dict,strict=True,assign=assign)
        self._map_check()
        return result


def typed_reconstruction_loss(prediction,target,masked_fields,groups):
    files.require(prediction.shape==target.shape and prediction.ndim==2
        and masked_fields.shape==(len(target),) and masked_fields.dtype==torch.int64
        and bool(torch.isfinite(prediction).all()) and bool(torch.isfinite(target).all()),
        'finite typed masked predictions and detached original targets')
    result=prediction.new_zeros(len(target),dtype=torch.float32)
    seen=0
    for field,group in enumerate(groups):
        rows=masked_fields==field
        count=int(rows.sum())
        if not count: continue
        columns=group['selected_columns'];truth=target.detach()[rows][:,columns].float()
        output=prediction[rows][:,columns].float()
        if group['kind']=='categorical':
            files.require(bool(((truth==0)|(truth==1)).all()) and bool((truth.sum(dim=1)==1).all()),
                'categorical CE uses actual complete onehot including reserved UNSEEN')
            loss=F.cross_entropy(output,truth.argmax(dim=1),reduction='none')
        else:
            files.require(group['kind']=='numeric','explicit encoder field kind required')
            loss=F.smooth_l1_loss(output,truth,reduction='none').mean(dim=1)
        result[rows]=loss;seen+=count
    files.require(seen==len(target),'exactly one full original field per optimizer draw')
    return result.mean()


def known_objective(net,x,coarse,fine,masked_fields,*,roles):
    files.require(isinstance(net,ExpandedWholeFieldMaskedMHFD),'own full masked network required')
    mask_core._features(x,net.feature_count)
    files.require(tuple(roles)==('FIT',)*len(x), 'known FIT optimization only')
    files.require(coarse.dtype==fine.dtype==torch.int64 and coarse.shape==fine.shape==(len(x),)
        and bool(((coarse==0)|(coarse==1)).all())
        and bool(((fine>=0)&(fine<net.fine_head.out_features)).all())
        and torch.equal(coarse==0,fine==0), 'known BEN0/KNA1 and fine labels only')
    clean=net(x); masked=net.forward_masked(x,masked_fields)
    reconstruction=typed_reconstruction_loss(masked['reconstruction'],x,masked_fields,net.field_map.groups)
    coarse_loss=F.cross_entropy(clean['coarse_logits'],coarse)
    fine_loss=F.cross_entropy(clean['fine_logits'],fine,label_smoothing=.01)
    loss=.1*coarse_loss+.035*fine_loss+reconstruction
    files.require(bool(torch.isfinite(loss)), 'finite clean classification and masked-only loss')
    return dict(loss=loss,coarse_loss=coarse_loss,fine_loss=fine_loss,masked_loss=reconstruction)


def freeze():
    pins={}; mat=files.js(MATERIAL,pins)
    producer=files.js(WARM_TRAIN,pins);warmreg=files.js(producer["registry"],pins)
    files.require(producer["epochs_completed"]==80 and producer["unknown_numeric_decodes"]==0 and producer["material"]==MATERIAL,"completed known-only typed warm producer")
    check=preflight.preflight(json_contracts=[dict(asset=WARM_TRAIN,paths=[("files","model"),("registry",),("model_state_sha256",),("training_seconds",),("runtime_during_training",)])],api_contracts=[dict(module_name="paper_open_set.nsl1_expanded_fit6000_typedmask_v1",function_name="typed_reconstruction_loss",required_parameters=["prediction","target","masked_fields","groups"],source_sha256=files.item(warm.__file__)["sha256"])])
    files.read(producer["files"]["model"],pins)
    reusable=dict(report=MATERIAL,material_registry=previous.REUSABLE_MATERIAL_REGISTRY)
    previous.require_reusable_material(MATERIAL,mat,dict(reusable_material=reusable))
    original=files.js(previous.REUSABLE_MATERIAL_REGISTRY,pins)
    unsigned=dict(original); signature=unsigned.pop('registry_sha256')
    files.require(signature==files.digest(unsigned) and original['sources']['caller']==previous.PRESERVED_V1_SOURCE,
        'original producer registry, not new preprocessing')
    files.read(previous.PRESERVED_V1_SOURCE,pins)
    files.require(mat['encoder']==ENCODER, 'exact existing sealed encoder117')
    encoder=files.js(ENCODER,pins); field_state=field_map_state(encoder); field_map=field_map_from_state(field_state)
    numeric=[g for g in field_map.groups if g['kind']=='numeric']
    categorical=[g for g in field_map.groups if g['kind']=='categorical']
    files.require(len(numeric)==38 and len(categorical)==3
        and sum(len(g['selected_columns']) for g in categorical)==79
        and sum(len(g['selected_columns']) for g in numeric)==38,
        'complete numeric38 and categorical76 plus all3 UNSEEN coordinates')
    headers=previous.metadata_headers(mat['encoded_inputs'],pins)
    native_headers=previous.metadata_headers(mat['known_source'],pins)
    for role,n in ROLES.items():
        files.require(headers[role+'_features']['shape']==[n,117]
            and native_headers[role+'_native41']['shape']==[n,41]
            and headers[role+'_ids']==native_headers[role+'_ids'], 'existing frozen role/header:'+role)
    protocol=files.js(previous.PROTOCOL,pins)
    files.require(protocol['test_total_cap'] is None and protocol['actual_FIT_optimizer_cap']==6000,
        'current no test-total cap and optimizer draw budget6000')
    for path,wanted in mat['input_sha256'].items():files.read(dict(path=path,sha256=wanted),pins)
    REGDIR.mkdir(parents=True,exist_ok=True)
    field_asset=files.write(REGDIR/'encoder117_original41_fieldmap_before_training.json',field_state)
    reg=dict(schema_version=SCHEMA+'-registry',policy=recipe(),reusable_material=reusable,
        assets=dict(encoded_inputs=mat['encoded_inputs'],encoder=ENCODER,field_map=field_asset,
            original_encoded_labels=original['assets']['original_encoded_labels'],warm_model=producer["files"]["model"]),
        warm_train=WARM_TRAIN,warm_registry=producer["registry"],warm_model_state_sha256=producer["model_state_sha256"],warm_training_seconds=producer["training_seconds"],artifact_API_preflight=check,
        encoder_state_sha256=encoder['state_sha256'],field_map_canonical_sha256=field_map.file_sha256,
        material_headers=headers,native_headers=native_headers,protocol=previous.PROTOCOL,
        sources={Path(module.__file__).name:files.item(module.__file__) for module in
            (previous,known_checks,mask_core,model,config,output_io,files,warm,preflight)},
        outputs=dict(train=str(BASE/'train')),input_sha256=pins,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    reg['sources']['caller']=files.item(__file__);reg['registry_sha256']=files.digest(reg)
    return files.write(REGDIR/'registry_before_known_only_mask_training.json',reg)


def bind(registry,sha,pins):
    reg=files.js(dict(path=str(Path(registry).resolve()),sha256=sha),pins)
    unsigned=dict(reg); signature=unsigned.pop('registry_sha256')
    files.require(signature==files.digest(unsigned) and reg['policy']==recipe()
        and reg['sources']['caller']==files.item(__file__), 'frozen own maskaux contract')
    for asset in reg['sources'].values():files.read(asset,pins)
    return reg


def capture_runtime_flags():
    return previous.capture_runtime_flags()


def restore_runtime_flags(before):
    return previous.restore_runtime_flags(before)


def save_epoch_history(out,history,epoch,report):
    files.require(type(epoch) is int and 1<=epoch<=EPOCHS and len(history)==epoch
        and history[-1]['epoch']==epoch, 'actual completed unique epoch journal')
    name='history_through_epoch'+format(epoch,'03d')
    asset=files.write(out/(name+'.json'),history)
    report['files'][name]=asset; report['files']['history_latest']=asset
    return asset


def infer_once(net,x,role,out,report):
    """Same raw5/returned7 capture; base model infer has its original contract."""
    return previous.infer_once(net,x,role,out,report)


def checkpoint_signature(reg):
    return dict(schema_version=SCHEMA+'-full-network-signature',model_class='ExpandedWholeFieldMaskedMHFD',
        input_dim=117,fine_classes=list(FAMILIES),seed=SEED,epochs_completed=EPOCHS,
        field_count=41,encoder=reg['assets']['encoder'],encoder_state_sha256=reg['encoder_state_sha256'],
        field_map=reg['assets']['field_map'],field_map_canonical_sha256=reg['field_map_canonical_sha256'],
        objective=recipe(),mandatory_new_state=['field_mask_tokens','field_column_membership'])


def load_checkpoint(checkpoint,reg,field_map,*,device):
    files.require(checkpoint['network_signature']==checkpoint_signature(reg), 'exact full maskaux network signature')
    files.require(field_map.file_sha256==reg['field_map_canonical_sha256'], 'exact checkpoint frozen field map')
    net=ExpandedWholeFieldMaskedMHFD(field_map,9).to(device)
    net.load_state_dict(checkpoint['state_dict'],strict=True)
    files.require(output_io.state_digest(net)==checkpoint['model_state_sha256'], 'complete masked tensor state SHA')
    net.eval();return net


def train(registry,sha,material_report=None,material_sha=None):
    started=time.perf_counter();pins={};reg=bind(registry,sha,pins)
    ma=MATERIAL if material_report is None else dict(path=str(Path(material_report).resolve()),sha256=material_sha)
    mat=files.js(ma,pins);previous.require_reusable_material(ma,mat,reg)
    out=Path(reg['outputs']['train']);files.require(out==BASE/'train' and not out.exists(),'fresh exclusive maskaux training')
    out.mkdir(parents=True);before=capture_runtime_flags()
    report=dict(schema_version=SCHEMA,registry=dict(path=str(Path(registry).resolve()),sha256=sha),material=ma,
        policy=recipe(),files={},counts=dict(training_runs=0,optimizer_steps=0,epochs_completed=0,
            training_clean_forwards=0,training_masked_forwards=0,known_infer_attempts=0,known_infer_returns=0,
            known_forward_batches=0,unknown_forward=0,mask_score=0,metric_fit=0,DVC=0),
        unknown_numeric_decodes=0,OPEN_truth_opened=False,accepted_baseline_replaced=False,
        input_width=117,field_count=41,runtime_before=before,preprocessor_replay=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        files.require(os.environ.get('CUBLAS_WORKSPACE_CONFIG')==':4096:8',
            'ROOT must set CUBLAS_WORKSPACE_CONFIG before starting Python')
        data=previous.archive(mat['encoded_inputs'],tuple(role+'_'+key for role in ROLES for key in ('features','ids'))
            +tuple(role+'_'+key for role in ('fit','calibration') for key in ('known_fine','known_coarse')),pins)
        all_ids=np.concatenate([data[role+'_ids'] for role in ROLES]).astype(str)
        files.require(len(all_ids)==len(set(all_ids.tolist()))==7966,'exact7966 disjoint original role IDs')
        for role,n in ROLES.items():
            files.require(data[role+'_features'].shape==(n,117) and data[role+'_features'].dtype==np.float32
                and np.isfinite(data[role+'_features']).all(), 'fixed original all117 role:'+role)
        counts=Counter(data['fit_known_fine'].tolist())
        files.require(set(counts)==set(range(9)) and min(counts.values())>=20, 'all9 genuine known FIT families')
        field_state=files.js(reg['assets']['field_map'],pins)
        field_map=field_map_from_state(field_state)
        files.require(field_map.file_sha256==reg['field_map_canonical_sha256'] and field_map.count==41,
            'same entire41 frozen field map')
        report['files']['prefit']=files.write(out/'policy_before_model_initialization.json',dict(policy=recipe(),
            network_signature=checkpoint_signature(reg),material=ma,FIT_optimizer_draws=6000,
            role_ID_descriptors={role:known_checks.array_descriptor(data[role+'_ids']) for role in ROLES},
            target_units_refit=False,old_weights_transferred=True,warm_model=reg["assets"]["warm_model"],OPEN_labels_used=False))
        torch.set_num_threads(4);model.set_seed(SEED)
        torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
        report['runtime_during_training']=capture_runtime_flags()
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        net=ExpandedWholeFieldMaskedMHFD(field_map,9).to(device)
        warm_checkpoint=torch.load(io.BytesIO(files.read(reg["assets"]["warm_model"],pins)),map_location="cpu",weights_only=True)
        warmreg=files.js(reg["warm_registry"],pins)
        files.require(warm_checkpoint["network_signature"]==warm.checkpoint_signature(warmreg),"exact prior typedmask full-state signature")
        net.load_state_dict(warm_checkpoint["state_dict"],strict=True)
        files.require(output_io.state_digest(net)==reg["warm_model_state_sha256"],"warm full-state tensors exact before new optimization")
        initial=output_io.state_digest(net)
        sampler=WeightedRandomSampler(model._hierarchical_sample_weights(data['fit_known_fine']),num_samples=6000,
            replacement=True,generator=torch.Generator().manual_seed(SEED))
        optimizer=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.0002)
        scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=EPOCHS,eta_min=.0001)
        scaler=torch.amp.GradScaler('cuda',enabled=device.type=='cuda')
        history=[];training_start=time.perf_counter();report['counts']['training_runs']=1
        for epoch in range(1,EPOCHS+1):
            net.train();draws=np.asarray(list(sampler),np.int64);masked=balanced_schedule(6000,41,epoch=epoch-1)
            files.require(draws.shape==(6000,) and int(draws.min())>=0 and int(draws.max())<6000,
                'known optimizer draws including replacement copies capped6000')
            totals={key:0. for key in ('loss','coarse_loss','fine_loss','masked_loss')};seen=0
            for start in range(0,6000,BATCH):
                indexes=draws[start:start+BATCH]
                xb=torch.from_numpy(data['fit_features'][indexes].copy()).to(device)
                cb=torch.from_numpy(data['fit_known_coarse'][indexes].astype(np.int64,copy=True)).to(device)
                fb=torch.from_numpy(data['fit_known_fine'][indexes].astype(np.int64,copy=True)).to(device)
                masks=torch.from_numpy(masked[start:start+len(indexes)].copy()).to(device)
                optimizer.zero_grad(set_to_none=True)
                with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=device.type=='cuda'):
                    losses=known_objective(net,xb,cb,fb,masks,roles=['FIT']*len(indexes))
                scaler.scale(losses['loss']).backward();scaler.unscale_(optimizer)
                nn.utils.clip_grad_norm_(net.parameters(),5.)
                scaler.step(optimizer);scaler.update();seen+=len(indexes)
                report['counts']['optimizer_steps']+=1
                report['counts']['training_clean_forwards']+=1;report['counts']['training_masked_forwards']+=1
                for key in totals:totals[key]+=float(losses[key].detach())*len(indexes)
            files.require(seen==6000,'exact6000 optimizer examples including sampler repeats')
            scheduler.step();hist=dict(epoch=epoch,optimizer_draws=seen,
                learning_rate=scheduler.get_last_lr()[0],mask_group_counts=np.bincount(masked,minlength=41).tolist(),
                **{key:totals[key]/seen for key in totals})
            history.append(hist);report['counts']['epochs_completed']=epoch;save_epoch_history(out,history,epoch,report)
            if epoch==1 or epoch%10==0:
                print(f'[NSL1 predictive-dominant full117 v53] epoch={epoch}/80 loss={totals["loss"]/seen:.6f} elapsed={time.perf_counter()-training_start:.1f}s',flush=True)
        report['files']['history']=files.write(out/'actual_history_completed_epochs.json',history)
        report.update(training_seconds=time.perf_counter()-training_start,epochs_completed=EPOCHS,device=str(device),inherited_training_seconds=reg['warm_training_seconds'])
        files.require(report['counts']['optimizer_steps']==EPOCHS*((6000+BATCH-1)//BATCH), 'actual80 complete optimizer steps')
        state=output_io.state_digest(net);files.require(state!=initial,'shared full-network state updated')
        checkpoint=out/'predictive_dominant_full117_typed41_maskaux_final80_v53.pt'
        with checkpoint.open('xb') as stream:
            torch.save(dict(network_signature=checkpoint_signature(reg),
                state_dict={name:value.detach().cpu().clone() for name,value in net.state_dict().items()},
                model_state_sha256=state,initial_model_state_sha256=initial),stream)
        report['files']['model']=files.item(checkpoint);report['model_state_sha256']=state;net.eval()
        outputs={role:infer_once(net,data[role+'_features'],role,out,report) for role in ('fit','checkpoint','calibration')}
        theta,metrics=model.choose_coarse_threshold(data['calibration_known_coarse'],outputs['calibration']['coarse_attack_probability'])
        report['files']['threshold']=files.write(out/'CAL656_coarse_threshold_sealed_before_OPEN654.json',dict(threshold=float(theta),
            CAL_IDs=known_checks.array_descriptor(data['calibration_ids']),calibration_metrics=metrics,
            model=report['files']['model'],probability='coarse_attack_probability only; fine head auxiliary',OPEN_truth_used=False,
            status='FAIL_TARGET99',published=False,final_test_executed=False))
        outputs['open_known']=infer_once(net,data['open_known_features'],'open_known',out,report)
        predictions={role+'_prediction':(values['coarse_attack_probability']>=theta).astype(np.int64) for role,values in outputs.items()}
        predictions.update({role+'_ids':data[role+'_ids'] for role in outputs})
        pa=previous.save(out,'complete_known_predictions_before_OPEN_truth',predictions,report)
        report['files']['prediction_seal']=files.write(out/'known_predictions_sealed_before_OPEN_truth.json',dict(predictions=pa,
            model=report['files']['model'],threshold=report['files']['threshold'],OPEN_truth_opened=False,
            primary_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False))
        truth=previous.archive(reg['assets']['original_encoded_labels'],('open_known_ids','open_known_known_coarse'),pins)
        report['OPEN_truth_opened']=True
        files.require(np.array_equal(truth['open_known_ids'],data['open_known_ids']), 'fixed original654 evaluation IDs')
        gates={role:known_checks.bridge_gates(data[role+'_known_coarse'],predictions[role+'_prediction']) for role in ('fit','calibration')}
        gates['open_known']=known_checks.bridge_gates(truth['open_known_known_coarse'],predictions['open_known_prediction'])
        report.update(execution_status='warm_predictive_dominant_full117_typed41_known_evaluated',coarse_threshold=float(theta),
            known_class_gates=gates,known654_passed=all(value['passed'] for value in gates['open_known'].values()),
            primary_classification_unchanged=True,fine_head_auxiliary=True,unknown_performance_measured=False,
            future_geometry_requires_own_signature_metric_and_CAL=True)
        files.require(output_io.state_digest(net)==state,'maskaux weights unchanged during clean inference')
        for path,wanted in pins.items():files.require(files.item(path)['sha256']==wanted,'source and inputs unchanged')
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        after=restore_runtime_flags(before)
        report['runtime_restoration']=dict(before=before,after=after,all_flags_restored=after==before)
        report['wall_seconds']=time.perf_counter()-started;report['input_sha256']=pins
        files.write(out/'report.json',report)
    return files.item(out/'report.json')


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=('freeze','train'),required=True)
    parser.add_argument('--registry');parser.add_argument('--registry-sha256')
    parser.add_argument('--material-report');parser.add_argument('--material-sha256')
    args=parser.parse_args(argv)
    result=freeze() if args.phase=='freeze' else train(args.registry,args.registry_sha256,args.material_report,args.material_sha256)
    print(json.dumps(result))


if __name__=='__main__':main()
