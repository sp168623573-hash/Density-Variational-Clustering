"""Complete R10 parent and frozen V980 geometry; no truth in prediction APIs."""
from pathlib import Path
import os,sys,hashlib,json,time
for k in('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='2'
os.environ['CUDA_VISIBLE_DEVICES']='-1'
import numpy as np
from sklearn.cluster import DBSCAN
H=Path(__file__).resolve().parent;I=H.parents[1];R10=I/'baseline_continuation_20261030_r10/nsl2';R17=I/'mhfd_field_measure_20261031_r17/nsl2'
sys.path.insert(0,str(R10))
import source_anchored_witness as K
M=K.M;STATUS=M.STATUS
A=M.mod(I/'target99_v1051_20261024/nsl2/inputs_v1051.py','r18_inputs')
D=M.mod(I/'target99_v980_20261023/density/full_context_candidate_mutual_dvc_v980.py','r18_frozen_density')
LEGACY=I/'target99_v980_20261023/nsl2/actual_once';CACHE=H/'geometry_cache'

def arrdesc(a):
    a=np.ascontiguousarray(a);return dict(shape=list(a.shape),dtype=str(a.dtype),sha256=hashlib.sha256(a.tobytes()).hexdigest())

def save(p,**kw):
    with Path(p).open('xb')as f:np.savez_compressed(f,**{k:v for k,v in kw.items()if isinstance(v,np.ndarray)and not v.dtype.hasobject})
    return M.desc(p)

def role_data(role):
    q=A.load_role(role);phase='current-predict'if role=='current'else'known-predict'
    parentpath=R10/'actual_once'/phase/(role+'_prediction_before_truth.npz')
    with np.load(parentpath,allow_pickle=False)as a:parent={k:a[k]for k in a.files}
    assert np.array_equal(q['ids'],parent['ids'])
    legacy=M.js(LEGACY/phase/'report.json')['files'][role]
    for field in('density','density_manifest','scores','prediction'):
        assert M.desc(legacy[field]['path'])['sha256']==legacy[field]['sha256']
    with np.load(legacy['density']['path'],allow_pickle=False)as a:geom={k:a[k]for k in a.files}
    with np.load(legacy['prediction']['path'],allow_pickle=False)as a:base_decisions={k:a[k]for k in a.files}
    assert np.array_equal(base_decisions['ids'],q['ids'])and np.array_equal(base_decisions['new_raw'],q['base_raw'])
    assert np.all(~(base_decisions['native_novelty_reject']|base_decisions['conditional_dual_reject'])|q['base_raw'])
    with np.load(legacy['scores']['path'],allow_pickle=False)as a:
        assert np.array_equal(a['ids'],q['ids'])and np.array_equal(a['Z'],q['Z'])
    reps,inv=geom['representatives'],geom['inverse'];_,newreps,newinv=np.unique(q['groups'],return_index=True,return_inverse=True)
    assert np.array_equal(reps,newreps)and np.array_equal(inv,newinv)
    q.update(parent=parent['prediction'],parent_fields=parent,parent_ref=M.desc(parentpath),geom=geom,base_decisions=base_decisions,
        density_manifest=M.js(legacy['density_manifest']['path']),legacy_refs=legacy,reps=reps,inverse=inv)
    return q

def distances(role,q):
    CACHE.mkdir(exist_ok=True);p=CACHE/(role+'_distance.npy');meta=CACHE/(role+'_distance.json');z=q['Z'][q['reps']];metric=A.fixed_metric()
    geometry=arrdesc(z)
    if meta.exists():
        r=M.js(meta);assert r['geometry']==geometry and r['metric_state_sha256']==metric.state_sha256
        assert M.desc(p)==r['distance'];return np.load(p,mmap_mode='r',allow_pickle=False)
    tick=time.perf_counter();distance=metric.pairwise_distances(z)
    assert np.array_equal(distance,distance.T)and np.all(np.diag(distance)==0)
    work=distance.copy();np.fill_diagonal(work,np.inf);neighbors=np.argsort(work,axis=1,kind='stable')[:,:7]
    assert np.array_equal(neighbors,q['geom']['physical_neighbors'])
    radii=np.take_along_axis(distance,neighbors,axis=1)[:,-1]
    assert np.array_equal(radii,q['geom']['radii'][q['reps']])
    primary=q['density_manifest']['primary_selection']['selected']
    first=DBSCAN(eps=primary['eps'],min_samples=primary['minPts'],metric='precomputed',n_jobs=1).fit_predict(distance)
    assert np.array_equal(first,q['geom']['first'][q['reps']])
    secondary=q['density_manifest']['secondary_selection'];safe=np.where(radii>0,radii,secondary['zero_radius_replacement'])
    local=distance/np.sqrt(safe[:,None]*safe[None,:]);np.fill_diagonal(local,0.)
    second=DBSCAN(eps=secondary['eps'],min_samples=secondary['minPts'],metric='precomputed',n_jobs=1).fit_predict(local)
    assert np.array_equal(second,q['geom']['second'][q['reps']])
    with p.open('xb')as f:np.save(f,distance,allow_pickle=False)
    M.put(meta,dict(geometry=geometry,metric_state_sha256=metric.state_sha256,distance=M.desc(p),
        full_physical_neighbors_exact=True,primary_and_secondary_labels_exact=True,
        selection_reuse='Identical complete unlabelled cohort/coordinates/metric/algorithm; selection and affinity are independent of candidate mask.',
        computed_seconds=time.perf_counter()-tick,**STATUS))
    return distance

def replay(q,context,distance):
    reps,inv=q['reps'],q['inverse'];g=np.zeros(len(reps),bool);np.logical_or.at(g,inv,context)
    geometric=(q['geom']['primary_supported']|q['geom']['secondary_supported'])[reps]
    votes=D.local_vote_masks(q['geom']['physical_neighbors'],g)
    ix=np.flatnonzero(g);component=D.candidate_mutual_component_support(np.asarray(distance[np.ix_(ix,ix)]),np.ones(len(ix),bool))
    support=np.zeros(len(reps),bool);support[ix]=component['candidate_component_support']
    primary=g&geometric&votes['raw_majority'];ret=primary|support
    result=dict(retained=ret[inv]&context,raw_majority=votes['raw_majority'][inv],
        raw_neighbor_count=g[q['geom']['physical_neighbors']].sum(1)[inv],primary_retained=primary[inv]&context)
    for key in('candidate_component_support','candidate_component_size','candidate_mutual_degree','candidate_component_id'):
        full=np.zeros(len(reps),component[key].dtype)
        if key=='candidate_component_id':full[:]=-1
        full[ix]=component[key];result[key]=full[inv]
    return result

def known_priority_candidates(q):
    # Propagate the original first-stage risk signal through the R10 boundary,
    # while honoring the EXISTING independent-source known certificate pool.
    # No score/threshold changes; no rejected R15/R16/R17 model is reused.
    known=q['parent_fields']['known_certificate_pool']
    assert known.shape==q['base_raw'].shape==q['parent'].shape
    return (q['parent']<2)&q['base_raw']&~known

def consensus_candidates(q):
    # Existing native novelty and rejection by BOTH known conditional models.
    # No added classifier, fitted score, new cut, target label or ID exception.
    b=q['base_decisions']
    return known_priority_candidates(q)&b['native_novelty_reject']&b['conditional_dual_reject']
