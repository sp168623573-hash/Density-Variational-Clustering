"""Bounded current35e standalone auxiliary unseen-family DEV admission.

Root alone executes metadata selection/SQL. No CSV, feature, model, predictor,
score, distance, DVC or new fit is accessed. This scope is NOT Table1 UNA22 or
a final test. Metadata admission and actual feature-equivalence are separate.
"""
from __future__ import annotations
import argparse,collections,hashlib,json,sqlite3,time
from pathlib import Path
from .config import NSL_FEATURE_COLUMNS
from .table1_final_family_contract_v1 import canonical_families

ROOT=Path(__file__).resolve().parents[1]
SCHEMA='NSL1-current35e-standalone-auxiliary-unseen-family-DEV-scoped-admission-v1'
FAMILIES=('saint','mscan','apache2','processtable','mailbomb','worm','udpstorm')
STRONG=('rawrow_sha256','native41_sha256','native40_sha256','export_normalized40_sha256','legacy_typed40_sha256')
ROLE_SHA='17b5a2f93ecb3475b237176fef9311b9e36efae58b1bd6406325199aff490c3b'
MODEL='35e030de1d72b4d594ef9b8923a267dd20e0bb1c72e0def19c5fdf3ce768409e'
SOURCE='fa46b0935342616aa83b7c2578db355b6a7aaabbc492248172c7a1e8b7ab8f84'
def require(ok,reason):
    if not ok:raise ValueError(reason)
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def is_sha(value):return isinstance(value,str) and len(value)==64 and all(c in '0123456789abcdef' for c in value)
def item(path):
    p=Path(path).resolve();return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(a,pins):
    p=Path(a['path']);p=(p if p.is_absolute() else ROOT/p).resolve()
    require(p.is_relative_to(ROOT) and p.suffix in ('.json','.jsonl','.sqlite','.npz','.pt','.joblib','.py'),'explicit saved assets only; no rawCSV')
    b=p.read_bytes();h=hashlib.sha256(b).hexdigest();require(h==a['sha256'],'saved evidence byte binding:'+str(p));pins[str(p)]=h;return b
def js(a,pins):
    require(Path(a['path']).suffix=='.json','JSON metadata only');return json.loads(read(a,pins))
def rows(a,pins):
    require(Path(a['path']).suffix=='.jsonl','JSONL identity metadata only');return [json.loads(s) for s in read(a,pins).decode('utf8').splitlines()]
def write(path,value):
    with path.open('x',encoding='utf8') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    return item(path)
def write_rows(path,values):
    with path.open('x',encoding='utf8') as f:
        for value in values:f.write(json.dumps(value,sort_keys=True,allow_nan=False)+'\n')
    return dict(item(path),rows=len(values))
def key(row):return row['source_sha256'],row['ordinal']


def recipe():
    return dict(schema_version=SCHEMA,scope='current35e standalone auxiliary unseen-family UNKNOWN DEV',
        families=list(FAMILIES),labels='existing3034 label-tail membership only for declared split/admission; never parameter optimization',
        exclusion='predeclared9 saved protocol-population possible touches; conservative source condition, NOT a training-leak finding',
        independence='bounded actual known6000 numerical inputs and registered current3598 computation/selection feedback; not unused anywhere',
        namespace='exact sourceSHA/ordinal/rawrow + each named native41/native40/export40/typed40 hash and existing strong component; weakuint64 never exclusion',
        ambiguity='preserve all possible parents by custody component reference; no arbitrary representative parent or global-history veto',
        originals='each selected original sourceordinal once in original order; no feature/score-dependent selection',
        positive_family_minimum='report-only deterministic within-family original-parent copies to20 only when original>0',
        copies_in_model_or_density=0,max_original_and_report_rows=6000,
        active_parameters='frozen current35e/model+known-only preprocessing,3e96units,225metric,88629nativeunits,map139,known joint-support policy and CAL; no2271/fused/white overlay',
        new_parameter_fit=False,source_admitted_global=False,metadata_admission_separate_from_feature_equivalence=True,
        native_runtime='exactsourceSHA+ordinal;43raw fields; onlyfirst41 decoded; final2label/difficulty never parsed into feature stage',
        prediction_before_label_release=True,Table1_final_UNA22_admitted=False,final_test_executed=False,published=False)


def select_metadata(candidates,memberships,relations,known,query,authority,*,families=FAMILIES):
    """Pure metadata operation; real callers are root, toys may inject authority."""
    require(len({key(r) for r in candidates})==len(candidates),'one explicit original key per candidate')
    member={key(r):r['family'] for r in memberships};relation={key(r):r for r in relations}
    require(set(member)==set(relation)=={key(r) for r in candidates},'same exact candidate/membership/population identities')
    actual=known+query;current_keys={key(r) for r in actual}
    current_hash={name:{r[name] for r in actual} for name in STRONG}
    current_components={authority(r)['component_id'] for r in actual}
    selected=[];excluded=[]
    for c in candidates:
        require(c['family']==member[key(c)] and c['family'] in families,'only frozen auxiliary membership families')
        official=authority(c)
        require(all(is_sha(c[name]) and c[name]==official[name] for name in STRONG)
                and c['component_id']==official['component_id'],'each native/raw hash namespace and component agrees with exact official parent')
        rel=relation[key(c)];possible=bool(any(rel['direct_named_strong_hash_population_parents'].values()) or rel['transitive_strong_alias_population_ordinals'])
        require(rel['protocol_population_possible_identity_touch']==possible
                and rel['numerical_parameter_fit_touch_proved_by_population_relation'] is False,'population possible relation is not proof of numerical fit')
        require(key(c) not in current_keys and not any(c[name] in current_hash[name] for name in STRONG)
                and c['component_id'] not in current_components,'current bounded computation/selection identity must be disjoint')
        if possible:excluded.append(dict(source_sha256=c['source_sha256'],ordinal=c['ordinal'],family=c['family'],
            reason='PREDECLARED_CONSERVATIVE_PROTOCOL_POPULATION_CONDITION',training_leak_claim=False));continue
        selected.append(dict(source_sha256=c['source_sha256'],ordinal=c['ordinal'],family=c['family'],
            **{name:c[name] for name in STRONG},component_id=c['component_id'],
            historical_exposure_state=official['exposure_kind'],weak_uint64_used=False,
            possible_parent_closure='all aliases retained by source-bound existing component reference; no unique alias assumed'))
    counts=collections.Counter(r['family'] for r in selected)
    require(all(counts[f]>0 for f in families),'positive genuine original required before declared family resampling')
    reporting=list(range(len(selected)));copy_map=[]
    for family in families:
        parents=[i for i,r in enumerate(selected) if r['family']==family]
        for offset in range(max(0,20-len(parents))):
            parent=parents[offset%len(parents)];reporting.append(parent)
            copy_map.append(dict(report_position=len(reporting)-1,original_member_index=parent,family=family,
                source_sha256=selected[parent]['source_sha256'],ordinal=selected[parent]['ordinal'],model_or_density_copy=False))
    require(len(selected)<=6000 and len(reporting)<=6000,'original and copy-inclusive cap6000')
    return selected,excluded,dict(counts),reporting,copy_map


class ReadOnlyIdentityAuthority:
    def __init__(self,identity,closure,pins):
        read(identity,pins);read(closure,pins);self.cache={};self.calls=0
        self.dbs=[sqlite3.connect(str(Path(a['path']).resolve().as_uri())+'?mode=ro',uri=True) for a in (identity,closure)]
        for db in self.dbs:db.execute('PRAGMA query_only=ON')
    def __call__(self,row):
        parent=key(row)
        if parent not in self.cache:
            value=self.dbs[0].execute('SELECT '+','.join(STRONG)+' FROM official_records WHERE source_sha256=? AND ordinal=?',parent).fetchone()
            event=self.dbs[1].execute('SELECT component_id,exposure_kind FROM record_closure WHERE source_sha256=? AND ordinal=?',parent).fetchone();self.calls+=2
            require(value is not None and event is not None,'explicit sourceordinal exists in registered authority/custody')
            self.cache[parent]=dict(zip(STRONG,value),component_id=event[0],exposure_kind=event[1])
        return dict(self.cache[parent])
    def close(self):
        for db in self.dbs:db.close()


def validate_active(reg,pins):
    a=reg['assets'];r=js(a['known35_report'],pins);runtime=js(a['known_runtime'],pins);base=js(a['base_original_report'],pins)
    require(r['updated_model_state_sha256']==runtime['updated_model_state_sha256']==MODEL and r['execution_status']=='updated_shared_whole_field_known80_completed'
            and r['counts']['warm_or_final_reads']==0 and r['counts']['epochs_completed']==80,'actual fixed known-only35e training')
    require(base['frozen_policy']['role_ids_sha256']==ROLE_SHA and base['source_role_plan']['selected_source_rows']==6000
            and base['source_role_plan']['unknown_development_rows_used'] is base['source_test_file_opened'] is False,'f007 original known-domain ancestor')
    init=js(r['initialization_receipt'],pins)
    require(init['original_checkpoint']==a['base_original_checkpoint'] and init['all_shared_keys_and_tensor_bytes_exact'] is True
            and init['posttraining_old_original_identity_claim'] is False,'actual known f007 initialization into new35e')
    bindings={'updated_checkpoint':'model35','field_map':'field_map','masked_target_units':'target107_units','new_FIT96_units':'units96','new_metric':'metric225'}
    for field,name in bindings.items():require(runtime[field]==reg['active_parameter_assets'][name],'same frozen active parameter:'+name)
    require(runtime['new_FIT96_units_state_sha256']=='3e3ceb3b59c28888477e28a48d093fdf6684ac39a00628f446ded111449ea8f9'
            and runtime['new_metric_state_sha256']=='22545392c2f30a0b43b2b266fec58118e4df6f92a2ccefda84d5d032e23c5870'
            and runtime['masked_target_units_state_sha256']=='88629b597f598197894cc0ead7ed29c1afe87d04c32103239ffc0c2dae670732','distinct known-domain96/native107 units and learned225')
    joint=js(a['joint_known_report'],pins);binding=js(joint['fixed_policy'],pins);cal=js(joint['CAL_rule'],pins)
    unsigned=dict(binding);sha=unsigned.pop('state_sha256')
    require(sha==digest(unsigned)==joint['policy_state_sha256'] and joint['counts']['unknown_source_reads']==0
            and joint['known_DVC_passed'] is True and joint['execution_status']=='fixed_joint_support_known_CAL_DEV_completed','actual frozen known joint support/CAL stage')
    require(joint['fixed_policy']==reg['active_parameter_assets']['joint_policy'] and joint['CAL_rule']==reg['active_parameter_assets']['joint_CAL_rule']
            and binding['metric_state_sha256']==runtime['new_metric_state_sha256'],'same candidate policy and final learned metric')
    for c,n,rank in (('0',320,318),('1',336,334)):
        require(cal['rules'][c]['support']==n and cal['rules'][c]['rank_one_based']==rank
                and cal['rules'][c]['strict_greater'] is True,'knownCAL original finite99 frozen')
    for asset in reg['active_parameter_assets'].values():read(asset,pins)
    require(set(reg['active_parameter_assets'])=={'model35','preprocessing_original107','field_map','target107_units','units96','metric225',
            'learned_support','native_support','joint_policy','joint_CAL_rule'},'closed standalone parameter set, no old ensemble asset')
    require(reg['active_parameter_assets']['preprocessing_original107']['sha256']=='c685dd4bcdd7621d209c71a7dd0ad1f2e3764f30b0aa6141388707d3892c8e50','original40 to107 preprocessing authority')
    return r,runtime,joint


def assemble(registry_path,registry_sha256,output_directory):
    pins={};start=time.perf_counter();reg=js(dict(path=str(Path(registry_path).resolve()),sha256=registry_sha256),pins)
    unsigned=dict(reg);signature=unsigned.pop('registry_sha256');require(signature==digest(unsigned) and reg['recipe']==recipe(),'prospective signed scoped auxiliary DEV recipe')
    require(reg['schema_version']==SCHEMA+'-registry' and reg['root_sole_actual'] is True and reg['source_admitted'] is False,'metadata root authorization; no prior sourceadmit')
    for source in reg['sources'].values():read(source,pins)
    require(reg['sources']['assembler']['path']==str(Path(__file__).resolve()),'exact new metadata assembler')
    a=reg['assets'];known35,runtime,joint=validate_active(reg,pins)
    carrier=js(a['carrier_report'],pins);known=rows(carrier['known_identity_carrier'],pins);query=rows(carrier['query_identity_carrier'],pins)
    require(len(known)==6000 and len(query)==3598 and len({key(r) for r in known})==6000,'bound actual known numerical and registered selection cohorts')
    require([r['sample_id'] for r in query[:654]]==[r['sample_id'] for r in known if r['role']=='open_known'],'same654 query prefix, no identity guessing')
    base=js(a['base_original_report'],pins)
    role_digests={role:hashlib.sha256('\n'.join(sorted(r['sample_id'] for r in known if r['role']==role)).encode()).hexdigest()
                  for role in ('fit','checkpoint','calibration','open_known')}
    require(base['source_role_plan']['role_sample_id_set_sha256']==role_digests,'actual f007 known6000 role sets equal current numerical authority')
    for role,asset in known35['updated_role_receipts'].items():
        receipt=js(asset,pins)
        require(receipt['ordered_ids']==[r['sample_id'] for r in known if r['role']==role]
                and receipt['updated_model_state_sha256']==MODEL and receipt['post_forward_guards_passed'] is True,
                'actual35e role identity:'+role)
    bridge=js(a['identity_bridge_report'],pins);schema=js(a['feature_schema'],pins)
    require(bridge['execution_status']=='official_identity_bridge_index_completed' and bridge['summary']['existing_official_parents_exact_hash_parity']==8944
            and bridge['source_boundaries']['official_Test']['identity_feature_rows']==22544
            and bridge['source_boundaries']['official_Test']['label_cells_decoded']==0
            and schema['feature_columns']==list(NSL_FEATURE_COLUMNS),'registered native41/raw40 field namespace and source correspondence')
    aux=js(a['candidate_report'],pins);candidates=rows(aux['candidates'],pins);membership=rows(aux['membership'],pins)
    relations=js(a['population_relations'],pins)['rows'];canonical=canonical_families('NSL-KDD Setting1')
    require(aux['selected_original_rows']==3034 and aux['counts']['feature_cells_decoded']==0
            and len(candidates)==len(membership)==len(relations)==3034 and all(c['source_sha256']==SOURCE for c in candidates)
            and not set(FAMILIES).intersection(canonical['KNA']) and not set(FAMILIES).intersection(canonical['UNA']),
            'explicit nonfinal auxiliary unseen family roster, never Table1 target UNA22')
    out=Path(output_directory).resolve();require(str(out)==reg['output_directory'] and out.is_relative_to(ROOT) and not out.exists(),'fresh registered scope output')
    authority=ReadOnlyIdentityAuthority(a['identity_index'],a['exposure_closure'],pins)
    try:selected,excluded,counts,reporting,copies=select_metadata(candidates,membership,relations,known,query,authority)
    finally:authority.close()
    require(len(selected)==3025 and len(excluded)==9 and {r['family'] for r in excluded}=={'saint'}
            and len(reporting)==3061 and len(copies)==36,'predeclared actual source selection/copy totals; no performance-guided edit')
    out.mkdir(parents=True);source_policy=write(out/'scope_policy_before_any_feature_projection.json',dict(recipe=recipe(),registry=dict(path=str(Path(registry_path).resolve()),sha256=registry_sha256),
        active_parameter_assets=reg['active_parameter_assets'],registered_selection_carrier=carrier['query_identity_carrier'],
        feature_equivalence_executed=False,end_to_end_ready=False,global_source_admitted=False))
    feature_members=[];labels=[]
    for i,row in enumerate(selected):
        label=dict(member_index=i,source_sha256=row['source_sha256'],ordinal=row['ordinal'],family=row['family'],
                   scoped_auxiliary_truth=2,paper_Table1_UNA_truth_claim=False)
        member=dict(row);member.pop('family');member.update(member_index=i,sample_id='auxdev:'+str(row['ordinal'])+':'+row['rawrow_sha256'],
                                                          parameter_or_density_copies=0)
        feature_members.append(member);labels.append(label)
    members=write_rows(out/'selected3025_original_identity_members_no_labels.jsonl',feature_members)
    labelstore=write_rows(out/'scoped_auxiliary_labels_sealed_until_predictions.jsonl',labels)
    exclusion=write_rows(out/'excluded9_population_condition_not_leak_findings.jsonl',excluded)
    copy_asset=write(out/'report_only_family20_parent_map.json',dict(original_rows=3025,effective_report_rows=3061,
        reporting_indices=reporting,copies=copies,model_or_density_copy_rows=0,positive_original_required=True))
    manifest=dict(schema_version=SCHEMA+'-manifest',scope='current35e standalone auxiliary unseen-family DEV',
        scope_policy=source_policy,original_members=members,label_store_after_prediction_seal=labelstore,excluded_metadata=exclusion,
        report_only_parent_map=copy_asset,original_family_counts=counts,effective_family_counts={f:max(20,counts[f]) for f in FAMILIES},
        original_rows=3025,effective_report_rows=3061,report_only_copies=36,original_mixed_with_known654_rows=3679,
        effective_report_mixed_with_known654_rows=3715,copies_in_model_or_density=0,
        active_parameter_assets=reg['active_parameter_assets'],actual_known_numerical_identity_carrier=carrier['known_identity_carrier'],
        registered_parameter_selection_cohort_identity_carrier=carrier['query_identity_carrier'],
        native41_feature_contract=dict(source_sha256=SOURCE,original43_fields=43,decode_columns=list(range(41)),
            native41_columns=['duration',*NSL_FEATURE_COLUMNS],model40_columns=list(NSL_FEATURE_COLUMNS),
            label_difficulty_decode_columns=[],five_hash_namespaces=list(STRONG),official_identity_index=a['identity_index'],
            custody_components=a['exposure_closure'],feature_schema=a['feature_schema'],original107_preprocessing=reg['active_parameter_assets']['preprocessing_original107']),
        scopedAuxDEV_admitted=True,scopedAuxDEV_metadata_admitted=True,source_admitted_for_declared_aux_DEV=True,
        admission_stage='source_identity_and_frozen_parameter_metadata_only',
        feature_equivalence_executed=False,scoped_aux_DEV_NN_execution_ready=False,end_to_end_ready=False,
        runtime_feature_projection_required='root fresh sourceSHA/ordinal/rawrow/5namespace equality; selected107 through frozen original preprocessing; save before model calls',
        no_new_parameter_or_cut_fit=True,no2271_fused_white_overlay=True,
        auxiliary_families=list(FAMILIES),canonical_final_UNA_families=list(canonical['UNA']),
        Table1_final_UNA22_admitted=False,source_admitted=False,cold_certificate=False,final_execution_authorized=False,published=False,final_test_executed=False)
    manifest['manifest_sha256']=digest(manifest);m=write(out/'scoped_metadata_admission_manifest.json',manifest)
    require(all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in pins.items()),'bound sources/known parameters/identity inputs unchanged')
    report=dict(schema_version=SCHEMA,execution_status='scoped_auxiliary_DEV_metadata_admitted_pending_feature_projection',manifest=m,
        selected_original_rows=3025,excluded_predeclared_population_conditions=9,original_family_counts=counts,report_only_copy_rows=36,
        effective_report_rows=3061,scopedAuxDEV_admitted=True,scopedAuxDEV_metadata_admitted=True,feature_equivalence_executed=False,end_to_end_ready=False,
        source_admitted=False,cold_certificate=False,published=False,final_test_executed=False,status='FAIL_TARGET99',
        actual_metadata_SQL_calls=authority.calls,population_rescan_SQL_calls=0,model_feature_score_distance_DVC_calls=0,
        CSV_or_feature_or_new_label_tail_reads=0,only_existing_membership_labels_for_admission=True,
        input_sha256=pins,wall_seconds=time.perf_counter()-start)
    return write(out/'report.json',report)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('registry','registry-sha256','output-directory'):p.add_argument('--'+n,required=True)
    args=p.parse_args();print(json.dumps(assemble(args.registry,args.registry_sha256,args.output_directory)))
if __name__=='__main__':main()
