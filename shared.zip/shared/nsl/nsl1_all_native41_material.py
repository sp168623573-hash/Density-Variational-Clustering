"""Known-only information restoration: retain all41 native fields.

No variance filter discards constant known fields; categorical unknown slots
are representation coordinates, never fabricated traffic. The mixed-query
asset is read only for its verified first654 known rows, with correct NPY
column-major handling. No2944 unknown value is interpreted or normalized.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import zipfile
import numpy as np
from . import nsl35e_aux7_scoped_dev_admission_v1 as files
from . import config

ROOT = files.ROOT
FIELDS = ('duration', *config.NSL_FEATURE_COLUMNS)
SCHEMA = 'NSL1-original-all41-no-variance-drop-known-material-v1'


def prefix_rows(archive_bytes, member, count, expected_shape):
    """Only selected rows become string/numeric arrays; other bytes stay opaque."""
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
        with archive.open(member) as stream:
            version = np.lib.format.read_magic(stream)
            shape, fortran, dtype = np.lib.format._read_array_header(stream, version)
            offset = stream.tell()
            files.require(shape == expected_shape and len(shape) == 2 and 0 < count <= shape[0]
                and dtype.kind == 'U' and not dtype.hasobject, 'exact closed native41 string member header')
            n, width = shape; result = np.empty((count, width), dtype=dtype)
            if fortran:
                for col in range(width):
                    stream.seek(offset + col * n * dtype.itemsize)
                    payload = stream.read(count * dtype.itemsize)
                    files.require(len(payload) == count * dtype.itemsize, 'complete known column prefix')
                    result[:, col] = np.frombuffer(payload, dtype=dtype, count=count)
            else:
                payload = stream.read(count * width * dtype.itemsize)
                files.require(len(payload) == count * width * dtype.itemsize, 'complete known row prefix')
                result[:] = np.frombuffer(payload, dtype=dtype).reshape(count, width)
    return result


def freeze():
    known_dir = ROOT / 'NSL-KDD Setting1/run/known_BEN_native41_mixture_nll_control_20261004_v2'
    known_audit = dict(path=str(ROOT / 'tmp/nsl_mhfd_unified_entry_20261008_v1/known_native41_parent_audit.json'),
        sha256='9816013bfc88f693907809e3981ed571295ca807a56192d94a707d774af676cf')
    pins = {}; audit = files.js(known_audit, pins)
    files.require(audit['all6000_parent_native41_matches'] and audit['duration_is_direct_saved_native41_first_cell_bound_to_exact_original_parent'],
                  'actual known native41 authority, never inferred legacy40 duration')
    model = dict(path=str(ROOT / 'data/external_dev/processed/nsl_MHFD_whole_field_mask_known80_20261009_v1/NSL_KDD_Setting1/report.json'),
        sha256='9b3e14629a6a9b1add35fc9855a14eeafa0d81c86a799249a05737628dd1e7af')
    known = files.js(model, pins)
    reg = dict(schema_version=SCHEMA + '-registry', source=files.item(__file__), authority=known_audit,
        pure_known=dict(path=str(known_dir / 'known_source_coordinates_frozen_before_query.npz'),
            sha256='a222ac2f8c067fa98d2968d68cb8919fcd6708a08eb83924cbb23dd8c0fdce85'),
        mixed_known_prefix=dict(path=str(known_dir / 'native41_query_features_frozen_before_prediction.npz'),
            sha256='06bacd375e2291e099812794f8deb8e3a67da89cc623e3e66c94c39e6f6e3f3a'),
        known_ID_label_material=known['updated_clean_material'], original_field_names=list(FIELDS),
        roles={'fit':4034, 'checkpoint':656, 'calibration':656, 'open_known':654},
        policy=dict(numeric='log1p raw values / FIT-only RMS of log1p values; exactzero uses natural unit1 and remains declaredzero',
            categorical='all observed original knownFIT categories plus one explicit unknown coordinate per field',
            selection='all41 native original fields including known-constant fields, no known-variance pruning',
            training_classes=['BEN','KNA'], unknown_values_interpreted=0, source_IDs_in_features=False,
            future_model='paper MHFD attention/gating/position/CNN/BiLSTM, known-only masked auxiliary loss; own metric/DVC'),
        output=str(ROOT / 'data/external_dev/processed/nsl1_all_native41_material_20261009_v1'),
        source_admitted=False, published=False, final_test_executed=False)
    reg['registry_sha256'] = files.digest(reg)
    directory = ROOT / 'tmp/nsl1_all_native41_material_20261009_v1'; directory.mkdir(exist_ok=True)
    return files.write(directory / 'registry_before_actual.json', reg)


def run(path, sha):
    pins = {}; reg = files.js(dict(path=str(Path(path).resolve()), sha256=sha), pins)
    unsigned = dict(reg); signature = unsigned.pop('registry_sha256')
    files.require(signature == files.digest(unsigned) and reg['source'] == files.item(__file__), 'frozen all41 material recipe')
    files.read(reg['source'], pins); authority = files.js(reg['authority'], pins)
    files.require(authority['all6000_parent_native41_matches'], 'all source parents verified')
    out = Path(reg['output']); files.require(out.is_relative_to(ROOT) and not out.exists(), 'fresh known-only material output')
    out.mkdir(parents=True)
    pure = files.read(reg['pure_known'], pins)
    original = {role: prefix_rows(pure, role + '_native41.npy', n, (n, 41))
        for role, n in reg['roles'].items() if role != 'open_known'}
    original['open_known'] = prefix_rows(files.read(reg['mixed_known_prefix'], pins), 'native41.npy', 654, (3598,41))
    # Only closed known members, never the old warm unknown material.
    with np.load(io.BytesIO(files.read(reg['known_ID_label_material'], pins)), allow_pickle=False) as z:
        labels = {role + '_' + key: z[role + '_' + key].copy()
            for role in reg['roles'] for key in ('ids', 'known_fine', 'known_coarse')}
    files.require(all(labels[r + '_known_coarse'].shape == (n,) and np.isin(labels[r + '_known_coarse'], (0,1)).all()
        for r, n in reg['roles'].items()), 'exact6000 known roles only')
    raw = {**labels, **{r + '_native41': x for r, x in original.items()}}
    path = out / 'actual_known6000_native41_before_encoding.npz'; np.savez_compressed(path, **raw)
    native_a = files.item(path)
    cat = [i for i, field in enumerate(FIELDS) if field in ('protocol_type','service','flag')]
    numeric = [i for i in range(41) if i not in cat]
    converted = {r: x[:, numeric].astype(np.float64) for r, x in original.items()}
    files.require(all(np.isfinite(x).all() and np.all(x >= 0) for x in converted.values()), 'finite actual numeric native values')
    log = {r: np.log1p(x) for r, x in converted.items()}
    seen = set(); representatives = []
    for i, row in enumerate(original['fit']):
        key = tuple(row.tolist())
        if key not in seen: representatives.append(i); seen.add(key)
    fit = log['fit'][representatives]; largest = np.max(np.abs(fit), axis=0); scale = np.ones(len(numeric)); nonzero = largest > 0
    scale[nonzero] = largest[nonzero] * np.sqrt(np.mean((fit[:, nonzero] / largest[nonzero])**2, axis=0))
    files.require(np.isfinite(scale).all() and np.all(scale > 0), 'frozen positive native numeric units')
    vocab = {str(i): sorted(set(original['fit'][:, i].tolist())) for i in cat}
    state = dict(schema_version=SCHEMA + '-encoder', policy=reg['policy'], numeric_indices=numeric,
        log_numeric_FIT_RMS=scale.tolist(), exactzero_FIT_numeric_fields=[FIELDS[numeric[i]] for i in np.flatnonzero(~nonzero)],
        categorical_vocabularies=vocab, categorical_unknown_coordinate=True, fields=list(FIELDS),
        unique_native41_FIT_representative_indices=representatives, unique_native41_FIT_rows=len(representatives),
        source_authority=reg['authority'], knownFIT_source_sha256=native_a['sha256'])
    state['state_sha256'] = files.digest(state)
    state_a = files.write(out / 'knownFIT_all41_encoder_before_new_model.json', state)
    groups, names, width = [], [], 0
    for i, field in enumerate(FIELDS):
        count = len(vocab[str(i)]) + 1 if i in cat else 1
        cols = list(range(width, width + count)); width += count
        names += [field + '_' + v for v in vocab[str(i)]] + [field + '___UNSEEN__'] if i in cat else [field]
        groups.append(dict(field=field, kind='categorical' if i in cat else 'numeric', selected_columns=cols))
    encoded = {}
    for role, n in reg['roles'].items():
        parts = []
        for i in range(41):
            if i in cat:
                levels = vocab[str(i)]; mapping = {v:j for j,v in enumerate(levels)}
                positions = np.asarray([mapping.get(v,len(levels)) for v in original[role][:,i]])
                value = np.zeros((n,len(levels)+1),np.float32); value[np.arange(n),positions]=1
            else:
                j = numeric.index(i); value = (log[role][:,j] / scale[j]).astype(np.float32)[:,None]
            parts.append(value)
        encoded[role + '_features'] = np.concatenate(parts,axis=1)
    files.require(width <= 128 and len(groups) == 41 and all(np.isfinite(x).all() and x.shape == (reg['roles'][r[:-9]],width)
        for r,x in encoded.items()), 'all41 native fields encoded within paper dimension bound')
    target = out / 'new_all41_known_features_before_training.npz'; np.savez_compressed(target,**encoded,**labels)
    encoded_a = files.item(target)
    prefit = dict(schema_version=SCHEMA + '-new-model-prefit', encoder=state_a, known_source=native_a,
        new_known_inputs=encoded_a, role_counts=reg['roles'], original_known_rows=6000, input_width=width,
        all41_original_groups=groups, encoded_feature_names=names, roles_labels=reg['known_ID_label_material'],
        native_constant_fields_retained=True, numeric_FIT_only=True, unknown_numeric_decodes=0,
        mixed_member_known_prefix_only=654, future_main_model_training_executed=False,
        source_admitted=False, published=False, final_test_executed=False)
    prefit_a = files.write(out / 'all41_new_model_prefit.json',prefit)
    for p,h in pins.items(): files.require(files.item(p)['sha256'] == h, 'all sources preserved')
    return files.write(out / 'report.json',dict(execution_status='all41_original_known_material_encoded',
        known_source=native_a, encoder=state_a, model_prefit=prefit_a, encoded_inputs=encoded_a,
        known_rows=6000, input_width=width, original_field_groups=41, actual_constant_fields=state['exactzero_FIT_numeric_fields'],
        unknown_numeric_interpreted=0, mixed_known_prefix_rows=654, model_training_or_inference=0,
        source_admitted=False, published=False, final_test_executed=False,status='FAIL_TARGET99',input_sha256=pins))


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--freeze',action='store_true');p.add_argument('--registry');p.add_argument('--registry-sha256')
    a=p.parse_args();print(json.dumps(freeze() if a.freeze else run(a.registry,a.registry_sha256)))
