"""Collective joint categorical usage increase, original owned149 paper chain.
Known FIT vocabulary isfixed, unlabelled cohort frequencies areinference only.
No neural/metric/R7 fitting; source/current classlabels do not enter profiles.
"""
import argparse
import json
import sys
import time
import types
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from . import nsl1_cic1_equalfine_RFF_candidates_v92 as old
from . import nsl1_collective_categorical_profile_core_v116 as core
from . import nsl1_nativecell_Student3_typedmask_v60 as fields_source
from . import cic2017_all_native78_known_material_v1 as cic_fields

ROOT,files,require = old.ROOT,old.files,old.require
nsl,cic,helpers = old.nsl,old.cic,old.helpers
MODULE = 'paper_open_set.nsl1_collective_categorical_profile149_v116b'
DIR = ROOT/'tmp/nsl1_collective_categorical_profile149_20261012_v116b'
BASE = ROOT/'data/external_dev/processed/nsl1_collective_categorical_profile149_20261012_v116b'

def registry_path(setting):
    return DIR/(setting+'_registry_before_known_collective_context.json')

def policy(setting):
    require(setting=='NSL1','only NSL1 original existingcohort')
    return dict(schema_version='NSL1-full117-threecategorical-collective-profile-Dirichlet1-BENonly-rawonly-original149-v116b',hypotheses=1,setting=setting,
        fields='allactual three completecategorical wholefields protocol_type/service/flag fromactualencoder41/full117; completeUNSEEN slots remain; no field/context chosenbycurrenterrors',
        FIT='genuine5999 originalnativegroups exactlyonce, naturalcounts allknownBEN+KNA; no fineprior reweighting or reportcopies',
        vocabulary='allobserved genuineFIT jointtriples lexicographic, plus singleOTHER for everyunseen tuple; no queryvocabulary extension',
        probabilities='P_FIT=(FITcount+1)/(5999+K), K=observedcontexts+OTHER; P_query=(uniquenativegroup_count+1)/(N_unique_query+K), same fixedDirichlet1 prior; pseudocounts areprior notphysicalevents',
        score='logP_query(context_i)-logP_FIT(context_i), samegroup scatter; allunlabelled querycohort contributes once; not p_ATTACK',
        population='CAL656/known654/current3598 eachownoriginalnativegroups once; queryfeature counts aretest-time collectiveinference likeDVC, no querylabels/cut/modelparameteroptimization',
        calibration='alltrueknownCAL656 ownpopulation scores oncefinite99 pertruecoarse; originalstage1 query choosesbank; allknown labels only, no correct-onlyfilter',
        assumptions='normal knowncontext usage distribution stable underdeployment; collectivefrequency increase iscandidate evidence, notattackidentity/coldfinal guarantee; benignusage surge maytrigger falsepositives',
        geometry='unmodified original V62 exact149 masked32+native117, originalownedmetric/ref/R7; neitherTAN158 norGaussianrank geometry consumed',
        DVC='newraw excludesoldpredUNA2, rawonly actualnativegroup graph; same149 Eq9/10 knee minPts2..10/SCCH/affinity/reconstruction/localdensity/secondarynoise; oldUNA outputonly',
        baseline='whole2618 317/335/2618, old2601/2605 preserved',
        scope='newraw only originalbaselineBEN0; baselineKNA1/UNA2 preserved; genuineknownKNA primary335/335 iskept, not wrongUID filtering; canmiss unknown incorrectlyprimaryKNA',
        fixed_probability_math='reuse exactly sealedV116 FIT vocabulary/probabilities/allknownCALcut; no newalpha/context/cut/grid or querypopulation filtering',
        acceptance='positive-support exactBEN/KNA99 knownbeforecurrent, allclassinteger99 priority/allgainloss explicit; originalwhole retained ifmixed/regression/noadvance',
        boundary='distinct from V72 continuousR20 withinball occupancies and BEN-onlycontext point-density/tree; categoricaljoint cohortfrequency ratio withfrozen allknown vocabulary',
        NN_fit=0,NN_forward=0,metric_fit=0,R7_fit=0,query_cut_fit=False,query_label_training=False,cohort_features_used_for_profile_inference=True,
        parameter_grid=False,field_selection=False,timecap_coded=False,extension_not_verbatim_paper=True,warm_development_only=True,
        status='FAIL_TARGET99',published=False,final_test_executed=False)

def closure():
    pending=[sys.modules[__name__]];seen=set();result={}
    while pending:
        m=pending.pop()
        if m is None or id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if not p or not Path(p).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        result[MODULE if m is sys.modules[__name__] else m.__name__]=files.item(p)
        for value in vars(m).values():
            child=value if isinstance(value,types.ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            if child is not None:pending.append(child)
    result[MODULE]=files.item(__file__)
    require(all(m.__name__ in result for m in (old,core,nsl,cic,helpers)),'direct owned closure')
    return result

def metadata(setting,pins):
    require(setting=='NSL1','single fixedsetting')
    a,ancestry,refs=old.metadata(setting,pins)
    a['actual_encoder']=fields_source.ENCODER
    groups=fields_source.field_map_state(files.js(a['actual_encoder'],pins))['groups']
    priorref=files.item(ROOT/'tmp/nsl1_collective_categorical_profile149_20261012_v116/NSL1_V116_COLLECTIVE_PROFILE_KNOWN_FAILED_CLOSEOUT.json')
    prior=files.js(priorref,pins)
    ancestry['allfailed_andcompleted_preceding_attempt_preparation']=prior['timing_seconds']['conservative_allprep_plus_ancestry']-sum(ancestry.values())
    refs['allattempt_time_evidence']=priorref
    parent_ref=files.item(ROOT/'data/external_dev/processed/nsl1_collective_categorical_profile149_20261012_v116/NSL1/known/report.json')
    parent=files.js(parent_ref,pins)
    require(parent['prediction_sealed'] and not parent['known_gate_passed'] and parent['current_numeric_rows_decoded']==0,'originalV116 knownfailed withno current exposure')
    a['reused_profile_state']=parent['files']['state'];a['reused_CAL_rule']=parent['files']['rule'];a['reused_CAL_profile']=parent['files']['alltrueknown_CAL_collective_context_before_cut'];refs['originalV116_known_report']=parent_ref
    core.categorical_mapping(groups)
    return a,ancestry,refs,groups

def freeze(setting):
    started=time.perf_counter();pins={}
    a,ancestry,refs,groups=metadata(setting,pins);sources=closure()
    for descriptor in [*a.values(),*sources.values()]:files.read(descriptor,pins)
    require(not registry_path(setting).exists() and not (BASE/setting).exists(),'fresh unique empiricaldoubletail branch')
    DIR.mkdir(parents=True,exist_ok=True)
    return files.write(registry_path(setting),dict(policy=policy(setting),assets=a,sources=sources,
        ancestry_seconds=ancestry,necessary_ancestry_seconds=sum(ancestry.values()),references=refs,groups=groups,
        metadata_preparation_seconds=time.perf_counter()-started,input_sha256=pins,
        current_numeric_rows_decoded=0))

def bind(setting,desc,pins):
    reg=files.js(desc,pins)
    require(Path(desc['path']).resolve()==registry_path(setting).resolve() and reg['policy']==policy(setting)
            and reg['sources']==closure(),'own frozen source/policy/roles')
    for path,sha in reg['input_sha256'].items():files.read(dict(path=path,sha256=sha),pins)
    return reg

def save(out,r,name,values):return old.save(out,r,name,values)
def archive(asset,keys,pins):return old.archive(asset,keys,pins)

def run(setting,phase,desc,known_desc=None):
    started=time.perf_counter();pins={};reg=bind(setting,desc,pins);known=None
    if phase=='current':
        known=files.js(known_desc,pins)
        require(known['registry']==desc and known['prediction_sealed'] and known['known_gate_passed'],
                'positive-support exactknown99 beforecurrent values')
    out=BASE/setting/phase;out.mkdir(parents=True,exist_ok=False)
    r=dict(policy=policy(setting),registry=desc,phase=phase,files={},NN_fit=0,NN_forward=0,
        metric_fit=0,R7_fit=0,FIT_profile_fit=0,query_population_inference=0,CAL_fit=0,DVC=0,current_numeric_rows_decoded=0,
        prediction_sealed=False,truth_opened=False,accepted_baseline_replaced=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        with threadpool_limits(limits=4):
            a=reg['assets']
            if phase=='known':
                prep=time.perf_counter()
                state=archive(a['reused_profile_state'],('vocabulary3','FIT_context_counts','FIT_context_probability','genuineFIT_rows','Dirichlet_alpha'),pins)
                rule=files.js(a['reused_CAL_rule'],pins)
                r['files'].update(state=a['reused_profile_state'],rule=a['reused_CAL_rule'],original_CAL_profile=a['reused_CAL_profile'])
                r['training_preparation_seconds']=time.perf_counter()-prep
                r['FIT_context_vocabulary_count_seconds']=0.0
                r['reused_FIT_profile_and_CAL_rule']=True
            else:
                state=archive(known['files']['state'],('vocabulary3','FIT_context_counts','FIT_context_probability','genuineFIT_rows','Dirichlet_alpha'),pins)
                rule=files.js(known['files']['rule'],pins)
                r['files'].update(state=known['files']['state'],rule=known['files']['rule']);r['known_report']=known_desc
            q,baseline,native=old.query(setting,phase,a,pins)
            r['current_numeric_rows_decoded']=len(q['ids']) if phase=='current' else 0
            score_started=time.perf_counter();cue=core.infer_profile(native,q['groups'],state,reg['groups']);r['query_population_inference']+=1;r['query_score_seconds']=time.perf_counter()-score_started
            raw=nsl.base.paper_route.candidate_mask(cue['score'],q['stage1'],rule)&(baseline==0);density=raw.copy()
            save(out,r,'collective_jointcontext_population_rawonly_before_DVC',dict(ids=q['ids'],native=native,stage1=q['stage1'],raw=raw,density=density,**cue))
            save(out,r,'unchanged_originalgeometry_before_DVC',q)
            payload=files.js(a['metric'],pins)
            metric=(nsl.learned if setting=='NSL1' else cic.learned).PaperVariationalPairMetric.from_state(payload if setting=='NSL1' else payload['metric_payload'])
            r['files']['metric']=a['metric'];ds=time.perf_counter()
            if setting=='NSL1':
                def sink(name,value,manifest):
                    save(out,r,name+'_DVC_before_truth',value)
                    r['files'][name+'_DVC_manifest']=files.write(out/(name+'_DVC_manifest.json'),manifest)
                route,_=nsl.base.route_once(metric,q,density,sink)
            else:
                route=cic.dvc.route_current_candidates(metric,q['Z126'],density,seed=20261009)
                save(out,r,'original126_DVC_before_truth',{k:v for k,v in route.items() if k!='manifest'})
                r['files']['DVC_manifest']=files.write(out/'original126_DVC_manifest.json',route['manifest'])
            r['DVC']=1;r['query_DVC_inference_seconds']=time.perf_counter()-ds
            retained=raw&route['retained'];prediction=baseline.copy();prediction[retained]=2
            require(np.all(prediction[baseline==2]==2),'old full predictions preserved output only')
            values=dict(ids=q['ids'],prediction=prediction,baseline=baseline,raw=raw,density=density,
                        retained=retained,density_retained=route['retained'])
            sealed=save(out,r,'complete_prediction_before_truth',values)
            r['files']['seal']=files.write(out/'prediction_seal_before_truth.json',dict(predictions=sealed,
                registry=desc,state=r['files']['state'],rule=r['files']['rule'],metric=a['metric'],truth_used=False))
            r['prediction_sealed']=True
            if setting=='NSL1':
                truth=nsl.parent.previous.prefix_archive(a['baseline'],('ids','truth'),654,pins) if phase=='known' else archive(a['baseline'],('ids','truth'),pins)
                require(np.array_equal(truth['ids'],q['ids']),'original ordered truth only afterseal');y=truth['truth']
            elif phase=='known':y=archive(a['known_truth'],('CP_truth',),pins)['CP_truth']
            else:
                truth=archive(a['truth'],('ids','truth'),pins)
                require(np.array_equal(truth['ids'],q['ids']),'original orderedtruth afterseal');y=truth['truth']
            r['truth_opened']=True;g,e,binary=helpers.metrics(y,baseline,prediction)
            knownpass=all(g[name]['passed'] for name in ('BEN','KNA'))
            r.update(execution_status='collective_jointcontext_'+setting+'_'+phase+'_completed',original_class_gates=g,
                EffectDelta=e,binary_attack_detection=binary,known_gate_passed=knownpass,
                all_old_correct_loss_free=all(z['loss']==0 for z in e['gain_loss'].values()),
                candidate_accepted_for_retention=bool(phase=='current' and knownpass and e['correct_count_delta']['UNA']>0),
                all_three_integer99_passed=bool(phase=='current' and all(z['passed'] for z in g.values())),
                raw_by_true_class={n:int(((y==c)&raw).sum()) for c,n in enumerate(('BEN','KNA','UNA'))},
                new_external_raw_by_true_class={n:int(((y==c)&raw&(baseline==0)).sum()) for c,n in enumerate(('BEN','KNA','UNA'))})
            save(out,r,'postseal_paired_comparison',dict(**values,truth=y))
            if phase=='current':
                r['perfect_raw_retention_UNA_ceiling']=int(((y==2)&(baseline==2)).sum()+((y==2)&raw&(baseline==0)).sum())
                r['postseal_raw_group_counts']={n:len(np.unique(q['groups'][(y==c)&raw])) for c,n in enumerate(('BEN','KNA','UNA'))}
        for path,sha in pins.items():require(files.item(path)['sha256']==sha,'sealed source/asset bytes unchanged')
    except Exception as error:
        r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started)
        if phase=='known':
            r['conservative_preparation_seconds']=reg['necessary_ancestry_seconds']+reg['metadata_preparation_seconds']+r['wall_seconds']
        files.write(out/'report.json',r)
    return files.item(out/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--setting',choices=('NSL1',),required=True)
    p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for name in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+name)
    args=p.parse_args()
    desc=None if not args.registry else dict(path=str(Path(args.registry).resolve()),sha256=args.registry_sha256)
    known=None if not args.known_report else dict(path=str(Path(args.known_report).resolve()),sha256=args.known_sha256)
    print(json.dumps(freeze(args.setting) if args.phase=='freeze' else run(args.setting,args.phase,desc,known)))
