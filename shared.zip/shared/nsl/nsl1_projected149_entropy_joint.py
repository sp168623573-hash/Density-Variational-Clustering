"""ROOT-only known-calibrated entropy times frozen projected149 distance ratio.

Only the candidate score changes. The MAIN35e classification, projected149
metric, FIT reference/R7, raw geometry and preserved2596 vector stay fixed.
Real cached score/probability arithmetic and labelblind DVC run only in ROOT.
freeze reads JSON, hashes and NPZ headers; it never decodes array values.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import time
import numpy as np

from . import nsl1_projection149_entry_v1 as projected
from . import nsl1_projection149_pair_metric_v1 as learned

files, ROOT, producer, paper_route = projected.files, projected.ROOT, projected.producer, projected.paper_route
archive, save, descriptor = projected.archive, projected.save, projected.descriptor
route_once, merge, delta = projected.route_once, projected.merge, projected.delta
SCHEMA = 'NSL1-preserved2596-frozen-projected149-entropy-distance-product-v1'
BASE = ROOT/'data/external_dev/processed/nsl1_projected149_entropy_joint_20261010_v1'
METRIC_STATE_SHA = '1d0c3af0e12d30c37cbec9c1e68a3c283176858b96a782c53fd1edb1d0f563c5'
PROJECTED_KNOWN = dict(path=str(projected.BASE/'known/report.json'),
    sha256='9cbf9c9bd5292bd21f3e522d23bdb8d1c99a3aec18287024236ca88ed63f9b35')
PROJECTED_CURRENT = dict(path=str(projected.BASE/'current/report.json'),
    sha256='8fbf0a584e3de08d931fa1490f4bbddcc3c11f9a6ddb55cc49d4179419081025')


def recipe():
    return dict(schema_version=SCHEMA, setting='NSL-KDD Setting1', width=149,
        frozen_metric_state_sha256=METRIC_STATE_SHA,
        candidate_score='cached projected149 nearest PRIMARY-predicted-fine distanceRatio times normalized entropy of genuine PRIMARY fine9 probabilities',
        entropy='normalize each row by its positive row mass; -sum(p log p)/log(9); exact zero terms contribute zero',
        entropy_floor_or_epsilon_or_clipping=False, new_formula_count=1, parameter_or_threshold_grid=False,
        baseline='original feature-derived full317/335/2596 vector; rejected2610 vector not used',
        primary_classifier_unchanged=True, fine_family_ID_or_truth_exception=False,
        learned_metric_reference_R7_units_reused=True,
        NN_replay=0, metric_fit=0, projection_fit=0, R7_refit=0, units_refit=0,
        nearest_distance_score_recomputed=0,
        calibration='one genuine knownCAL656 PRIMARY-coarse finite99 strictgreater under this new joint score',
        known_gate='known654 BEN/KNA exact integer99 AND zero paired loss versus retained2596 before current numeric array decode',
        DVC='same projected149 distance, candidate/centre/secondary affinity and noise on own new raw candidates',
        merge='copy retained2596; only own raw AND own same-query DVC retained become UNA',
        current_scope='already-observed original3598 DEV; no independent final assertion',
        original2579_and2596_immutable=True, query_parameter_fit=False, new_data_or_row_selection=False,
        unknown_in_metric_or_Calibration_fit=False, source_admitted=False,
        accepted_baseline_replaced=False, independent_final=False,
        published=False, final_test_executed=False, status='FAIL_TARGET99')


def freeze():
    pins = {}
    known, current = (files.js(a,pins) for a in (PROJECTED_KNOWN,PROJECTED_CURRENT))
    preparation = files.js(known['preparation'],pins)
    preg = files.js(known['registry'],pins)
    inherited = files.js(preg['controlled_registry'],pins)
    files.require(known['known_gate_passed'] is True and current['prediction_sealed'] is True
        and current['EffectDelta']['verdict'] == 'MIXED'
        and known['metric_state_sha256'] == current['metric_state_sha256'] == METRIC_STATE_SHA,
        'actual projected149 metric and separately rejected current result')
    assets = dict(prepared_material=preparation['prepared_material'], query_geometry=preg['assets']['query_geometry'],
        metric=known['files']['metric'], reference=known['files']['reference'], radii=known['files']['radii'],
        CAL_distance_ratio=known['files']['CAL149_scores_before_cutoffs'],
        known_distance_ratio=known['files']['known654_scores_raw_before_DVC'],
        current_distance_ratio=current['files']['projected149_current_scores_raw_before_DVC'],
        main_known=inherited['assets']['main_known'], main_current=inherited['assets']['main_current'],
        baseline_and_truth_after_seal=preg['assets']['baseline_and_truth_after_seal'],
        known_truth_after_seal=preg['assets']['known_truth_after_seal'])
    headers = {k:producer.metadata_headers(a,pins) for k,a in assets.items() if Path(a['path']).suffix == '.npz'}
    files.require(headers['prepared_material']['calibration_Z149']['shape'] == [656,149]
        and headers['prepared_material']['open_known_Z149']['shape'] == [654,149]
        and headers['query_geometry']['Z149']['shape'] == [3598,149], 'same fixed real geometry headers')
    for name,n in (('CAL_distance_ratio',656),('known_distance_ratio',654),('current_distance_ratio',3598)):
        files.require(headers[name]['score']['shape'] == headers[name]['stage1']['shape'] == [n]
            and headers[name]['score']['dtype'] == '<f8', 'actual projected149 cached score header:'+name)
    files.require(headers['main_known']['calibration_fine_probability']['shape'] == [656,9]
        and headers['main_known']['open_known_fine_probability']['shape'] == [654,9]
        and headers['main_current']['fine_probability']['shape'] == [3598,9], 'genuine MAIN35e fine9 probability headers')
    for a in assets.values(): files.read(a,pins)
    sources = {Path(m.__file__).name:files.item(m.__file__) for m in
        (projected,projected.vanilla,learned,learned.inherited,producer,projected.owned_dvc,paper_route,paper_route.sealed,files)}
    sources['caller'] = files.item(__file__)
    for a in preg['sources'].values(): files.read(a,pins)
    reg = dict(schema_version=SCHEMA+'-registry', policy=recipe(), sources=sources, assets=assets, headers=headers,
        projected_known_report=PROJECTED_KNOWN, rejected_projected_current_report=PROJECTED_CURRENT,
        inherited_preparation=known['preparation'], inherited_registry=preg['controlled_registry'],
        material_descriptors=preparation['material_descriptors'],
        output={p:str(BASE/p) for p in ('known','current')}, input_sha256=pins,
        actual_numeric_array_decodes=0, published=False, final_test_executed=False, status='FAIL_TARGET99')
    reg['registry_sha256'] = files.digest(reg)
    directory = ROOT/'tmp/nsl1_projected149_entropy_joint_20261010_v1';directory.mkdir(exist_ok=True)
    return files.write(directory/'registry_before_new_entropy_CAL.json',reg)


def bind(path,sha,pins):
    a = dict(path=str(Path(path).resolve()),sha256=sha);reg = files.js(a,pins)
    unsigned = dict(reg);signature = unsigned.pop('registry_sha256')
    files.require(signature == files.digest(unsigned) and reg['policy'] == recipe()
        and reg['sources']['caller'] == files.item(__file__), 'own pre-CAL source and one formula recipe')
    for item in reg['sources'].values(): files.read(item,pins)
    for p,h in reg['input_sha256'].items(): files.read(dict(path=p,sha256=h),pins)
    return a,reg


def start(reg,phase,registry):
    out = Path(reg['output'][phase]);files.require(out == BASE/phase and not out.exists(),'fresh once-only entropy joint phase:'+phase)
    out.mkdir(parents=True)
    report = dict(schema_version=SCHEMA,phase=phase,registry=registry,policy=recipe(),files={},
        counts=dict(NN_replay=0,metric_fit=0,projection_fit=0,R7_fit=0,units_fit=0,nearest_distance_score_recomputed=0,
            CAL_joint_score=0,CAL_fit=0,query_joint_score=0,DVC_calls=0),
        execution_status='not_completed',prediction_sealed=False,known_truth_opened=False,
        unknown_truth_opened=False,full_current_truth_opened=False,accepted_baseline_replaced=False,
        published=False,final_test_executed=False,status='FAIL_TARGET99')
    return out,report


def finish(out,report,pins,started):
    for p,h in pins.items(): files.require(files.item(p)['sha256'] == h,'unchanged frozen source and input bytes')
    report['input_sha256'] = pins;report['wall_seconds'] = time.perf_counter()-started
    return files.write(out/'report.json',report)


def normalized_entropy(fine_probability):
    p = np.asarray(fine_probability,np.float64)
    files.require(p.ndim == 2 and p.shape[1] == 9 and np.isfinite(p).all()
        and np.all(p >= 0) and np.all(p <= 1), 'finite genuine nine-class probability values')
    mass = p.sum(axis=1)
    files.require(np.isfinite(mass).all() and np.all(mass > 0),'positive finite probability row mass')
    normalized = p/mass[:,None]
    terms = np.zeros_like(normalized)
    positive = normalized > 0
    terms[positive] = normalized[positive]*np.log(normalized[positive])
    entropy = -terms.sum(axis=1)/np.log(9.0)
    files.require(np.isfinite(entropy).all() and np.all(entropy >= 0),'finite normalized entropy; natural zero terms')
    return entropy


def joint_scores(distance_ratio,fine_probability):
    d = np.asarray(distance_ratio,np.float64)
    h = normalized_entropy(fine_probability)
    files.require(d.shape == h.shape and np.isfinite(d).all() and np.all((d >= 0)&(d <= 1)),
        'same-row frozen nearest-fine distance ratio')
    score = d*h
    files.require(np.isfinite(score).all() and np.all(score >= 0),'one distance times normalized entropy formula')
    return score,h


def load_metric(reg,pins):
    metric = learned.PaperVariationalPairMetric.from_state(files.js(reg['assets']['metric'],pins))
    files.require(metric.state_sha256 == METRIC_STATE_SHA,'exact frozen projected149 metric without fit')
    return metric


def known(path,sha):
    started,pins = time.perf_counter(),{};registry,reg = bind(path,sha,pins);out,report = start(reg,'known',registry)
    before_runtime = producer.capture_runtime_flags();report['runtime_before'] = before_runtime
    try:
        material = archive(reg['assets']['prepared_material'],tuple(reg['material_descriptors']),pins)
        files.require({k:descriptor(v) for k,v in material.items()} == reg['material_descriptors'],'unchanged genuine known149 geometry')
        main = archive(reg['assets']['main_known'],tuple(r+'_'+k for r in ('calibration','open_known')
            for k in ('ids','fine_probability','predicted_coarse')),pins)
        for r in ('calibration','open_known'):
            files.require(np.array_equal(main[r+'_ids'],material[r+'_ids'])
                and np.array_equal(main[r+'_predicted_coarse'],material[r+'_stage1'])
                and np.array_equal(main[r+'_fine_probability'].argmax(axis=1),material[r+'_predicted_fine']),
                'same immutable original MAIN role semantics:'+r)
        cal_cache = archive(reg['assets']['CAL_distance_ratio'],('score','stage1'),pins)
        known_cache = archive(reg['assets']['known_distance_ratio'],('score','stage1'),pins)
        files.require(np.array_equal(cal_cache['stage1'],material['calibration_stage1'])
            and np.array_equal(known_cache['stage1'],material['open_known_stage1']),'same cached score PRIMARY coarse conditioning')
        report['counts']['CAL_joint_score'] = 1
        cal_score,cal_entropy = joint_scores(cal_cache['score'],main['calibration_fine_probability'])
        save(out,report,'CAL656_joint_scores_before_cutoffs',dict(score=cal_score,entropy=cal_entropy,
            distance_ratio=cal_cache['score'],stage1=cal_cache['stage1']))
        cut = paper_route.calibrate_known_cutoffs(cal_score,cal_cache['stage1'])
        ca = files.write(out/'new_knownCAL656_joint_cutoffs_before_known654.json',dict(cutoffs=cut,
            original_CAL_rows=656,query_used=False,metric=reg['assets']['metric'],score_recipe=recipe()))
        report['files']['calibration'] = ca;cut = files.js(ca,pins)['cutoffs'];report['counts']['CAL_fit'] = 1
        report['counts']['query_joint_score'] = 1
        score,entropy = joint_scores(known_cache['score'],main['open_known_fine_probability'])
        raw = paper_route.candidate_mask(score,known_cache['stage1'],cut)
        save(out,report,'known654_joint_scores_raw_before_DVC',dict(score=score,entropy=entropy,
            distance_ratio=known_cache['score'],stage1=known_cache['stage1'],raw=raw))
        query = dict(Z149=material['open_known_Z149'],groups=material['open_known_groups'],stage1=known_cache['stage1'])
        metric = load_metric(reg,pins)
        def sink(name,v,manifest):
            save(out,report,'known654_'+name+'_same_projected_DVC',v)
            report['files']['route_'+name] = files.write(out/('known654_'+name+'_DVC_manifest.json'),manifest)
        report['counts']['DVC_calls'] = 1;route,_ = route_once(metric,query,raw,sink)
        ids = archive(reg['assets']['query_geometry'],('ids',),pins)['ids']
        files.require(np.array_equal(ids[:654],material['open_known_ids']),'original known-prefix custody; current feature decode zero')
        baseline = archive(reg['assets']['baseline_and_truth_after_seal'],('fresh_increment',),pins)['fresh_increment'][:654]
        prediction = merge(baseline,raw,route['retained'])
        pred = save(out,report,'known654_joint_increment_before_truth',dict(ids=material['open_known_ids'],prediction=prediction,
            baseline=baseline,raw=raw,retained=route['retained']))
        seal = files.write(out/'known654_joint_prediction_seal_before_truth.json',dict(prediction=pred,
            registry=registry,metric=reg['assets']['metric'],CAL=ca,truth_opened=False))
        report['files']['prediction_seal'] = seal;files.js(seal,pins);report['prediction_sealed'] = True
        truth = archive(reg['assets']['known_truth_after_seal'],('open_known_ids','open_known_known_coarse'),pins)
        report['known_truth_opened'] = True
        files.require(np.array_equal(truth['open_known_ids'],material['open_known_ids']),'fixed known654 truth custody after seal')
        effect,gates,prior = delta(truth['open_known_known_coarse'],prediction,baseline)
        zero_loss = all(effect['gain_loss'][n]['loss'] == 0 for n in ('BEN','KNA'))
        integer_ok = all(v['passed'] for v in gates.values())
        save(out,report,'postseal_known654_joint_comparison',dict(ids=material['open_known_ids'],truth=truth['open_known_known_coarse'],
            prediction=prediction,baseline=baseline,raw=raw,retained=route['retained']))
        report.update(execution_status='entropy_joint149_known_zero_loss_gate_evaluated',original_class_gates=gates,
            baseline_class_gates=prior,EffectDelta=effect,known_gate_passed=zero_loss and integer_ok,
            paired_known_no_loss=zero_loss,known_integer99_passed=integer_ok,
            known_raw=int(raw.sum()),known_retained=int(route['retained'].sum()),
            metric_state_sha256=metric.state_sha256,current_cached_probability_or_score_numeric_reads=0,
            current_cached_geometry_numeric_reads=0,primary_classification_unchanged=True)
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        restored = producer.restore_runtime_flags(before_runtime)
        report['runtime_restoration'] = dict(before=before_runtime,after=restored,all_flags_restored=restored == before_runtime)
        result = finish(out,report,pins,started)
    return result


def current(path,sha,known_path,known_sha):
    started,pins = time.perf_counter(),{};registry,reg = bind(path,sha,pins)
    ka = dict(path=str(Path(known_path).resolve()),sha256=known_sha);kr = files.js(ka,pins)
    files.require(ka['path'] == str(Path(reg['output']['known'])/'report.json') and kr['registry'] == registry
        and kr['execution_status'] == 'entropy_joint149_known_zero_loss_gate_evaluated' and kr['known_gate_passed'] is True,
        'known integer99 and zero paired loss before current cached numeric reads')
    out,report = start(reg,'current',registry);report['known_report'] = ka
    before_runtime = producer.capture_runtime_flags();report['runtime_before'] = before_runtime
    try:
        query = archive(reg['assets']['query_geometry'],('ids','groups','Z149','stage1','predicted_fine'),pins)
        main = archive(reg['assets']['main_current'],('fine_probability','stage1'),pins)
        cache = archive(reg['assets']['current_distance_ratio'],('score','stage1'),pins)
        saved_known = archive(reg['assets']['known_distance_ratio'],('score','stage1'),pins)
        known_main = archive(reg['assets']['main_known'],('open_known_ids','open_known_fine_probability'),pins)
        files.require(query['Z149'].shape == (3598,149) and len(set(query['ids'].tolist())) == 3598
            and np.array_equal(query['ids'][:654],known_main['open_known_ids'])
            and np.array_equal(main['fine_probability'][:654],known_main['open_known_fine_probability'])
            and np.array_equal(main['fine_probability'].argmax(axis=1),query['predicted_fine'])
            and np.array_equal(main['stage1'],query['stage1']) and np.array_equal(cache['stage1'],query['stage1'])
            and np.array_equal(cache['score'][:654],saved_known['score']), 'immutable original3598 score/probability custody and known prefix')
        save(out,report,'current3598_cached149_geometry_before_joint_score',query)
        cut = files.js(kr['files']['calibration'],pins)['cutoffs'];metric = load_metric(reg,pins)
        report['counts']['query_joint_score'] = 1
        score,entropy = joint_scores(cache['score'],main['fine_probability'])
        raw = paper_route.candidate_mask(score,query['stage1'],cut)
        save(out,report,'current3598_joint_scores_raw_before_DVC',dict(score=score,entropy=entropy,
            distance_ratio=cache['score'],raw=raw,stage1=query['stage1']))
        def sink(name,v,manifest):
            save(out,report,'current3598_'+name+'_same_projected_DVC',v)
            report['files']['route_'+name] = files.write(out/('current3598_'+name+'_DVC_manifest.json'),manifest)
        report['counts']['DVC_calls'] = 1;route,_ = route_once(metric,query,raw,sink)
        baseline = archive(reg['assets']['baseline_and_truth_after_seal'],('fresh_increment',),pins)['fresh_increment']
        prediction = merge(baseline,raw,route['retained'])
        pred = save(out,report,'complete_current3598_joint_increment_before_truth',dict(ids=query['ids'],
            prediction=prediction,baseline=baseline,raw=raw,retained=route['retained']))
        seal = files.write(out/'current3598_joint_prediction_seal_before_truth.json',dict(prediction=pred,registry=registry,
            metric=reg['assets']['metric'],CAL=kr['files']['calibration'],known_gate_report=ka,truth_opened=False))
        report['files']['prediction_seal'] = seal;files.js(seal,pins);report['prediction_sealed'] = True
        truth = archive(reg['assets']['baseline_and_truth_after_seal'],('ids','truth'),pins)
        report['known_truth_opened'] = True;report['unknown_truth_opened'] = True;report['full_current_truth_opened'] = True
        files.require(np.array_equal(truth['ids'],query['ids']),'full original3598 truth custody after new prediction seal')
        effect,gates,prior = delta(truth['truth'],prediction,baseline,full=True)
        zero_loss = all(effect['gain_loss'][n]['loss'] == 0 for n in ('BEN','KNA'))
        save(out,report,'postseal_current3598_joint_comparison',dict(**truth,prediction=prediction,
            baseline=baseline,raw=raw,retained=route['retained']))
        report.update(execution_status='entropy_joint149_preserved2596_current3598_evaluated',original_class_gates=gates,
            baseline_class_gates=prior,EffectDelta=effect,paired_known_no_loss=zero_loss,
            all_three_integer99_passed=all(v['passed'] for v in gates.values()),
            DEV_review_eligible=effect['verdict'] == 'UP' and zero_loss,
            known_raw=int(raw[:654].sum()),known_retained=int(route['retained'][:654].sum()),
            unknown_raw=int(raw[654:].sum()),unknown_retained=int(route['retained'][654:].sum()),
            metric_state_sha256=metric.state_sha256,query_fine_or_entropy_in_classifier=False,
            projection_metric_R7_units_or_CAL_fit_in_current=0,independent_unknown_DEV_measured=False)
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        restored = producer.restore_runtime_flags(before_runtime)
        report['runtime_restoration'] = dict(before=before_runtime,after=restored,all_flags_restored=restored == before_runtime)
        result = finish(out,report,pins,started)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=('freeze','known','current'),required=True)
    parser.add_argument('--registry');parser.add_argument('--registry-sha256')
    parser.add_argument('--known-report');parser.add_argument('--known-sha256');args = parser.parse_args()
    result = freeze() if args.phase == 'freeze' else known(args.registry,args.registry_sha256) if args.phase == 'known' else current(args.registry,args.registry_sha256,args.known_report,args.known_sha256)
    print(json.dumps(result))
