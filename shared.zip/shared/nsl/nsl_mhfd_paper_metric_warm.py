"""Single original MHFD -> metric candidate -> DVC -> affinity/noise experiment.

Warm observed data only. Historical forecasts enter comparison after sealing;
they cannot supply predictions or permanently retain an old UNA decision.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
from pathlib import Path
import time
import joblib
import numpy as np
import pandas as pd
import torch
from sklearn.cluster import DBSCAN
from sklearn.metrics import silhouette_score
from . import nsl_auth2188_frozen_conditional_blocks_warm_pair_v2 as sealed
from .config import NSL_FEATURE_COLUMNS, get_spec
from .dependence_candidate_paper_dvc import knee_radius
from .model import MHFDNetwork, infer
from .nsl_frozen_category_vocabulary import FrozenCategoryVocabulary

ROOT = Path(__file__).resolve().parents[1]
ORIGINAL = 'NSL-KDD Setting1/run/role_floor_original_train_20261002_v1/'
KNOWN = 'NSL-KDD Setting1/run/known_BEN_native41_mixture_nll_control_20261004_v2/known_source_coordinates_frozen_before_query.npz'
QUERY = 'NSL-KDD Setting1/run/frozen_feature_pipeline_replay_20261004_v2/predictions_frozen_before_counting.npz'
IDENTITY = 'NSL-KDD Setting1/run/frozen_feature_pipeline_replay_recovered_20261004_v3/source_verified_report_identity_map.npz'
RECORDS = 'tmp/target99_continuation_20261004_v6/actual_known_record_training_verification.json'
COMPARE = 'data/external_dev/processed/nsl_2267_joint_sad_warm_20261008_v1/NSL_KDD_Setting1/paired_predictions_before_truth.npz'
EVALUATION = 'data/external_dev/processed/nsl_auth2188_conditional_blocks_warm_20261008_v2/NSL_KDD_Setting1/evaluation_and_report_only_copy_mapping.npz'
ASSET_PINS = {
 ORIGINAL+'checkpoint_selected.pt':'f00758df98feb038ffee5f71f7b74c7f120be579fd033531577673f5254c0b44',
 ORIGINAL+'preprocessing_and_calibrator.joblib':'c685dd4bcdd7621d209c71a7dd0ad1f2e3764f30b0aa6141388707d3892c8e50',
 ORIGINAL+'report.json':'8e70a68a59dd1e83a5bed4d0bfbb930690e6d387ad09840f8a8c8a1394ff83c4',
 ORIGINAL+'frozen_role_ids.npz':'17b5a2f93ecb3475b237176fef9311b9e36efae58b1bd6406325199aff490c3b',
 ORIGINAL+'known_query_predictions_frozen.npz':'d1dd9500f97f1b0d470ddbebfd760f7503b54a9ddd010364a992b109c7a5d0fa',
 KNOWN:'a222ac2f8c067fa98d2968d68cb8919fcd6708a08eb83924cbb23dd8c0fdce85',
 QUERY:'8ee814010ca13a936f4d8271a4732abc045fe1c452f3a473345b66e11fa90f2f',
 IDENTITY:'822f7c0347d7aa3487f0b811fea7452f7e4b28eb822498957625cff7e032ddcc',
 RECORDS:'37028c26add68feec4ebbc1c037a5dc7b4bc9f31522f1c89c317abae93cb1b46',
 COMPARE:'1af0e8ed5f2198c2504c9fe21cc40f882f42b41f929ad0ec70b1c78565fc4ca8',
 EVALUATION:'6168ea691a73b900bd2c3491c5aa0d1dbea8214b27ad19d133881604bb12ad42',
}
CONFIG = dict(schema_version='NSL1-single-original-MHFD-paper-metric-warm-v1',
 setting='NSL-KDD Setting1', FIT_rows=4034, CP_rows=656, CAL_rows=656,
 known_query_rows=654, warm_UNA_rows=2944, known_original_role_pool=6000,
 representation='actual original single MHFD embedding32; no secondary anomaly encoder',
 MHFD_input='exact frozen original107, no inverse reconstruction from log107',
 candidate='kth(min7, same predicted fine FIT originals count) same learned distance',
 calibration='all CAL grouped by actual single MHFD predicted coarse; finite99 integer rank; strict greater',
 raw_all_coarse=True, graph='only current raw candidates; no known anchors or historical UNA OR',
 DVC='minPts2..10, learned k-distance knee, precomputed standard silhouette then generalized learned-metric CH',
 paper_formula_limits='SC implementation choice differs from Eq11 additions; generalized CH is not every Eq12 addition',
 affinity='same learned distance to raw MHFD cluster means; alpha=beta=1',
 noise='primary nonnoise reconstruction R95 and density median; same eps/minPts secondary',
 native_source_numeric_reads=0, MHFD_training_runs=0, metric_training_runs=1,
 deprecated_warm_development=True, prior_truth_already_observed=True,
 independent_unknown_DEV_claim=False, fresh_blind_claim=False, full_Table1=False,
 report_only_copies=34, copies_in_MHFD_or_metric_or_density=0,
 accepted_baseline_replaced=False, published=False, final_test_executed=False)

require = sealed.require
same = sealed.same
same_ids = sealed.same_ids

def _pins():
    return {str((ROOT / p).resolve()): h for p,h in ASSET_PINS.items()}

def _checked(p, pins):
    return sealed.checked(p,pins,ASSET_PINS.get(str(p)))

def _archive(p,pins,keys):
    with np.load(io.BytesIO(_checked(p,pins)),allow_pickle=False) as z:
        return {k:z[k].copy() for k in keys}

def _new_directory(p):
    out=Path(p).resolve()
    require(out.is_relative_to(ROOT) and out!=ROOT,'workspace_output_required')
    out.mkdir(parents=True,exist_ok=False)
    return out

def _state_sha(model):
    h=hashlib.sha256()
    for name,value in sorted(model.state_dict().items()):
        a=value.detach().cpu().contiguous().numpy()
        h.update(name.encode()); h.update(a.dtype.str.encode()); h.update(repr(a.shape).encode()); h.update(a.tobytes())
    return h.hexdigest()

def _load_model(pins):
    checkpoint=torch.load(io.BytesIO(_checked(ORIGINAL+'checkpoint_selected.pt',pins)),map_location='cpu',weights_only=True)
    known=('BEN',*get_spec('NSL-KDD Setting1').known_families)
    require(tuple(checkpoint['fine_classes'])==known and checkpoint['feature_count']==107,'single_MHFD_known_fine_input_schema')
    model=MHFDNetwork(107,len(known)).cpu().eval()
    model.load_state_dict(checkpoint['state_dict'],strict=True)
    report=json.loads(_checked(ORIGINAL+'report.json',pins))
    require(report['execution_status']=='complete' and report['published'] is False and report['final_test_executed'] is False
        and report['frozen_policy']['checkpoint_sha256']==ASSET_PINS[ORIGINAL+'checkpoint_selected.pt']
        and report['frozen_policy']['preprocessing_sha256']==ASSET_PINS[ORIGINAL+'preprocessing_and_calibrator.joblib']
        and report['frozen_policy']['role_ids_sha256']==ASSET_PINS[ORIGINAL+'frozen_role_ids.npz']
        and checkpoint['coarse_threshold']==report['frozen_policy']['threshold_selected_from_known_calibration_only'],
        'completed_known_only_single_MHFD_checkpoint_binding')
    return model,checkpoint

def _selected(prep,native):
    a=np.asarray(native)
    require(a.ndim==2 and a.shape[1]==41 and a.dtype.kind=='U','frozen_native41_unicode_known_only')
    frame=pd.DataFrame(a[:,1:],columns=NSL_FEATURE_COLUMNS)
    for name in NSL_FEATURE_COLUMNS[3:]:
        frame[name]=pd.to_numeric(frame[name],errors='raise')
    encoded=np.asarray(FrozenCategoryVocabulary(prep['preprocessor']).transform(frame),np.float32)
    value=np.asarray(prep['selector'].transform(encoded[:,prep['variance_mask']]),np.float32)
    require(value.shape==(len(a),107) and np.isfinite(value).all(),'finite_original_selected107')
    return value

def _metadata(pins):
    roles=_archive(ORIGINAL+'frozen_role_ids.npz',pins,('fit','checkpoint','calibration','open_known'))
    require([len(roles[r]) for r in roles]==[4034,656,656,654]
        and len(set(np.concatenate(list(roles.values())).tolist()))==6000,'all_disjoint_original6000_roles')
    records=json.loads(_checked(RECORDS,pins))['known_record_inventory']
    lookup={r['sample_id']:r for r in records}
    require(len(lookup)==len(records)==6000,'known_original_record_inventory6000')
    classes=('BEN',*get_spec('NSL-KDD Setting1').known_families)
    result={}
    for role,ids in roles.items():
        rows=[lookup[s] for s in ids]
        require(all(r['role']==role and r['source_native_family'] in classes for r in rows),'bound_known_roles_and_families')
        require(all(r['original_label']==('normal' if r['source_native_family']=='BEN' else r['source_native_family']) for r in rows),'known_native_family_label_consistency')
        fine=np.asarray([classes.index(r['source_native_family']) for r in rows],np.int64)
        require(all(int((fine==c).sum())>=20 for c in range(len(classes))),'each_known_family_original_floor20')
        result[role]=dict(ids=ids,fine=fine,coarse=(fine!=0).astype(np.int64),
            groups=np.asarray([r['projected_model40_feature_values_sha256'] for r in rows],dtype=str))
    return result

def prepare_known(*,output_directory):
    """Root executes once: four known-role MHFD forwards, no warm payload."""
    out=_new_directory(output_directory); pins=_pins(); started=time.perf_counter(); stage='known_metadata'
    report=dict(configuration=CONFIG,status='FAIL_TARGET99',published=False,final_test_executed=False,
        accepted_baseline_replaced=False,execution_status='not_completed',warm_numeric_opened=False,
        native_source_numeric_reads=0,MHFD_training_runs=0,forward_roles_attempted=[],forward_roles_returned=[])
    try:
        torch.set_num_threads(4)
        metadata=_metadata(pins)
        prep=joblib.load(io.BytesIO(_checked(ORIGINAL+'preprocessing_and_calibrator.joblib',pins)))
        require(set(prep)=={'preprocessor','selector','variance_mask','novelty_calibrator'},'original_preprocessor_four_keys')
        original_state=joblib.hash(prep)
        model,checkpoint=_load_model(pins); model_state=_state_sha(model)
        known=_archive(KNOWN,pins,('fit_native41','checkpoint_native41','calibration_native41'))
        x={role:_selected(prep,known[role+'_native41']) for role in ('fit','checkpoint','calibration')}
        fit_scaled=prep['novelty_calibrator'].feature_scaler_.transform(x['fit'])
        same(fit_scaled,prep['novelty_calibrator'].fit_features_,'exact_original_FIT_numeric_reference')
        same(metadata['fit']['fine'],prep['novelty_calibrator'].fit_fine_,'exact_original_FIT_fine_order')
        q=sealed.prefix(QUERY,pins,('original_model_features','original_stage1'))
        x['open_known']=q['original_model_features']
        require(x['open_known'].shape==(654,107) and x['open_known'].dtype==np.float32
            and np.isfinite(x['open_known']).all(),'known654_frozen_original107_prefix_only')
        cached=_archive(ORIGINAL+'known_query_predictions_frozen.npz',pins,('sample_id','stage1'))
        same_ids(cached['sample_id'],metadata['open_known']['ids'],'known654_original_cached_ID_order')
        same(cached['stage1'],q['original_stage1'],'same_original_MHFD_known_coarse_before_forward')
        module_paths=(Path(__file__).resolve(),Path(sealed.__file__).resolve(),
            Path(__file__).with_name('model.py'),Path(__file__).with_name('nsl_frozen_category_vocabulary.py'),
            Path(__file__).with_name('config.py'),Path(__file__).with_name('dvc.py'))
        for path in module_paths: pins[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
        sealed.write_json(out/'policy_before_known_MHFD_forward.json',dict(configuration=CONFIG,
            actual_forward_roles=['fit','checkpoint','calibration','open_known'],actual_forward_rows=[4034,656,656,654],
            feature_contract=dict(source_saved_native_fields=41,duration_in_saved_column=0,
                MHFD_native_input_fields=40,duration_entering_MHFD=False,selected_width=107,embedding_width=32),
            original_MHFD_state_sha256=model_state,original_threshold=float(checkpoint['coarse_threshold']),
            historical_warm_truth_already_observed=True,warm_payload_decoded_this_run=False,
            scalar_feature_parity='FIT original feature_scaler transform byte-exact existing fit_features_',
            source_file_numeric_reads=0,input_sha256=dict(pins)),pins)
        material={}
        for role in ('fit','checkpoint','calibration','open_known'):
            stage='single_original_MHFD_forward_'+role
            report['forward_roles_attempted'].append(role)
            print(json.dumps(dict(phase=stage,rows=len(x[role]),warm_numeric_opened=False)),flush=True)
            output=infer(model,x[role],device=torch.device('cpu'),batch_size=512)
            report['forward_roles_returned'].append(role)
            coarse=(output.attack_probability>=checkpoint['coarse_threshold']).astype(np.int64)
            fine=np.argmax(output.fine_probability,axis=1).astype(np.int64)
            require(output.embedding.shape==(len(x[role]),32) and np.isfinite(output.embedding).all(),'actual_MHFD_Z32_'+role)
            values=dict(selected=x[role],Z=output.embedding,attack_probability=output.attack_probability,
                fine_probability=output.fine_probability,predicted_coarse=coarse,predicted_fine=fine,**metadata[role])
            material.update({role+'_'+k:v for k,v in values.items()})
        same(material['open_known_predicted_coarse'],cached['stage1'],'single_original_known_coarse_reproduced')
        require(joblib.hash(prep)==original_state and _state_sha(model)==model_state,'original_MHFD_and_preprocessing_frozen')
        sealed.integrity(pins)
        item,_=sealed.save_arrays(out/'known_MHFD_material.npz',pins,material)
        gates=sealed._gates(metadata['open_known']['coarse'],material['open_known_predicted_coarse'])
        require([(gates[c]['correct'],gates[c]['support']) for c in ('BEN','KNA')]==[(317,319),(335,335)],'single_MHFD_original_known317_335_binding')
        source=Path(__file__).resolve(); pins[str(source)]=hashlib.sha256(source.read_bytes()).hexdigest()
        report.update(execution_status='known_MHFD_material_completed',material=item,
            single_MHFD_state_sha256=model_state,single_MHFD_threshold=float(checkpoint['coarse_threshold']),
            fine_classes=list(checkpoint['fine_classes']),known_stage1_gates=gates,
            fitted_preprocessing_state=original_state,input_sha256=dict(pins),wall_seconds=time.perf_counter()-started)
        sealed.write_json(out/'report.json',report,pins)
        print(json.dumps(dict(execution_status=report['execution_status'],known_stage1_gates=gates,
            wall_seconds=report['wall_seconds']),ensure_ascii=False),flush=True)
        return report
    except Exception as error:
        report.update(execution_status='execution_failed',failure_stage=stage,error_type=type(error).__name__,
            error=str(error),input_sha256=dict(pins),wall_seconds=time.perf_counter()-started)
        sealed.write_json(out/'report.json',report,pins)
        raise

def fine_reference_scores(metric,Z,predicted_fine,fit_Z,fit_fine):
    z=np.asarray(Z); labels=np.asarray(predicted_fine); f=np.asarray(fit_fine)
    require(z.ndim==2 and labels.shape==(len(z),) and f.shape==(len(fit_Z),)
        and labels.dtype.kind in 'iu' and f.dtype.kind in 'iu','paired_predicted_fine_and_known_FIT')
    score=np.empty(len(z),np.float64)
    for c in np.unique(labels):
        query=np.flatnonzero(labels==c); refs=np.flatnonzero(f==c)
        require(len(refs)>0,'predicted_fine_has_known_FIT_reference')
        distance=metric.pairwise_distances(z[query],np.asarray(fit_Z)[refs])
        require(distance.shape==(len(query),len(refs)) and np.isfinite(distance).all() and np.all(distance>=0),'finite_same_metric_reference_distance')
        k=min(7,len(refs)); score[query]=np.partition(distance,k-1,axis=1)[:,k-1]
    return score

def calibrate_known_cutoffs(score,predicted_coarse):
    score=np.asarray(score,np.float64); coarse=np.asarray(predicted_coarse)
    require(score.ndim==1 and len(score)>0 and coarse.shape==score.shape and coarse.dtype.kind in 'iu'
        and np.isfinite(score).all() and np.isin(coarse,(0,1)).all(),'all_known_CAL_scores_and_predicted_coarse')
    result={}
    for c in (0,1):
        value=np.sort(score[coarse==c]); n=len(value); rank=(99*(n+1)+99)//100
        enabled=bool(n and rank<=n)
        result[str(c)]=dict(support=n,rank_one_based=rank,enabled=enabled,
            cutoff=float(value[rank-1]) if enabled else None,strict_greater=True)
    return result

def candidate_mask(score,predicted_coarse,cutoffs):
    score=np.asarray(score,np.float64); c=np.asarray(predicted_coarse)
    require(score.ndim==1 and c.shape==score.shape and c.dtype.kind in 'iu'
        and np.isfinite(score).all() and np.isin(c,(0,1)).all(),'finite_query_score_and_actual_MHFD_coarse')
    raw=np.zeros(len(score),bool)
    for label in (0,1):
        item=cutoffs[str(label)]
        if item['enabled']: raw[c==label]=score[c==label]>item['cutoff']
    return raw

def _canonical(labels):
    mapping={}; out=np.full(len(labels),-1,np.int64)
    for i,c in enumerate(labels):
        if c>=0: out[i]=mapping.setdefault(int(c),len(mapping))
    return out

def metric_CH(metric,x,labels):
    """Declared generalized CH; all centre distances use the frozen metric."""
    clusters=np.unique(labels); n=len(x); k=len(clusters)
    require(k>1 and n>k,'CH_nonnoise_multicluster_required')
    centres=np.vstack([x[labels==c].mean(axis=0) for c in clusters])
    global_centre=x.mean(axis=0,keepdims=True)
    between=metric.pairwise_distances(centres,global_centre)[:,0]**2
    counts=np.asarray([int((labels==c).sum()) for c in clusters])
    within=0.
    for j,c in enumerate(clusters):
        within+=float(np.sum(metric.pairwise_distances(x[labels==c],centres[j:j+1])[:,0]**2))
    return 1. if within==0 else float(np.dot(counts,between)*(n-k)/(within*(k-1)))

def metric_affinity_geometry(metric,x,labels,distances):
    clusters=np.unique(labels[labels>=0]); require(len(clusters)>0,'primary_nonnoise_cluster_for_affinity')
    centres=np.vstack([x[labels==c].mean(axis=0) for c in clusters])
    centre_distance=metric.pairwise_distances(x,centres)
    bandwidth=np.asarray([max(float(centre_distance[labels==c,j].mean()),1.e-12) for j,c in enumerate(clusters)])
    squared=centre_distance**2; logp=-squared/(2.*bandwidth**2)
    errors=squared-logp; nearest=np.argmin(errors,axis=1); row=np.arange(len(x))
    reconstruction=errors[row,nearest]
    density_distance=np.partition(distances,min(7,len(x))-1,axis=1)[:,min(7,len(x))-1]
    density=1./(1.+density_distance)
    span=float(np.ptp(reconstruction)); normalized=(reconstruction-reconstruction.min())/span if span else np.zeros(len(x))
    anomaly=normalized*np.exp(-density)
    require(all(np.isfinite(a).all() for a in (reconstruction,density,anomaly)),'finite_same_metric_affinity_noise')
    return dict(reconstruction=reconstruction,density=density,anomaly=anomaly,
        affinity=np.exp(logp[row,nearest]),nearest_cluster=clusters[nearest],
        bandwidth=bandwidth,centres=centres)

def route_current_candidates(metric,Z,raw,*,seed=20261008):
    """No labels, source IDs, historical forecasts, anchors or fallback model."""
    z=np.asarray(Z,np.float64); raw=np.asarray(raw)
    require(z.ndim==2 and 0<len(z)<=6000 and 0<z.shape[1]<=128 and np.isfinite(z).all()
        and raw.shape==(len(z),) and raw.dtype==bool,'bounded_finite_MHFD_Z_and_current_raw')
    first=np.full(len(z),-2,np.int64); second=first.copy(); suspected=np.zeros(len(z),bool)
    reconstruction=np.zeros(len(z)); density=np.zeros(len(z)); anomaly=np.zeros(len(z))
    indices=np.flatnonzero(raw); order=np.lexsort(tuple(z[indices,j] for j in range(z.shape[1]-1,-1,-1)))
    indices=indices[order]; x=z[indices]
    manifest=dict(schema_version='single-MHFD-current-candidate-same-metric-DVC-v1',candidate_rows=len(x),
        minPts_grid=list(range(2,11)),eps_rule='normalized_k_distance_knee',
        parameter_selection='standard_precomputed_SC_then_generalized_same_metric_CH',
        paper_Eq11_Eq12_unspecified_additions_not_claimed=True,primary_and_secondary_same_metric=True,
        same_eps_minPts_secondary=True,alpha=1.,beta=1.,density_neighbors=7,
        noise_thresholds='label_blind_primary_nonnoise_R95_and_Dmedian',
        query_truth_ID_family_or_parent_used=False,known_anchor_rows=0, historical_UNA_OR=False,
        published=False,final_test_executed=False,evaluations=[],selected=None)
    best=labels=None
    if len(x)>=2:
        d=metric.pairwise_distances(x)
        require(d.shape==(len(x),len(x)) and np.isfinite(d).all() and np.all(d>=0)
            and np.array_equal(d,d.T) and np.all(np.diag(d)==0),'complete_symmetric_same_metric_DVC_matrix')
        for k in range(2,min(10,len(x))+1):
            kth=np.partition(d,k-1,axis=1)[:,k-1]; eps,knee=knee_radius(kth)
            value=DBSCAN(eps=eps,min_samples=k,metric='precomputed',n_jobs=1).fit_predict(d)
            supported=value>=0; count=len(np.unique(value[supported])); sc=ch=None
            if count>1 and int(supported.sum())>=count+2:
                part=d[np.ix_(supported,supported)]
                sc=float(silhouette_score(part,value[supported],metric='precomputed',
                    sample_size=min(1000,int(supported.sum())),random_state=seed))
                ch=metric_CH(metric,x[supported],value[supported])
                if not np.isfinite(sc) or not np.isfinite(ch): sc=ch=None
            item=dict(minPts=k,eps=eps,knee_index=knee,cluster_count=count,non_noise_rows=int(supported.sum()),silhouette=sc,calinski_harabasz=ch)
            manifest['evaluations'].append(item)
            if sc is not None and (best is None or (sc,ch)>(best['silhouette'],best['calinski_harabasz'])): best,labels=item,value
    if best is None:
        first[indices]=-1; retained=np.zeros(len(z),bool)
        manifest['status']='NO_ELIGIBLE_MULTI_CLUSTER_PARAMETER_FAIL_CLOSED'
    else:
        first[indices]=_canonical(labels); geom=metric_affinity_geometry(metric,x,labels,d)
        mask=labels>=0; rcut=float(np.quantile(geom['reconstruction'][mask],.95,method='higher'))
        dcut=float(np.median(geom['density'][mask])); s=(geom['reconstruction']>rcut)&(geom['density']<dcut)
        suspected[indices]=s
        reconstruction[indices]=geom['reconstruction']; density[indices]=geom['density']; anomaly[indices]=geom['anomaly']
        if s.any():
            second[indices[s]]=_canonical(DBSCAN(eps=best['eps'],min_samples=best['minPts'],metric='precomputed',n_jobs=1).fit_predict(d[np.ix_(s,s)]))
        retained=raw&(((first>=0)&~suspected)|(suspected&(second>=0)))
        manifest.update(status='CURRENT_DVC_COMPLETED_NOT_FINAL',selected=best,reconstruction_cutoff=rcut,density_cutoff=dcut,
            retained_rows=int(retained.sum()),suspected_rows=int(s.sum()),primary_centres=geom['centres'].tolist(),kernel_bandwidths=geom['bandwidth'].tolist())
    return dict(retained=retained,first=first,second=second,suspected=suspected,
        reconstruction=reconstruction,density=density,anomaly=anomaly,manifest=manifest)

def predict_current_main_chain(stage1,raw,route):
    stage1=np.asarray(stage1); raw=np.asarray(raw); retained=np.asarray(route['retained'])
    require(stage1.ndim==1 and stage1.dtype.kind in 'iu' and np.isin(stage1,(0,1)).all()
        and raw.shape==retained.shape==stage1.shape and raw.dtype==retained.dtype==bool
        and np.all(~retained|raw),'only_same_run_raw_DVC_supported_UNA')
    expected=raw&(((route['first']>=0)&~route['suspected'])|(route['suspected']&(route['second']>=0)))
    same(retained,expected,'same_run_primary_secondary_noise_formula')
    result=stage1.copy(); result[retained]=2
    return result

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output-directory',required=True)
    parser.add_argument('--prepare-known-only',action='store_true')
    parser.add_argument('--known-material-report')
    parser.add_argument('--known-material-report-sha256')
    args=parser.parse_args()
    if args.prepare_known_only:
        prepare_known(output_directory=args.output_directory)
    else:
        raise RuntimeError('unified_run_not_ready_before_metric_core_frozen')

if __name__=='__main__': main()
