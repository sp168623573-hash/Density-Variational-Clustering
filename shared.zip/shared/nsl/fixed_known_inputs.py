"""NSL2-only V970 inputs. No NN, metric fitting or truth loader on import.

The pilot consumes native115 plus the R960 source-only Z113 transform. R960
failed predictions never act as parent: only the complete V928 2963 does.
"""
from pathlib import Path
import hashlib
import importlib.util
import io
import json
import sys
import numpy as np

H=Path(__file__).resolve().parent
MANIFEST=H/'V970_NSL2_PILOT_INPUT_MANIFEST.json'

def require(v,s):
    if not bool(v):raise ValueError(s)

def descriptor(path):
    p=Path(path).resolve(strict=True)
    return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def raw(d):
    b=Path(d['path']).read_bytes();require(hashlib.sha256(b).hexdigest()==d['sha256'],'immutable input '+d['path']);return b

def js(d):return json.loads(raw(d).decode('utf-8-sig'))

def arrays(d,keys):
    with np.load(io.BytesIO(raw(d)),allow_pickle=False)as a:return{k:a[k]for k in keys}

def module_file(d,prefix):
    raw(d);name=prefix+'_'+d['sha256'];s=importlib.util.spec_from_file_location(name,d['path'])
    m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m

def manifest():return json.loads(MANIFEST.read_text(encoding='utf8'))

def assets(m=None):
    m=manifest()if m is None else m
    b=module_file(m['R960_boundary'],'v970_frozen_R960_input_boundary')
    return b.FrozenAssets('NSL2')

def transform_cached(role,ids,groups,m=None):
    """One consistent known-source q/RMS transform; no query fit or old scores."""
    m=manifest()if m is None else m;cache=m['readouts'][role]
    ro=arrays(cache,('ids','groups','embedding32','field_mse','field_signed','coarse_logits','fine_logits'))
    require(np.array_equal(ids,ro['ids'])and np.array_equal(groups,ro['groups']),'cache exact ID/group ordering')
    require(ro['embedding32'].shape==(len(ids),32)and ro['field_mse'].shape==ro['field_signed'].shape==(len(ids),40,2),'own original115/40 readout schema')
    C=module_file(m['R960_transform_core'],'v970_source_only_R960_transform')
    units=js(m['R960_signature_units']);z=C.transform(ro,units)['Z']
    require(z.shape==(len(ids),113)and np.isfinite(z).all(),'same original h32/sourceRMS plus q81')
    if role in m['stored_geometries']:
        stored=arrays(m['stored_geometries'][role],('ids','groups','Z'))
        require(np.array_equal(ids,stored['ids'])and np.array_equal(groups,stored['groups'])and np.array_equal(z,stored['Z']),
                'reused source/CAL geometry exact transform, not a new fit')
    return np.ascontiguousarray(z,dtype=np.float64)

def feature_matrix(native115,Z113):
    native,z=np.asarray(native115),np.asarray(Z113)
    require(native.dtype==np.float32 and native.shape==(len(z),115)and z.shape==(len(native),113),'same-row native115 and source-scaled113')
    x=np.concatenate((native.astype(np.float64),z),axis=1)
    require(x.shape==(len(native),228)and np.isfinite(x).all(),'fixed228, no current feature selection or scaling')
    return x

def load_source(m=None):
    m=manifest()if m is None else m;a=assets(m);f=a.load_fit();s=f['source'];t=f['training']
    ro=arrays(m['readouts']['source'],('ids','groups','fine'))
    require(np.array_equal(s['ids'],ro['ids'])and np.array_equal(s['groups'],ro['groups'])and np.array_equal(s['fine'],ro['fine']),
            'R950 public source roster and R960 source readout exact physical5967/fine9')
    z=transform_cached('source',s['ids'],s['groups'],m);x=feature_matrix(s['x'],z)
    return dict(X=x,Z113=z,native115=s['x'],ids=s['ids'],groups=s['groups'],fine=s['fine'],
                logical_training_ids=t['ids'][t['optimizer_indices']],logical_training_fine=t['fine'][t['optimizer_indices']],optimizer_indices=t['optimizer_indices'],
                logical_X=x[t['logical_to_genuine']][t['optimizer_indices']],logical_parent_ids=t['parent_ids'][t['optimizer_indices']],
                logical_to_genuine=t['logical_to_genuine'],trace=f['trace'],NN_readouts=0,NN_gradient_steps=0,new_Eq9_10_fit=0)

def load_role(role,m=None):
    require(role in('CAL','CP','current'),'declared complete role')
    m=manifest()if m is None else m;q=assets(m).load_role(role);z=transform_cached(role,q['ids'],q['groups'],m)
    p=arrays(m['best_parent'][role],('ids','prediction'))
    require(np.array_equal(q['ids'],p['ids'])and np.array_equal(q['parent_prediction'],p['prediction']),'whole original2963 parent only')
    return dict(X=feature_matrix(q['x'],z),Z113=z,native115=q['x'],ids=q['ids'],groups=q['groups'],
                parent_prediction=p['prediction'],role=role,query_truth_decodes=0,NN_readouts=0,new_Eq9_10_fit=0)

def load_known_labels(role,m=None):
    require(role in('CAL','CP'),'no current truth API; labels only CAL fit / sealed known validation')
    return assets(m).load_known_labels(role)

def density_metric(m=None):
    m=manifest()if m is None else m;M=module_file(m['R960_metric_core'],'v970_reused_R960_metric_class')
    metric=M.PaperVariationalPairMetric.from_state(js(m['R960_metric_state']))
    require(metric.dimension==113,'frozen source-only113 metric, never apply to auditor228')
    return metric
