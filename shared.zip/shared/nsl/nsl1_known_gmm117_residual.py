"""One FIT-only PCA-complement density increment beside complete NSL1 2602.

The sealed latent PCA/GMM is reused without refitting. Ledoit-Wolf class
covariances model all117 reconstruction residual coordinates; exactly constant
coordinates retain native unit1 deviation costs. Frozen MAIN and149 DVC remain.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import time
import numpy as np
from sklearn.covariance import LedoitWolf
from threadpoolctl import threadpool_limits
from . import nsl1_known_gmm117_candidate_v47 as latent
from .paired_integer_gate_status_v1 import gate_status

ROOT,files,previous = latent.ROOT,latent.files,latent.previous
BASE = ROOT/'data/external_dev/processed/nsl1_known_gmm117_residual_20261011_v47'
REGISTRY = ROOT/'tmp/nsl1_known_gmm117_residual_20261011_v47/registry_before_known_residual_fit.json'
SCHEMA = 'NSL1-preserved2602-FIT-only-sealedGMM-PCA-complement117-v47'
KNOWN_LATENT = dict(path=str(latent.BASE/'known/report.json'),sha256='5d4aaf5cac8b8f90ab61dc5eaaf99c3f8e7a68c7cd95e5cecd01b53475e685eb')
BASELINE2602 = dict(path=str(latent.BASE/'current/report.json'),sha256='9f10d677e5ead946f3906232badb3214a24d51431e7c2fdf8347a55be8e5ea2a')


def recipe():
    return dict(schema_version=SCHEMA,setting='NSL-KDD Setting1',FIT_original_cap=6000,
        latent='reuse exact sealed FIT-only PCA16 and classconditional full-covariance GMM; PCA/GMM refit0',
        residual='all117 encoded native41 minus sealed PCA16 inverse_transform; every native coordinate retained',
        residual_model='one LedoitWolf covariance per true known fine; shrinkage analytically estimated from that class FIT residuals only',
        constant='exact FIT-class constant residual coordinates have first-FIT-row center and native unit1 squared deviation, never discarded',
        density='joint negative loglikelihood = existing latentGMM NLL + 0.5*(residual active Mahalanobis + residual constant unit1 squared deviation + active covariance logdet +117log(2pi))',
        score='joint negative loglikelihood divided by fixed16+117=133 modeled coordinates; no alpha, score clamps, epsilon or learned target weights',
        covariance_epsilon=False,query_or_CAL_density_fit=False,unknown_label_fit=False,
        calibration='one new knownCAL656 predicted-MAIN-coarse finite99 strictgreater cutoff',
        consistency='raw candidates require frozen MAIN fine0/coarse0 or fine1..8/coarse1 agreement',
        DVC='same frozen learned149 geometry and metric, own candidates through centre-secondary affinity and noise',
        merge='copy complete2602 vector; only own raw AND own same-query DVC-retained become UNA',
        known_gate='actual current654 prefix, exact BEN/KNA integer99 and zero paired correct losses before unknown query numeric decode',
        no_new_NN_or_data=True,CPU_threads=2,formula_count=1,parameter_or_threshold_grid=False,
        current_scope='already observed original3598 development IDs',accepted_baseline_replaced=False,
        original2601_and2602_immutable=True,exact_original_paper_residual_density_formula_claim=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)


def freeze():
    pins = {};known = files.js(KNOWN_LATENT,pins);baseline = files.js(BASELINE2602,pins)
    old = files.js(known['registry'],pins)
    unsigned = dict(old);signature = unsigned.pop('registry_sha256')
    files.require(signature == files.digest(unsigned) and old['policy'] == latent.recipe()
        and old['sources']['caller'] == files.item(latent.__file__), 'exact sealed latent source and recipe')
    files.require(known['known_gate_passed'] and known['unknown_query_numeric_rows_decoded'] == 0
        and baseline['registry'] == known['registry'] and baseline['prediction_sealed']
        and baseline['EffectDelta']['verdict'] == 'UP'
        and baseline['original_class_gates']['BEN']['correct'] == 317
        and baseline['original_class_gates']['KNA']['correct'] == 335
        and baseline['original_class_gates']['UNA']['correct'] == 2602,
        'completed actual latent known gate and full2602 baseline')
    assets = dict(old['assets'],latent_state=known['files']['density_state'],baseline=baseline['files']['postseal_comparison'])
    headers = {n:latent.producer.metadata_headers(a,pins) for n,a in assets.items() if Path(a['path']).suffix == '.npz'}
    files.require(headers['latent_state']['pca_components']['shape'] == [16,117]
        and headers['encoded']['fit_features']['shape'] == [6000,117]
        and headers['query_geometry']['Z149']['shape'] == [3598,149]
        and headers['baseline']['prediction']['shape'] == [3598], 'explicit closed residual member headers')
    for a in assets.values(): files.read(a,pins)
    for a in old['sources'].values(): files.read(a,pins)
    sources = dict(old['sources']);sources['latent_caller'] = files.item(latent.__file__);sources['caller'] = files.item(__file__)
    reg = dict(schema_version=SCHEMA+'-registry',policy=recipe(),assets=assets,sources=sources,
        headers=headers,latent_known_report=KNOWN_LATENT,baseline_report=BASELINE2602,
        original2601_registry=known['registry'],material_descriptors=old['material_descriptors'],
        latent_state_members=known['density_state_members'],metric_state_sha256=previous.METRIC_STATE_SHA,
        fine_order=old['fine_order'],output={p:str(BASE/p) for p in ('known','current')},
        input_sha256=pins,numeric_array_decodes=0,published=False,final_test_executed=False,status='FAIL_TARGET99')
    reg['registry_sha256'] = files.digest(reg);REGISTRY.parent.mkdir(exist_ok=True)
    files.require(not REGISTRY.exists(),'fresh once-only residual registration')
    return files.write(REGISTRY,reg)


def bind(path,sha,pins):
    ref = dict(path=str(Path(path).resolve()),sha256=sha);reg = files.js(ref,pins)
    unsigned = dict(reg);signature = unsigned.pop('registry_sha256')
    files.require(signature == files.digest(unsigned) and reg['policy'] == recipe()
        and reg['sources']['caller'] == files.item(__file__),'one frozen residual source and recipe')
    for a in reg['sources'].values(): files.read(a,pins)
    for p,h in reg['input_sha256'].items(): files.read(dict(path=p,sha256=h),pins)
    return ref,reg


def residual(state,x):
    x = np.asarray(x,np.float64);z = latent.project(state,x)
    reconstructed = (z*state['pca_whiten_scale']) @ state['pca_components']+state['pca_mean']
    return x-reconstructed,z


def fit_residual(latent_state,x,y):
    r,_ = residual(latent_state,x);model = {};summaries = {}
    files.require(r.shape == (6000,117) and set(y.tolist()) == set(range(9)),'genuine all117 known residualFIT6000')
    for label in range(9):
        rows = r[y == label];active = np.any(rows != rows[:1],axis=0)
        centre = rows[0].copy()
        if active.any():
            lw = LedoitWolf(assume_centered=False,store_precision=True).fit(rows[:,active])
            sign,logdet = np.linalg.slogdet(lw.covariance_)
            files.require(sign > 0 and np.isfinite(logdet) and np.isfinite(lw.precision_).all(),
                'positive statistical shrinkage covariance without epsilon:'+str(label))
            centre[active] = lw.location_
            precision,covariance = lw.precision_.copy(),lw.covariance_.copy()
            shrinkage = float(lw.shrinkage_)
        else:
            precision = covariance = np.empty((0,0),np.float64);logdet = 0.;shrinkage = 0.
        model['fine'+str(label)+'_active'] = active
        model['fine'+str(label)+'_centre'] = centre
        model['fine'+str(label)+'_precision'] = precision
        model['fine'+str(label)+'_covariance'] = covariance
        model['fine'+str(label)+'_logdet'] = np.asarray(logdet,np.float64)
        summaries[str(label)] = dict(trueFIT_rows=len(rows),active_residual_coordinates=int(active.sum()),
            constant_unit1_coordinates=int((~active).sum()),shrinkage=shrinkage,logdet=float(logdet),epsilon_added=False)
    return model,summaries


def score(latent_state,model,x,fine,coarse):
    r,z = residual(latent_state,x);fine,coarse = np.asarray(fine),np.asarray(coarse)
    files.require(fine.shape == coarse.shape == (len(r),) and np.isin(fine,range(9)).all()
        and np.isin(coarse,(0,1)).all(),'original MAIN same-row coarse/fine only')
    latent_nll = np.empty(len(r),np.float64);residual_nll = np.empty(len(r),np.float64)
    constant_deviation = np.empty(len(r),np.float64);quadratic = np.empty(len(r),np.float64)
    for label in range(9):
        rows = fine == label
        if not rows.any(): continue
        active,centre,precision,logdet = (model['fine'+str(label)+'_'+name] for name in ('active','centre','precision','logdet'))
        d = r[rows]-centre;dactive = d[:,active]
        q = np.einsum('ni,ij,nj->n',dactive,precision,dactive,optimize=True) if active.any() else np.zeros(rows.sum())
        c = np.square(d[:,~active]).sum(axis=1)
        quadratic[rows],constant_deviation[rows] = q,c
        residual_nll[rows] = .5*(q+c+logdet+117*np.log(2*np.pi))
        latent_nll[rows] = latent.negative_density(latent_state,z[rows],label)
    combined = (latent_nll+residual_nll)/133.
    files.require(np.isfinite(combined).all(),'finite full117 residual joint density; no clamps or epsilon')
    consistent = ((fine == 0)&(coarse == 0))|((fine > 0)&(coarse == 1))
    return dict(score=combined,latent_negative_log_density=latent_nll,residual_negative_log_density=residual_nll,
        residual_quadratic=quadratic,constant_unit1_squared_deviation=constant_deviation,coarse_fine_consistent=consistent)


def save(out,report,name,value): return previous.save(out,report,name,value)


def run(phase,path,sha,known_path=None,known_sha=None):
    started,pins = time.perf_counter(),{};ref,reg = bind(path,sha,pins)
    if phase == 'current':
        kref = dict(path=str(Path(known_path).resolve()),sha256=known_sha);kr = files.js(kref,pins)
        files.require(kref['path'] == str(BASE/'known/report.json') and kr['registry'] == ref
            and kr['known_gate_passed'] and kr['unknown_query_numeric_rows_decoded'] == 0,
            'new known zero paired loss integer99 before any unknown query numeric decode')
    out = Path(reg['output'][phase]);files.require(not out.exists(),'fresh once-only residual phase');out.mkdir(parents=True)
    report = dict(schema_version=SCHEMA,phase=phase,registry=ref,policy=recipe(),files={},
        counts=dict(residual_covariance_fit=0,PCA_refit=0,GMM_refit=0,CAL_fit=0,query_score=0,DVC=0,NN_training=0,NN_forward=0,metric_fit=0),
        prediction_sealed=False,known_truth_opened=False,unknown_truth_opened=False,unknown_query_numeric_rows_decoded=0,
        accepted_baseline_replaced=False,published=False,final_test_executed=False,status='FAIL_TARGET99')
    try:
        prepared = previous.archive(reg['assets']['prepared'],tuple(reg['material_descriptors']),pins)
        files.require({k:previous.descriptor(v) for k,v in prepared.items()} == reg['material_descriptors'],'unchanged genuine149 known geometry')
        latent_state = previous.archive(reg['assets']['latent_state'],tuple(reg['latent_state_members']),pins)
        report['files']['latent_state'] = reg['assets']['latent_state']
        if phase == 'known':
            encoded = previous.archive(reg['assets']['encoded'],('fit_features','fit_known_fine','fit_ids','calibration_features','calibration_ids'),pins)
            files.require(len(set(encoded['fit_ids'].tolist())) == 6000
                and np.array_equal(encoded['fit_ids'],prepared['fit_ids'])
                and np.array_equal(encoded['fit_known_fine'],prepared['fit_fine'])
                and np.array_equal(encoded['fit_features'],prepared['fit_Z149'][:,32:])
                and np.array_equal(encoded['calibration_ids'],prepared['calibration_ids'])
                and np.array_equal(encoded['calibration_features'],prepared['calibration_Z149'][:,32:]), 'exact trueFIT6000 and frozenCAL656 all117')
            query = previous.prefix_archive(reg['assets']['query_geometry'],('ids','groups','Z149','stage1','predicted_fine'),654,pins)
            files.require(np.array_equal(query['ids'],prepared['open_known_ids'])
                and np.array_equal(query['Z149'],prepared['open_known_Z149'])
                and np.array_equal(query['groups'],prepared['open_known_groups'])
                and np.array_equal(query['stage1'],prepared['open_known_stage1'])
                and np.array_equal(query['predicted_fine'],prepared['open_known_predicted_fine']), 'actual current654 exact query input prefix')
            with threadpool_limits(limits=2): model,summaries = fit_residual(latent_state,encoded['fit_features'],encoded['fit_known_fine'])
            report['counts']['residual_covariance_fit'] = 9
            report['residual_fit_summary'] = summaries;report['FIT_original_rows'] = 6000;report['FIT_copies'] = 0
            state_asset = save(out,report,'FIT_only_truefine_LedoitWolf_residual117_state_before_CAL',model)
            report['files']['residual_state'] = state_asset;report['residual_state_members'] = list(model)
            report['files']['FIT_state_seal'] = files.write(out/'FIT_only_residual_state_seal_before_CAL.json',dict(residual_state=state_asset,
                latent_state=reg['assets']['latent_state'],registry=ref,FIT_only=True,CAL_used=False,query_used=False))
            cal = score(latent_state,model,encoded['calibration_features'],prepared['calibration_predicted_fine'],prepared['calibration_stage1'])
            save(out,report,'CAL656_joint_residual_scores_before_cutoffs',dict(**cal,stage1=prepared['calibration_stage1']))
            cut = previous.paper_route.calibrate_known_cutoffs(cal['score'],prepared['calibration_stage1'])
            report['files']['calibration'] = files.write(out/'knownCAL656_joint_residual_cutoffs_before_known654.json',dict(cutoffs=cut,query_used=False,
                original_CAL_rows=656,registry=ref,residual_state=state_asset,latent_state=reg['assets']['latent_state']))
            report['counts']['CAL_fit'] = 1;save(out,report,'actual_current_known654_geometry_before_score',query)
        else:
            query = previous.archive(reg['assets']['query_geometry'],('ids','groups','Z149','stage1','predicted_fine'),pins)
            report['unknown_query_numeric_rows_decoded'] = 2944
            saved = previous.archive(kr['files']['actual_current_known654_geometry_before_score'],('ids','groups','Z149','stage1','predicted_fine'),pins)
            files.require(query['Z149'].shape == (3598,149) and len(set(query['ids'].tolist())) == 3598
                and all(np.array_equal(query[k][:654],saved[k]) for k in saved),'full original3598 IDs and known actual-prefix identity')
            model = previous.archive(kr['files']['residual_state'],tuple(kr['residual_state_members']),pins)
            report['files']['residual_state'] = kr['files']['residual_state'];report['residual_state_members'] = kr['residual_state_members']
            report['known_report'] = kref;report['files']['calibration'] = kr['files']['calibration']
            cut = files.js(kr['files']['calibration'],pins)['cutoffs'];save(out,report,'actual_current3598_geometry_before_score',query)
        live = score(latent_state,model,query['Z149'][:,32:],query['predicted_fine'],query['stage1'])
        raw = previous.paper_route.candidate_mask(live['score'],query['stage1'],cut)&live['coarse_fine_consistent']
        report['counts']['query_score'] = 1;save(out,report,'new_joint_residual_density_before_DVC',dict(**live,raw=raw,stage1=query['stage1'],predicted_fine=query['predicted_fine']))
        metric = previous.load_metric(reg,pins)
        def sink(name,value,manifest):
            save(out,report,name+'_DVC_result',value);report['files'][name+'_DVC_manifest'] = files.write(out/(name+'_DVC_manifest.json'),manifest)
        report['counts']['DVC'] = 1;route,_ = previous.route_once(metric,query,raw,sink)
        baseline = previous.prefix_archive(reg['assets']['baseline'],('prediction',),654,pins)['prediction'] if phase == 'known' else previous.archive(reg['assets']['baseline'],('prediction',),pins)['prediction']
        pred = previous.merge(baseline,raw,route['retained'])
        pa = save(out,report,'prediction_before_truth',dict(ids=query['ids'],prediction=pred,baseline=baseline,raw=raw,retained=route['retained']))
        report['files']['prediction_seal'] = files.write(out/'prediction_seal_before_truth.json',dict(prediction=pa,registry=ref,
            metric=reg['assets']['metric'],residual_state=report['files']['residual_state'],latent_state=reg['assets']['latent_state'],CAL=report['files']['calibration'],truth_opened=False))
        report['prediction_sealed'] = True
        truth = previous.prefix_archive(reg['assets']['baseline'],('ids','truth'),654,pins) if phase == 'known' else previous.archive(reg['assets']['baseline'],('ids','truth'),pins)
        report['known_truth_opened'] = True;report['unknown_truth_opened'] = phase == 'current'
        files.require(np.array_equal(truth['ids'],query['ids']),'same original truth IDs after prediction seal')
        effect,gates,prior = previous.delta(truth['truth'],pred,baseline,full=phase == 'current')
        save(out,report,'postseal_comparison',dict(**truth,prediction=pred,baseline=baseline,raw=raw,retained=route['retained']))
        zero_loss = all(effect['gain_loss'][n]['loss'] == 0 for n in ('BEN','KNA'))
        report.update(execution_status='classconditional_GMM_residual117_'+phase+'_evaluated',original_class_gates=gates,baseline_class_gates=prior,
            EffectDelta=effect,paired_known_no_loss=zero_loss,known_gate_passed=zero_loss and all(gates[n]['passed'] for n in ('BEN','KNA')),
            all_three_integer99_passed=phase == 'current' and all(v['passed'] for v in gates.values()),
            DEV_review_eligible=phase == 'current' and effect['verdict'] == 'UP' and zero_loss,
            known_raw=int(raw[:654].sum()),known_retained=int(route['retained'][:654].sum()),
            unknown_raw=int(raw[654:].sum()),unknown_retained=int(route['retained'][654:].sum()),
            metric_state_sha256=metric.state_sha256,baseline2602_UNA_predictions_preserved=True,primary_classification_unchanged=True)
        report['explicit_gate_status'] = gate_status(gates,{n:effect['gain_loss'][n]['loss'] for n in ('BEN','KNA')})
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        for p,h in pins.items(): files.require(files.item(p)['sha256'] == h,'all residual frozen source/input bytes unchanged')
        report['input_sha256'] = pins;report['wall_seconds'] = time.perf_counter()-started;files.write(out/'report.json',report)
    return files.item(out/'report.json')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for n in ('registry','registry-sha256','known-report','known-sha256'): p.add_argument('--'+n)
    a = p.parse_args();print(json.dumps(freeze() if a.phase == 'freeze' else run(a.phase,a.registry,a.registry_sha256,a.known_report,a.known_sha256)))
