"""Recover the NSL-KDD ``duration`` column without consulting target labels.

The historical sampled files used by this project contain the last 40
NSL-KDD connection features but accidentally omit the first feature,
``duration``.  The official complete NSL-KDD rows are available locally.  A
duration value is admitted only when the 40 already-observed model features
map to exactly one duration across both complete source files.  Ambiguous or
missing matches stay missing and are accompanied by an availability flag.

Neither the attack label nor the difficulty column participates in the join.
This is important: using either field to disambiguate a target row would leak
evaluation truth into model input.
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import pandas as pd

from .config import NSL_FEATURE_COLUMNS


FULL_COLUMNS = ("duration",) + NSL_FEATURE_COLUMNS + ("label", "difficulty_level")
ENRICHED_COLUMNS = ("duration_recovered", "duration_recovery_available")


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _normalized_features(frame: pd.DataFrame) -> pd.DataFrame:
    missing = [column for column in NSL_FEATURE_COLUMNS if column not in frame]
    if missing:
        raise ValueError(f"NSL duration recovery lacks feature columns: {missing}")
    result = frame.loc[:, NSL_FEATURE_COLUMNS].copy()
    for column in NSL_FEATURE_COLUMNS[:3]:
        result[column] = result[column].astype(str).str.strip().str.casefold()
    for column in NSL_FEATURE_COLUMNS[3:]:
        result[column] = pd.to_numeric(result[column], errors="coerce")
    if result.loc[:, NSL_FEATURE_COLUMNS[3:]].isna().any().any():
        raise ValueError("NSL duration recovery found a non-numeric model feature")
    return result


def feature_fingerprint(frame: pd.DataFrame) -> pd.Series:
    """Return the label-free deterministic 40-feature join key."""

    normalized = _normalized_features(frame)
    values = pd.util.hash_pandas_object(normalized, index=False).to_numpy(
        dtype=np.uint64
    )
    return pd.Series(
        [f"{value:016x}" for value in values],
        index=frame.index,
        dtype="object",
    )


def build_duration_lookup(
    full_paths: Sequence[str | Path],
) -> tuple[dict[str, float], set[str], dict[str, Any]]:
    """Build a feature-only map and record every ambiguous fingerprint."""

    paths = tuple(Path(path).resolve() for path in full_paths)
    if len(paths) != 2:
        raise ValueError("duration recovery requires the two complete NSL source files")

    pieces: list[pd.DataFrame] = []
    file_audit: list[dict[str, Any]] = []
    for path in paths:
        if not path.is_file():
            raise FileNotFoundError(f"missing complete NSL source: {path}")
        frame = pd.read_csv(
            path,
            header=None,
            names=FULL_COLUMNS,
            usecols=range(41),
            low_memory=False,
        )
        if frame.shape[1] != 41:
            raise ValueError(f"{path} has {frame.shape[1]} loaded columns; expected 41")
        duration = pd.to_numeric(frame["duration"], errors="coerce")
        if duration.isna().any():
            raise ValueError(f"{path} contains a non-numeric duration")
        fingerprints = feature_fingerprint(frame)
        pieces.append(
            pd.DataFrame(
                {
                    "fingerprint": fingerprints.to_numpy(dtype=str),
                    "duration": duration.to_numpy(dtype=np.float64),
                }
            )
        )
        file_audit.append(
            {
                "path": str(path),
                "rows": int(len(frame)),
                "sha256": _sha256_file(path),
            }
        )

    combined = pd.concat(pieces, ignore_index=True)
    duration_sets = combined.groupby("fingerprint", sort=True)["duration"].agg(
        lambda values: tuple(sorted(set(float(value) for value in values)))
    )
    unique_lookup = {
        str(fingerprint): float(values[0])
        for fingerprint, values in duration_sets.items()
        if len(values) == 1
    }
    ambiguous = {
        str(fingerprint)
        for fingerprint, values in duration_sets.items()
        if len(values) != 1
    }
    audit = {
        "schema_version": "nsl-label-free-duration-lookup-v1",
        "join_features": list(NSL_FEATURE_COLUMNS),
        "join_excludes_label": True,
        "join_excludes_difficulty": True,
        "full_source_files": file_audit,
        "full_rows": int(len(combined)),
        "full_unique_feature_fingerprints": int(len(duration_sets)),
        "unique_duration_fingerprints": int(len(unique_lookup)),
        "ambiguous_duration_fingerprints": int(len(ambiguous)),
        "ambiguous_values_are_not_imputed_from_target_truth": True,
    }
    return unique_lookup, ambiguous, audit


def enrich_sample_frames(
    frames: Sequence[pd.DataFrame],
    *,
    full_paths: Sequence[str | Path],
) -> tuple[list[pd.DataFrame], dict[str, Any]]:
    """Add recovered duration and an availability indicator to sample frames."""

    lookup, ambiguous, lookup_audit = build_duration_lookup(full_paths)
    enriched: list[pd.DataFrame] = []
    frame_audit: list[dict[str, Any]] = []
    for index, source in enumerate(frames):
        frame = source.copy()
        fingerprints = feature_fingerprint(frame)
        duration = fingerprints.map(lookup).astype(float)
        available = duration.notna()
        frame["duration_recovered"] = duration
        frame["duration_recovery_available"] = available.astype(np.int64)
        missing = ~available & ~fingerprints.isin(ambiguous)
        ambiguous_rows = fingerprints.isin(ambiguous)
        frame_audit.append(
            {
                "frame_index": int(index),
                "rows": int(len(frame)),
                "recovered_rows": int(available.sum()),
                "ambiguous_rows": int(ambiguous_rows.sum()),
                "missing_rows": int(missing.sum()),
                "recovery_rate": float(available.mean()) if len(frame) else 0.0,
            }
        )
        enriched.append(frame)

    audit = {
        **lookup_audit,
        "sample_frames": frame_audit,
        "model_columns_added": list(ENRICHED_COLUMNS),
        "missing_duration_policy": (
            "known-only preprocessing median plus explicit availability indicator"
        ),
        "target_labels_used_for_recovery": False,
        "status": "admitted_label_free_partial_duration_recovery",
    }
    return enriched, audit

