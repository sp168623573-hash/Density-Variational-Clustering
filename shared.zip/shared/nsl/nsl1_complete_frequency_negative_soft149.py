"""Full old label-blind population-frequency raw cue, genuine negative anchors."""
import argparse,json,sys,time,types
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from . import nsl1_complete_two_view_query_reach149_v186 as previous
from . import nsl1_native117_query7_soft_core_v178 as softcore
from . import nsl1_collective_categorical_profile149_v116b as frequency
from . import nsl1_query7_contrast149_v164 as cached
ROOT,files,require=previous.ROOT,previous.files,previous.require
old,nsl=previous.old,previous.nsl;MODULE='paper_open_set.nsl1_complete_frequency_negative_soft149_v192'
DIR=ROOT/'tmp/nsl1_complete_frequency_negative_soft149_20261012_v192';BASE=ROOT/'data/external_dev/processed/nsl1_complete_frequency_negative_soft149_20261012_v192';REG=DIR/'registry_before_known.json'
def policy():
    return dict(schema_version='NSL1-fulloldV116b_frequency_seed-knownnegative149soft-v192',hypotheses=1,
        initial='all savedpretruth V116b raw candidates includingknown falsepositives OR all retainedwhole2855 pred2; no actualUNA/UID/fine/sample-selected seed',
        graph='complete genuine sourceowned learned149 cachedV164 query-to-all5999known and selfzero query-query distances, canonicalnative physicalgroupsonce; OR seeds group, allknownanchors0, exactnearest7 stableanchorfirstties Gaussian sigma7, .9 diffusion20 steps noqueryhardclamp',
        threshold='reuse exact alltrueknown V116 original CAL oncefinite99 only; soft strict>fixed.5 engineeringfloor, no new graphcut/refit/grid; score not unknownprobability',
        CAL_background_limitation='no complete old2855 CAL prediction asset exists; CAL descriptivegraph uses old V116 score-derived labelblind stage1BENscope raw only, does not invent old2855 CAL prediction2. CP/current use saved complete2855 includingerrors. Graphfloor not CAL-fitted, knownCP gate tests full combined initial recipe.',
        CAL_known_authority='all656 genuine trueknown IDs/coarse used only toverify originalonce99 rule; no truecoarse enters seed, graph, scope, anchor or node assignment',
        DVC='raw=fullV116braw AND soft>.5 AND baseline!=2; original149 DVC candidates raw OR entire2855pred2 background; complete2855 copy and newretained append2',
        nonduplicate='V118 grammarfilter and V120contextlocaldensity different; V178 seeds onlynative117ratio cue, not entireoldV116b falsepositive-inclusive largecoverage source',
        risk='transductive batchdensity and legacyDEV labels repeatedly observed, mixedBEN316 zero margin; knownpass alone not finalproof',
        NN_fit=0,NN_forward=0,metric_fit=0,main_R7_refit=0,critic_fit=0,query_fit=False,trueUNA_fit=False,parameter_grid=False,timecap_coded=False,extension_not_verbatim_paper=True,status='FAIL_TARGET99',published=False,final_test_executed=False)
def closure():
    found={};seen=set();todo=[sys.modules[__name__]]
    while todo:
        m=todo.pop()
        if m is None or id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if not p or not Path(p).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        found[MODULE if m is sys.modules[__name__] else m.__name__]=files.item(p)
        for value in vars(m).values():
            child=value if isinstance(value,types.ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            if child is not None:todo.append(child)
    return found
archive=previous.archive;save=previous.save
def freeze():
    started=time.perf_counter();pins={};pr=files.item(previous.REG);p=files.js(pr,pins);kr=files.item(previous.BASE/'known/report.json');cr=files.item(previous.BASE/'current/report.json');k=files.js(kr,pins);c=files.js(cr,pins);require(k['known_gate_passed'] and c['prediction_sealed'],'V186 completefailed heldbeforefreeze not promoted');a=dict(p['assets'])
    # Retain source2855 from V186 registry, never V186 mixed2913 prediction.
    for phase in ('known','current'):
        fr=files.item(frequency.BASE/'NSL1'/phase/'report.json');f=files.js(fr,pins);require(f['prediction_sealed'],'V116b old wholeprediction sealed');a['frequency_'+phase]=f['files']['complete_prediction_before_truth'];a['frequency_report_'+phase]=fr
        qr=files.item(cached.BASE/phase/'report.json');q=files.js(qr,pins);a['distance_CP' if phase=='known' else 'distance_current']=q['files']['CP_cue' if phase=='known' else 'current_cue']
        if phase=='known':a['distance_CAL']=q['files']['CAL_cue'];a['frequency_CAL']=f['files']['original_CAL_profile'];a['frequency_rule']=f['files']['rule']
    close_ref=files.item(previous.DIR/'NSL1_V186_COMPLETE_QUERY_REACH_COMPLETE_CLOSEOUT.json');close=files.js(close_ref,pins)
    for item in [*a.values(),*closure().values()]:files.read(item,pins)
    require(not REG.exists() and not BASE.exists(),'exclusive fullfrequencynegativegraph namespace');DIR.mkdir(parents=True,exist_ok=True)
    return files.write(REG,dict(policy=policy(),assets=a,sources=closure(),synthetic_contract=softcore.synthetic_contract(),previous_registry=pr,previous_known=kr,previous_current=cr,ancestry_closeout=close_ref,prior_necessary_preparation_seconds=close['actual_preparation']['necessary_allprep_plus_ancestry_seconds'],freeze_seconds=time.perf_counter()-started,input_sha256=pins,current_numeric_decodes=0))
def bind(ref,pins):
    r=files.js(ref,pins);require(r['policy']==policy() and r['sources']==closure(),'fixed fullfrequencynegativegraph frozen source');
    for path,sha in r['input_sha256'].items():files.read(dict(path=path,sha256=sha),pins)
    return r
def graph(q,seed,a,out,r,role,pins):
    start=time.perf_counter();d=archive(a['distance_'+role],('ids','groups','Z149','representatives','inverse','query_to_allknown_distances','query_pair_distances'),pins);require(np.array_equal(q['ids'],d['ids']) and np.array_equal(q['groups'],d['groups']) and np.array_equal(q['Z149'],d['Z149']),'exact ownrole sameordered original149 cache');rep,inv=cached.collapse(q);require(np.array_equal(rep,d['representatives']) and np.array_equal(inv,d['inverse']),'actualcanonical geometry noquerysubset');canonical=np.zeros(len(rep),bool);np.logical_or.at(canonical,inv,seed);g=softcore.diffusion(d['query_to_allknown_distances'],d['query_pair_distances'],canonical);r['graph_seconds'][role]=time.perf_counter()-start;r['files'][role+'_graph']=save(out,r,role+'_fullfrequency_knownnegative149_beforetruth',dict(ids=q['ids'],groups=q['groups'],representatives=rep,inverse=inv,initial_rows=seed,support_rows=g['support_score'][inv],**g));return g['support_score'][inv]
def run(phase,ref,knownref=None):
    started=time.perf_counter();pins={};reg=bind(ref,pins);control=None
    if phase=='current':control=files.js(knownref,pins);require(control['known_gate_passed'] and control['prediction_sealed'] and control['registry']==ref,'knownintegergate beforecurrentvalue')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False);r=dict(policy=policy(),phase=phase,registry=ref,files={},graph_seconds={},NN_fit=0,NN_forward=0,metric_fit=0,main_R7_refit=0,critic_fit=0,CAL_fit=0,DVC=0,current_numeric_decodes=0,prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        with threadpool_limits(limits=4):
            a=reg['assets'];metric=nsl.learned.PaperVariationalPairMetric.from_state(files.js(a['metric'],pins));reference=archive(a['reference'],('ids','groups','Z149'),pins);require(len(reference['ids'])==len(np.unique(reference['groups']))==5999 and metric.dimension==149,'samegenuine5999 and source149');r['files'].update(metric=a['metric'],reference=a['reference'],rule=a['frequency_rule']);rule=files.js(a['frequency_rule'],pins)
            if phase=='known':
                mat=archive(a['material'],('calibration_ids','calibration_groups','calibration_Z149','calibration_stage1'),pins);cal={key:mat['calibration_'+key] for key in ('ids','groups','Z149','stage1')};f=archive(a['frequency_CAL'],('ids','score'),pins);require(np.array_equal(cal['ids'],f['ids']),'all656 CALscore sourceauthority');labels=archive(a['encoded'],('calibration_ids','calibration_known_coarse'),pins);require(np.array_equal(cal['ids'],labels['calibration_ids']) and rule==nsl.base.paper_route.calibrate_known_cutoffs(f['score'],labels['calibration_known_coarse']),'originalexact oncealltrueknown99 rule unchanged');initial=nsl.base.paper_route.candidate_mask(f['score'],cal['stage1'],rule)&(cal['stage1']==0);graph(cal,initial,a,out,r,'CAL',pins)
            else:r['known_report']=knownref
            q,_,_=old.query('NSL1',phase,a,pins);merge=archive(a['merge_known' if phase=='known' else 'merge_current'],('ids','prediction'),pins);f=archive(a['frequency_'+phase],('ids','raw','prediction'),pins);require(np.array_equal(q['ids'],merge['ids']) and np.array_equal(q['ids'],f['ids']),'exact complete old2855 and V116b allrows');baseline=merge['prediction'];seed=f['raw']|(baseline==2);r['current_numeric_decodes']=len(q['ids']) if phase=='current' else 0;support=graph(q,seed,a,out,r,'CP' if phase=='known' else 'current',pins);raw=f['raw']&(support>softcore.FLOOR)&(baseline!=2);density=raw|(baseline==2)
            def sink(name,value,manifest):save(out,r,name+'_DVC_beforetruth',value);r['files'][name+'_DVC_manifest']=files.write(out/(name+'_DVC_manifest.json'),manifest)
            routed,_=nsl.base.route_once(metric,q,density,sink);r['DVC']=1;retained=raw&routed['retained'];prediction=baseline.copy();prediction[retained]=2;require(np.all(prediction[baseline==2]==2),'complete2855 old2 protected');values=dict(ids=q['ids'],prediction=prediction,baseline=baseline,frequency_raw=f['raw'],seed=seed,support=support,raw=raw,density=density,retained=retained);sealed=save(out,r,'complete_frequency_soft_prediction_beforetruth',values);r['files']['seal']=files.write(out/'complete_frequency_soft_prediction_seal_beforetruth.json',dict(predictions=sealed,registry=ref,metric=a['metric'],rule=a['frequency_rule'],querytruth_used=False));r['prediction_sealed']=True
            truth=nsl.parent.previous.prefix_archive(a['baseline'],('ids','truth'),654,pins) if phase=='known' else archive(a['baseline'],('ids','truth'),pins);require(np.array_equal(truth['ids'],q['ids']),'newfullfrequencyvector sealed beforetruth');y=truth['truth'];r['truth_opened']=True;gates,delta,binary=old.helpers.metrics(y,baseline,prediction);r.update(execution_status='NSL1_fullfrequency_negativegraph_original149_'+phase+'_completed',original_class_gates=gates,EffectDelta=delta,binary_attack_detection=binary,known_gate_passed=all(gates[name]['passed'] for name in ('BEN','KNA')),candidate_accepted_for_retention=False,raw_by_trueclass={name:int(((y==c)&raw).sum()) for c,name in enumerate(('BEN','KNA','UNA'))},retained_by_trueclass={name:int(((y==c)&retained).sum()) for c,name in enumerate(('BEN','KNA','UNA'))});save(out,r,'postseal_complete_frequency_soft_pair',dict(**values,truth=y))
            if phase=='current':r['perfect_frequency_soft_raw_UNA_ceiling']=int(((y==2)&((baseline==2)|raw)).sum())
        for path,sha in pins.items():require(files.item(path)['sha256']==sha,'all parentcompletevectors, frequency/cache, sourceown149 unchanged')
    except Exception as error:r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for key in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+key)
    args=p.parse_args();ref=None if args.registry is None else dict(path=str(Path(args.registry).resolve()),sha256=args.registry_sha256);known=None if args.known_report is None else dict(path=str(Path(args.known_report).resolve()),sha256=args.known_sha256);print(json.dumps(freeze() if args.phase=='freeze' else run(args.phase,ref,known)),flush=True)
