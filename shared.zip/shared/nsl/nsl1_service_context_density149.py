"""Application/service conditioned relative-density cue, same full149 DVC."""
import argparse,json,sys,time,types
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from . import nsl1_service_context_density_core_v148 as core
from . import nsl1_context_local_density_ratio149_v120 as previous
ROOT,files,require=previous.ROOT,previous.files,previous.require
old,nsl=previous.old,previous.nsl;MODULE='paper_open_set.nsl1_service_context_density149_v148'
DIR=ROOT/'tmp/nsl1_service_context_density149_20261012_v148';BASE=ROOT/'data/external_dev/processed/nsl1_service_context_density149_20261012_v148';REG=DIR/'registry_before_known.json'
def policy():
    return dict(schema_version='NSL1-allreal-service-context-relative-density-original149-v148',hypotheses=1,
        grouping='all complete actualencoder service onehot levels includingUNSEEN, context shape(N,1); no selectedservice or target-derivedfield',
        preservation='protocol/flag and all117physicalfields+actualmaskedMHFD32 remain in original149learneddistance, no fieldremoved',
        invariant='service/application population may span protocol/flag variation measured jointlyinside149, not triplet categoricalidentity',
        reference='genuineoriginal5999known groups canonicalfine0 BEN3240, allservice levels; optimizer6000family20 unchanged, no copy references',
        radius='fixed NFservice>=20,NQservice>=7,R7 closedball allties, queryselfexclude, countprior1; unavailablecontext eligiblefalse score0',
        score='log((query_other+1)/NQservice)-log((FIT_BEN_inball+1)/(NFservice+1))',
        CAL='trueknownBEN AND realstage1==0 negativepopulation, otherknown inactive/score0; all656trueknown oncefinite99, queryactualstage choosescutbank',
        query='same originalwhole2618 baselineBEN0 population asV120, including139nowcorrectUNA; no removaldue merge2757',
        merge='completeoriginal317/335/2757 old2 preserved; only originalpopulationBen0 AND merge!=2 newraw may append2 aftersame149DVC',
        DVC='newraw-only matchingoriginal149 primary/secondary paperdensityaffinity, genuinegroupsonce samefrozenmetric no reGraph/NN/metric/R7fit',
        history='oldservice/authcontext normal-support guards existed; this conditionalrelativepopulationdensity is not Ben identity or an unseenservice unknown certificate',
        budget='necessary typedmaskedNN+entire original149known producer only; historical unusedattempts separatelydisclosed, no codeddeadline',
        NN_fit=0,NN_forward=0,metric_fit=0,R7_fit=0,trueUNA_fit=False,parameter_grid=False,timecap_coded=False,
        extension_not_verbatim_paper=True,status='FAIL_TARGET99',published=False,final_test_executed=False)
def closure():
    result={};seen=set();todo=[sys.modules[__name__]]
    while todo:
        m=todo.pop()
        if m is None or id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if not p or not Path(p).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        result[MODULE if m is sys.modules[__name__] else m.__name__]=files.item(p)
        for value in vars(m).values():
            child=value if isinstance(value,types.ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            if child is not None:todo.append(child)
    return result
def archive(a,keys,pins):return old.archive(a,keys,pins)
def save(out,r,key,value):return old.save(out,r,key,value)
def synthetic_contract(mapping):
    fields=core.contexts_core.categorical_mapping(mapping);service=next(g for g in fields if g['field']=='service');protocol=next(g for g in fields if g['field']=='protocol_type');flag=next(g for g in fields if g['field']=='flag')
    z=np.zeros((40,149))
    for f in fields:z[:,32+f['selected_columns'][0]]=1
    changed=z[0].copy();changed[32+protocol['selected_columns'][0]]=0;changed[32+protocol['selected_columns'][1]]=1;changed[32+flag['selected_columns'][0]]=0;changed[32+flag['selected_columns'][1]]=1
    pair=np.stack((z[0],changed));ctx=core.service_contexts(pair[:,32:],mapping)
    require(ctx.shape==(2,1) and ctx[0,0]==ctx[1,0] and np.square(pair[0]-pair[1]).sum()>0,'service context invariant but allprotocol/flag coordinates retained149')
    class M:
        dimension=149
        def pairwise_distances(self,q,r=None):
            r=q if r is None else r;return np.sqrt(np.square(q[:,None]-r[None]).sum(2))
    bg=core.fit_background(z,np.array(['F'+str(i) for i in range(40)]),np.zeros(40,np.int64),mapping)
    q=z[:7].copy();groups=np.array(['Q'+str(i) for i in range(7)]);active=np.ones(7,bool);cue,detail=core.infer(M(),q,groups,active,bg,mapping)
    require(cue['contexts1'].shape==(7,1) and len(detail)==1 and np.all(cue['eligible']) and np.all(cue['FIT_ball_count']==40) and np.all(cue['query_other_ball_count']==6),'actualclosedties R7/selfexclude/support syntheticreturn')
    q2=q.copy();q2[:,32+service['selected_columns'][0]]=0;q2[:,32+service['selected_columns'][1]]=1;none,_=core.infer(M(),q2,groups,active,bg,mapping);require(not none['eligible'].any() and np.all(none['score']==0),'unseenservice unavailableevidence failclosed')
    copy,_=core.infer(M(),np.concatenate((q,q[2:3])),np.concatenate((groups,groups[2:3])),np.ones(8,bool),bg,mapping)
    require(int(copy['genuine_nativegroups'])==7 and np.array_equal(cue['genuine_score'],copy['genuine_score']),'nativecopies no population/reference amplification')
    return dict(synthetic_only=True,realtraffic=0,actualservice_columns=service['selected_columns'],context_shape=[7,1],protocol_flag_still_measured149=True,closedties_and_selfexclude=True,unseenservice_failclosed=True,genuinecopy_noamplification=True)
def freeze():
    started=time.perf_counter();pins={};pr=files.item(previous.registry_path('NSL1'));p=files.js(pr,pins);kr=files.item(previous.BASE/'NSL1/known/report.json');cr=files.item(previous.BASE/'NSL1/current/report.json');k=files.js(kr,pins);c=files.js(cr,pins)
    require(k['known_gate_passed'] and c['prediction_sealed'] and c['original_class_gates']['UNA']['correct']==2757,'actualwhole2757 completeknown/current source')
    a=dict(p['assets']);a.update(merge_known=k['files']['complete_prediction_before_truth'],merge_current=c['files']['complete_prediction_before_truth'])
    mapping=previous.fields_source.field_map_state(files.js(a['actual_encoder'],pins))['groups'];require(mapping==p['groups'],'realcurrent knownencoder fieldmap byteowned contract')
    service=next(g for g in core.contexts_core.categorical_mapping(mapping) if g['field']=='service');contract=synthetic_contract(mapping);src=closure()
    for item in [*a.values(),*src.values()]:files.read(item,pins)
    required_ancestry=dict(typedmasked_NN=p['ancestry_seconds']['primary_typedmasked_NN'],original149_wholeknown=p['ancestry_seconds']['original149_wholeknown'])
    historical=dict(p['ancestry_seconds']);historical['V120_actualfreeze_known_after_ancestry']=files.js(files.item(previous.DIR/'NSL1_ACTUAL_FINAL_RECEIPT_V120.json'),pins)['conservative_allprep_plus_ancestry_seconds']-p['necessary_ancestry_seconds']
    require(not REG.exists() and not BASE.exists(),'exclusive allservice context fixedhypothesis namespace')
    DIR.mkdir(parents=True,exist_ok=True)
    return files.write(REG,dict(policy=policy(),assets=a,sources=src,groups=mapping,service_field=service,synthetic_contract=contract,previous_registry=pr,previous_known=kr,previous_current=cr,
        necessary_ancestry_seconds=required_ancestry,necessary_ancestry_total=sum(required_ancestry.values()),historical_unused_attempts_and_prior_timing=historical,
        original_metric_extra_seconds_already_inside_wholeknown=p['ancestry_seconds']['original149_metric_extra_conservative_already_inside_wholeknown'],
        history_budget_not_fresh_training=True,freeze_seconds=time.perf_counter()-started,input_sha256=pins,current_numeric_decodes=0))
def bind(ref,pins):
    reg=files.js(ref,pins);require(reg['policy']==policy() and reg['sources']==closure(),'exactfrozenservice invariant/full149 policy andsource')
    for p,s in reg['input_sha256'].items():files.read(dict(path=p,sha256=s),pins)
    return reg
def cue_save(out,r,prefix,q,cue,detail):
    save(out,r,prefix,dict(ids=q['ids'],groups=q['groups'],Z149=q['Z149'],stage1=q['stage1'],**cue))
    for j,item in enumerate(detail):save(out,r,prefix+'_service'+str(j)+'_actualdistances',item)
def run(phase,ref,knownref=None):
    started=time.perf_counter();pins={};reg=bind(ref,pins);control=None
    if phase=='current':control=files.js(knownref,pins);require(control['known_gate_passed'] and control['prediction_sealed'] and control['registry']==ref,'newknownintegercontrol beforewholequeryservice evaluation')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False);r=dict(policy=policy(),phase=phase,registry=ref,files={},NN_fit=0,NN_forward=0,metric_fit=0,R7_fit=0,BEN_service_background_fit=0,CAL_fit=0,DVC=0,current_numeric_decodes=0,prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        with threadpool_limits(limits=4):
            a=reg['assets'];metric=nsl.learned.PaperVariationalPairMetric.from_state(files.js(a['metric'],pins));require(metric.dimension==149,'sameoriginalfull149 learnedowner');r['files']['metric']=a['metric']
            if phase=='known':
                prep=time.perf_counter();enc=archive(a['encoded'],('fit_ids','fit_features','fit_known_fine','calibration_ids','calibration_features','calibration_known_coarse'),pins);mat=archive(a['material'],('fit_ids','fit_fine','fit_Z149','calibration_ids','calibration_groups','calibration_Z149','calibration_stage1'),pins);original=archive(a['reference'],('ids','groups','Z149','original_indices','known_fine_membership'),pins)
                ix=original['original_indices'];fine=mat['fit_fine'][ix];require(len(mat['fit_ids'])==6000 and np.bincount(mat['fit_fine'],minlength=9).min()>=20 and len(ix)==len(np.unique(original['groups']))==5999 and np.array_equal(mat['fit_ids'],enc['fit_ids']) and np.array_equal(mat['fit_fine'],enc['fit_known_fine']) and np.array_equal(original['Z149'][:,32:],enc['fit_features'][ix].astype(np.float64)),'actual6000knownpresentations/genuine5999 canonicalknownroster')
                require(metric.to_state()['prefit_descriptor']['FIT_MHFD_Z']==nsl.base.descriptor(mat['fit_Z149']),'originalmetric fitsall149 parentroster not newservice projection')
                background=core.fit_background(original['Z149'],original['groups'],fine,reg['groups']);require(int(background['genuine_BEN_groups'])==3240,'allactualgenuineBEN3240 service references')
                r['BEN_service_background_fit']=1;r['files']['reference']=save(out,r,'genuineBEN3240_allservice_full149_reference_before_CAL',background)
                q={key:mat['calibration_'+key] for key in ('ids','groups','Z149','stage1')};require(np.array_equal(q['ids'],enc['calibration_ids']) and np.array_equal(q['Z149'][:,32:],enc['calibration_features'].astype(np.float64)),'allrealCAL656identity/native117')
                active=(enc['calibration_known_coarse']==0)&(q['stage1']==0);cal,detail=core.infer(metric,q['Z149'],q['groups'],active,background,reg['groups']);cue_save(out,r,'alltrueknownCAL656_servicepopulation_beforecut',q,cal,detail)
                save(out,r,'alltrueknownCAL656_negativepopulation_for_oncecut',dict(ids=q['ids'],truecoarse=enc['calibration_known_coarse'],active=active))
                rule=nsl.base.paper_route.calibrate_known_cutoffs(cal['score'],enc['calibration_known_coarse']);r['CAL_fit']=1;r['files']['rule']=files.write(out/'all656_trueknown_oncefinite99_servicecontext.json',rule);r['newFIT_CAL_preparation_seconds']=time.perf_counter()-prep
            else:background=archive(control['files']['reference'],('Z149','groups','original_genuine_indices','contexts1','vocabulary1','context_counts','genuine_BEN_groups'),pins);rule=files.js(control['files']['rule'],pins);r['files'].update(reference=control['files']['reference'],rule=control['files']['rule']);r['known_report']=knownref
            q,original_population,_=old.query('NSL1',phase,a,pins);merge=archive(a['merge_known' if phase=='known' else 'merge_current'],('ids','prediction'),pins);require(np.array_equal(merge['ids'],q['ids']),'whole2757 merge orderedids separatedfrom2618population')
            baseline=merge['prediction'];r['current_numeric_decodes']=len(q['ids']) if phase=='current' else 0;began=time.perf_counter();cue,detail=core.infer(metric,q['Z149'],q['groups'],original_population==0,background,reg['groups']);r['query_service_density_seconds']=time.perf_counter()-began
            raw=(original_population==0)&(baseline!=2)&cue['eligible']&nsl.base.paper_route.candidate_mask(cue['score'],q['stage1'],rule);cue_save(out,r,'wholeoriginal2618_BENpopulation_servicecue_beforeDVC',q,cue,detail)
            def sink(name,value,manifest):save(out,r,name+'_DVC_beforetruth',value);r['files'][name+'_DVC_manifest']=files.write(out/(name+'_DVC_manifest.json'),manifest)
            routed,_=nsl.base.route_once(metric,q,raw,sink);r['DVC']=1;retained=raw&routed['retained'];p=baseline.copy();p[retained]=2;require(np.all(p[baseline==2]==2),'allpriorwhole2757old2 intact, no knownconfidence veto')
            values=dict(ids=q['ids'],prediction=p,baseline=baseline,population_prediction=original_population,score=cue['score'],eligible=cue['eligible'],raw=raw,retained=retained)
            sealed=save(out,r,'complete_serviceprediction_beforetruth',values);r['files']['seal']=files.write(out/'complete_serviceprediction_seal_beforetruth.json',dict(predictions=sealed,registry=ref,reference=r['files']['reference'],rule=r['files']['rule'],metric=a['metric'],querytruth_used=False));r['prediction_sealed']=True
            if phase=='known':truth=nsl.parent.previous.prefix_archive(a['baseline'],('ids','truth'),654,pins)
            else:truth=archive(a['baseline'],('ids','truth'),pins)
            require(np.array_equal(truth['ids'],q['ids']),'truequery onlyafternewwholeprediction seal');y=truth['truth'];r['truth_opened']=True;gates,delta,binary=previous.helpers.metrics(y,baseline,p)
            r.update(execution_status='NSL1_serviceonly_context149_'+phase+'_completed',original_class_gates=gates,EffectDelta=delta,binary_attack_detection=binary,known_gate_passed=all(gates[n]['passed'] for n in ('BEN','KNA')),candidate_accepted_for_retention=False,
                raw_by_trueclass={n:int(((y==c)&raw).sum()) for c,n in enumerate(('BEN','KNA','UNA'))},retained_by_trueclass={n:int(((y==c)&retained).sum()) for c,n in enumerate(('BEN','KNA','UNA'))})
            save(out,r,'postseal_complete_serviceprediction_pair',dict(**values,truth=y))
            if phase=='current':r['perfect_service_raw_UNA_ceiling']=int(((y==2)&((baseline==2)|raw)).sum())
        for p,s in pins.items():require(files.item(p)['sha256']==s,'alloldsource/encoder/model/metric/wholeversion byteidentity preserved')
    except Exception as error:r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for key in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+key)
    a=p.parse_args();ref=None if a.registry is None else dict(path=str(Path(a.registry).resolve()),sha256=a.registry_sha256);k=None if a.known_report is None else dict(path=str(Path(a.known_report).resolve()),sha256=a.known_sha256)
    print(json.dumps(freeze() if a.phase=='freeze' else run(a.phase,ref,k)))
