"""Known-only expanded FIT6000 auxiliary MHFD with preserved heldout roles.

The original2579/2596 classifier pipelines are never modified. This module
materializes a new all41 encoder and trains one final80 model. No unknown
feature archive is opened, and heldout OPEN labels are read after its seal.
Training time is recorded, never used as a programmed stopping criterion.
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import io
import json
import os
from pathlib import Path
import time

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler

from . import config, model
from . import nsl1_all_native41_material_v1 as old_material
from . import nsl1_all_native41_known80_v1 as old_training
from . import nsl2_clean_known_material_training_v1 as output_io

files, ROOT = old_material.files, old_material.ROOT
BASE = ROOT/'data/external_dev/processed/nsl1_expanded_FIT6000_all41_20261009_v1'
SCHEMA = 'NSL1-expanded-FIT6000-original-all41-MHFD-final80-v1'
ROLES = dict(fit=6000,checkpoint=656,calibration=656,open_known=654)
FAMILIES = ('BEN',*config.get_spec('NSL-KDD Setting1').known_families)
EPOCHS, SEED = 80, 20261009
OLD = dict(path=str(ROOT/'data/external_dev/processed/nsl1_all_native41_material_20261009_v1/report.json'),sha256='35f0839ac457d46d05345131a3ae2afe676807d7c8f5b56163476522cda09e87')
ADDITIONS = dict(path=str(ROOT/'data/external_dev/processed/NSL_FIT_additions6000_20261009_v1/report.json'),sha256='1204960e84e6ca05c5edb4f64478b83904ede1995a9c602a0e554d9eb29f0f7b')
PROTOCOL = dict(path=str(ROOT/'tmp/currentdata_expansion_budget_20261009_v1/four_setting_expansion_protocol_v2.json'),sha256='6c53b19221d8221b066a6eba96d8026b047c43aac8bac93d957029c274b93cdc')
RAW_FIELDS = {'coarse_logits','fine_logits','embedding','reconstruction','gate_mean'}


def archive(asset,keys,pins):
    with np.load(io.BytesIO(files.read(asset,pins)),allow_pickle=False) as z:
        return {key:z[key].copy() for key in keys}


def save(out,name,values,report):
    path=out/(name+'.npz')
    with path.open('xb') as stream:
        np.savez_compressed(stream,**values)
    asset=files.item(path);report['files'][name]=asset
    return asset


def recipe():
    return dict(schema_version=SCHEMA,setting='NSL-KDD Setting1',classes=list(FAMILIES),
        FIT_original=6000,FIT_optimizer=6000,FIT_copies=0,roles=ROLES,
        encoder='new unique knownFIT log1p/RMS; complete all41, full FIT categorical vocabulary+UNSEEN; no feature pruning',
        model='unchanged MHFDNetwork attention/gate/position/CNN/BiLSTM/known heads/decoder',
        loss='coarseCE + .35 fineCE(smoothing.01) + .03 cleanSmoothL1',
        optimizer='AdamW .001 wd.0002 cosine80 min.0001 clip5',
        epochs=EPOCHS,batch_size=128,seed=SEED,CPU_threads=4,
        checkpoint='final80; no per-epoch heldout scoring',
        CAL='one calibration656 threshold, sealed before OPEN654',
        auxiliary_candidate_only=True,prior2579_and2596_unchanged=True,
        unknown_training_or_feature_reads=False,old_weights_transferred=False,
        independent_final_admitted=False,published=False,final_test_executed=False,status='FAIL_TARGET99')


def freeze():
    pins={};original=files.js(OLD,pins);addition=files.js(ADDITIONS,pins);protocol=files.js(PROTOCOL,pins)
    files.require(protocol['test_total_cap'] is None and protocol['actual_FIT_optimizer_cap']==6000,
        'latest user training budget and separate fixed holdouts')
    files.require(original['known_rows']==6000 and addition['settings']['NSL-KDD Setting1']['selected_original_rows']==1966,
        'original4034 FIT and true1966 additions')
    assets=dict(original_native=original['known_source'],original_encoded_labels=original['encoded_inputs'],
        additions=addition['settings']['NSL-KDD Setting1']['additions_archive'])
    for asset in assets.values(): files.read(asset,pins)
    reg=dict(schema_version=SCHEMA+'-registry',policy=recipe(),assets=assets,
        original_material_report=OLD,additions_report=ADDITIONS,protocol=PROTOCOL,
        sources={Path(module.__file__).name:files.item(module.__file__) for module in
            (old_material,old_training,model,config,output_io,files)},
        outputs=dict(material=str(BASE/'material'),train=str(BASE/'train')),
        input_sha256=pins,status='FAIL_TARGET99',published=False,final_test_executed=False)
    reg['sources']['caller']=files.item(__file__);reg['registry_sha256']=files.digest(reg)
    directory=ROOT/'tmp/nsl1_expanded_FIT6000_all41_20261009_v1';directory.mkdir(exist_ok=True)
    return files.write(directory/'registry_before_material_and_training.json',reg)


def bind(registry,sha,pins):
    reg=files.js(dict(path=str(Path(registry).resolve()),sha256=sha),pins)
    unsigned=dict(reg);signature=unsigned.pop('registry_sha256')
    files.require(signature==files.digest(unsigned) and reg['policy']==recipe()
        and reg['sources']['caller']==files.item(__file__),'frozen own expandedFIT contract')
    for asset in reg['sources'].values():files.read(asset,pins)
    return reg


def encode_native(original,state):
    numeric=state['numeric_indices'];vocab=state['categorical_vocabularies'];scale=np.asarray(state['log_numeric_FIT_RMS'])
    values=original[:,numeric].astype(np.float64)
    files.require(np.isfinite(values).all() and np.all(values>=0),'genuine finite nonnegative native numeric fields')
    logged=np.log1p(values);parts=[]
    for i in range(41):
        if str(i) in vocab:
            levels=vocab[str(i)];mapping={token:j for j,token in enumerate(levels)}
            positions=np.asarray([mapping.get(token,len(levels)) for token in original[:,i]],np.int64)
            part=np.zeros((len(original),len(levels)+1),np.float32);part[np.arange(len(original)),positions]=1
        else:
            j=numeric.index(i);part=(logged[:,j]/scale[j]).astype(np.float32)[:,None]
        parts.append(part)
    return np.concatenate(parts,axis=1)


def material(registry,sha):
    pins={};reg=bind(registry,sha,pins);out=Path(reg['outputs']['material'])
    files.require(out==BASE/'material' and not out.exists(),'fresh own expandedFIT material');out.mkdir(parents=True)
    report=dict(schema_version=SCHEMA+'-material',registry=dict(path=str(Path(registry).resolve()),sha256=sha),
        files={},unknown_numeric_decodes=0,OPEN_truth_opened=False,old_roles_changed=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        keys=tuple(role+'_'+key for role in ROLES for key in ('native41','ids'))
        old=archive(reg['assets']['original_native'],keys,pins)
        labels=archive(reg['assets']['original_encoded_labels'],tuple(role+'_'+key
            for role in ('fit','calibration') for key in ('known_fine','known_coarse')),pins)
        new=archive(reg['assets']['additions'],('native41','sample_ids','families','model40_groups'),pins)
        files.require(new['native41'].shape==(1966,41) and len(set(new['model40_groups'].tolist()))==1966
            and set(new['families'].tolist())<=set(FAMILIES),'fixed true known-only additions')
        raw={role:old[role+'_native41'] for role in ROLES}
        files.require(raw['fit'].shape==(4034,41),'exact old4034 prefix')
        raw['fit']=np.concatenate((raw['fit'],new['native41']))
        ids={role:old[role+'_ids'] for role in ROLES}
        ids['fit']=np.concatenate((ids['fit'],new['sample_ids']))
        fine_new=np.asarray([FAMILIES.index(family) for family in new['families'].tolist()],np.int64)
        labels['fit_known_fine']=np.concatenate((labels['fit_known_fine'],fine_new))
        labels['fit_known_coarse']=np.concatenate((labels['fit_known_coarse'],(fine_new!=0).astype(np.int64)))
        all_ids=np.concatenate(list(ids.values()))
        files.require(len(all_ids)==len(set(all_ids.tolist()))==7966,'FIT6000+immutable heldouts1966 distinct IDs')
        for role,n in ROLES.items():files.require(raw[role].shape==(n,41) and len(ids[role])==n,'native role size:'+role)
        seen=set();representatives=[]
        for i,row in enumerate(raw['fit']):
            group=tuple(row.tolist())
            if group not in seen:seen.add(group);representatives.append(i)
        cat=[i for i,field in enumerate(old_material.FIELDS) if field in ('protocol_type','service','flag')]
        numeric=[i for i in range(41) if i not in cat]
        native_numeric=raw['fit'][:,numeric].astype(np.float64)
        files.require(np.isfinite(native_numeric).all() and np.all(native_numeric>=0),'genuine expandedFIT numeric before units')
        logs=np.log1p(native_numeric)[representatives];largest=np.max(np.abs(logs),axis=0)
        nonzero=largest>0;scale=np.ones(len(numeric))
        scale[nonzero]=largest[nonzero]*np.sqrt(np.mean((logs[:,nonzero]/largest[nonzero])**2,axis=0))
        vocab={str(i):sorted(set(raw['fit'][:,i].tolist())) for i in cat}
        groups=[];names=[];width=0
        for i,field in enumerate(old_material.FIELDS):
            count=len(vocab[str(i)])+1 if i in cat else 1
            groups.append(dict(field=field,kind='categorical' if i in cat else 'numeric',selected_columns=list(range(width,width+count))))
            names.extend([field+'_'+token for token in vocab[str(i)]]+[field+'___UNSEEN__'] if i in cat else [field])
            width+=count
        state=dict(schema_version=SCHEMA+'-encoder',numeric_indices=numeric,
            categorical_vocabularies=vocab,log_numeric_FIT_RMS=scale.tolist(),fields=list(old_material.FIELDS),
            unique_native41_FIT_representative_indices=representatives,unique_native41_FIT_rows=len(representatives),
            original_field_groups=groups,encoded_feature_names=names,input_width=width,
            exactzero_FIT_numeric_fields=[old_material.FIELDS[numeric[i]] for i in np.flatnonzero(~nonzero)],
            no_variance_pruning=True,no_target_fit=True)
        state['state_sha256']=files.digest(state)
        encoder=files.write(out/'new_unique_FIT6000_all41_encoder_before_training.json',state)
        encoded={role+'_features':encode_native(raw[role],state) for role in ROLES}
        native_asset=save(out,'expanded_native_known7966_before_training',
            {**{r+'_native41':v for r,v in raw.items()},**{r+'_ids':v for r,v in ids.items()}},report)
        features_asset=save(out,'expanded_all41_known_inputs_before_training',
            {**encoded,**{r+'_ids':v for r,v in ids.items()},**labels},report)
        files.require(width==len(names) and len(groups)==41 and all(x.shape==(ROLES[key[:-9]],width)
            and x.dtype==np.float32 and np.isfinite(x).all() for key,x in encoded.items()),'full field map and encoded role arrays')
        report.update(execution_status='expandedFIT6000_all41_known_material_encoded',
            encoded_inputs=features_asset,known_source=native_asset,encoder=encoder,input_width=width,
            FIT_original=6000,heldout_rows=1966,total_known_material_rows=7966,
            original_FIT_prefix4034_preserved=True,original_holdout_values_and_IDs_preserved=True,
            FIT_family_counts=dict(Counter(FAMILIES[int(f)] for f in labels['fit_known_fine'])),
            preprocessor_fit_roles=['fit'],model_fit=0,inference=0)
        for path,wanted in pins.items():files.require(files.item(path)['sha256']==wanted,'frozen material input unchanged')
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        report['input_sha256']=pins;files.write(out/'report.json',report)
    return files.item(out/'report.json')


def infer_once(net,x,role,out,report):
    captured=[];state=output_io.state_digest(net);flags={n:p.requires_grad for n,p in net.named_parameters()}
    def hook(module,args,output):
        value={name:part.detach().float().cpu().numpy().copy() for name,part in output.items()}
        save(out,role+'_raw5_batch'+str(len(captured))+'_before_caller_guard',value,report)
        captured.append(value)
    handle=net.register_forward_hook(hook);report['counts']['known_infer_attempts']+=1
    try:
        result=model.infer(net,x,device=next(net.parameters()).device,batch_size=2048)
        report['counts']['known_infer_returns']+=1
    finally:handle.remove()
    values={key:np.asarray(value).copy() for key,value in vars(result).items()}
    for key in RAW_FIELDS:values['raw_'+key]=np.concatenate([batch[key] for batch in captured])
    values['embedding32']=values['embedding'].copy()
    save(out,role+'_complete_all7_raw5_before_caller_guard',values,report)
    files.require(all(set(batch)==RAW_FIELDS for batch in captured) and len(captured)==(len(x)+2047)//2048
        and len(vars(result))==7 and all(len(v)==len(x) and np.isfinite(v).all() for v in values.values())
        and flags=={n:p.requires_grad for n,p in net.named_parameters()}
        and output_io.state_digest(net)==state,'complete frozen real known inference outputs')
    report['counts']['known_forward_batches']+=len(captured)
    return values


def train(registry,sha,material_report,material_sha):
    started=time.perf_counter();pins={};reg=bind(registry,sha,pins)
    ma=dict(path=str(Path(material_report).resolve()),sha256=material_sha);mat=files.js(ma,pins)
    files.require(mat['registry']==dict(path=str(Path(registry).resolve()),sha256=sha)
        and mat['execution_status']=='expandedFIT6000_all41_known_material_encoded','completed own material')
    out=Path(reg['outputs']['train']);files.require(out==BASE/'train' and not out.exists(),'fresh once-only expandedFIT training');out.mkdir(parents=True)
    prior_threads=torch.get_num_threads();prior_env=os.environ.get('CUBLAS_WORKSPACE_CONFIG')
    report=dict(schema_version=SCHEMA,registry=dict(path=str(Path(registry).resolve()),sha256=sha),material=ma,
        policy=recipe(),files={},counts=dict(training_runs=0,known_infer_attempts=0,known_infer_returns=0,known_forward_batches=0,unknown_forward=0),
        unknown_numeric_decodes=0,OPEN_truth_opened=False,accepted_baseline_replaced=False,
        published=False,final_test_executed=False,status='FAIL_TARGET99',input_width=mat['input_width'])
    try:
        data=archive(mat['encoded_inputs'],tuple(role+'_'+key for role in ROLES for key in ('features','ids'))
            +tuple(role+'_'+key for role in ('fit','calibration') for key in ('known_fine','known_coarse')),pins)
        counts=Counter(data['fit_known_fine'].tolist())
        files.require(set(counts)==set(range(9)) and min(counts.values())>=20
            and data['fit_features'].shape==(6000,mat['input_width']),'all9 genuine training families and cap6000')
        report['files']['prefit']=files.write(out/'training_recipe_before_model_fit.json',dict(policy=recipe(),material=ma,
            input_width=mat['input_width'],optimizer_original_rows=6000,copies=0,
            runtime_environment=dict(CUBLAS_WORKSPACE_CONFIG=prior_env,torch_version=torch.__version__),
            old_model_transfer=False,unknown_and_OPEN_labels_used_in_fit=False))
        torch.set_num_threads(4);model.set_seed(SEED)
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        net=model.MHFDNetwork(mat['input_width'],9).to(device)
        sampler=WeightedRandomSampler(model._hierarchical_sample_weights(data['fit_known_fine']),num_samples=6000,replacement=True,
            generator=torch.Generator().manual_seed(SEED))
        loader=DataLoader(TensorDataset(torch.from_numpy(data['fit_features']),torch.from_numpy(data['fit_known_coarse']),
            torch.from_numpy(data['fit_known_fine'])),batch_size=128,sampler=sampler,num_workers=0,pin_memory=device.type=='cuda')
        optimizer=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.0002)
        scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=80,eta_min=.0001)
        scaler=torch.amp.GradScaler('cuda',enabled=device.type=='cuda')
        cc=nn.CrossEntropyLoss();cf=nn.CrossEntropyLoss(label_smoothing=.01);cr=nn.SmoothL1Loss()
        history=[];training_start=time.perf_counter();report['counts']['training_runs']=1
        for epoch in range(1,81):
            net.train();total=0.;seen=0
            for xb,cb,fb in loader:
                xb,cb,fb=xb.to(device),cb.to(device),fb.to(device);optimizer.zero_grad(set_to_none=True)
                with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=device.type=='cuda'):
                    outputs=net(xb);loss=cc(outputs['coarse_logits'],cb)+.35*cf(outputs['fine_logits'],fb)+.03*cr(outputs['reconstruction'],xb)
                files.require(torch.isfinite(loss).item(),'finite actual expandedFIT loss')
                scaler.scale(loss).backward();scaler.unscale_(optimizer);nn.utils.clip_grad_norm_(net.parameters(),5.)
                scaler.step(optimizer);scaler.update();total+=float(loss.detach())*len(xb);seen+=len(xb)
            scheduler.step();history.append(dict(epoch=epoch,loss=total/seen,learning_rate=scheduler.get_last_lr()[0]))
            files.write(out/'actual_history_completed_epochs.json',history)
            if epoch==1 or epoch%10==0:print(f'[NSL1 expanded FIT6000] epoch={epoch}/80 loss={total/seen:.6f} elapsed={time.perf_counter()-training_start:.1f}s',flush=True)
        report.update(training_seconds=time.perf_counter()-training_start,epochs_completed=80,device=str(device))
        state=output_io.state_digest(net);checkpoint=out/'expanded_FIT6000_MHFD_all41_final80.pt'
        torch.save(dict(state_dict={n:p.detach().cpu() for n,p in net.state_dict().items()},input_dim=mat['input_width'],
            fine_classes=list(FAMILIES),epochs_completed=80,model_state_sha256=state,seed=SEED),checkpoint)
        report['files']['model']=files.item(checkpoint);report['model_state_sha256']=state;net.eval()
        outputs={role:infer_once(net,data[role+'_features'],role,out,report) for role in ('fit','checkpoint','calibration')}
        theta,metrics=model.choose_coarse_threshold(data['calibration_known_coarse'],outputs['calibration']['attack_probability'])
        report['files']['threshold']=files.write(out/'CAL656_threshold_sealed_before_OPEN654.json',dict(threshold=float(theta),
            CAL_IDs=old_training.array_descriptor(data['calibration_ids']),calibration_metrics=metrics,
            model=report['files']['model'],OPEN_truth_used=False))
        outputs['open_known']=infer_once(net,data['open_known_features'],'open_known',out,report)
        predictions={role+'_prediction':(values['attack_probability']>=theta).astype(np.int64) for role,values in outputs.items()}
        predictions.update({role+'_ids':data[role+'_ids'] for role in outputs})
        pa=save(out,'complete_known_predictions_before_OPEN_truth',predictions,report)
        report['files']['prediction_seal']=files.write(out/'known_predictions_sealed_before_OPEN_truth.json',dict(predictions=pa,
            model=report['files']['model'],threshold=report['files']['threshold'],OPEN_truth_opened=False))
        truth=archive(reg['assets']['original_encoded_labels'],('open_known_ids','open_known_known_coarse'),pins)
        report['OPEN_truth_opened']=True
        files.require(np.array_equal(truth['open_known_ids'],data['open_known_ids']),'fixed654 comparison IDs')
        gs={role:old_training.bridge_gates(data[role+'_known_coarse'],predictions[role+'_prediction']) for role in ('fit','calibration')}
        gs['open_known']=old_training.bridge_gates(truth['open_known_known_coarse'],predictions['open_known_prediction'])
        report.update(execution_status='expandedFIT6000_MHFD_final80_known_evaluated',coarse_threshold=float(theta),known_class_gates=gs,
            known654_passed=all(n['passed'] for n in gs['open_known'].values()),unknown_performance_measured=False,
            training_and_FIT_encoding_changes_joint=True,auxiliary_geometry_requires_new_known_only_metric_and_CAL=True)
        files.require(output_io.state_digest(net)==state,'weights unchanged during heldout inference')
        for path,wanted in pins.items():files.require(files.item(path)['sha256']==wanted,'training source/data unchanged')
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        torch.set_num_threads(prior_threads)
        report['runtime_restoration']=dict(intraop_threads=torch.get_num_threads(),CUBLAS_WORKSPACE_CONFIG=os.environ.get('CUBLAS_WORKSPACE_CONFIG'),unchanged_environment=os.environ.get('CUBLAS_WORKSPACE_CONFIG')==prior_env)
        report['wall_seconds']=time.perf_counter()-started;report['input_sha256']=pins;files.write(out/'report.json',report)
    return files.item(out/'report.json')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=('freeze','material','train'),required=True)
    parser.add_argument('--registry');parser.add_argument('--registry-sha256')
    parser.add_argument('--material-report');parser.add_argument('--material-sha256')
    args=parser.parse_args()
    result=freeze() if args.phase=='freeze' else material(args.registry,args.registry_sha256) if args.phase=='material' else train(args.registry,args.registry_sha256,args.material_report,args.material_sha256)
    print(json.dumps(result))
