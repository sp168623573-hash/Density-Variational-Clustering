"""Complete-view query versus genuine-known local reachability, fixed k=7."""
import numpy as np
from scipy.spatial.distance import cdist
from . import nsl1_complete_two_view_lof_core_v185 as inherited
K=7
require=inherited.require

def closed_ratio(a,b):
    m=np.maximum(a,b);out=np.zeros_like(a);positive=m>0;x=a[positive]/m[positive];y=b[positive]/m[positive];out[positive]=x/(x+y);return out

def query_view(reference,query,state):
    q=np.asarray(query,np.float64);require(len(q)>K,'canonical ownrole population has genuine7 other queries')
    # Only known negative reference state is reused, no current state is fitted.
    known=inherited.query_view(reference,q,state)
    qq=cdist(q,q,'euclidean');ix,near=inherited.nearest(qq,True);radius=near[:,-1];reach=np.maximum(near,radius[ix]).mean(1)
    score=closed_ratio(known['mean_reach'],reach)
    require(np.isfinite(score).all() and np.all((score>=0)&(score<=1)),'natural closed reachability ratio')
    return dict(known_neighbors=known['neighbors'],known_neighbor_distances=known['neighbor_distances'],known_mean_reach=known['mean_reach'],query_neighbors=ix,query_neighbor_distances=near,query_k_distance=radius,query_mean_reach=reach,reach_score=score)

def score(reference,query,state):
    f=np.asarray(reference,np.float64);q=np.asarray(query,np.float64);require(f.shape[1]==q.shape[1]==149,'all original149 and native117 fixed')
    native=query_view(f[:,32:],q[:,32:],state['native117']);whole=query_view(f,q,state['whole149']);return np.sqrt(native['reach_score']*whole['reach_score']),dict(native117=native,whole149=whole)

def synthetic_contract():
    f=np.zeros((9,149));f[:,32]=np.arange(9)*.1;state=inherited.fit(f);q=np.zeros((9,149));q[:,32]=np.arange(9)*.001+10;value,proof=score(f,q,state);require(np.all(value>.99),'dense remote unlabeled population has high known-vs-query reachability');require(np.all(proof['native117']['query_neighbors']!=np.arange(9)[:,None]),'query selfexcluded')
    require(closed_ratio(np.array([0.,1.,0.]),np.array([0.,0.,1.])).tolist()==[0.,1.,0.],'no epsilon genuinebothzero0')
    return dict(synthetic_only=True,realtraffic=0,all_complete117=True,all_complete149=True,query_selfexcluded=True,known_state_not_refit=True,no_truth_or_queryfine=True,no_epsilon=True,K=K)
