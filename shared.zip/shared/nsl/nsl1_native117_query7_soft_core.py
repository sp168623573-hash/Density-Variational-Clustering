"""Complete physical117 query7 contrast with fixed genuine-known soft suppression."""
import numpy as np
from scipy.spatial.distance import cdist
K=7;ALPHA=.9;ITERATIONS=20;FLOOR=.5;DIM=117
def require(value,reason):
    if not value:raise ValueError(reason)
def ratio(d,q):
    maximum=np.maximum(d,q);score=np.zeros_like(d);active=maximum>0;a=d[active]/maximum[active];b=q[active]/maximum[active];score[active]=a*a/(a*a+b*b);return score
def population(reference,query):
    f=np.asarray(reference,np.float64);q=np.asarray(query,np.float64)
    require(f.shape==(len(f),DIM) and q.shape==(len(q),DIM) and len(f)>0 and len(q)>K and np.isfinite(f).all() and np.isfinite(q).all(),'allcomplete117 genuineknown/nativequery')
    qf=cdist(q,f,metric='euclidean');qq=cdist(q,q,metric='euclidean');d=qf.min(1);other=qq.copy();np.fill_diagonal(other,np.inf);r7=np.partition(other,K-1,axis=1)[:,K-1];score=ratio(d,r7)
    require(np.array_equal(qq,qq.T) and np.all(np.diag(qq)==0) and np.isfinite(score).all() and np.all((score>=0)&(score<=1)),'actualEuclidean117 selfexcludedquery7 closedratio')
    return dict(score=score,nearest_allknown_distance=d,query_other_R7=r7,query_to_allknown_distances=qf,query_pair_distances=qq)
def diffusion(qf,qq,initial_raw):
    qf=np.asarray(qf,np.float64);qq=np.asarray(qq,np.float64);raw=np.asarray(initial_raw);n=len(qq);anchors=qf.shape[1]
    require(qq.shape==(n,n) and qf.shape[0]==n and raw.shape==(n,) and raw.dtype==bool and anchors+n-1>=K,'oneactualcanonicalquerynode and allknown0anchors')
    neighbors=np.empty((n,K),np.int64);distance=np.empty((n,K))
    for begin in range(0,n,128):
        end=min(begin+128,n);d=np.concatenate((qf[begin:end],qq[begin:end]),axis=1);d[np.arange(end-begin),anchors+np.arange(begin,end)]=np.inf
        order=np.argsort(d,axis=1,kind='stable')[:,:K];neighbors[begin:end]=order;distance[begin:end]=np.take_along_axis(d,order,axis=1)
    require(np.isfinite(distance).all() and np.all(neighbors!=anchors+np.arange(n)[:,None]),'exactglobalneighbor7 selfexcluded anchorfirststabletie')
    sigma=distance[:,-1];positive=sigma>0;weights=np.empty_like(distance);weights[positive]=np.exp(-.5*(distance[positive]/sigma[positive,None])**2);weights[~positive]=(distance[~positive]==0).astype(float);weights/=weights.sum(1,keepdims=True)
    initial=raw.astype(float);score=initial.copy();history=[]
    for _ in range(ITERATIONS):
        allscore=np.concatenate((np.zeros(anchors),score));score=ALPHA*np.sum(weights*allscore[neighbors],axis=1)/weights.sum(1)+(1-ALPHA)*initial;history.append(score.copy())
    require(np.all((score>=0)&(score<=1)),'boundedsoftindicator not probability')
    return dict(support_score=score,neighbors=neighbors,neighbor_distances=distance,sigma=sigma,weights=weights,initial_raw=raw,trajectory=np.stack(history),anchors_zero=np.zeros(anchors))
def synthetic_contract():
    reference=np.zeros((8,DIM));query=np.zeros((9,DIM));query[:,0]=np.arange(9)*1.e-5;p=population(reference,query);near=diffusion(p['query_to_allknown_distances'],p['query_pair_distances'],np.ones(9,bool))
    require(near['support_score'][0]<FLOOR,'knownnegativeanchors suppress truecomputed raw1 without hardqueryclamp')
    far=query.copy();far[:,0]+=10;p=population(reference,far);remote=diffusion(p['query_to_allknown_distances'],p['query_pair_distances'],np.ones(9,bool));require(np.all(remote['support_score']>FLOOR),'remote mutual rawcue corroborates')
    zero=diffusion(p['query_to_allknown_distances'],p['query_pair_distances'],np.zeros(9,bool));require(np.all(zero['support_score']==0),'zeroinitial follows math never knownrole shortcut')
    direct=p['query_pair_distances'].copy();np.fill_diagonal(direct,np.inf);require(np.array_equal(np.sort(direct,axis=1)[:,6],p['query_other_R7']),'trueother7 closedties no self')
    require(ratio(np.array([0.,1.,0.]),np.array([0.,0.,1.])).tolist()==[0.,1.,0.],'naturalbothzero no epsilon')
    return dict(synthetic_only=True,realtraffic=0,complete117=True,selfexcluded=True,knownanchors_negative=True,queryraw_not_hardclamped=True,remote_support=True,zero_initial_not_roleflag=True,finite_floor_fixed=FLOOR)
