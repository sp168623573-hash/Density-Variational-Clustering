"""Actual ViM matching174 admission: native117+realMHFD32+signedresidual16+actualfine9. Scientific Eq9/10 or DVC numeric mathematics inherited; dimension guard onlychanged."""
from __future__ import annotations
import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.metrics import silhouette_score
from .nsl_auth2188_frozen_conditional_blocks_warm_pair_v2 import require, same
from .dependence_candidate_paper_dvc import knee_radius
DVC_SOURCE_MODULE = 'paper_open_set/nsl1_hybrid147_dvc_v1.py'
DVC_SOURCE_SHA256 = 'ba7368a2f2be5f1d2f0571002055f9e9fcaf7aca96fa58e71b06f980e0d59a2d'
KNEE_SOURCE_MODULE = 'paper_open_set/dependence_candidate_paper_dvc.py'
KNEE_SOURCE_SHA256 = '2ef8928db73f6cf27de011ee7dd6f110acf1e780e28f0f895245a3a60279ec57'
WIDTH = 174

def _canonical(labels):
    mapping = {}
    out = np.full(len(labels), -1, np.int64)
    for i, c in enumerate(labels):
        if c >= 0:
            out[i] = mapping.setdefault(int(c), len(mapping))
    return out

def metric_CH(metric, x, labels):
    """Declared generalized CH; all centre distances use the frozen metric."""
    clusters = np.unique(labels)
    n = len(x)
    k = len(clusters)
    require(k > 1 and n > k, 'CH_nonnoise_multicluster_required')
    centres = np.vstack([x[labels == c].mean(axis=0) for c in clusters])
    global_centre = x.mean(axis=0, keepdims=True)
    between = metric.pairwise_distances(centres, global_centre)[:, 0] ** 2
    counts = np.asarray([int((labels == c).sum()) for c in clusters])
    within = 0.0
    for j, c in enumerate(clusters):
        within += float(np.sum(metric.pairwise_distances(x[labels == c], centres[j:j + 1])[:, 0] ** 2))
    return 1.0 if within == 0 else float(np.dot(counts, between) * (n - k) / (within * (k - 1)))

def metric_affinity_geometry(metric, x, labels, distances):
    clusters = np.unique(labels[labels >= 0])
    require(len(clusters) > 0, 'primary_nonnoise_cluster_for_affinity')
    centres = np.vstack([x[labels == c].mean(axis=0) for c in clusters])
    centre_distance = metric.pairwise_distances(x, centres)
    bandwidth = np.asarray([max(float(centre_distance[labels == c, j].mean()), 1e-12) for j, c in enumerate(clusters)])
    squared = centre_distance ** 2
    logp = -squared / (2.0 * bandwidth ** 2)
    errors = squared - logp
    nearest = np.argmin(errors, axis=1)
    row = np.arange(len(x))
    reconstruction = errors[row, nearest]
    density_distance = np.partition(distances, min(7, len(x)) - 1, axis=1)[:, min(7, len(x)) - 1]
    density = 1.0 / (1.0 + density_distance)
    span = float(np.ptp(reconstruction))
    normalized = (reconstruction - reconstruction.min()) / span if span else np.zeros(len(x))
    anomaly = normalized * np.exp(-density)
    require(all((np.isfinite(a).all() for a in (reconstruction, density, anomaly))), 'finite_same_metric_affinity_noise')
    return dict(reconstruction=reconstruction, density=density, anomaly=anomaly, affinity=np.exp(logp[row, nearest]), nearest_cluster=clusters[nearest], bandwidth=bandwidth, centres=centres)

def route_current_candidates(metric, Z, raw, *, seed=20261008):
    """No labels, source IDs, historical forecasts, anchors or fallback model."""
    z = np.asarray(Z, np.float64)
    raw = np.asarray(raw)
    require(z.ndim == 2 and 0 < len(z) and (z.shape[1] == WIDTH) and (metric.dimension == WIDTH) and np.isfinite(z).all() and (raw.shape == (len(z),)) and (raw.dtype == bool), 'bounded_finite_exact_expandedaux174_Z_same174_metric_and_current_raw')
    first = np.full(len(z), -2, np.int64)
    second = first.copy()
    suspected = np.zeros(len(z), bool)
    reconstruction = np.zeros(len(z))
    density = np.zeros(len(z))
    anomaly = np.zeros(len(z))
    indices = np.flatnonzero(raw)
    order = np.lexsort(tuple((z[indices, j] for j in range(z.shape[1] - 1, -1, -1))))
    indices = indices[order]
    x = z[indices]
    manifest = dict(schema_version='NSL1-expandedaux174-current-candidate-same174-metric-DVC-v1', candidate_rows=len(x), minPts_grid=list(range(2, 11)), eps_rule='normalized_k_distance_knee', parameter_selection='standard_precomputed_SC_then_generalized_same_metric_CH', paper_Eq11_Eq12_unspecified_additions_not_claimed=True, primary_and_secondary_same_metric=True, same_eps_minPts_secondary=True, alpha=1.0, beta=1.0, density_neighbors=7, noise_thresholds='label_blind_primary_nonnoise_R95_and_Dmedian', query_truth_ID_family_or_parent_used=False, known_anchor_rows=0, historical_UNA_OR=False, published=False, final_test_executed=False, evaluations=[], selected=None)
    best = labels = None
    if len(x) >= 2:
        d = metric.pairwise_distances(x)
        require(d.shape == (len(x), len(x)) and np.isfinite(d).all() and np.all(d >= 0) and np.array_equal(d, d.T) and np.all(np.diag(d) == 0), 'complete_symmetric_same_metric_DVC_matrix')
        for k in range(2, min(10, len(x)) + 1):
            kth = np.partition(d, k - 1, axis=1)[:, k - 1]
            eps, knee = knee_radius(kth)
            value = DBSCAN(eps=eps, min_samples=k, metric='precomputed', n_jobs=1).fit_predict(d)
            supported = value >= 0
            count = len(np.unique(value[supported]))
            sc = ch = None
            if count > 1 and int(supported.sum()) >= count + 2:
                part = d[np.ix_(supported, supported)]
                sc = float(silhouette_score(part, value[supported], metric='precomputed', sample_size=min(1000, int(supported.sum())), random_state=seed))
                ch = metric_CH(metric, x[supported], value[supported])
                if not np.isfinite(sc) or not np.isfinite(ch):
                    sc = ch = None
            item = dict(minPts=k, eps=eps, knee_index=knee, cluster_count=count, non_noise_rows=int(supported.sum()), silhouette=sc, calinski_harabasz=ch)
            manifest['evaluations'].append(item)
            if sc is not None and (best is None or (sc, ch) > (best['silhouette'], best['calinski_harabasz'])):
                best, labels = (item, value)
    if best is None:
        first[indices] = -1
        retained = np.zeros(len(z), bool)
        manifest['status'] = 'NO_ELIGIBLE_MULTI_CLUSTER_PARAMETER_FAIL_CLOSED'
    else:
        first[indices] = _canonical(labels)
        geom = metric_affinity_geometry(metric, x, labels, d)
        mask = labels >= 0
        rcut = float(np.quantile(geom['reconstruction'][mask], 0.95, method='higher'))
        dcut = float(np.median(geom['density'][mask]))
        s = (geom['reconstruction'] > rcut) & (geom['density'] < dcut)
        suspected[indices] = s
        reconstruction[indices] = geom['reconstruction']
        density[indices] = geom['density']
        anomaly[indices] = geom['anomaly']
        if s.any():
            second[indices[s]] = _canonical(DBSCAN(eps=best['eps'], min_samples=best['minPts'], metric='precomputed', n_jobs=1).fit_predict(d[np.ix_(s, s)]))
        retained = raw & ((first >= 0) & ~suspected | suspected & (second >= 0))
        manifest.update(status='CURRENT_DVC_COMPLETED_NOT_FINAL', selected=best, reconstruction_cutoff=rcut, density_cutoff=dcut, retained_rows=int(retained.sum()), suspected_rows=int(s.sum()), primary_centres=geom['centres'].tolist(), kernel_bandwidths=geom['bandwidth'].tolist())
    return dict(retained=retained, first=first, second=second, suspected=suspected, reconstruction=reconstruction, density=density, anomaly=anomaly, manifest=manifest)

def predict_current_main_chain(stage1, raw, route):
    stage1 = np.asarray(stage1)
    raw = np.asarray(raw)
    retained = np.asarray(route['retained'])
    require(stage1.ndim == 1 and stage1.dtype.kind in 'iu' and np.isin(stage1, (0, 1)).all() and (raw.shape == retained.shape == stage1.shape) and (raw.dtype == retained.dtype == bool) and np.all(~retained | raw), 'only_same_run_raw_DVC_supported_UNA')
    expected = raw & ((route['first'] >= 0) & ~route['suspected'] | route['suspected'] & (route['second'] >= 0))
    same(retained, expected, 'same_run_primary_secondary_noise_formula')
    result = stage1.copy()
    result[retained] = 2
    return result
