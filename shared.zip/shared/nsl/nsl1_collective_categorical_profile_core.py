"""Unlabelled cohort context-frequency increase relative to genuine known FIT.

All three complete categorical fields are used as one joint tuple. Vocabulary
is fixed using real known FIT only, plus one OTHER state. Query nativegroups
are counted once; profile counting is test-time inference, not threshold or
label training. Increased usage is a candidate hint, not attack probability.
"""
import numpy as np
def require(ok,reason):
    if not ok:raise ValueError(reason)
def categorical_mapping(mapping):
    require(len(mapping)==41 and sorted(c for g in mapping for c in g['selected_columns'])==list(range(117)),
            'actual complete native117/original41 encoder')
    chosen=[g for g in mapping if g['kind']=='categorical']
    require([g['field'] for g in chosen]==['protocol_type','service','flag'],'all three actual categorical semantics fixed, no chosencontext subset')
    return chosen
def contexts(x,mapping):
    x=np.asarray(x,np.float64);require(x.ndim==2 and x.shape[1]==117 and np.isfinite(x).all(),'complete finite originalnative117')
    fields=[]
    for g in categorical_mapping(mapping):
        block=x[:,g['selected_columns']]
        require(np.isin(block,(0,1)).all() and np.all(block.sum(axis=1)==1),'whole complete onehot includingUNSEEN, no argmax repair')
        fields.append(np.argmax(block,axis=1))
    return np.column_stack(fields).astype(np.int64)
def fit_state(x,groups,mapping):
    groups=np.asarray(groups);c=contexts(x,mapping)
    require(groups.shape==(len(c),) and len(c)==len(np.unique(groups))==5999,'allgenuine5999 knownnative groups countedonce, no fine reweight or copies')
    vocab,code=np.unique(c,axis=0,return_inverse=True);counts=np.bincount(code,minlength=len(vocab)+1)
    probability=(counts+1)/(len(c)+len(vocab)+1)
    require(counts.sum()==5999 and counts[-1]==0 and np.all((probability>0)&(probability<=1)),'Dirichlet1 observed FIT contexts plus singleOTHER, no artificialevents')
    return dict(vocabulary3=vocab,FIT_context_counts=counts,FIT_context_probability=probability,
                genuineFIT_rows=np.asarray(5999),Dirichlet_alpha=np.asarray(1)),dict(FIT_contexts3=c,FIT_codes=code)
def infer_profile(x,groups,state,mapping):
    groups=np.asarray(groups);c=contexts(x,mapping);require(groups.shape==(len(c),) and len(c)>0,'one entire real unlabelledcohort')
    unique,representative,inverse=np.unique(groups,return_index=True,return_inverse=True)
    require(np.array_equal(c,c[representative][inverse]),'duplicate nativegroups have same actualjointcontext')
    lookup={tuple(row):i for i,row in enumerate(state['vocabulary3'].tolist())};other=len(lookup)
    code=np.asarray([lookup.get(tuple(row),other) for row in c.tolist()],np.int64)
    counts=np.bincount(code[representative],minlength=other+1)
    query_probability=(counts+1)/(len(unique)+other+1)
    score=np.log(query_probability[code])-np.log(state['FIT_context_probability'][code])
    require(np.isfinite(score).all() and counts.sum()==len(unique),'finite fixedDirichlet1 populationincrease inference, no labels/cut fitting')
    return dict(score=score,contexts3=c,context_code=code,
        query_context_counts=counts,query_context_probability=query_probability,
        nativegroup_representatives=representative,original_to_representative=inverse,
        cohort_genuine_nativegroups=np.asarray(len(unique)),cohort_rows=np.asarray(len(c)))
