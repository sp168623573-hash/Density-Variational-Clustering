"""New typed whole-field conditional reconstruction hint beside preserved2601.

Only the known-trained mask network provides the new candidate score. DVC uses
the separately frozen projected149 geometry/metric. Neither component changes
the primary classifier or reads query labels before the prediction seal.
"""
from __future__ import annotations
import argparse
import io
import json
from pathlib import Path
import time
import numpy as np
import torch
from . import nsl1_expanded_fit6000_typedmask_v1 as masked
from . import nsl1_projected149_entropy_joint_v2 as previous
from .paired_integer_gate_status_v1 import gate_status

ROOT,files=masked.ROOT,masked.files
BASE=ROOT/'data/external_dev/processed/nsl1_typedmask_predictive_hint_20261011_v1'
TRAIN=dict(path=str(masked.BASE/'train/report.json'),sha256='eb12bf83b1f1667983ba84dc9e45d3d60b9da674b36eb1317317782f146edf87')
GEOMETRY_PARENT=dict(path=str(previous.BASE/'current/report.json'),sha256='c119232f712e43fc86afa8afae87e5e1e9b959eda66fd27b2a74542a7ebc8115')
BASELINE=dict(path=str(ROOT/'data/external_dev/processed/nsl1_mask117_predictive_hint_20261010_v2/current/report.json'),sha256='168e542ce17afc5fd5ec8ade4817333927edba3cf8b22a0f23accee1d9ce7740')
SCHEMA='NSL1-preserved2601-typed41-known-trained-predictive-field-hint-v1'

def policy():
    return dict(schema_version=SCHEMA,model='new actual masked117/41 known-only network',
        reconstruction='all41 original fields masked one at a time; categorical negative log-probability of true field token and numeric mean square error in frozen encoded117 units',
        score='maximum per-field error divided by that field knownCAL finite99, conditional on frozen MAIN35e coarse; exactzero scale uses native normalized unit1',
        threshold='one knownCAL finite99 conditional cut on new max-error score',
        DVC='unchanged separately fitted projected149 metric and genuine149 geometry; mask-model embeddings not substituted into distance',
        preserve='all original2579/2596/2598/2601 versions and complete baseline2601 predictions',
        gate='known654 both integer99 and zero correct BEN/KNA loss before unknown masks',
        known_training_only=True,query_or_CAL_model_fit=False,query_unit_or_cutoff_fit=False,
        whole_field_mask_auxiliary_extension=True,original_paper_exact_formula_claim=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)

def freeze():
    pins={};train=files.js(TRAIN,pins);old=files.js(BASELINE,pins);geometry=files.js(GEOMETRY_PARENT,pins);ereg=files.js(geometry['registry'],pins)
    mreg=files.js(train['registry'],pins);mat=files.js(train['material'],pins)
    vanilla=files.js(ereg['inherited_registry'],pins)
    files.require(train['epochs_completed']==80 and train['unknown_numeric_decodes']==0 and old['original_class_gates']['UNA']['correct']==2601,'actual new typed producer and preserved2601')
    # Vanilla inherited preparation already owns the exact current encoded117.
    new149_current=files.js(previous.PROJECTED_CURRENT,pins)
    preg=files.js(new149_current['registry'],pins)
    aux_current=files.js(preg['controlled_current_report'],pins) if 'controlled_current_report' in preg else None
    # The entropy registry points to genuine149 query coordinates; raw117 is its last117 columns.
    assets=dict(model=train['files']['model'],field_map=mreg['assets']['field_map'],
        known_inputs=mat['encoded_inputs'],prepared=ereg['assets']['prepared_material'],
        current_geometry=ereg['assets']['query_geometry'],metric=ereg['assets']['metric'],
        baseline=old['files']['postseal_comparison'])
    for a in assets.values():files.read(a,pins)
    reg=dict(schema_version=SCHEMA+'-registry',policy=policy(),assets=assets,masked_registry=train['registry'],
        producer_state_sha=train['model_state_sha256'],material_descriptors=ereg['material_descriptors'],
        sources={Path(m.__file__).name:files.item(m.__file__) for m in (masked,previous,previous.projected,previous.learned,previous.paper_route)},
        output={phase:str(BASE/phase) for phase in ('known','current')},input_sha256=pins)
    reg['sources']['caller']=files.item(__file__);reg['registry_sha256']=files.digest(reg)
    out=ROOT/'tmp/nsl1_typedmask_predictive_hint_20261011_v1';out.mkdir(exist_ok=True)
    return files.write(out/'registry_before_predictive_hint_CAL.json',reg)

def bind(path,sha,pins):
    ref=dict(path=str(Path(path).resolve()),sha256=sha);reg=files.js(ref,pins)
    unsigned=dict(reg);h=unsigned.pop('registry_sha256')
    files.require(h==files.digest(unsigned) and reg['policy']==policy() and reg['sources']['caller']==files.item(__file__),'fixed masked-hint source')
    for a in reg['sources'].values():files.read(a,pins)
    return ref,reg

def save(out,name,value,report):return masked.previous.save(out,name,value,report)

def network(reg,pins):
    trained=files.js(reg['masked_registry'],pins);mapping=masked.field_map_from_state(files.js(reg['assets']['field_map'],pins))
    state=torch.load(io.BytesIO(files.read(reg['assets']['model'],pins)),map_location='cpu',weights_only=True)
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    net=masked.load_checkpoint(state,trained,mapping,device=device)
    files.require(masked.output_io.state_digest(net)==reg['producer_state_sha'],'actual frozen maskaux117 state')
    return net,device

def typed_field_error(output,target,kind):
    output=np.asarray(output,np.float64);target=np.asarray(target,np.float64)
    files.require(output.shape==target.shape and output.ndim==2 and np.isfinite(output).all() and np.isfinite(target).all(),'typed complete field arrays')
    if kind=='categorical':
        files.require(np.isin(target,[0.,1.]).all() and np.all(target.sum(axis=1)==1),'true categorical onehot token, no fitted query labels')
        top=output.max(axis=1)
        return top+np.log(np.exp(output-top[:,None]).sum(axis=1))-output[np.arange(len(output)),target.argmax(axis=1)]
    files.require(kind=='numeric','explicit original encoder field kind')
    return np.square(output-target).mean(axis=1)


def errors(net,x,role,out,report):
    files.require(x.shape[1]==117 and x.dtype==np.float32 and np.isfinite(x).all(),'actual genuine encoded117 for field masks')
    result=np.empty((len(x),41),np.float64);device=next(net.parameters()).device
    with torch.no_grad():
        for field,group in enumerate(net.field_map.groups):
            columns=group['selected_columns']
            for first in range(0,len(x),1024):
                stop=min(first+1024,len(x));xb=torch.from_numpy(x[first:stop].copy()).to(device)
                labels=torch.full((len(xb),),field,dtype=torch.int64,device=device)
                with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=device.type=='cuda'):
                    value=net.forward_masked(xb,labels)
                live={k:v.detach().cpu().numpy().copy() if v.dtype==torch.bool else v.detach().float().cpu().numpy().copy() for k,v in value.items()}
                save(out,role+'_field'+str(field)+'_batch'+str(first)+'_raw_mask_output',live,report)
                report['counts']['masked_forward_batches']+=1
                files.require(set(live)==masked.RAW_FIELDS|{'masked_columns'} and np.isfinite(live['reconstruction']).all(),'actual masked output saved before caller guards')
                result[first:stop,field]=typed_field_error(live['reconstruction'][:,columns],x[first:stop,columns],group['kind'])
    save(out,role+'_all41_field_errors_before_score',dict(per_field_error=result),report)
    files.require(np.isfinite(result).all() and np.all(result>=0),'complete finite predictive field errors')
    return result

def field_scale(cal,stage):
    scale=np.ones((2,41),np.float64)
    for label in (0,1):
        for field in range(41):
            item=previous.paper_route.calibrate_known_cutoffs(cal[:,field],stage)[str(label)]
            files.require(item['enabled'] and item['cutoff'] is not None,
                'enough original CAL samples per primary coarse for finite99 field units')
            cutoff=item['cutoff']
            scale[label,field]=cutoff if cutoff>0 else 1
    return scale

def score_fields(error,stage,scale):
    return np.max(error/scale[stage],axis=1)

def run(phase,path,sha,known_path=None,known_sha=None):
    started=time.perf_counter();pins={};ref,reg=bind(path,sha,pins)
    if phase=='current':
        kref=dict(path=str(Path(known_path).resolve()),sha256=known_sha);kr=files.js(kref,pins)
        files.require(kr['registry']==ref and kr['known_gate_passed'],'known zero-loss integer gates before current masked values')
    out=Path(reg['output'][phase]);files.require(not out.exists(),'fresh masked-hint phase');out.mkdir(parents=True)
    before=masked.capture_runtime_flags()
    report=dict(schema_version=SCHEMA,phase=phase,registry=ref,policy=policy(),files={},
        counts=dict(masked_forward_batches=0,model_fit=0,metric_fit=0,CAL_fit=0,score=0,DVC=0),
        prediction_sealed=False,truth_opened=False,accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        torch.set_num_threads(4);net,_=network(reg,pins)
        prepared=previous.archive(reg['assets']['prepared'],tuple(reg['material_descriptors']),pins)
        if phase=='known':
            data=previous.archive(reg['assets']['known_inputs'],('calibration_features','open_known_features'),pins)
            cal=errors(net,data['calibration_features'],'CAL656',out,report);stage=prepared['calibration_stage1']
            scale=field_scale(cal,stage);cut=previous.paper_route.calibrate_known_cutoffs(score_fields(cal,stage,scale),stage)
            rule=files.write(out/'knownCAL_field_scale_and_cutoffs_before_known654.json',dict(scale=scale.tolist(),cutoffs=cut,query_used=False))
            report['files']['calibration']=rule;report['counts']['CAL_fit']=1
            query=dict(Z149=prepared['open_known_Z149'],groups=prepared['open_known_groups'],ids=prepared['open_known_ids'],stage1=prepared['open_known_stage1'])
            err=errors(net,data['open_known_features'],'known654',out,report)
        else:
            query=previous.archive(reg['assets']['current_geometry'],('ids','groups','Z149','stage1'),pins)
            data=np.ascontiguousarray(query['Z149'][:,32:],dtype=np.float32)
            rule=files.js(kr['files']['calibration'],pins);scale=np.asarray(rule['scale']);cut=rule['cutoffs']
            err=errors(net,data,'current3598',out,report)
        score=score_fields(err,query['stage1'],scale);raw=previous.paper_route.candidate_mask(score,query['stage1'],cut)
        report['counts']['score']=1;save(out,'new_predictive_score_before_DVC',dict(score=score,raw=raw,stage1=query['stage1']),report)
        metric=previous.load_metric(reg,pins)
        def sink(name,value,manifest):
            save(out,name+'_DVC_result',value,report);report['files'][name+'_manifest']=files.write(out/(name+'_DVC_manifest.json'),manifest)
        report['counts']['DVC']=1;route,_=previous.route_once(metric,query,raw,sink)
        baseline=previous.archive(reg['assets']['baseline'],('prediction',),pins)['prediction']
        if phase=='known':baseline=baseline[:654]
        pred=previous.merge(baseline,raw,route['retained'])
        pa=save(out,'prediction_before_truth',dict(ids=query['ids'],prediction=pred,baseline=baseline,raw=raw,retained=route['retained']),report)
        report['files']['prediction_seal']=files.write(out/'prediction_seal_before_truth.json',dict(prediction=pa,truth_opened=False));report['prediction_sealed']=True
        truth=previous.archive(reg['assets']['baseline'],('ids','truth'),pins);report['truth_opened']=True
        if phase=='known':truth={k:v[:654] for k,v in truth.items()}
        files.require(np.array_equal(query['ids'],truth['ids']),'same fixed original IDs afterseal')
        effect,gates,prior=previous.delta(truth['truth'],pred,baseline,full=phase=='current')
        save(out,'postseal_comparison',dict(**truth,prediction=pred,baseline=baseline,raw=raw,retained=route['retained']),report)
        zero_loss=all(effect['gain_loss'][n]['loss']==0 for n in ('BEN','KNA'))
        report.update(execution_status='masked117_predictive_hint_'+phase+'_evaluated',original_class_gates=gates,baseline_class_gates=prior,EffectDelta=effect,
            known_gate_passed=zero_loss and all(gates[name]['passed'] for name in ('BEN','KNA')),known_raw=int(raw[:654].sum()),known_retained=int(route['retained'][:654].sum()),
            unknown_raw=int(raw[654:].sum()),unknown_retained=int(route['retained'][654:].sum()),evaluated_class_gates_passed=all(v['passed'] for v in gates.values()),all_three_integer99_passed=phase=='current' and all(v['passed'] for v in gates.values()))
        report['explicit_gate_status']=gate_status(gates,{name:effect['gain_loss'][name]['loss'] for name in ('BEN','KNA')})
        files.require(masked.output_io.state_digest(net)==reg['producer_state_sha'],'mask weights unchanged during predictive fields')
    except Exception as error:report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        after=masked.restore_runtime_flags(before);report['runtime_restored']=after==before;report['input_sha256']=pins
        report['wall_seconds']=time.perf_counter()-started;files.write(out/'report.json',report)
    return files.item(out/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for n in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+n)
    a=p.parse_args();print(json.dumps(freeze() if a.phase=='freeze' else run(a.phase,a.registry,a.registry_sha256,a.known_report,a.known_sha256)))
