"""Predeclared warm NSL2 known-role reallocation, using metadata only.

Old FIT and CP supply known-supervised training representatives. Old CAL is
split by feature group, before a new model, into calibration and known DEV.
The previous OPEN role is retained in history and never becomes a new role.
"""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import time

from . import nsl_setting2_capped_known_training_v1 as parent
from . import nsl_setting2_warm_known_role_recovery_v1 as recovery

ROOT, SETTING, FAMILIES = parent.ROOT, parent.SETTING, parent.FAMILIES
SEED, NAMESPACE = 20261009, 'NSL2-known-FIT-CP-union-CAL-group-half-v2-20261009'
SOURCE_BASE = 'data/external_dev/processed/nsl_setting2_capped_known_source_extract_20261008_v1'
SOURCE_REPORT = {'path': SOURCE_BASE+'/report.json', 'sha256': '53b635cf87614399112d26d86ed1eeb5410d22aa8594a67702d882c0bf0a47a2'}
RECORDS = {'path': SOURCE_BASE+'/ordered_source_records.json', 'sha256': 'd2bb181a595ecb708767143f15a3e2a2f9f50113c09e70474cb8b4c0374901c0'}
OUTPUT = ROOT/'data/external_dev/processed/nsl_setting2_warm_fit_coverage_plan_20261009_v2'
ROLES = ('FIT', 'CAL', 'DEV')
sha, checked, write_json, require = parent.sha, parent.checked, parent.write_json, parent.require
POLICY = dict(schema_version='NSL2-warm-known-FIT-coverage-reallocation-plan-v2', setting=SETTING,
    seed=SEED, namespace=NAMESPACE, family_order=FAMILIES,
    FIT='all earliest-source-ordinal feature-group representatives in old FIT plus old CP',
    FIT_floor='positive original family only, cyclic role-local optimizer copies to20; no new physical events',
    controls='old CAL only; fixed family-stratified SHA group rank, floor(group_count/2) groups to CAL and remainder DEV',
    singleton_CAL_family='one complete group assigned DEV; no mandatory each-family CAL or DEV floor',
    control_records='all original old-CAL source-record IDs, duplicates grouped into one role; no extra copies',
    ranking='SHA256(namespace+NUL+family+NUL+legacy_model40_group); ties group string',
    output_order='ascending source_record_ordinal_zero_based within each role',
    proportions='known registered legacy Sample counts; retained-all available groups with rare optimizer floor; deviations explicit',
    aggregate_effective_cap=6000, final_test_cap=6000,
    zero_original_family_resampling_permitted=False, OPEN_reassigned=False,
    raw_source_opened_or_hashed=False, source_numeric_decoding=False,
    model_predictions_or_errors_read=False, planned_training_runs=0,
    warm_development_only=True, fresh_holdouts_claimed=False,
    historical_parent_flow_authority_resolved=False, physical_independence_verified=False,
    independent_final_admitted=False, formal_training_admitted=False,
    status='FAIL_TARGET99', published=False, final_test_executed=False)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def rank(family, group):
    return hashlib.sha256((NAMESPACE+'\0'+family+'\0'+group).encode()).hexdigest()


def _validate_records(records):
    require(records.get('schema_version') == 'NSL2-capped-warm-ordered-known-source-records-v1'
        and records.get('setting') == SETTING and tuple(records.get('family_order', ())) == FAMILIES
        and records.get('source_path') == recovery.SOURCE_REL and records.get('source_sha256') == recovery.SOURCE_SHA
        and records.get('warm_development_only') is True and records.get('independent_final_admitted') is False
        and records.get('physical_parent_flow_authority_resolved') is False
        and records.get('copies_in_original_feature_arrays') == 0
        and set(records['roles']) == set(parent.ALL_ROLES), 'registered_known_metadata_schema')
    seen_ids, seen_ordinals, group_role, group_strong, group_family = set(), set(), {}, {}, {}
    expected_lower = {'FIT':'fit', 'CP':'checkpoint', 'CAL':'calibration', 'OPEN':'open_known'}
    for role, rows in records['roles'].items():
        require(bool(rows), 'positive_old_known_role')
        previous = -1
        for row in rows:
            ordinal, group, family = row['source_record_ordinal_zero_based'], row['legacy_model40_group'], row['family']
            strong = row['pandas_string_feature_values_sha256']
            require(type(ordinal) is int and ordinal > previous and ordinal not in seen_ordinals
                and row['role'] == expected_lower[role] and family in FAMILIES
                and type(row['coarse']) is int and row['coarse'] == int(family != 'BEN')
                and re.fullmatch('[0-9a-f]{16}', group) is not None
                and re.fullmatch('[0-9a-f]{64}', strong) is not None,
                'known_record_order_family_or_identity')
            require(row['sample_id'] == f'nsl_kdd:source_train:{ordinal}:{group}'
                and row['sample_id'] not in seen_ids, 'source_ID_ordinal_group_binding')
            require(group_role.setdefault(group, role) == role, 'old_cross_role_group_overlap')
            require(group_strong.setdefault(group, strong) == strong
                and group_family.setdefault(group, family) == family, 'ambiguous_feature_group')
            seen_ids.add(row['sample_id']); seen_ordinals.add(ordinal); previous = ordinal
        require(set(r['family'] for r in rows) == set(FAMILIES), 'old_known_role_missing_family')


def _indices(rows, *, floor):
    indices = list(range(len(rows)))
    copies = {f:0 for f in FAMILIES}
    if floor:
        for f in FAMILIES:
            parents = [i for i, r in enumerate(rows) if r['family'] == f]
            require(bool(parents), 'cannot_resample_zero_FIT_family:'+f)
            copies[f] = max(0, 20-len(parents))
            indices.extend(parents[i % len(parents)] for i in range(copies[f]))
    return indices, copies


def _density(rows):
    result, seen = [], set()
    for i, row in enumerate(rows):
        if row['legacy_model40_group'] not in seen:
            result.append(i); seen.add(row['legacy_model40_group'])
    return result


def build_plan(records):
    """Pure known-record metadata: accepts no features, prediction, or score."""
    _validate_records(records)
    old = records['roles']
    fit_groups = {}
    for origin in ('FIT', 'CP'):
        for position, row in enumerate(old[origin]):
            candidate = {**deepcopy(row), 'origin_role':origin, 'origin_position':position, 'new_role':'FIT'}
            group = row['legacy_model40_group']
            if group not in fit_groups or row['source_record_ordinal_zero_based'] < fit_groups[group]['source_record_ordinal_zero_based']:
                fit_groups[group] = candidate
    groups_by_family = {f:set(r['legacy_model40_group'] for r in old['CAL'] if r['family'] == f) for f in FAMILIES}
    cal_groups, cal_ranks = set(), {}
    for family in FAMILIES:
        ordered = sorted(groups_by_family[family], key=lambda g:(rank(family, g), g))
        cal_groups.update(ordered[:len(ordered)//2])
        cal_ranks[family] = [{'group':g, 'rank':rank(family,g), 'role':'CAL' if g in cal_groups else 'DEV'} for g in ordered]
    roles = {'FIT':list(fit_groups.values()), 'CAL':[], 'DEV':[]}
    for i, row in enumerate(old['CAL']):
        role = 'CAL' if row['legacy_model40_group'] in cal_groups else 'DEV'
        roles[role].append({**deepcopy(row), 'origin_role':'CAL', 'origin_position':i, 'new_role':role})
    for rows in roles.values():
        rows.sort(key=lambda r:r['source_record_ordinal_zero_based'])
        require(rows and set(r['coarse'] for r in rows) == {0,1}, 'each_new_role_requires_BEN_and_KNA')
    groups = {r:set(row['legacy_model40_group'] for row in rows) for r, rows in roles.items()}
    require(all(not groups[a].intersection(groups[b]) for i,a in enumerate(ROLES) for b in ROLES[i+1:]), 'new_group_overlap')
    require(not set.union(*groups.values()).intersection(r['legacy_model40_group'] for r in old['OPEN']), 'OPEN_group_reassigned')
    indices, copies = _indices(roles['FIT'], floor=True)
    total = len(indices)+len(roles['CAL'])+len(roles['DEV'])
    require(total <= 6000, 'effective_training_side_cap')
    legacy_weights = dict(parent.source_code.planner.EXPECTED_WEIGHTS)
    effective = Counter(roles['FIT'][i]['family'] for i in indices)
    deviations = {f:{'original_rows':legacy_weights[f], 'FIT_effective_rows':effective[f],
        'percentage_point_deviation':{'numerator':(q:=100*(Fraction(effective[f],len(indices))-Fraction(legacy_weights[f],sum(legacy_weights.values())))).numerator,
            'denominator':q.denominator}} for f in FAMILIES}
    summaries = {r:dict(original_source_records=len(rows), unique_feature_groups=len(groups[r]),
        source_family_support={f:sum(row['family'] == f for row in rows) for f in FAMILIES},
        unique_family_support={f:sum(rows[i]['family'] == f for i in _density(rows)) for f in FAMILIES},
        effective_rows=len(indices) if r == 'FIT' else len(rows), optimization_copies=sum(copies.values()) if r == 'FIT' else 0)
        for r,rows in roles.items()}
    retained = {row['sample_id'] for rows in roles.values() for row in rows}
    return dict(schema_version=POLICY['schema_version'], configuration=deepcopy(POLICY),
        source_path=records['source_path'], source_sha256=records['source_sha256'], family_order=list(FAMILIES),
        roles=roles, FIT_optimization_indices=indices, FIT_copies_by_family=copies,
        role_density_representative_indices={r:_density(rows) for r,rows in roles.items()},
        role_summary=summaries, training_effective_aggregate=total,
        CAL_group_assignment_by_family=cal_ranks, legacy_known_source_row_weights=legacy_weights,
        FIT_proportion_deviations=deviations,
        old_OPEN_ordered_metadata_sha256=digest(old['OPEN']), old_OPEN_source_records=len(old['OPEN']),
        old_OPEN_ids_untouched=[row['sample_id'] for row in old['OPEN']],
        discarded_duplicate_known_record_IDs_still_exposed=[row['sample_id'] for origin in ('FIT','CP') for row in old[origin] if row['sample_id'] not in retained],
        all_parent_known_record_IDs_still_exposed=[row['sample_id'] for origin in ('FIT','CP','CAL','OPEN') for row in old[origin]],
        historical_12028_parent_exposure_preserved=True,
        fresh_holdout_claimed=False, warm_development_only=True, independent_final_admitted=False,
        formal_training_admitted=False, status='FAIL_TARGET99', published=False, final_test_executed=False,
        EffectDelta={'verdict':'NOT_COMPARABLE', 'reason':'known supervised role reallocation; old CP enters FIT, old CAL becomes calibration/known DEV'})


def run(*, output_directory=OUTPUT):
    out = Path(output_directory).resolve()
    require(out.is_relative_to(ROOT/'data/external_dev/processed'), 'processed_child_output_required')
    out.mkdir(parents=True, exist_ok=False)
    start, pins = time.perf_counter(), {}
    report = dict(configuration=POLICY, planning_completed=False, execution_status='started', stage='validate_known_metadata',
        status='FAIL_TARGET99', published=False, final_test_executed=False, files={}, raw_source_opened_or_hashed=False,
        model_inference_runs=0, training_runs=0, source_numeric_decoding=False)
    try:
        source = json.loads(checked(SOURCE_REPORT, pins))
        records = json.loads(checked(RECORDS, pins))
        require(source['source_extraction_completed'] is True and source['all_input_pins_stable'] is True
            and source['files']['ordered_source_records'] == RECORDS, 'completed_pinned_source_metadata_required')
        for path in (Path(__file__), Path(parent.__file__), Path(recovery.__file__)):
            pins[str(path.resolve())] = sha(path)
        report['files']['policy_before_group_selection'] = write_json(out/'policy_before_group_selection.json', dict(configuration=POLICY,input_sha256=pins))
        report['stage'] = 'predeclared_metadata_role_allocation'
        require({r:len(rows) for r,rows in records['roles'].items()} == parent.ALL_ROLES,
            'fixed_registered_old_role_sizes')
        plan = build_plan(records)
        require(plan['role_summary']['FIT']['original_source_records'] == 4488
            and plan['role_summary']['FIT']['effective_rows'] == 4519
            and len(plan['roles']['CAL'])+len(plan['roles']['DEV']) == 1279
            and plan['training_effective_aggregate'] == 5798
            and plan['FIT_copies_by_family']['httptunnel'] == 13
            and plan['FIT_copies_by_family']['xsnoop'] == 18,
            'anticipated_registered_FIT_union_and_copies')
        item = write_json(out/'known_role_plan.json', plan)
        require(digest(json.loads(checked(item,pins))) == digest(plan), 'saved_role_plan_binding')
        for path, expected in pins.items():
            require(sha(path) == expected, 'final_input_pin_changed:'+path)
        report['files']['known_role_plan'] = item
        report.update(planning_completed=True, execution_status='warm_known_role_reallocation_plan_completed', stage='complete',
            role_summary=plan['role_summary'], training_effective_aggregate=plan['training_effective_aggregate'],
            FIT_copies_by_family=plan['FIT_copies_by_family'], EffectDelta=plan['EffectDelta'], input_sha256=pins,
            final_input_pins_unchanged=True, warm_development_only=True, independent_final_admitted=False)
    except Exception as exc:
        report.update(execution_status='protocol_stop' if isinstance(exc,parent.util.NativeKnownTrainingStop) else 'execution_failed',
            error_type=type(exc).__name__, error_message=str(exc))
    report['wall_seconds'] = time.perf_counter()-start
    write_json(out/'report.json', report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-directory', type=Path, default=OUTPUT)
    args = parser.parse_args(argv)
    report = run(output_directory=args.output_directory)
    print(json.dumps({k:report.get(k) for k in ('execution_status','role_summary','training_effective_aggregate','error_message')},ensure_ascii=False))
    return 0 if report['planning_completed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
