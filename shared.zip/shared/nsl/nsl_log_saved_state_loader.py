"""Read one hash-pinned local -m pickle with its exact sealed callable.

The original FunctionTransformer callback was pickled as __main__. This loader
resolves ONLY that known callback to the immutable producer module, temporarily
and then restores the calling namespace. No artifact/refit/numeric rule changes.
"""
from contextlib import contextmanager
from pathlib import Path
import sys
import joblib
from .data import sha256_file
from .known_role_floor_log_development import log1p_nonnegative

ARTIFACT_SHA = "051e1c03eff48ea0e0f5bebc73e957955301ccd694470b6771058cf52a4a6a76"
PRODUCER_SHA = "62769a48b06b038161f7ce1045f0670317bce636cfa593a58973aa014e0282c6"


@contextmanager
def exact_callback_namespace():
    module = sys.modules["__main__"]
    sentinel = object()
    previous = getattr(module, "log1p_nonnegative", sentinel)
    if previous is not sentinel and previous is not log1p_nonnegative:
        raise ValueError("conflicting __main__ callback; no arbitrary replacement")
    setattr(module, "log1p_nonnegative", log1p_nonnegative)
    try:
        yield
    finally:
        if previous is sentinel:
            delattr(module, "log1p_nonnegative")
        else:
            setattr(module, "log1p_nonnegative", previous)


def load_saved_log_state(path):
    path = Path(path)
    producer = Path(__file__).with_name("known_role_floor_log_development.py")
    if sha256_file(path) != ARTIFACT_SHA or sha256_file(producer) != PRODUCER_SHA:
        raise ValueError("only exact sealed log producer and saved state may be loaded")
    with exact_callback_namespace():
        state = joblib.load(path)
    callback = state["preprocessor"].named_transformers_["numeric"].named_steps["log1p"].func
    if callback is not log1p_nonnegative:
        raise ValueError("saved callback did not resolve to exact immutable producer")
    return state
