"""Restore case/whitespace-equivalent NSL tokens to frozen known-fit spelling.

No refit or query-derived vocabulary. For example sf and SF both map to the
encoder's known-fit SF token. Truly unseen values remain unseen. Ambiguous
casefold collisions in a fitted vocabulary fail closed. Existing source
fingerprints/IDs and immutable artifacts are never rewritten.
"""
import hashlib
import json
import numpy as np
import pandas as pd
from .config import NSL_FEATURE_COLUMNS

FIELDS = NSL_FEATURE_COLUMNS[:3]
SCHEMA = "frozen-known-fit-NSL-categorical-casefold-spelling-adapter-v1"


def canonical_token(value):
    return str(value).strip().casefold()


class FrozenCategoryVocabulary:
    def __init__(self, preprocessor):
        self.preprocessor = preprocessor
        active = []
        for name, transformer, columns in preprocessor.transformers:
            if name=="remainder" or transformer=="drop": continue
            if not isinstance(columns,(list,tuple,np.ndarray)):
                raise ValueError("explicit frozen NSL columns required")
            active.extend(str(v) for v in columns)
        if tuple(active)!=NSL_FEATURE_COLUMNS or preprocessor.remainder!="drop":
            raise ValueError("exact 40-feature frozen NSL input contract required")
        vocabularies = preprocessor.named_transformers_["categorical"].named_steps["onehot"].categories_
        if len(vocabularies)!=len(FIELDS): raise ValueError("three frozen categorical vocabularies required")
        self.mapping = {}
        for field, vocabulary in zip(FIELDS,vocabularies):
            mapping = {}
            for value in vocabulary:
                if not isinstance(value,(str,np.str_)) or not canonical_token(value):
                    raise ValueError("nonempty string category tokens required")
                key = canonical_token(value)
                if key in mapping and mapping[key]!=str(value):
                    raise ValueError("ambiguous known-fit casefold vocabulary; no arbitrary merge")
                mapping[key] = str(value)
            self.mapping[field] = mapping
        self.frozen_mapping_sha256 = self._mapping_hash()
        self.manifest = {"schema_version":SCHEMA,"fields":list(FIELDS),"mapping":self.mapping,
            "frozen_mapping_sha256":self.frozen_mapping_sha256,"known_fit_vocabulary_only":True,
            "query_truth_or_ID_or_family_used":False,"query_used_to_fit_vocabulary":False,
            "known_numeric_weights_or_encoder_categories_refitted":False,
            "true_unseen_category_action":"retain canonical unseen token; frozen encoder still ignores it",
            "missing_category_action":"preserve missing value for original fitted imputer",
            "ambiguous_casefold_vocabularies_rejected":True,"numeric_fields_unchanged":True,
            "original_source_fingerprints_and_IDs_unchanged":True,
            "does_not_make_independent_data_or_99_certificate":True,"published":False}

    def _mapping_hash(self):
        return hashlib.sha256(json.dumps(self.mapping,sort_keys=True,ensure_ascii=False).encode("utf8")).hexdigest()

    @property
    def transformers(self): return self.preprocessor.transformers

    @property
    def remainder(self): return self.preprocessor.remainder

    @property
    def feature_names_in_(self): return self.preprocessor.feature_names_in_

    def get_feature_names_out(self): return self.preprocessor.get_feature_names_out()

    def transform(self, frame):
        if (not isinstance(frame,pd.DataFrame) or not set(NSL_FEATURE_COLUMNS).issubset(frame.columns)
                or self._mapping_hash()!=self.frozen_mapping_sha256):
            raise ValueError("unchanged known-only adapter and paired NSL frame required")
        model = frame.loc[:,NSL_FEATURE_COLUMNS].copy()
        for field in FIELDS:
            mapping = self.mapping[field]
            model[field] = model[field].map(lambda value: value if pd.isna(value)
                else mapping.get(canonical_token(value),canonical_token(value)))
        return self.preprocessor.transform(model)


def vocabulary_mismatch(preprocessor, frame):
    adapter = FrozenCategoryVocabulary(preprocessor)
    result = {}
    for field in FIELDS:
        raw = frame[field].astype(str)
        canonical = raw.map(canonical_token)
        values = adapter.mapping[field]
        result[field] = {"rows":len(frame),"exact_unrecognized":int((~raw.isin(values.values())).sum()),
            "canonical_unrecognized":int((~canonical.isin(values)).sum()),
            "case_or_whitespace_only_mismatches":int((~raw.isin(values.values())&canonical.isin(values)).sum())}
    return result
