"""Model-free native input boundary for subsequent paper-core experiments.
Copies only existing admitted values/IDs; no predictions or historical Z359.
"""
from pathlib import Path
import json,hashlib,sys,importlib.util
import numpy as np
H=Path(__file__).resolve().parent;I=H.parent;O=H/'clean_inputs'
def ref(p):
    p=Path(p)
    with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return dict(path=str(p.resolve()),sha256=h,bytes=p.stat().st_size)
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def put(p,v):
    with Path(p).open('x',encoding='utf8')as f:json.dump(v,f,indent=2,ensure_ascii=False)
    return ref(p)
def save(p,**kw):
    with Path(p).open('xb')as f:np.savez_compressed(f,**kw)
    return ref(p)
def load(role,logical_FIT=False):
    m=read(O/'INPUT_MANIFEST.json');r=m['inputs'][role];assert ref(r['path'])==r
    with np.load(r['path'],allow_pickle=False)as a:d={k:a[k]for k in a.files}
    if logical_FIT:
        if role!='FIT':raise ValueError('Resampling allowed only on FIT optimizer rows')
        r=m['FIT_optimizer_parents'];assert ref(r['path'])==r
        with np.load(r['path'])as a:p=a['parent_indices']
        d={k:(v[p]if v.ndim>=1 and len(v)==len(d['ids'])else v)for k,v in d.items()}
    return d
def load_known_labels(role):
    if role not in('CAL','CP'):raise ValueError('No current-truth API in model input loader')
    r=read(O/'INPUT_MANIFEST.json')['known_labels'][role];assert ref(r['path'])==r
    with np.load(r['path'],allow_pickle=False)as a:return{k:a[k]for k in a.files}
def load_calibration_reference():
    """Return only the declared decontaminated, unique-group references."""
    m=read(O/'INPUT_MANIFEST.json');ix=np.asarray(m['calibration_indices'],int)
    x=load('CAL');y=load_known_labels('CAL');assert np.array_equal(x['ids'],y['ids'])
    return dict(ids=x['ids'][ix],groups=x['groups'][ix],native115=x['native115'][ix],coarse=y['coarse'][ix])
def run():
    O.mkdir(exist_ok=False);p=I/'target99_v1051_20261024/nsl2/inputs_v1051.py';sp=importlib.util.spec_from_file_location('r12_clean_provider',p);A=importlib.util.module_from_spec(sp);sys.modules[sp.name]=A;sp.loader.exec_module(A)
    s=A.load_source();original={'FIT':dict(ids=s['ids'],groups=s['groups'],native115=s['native'],fine=s['fine'])};known={}
    for role in('CAL','CP','current'):
        q=A.load_role(role);original[role]=dict(ids=q['ids'],groups=q['groups'],native115=q['native'])
        if role!='current':y=A.load_known_labels(role);assert np.array_equal(y['ids'],q['ids']);known[role]=dict(ids=y['ids'],coarse=y['coarse'])
    inputs={role:save(O/(role+'_inputs.npz'),**d)for role,d in original.items()};labels={role:save(O/(role+'_known_labels.npz'),**d)for role,d in known.items()}
    plan=read(H/'nsl2/OWNEDFIT_PROTOCOL.json');trace=H/'nsl2/ownedfit_once/source/FIT_parent_trace.npz'
    with np.load(trace)as a:parents=a['optimizer_parent_indices'];assert np.array_equal(a['ids'],s['ids'])and np.array_equal(a['optimizer_parent_ids'],s['ids'][parents])
    pr=save(O/'FIT_optimizer_parents.npz',parent_indices=parents,parent_ids=s['ids'][parents],parent_groups=s['groups'][parents]);assert len(parents)==5999 and len(s['ids'])==5967
    owner=read(plan['source_ownership']['path']);fm=owner['field_map']['groups'];groups=[dict(name=g['field'],kind=g['kind'],columns=g['selected_columns'])for g in fm]
    assert sorted(c for g in groups for c in g['columns'])==list(range(115))
    put(O/'INPUT_MANIFEST.json',dict(schema='R12_MODEL_FREE_NATIVE_INPUTS',inputs=inputs,known_labels=labels,FIT_optimizer_parents=pr,
        field_groups=groups,encoder=owner['encoding'],source_ownership=plan['source_ownership'],known_label_authority=plan['source_authority']['known_label_authority'],
        calibration_indices=plan['calibration_indices'],calibration_class_unique_groups=plan['calibration_class_unique_groups'],
        adopted_view='40 admitted original fields encoded into115; duration is not fabricated; not a claim of all41 raw NSL fields',
        values_are_identical_to_existing_provider=True,no_HGB_graph_Z359_or_parent_prediction_in_inputs=True,
        genuine_FIT_rows=5967,logical_optimizer_rows=5999,optimizer_only_copies=32,
        density_and_calibration_use_genuine_references_only=True,current_truth_in_input_package=False,
        old_internal_source_QA_not_independent_for_ownedFIT=True,CP_current_ID_overlap=72,independent_final_cohort=False,
        loader=ref(__file__),status='FAIL_TARGET99',published=False,final_test_executed=False))
    checks={}
    for role,d in original.items():
        actual=load(role);assert all(np.array_equal(actual[k],v)for k,v in d.items());assert np.isfinite(actual['native115']).all()
        if role!='FIT':assert set(actual)=={'ids','groups','native115'}
        checks[role]=dict(rows=len(actual['ids']),every_array_exactly_equal=True)
    assert len(load('FIT',True)['ids'])==5999
    try:load_known_labels('current')
    except ValueError:pass
    else:raise AssertionError('current labels exposed through input API')
    c=load('CAL');q=load('current');ix=np.array(plan['calibration_indices']);assert not set(c['ids'][ix])&set(q['ids'])and not set(c['groups'][ix])&set(q['groups'])
    put(O/'VERIFICATION.json',dict(roles=checks,logical_FIT_parents_verified=True,current_truth_API_refused=True,calibration_current_ID_and_group_overlap=0,
        model_performance_test=False,status='FAIL_TARGET99',published=False));print('CLEAN_INPUTS_VERIFIED',checks,flush=True)
if __name__=='__main__':run()
