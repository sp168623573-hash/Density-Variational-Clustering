"""Field-count prior correction inside the original MHFD/CNN-LSTM network.

All115 encoded columns are retained. The attention-key and sequence-pooling
logits receive -log(number of encoded columns in that original field).
No trainable module or classifier is added. The prior is an explicit
implementation hypothesis, not a newly attributed manuscript equation.
"""
import types,math,time
import numpy as np
import torch
from torch.nn import functional as F
import common as C

def prior_for(fields,width):
    bias=np.empty(width,np.float32);seen=[]
    for cols in fields:bias[cols]=-math.log(len(cols));seen.extend(cols)
    assert sorted(seen)==list(range(width))
    return torch.tensor(bias)

def forward_tokens(net,tokens,prior):
    mask=None if prior is None else prior[None,:].expand(tokens.shape[1],-1)
    a,_=net.attention(tokens,tokens,tokens,attn_mask=mask,need_weights=False)
    gate=net.gate(a);enhanced=net.attention_norm(tokens+net.dropout(a)*gate)
    convolved=net.conv(enhanced.transpose(1,2)).transpose(1,2);sequence,_=net.sequence(convolved)
    pool=net.pool_score(sequence).squeeze(-1)
    if prior is not None:pool=pool+prior[None,:]
    weights=torch.softmax(pool,1);h=net.embedding((sequence*weights[...,None]).sum(1))
    return dict(coarse_logits=net.coarse_head(h),fine_logits=net.fine_head(h),embedding=h,
        reconstruction=net.decoder(h),gate_mean=gate.mean((1,2)))

def install(net,fields,corrected):
    bias=prior_for(fields,net.feature_count) if corrected else None
    def forward(self,x):
        self._query_features(x);self._map_check()
        tokens=x[...,None]*self.feature_weight[None]+self.feature_bias[None]+self.position[None]
        return forward_tokens(self,tokens,None if bias is None else bias.to(x.device))
    def masked(self,x,which):
        tokens,hidden=self.masked_tokens(x,which)
        return dict(forward_tokens(self,tokens,None if bias is None else bias.to(x.device)),masked_columns=hidden)
    net.forward=types.MethodType(forward,net);net.forward_masked=types.MethodType(masked,net)
    return net

def checks(net,fields,native):
    net.eval();x=torch.tensor(native[:12],dtype=torch.float32);which=torch.arange(len(x))%len(fields)
    with torch.no_grad():clean=net(x);masked=net.forward_masked(x,which)
    keys=set(net.state_dict());install(net,fields,False)
    with torch.no_grad():new=net(x);newmask=net.forward_masked(x,which)
    assert all(torch.allclose(clean[k],new[k],rtol=2e-5,atol=2e-5)for k in clean)
    assert all(torch.equal(masked[k],newmask[k]) if masked[k].dtype==torch.bool else torch.allclose(masked[k],newmask[k],rtol=2e-5,atol=2e-5)for k in masked)
    install(net,fields,True);assert set(net.state_dict())==keys
    # Replicating identical keys inside one field must not multiply its prior.
    base=torch.softmax(torch.tensor([.7,1.2],dtype=torch.float64),0)
    for n in(2,7,62):
        x=torch.tensor([.7]+[1.2-math.log(n)]*n,dtype=torch.float64);p=torch.softmax(x,0)
        assert torch.allclose(torch.stack((p[0],p[1:].sum())),base,atol=1e-14,rtol=1e-14)
    return dict(original_clean_forward_replayed=True,original_masked_forward_replayed=True,
        unchanged_trainable_parameter_names=True,field_replication_prior_invariant=True,all115_columns_retained=True,performance_claim=False)

@torch.no_grad()
def infer(net,x,batch=256):
    net.eval();parts={k:[]for k in('coarse_logits','fine_logits','embedding')}
    for start in range(0,len(x),batch):
        out=net(torch.tensor(np.asarray(x[start:start+batch]),dtype=torch.float32))
        for k in parts:parts[k].append(out[k].numpy().astype(np.float64))
    return {k:np.concatenate(v)for k,v in parts.items()}

def train(w,source,parents,corrected,deadline,folder):
    tick=time.perf_counter();torch.manual_seed(20261031);np.random.seed(20261031)
    net=install(w['net'],w['field_columns'],corrected);initial={k:v.detach().clone()for k,v in net.state_dict().items()}
    x=source['native115'];y=source['fine'];coarse=(y>0).astype(np.int64)
    assert len(source['ids'])==5967 and len(parents)==5999 and np.bincount(y[parents],minlength=9).min()>=20
    opt=torch.optim.AdamW(net.parameters(),lr=.0001,weight_decay=.0002);rng=np.random.default_rng(20261031);history=[]
    for epoch in range(1,7):
        assert time.time()<deadline,'shared setting deadline'
        net.train();order=rng.permutation(parents);fields=w['architecture'].balanced_schedule(len(order),len(w['field_columns']),epoch=epoch-1);sums=np.zeros(4);steps=0
        for start in range(0,len(order),128):
            assert time.time()<deadline,'shared setting deadline'
            at=order[start:start+128];bx=torch.tensor(x[at],dtype=torch.float32);cy=torch.tensor(coarse[at]);fy=torch.tensor(y[at]);mask=torch.tensor(fields[start:start+len(at)])
            out=w['architecture'].known_objective(net,bx,cy,fy,mask,roles=('FIT',)*len(at));loss=out['loss']
            opt.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),5.);opt.step();steps+=1
            sums+=np.array([float(out[k].detach())for k in('loss','coarse_loss','fine_loss','masked_loss')])*len(at)
        history.append(dict(epoch=epoch,optimizer_steps=steps,losses=(sums/len(order)).tolist(),elapsed_seconds=time.perf_counter()-tick))
        print('TRAIN',folder.name,epoch,round(history[-1]['losses'][0],6),round(history[-1]['elapsed_seconds'],2),flush=True)
    net.eval();changed=[k for k,v in net.state_dict().items()if not torch.equal(v,initial[k])]
    assert any(k.startswith('attention.')for k in changed)and any(k.startswith('sequence.')for k in changed)
    state=dict(state_dict={k:v.detach().cpu()for k,v in net.state_dict().items()},field_map=w['field_map'],input_width=115,
        original_checkpoint=w['checkpoint'],original_epochs=80,adaptation_epochs=6,seed=20261031,field_count_prior=corrected,
        source_classes=['BEN','KNA'],new_auxiliary_models=0)
    with(folder/'model.pt').open('xb')as f:torch.save(state,f)
    report=dict(epochs=6,steps=sum(h['optimizer_steps']for h in history),history=history,source_seconds=time.perf_counter()-tick,
        unique_FIT_rows=5967,optimizer_rows=5999,changed_state_keys=changed,field_count_prior=corrected,
        loss='Original clean coarseCE +0.35 fineCE(smoothing0.01)+0.03 whole-field masked SmoothL1',
        learning_rate=.0001,weight_decay=.0002,model= C.M.desc(folder/'model.pt'),current_truth_read=False,**C.STATUS)
    C.M.put(folder/'TRAINING.json',report)
    return net,report
