"""V960 data/feature boundary; no model, role or truth work on import.

Legacy model fine codes and optimizer parent order are preserved. Cache-only
features expose raw embedding and field MSE, never a silently mixed geometry.
"""
from pathlib import Path
import hashlib
import importlib.util
import io
import json
import sys
import numpy as np

H=Path(__file__).resolve().parent
MANIFEST=H/'V960_READOUT_REUSE_AND_ROLE_MANIFEST.json'

def require(ok,why):
    if not bool(ok):raise ValueError(why)

def descriptor(path):
    p=Path(path).resolve(strict=True)
    return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def raw(d):
    b=Path(d['path']).read_bytes()
    require(hashlib.sha256(b).hexdigest()==d['sha256'],'immutable bytes '+d['path'])
    return b

def js(d):return json.loads(raw(d).decode('utf-8-sig'))

def arrays(d,fields):
    with np.load(io.BytesIO(raw(d)),allow_pickle=False)as a:return{k:a[k]for k in fields}

def manifest():return json.loads(MANIFEST.read_text(encoding='utf8'))

def module_by_file(d,prefix):
    """No sys.path priority/short-module-name cross-setting selection."""
    raw(d)
    name=prefix+'_'+d['sha256']
    spec=importlib.util.spec_from_file_location(name,d['path'])
    require(spec is not None and spec.loader is not None,'absolute file module loader')
    module=importlib.util.module_from_spec(spec)
    # Dataclass/typing resolution needs the exact absolute-file module name
    # registered; this does not select another folder by a short import name.
    sys.modules[name]=module;spec.loader.exec_module(module)
    return module

class FrozenAssets:
    def __init__(self,setting):
        self.setting=setting;self.config=manifest()['settings'][setting]
        self._adapter=None

    def adapter(self):
        if self._adapter is None:
            self._adapter=module_by_file(self.config['original_adapter'],'v960_owned_'+self.setting)
        return self._adapter

    def load_fit(self):
        """Source only. Return the exact existing logical parent map unchanged."""
        fit=self.adapter().load_fit();t,s=fit['training'],fit['source'];ix=np.asarray(t['optimizer_indices'])
        require(ix.ndim==1 and ix.dtype.kind in'iu'and len(ix)<=6000 and ix.min()>=0 and ix.max()<len(t['x']),'actual legal optimizer map')
        require(np.array_equal(t['coarse'],(np.asarray(t['fine'])>0).astype(np.int64)),'original BEN/KNA fine mapping')
        counts=np.bincount(np.asarray(t['fine'])[ix],minlength=9)
        require(len(counts)==9 and counts.min()>=20,'same logical family floor20')
        require(len(np.unique(s['groups']))==len(s['groups']),'genuine source groups only for statistics')
        trace=arrays(self.config['physical_parent_trace'],('genuine_ids','genuine_groups'))
        require(np.array_equal(s['ids'],trace['genuine_ids'])and np.array_equal(s['groups'],trace['genuine_groups']),
                'source cache exact source-ID/group order, not only matching row count')
        # An arbitrary valid original optimizer ordering is legal. Do not force
        # arange(prefix), sort it, or replace the source's resampling plan.
        return fit

    def load_role(self,role):
        require(role in('CAL','CP','current'),'declared complete role')
        q=self.adapter().load_role(role)
        parent=arrays(self.config['roles'][role]['best_parent'],('ids','prediction'))
        require(np.array_equal(q['ids'],parent['ids'])and np.array_equal(q['parent_prediction'],parent['prediction']),'whole best parent exact order; not V950 metric splice')
        q['role_relationship_to_current']=self.config['roles'][role]['relationship_to_current']
        return q

    def load_known_labels(self,role):
        require(role in('CAL','CP'),'known controls only; no current truth loader')
        return self.adapter().load_known_labels(role)

    def current_known_subset(self):
        """Only the explicitly declared full subset can guard same-current known."""
        rel=self.config['roles']['CP']['relationship_to_current']
        if rel['kind'] not in('full_prefix_subset','full_subset'):
            return None
        cp=arrays(self.config['roles']['CP']['best_parent'],('ids',))['ids']
        current=arrays(self.config['roles']['current']['best_parent'],('ids',))['ids']
        positions={v:i for i,v in enumerate(current.tolist())}
        require(all(v in positions for v in cp.tolist()),'declared full known subset must actually match')
        return np.asarray([positions[v]for v in cp.tolist()],np.int64)

    def _cache_ids(self,role):
        if role=='source':
            return arrays(self.config['physical_parent_trace'],('genuine_ids','genuine_groups'))
        q=self.load_role(role)
        return dict(genuine_ids=q['ids'],genuine_groups=q['groups'])

    def load_cached_readout(self,role):
        """Authorized caller only. CP/current absent => explicit None, no guessing."""
        c=self.config['readout_caches'].get(role)
        if c is None:return None
        require(c['model_checkpoint']==self.config['model_checkpoint']and c['model_state_sha256']==self.config['model_state_sha256'],'same frozen V950 network owner')
        values=arrays(c['asset'],('embedding32','coarse_logits','fine_logits','masked_field_mse'))
        inventory=self._cache_ids(role);ids=inventory['genuine_ids'];n=len(ids)
        require(values['embedding32'].shape==(n,32)and values['masked_field_mse'].shape==(n,self.config['field_count'],2),'complete uncompressed ownfield MSE signature')
        require(all(np.isfinite(v).all()for v in values.values()),'finite frozen readout')
        require(values['fine_logits'].shape==(n,9)and values['coarse_logits'].shape==(n,2),'unchanged original head class order')
        return dict(ids=ids,groups=inventory['genuine_groups'],embedding32_unscaled=values['embedding32'],field_mse=values['masked_field_mse'],
                    coarse_logits=values['coarse_logits'],fine_logits=values['fine_logits'],
                    model_checkpoint=self.config['model_checkpoint'],model_state_sha256=self.config['model_state_sha256'],
                    cache_source=c['asset'],geometry_ready=False,
                    needs_one_frozen_V960_geometry_and_matching_source_fitted_metric=True,
                    signed_encoded_residual_available=False)

    def restore_frozen_v950_model(self,*,device='cpu'):
        """Future authorized readout only; no optimizer or training API here."""
        import torch
        a=self.adapter();w=a.restore_warm();c=self.config
        checkpoint=torch.load(io.BytesIO(raw(c['model_checkpoint'])),map_location='cpu',weights_only=True)
        require(checkpoint['contract']==c['v950_contract']and checkpoint['model_state_sha256']==c['model_state_sha256'],'strict own source-only warm12 checkpoint')
        w['net'].load_state_dict(checkpoint['state_dict'],strict=True)
        digest=a.state_sha(w['net'])if self.setting=='CIC2'else w['architecture'].output_io.state_digest(w['net'])
        require(digest==c['model_state_sha256'],'every restored tensor bound to frozen readout cache')
        w['net'].to(device);w['net'].eval()
        return w

    def readout_missing_role(self,role,*,device='cpu',signature_kind='field_mse'):
        """Future authorized feature forward. No fit/score/label selection.

        field_mse uses exactly the V950 scalar own-field error, not signed
        coordinates or CIC conditional variance. Other signatures require a
        separately frozen reader instead of inventing information from MSE.
        """
        require(signature_kind=='field_mse','unsupported residual signature cannot be reconstructed from MSE')
        cached=self.load_cached_readout(role)
        if cached is not None:return cached
        require(role in('CAL','CP','current'),'only declared role readout; source comes from source cache')
        a=self.adapter();q=self.load_role(role);w=self.restore_frozen_v950_model(device=device)
        c=self.config;core=module_by_file(c['v950_readout_core'],'v960_exact_readout_core')
        if self.setting=='CIC2':
            ro=core.infer_readout(w['net'],q['x'],w['field_columns'],masked_forward=w['masked_forward'],
                clean_forward=w['clean_forward'],conditional_coarse=True)
        else:
            ro=core.infer_grouped_readout(w['net'],q['x'],q['groups'],w['field_columns'],native_first=self.setting=='NSL2')
        return dict(ids=q['ids'],groups=q['groups'],embedding32_unscaled=ro['embedding32'],field_mse=ro['masked_field_mse'],
            coarse_logits=ro['coarse_logits'],fine_logits=ro['fine_logits'],model_checkpoint=c['model_checkpoint'],
            model_state_sha256=c['model_state_sha256'],cache_source=None,new_NN_fit=0,geometry_ready=False,
            signed_encoded_residual_available=False,needs_one_frozen_V960_geometry_and_matching_source_fitted_metric=True)
