"""Source-class local weighted tangent compatibility in two frozen views.

This source-only extension is neither leaf occupancy nor a global PCA probe.
Source R FIT multiplicities weight training statistics; genuine source rows
alone define each local neighborhood. Query rows fit no parameters. Empirical
tail ranks are compatibility scores, never class-membership posteriors.
"""
from pathlib import Path
import hashlib
import importlib.util
import sys
import time

import numpy as np
from sklearn.cluster import KMeans
from sklearn.utils.extmath import randomized_svd
from threadpoolctl import threadpool_limits

SCHEMA = 'V1038_TWO_VIEW_SOURCE_CLASS_LOCAL_WEIGHTED_TANGENT_BANK'
CALIBRATION_SCHEMA = 'V1038_GENUINE_SOURCE_V_QCAL_THREE_TANGENT_REFERENCES'
SOURCE_FIT_STATUS = 'SOURCE_PARAMETERS_COMPLETE'
SEED, CPU_THREADS = 20261024, 4
CENTERS, LOCAL_ROWS, MAX_RANK = 12, 128, 8
UNIT_FLOOR, EIGENVAR_FLOOR, RESIDUAL_RMS_FLOOR = 1e-6, .01, .1
RANK_CODE = dict(path='E:/Experiment/software transcition/target99_v1029_20261024/common/source_relation_novelty_graph_v1029.py',
                 sha256='f5042b01e8e0e0f5c5d1802a4f602d3e4d002eca1cf1b2305137dedad6ffe138')
GRAPH_CODE = dict(path='E:/Experiment/software transcition/target99_v1033_20261024/common/conditional_masked_group_graph_v1033.py',
                  sha256='329475ac889fbb28f609fd1a42553b661d597396b5dc2b8c4dafcb499b78406f')


def _load_rank():
    path = Path(RANK_CODE['path'])
    if hashlib.sha256(path.read_bytes()).hexdigest() != RANK_CODE['sha256']:
        raise ValueError('frozen empirical source rank code changed')
    name = 'V1038_rank_'+RANK_CODE['sha256']
    if name in sys.modules:
        return sys.modules[name]
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module; spec.loader.exec_module(module)
    return module


R = _load_rank()
require = R.require
calibrate_refs, calibrated_boost = R.calibrate_refs, R.calibrated_boost


def _matrix(values):
    result = np.asarray(values, np.float64)
    require(result.ndim == 2 and result.shape[1] > 0 and np.isfinite(result).all(), 'finite original view matrix')
    return result


def _strings(values, n, name):
    result = np.asarray(values).astype(str)
    require(result.shape == (n,) and np.all(result != '') and len(np.unique(result)) == n,
            'unique genuine '+name)
    return result


def _coarse(values, n):
    result = np.asarray(values)
    require(result.shape == (n,) and np.issubdtype(result.dtype, np.integer)
            and np.isin(result, (0, 1)).all(), 'real source BEN0/KNA1 coarse labels only')
    return result.astype(np.int64, copy=False)


def _digest(values):
    array = np.ascontiguousarray(values)
    return hashlib.sha256(str(array.dtype).encode()+str(array.shape).encode()+array.tobytes()).hexdigest()


def _weighted_units(x, weights):
    probability = weights/weights.sum()
    mean = probability@x
    rms = np.sqrt(probability@((x-mean)**2))
    scale = np.maximum(rms, UNIT_FLOOR)
    return dict(mean=mean, scale=scale, raw_weighted_std=rms,
                floored_columns=np.flatnonzero(rms < UNIT_FLOOR),
                weights_are_source_FIT_parent_multiplicity=True, floor=UNIT_FLOOR)


def _fit_local(x, weights, global_positions, ids, center, seed):
    distance = np.linalg.norm(x-center, axis=1)
    # Source ID is the deterministic secondary tie key, independent of labels.
    order = np.lexsort((ids, distance))[:min(LOCAL_ROWS, len(x))]
    local, w = x[order], weights[order]
    probability = w/w.sum()
    mean = probability@local
    centered = local-mean
    rank = min(MAX_RANK, len(local)-1, x.shape[1]-1)
    if rank:
        _, _, basis = randomized_svd(centered*np.sqrt(probability)[:, None],
            n_components=rank, n_iter=3, n_oversamples=10, random_state=int(seed))
    else:
        basis = np.empty((0, x.shape[1]), np.float64)
    coefficients = centered@basis.T
    reconstruction = coefficients@basis
    residual = centered-reconstruction
    eigenvar_raw = probability@(coefficients**2)
    eigenvar = np.maximum(eigenvar_raw, EIGENVAR_FLOOR)
    residual_rms_raw = np.sqrt(probability@(residual**2))
    residual_rms = np.maximum(residual_rms_raw, RESIDUAL_RMS_FLOOR)
    require(np.isfinite(basis).all() and np.isfinite(residual_rms).all()
            and np.isfinite(eigenvar).all(), 'finite local tangent parameters')
    return dict(center=np.asarray(center).copy(), source_positions=global_positions[order].copy(),
        source_ids=ids[order].copy(), source_weights=w.copy(), normalized_source_weights=probability,
        mean=mean, basis=basis, rank=rank, eigenvar=eigenvar, eigenvar_before_floor=eigenvar_raw,
        residual_RMS=residual_rms, residual_RMS_before_floor=residual_rms_raw,
        genuine_local_rows=len(local), duplicated_local_rows_for_reference=False,
        source_distance_to_KMeans_center=distance[order].copy(),
        stable_neighborhood_tie='distance then lexicographic genuine source ID',
        eigenvar_floor=EIGENVAR_FLOOR, residual_RMS_floor=RESIDUAL_RMS_FLOOR)


def fit_bank(N_R, Z_R, ycoarse, g_R, ids_R, FITslots, *, seed=SEED):
    """Fit one source bank: up to48 local tangents plus4 weighted KMeans.

    Both original views get their own globally source-R/FIT-weighted units.
    Per class KMeans has min(12,n_c) centers. Neighborhoods use up to128
    genuine class rows, with FIT multiplicity as weights and no copied rows.
    """
    started = time.perf_counter(); native, paper = _matrix(N_R), _matrix(Z_R); n = len(native)
    require(1 < n <= 6000 and len(paper) == n, 'matched genuine source-R rows within6000')
    y = _coarse(ycoarse, n); require(set(y.tolist()) == {0, 1}, 'both real source coarse classes')
    groups, ids = _strings(g_R, n, 'source-R groups'), _strings(ids_R, n, 'source-R IDs')
    slots = np.asarray(FITslots)
    require(slots.ndim == 1 and np.issubdtype(slots.dtype, np.integer)
            and n <= len(slots) <= 6000 and slots.min() >= 0 and slots.max() < n,
            'traced source-R FIT-only parent slots within6000')
    slots = slots.astype(np.int64, copy=True); multiplicity = np.bincount(slots, minlength=n)
    require(np.all(multiplicity >= 1), 'every genuine source parent retained in FIT map')
    require(isinstance(seed, (int, np.integer)) and 0 <= int(seed) <= 2**32-1, 'fixed supported seed')
    views, kmeans_count, tangent_count = {}, 0, 0
    with threadpool_limits(limits=CPU_THREADS):
        for view_name, x in (('native', native), ('paper', paper)):
            units = _weighted_units(x, multiplicity)
            standard = (x-units['mean'])/units['scale']
            classes = {}
            for c in (0, 1):
                positions = np.flatnonzero(y == c)
                class_x, class_w = standard[positions], multiplicity[positions].astype(np.float64)
                cluster_count = min(CENTERS, len(positions))
                kmeans = KMeans(n_clusters=cluster_count, n_init=3, max_iter=100,
                                random_state=int(seed))
                kmeans.fit(class_x, sample_weight=class_w); kmeans_count += 1
                local_models = [_fit_local(class_x, class_w, positions, ids[positions], center, int(seed))
                                for center in kmeans.cluster_centers_]
                tangent_count += len(local_models)
                classes[str(c)] = dict(genuine_source_rows=len(positions), logical_FIT_rows=int(class_w.sum()),
                    KMeans_centers=kmeans.cluster_centers_.copy(), KMeans_labels=kmeans.labels_.copy(),
                    KMeans_iterations=int(kmeans.n_iter_), KMeans_inertia=float(kmeans.inertia_),
                    KMeans_parameters=dict(n_clusters=cluster_count, n_init=3, max_iter=100, random_state=int(seed)),
                    locals=local_models, local_model_count=len(local_models),
                    overlapping_neighborhoods_and_duplicate_centers_allowed=True)
                del kmeans
            views[view_name] = dict(width=x.shape[1], units=units, classes=classes,
                                    original_R_view_sha256=_digest(x))
    return dict(schema=SCHEMA, fit_status=SOURCE_FIT_STATUS, views=views, source_R_ids=ids.copy(),
        source_R_groups=groups.copy(), source_R_coarse=y.copy(), source_genuine_rows=n,
        FIT_slot_parent_indices=slots, FIT_slot_parent_ids=ids[slots], FIT_slot_parent_groups=groups[slots],
        FIT_parent_multiplicity=multiplicity, logical_FIT_rows=len(slots), seed=int(seed),
        fit_record=dict(KMeans_fits=kmeans_count, local_weighted_PCA_models=tangent_count,
            local_neighborhood_genuine_row_cap=LOCAL_ROWS, local_rank_cap=MAX_RANK,
            class_center_cap=CENTERS, CPU_threads=CPU_THREADS,
            global_R_units_floor=UNIT_FLOOR, local_eigenvar_floor=EIGENVAR_FLOOR,
            local_residual_RMS_floor=RESIDUAL_RMS_FLOOR,
            source_training_classes=['BEN','KNA'], source_true_UNA_fit=False,
            reference_copies_materialized=False, FIT_copies_are_loss_weights_not_independent_events=True,
            new_NN_fits=0, new_HGB_fits=0, new_metric_fits=0,
            entire_bank_source_seconds=time.perf_counter()-started),
        query_parameter_fit=False, source_true_UNA_fit=False, published=False, final_test_executed=False)


def _local_score(standardized_rows, local):
    centered = standardized_rows-local['mean']
    coefficients = centered@local['basis'].T
    residual = centered-coefficients@local['basis']
    off_tangent = np.mean((residual/local['residual_RMS'])**2, axis=1)
    on_tangent = np.mean(coefficients**2/local['eigenvar'], axis=1) if local['rank'] else np.zeros(len(centered))
    value = .5*(off_tangent+on_tangent)
    require(np.isfinite(value).all() and np.all(value >= 0), 'finite nonnegative local tangent score')
    return value


def score_bank(N_Q, Z_Q, g_Q, bank):
    """Score outside-training physical groups only; unavailable rows stay zero."""
    require(bank['schema'] == SCHEMA, 'owned frozen local tangent bank')
    native, paper = _matrix(N_Q), _matrix(Z_Q); n = len(native)
    require(n > 0 and len(paper) == n and native.shape[1] == bank['views']['native']['width']
            and paper.shape[1] == bank['views']['paper']['width'], 'same original query view widths')
    groups = _strings(g_Q, n, 'query groups')
    eligible = ~np.isin(groups, bank['source_R_groups'])
    view_scores = {key:np.zeros((n, 2), np.float64) for key in ('native','paper')}
    selected_locals = {key:np.full((n, 2), -1, np.int64) for key in ('native','paper')}
    use = np.flatnonzero(eligible)
    with threadpool_limits(limits=CPU_THREADS):
        for key, x in (('native',native),('paper',paper)):
            view = bank['views'][key]
            if not len(use):
                continue
            standardized = (x[use]-view['units']['mean'])/view['units']['scale']
            for c in (0, 1):
                locals_ = view['classes'][str(c)]['locals']
                all_local = np.column_stack([_local_score(standardized, local) for local in locals_])
                selected = all_local.argmin(axis=1)
                view_scores[key][use, c] = all_local[np.arange(len(use)), selected]
                selected_locals[key][use, c] = selected
    raw_r = .5*(np.log1p(view_scores['native'])+np.log1p(view_scores['paper']))
    bounded = raw_r/(1.+raw_r)
    view_bounded = {key:value/(1.+value) for key,value in view_scores.items()}
    require(np.isfinite(raw_r).all() and np.isfinite(bounded).all()
            and np.all((bounded >= 0) & (bounded <= 1)), 'fixed bounded combined tangent nonconformity')
    return dict(schema=SCHEMA+'_SCORES', raw_r=raw_r, bounded_nonconformity=bounded,
        view_scores=view_scores, view_bounded_nonconformity=view_bounded, selected_local_indices=selected_locals,
        conditional_eligible=eligible, conditional_available=np.broadcast_to(eligible[:,None],(n,2)).copy(),
        unavailable_row_count=int((~eligible).sum()), unavailable_placeholders=0.,
        raw_combination='.5*(log1p(native class score)+log1p(paper class score))',
        combined_bounding='r/(1+r)', per_view_bounding='s/(1+s)',
        raw_view_score='.5*(mean((off_tangent/residualRMS)^2)+mean(tangent_coeff^2/eigenvar)); rank0 tangent term0',
        query_parameter_fit=False, new_NN_fits=0, new_HGB_fits=0, new_metric_fits=0,
        training_R_overlap_scored=False, class_scores_are_membership_posteriors=False)


def calibrate_bank(N_cal, Z_cal, truecoarse, g_cal, bank, *, ids_cal=None):
    """Three source true-class empirical references from genuine held-excluded V+Qcal.

    Profiles own role and held-family exclusion. Source R overlap and duplicate
    physical calibration parents are rejected. Each true coarse class needs100
    genuine parents; FIT copies cannot enlarge these denominators.
    """
    scores = score_bank(N_cal, Z_cal, g_cal, bank)
    y = _coarse(truecoarse, len(scores['raw_r']))
    groups = _strings(g_cal, len(y), 'source calibration groups')
    ids = groups.copy() if ids_cal is None else _strings(ids_cal, len(y), 'source calibration IDs')
    require(scores['conditional_eligible'].all(), 'genuine calibration is disjoint from trained R groups')
    counts = np.bincount(y, minlength=2)
    require(np.all(counts >= 100), 'each genuine true-coarse source calibration class has at least100 parents')
    combined = R.calibrate_refs(scores['bounded_nonconformity'], y, groups)
    views = {key:R.calibrate_refs(scores['view_bounded_nonconformity'][key], y, groups)
             for key in ('native','paper')}
    return dict(schema=CALIBRATION_SCHEMA, combined_calibration=combined, view_calibrations=views,
        true_class_counts=counts, genuine_reference_ids=ids, genuine_reference_groups=groups,
        true_coarse=y.copy(), reference_raw_r=scores['raw_r'],
        reference_bounded_nonconformity=scores['bounded_nonconformity'],
        reference_view_scores=scores['view_scores'], reference_view_bounded_nonconformity=scores['view_bounded_nonconformity'],
        source_R_ids_sha256=_digest(bank['source_R_ids']), source_R_groups_sha256=_digest(bank['source_R_groups']),
        three_calibration_sets=3, true_class_reference_arrays=6, learned_model_fits=0,
        role_contract='caller genuine held-family-excluded V union Qcal; no source R or Qaudit used as references',
        held_family_exclusion_caller_enforced=True, reference_resampling=False,
        empirical_p_values_are_membership_posteriors=False, views_are_independent_claimed=False,
        finite_sample_graph_or_true_UNA_guarantee_claimed=False, rank_code=RANK_CODE,
        query_parameter_fit=False, source_true_UNA_calibration=False)


def calibrated_evidence(scores, calibration):
    """Use the exact frozen ranks; unavailable rows provide no joint evidence."""
    require(calibration['schema'] == CALIBRATION_SCHEMA, 'owned tangent calibration')
    eligible = np.asarray(scores['conditional_eligible'])
    require(eligible.dtype == np.dtype(bool) and eligible.shape == (len(scores['raw_r']),), 'aligned tangent availability')
    combined = R.calibrated_boost(scores['bounded_nonconformity'], calibration['combined_calibration'])
    views = {key:R.calibrated_boost(scores['view_bounded_nonconformity'][key], calibration['view_calibrations'][key])
             for key in ('native','paper')}
    known_p = combined['known_p_value'].copy(); class_p = combined['class_p_values'].copy(); boost = combined['boost'].copy()
    native_p, paper_p = (views[key]['known_p_value'].copy() for key in ('native','paper'))
    hard = eligible & (known_p < .01) & (native_p < .01) & (paper_p < .01)
    unary = -np.column_stack((class_p, boost)); unary[~eligible] = 0.
    known_p[~eligible] = 0.; class_p[~eligible] = 0.; boost[~eligible] = 0.
    native_p[~eligible] = 0.; paper_p[~eligible] = 0.
    view_class_p = {key:views[key]['class_p_values'].copy() for key in views}
    for value in view_class_p.values(): value[~eligible] = 0.
    return dict(combined_class_p_values=class_p, combined_known_p_value=known_p,
        class_p_values=class_p, known_p_value=known_p,
        view_class_p_values=view_class_p, native_known_p_value=native_p, paper_known_p_value=paper_p,
        view_known_p_values={'native':native_p,'paper':paper_p}, eligible=eligible.copy(),
        unknown_boost=boost, conditional_unary=unary, hard_OOD=hard, conditional_eligible=eligible.copy(),
        p_values_available=eligible.copy(), unavailable_p_values_are_zero_placeholders=True,
        discrete_max_boost=combined['discrete_max_boost'], class_reference_counts=combined['class_reference_counts'],
        hard_OOD_definition='eligible AND combined pKnown<.01 AND native pKnown<.01 AND paper pKnown<.01',
        empirical_class_p_values_are_membership_posteriors=False, independent_views_claimed=False,
        query_parameter_fit=False, known_certificate_requires_existing_graph_QQ_and_A=True,
        noQQ_counterfactual_A_upper_bound=-1., no_true_UNA_guarantee=True)


def pure_synthetic_checks():
    """Toy KMeans/SVD fits are operator checks, not real traffic performance."""
    rng = np.random.default_rng(1038)
    native = np.r_[rng.normal(0,.3,(16,4)), rng.normal(3,.3,(16,4))]
    paper = np.column_stack((native[:,0]+native[:,1],native[:,2]-native[:,3],native[:,0]))
    y = np.repeat([0,1],16); groups = np.asarray(['toyR%d'%i for i in range(32)])
    ids = np.asarray(['id%03d'%i for i in range(32)]); slots = np.r_[np.arange(32),0,0,17]
    bank = fit_bank(native,paper,y,groups,ids,slots)
    require(np.allclose(bank['views']['native']['units']['mean'],native[slots].mean(0))
            and np.allclose(bank['views']['native']['units']['scale'],np.maximum(native[slots].std(0),1e-6)),
            'FIT slot weighted units exactly match materialized population moments')
    local=bank['views']['native']['classes']['0']['locals'][0]
    standard=(native-bank['views']['native']['units']['mean'])/bank['views']['native']['units']['scale']
    positions=local['source_positions']; p=local['normalized_source_weights'];centered=standard[positions]-local['mean']
    coefficients=centered@local['basis'].T; residual=centered-coefficients@local['basis']
    require(np.allclose(local['eigenvar'],np.maximum(p@(coefficients**2),.01))
            and np.allclose(local['residual_RMS'],np.maximum(np.sqrt(p@(residual**2)),.1)),
            'weighted projection coefficient variance and diagonal residual RMS')
    query=np.asarray([[.1,.2,.3,.4],[3.,3.,3.,3.]])
    zquery=np.column_stack((query[:,0]+query[:,1],query[:,2]-query[:,3],query[:,0]))
    scores=score_bank(query,zquery,np.asarray(['new','toyR0']),bank)
    model=bank['views']['native']; standardized=(query[:1]-model['units']['mean'])/model['units']['scale']
    expected=min(float(_local_score(standardized,l)[0]) for l in model['classes']['0']['locals'])
    require(scores['view_scores']['native'][0,0]==expected
            and np.all(scores['bounded_nonconformity'][1]==0.) and not scores['conditional_eligible'][1],
            'class score is minimum local score; trained-R overlap is unscored neutral')
    caln=rng.normal(1,1,(300,4)); calz=np.column_stack((caln[:,0]+caln[:,1],caln[:,2]-caln[:,3],caln[:,0]))
    cal=calibrate_bank(caln,calz,np.repeat([0,1],150),np.asarray(['cal%d'%i for i in range(300)]),bank)
    # Artificial bounded score arrays test exact rank logic and hard two-view direction.
    reference=R.calibrate_refs(np.full((300,2),.2),np.repeat([0,1],150),np.asarray(['ref%d'%i for i in range(300)]))
    fakecal=dict(schema=CALIBRATION_SCHEMA,combined_calibration=reference,view_calibrations={'native':reference,'paper':reference})
    fake=dict(raw_r=np.zeros((3,2)),bounded_nonconformity=np.ones((3,2)),
        view_bounded_nonconformity={'native':np.ones((3,2)),'paper':np.asarray([[1.,1.],[0.,0.],[1.,1.]])},
        conditional_eligible=np.asarray([True,True,False]))
    evidence=calibrated_evidence(fake,fakecal)
    require(evidence['hard_OOD'].tolist()==[True,False,False]
            and np.all(evidence['conditional_unary'][2]==0.) and not evidence['p_values_available'][2],
            'hard OOD needs allthree upper-tail max-p rejections and eligibility; invalid evidence neutral')
    require(all(v['class_counts'].tolist()==[150,150] for v in [cal['combined_calibration'],*cal['view_calibrations'].values()]),
            'three references preserve genuine true-class denominators')
    return dict(weighted_slots_population_units=True,weighted_local_projection=True,class_view_minimum=True,
        trained_R_group_neutral=True,source_calibration_three_sets=True,hard_OOD_allthree_direction=True,
        toy_KMeans_fits=bank['fit_record']['KMeans_fits'],toy_local_weighted_PCA_models=bank['fit_record']['local_weighted_PCA_models'],
        real_source_fit_count=0,real_data_reads=0,actual_role_reads=0,new_NN_fits=0,new_HGB_fits=0,new_metric_fits=0,
        performance_claimed=False,rank_formula=RANK_CODE,graph_compatibility=GRAPH_CODE)
