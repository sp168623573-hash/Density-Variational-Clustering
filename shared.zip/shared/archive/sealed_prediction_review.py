"""Independent read-only verification of sealed results; additive round report."""
from pathlib import Path
import csv
import json
import numpy as np
from review_baselines import ROOT, OUT, INC, CLASSES, BASELINES, digest, descriptor, write_json


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def verify_refs(obj):
    count=0
    if isinstance(obj,dict):
        if 'path' in obj and 'sha256' in obj:
            assert digest(obj['path'])==obj['sha256'],obj['path']
            return 1
        for value in obj.values():count+=verify_refs(value)
    elif isinstance(obj,list):
        for value in obj:count+=verify_refs(value)
    return count


def verify_tables(path):
    spec=read(path);checked=0
    for table in spec['tables']:
        with Path(table['path']).open(encoding='utf-8-sig',newline='') as f:
            actual=list(csv.reader(f))
        expected=table['matrix']
        assert len(actual)==len(expected)
        for ar,er in zip(actual,expected):
            assert len(ar)==len(er)
            for a,e in zip(ar,er):
                if e is None:assert a==''
                elif isinstance(e,bool):assert a.lower()==str(e).lower()
                elif isinstance(e,(int,float)):assert abs(float(a)-e)<=1e-14*max(1,abs(e))
                else:assert a==e,(a,e)
                checked+=1
    return checked


def verify_candidate(setting,folder,pair,result_path,tables,prediction_path):
    base=BASELINES[setting]
    with np.load(base['prediction'],allow_pickle=False) as b,np.load(base['truth'],allow_pickle=False) as t,np.load(pair,allow_pickle=False) as q,np.load(prediction_path,allow_pickle=False) as p:
        ids=q['ids'].astype(str);truth=q['truth'];prediction=q['prediction'];parent=q['parent_prediction']
        assert len(set(ids))==len(ids)
        assert np.array_equal(ids,b['ids'].astype(str)) and np.array_equal(ids,t['ids'].astype(str))
        assert np.array_equal(ids,p['ids'].astype(str))
        assert np.array_equal(truth,t['truth']) and np.array_equal(parent,b['prediction'])
        assert np.array_equal(prediction,p['prediction'])
    r=read(result_path);matrix=np.zeros((3,3),dtype=np.int64)
    np.add.at(matrix,(prediction,truth),1)
    assert matrix.tolist()==r['confusion_matrix']
    gains=[];losses=[];correct=[];support=[];gap=[]
    for k,c in enumerate(CLASSES):
        mask=truth==k;g=int(np.sum(mask&(prediction==k)&(parent!=k)));l=int(np.sum(mask&(prediction!=k)&(parent==k)))
        n=int(mask.sum());v=int(np.sum(mask&(prediction==k)));gate=r['gates'][c]
        assert gate['correct']==v and gate['support']==n and gate['required_correct']==(99*n+99)//100
        assert gate['gap']==max(0,(99*n+99)//100-v)
        assert gate['passed']==(100*v>=99*n)
        assert r['EffectDelta']['per_class'][c]['gained_correct']==g
        assert r['EffectDelta']['per_class'][c]['lost_correct']==l
        gains.append(g);losses.append(l);correct.append(v);support.append(n);gap.append(gate['gap'])
    delta=np.array(correct)-np.array(base['correct'])
    direction='UNCHANGED' if np.all(delta==0) else 'UP' if np.all(delta>=0) else 'DOWN' if np.all(delta<=0) else 'MIXED'
    assert direction==r['EffectDelta']['direction']
    assert r['published'] is False and r['final_test_executed'] is False
    cells=sum(verify_tables(p)for p in tables)
    return dict(setting=setting,correct=correct,support=support,gaps=gap,gain=gains,loss=losses,
                delta=delta.tolist(),EffectDelta=direction,old_correct_UNA_loss=losses[2],
                whole_vector_verified=True,all_IDs_and_truth_verified=True,changed_predictions=int(np.sum(prediction!=parent)),
                baseline_replaced=False,result=descriptor(result_path),postseal_pair=descriptor(pair),
                csv_cells_independently_verified=cells,code_folder=str(folder))


def main():
    cic=INC/'target99_cic2_20261028';nsl2=INC/'target99_nsl2_20261028';nsl1=INC/'target99_nsl1_20261028'
    index_paths={'CIC2':cic/'DELIVERY_INDEX.json','NSL2':nsl2/'DELIVERY_INDEX.json','NSL1':nsl1/'DELIVERY_INDEX_COMPLETE.json'}
    indexes={s:read(p)for s,p in index_paths.items()}
    refcounts={s:verify_refs(i)for s,i in indexes.items()}
    candidate={}
    candidate['CIC2']=verify_candidate('CIC2',cic,
        cic/'actual_once/current-evaluate/current_postseal_pair.npz',
        cic/'actual_once/current-evaluate/results_current/result.json',
        [cic/'actual_once'/phase/('results_'+role)/'tables.json'for phase,role in [('known-evaluate','CAL'),('known-evaluate','CP'),('current-evaluate','current')]],
        cic/'actual_once/current-predict/current_prediction_before_truth.npz')
    candidate['NSL2']=verify_candidate('NSL2',nsl2,
        nsl2/'actual_once/current_postseal_pair.npz',nsl2/'actual_once/results_current/result.json',
        [nsl2/'actual_once'/('results_'+role)/'tables.json'for role in ('CAL','CP','current')],
        nsl2/'actual_once/current_prediction_before_truth.npz')
    source1=read(nsl1/'source_report.json');time1=read(nsl1/'source_execution_receipt.json')
    assert source1['source_qualification'] is False and source1['source_proxy_unique_signal']==0
    assert source1['source_true_classes']==['BEN','KNA'] and source1['target_truth_reads']==0
    candidate['NSL1']=dict(candidate_result=None,EffectDelta='NOT_COMPARABLE',execution_status='SOURCE_QUALIFICATION_STOP',
        source_fit_seconds=source1['new_source_fit_seconds'],source_phase_seconds=source1['source_fit_calibration_audit_seconds'],
        external_source_seconds=time1['external_seconds'],baseline_replaced=False,
        reason='Nonfinite known Qcal 99% order statistics disable all frozen new candidate cues; no current inference or new DEV performance result.',
        retained_baseline_export_is_not_new_performance=True,source_report=descriptor(nsl1/'source_report.json'))
    nsl1tables=list((nsl1/'retained_baseline').rglob('tables.json'))
    assert len(nsl1tables)==1
    candidate['NSL1']['csv_cells_independently_verified']=verify_tables(nsl1tables[0])
    ts2=read(nsl2/'actual_once/source_report.json');te2=read(nsl2/'external_receipt.json')
    tc=read(cic/'actual_once/source/external_receipt.json');cs=read(cic/'actual_once/source/report.json')
    times=dict(CIC2=dict(source_phase_external_seconds=tc['wall_seconds'],model_fit_seconds=cs['model_fit_seconds'],scope='nine new HGB fits plus source graph qualification'),
        NSL2=dict(source_phase_seconds=ts2['source_seconds'],external_fit_and_three_role_prediction_seconds=te2['external_seconds'],scope='nine nonparametric source support banks'),
        NSL1=dict(model_fit_seconds=source1['new_source_fit_seconds'],source_phase_external_seconds=time1['external_seconds'],scope='nine projection depth banks, stopped at source qualification'))
    assert tc['wall_seconds']<1800 and te2['external_seconds']<1800 and time1['external_seconds']<1800
    assert tc['exit_code']==te2['exit_code']==time1['exit_code']==0
    frozen=read(OUT/'BASELINE_FREEZE_MANIFEST.json');preserved=read(OUT/'ORIGINAL_PRESERVATION_VERIFICATION.json')
    assert preserved['passed'] is True and not preserved['changed_files']
    report=dict(schema='TARGET99_20261028_INDEPENDENT_ROUND_REVIEW',CIC1_frozen=True,
        exact_integer_gate='100*correct >= 99*support; required=(99*support+99)//100',
        user_requested_baselines=frozen['baselines'],candidate_results=candidate,
        baseline_replacements=[],round_has_accepted_improvement=False,training=times,
        training_budget_scope='Actual new fitting in this round; existing models reused. This is not a measured cold rebuild of the historical pipeline.',
        source_classes=['BEN','KNA'],current_UNA_training=False,new_neural_epochs=0,
        delivery_indexes={s:descriptor(p)for s,p in index_paths.items()},
        artifact_reference_checks=refcounts,preserved_original_files=preserved['checked_files'],
        status='FAIL_TARGET99',published=False,final_test_executed=False,
        strict_final_registration_gap='INDEPENDENT_FULL_TABLE1_SAME_FEATURE_FOUR_SETTING_COHORT_UNAVAILABLE')
    write_json(OUT/'ROUND_REVIEW.json',report)
    write_json(OUT/'CURRENT_FOUR_SETTING_SCORECARD.json',dict(baselines=frozen['baselines'],baseline_replacements=[],CIC1_frozen=True,status='FAIL_TARGET99',published=False,final_test_executed=False))
    lines=['2026-10-28 四设置继续优化：本轮没有可接纳的性能提升。',
        'CIC1冻结；原版保留。NSL2以用户指定V1051 1511/581/3125为基线，不采用V1061总表中的旧版1511/582/3124。',
        '', '本轮实测/停止情况：',
        f"CIC2 局部有符号切空间残差：{candidate['CIC2']['correct']}；{candidate['CIC2']['EffectDelta']}，增量源训练与资格检查{tc['wall_seconds']:.3f}秒。",
        'NSL2 真实双见证多语义块支持：1514/1604、581/589、3019/3393；MIXED，+3/0/-106。损失106条旧正确UNA，拒绝替换。',
        f"NSL2 增量源拟合与审计{ts2['source_seconds']:.3f}秒；含三角色推理外部{te2['external_seconds']:.3f}秒。",
        f"NSL1 投影深度：实际拟合{source1['new_source_fit_seconds']:.3f}秒，源外部阶段{time1['external_seconds']:.3f}秒。源校准分位无界，候选信号关闭，SOURCE_QUALIFICATION_STOP。",
        'NSL1未运行新current推理；candidate_result=null、EffectDelta=NOT_COMPARABLE。其三种结果文件是保留V918基线重核，不能当作本轮新性能。',
        '', '继续保留的完整DEV版本（BEN/KNA/UNA；距99%整数门）：']
    for setting,r in frozen['baselines'].items():
        gates=r['gates'];lines.append(setting+' '+r['version']+' | '+' | '.join(f"{gates[c]['correct']}/{gates[c]['support']}"for c in CLASSES)+' | '+ '/'.join(str(gates[c]['gap'])for c in CLASSES))
    lines += ['', '资源与验证：',
        '本轮三个设置的新增拟合均低于30分钟，仅使用现有BEN/KNA源。新增NN epoch=0；HGB迭代与非参数拟合不冒充NN epoch。历史模型复用，未测全链冷启动。',
        f"{preserved['checked_files']}个受保护原代码/资产/结果文件SHA256复核未变。独立核对完整ID、真值、预测向量、矩阵、每类gain/loss、整数门和CSV持久化内容。",
        '两份新完整DEV候选均保持独立预测向量；不拼各版本的类别指标。CIC1未训练、未重新推理。',
        '', '三种结果文件：experiment_B_transfer_metrics.csv、experiment_B_transfer_accuracy.csv、Matrix.txt。',
        'CIC2与NSL2各CAL/CP/current，NSL1仅retained_baseline重核；精确路径与SHA256见各DELIVERY_INDEX.json。',
        str(index_paths['CIC2']),str(index_paths['NSL2']),str(index_paths['NSL1']),
        '', '新增失败路线均记录ERROR_AND_NO_REPEAT；本轮观察之后没有重新选阈值或再次拟合。',
        '四设置十二个整数门仍未全部通过，独立最终队列也未获验证。FAIL_TARGET99；published=false；final_test_executed=false。']
    (OUT/'ROUND_REPORT.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps(dict(candidates={s:r.get('correct')for s,r in candidate.items()},references_verified=refcounts,preserved_files=preserved['checked_files'],status='FAIL_TARGET99'),ensure_ascii=False))


if __name__=='__main__':main()
