"""V960 frozen known-only field-shape compatibility and bidirectional compose.

Pure numerical APIs: no file, model, traffic, current-truth or training-loader
access. Inputs must come from the caller's original owned fixed MHFD weights.
All persistent parameters are fitted from one genuine-parent FIT row each;
only finite99 score cutoffs consume known CAL labels. New Eq9/10 fitting and
full unlabelled context density are supplied by their owned adapters.
"""
from __future__ import annotations
import hashlib
import math
import numpy as np
from sklearn.cluster import KMeans

SEED=20261023


def require(ok,message):
    if not bool(ok):raise ValueError(message)


def recipe():
    return dict(schema='V960_ORIGINAL_MHFD_FIELD_SHAPE_COMPATIBILITY',new_NN_training=False,
        original_best_weights_only=True,eps='max(median(correct source field MSE)*1e-3,1e-8)',
        q='[log(e+eps)-mean_fields(log(e+eps)), mean(x-pred)/sqrt(e+eps), mean_fields(log(e+eps))]',
        q_units='genuine-source correct-head median/MAD*1.4826; exact zero -> IQR/1.349 ->1; no clipping or query fit',
        Z='original MHFD h32 / genuine source RMS, q_std0, q_std1 only for CIC2 conditional head',
        source_modes=dict(BEN_cap=8,KNA_fine_cap=3,min_mode=20,KMeans_seed=SEED,KMeans_n_init=1,KMeans_max_iter=50),
        variance='(n*localPopulationVar+20*coarseGlobalPopulationVar)/(n+20), floor coarseGlobalVar*1e-4+1e-8',
        Student3='proper independent coordinates with actual variance v: .5log(v)+log(pi/2)+2log1p(delta^2/v)',
        mode_score='sum Student3 NLL(q_h)+log1p(newEq9_10distance(Z,modeZcentre)^2/modeSourceMeanSquaredRadius)',
        radius_zero_fallback='median strictly positive mode radii squared, else1',
        mixture='BEN empirical mode masses; KNA fine uniform1/8 then empirical within-fine mode masses; -logsumexp',
        CAL='one true-known coarse finite99 rank ceil(99*(n+1)/100), strict greater rejects',
        dynamic='dual rejection + density structure + fixed7NN raw majority -> UNA; unique acceptance + fixed7NN same unique-class majority -> known, historical U requires dominant mode >=20 genuine',
        neural_logits='record hierarchy/conflicts only, never confidence protection or hard veto',
        old_U_seeds=False,old_U_hardlocked=False,source_or_query_copies_as_independent=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)


def _array_hash(a):
    a=np.ascontiguousarray(a)
    require(not a.dtype.hasobject,'no object array binding')
    return dict(shape=list(a.shape),dtype=a.dtype.str,sha256=hashlib.sha256(a.tobytes()).hexdigest())


def _source_labels(fine,parent_ids,n):
    fine=np.asarray(fine);parents=np.asarray(parent_ids)
    require(fine.shape==parents.shape==(n,)and fine.dtype.kind in'iu'and 0<n<=6000,'aligned true-known genuine FIT labels and parents')
    require(np.array_equal(np.unique(fine),np.arange(9)),'original own fine0 BEN / fine1..8 KNA mapping preserved')
    require(not parents.dtype.hasobject and len(np.unique(parents))==n,'one genuine parent each, never copies for support')
    return fine,parents,(fine>0).astype(np.int64)


def _readout(readout):
    e=np.asarray(readout['field_mse'],np.float64);r=np.asarray(readout['field_signed'],np.float64)
    h=np.asarray(readout['embedding32'],np.float64)
    require(e.ndim==3 and e.shape[2]==2 and r.shape==e.shape and h.shape==(len(e),32),'actual clean32 and both owned coarse-head whole-field moments')
    require(np.isfinite(e).all()and np.isfinite(r).all()and np.isfinite(h).all()and np.all(e>=0),'finite field moments; MSE nonnegative')
    return e,r,h


def _unscaled_q(e,r,eps):
    a=np.log(e+eps[None,:,None]);amp=a.mean(axis=1)
    shape=a-amp[:,None,:];direction=r/np.sqrt(e+eps[None,:,None])
    return np.concatenate([shape.transpose(0,2,1),direction.transpose(0,2,1),amp[:,:,None]],axis=2)


def fit_units(source_readout,fine,genuine_parent_ids,*,conditional_coarse=False):
    e,r,h=_readout(source_readout);fine,parents,c=_source_labels(fine,genuine_parent_ids,len(e))
    correct=e[np.arange(len(e)),:,c]
    eps=np.maximum(np.median(correct,axis=0)*1.e-3,1.e-8)
    q=_unscaled_q(e,r,eps);actual=q[np.arange(len(q)),c]
    median=np.median(actual,axis=0);mad=1.4826*np.median(np.abs(actual-median),axis=0)
    iqr=(np.quantile(actual,.75,axis=0)-np.quantile(actual,.25,axis=0))/1.349
    use_iqr=mad==0.;scale=np.where(use_iqr,iqr,mad);use_one=scale==0.;scale=np.where(use_one,1.,scale)
    rms=np.sqrt(np.mean(h*h,axis=0));rms_zero=rms<=1.e-12;rms=np.where(rms_zero,1.,rms)
    require(np.isfinite(scale).all()and np.all(scale>0),'genuine source finite positive robust units')
    if not conditional_coarse:require(np.array_equal(e[:,:,0],e[:,:,1])and np.array_equal(r[:,:,0],r[:,:,1]),'NSL nonconditional heads must be byte-equal aliases, no duplicate q geometry')
    return dict(schema='V960_GENUINE_SOURCE_FIELD_SHAPE_UNITS',field_count=e.shape[1],Q=2*e.shape[1]+1,
        conditional_coarse=bool(conditional_coarse),eps=eps.tolist(),q_median=median.tolist(),q_scale=scale.tolist(),
        MAD_zero_IQR_fallback=np.flatnonzero(use_iqr).tolist(),IQR_zero_unit1_fallback=np.flatnonzero(use_one).tolist(),
        embedding_RMS=rms.tolist(),embedding_RMS_unit1_fallback=np.flatnonzero(rms_zero).tolist(),
        genuine_rows=len(e),genuine_fine_counts=np.bincount(fine,minlength=9).tolist(),
        genuine_parent_binding=_array_hash(parents),fine_binding=_array_hash(fine),
        no_query_fit=True,no_query_clip=True,copies_used=False,recipe=recipe())


def transform(readout,units):
    e,r,h=_readout(readout);eps=np.asarray(units['eps'],np.float64)
    require(e.shape[1]==units['field_count']and eps.shape==(e.shape[1],),'same original field map as source units')
    if not units['conditional_coarse']:require(np.array_equal(e[:,:,0],e[:,:,1])and np.array_equal(r[:,:,0],r[:,:,1]),'no fictitious second NSL head')
    q=(_unscaled_q(e,r,eps)-np.asarray(units['q_median'])[None,None,:])/np.asarray(units['q_scale'])[None,None,:]
    parts=[h/np.asarray(units['embedding_RMS']),q[:,0]]
    if units['conditional_coarse']:parts.append(q[:,1])
    z=np.concatenate(parts,axis=1)
    require(np.isfinite(q).all()and np.isfinite(z).all(),'finite unclipped new q and Z geometry')
    result=dict(Z=z,q_std=q)
    for key in('coarse_logits','fine_logits'):
        if key in readout:result[key]=np.asarray(readout[key]).copy()
    return result


def _merged_modes(q,k):
    if k==1:return np.zeros(len(q),np.int64)
    labels=KMeans(n_clusters=k,n_init=1,max_iter=50,random_state=SEED).fit_predict(q)
    while len(np.unique(labels))>1:
        values,counts=np.unique(labels,return_counts=True);small=values[counts<20]
        if not len(small):break
        victim=int(small[0]);others=values[values!=victim];center=q[labels==victim].mean(axis=0)
        target=int(others[np.argmin([np.mean((center-q[labels==j].mean(axis=0))**2)for j in others])])
        labels[labels==victim]=target
    return labels


def fit_modes(source_transformed,fine,genuine_parent_ids):
    z=np.asarray(source_transformed['Z'],np.float64);q=np.asarray(source_transformed['q_std'],np.float64)
    fine,parents,c=_source_labels(fine,genuine_parent_ids,len(z))
    require(z.ndim==2 and q.ndim==3 and q.shape[:2]==(len(z),2)and np.isfinite(z).all()and np.isfinite(q).all(),'new source Z/q geometry finite')
    actual=q[np.arange(len(q)),c];global_var=[actual[c==j].var(axis=0)for j in(0,1)]
    modes=[];counts=np.bincount(fine,minlength=9)
    for j in range(9):
        indices=np.flatnonzero(fine==j);qq=actual[indices];n=len(indices);coarse=int(j>0)
        labels=_merged_modes(qq,1 if n<20 else min(8 if j==0 else 3,n//20))
        for label in np.unique(labels):
            rows=indices[labels==label];nn=len(rows);local=actual[rows]
            prior=global_var[coarse];variance=np.maximum((nn*local.var(axis=0)+20.*prior)/(nn+20.),prior*1.e-4+1.e-8)
            weight=nn/n if coarse==0 else(nn/n)/8.
            modes.append(dict(index=len(modes),fine=j,coarse=coarse,genuine_count=nn,low_support=nn<20,
                log_weight=float(math.log(weight)),q_center=local.mean(axis=0).tolist(),variance=variance.tolist(),
                Z_center=z[rows].mean(axis=0).tolist(),genuine_source_rows=rows.tolist(),radius_squared=None))
    require(all(abs(sum(math.exp(m['log_weight'])for m in modes if m['coarse']==c)-1.)<1.e-10 for c in(0,1)),'proper class-conditional mode/fine mixture masses')
    return dict(schema='V960_GENUINE_FINE_LOCAL_STUDENT3_MODES',dimension=z.shape[1],Q=q.shape[2],modes=modes,
        genuine_rows=len(z),genuine_fine_counts=counts.tolist(),genuine_parent_binding=_array_hash(parents),
        fine_binding=_array_hash(fine),source_Z_binding=_array_hash(z),source_q_binding=_array_hash(q),
        local_variance_used_in_density=True,new_metric_radii_attached=False,recipe=recipe())


def attach_metric_radii(support,source_transformed,fine,genuine_parent_ids,metric):
    import copy
    state=copy.deepcopy(support);z=np.asarray(source_transformed['Z'],np.float64)
    fine,parents,_=_source_labels(fine,genuine_parent_ids,len(z))
    require(_array_hash(parents)==state['genuine_parent_binding']and _array_hash(fine)==state['fine_binding']and _array_hash(z)==state['source_Z_binding'],'exact same genuine source rows for new Eq9/10 radii')
    require(metric.dimension==state['dimension'],'newly fitted metric and source mode geometry agree')
    values=[]
    for mode in state['modes']:
        rows=np.asarray(mode['genuine_source_rows'],np.int64);center=np.asarray(mode['Z_center'],np.float64)[None,:]
        distance=np.asarray(metric.pairwise_distances(z[rows],center),np.float64)
        require(distance.shape==(len(rows),1)and np.isfinite(distance).all()and np.all(distance>=0),'same new metric source-mode radius')
        values.append(float(np.mean(distance[:,0]**2)))
    positive=[v for v in values if v>0.];fallback=float(np.median(positive)) if positive else 1.
    for mode,value in zip(state['modes'],values):
        mode['radius_squared']=value if value>0. else fallback;mode['zero_radius_used_global_fallback']=value==0.
    state.update(new_metric_radii_attached=True,positive_radius_fallback=fallback)
    return state


def _logsumexp(values):
    high=np.max(values,axis=1)
    return high+np.log(np.exp(values-high[:,None]).sum(axis=1))


def score(transformed,support,metric):
    z=np.asarray(transformed['Z'],np.float64);q=np.asarray(transformed['q_std'],np.float64)
    require(support['new_metric_radii_attached']is True and z.shape[1]==metric.dimension==support['dimension']and q.shape==(len(z),2,support['Q']),'same newly fitted Eq9/10 geometry for scores and density')
    class_scores=np.empty((len(z),2));dominant_mode=np.empty((len(z),2),np.int64)
    dominant_fine=np.empty_like(dominant_mode);dominant_count=np.empty_like(dominant_mode)
    dominant_shape_nll=np.empty((len(z),2));dominant_metric_term=np.empty((len(z),2))
    for c in(0,1):
        modes=[m for m in support['modes']if m['coarse']==c];terms=[];nlls=[];spatial=[]
        for mode in modes:
            variance=np.asarray(mode['variance'],np.float64);center=np.asarray(mode['q_center'],np.float64)
            nll=np.sum(.5*np.log(variance)+math.log(math.pi/2.)+2.*np.log1p((q[:,c]-center)**2/variance),axis=1)
            d=metric.pairwise_distances(z,np.asarray(mode['Z_center'],np.float64)[None,:])[:,0]
            local=np.log1p(d*d/mode['radius_squared'])
            terms.append(mode['log_weight']-nll-local);nlls.append(nll);spatial.append(local)
        mixture=np.stack(terms,axis=1);which=mixture.argmax(axis=1);class_scores[:,c]=-_logsumexp(mixture)
        dominant_mode[:,c]=np.asarray([m['index']for m in modes])[which]
        dominant_fine[:,c]=np.asarray([m['fine']for m in modes])[which]
        dominant_count[:,c]=np.asarray([m['genuine_count']for m in modes])[which]
        dominant_shape_nll[:,c]=np.stack(nlls,axis=1)[np.arange(len(z)),which]
        dominant_metric_term[:,c]=np.stack(spatial,axis=1)[np.arange(len(z)),which]
    require(np.isfinite(class_scores).all(),'finite proper Student mode-mixture compatibility scores')
    result=dict(class_scores=class_scores,dominant_mode=dominant_mode,dominant_fine=dominant_fine,
        dominant_genuine_count=dominant_count,dominant_shape_nll=dominant_shape_nll,dominant_metric_term=dominant_metric_term)
    if'coarse_logits'in transformed and'fine_logits'in transformed:
        coarse=np.asarray(transformed['coarse_logits']).argmax(axis=1);fine=np.asarray(transformed['fine_logits']).argmax(axis=1)
        result.update(neural_coarse=coarse,neural_fine=fine,neural_hierarchy_agrees=coarse==(fine>0))
    return result


def calibrate(scores,CAL_coarse):
    values=np.asarray(scores['class_scores'],np.float64);y=np.asarray(CAL_coarse)
    require(values.ndim==2 and values.shape[1]==2 and y.shape==(len(values),)and np.array_equal(np.unique(y),[0,1]),'true-known CAL coarse only, never UNA labels')
    cuts=[];inventory=[]
    for c in(0,1):
        a=values[y==c,c];require(np.isfinite(a).all(),'finite trueclass CAL scores')
        rank=(99*(len(a)+1)+99)//100;supported=rank<=len(a)
        cuts.append(float(np.sort(a)[rank-1])if supported else None)
        inventory.append(dict(coarse=c,support=len(a),rank=rank,finite_supported=supported))
    return dict(schema='V960_ONE_KNOWN_CAL_FINITE99_CUT',cuts=cuts,inventory=inventory,
        strict_greater_reject=True,central50_used=False,query_fit=False,unknown_labels_used=False)


def decisions(scores,cuts):
    values=np.asarray(scores['class_scores'],np.float64);accept=np.empty(values.shape,bool);supported=[]
    for c in(0,1):
        cut=cuts['cuts'][c];supported.append(cut is not None)
        # An unsupported finite rank supplies no evidence to reject that class.
        accept[:,c]=True if cut is None else values[:,c]<=cut
    raw=~accept.any(axis=1);unique=accept.sum(axis=1)==1;which=accept.argmax(axis=1)
    unique&=np.asarray(supported,bool)[which]
    return dict(raw=raw,accepted=accept,unique_accept=unique,accepted_class=which)


def candidate_mask(scores,cuts):
    return decisions(scores,cuts)['raw']


def unique_accept_mask(scores,cuts):
    d=decisions(scores,cuts)
    return d['accepted']&d['unique_accept'][:,None]


def compose(scores,cuts,parent_prediction,density_result):
    parent=np.asarray(parent_prediction);d=decisions(scores,cuts);n=len(parent)
    require(parent.shape==(n,)and np.isin(parent,[0,1,2]).all()and d['raw'].shape==(n,),'whole same ordered categorical parent')
    retained=np.asarray(density_result['retained'])
    require(retained.dtype==bool and retained.shape==(n,)and np.all(~retained|d['raw']),'only dual rejected flows retained by same-run whole-context DVC')
    raw_majority=np.asarray(density_result['raw_majority'])
    majority=np.stack([density_result['known_B_majority'],density_result['known_K_majority']],axis=1)
    require(raw_majority.dtype==majority.dtype==bool and raw_majority.shape==(n,)and majority.shape==(n,2),'fixed physical-context 7NN votes for raw and unique-class acceptance')
    require(np.all(~retained|raw_majority),'new UNA also needs raw-neighbour majority, never only a known large cluster')
    winning=d['accepted_class'];counts=np.asarray(scores['dominant_genuine_count'])[np.arange(n),winning]
    known=d['unique_accept']&majority[np.arange(n),winning]&((parent!=2)|(counts>=20))
    out=parent.copy();out[known]=winning[known];out[retained]=2
    return dict(prediction=out,new_raw=d['raw'],new_UNA=retained,
        returned_BEN=(parent==2)&(out==0),returned_KNA=(parent==2)&(out==1),
        known_cross=(parent!=2)&(out!=2)&(out!=parent),unique_known_accept=d['unique_accept'],
        known_action=known,strict_known=known,raw_majority=raw_majority,known_class_majority=majority,
        dominant_low_support_oldU_return_blocked=(parent==2)&d['unique_accept']&(counts<20),
        class_accepted=d['accepted'],old_U_seed_used=False,neural_hierarchy_hard_veto=False)
