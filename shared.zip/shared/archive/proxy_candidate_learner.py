"""Source-V held-family proxy candidate HGB, separate from dataset UNA.

This module has no source-file/role reader and performs no work on import.
ID hashes choose held-bank views only; IDs, group IDs, fine IDs, bank IDs and
argmax classes never enter features. Only fit_meta explicitly fits one HGB.
"""
import hashlib
import math
import time

import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits

SCHEMA='V1041_SOURCE_V_HELD_FAMILY_PROXY_NONLINEAR_CANDIDATE'
PLAN_SCHEMA=SCHEMA+'_VIEW_PLAN'
FEATURE_SCHEMA=SCHEMA+'_FEATURES'
CUT_SCHEMA=SCHEMA+'_MATCHED_BANK_QCAL_CUT'
SEED=20261024
CPU_THREADS=4
HGB_PARAMETERS=dict(max_iter=80,max_leaf_nodes=15,learning_rate=.05,l2_regularization=1.,
    max_bins=64,min_samples_leaf=20,class_weight='balanced',early_stopping=False,random_state=SEED)


def require(condition,message):
    if not bool(condition):raise ValueError(message)


def _strings(values,n,name):
    result=np.asarray(values).astype(str)
    require(result.shape==(n,)and np.all(result!='')and len(np.unique(result))==n,'unique genuine '+name)
    return result


def _matrix(values,n=None,width=None):
    result=np.asarray(values,np.float64)
    require(result.ndim==2 and result.shape[1]>0 and np.isfinite(result).all(),'finite feature matrix')
    if n is not None:require(len(result)==n,'matched feature row counts')
    if width is not None:require(result.shape[1]==width,'declared feature width')
    return result


def _digest(values):
    array=np.ascontiguousarray(values)
    return hashlib.sha256(str(array.dtype).encode()+str(array.shape).encode()+array.tobytes()).hexdigest()


def _id_number(identifier):
    return int.from_bytes(hashlib.sha256(identifier.encode('utf-8')).digest(),'big')


def build_plan(Vids,Vgroups,Vfine):
    """One BEN held view, two KNA views, followed by FIT-only fine floor20.

    Profiles must verify these are source-V rows, not R/Qaudit/actual roles.
    For KNA fine f, its own-held f view is proxy2; a different deterministic
    held bank view is known1. Genuine dataset fine labels are never rewritten.
    """
    fine=np.asarray(Vfine);n=len(fine)
    require(fine.shape==(n,)and np.issubdtype(fine.dtype,np.integer)and np.isin(fine,np.arange(9)).all()
            and np.any(fine==0)and np.any(fine>0),'genuine source-V BEN and KNA fine0..8')
    ids,groups=_strings(Vids,n,'source-V IDs'),_strings(Vgroups,n,'source-V physical groups')
    rows,banks,labels=[],[],[]
    for i in range(n):
        value=_id_number(ids[i]);f=int(fine[i])
        if f==0:
            rows.append(i);banks.append(str(1+value%8));labels.append(0)
        else:
            other=[h for h in range(1,9)if h!=f]
            rows.extend((i,i));banks.extend((str(f),str(other[value%7])));labels.extend((2,1))
    rows=np.asarray(rows,np.int64);banks=np.asarray(banks);labels=np.asarray(labels,np.int8)
    require(len(rows)<2000,'predeclared genuine V proxy views below2000 before FIT repeats')
    sourcefine=fine[rows].astype(np.int64,copy=True)
    slots=list(range(len(rows)))
    for f in np.unique(fine):
        members=np.flatnonzero(sourcefine==f)
        # Stable physical ID/bank/label order; repeats remain traced view copies.
        members=sorted(members.tolist(),key=lambda j:(ids[rows[j]],banks[j],int(labels[j])))
        for j in range(max(0,20-len(members))):slots.append(members[j%len(members)])
    slots=np.asarray(slots,np.int64);multiplicity=np.bincount(slots,minlength=len(rows))
    require(len(slots)<=6000 and np.all(multiplicity>=1)
            and all(np.sum(sourcefine[slots]==f)>=20 for f in np.unique(fine)),
            'present source fine floor20 by FIT-only deterministic traced view repeats within6000')
    return dict(schema=PLAN_SCHEMA,V_ids=ids,V_groups=groups,V_fine=fine.astype(np.int64,copy=True),
        row_positions=rows,bank_keys=banks,pretext_labels=labels,source_fine=sourcefine,
        source_ids=ids[rows],source_groups=groups[rows],FIT_slot_view_indices=slots,
        FIT_view_multiplicity=multiplicity,FIT_slot_source_row_positions=rows[slots],
        FIT_slot_source_ids=ids[rows[slots]],FIT_slot_source_groups=groups[rows[slots]],
        FIT_slot_source_fine=sourcefine[slots],FIT_slot_pretext_labels=labels[slots],
        base_view_count=len(rows),genuine_V_parents=n,logical_FIT_rows=len(slots),FIT_copy_rows=len(slots)-len(rows),
        base_pretext_counts=np.bincount(labels,minlength=3),logical_pretext_counts=np.bincount(labels[slots],minlength=3),
        label_meanings={'0':'real source BEN under one held-bank view',
                        '1':'real source KNA under a different-held-bank view',
                        '2':'own-held source known family proxy; not dataset UNA'},
        stable_bank_policy='BEN 1+SHA256(ID)%8; KNA ownfine proxy2 plus sortedotherbank[SHA256(ID)%7] known1',
        no_fullbank_V_training_views=True,source_role_caller_enforced='source V only; no R/Qcal/Qaudit/actual role rows',
        present_fine_floor20_FIT_only=True,views_and_copies_are_not_independent_events=True,
        unchanged_dataset_fine_labels=True,source_true_UNA_used=False,
        ID_hash_is_feature=False,bank_or_fine_ID_is_feature=False)


def _softmax(logits):
    centered=logits-logits.max(axis=1,keepdims=True);out=np.exp(centered);out/=out.sum(axis=1,keepdims=True)
    require(np.isfinite(out).all(),'finite clean-head softmax')
    return out


def _group_invariants(logits,globalprob,columns):
    selected=logits[:,columns];conditional=_softmax(selected);n=len(columns)
    maximum=conditional.max(axis=1)
    if n==1:
        entropy=np.zeros(len(logits));margin=np.ones(len(logits))
    else:
        entropy=-np.sum(np.where(conditional>0,conditional*np.log(np.maximum(conditional,np.finfo(float).tiny)),0.),axis=1)/math.log(n)
        two=np.partition(conditional,n-2,axis=1)[:,-2:];margin=two.max(axis=1)-two.min(axis=1)
    return np.column_stack((maximum,entropy,margin,globalprob[:,columns].sum(axis=1)))


def feature_matrix(native,Z,tangent_score,tangent_evidence,coarse_logits,fine_logits,
                   embedding,embedding_center,Bfinecols,Kfinecols):
    """native + original Z +27 invariant geometry/clean-neural summaries.

    Native units and source-R embedding center are caller-owned frozen source
    parameters. No transform is fitted here. Clean head outputs are required;
    graph labels, proxy labels, IDs and held-bank identifiers are not accepted.
    """
    native=_matrix(native);n=len(native);z=_matrix(Z,n);coarse=_matrix(coarse_logits,n,2)
    fine=_matrix(fine_logits,n);embed=_matrix(embedding,n);center=np.asarray(embedding_center,np.float64)
    require(center.shape==(embed.shape[1],)and np.isfinite(center).all(),'frozen source-R embedding center')
    columns=[]
    for supplied in(Bfinecols,Kfinecols):
        col=np.asarray(supplied);require(col.ndim==1 and len(col)>0 and np.issubdtype(col.dtype,np.integer),'nonempty proper fine-head column group')
        columns.append(col.astype(np.int64,copy=False))
    joined=np.r_[columns[0],columns[1]]
    require(np.array_equal(np.sort(joined),np.arange(fine.shape[1])),'BEN/KNA fine-head columns are a disjoint complete partition')
    combined=_matrix(tangent_score['raw_r'],n,2)
    native_score=_matrix(tangent_score['view_scores']['native'],n,2)
    paper_score=_matrix(tangent_score['view_scores']['paper'],n,2)
    require(np.all(combined>=0)and np.all(native_score>=0)and np.all(paper_score>=0),'nonnegative local-tangent raw scores')
    classp=_matrix(tangent_evidence['class_p_values'],n,2)
    nativep=_matrix(tangent_evidence['view_class_p_values']['native'],n,2)
    paperp=_matrix(tangent_evidence['view_class_p_values']['paper'],n,2)
    require(all(np.all((value>=0)&(value<=1))for value in(classp,nativep,paperp)),'source empirical rank ranges')
    eligible=np.asarray(tangent_score['conditional_eligible'])
    require(eligible.shape==(n,)and eligible.dtype==np.dtype(bool)and eligible.all(),
            'proxy/calibration/eligible query features require available outside-R local geometry')
    coarseprob=_softmax(coarse);globalfine=_softmax(fine)
    fineinvariants=np.column_stack([_group_invariants(fine,globalfine,col)for col in columns])
    centered=embed-center
    embeddingstats=np.column_stack((np.linalg.norm(centered,axis=1),centered.mean(axis=1),centered.std(axis=1),np.abs(centered).max(axis=1)))
    extras=np.column_stack((np.log1p(combined),np.log1p(native_score),np.log1p(paper_score),
        classp,nativep,paperp,coarseprob,coarse[:,1]-coarse[:,0],fineinvariants,embeddingstats))
    require(extras.shape==(n,27)and np.isfinite(extras).all(),'exact27 ID-free invariant geometry/neural summaries')
    matrix=np.column_stack((native,z,extras));require(np.isfinite(matrix).all(),'finite nonlinear proxy feature matrix')
    extra_names=tuple('log1p_'+view+'_'+c for view in('combined_r','native_score','paper_score')for c in('B','K'))
    extra_names+=tuple(view+'_empirical_p_'+c for view in('combined','native','paper')for c in('B','K'))
    extra_names+=('clean_coarse_softmax_B','clean_coarse_softmax_K','clean_coarse_logit_K_minus_B')
    extra_names+=tuple(group+'_'+name for group in('BEN_fine_group','KNA_fine_group')for name in('conditional_max','entropy_over_logn','top2_probability_margin','full_fine_softmax_mass'))
    extra_names+=('R_centered_embedding_norm','R_centered_embedding_mean','R_centered_embedding_std','R_centered_embedding_maxabs')
    names=tuple('native_%03d'%j for j in range(native.shape[1]))+tuple('original_paperZ_%03d'%j for j in range(z.shape[1]))+extra_names
    require(len(names)==matrix.shape[1]and len(extra_names)==27,'explicit feature schema widths')
    return dict(schema=FEATURE_SCHEMA,features=matrix,feature_names=names,invariant_features=extras,
        native_width=native.shape[1],original_paper_width=z.shape[1],invariant_width=27,
        coarse_margin_direction='clean raw K logit minus B logit',fine_single_class_entropy=0.,fine_single_class_top2_margin=1.,
        class_p_values_are_membership_posteriors=False,IDs_groups_held_bank_and_fine_ID_are_features=False,
        class_argmax_is_feature=False,query_transform_fit=False)


def fit_meta(base_features,plan):
    """Fit exactly one fixed80 nonlinear HGB on materialized source-V slots."""
    require(plan['schema']==PLAN_SCHEMA,'owned source-V proxy plan')
    features=_matrix(base_features,plan['base_view_count']);slots=np.asarray(plan['FIT_slot_view_indices'])
    labels=np.asarray(plan['pretext_labels']);require(set(labels.tolist())=={0,1,2},'three source proxy targets present')
    require(plan['logical_FIT_rows']==len(slots)<=6000,'source-V proxy FIT cap')
    started=time.perf_counter();model=HistGradientBoostingClassifier(**HGB_PARAMETERS)
    with threadpool_limits(limits=CPU_THREADS):model.fit(features[slots],labels[slots],sample_weight=np.ones(len(slots)))
    require(model.classes_.tolist()==[0,1,2]and model.n_iter_==80,'actual fixed80 HGB proxy learner')
    return dict(schema=SCHEMA,model=model,view_plan=plan,feature_width=features.shape[1],
        fit_record=dict(new_proxy_HGB_fits=1,HGB_iterations=int(model.n_iter_),CPU_threads=CPU_THREADS,
            HGB_parameters=model.get_params(),fit_seconds=time.perf_counter()-started,
            materialized_source_V_FIT_rows=len(slots),genuine_source_V_parents=plan['genuine_V_parents'],
            base_views=plan['base_view_count'],FIT_copy_rows=plan['FIT_copy_rows'],sample_weight_all_ones=True,
            training_features_sha256=_digest(features[slots]),training_labels_sha256=_digest(labels[slots]),
            original_dataset_fine_unchanged=True,source_true_UNA_fit=False,
            new_NN_fits=0,new_metric_fits=0,other_HGB_fits=0),
        known_identity_never_certified_by_this_head_alone=True,query_parameter_fit=False,
        published=False,final_test_executed=False)


def candidate_score(probabilities):
    probability=_matrix(probabilities,width=3)
    require(np.all(probability>0)and np.all(probability<=1)
            and np.allclose(probability.sum(axis=1),1.,rtol=1e-12,atol=1e-12),
            'strictly positive finite HGB probabilities in fixed BEN/knownK/proxyU class order')
    log=np.log(probability);score=log[:,2]-log[:,:2].max(axis=1)
    require(np.isfinite(score).all(),'finite logproxyU minus maxlogknown score')
    return score


def score_meta(meta,features):
    """Fixed classifier readout only; caller supplies the matching bank view."""
    require(meta['schema']==SCHEMA and meta['model'].classes_.tolist()==[0,1,2],'owned fitted source proxy learner')
    matrix=_matrix(features,width=meta['feature_width'])
    with threadpool_limits(limits=CPU_THREADS):probability=meta['model'].predict_proba(matrix)
    return dict(probabilities=probability,score=candidate_score(probability),
        class_order=['BEN0','knownK1','held_source_proxy2_not_dataset_UNA'],
        new_fits=0,query_parameter_fit=False,known_identity_never_certified_by_this_head_alone=True)


def calibrate_cut(probabilities,truecoarse,genuine_groups,*,bank_key):
    """Matched-bank Qcal TRUE-known cuts; class n<100 disables the bank.

    Profiles exclude the held family from genuine Qcal and never reuse source-V
    training views as calibration. Calibration copies are forbidden. Both cuts
    are FINITE upper99, rank ceil(.99*(n+1)); global threshold is their maximum.
    """
    score=candidate_score(probabilities);n=len(score);y=np.asarray(truecoarse)
    require(y.shape==(n,)and np.issubdtype(y.dtype,np.integer)and np.isin(y,(0,1)).all(),'true-known source Qcal coarse labels')
    groups=_strings(genuine_groups,n,'source Qcal physical groups')
    require(str(bank_key)in[str(i)for i in range(1,9)]+['full'],'explicit matched held/full calibration owner')
    counts=np.bincount(y,minlength=2);cuts={}
    for c in(0,1):
        value=np.sort(score[y==c]);rank=(99*(len(value)+1)+99)//100
        if len(value)<100 or rank>len(value):
            cuts[str(c)]=dict(enabled=False,kind='INSUFFICIENT_GENUINE_CLASS_SUPPORT',value=None,rows=len(value),rank=rank)
        else:cuts[str(c)]=dict(enabled=True,kind='FINITE',value=float(value[rank-1]),rows=len(value),rank=rank)
    enabled=all(v['enabled']and v['kind']=='FINITE'for v in cuts.values())
    return dict(schema=CUT_SCHEMA,bank_key=str(bank_key),enabled=enabled,kind='FINITE'if enabled else'DISABLED_SMALL_CLASS',
        value=max(v['value']for v in cuts.values())if enabled else None,truecoarse_cuts=cuts,truecoarse_counts=counts,
        reference_groups=groups,calibration_score=score,calibration_rows=n,
        score_definition='log p(proxy2) minus max(log p(BEN0),log p(knownK1))',
        calibration_role_caller_enforced='genuine source Qcal TRUE-known excluding held fine; no V/R/Qaudit/actual roles',
        global_rule='strict score>max(truecoarse upper99 cuts) AND score>0',
        matched_bank_cut_required=True,reference_copies_used=False,source_true_UNA_calibration=False,
        empirical_known_tail_cut_is_not_true_UNA_guarantee=True)


def unknownmask(scores,cut):
    value=np.asarray(scores,np.float64);require(value.ndim==1 and np.isfinite(value).all(),'finite candidate scores')
    require(cut['schema']==CUT_SCHEMA,'owned matched-bank proxy threshold')
    if not cut['enabled']:return np.zeros(len(value),bool)
    require(cut['kind']=='FINITE'and np.isfinite(cut['value']),'enabled finite proxy threshold')
    return(value>cut['value'])&(value>0.)


def pure_toy_checks():
    ids=np.asarray(['v%d'%i for i in range(13)]);groups=np.asarray(['g%d'%i for i in range(13)])
    fine=np.asarray([0]*10+[1,2,8]);plan=build_plan(ids,groups,fine);again=build_plan(ids,groups,fine)
    require(plan['base_view_count']==16 and np.array_equal(plan['bank_keys'],again['bank_keys']),'stable oneBEN/twoKNA view plan')
    for row,f in enumerate(fine):
        use=np.flatnonzero(plan['row_positions']==row)
        if f==0:require(len(use)==1 and plan['pretext_labels'][use[0]]==0,'BEN oneheld view')
        else:
            require(len(use)==2 and plan['bank_keys'][use[0]]==str(f)and plan['pretext_labels'][use[0]]==2
                    and plan['bank_keys'][use[1]]!=str(f)and plan['pretext_labels'][use[1]]==1,'ownheldproxy and differentheldknown labels')
    require(all(np.sum(plan['FIT_slot_source_fine']==f)>=20 for f in np.unique(fine))and plan['logical_FIT_rows']<=6000,'traced FIT-only source fine floor20')
    n=3;tangent=dict(raw_r=np.ones((n,2)),view_scores={'native':np.ones((n,2))*2,'paper':np.ones((n,2))*3},conditional_eligible=np.ones(n,bool))
    evidence=dict(class_p_values=np.full((n,2),.5),view_class_p_values={'native':np.full((n,2),.2),'paper':np.full((n,2),.7)})
    logits=np.asarray([[.1,.4,.2,.7],[.3,.1,.6,.4],[.2,.8,.4,.3]])
    feature=feature_matrix(np.ones((n,4)),np.ones((n,5)),tangent,evidence,np.zeros((n,2)),logits,np.arange(9).reshape(n,3),np.zeros(3),[0],[1,2,3])
    permuted=feature_matrix(np.ones((n,4)),np.ones((n,5)),tangent,evidence,np.zeros((n,2)),logits[:,[0,3,1,2]],np.arange(9).reshape(n,3),np.zeros(3),[0],[1,2,3])
    require(feature['features'].shape==(3,36)and np.allclose(feature['features'],permuted['features'])
            and np.all(feature['invariant_features'][:,16]==0.)and np.all(feature['invariant_features'][:,17]==1.),
            'exact27 invariants, within-group fine permutation invariant and singleton convention')
    probability=np.tile([.4,.4,.2],(200,1));cut=calibrate_cut(probability,np.repeat([0,1],100),np.asarray(['q%d'%i for i in range(200)]),bank_key='full')
    require(cut['enabled']and cut['truecoarse_cuts']['0']['rank']==100,'genuine100 finiteupper99 rank')
    require(not unknownmask(np.asarray([cut['value'],0.]),cut).any()and unknownmask(np.asarray([.1]),cut)[0],
            'strict tie exclusion and positive score requirement')
    small=calibrate_cut(probability[:199],np.r_[np.zeros(100,int),np.ones(99,int)],np.asarray(['s%d'%i for i in range(199)]),bank_key='8')
    require(not small['enabled']and not unknownmask(np.asarray([100.]),small).any(),'small genuine known-class calibration disables bank without exception')
    return dict(stable_source_V_plan=True,oneBEN_twoKNAviews=True,ownheld_proxy_is_not_UNA=True,
        fine_floor20_traced_FIT_only=True,exact27_invariant_features=True,fine_group_permutation_invariant=True,
        singleton_entropy0_margin1=True,strict_finite_upper99=True,small_n99_bank_disabled=True,
        real_HGB_fits=0,real_source_reads=0,actual_role_reads=0,trained_estimator_predictions=0,
        performance_claimed=False,feature_width_formula='standardized native +original Z +27')
