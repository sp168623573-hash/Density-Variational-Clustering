"""Independent Q-Q and Q-source neighborhoods with frozen V1023 Potts energy.

Only the edge-search populations change. Fixed source relation models,
feature scales, weight bounds, priors and alpha-expansion are reused.
The parent constructor is the profile's responsibility.
"""
from pathlib import Path
import hashlib
import importlib.util
import sys
import time
import numpy as np
from scipy.spatial.distance import cdist

SCHEMA = 'V1025_SOURCE_RELATIONAL_POTTS_DECOUPLED_NEIGHBORS'
SOURCE_FIT_STATUS = 'SOURCE_PARAMETERS_COMPLETE'
ORIGINAL = dict(path='E:/Experiment/software transcition/target99_v1023_20261024/common/relational_potts_graph_v1023.py',
                sha256='083cc0b0efaa6a41773fb922d6bb9007065bfd880628a41167434a9877c3b19b')


def _load_original():
    p = Path(ORIGINAL['path'])
    if hashlib.sha256(p.read_bytes()).hexdigest() != ORIGINAL['sha256']:
        raise ValueError('original frozen relational energy bytes changed')
    spec = importlib.util.spec_from_file_location('V1025_original_relational_energy_'+ORIGINAL['sha256'], p)
    module = importlib.util.module_from_spec(spec); sys.modules[spec.name] = module; spec.loader.exec_module(module)
    return module


B = _load_original()
require = B.require


def _cross_euclidean_neighbors(query, reference, k):
    """Exact cross-population search; same physical parents were already removed."""
    k = min(k, len(reference)); result = np.empty((len(query), k), np.int64)
    if not k:
        return result
    for first in range(0, len(query), 64):
        distances = cdist(query[first:first+64], reference, metric='euclidean')
        for at, row in enumerate(distances):
            cutoff = np.partition(row, k-1)[k-1]
            eligible = np.flatnonzero(row <= cutoff)
            order = np.lexsort((eligible, row[eligible]))
            result[first+at] = eligible[order[:k]]
    return result


def _refine_paper(query, reference, shortlist, paired_metric):
    count = min(B.K_PAPER, shortlist.shape[1])
    result = np.empty((len(query), count), np.int64)
    if not count:
        return result
    for first in range(0, len(query), 128):
        chunk = shortlist[first:first+128]
        left = np.repeat(query[first:first+len(chunk)], chunk.shape[1], axis=0)
        distance = B._paired(paired_metric, left, reference[chunk.ravel()]).reshape(chunk.shape)
        for at in range(len(chunk)):
            order = np.lexsort((chunk[at], distance[at]))
            result[first+at] = chunk[at, order[:count]]
    return result


def infer_graph(N_R, Z_R, ycoarse, g_R, N_Q, Z_Q, g_Q, threeway_logits,
                parent_group_labels, edge_bundle, paired_metric):
    started = time.perf_counter()
    nr, zr, nq, zq = B._matrix(N_R), B._matrix(Z_R), B._matrix(N_Q), B._matrix(Z_Q)
    n, r = len(nq), len(nr)
    require(n > 0 and len(zq) == n and len(zr) == r and nr.shape[1] == nq.shape[1]
            and zr.shape[1] == zq.shape[1], 'matched native/paper source-query coordinates')
    gr, gq = B._strings(g_R, r, 'source groups'), B._strings(g_Q, n, 'canonical query groups')
    yc, parent = B._labels(ycoarse, r, (0, 1)), B._labels(parent_group_labels, n, (0, 1, 2))
    require(edge_bundle['schema'] == B.SCHEMA and np.array_equal(gr, edge_bundle['source_groups'])
            and np.array_equal(yc, (edge_bundle['source_fine'] > 0).astype(np.int64)),
            'unchanged fitted relation model/source roster and real boundary classes')
    logits = B._matrix(threeway_logits); require(logits.shape == (n, 3), 'continuous weak threeway logits')
    keep = ~np.isin(gr, gq); source_indices = np.flatnonzero(keep)
    source_n, source_z, source_y = nr[keep], zr[keep], yc[keep]
    m = len(source_indices)

    # Source size cannot enter either of these Q-Q search populations.
    q_native = B._exact_euclidean_neighbors(nq, nq, np.arange(n), B.K_NATIVE)
    q_shortlist = B._exact_euclidean_neighbors(zq, zq, np.arange(n), B.PAPER_EUCLIDEAN_SHORTLIST)
    q_paper = _refine_paper(zq, zq, q_shortlist, paired_metric)
    # Boundary edges have their own quota and never occupy Q-Q neighbor slots.
    s_native = _cross_euclidean_neighbors(nq, source_n, B.K_NATIVE)
    s_shortlist = _cross_euclidean_neighbors(zq, source_z, B.PAPER_EUCLIDEAN_SHORTLIST)
    s_paper = _refine_paper(zq, source_z, s_shortlist, paired_metric)
    qq, qr = set(), set()
    for i in range(n):
        for j in np.unique(np.r_[q_native[i], q_paper[i]]):
            j = int(j); require(j != i, 'query self edges excluded')
            qq.add((min(i, j), max(i, j)))
        for j in np.unique(np.r_[s_native[i], s_paper[i]]):
            qr.add((i, int(j)))
    qq, qr = np.asarray(sorted(qq), np.int64).reshape(-1, 2), np.asarray(sorted(qr), np.int64).reshape(-1, 2)

    def probability(left_n, right_n, left_z, right_z):
        if not len(left_n):
            return np.empty(0, np.float64)
        dn = np.linalg.norm(left_n-right_n, axis=1)
        dm = B._paired(paired_metric, left_z, right_z)
        value = edge_bundle['model'].predict_proba(B._features(dn, dm, edge_bundle['scales']))[:, 1]
        require(np.isfinite(value).all() and np.all((value >= 0) & (value <= 1)), 'fixed source relation probabilities')
        return value

    pq = probability(nq[qq[:, 0]], nq[qq[:, 1]], zq[qq[:, 0]], zq[qq[:, 1]])
    pr = probability(nq[qr[:, 0]], source_n[qr[:, 1]], zq[qr[:, 0]], source_z[qr[:, 1]])
    degree = np.bincount(qq.ravel(), minlength=n)
    qw = 7.*pq/np.maximum(7, np.maximum(degree[qq[:, 0]], degree[qq[:, 1]]))
    mass = np.bincount(qr[:, 0], weights=pr, minlength=n)
    rw = pr/np.maximum(1., mass[qr[:, 0]])
    source_unary = B.source_elimination(qr[:, 0], source_y[qr[:, 1]], rw, n)
    weighted_degree = np.bincount(qq[:, 0], weights=qw, minlength=n)+np.bincount(qq[:, 1], weights=qw, minlength=n)
    require(np.all(weighted_degree <= 7.+1e-12) and np.all(source_unary[:, 2] <= 1.+1e-12),
            'only numerical validation of unchanged edge-mass bounds')
    centered = logits-logits.max(axis=1, keepdims=True)
    prob = np.exp(centered); prob /= prob.sum(axis=1, keepdims=True)
    base = 1.-prob
    strength = np.where(parent == 2, B.UNKNOWN_CHANGE_PRIOR, B.KNOWN_CHANGE_PRIOR)
    prior = strength[:, None]*(np.arange(3)[None, :] != parent[:, None])
    no_parent = base+source_unary
    inference = B.alpha_expansion(no_parent+prior, qq[:, 0], qq[:, 1], qw, parent)
    labels = inference['labels']
    costs = B.local_costs(labels, no_parent, qq[:, 0], qq[:, 1], qw)
    coarse = costs[:, :2].argmin(axis=1).astype(np.int8); row = np.arange(n)
    S = costs[:, :2].min(axis=1)-costs[:, 2]
    counter = costs+np.asarray([B.UNKNOWN_CHANGE_PRIOR, B.UNKNOWN_CHANGE_PRIOR, 0.])[None, :]
    A = np.minimum(counter[row, 1-coarse], counter[:, 2])-counter[row, coarse]
    known = (labels < 2) & (labels == coarse) & (A > 0.)
    raw = (labels == 2) & (S > 0.)
    require(not np.any(known & raw), 'same disjoint positive known/unknown proposals')
    return dict(schema=SCHEMA, labels=labels.astype(np.int8), S=S, A=A, predicted_coarse=coarse,
        known_proposal=known, raw_proposal=raw, local_cost_no_parent=costs,
        local_cost_actual_prior=costs+prior, weak_probabilities=prob, base_unary=base,
        source_unary=source_unary, prior_unary=prior, QQ_left=qq[:, 0], QQ_right=qq[:, 1],
        QQ_probability=pq, QQ_weight=qw, QQ_degree=degree, QQ_weighted_degree=weighted_degree,
        QR_query=qr[:, 0], QR_source_original=source_indices[qr[:, 1]], QR_probability=pr, QR_weight=rw,
        source_anchor_indices=source_indices, excluded_source_anchor_groups=gr[~keep],
        native_QQ_neighbors=q_native, native_QS_neighbors=s_native,
        paper_QQ_euclidean_shortlist=q_shortlist, paper_QS_euclidean_shortlist=s_shortlist,
        paper_QQ_neighbors=q_paper, paper_QS_neighbors=s_paper,
        native_neighbors=np.concatenate((s_native, m+q_native), axis=1),
        paper_euclidean_shortlist=np.concatenate((s_shortlist, m+q_shortlist), axis=1),
        paper_neighbors=np.concatenate((s_paper, m+q_paper), axis=1),
        neighbor_index_convention='combined compatibility arrays: kept source first, then query; independent QQ arrays use query-local indices, QS arrays kept-source-local indices',
        QQ_QS_search_populations_decoupled=True,
        fixed_theta_query_QQ_invariant_to_source_anchor_addition=True,
        native_neighbors_exact_full_search=True, paper_neighbors_are_sparse_shortlist_approximation=True,
        source_anchor_elimination_exact=True, energy_history=inference['energy_history'],
        expansion_moves=inference['moves'], converged=inference['converged'],
        completed_sweeps=inference['completed_sweeps'], accepted_moves=inference['accepted_moves'],
        global_three_label_optimum_claimed=False, inference_seconds=time.perf_counter()-started,
        reused_energy_code=ORIGINAL, new_NN_fits=0, new_HGB_fits=0, new_metric_fits=0,
        source_only_evidence_cannot_certify_known=True, query_parameter_fit=False,
        current_truth_used=False, published=False, final_test_executed=False)
