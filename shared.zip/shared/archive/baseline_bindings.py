"""Read-only baseline audit and additive evidence delivery; never fits a model."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
from datetime import datetime, timezone, timedelta
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
INC = ROOT / 'incremental_experiments'
DATA = ROOT / 'data/external_dev/processed'
CLASSES = ('BEN', 'KNA', 'UNA')
BLOCKER = 'INDEPENDENT_FULL_TABLE1_SAME_FEATURE_FOUR_SETTING_COHORT_UNAVAILABLE'


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def descriptor(path):
    path = Path(path)
    return {'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}


def write_json(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


BASELINES = {
    'CIC1': dict(version='V142_frozen', correct=[645,247,3127], support=[651,249,3156],
        prediction=DATA/'cic1_MHFD32_multiview126_20261012_v142/current/complete_threeviewprediction_beforetruth.npz',
        truth=DATA/'cic1_MHFD32_multiview126_20261012_v142/current/postseal_complete_threeview_pair.npz'),
    'CIC2': dict(version='V1050', correct=[1454,506,817], support=[1465,519,1200],
        prediction=INC/'target99_v1050_20261024/cic2/actual_once/current-predict/current_complete_prediction_before_truth.npz',
        truth=DATA/'cic2_live_guard_owned110_current_20261011_v1/postseal_complete3184_evaluation_and_comparison.npz'),
    'NSL1': dict(version='V918_complete2864', correct=[316,335,2864], support=[319,335,2944],
        prediction=INC/'target99_v900_20261023/nsl1_masked_random_feature_runtime_v918/actual_v918_masked_ridge_fullrole/current/complete_prediction_before_any_new_labels.npz',
        truth=DATA/'nsl1_nativecell_clean149_20261011_v62/current/postseal_comparison.npz'),
    'NSL2': dict(version='V1051_user_selected', correct=[1511,581,3125], support=[1604,589,3393],
        prediction=INC/'target99_v1051_20261024/nsl2/actual_once/current-predict/current_complete_prediction_before_truth.npz',
        truth=DATA/'nsl2_fusion192_geometry_20261011_v67/current/postseal_same_original_comparison.npz'),
}


def score(setting, spec):
    with np.load(spec['prediction'], allow_pickle=False) as a, np.load(spec['truth'], allow_pickle=False) as b:
        ids = a['ids'].astype(str)
        assert len(set(ids)) == len(ids)
        assert np.array_equal(ids, b['ids'].astype(str)), setting
        prediction = a['prediction'].astype(np.int64)
        truth = b['truth'].astype(np.int64)
    assert prediction.shape == truth.shape == ids.shape
    assert set(np.unique(prediction)) <= {0,1,2} and set(np.unique(truth)) <= {0,1,2}
    matrix = np.zeros((3,3), dtype=np.int64)
    np.add.at(matrix, (prediction, truth), 1)
    correct, support = np.diag(matrix), matrix.sum(axis=0)
    assert correct.tolist() == spec['correct'], (setting, correct)
    assert support.tolist() == spec['support'], (setting, support)
    gates = {c:dict(correct=int(k), support=int(n), required_correct=(99*int(n)+99)//100,
              gap=max(0,(99*int(n)+99)//100-int(k)), passed=100*int(k)>=99*int(n))
             for c,k,n in zip(CLASSES,correct,support)}
    return dict(setting=setting,version=spec['version'],rows=len(ids),gates=gates,
                confusion_matrix=matrix.tolist(),matrix_orientation='predicted_rows_true_columns',
                prediction=descriptor(spec['prediction']),truth=descriptor(spec['truth']),
                complete_same_ID_order_verified=True,metric_splicing=False,
                observation_scope='historical_complete_DEV_recount_not_new_training',
                frozen=setting=='CIC1',status='FAIL_TARGET99',published=False,
                final_test_executed=False,strict_final_registration_gap=BLOCKER)


def export_result(result, directory):
    directory.mkdir(parents=True, exist_ok=False)
    matrix = np.array(result['confusion_matrix'])
    support, predicted, diagonal = matrix.sum(axis=0), matrix.sum(axis=1), np.diag(matrix)
    recall = diagonal / support
    precision = np.divide(diagonal, predicted, out=np.zeros(3), where=predicted!=0)
    f1 = np.divide(2*precision*recall,precision+recall,out=np.zeros(3),where=(precision+recall)!=0)
    with (directory/'experiment_B_transfer_accuracy.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['Setting','Version','Class','Correct','Support','Required99','Gap','Passed','Accuracy','Scope'])
        for i,c in enumerate(CLASSES):
            g=result['gates'][c];w.writerow([result['setting'],result['version'],c,g['correct'],g['support'],g['required_correct'],g['gap'],g['passed'],recall[i],result['observation_scope']])
    with (directory/'experiment_B_transfer_metrics.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['Setting','Version','Class','Precision','Recall','F1','Support','status','published','final_test_executed'])
        for i,c in enumerate(CLASSES):w.writerow([result['setting'],result['version'],c,precision[i],recall[i],f1[i],support[i],'FAIL_TARGET99',False,False])
    lines=[f"{result['setting']} {result['version']} - retained complete DEV baseline",'No model was fitted for this export.','Rows=prediction; columns=truth; class order BEN KNA UNA','prediction/truth BEN KNA UNA']
    lines += [c+' '+' '.join(map(str,row)) for c,row in zip(CLASSES,matrix)]
    lines += [f"{c}: {g['correct']}/{g['support']}; required={g['required_correct']}; gap={g['gap']}" for c,g in result['gates'].items()]
    lines += ['FAIL_TARGET99; published=false; final_test_executed=false',BLOCKER]
    (directory/'Matrix.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    write_json(directory/'result.json',result)
    # Verify persisted cells and matrix rather than relying on a successful write.
    with (directory/'experiment_B_transfer_accuracy.csv').open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    assert [(int(x['Correct']),int(x['Support']))for x in rows]==[(result['gates'][c]['correct'],result['gates'][c]['support'])for c in CLASSES]
    with (directory/'experiment_B_transfer_metrics.csv').open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    assert np.allclose([float(x['F1'])for x in rows],f1,rtol=0,atol=0)
    return [descriptor(directory/n)for n in ('experiment_B_transfer_metrics.csv','experiment_B_transfer_accuracy.csv','Matrix.txt','result.json')]


def protected_files():
    dirs=[INC/'target99_v1050_20261024',INC/'target99_v1051_20261024',
          INC/'target99_v900_20261023/nsl1_masked_random_feature_runtime_v918',
          DATA/'cic1_MHFD32_multiview126_20261012_v142']
    files={p for d in dirs for p in d.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    files.update(p for p in (ROOT/'paper_open_set').glob('*.py'))
    for name in ('CIC Setting1','CIC Setting2','NSL-KDD Setting1','NSL-KDD Setting2'):
        files.update(p for p in (ROOT/name).iterdir() if p.is_file() and p.suffix in {'.py','.bat','.ps1','.json'})
    return sorted(files)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--verify-preserved',action='store_true');args=parser.parse_args()
    frozen=OUT/'BASELINE_FREEZE_MANIFEST.json'
    if args.verify_preserved:
        manifest=json.loads(frozen.read_text(encoding='utf-8'))
        mismatches=[x['path']for x in manifest['protected_original_assets']if digest(x['path'])!=x['sha256']]
        receipt=dict(checked_files=len(manifest['protected_original_assets']),changed_files=mismatches,passed=not mismatches,
                     scope='listed_baselines_original_code_models_and_results_excluding_bytecode_cache')
        write_json(OUT/'ORIGINAL_PRESERVATION_VERIFICATION.json',receipt)
        assert not mismatches, mismatches
        print(json.dumps(receipt));return
    assert not frozen.exists(), 'Baseline evidence already sealed; do not overwrite.'
    results={s:score(s,v)for s,v in BASELINES.items()}
    protected=[descriptor(p)for p in protected_files()]
    exports={s:export_result(r,OUT/'retained_baselines'/s)for s,r in results.items()}
    manifest=dict(created_at=datetime.now(timezone(timedelta(hours=8))).isoformat(),CIC1_frozen=True,
                  user_requested_NSL2_V1051_overrides_old_V1061_scorecard=True,baselines=results,
                  protected_original_assets=protected,baseline_exports=exports,
                  status='FAIL_TARGET99',published=False,final_test_executed=False)
    write_json(frozen,manifest)
    print(json.dumps({'baselines':{s:{c:g['correct']for c,g in r['gates'].items()}for s,r in results.items()},'protected_files':len(protected),'exports':len(exports)*3},ensure_ascii=False))


if __name__=='__main__':
    main()
