"""Same-session SHA256 memoization, with rehash on any size/mtime change.

The cache stores hashes actually read in this session; it is not populated
from expected digests. It does not cache predictions or numerical checks.
"""
from pathlib import Path
import json,hashlib,os,time,atexit,msvcrt
H=Path(__file__).resolve().parent;CACHE=H/'VERIFIED_HASH_CACHE.json';LOCK=H/'cache.lock'
stats={'fresh_reads':0,'cache_hits':0,'fresh_bytes':0};dirty={}
def read_cache():
    return json.loads(CACHE.read_text(encoding='utf-8')) if CACHE.exists() else {}
cache=read_cache()
def descriptor(path):
    # Frozen descriptors already use absolute canonical paths. Avoid resolving
    # the same path through Windows repeatedly, but still stat every cache hit.
    raw=os.path.abspath(os.fspath(path));old=cache.get(raw)
    if old:
        st=Path(raw).stat()
        if (old['bytes'],old['mtime_ns'])==(st.st_size,st.st_mtime_ns):
            stats['cache_hits']+=1;return {k:old[k] for k in ('path','sha256','bytes')}
    p=Path(path).resolve(strict=True);key=str(p);st=p.stat();old=cache.get(key)
    if old and (old['bytes'],old['mtime_ns'])==(st.st_size,st.st_mtime_ns):
        stats['cache_hits']+=1;return {k:old[k] for k in ('path','sha256','bytes')}
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    after=p.stat();assert (st.st_size,st.st_mtime_ns)==(after.st_size,after.st_mtime_ns),'file changed during verification'
    rec=dict(path=key,sha256=h.hexdigest(),bytes=st.st_size,mtime_ns=st.st_mtime_ns);cache[key]=rec;dirty[key]=rec;stats['fresh_reads']+=1;stats['fresh_bytes']+=st.st_size
    return {k:rec[k] for k in ('path','sha256','bytes')}
def verify(ref):
    actual=descriptor(ref['path']);assert actual['sha256']==ref['sha256'] and actual['bytes']==ref.get('bytes',actual['bytes']),ref['path'];return actual
def flush():
    if not dirty:return
    with LOCK.open('a+b') as f:
        if f.tell()==0:f.write(b'0');f.flush()
        deadline=time.time()+30
        while True:
            try:f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1);break
            except OSError:
                if time.time()>deadline:raise
                time.sleep(.05)
        try:
            current=read_cache();current.update(dirty);temp=H/('cache.'+str(os.getpid())+'.tmp');temp.write_text(json.dumps(current,ensure_ascii=False),encoding='utf-8');os.replace(temp,CACHE);dirty.clear()
        finally:f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
atexit.register(flush)
