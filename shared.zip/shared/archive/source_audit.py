"""R-only representation, saved known-confidence and rejection-rule audit."""
from pathlib import Path
import sys,json,hashlib,importlib.util
import numpy as np
import torch
H=Path(__file__).resolve().parent;INC=H.parent;ROOT=INC.parent;R6=INC/'paper_mainline_20261029_r6'
def ref(p):
    p=Path(p).resolve(strict=True);return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def write(p,v):
    def conv(x):
        if isinstance(x,np.ndarray):return x.tolist()
        if isinstance(x,np.generic):return x.item()
        raise TypeError(type(x).__name__)
    with Path(p).open('x',encoding='utf8')as f:json.dump(v,f,ensure_ascii=False,indent=2,default=conv,allow_nan=False)
def fieldmap(setting):
    if setting=='NSL2':
        p=INC/'target99_v950_20261023/nsl2/NSL2_SOURCE_ONLY_OWNED_ADAPTER_MANIFEST_V950.json'
        g=read(p)['field_map']['groups'];return [dict(name=x['field'],columns=x['selected_columns'],kind='categorical'if len(x['selected_columns'])>1 else'numeric')for x in g],[ref(p)]
    p=ROOT/'data/external_dev/processed/nsl1_expanded_FIT6000_all41_20261009_v1/material/new_unique_FIT6000_all41_encoder_before_training.json'
    plan=ROOT/'tmp/nsl1_full5999_TAN_innovation_alignment_20261016_v685b/genuine5999_same_codec_source_before_new_TAN_fit.npz'
    with np.load(plan,allow_pickle=False)as z:perm=z['permutation117']
    g=[]
    for x in read(p)['original_field_groups']:
        cols=np.flatnonzero(np.isin(perm,x['selected_columns'])).tolist();assert len(cols)==len(x['selected_columns'])
        g.append(dict(name=x['field'],columns=cols,kind=x['kind']))
    return g,[ref(p),ref(plan)]
def main():
    summaries={};inputs=[]
    for setting in('NSL1','NSL2'):
        d=R6/'coarse_balance'/setting/'source';ck=torch.load(d/'mhfd_cnn_lstm.pt',map_location='cpu',weights_only=False)
        groups,refs=fieldmap(setting);inputs.extend(refs);selected=set(map(int,ck['selected_indices']))
        assert sorted(c for g in groups for c in g['columns'])==list(range(ck['feature_count']))
        coverage=[dict(g,selected_columns=sorted(selected&set(g['columns'])),complete=bool(set(g['columns'])<=selected),touched=bool(set(g['columns'])&selected))for g in groups]
        with np.load(d/'R_NN_before_DEV.npz',allow_pickle=False)as z:emb=z['Z'];p=z['fine_probability']
        centered=emb-emb.mean(0);sv=np.linalg.svd(centered,compute_uv=False);mass=sv**2/np.sum(sv**2)
        effective=float(np.exp(-np.sum(mass[mass>0]*np.log(mass[mass>0]))))
        thresholds=read(d/'candidate_cut.json');known={}
        for role in('V','Qcal','Qaudit'):
            with np.load(d/(role+'_NN_before_DEV.npz'),allow_pickle=False)as z:y=z['truth'];u=z['uncertainty'];pred=z['stage1']
            known[role]={str(c):dict(support=int(np.sum(y==c)),correct=int(np.sum((y==c)&(pred==c))),uncertainty_quantiles=np.quantile(u[y==c],[0,.5,.9,.99,1]).tolist(),raw=int(np.sum((y==c)&(u>thresholds['cut']))))for c in(0,1)}
        # Common logit shifts cannot represent absolute lack of support with softmax.
        logits=emb[:64]@ck['state']['classifier.weight'].numpy().T+ck['state']['classifier.bias'].numpy()
        soft=lambda t:np.exp(t-t.max(1,keepdims=True))/np.exp(t-t.max(1,keepdims=True)).sum(1,keepdims=True)
        invariant=float(np.max(np.abs(soft(logits)-soft(logits-100))))
        assert invariant<1e-12
        summaries[setting]=dict(field_count=len(groups),encoded_columns=ck['feature_count'],topk_encoded_columns=len(selected),
            covered_original_fields=sum(x['touched']for x in coverage),fully_preserved_original_fields=sum(x['complete']for x in coverage),
            categorical_field_coverage=[x for x in coverage if x['kind']=='categorical'],all_field_coverage=coverage,
            embedding_centered_rank=int(np.linalg.matrix_rank(centered)),embedding_effective_rank=effective,
            leading_variance_fraction=mass[:4].tolist(),complete_embedding_collapse=bool(np.max(sv)==0),
            softmax_common_shift_max_error=invariant,uncertainty_theoretical_max=8/9,cut=thresholds,
            threshold_mathematically_unreachable=thresholds['cut']>=8/9,known_confidence=known,
            full_known_softmax_not_unknown_membership_probability=True,source_current_truth_read=False)
        inputs.extend([ref(d/'mhfd_cnn_lstm.pt'),ref(d/'R_NN_before_DEV.npz'),ref(d/'candidate_cut.json')])
    history=[ROOT/'paper_open_set/nsl2_fresh_field40_mhfd_core_v136.py',ROOT/'paper_open_set/known_fine_additive_cosine_margin_head_v1.py']
    write(H/'SOURCE_FIRST_STAGE_AUDIT.json',dict(settings=summaries,inputs=inputs,historical_precedents=[ref(p)for p in history],
       findings=['R6 TopK operated on encoded columns, fragmenting categorical fields; restore whole original-field tokens and group-gradient TopK within Algorithm1.',
       'Representation is not totally constant; low effective rank alone is not proof of error. Preserve complete categorical evidence before blaming density.',
       'Softmax confidence is invariant to a common logit decrease and therefore cannot indicate that every known class is unsupported. Test unnormalized one-vs-rest outputs in the existing CNN-LSTM head.',
       'Both R6 cuts remain below the theoretical uncertainty ceiling; this is not an all-off numeric threshold bug. Do not lower the recorded cut using target errors.',
       'V136 already used whole-field tokens in a different single-attention/decoder model. This is an R6 input-semantics repair, not a claim that field tokens are novel.'],
       new_model_fits=0,current_truth_reads=0,status='FAIL_TARGET99',published=False,final_test_executed=False))
    write(H/'FIELD_MAPS.json',{s:fieldmap(s)[0]for s in('NSL1','NSL2')})
    print(json.dumps({k:{x:v[x]for x in('field_count','covered_original_fields','fully_preserved_original_fields','embedding_effective_rank','categorical_field_coverage')}for k,v in summaries.items()},ensure_ascii=False))
if __name__=='__main__':main()
