"""Source-only nested support-conditioned pretest, not a target pipeline.

ONE immutable FULL encoder/native frame and original Z are used throughout.
Only genuine R support changes. Head input is 12 compatibility features.
No graph, known return, DVC, actual role or current truth is evaluated here.
"""
from pathlib import Path
import os,sys,hashlib,importlib.util,io,time,gc
for _k,_v in {'CUDA_VISIBLE_DEVICES':'-1','TARGET99_AUX_DEVICE':'cpu','PYTORCH_NVML_BASED_CUDA_CHECK':'1'}.items():os.environ[_k]=_v
import numpy as np
import joblib
SCHEMA='V1048_SOURCE_ONLY_SINGLE_ENCODER_NESTED_SUPPORT_PRETEST'
PREFIX_STATUS='SOURCE_NESTED_PREFIX_OUTER1_COMPLETE_NOT_FULL_PRETEST'
NESTED_STATUS='SOURCE_NESTED_PRETEST_COMPLETE_NOT_DEPLOYMENT_PIPELINE'
FINAL_STATUS='FINAL_POINT_HEAD_COMPLETE_NOT_GRAPH_PIPELINE_QUALIFIED'
SUPPORT=dict(path='E:/Experiment/software transcition/target99_v1047_20261024/common/single_frame_support_geometry_v1047.py',sha256='b4a26c447e95e6b4c53eb96d4fc8ed3bb51f0573b41146c9dc16d812acabb6f6')
HEAD=dict(path='E:/Experiment/software transcition/target99_v1041_20261024/common/proxy_candidate_learner_v1041.py',sha256='9335f730e12da8054f76bf1b5d293fdaf3ae74a41642cb37d850441ac24bfea6')
SEED=20261024
def require(v,s):
    if not bool(v):raise ValueError(s)
def descriptor(p):
    p=Path(p).resolve(strict=True);return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def raw(d):
    b=Path(d['path']).read_bytes();require(hashlib.sha256(b).hexdigest()==d['sha256'],'immutable '+d['path']);return b
def module(d,tag):
    raw(d);name=tag+'_'+d['sha256']
    if name in sys.modules:return sys.modules[name]
    sp=importlib.util.spec_from_file_location(name,d['path']);m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m
def dump(path,value):
    with Path(path).open('xb')as f:joblib.dump(value,f,compress=3)
    return descriptor(path)
def load(d):return joblib.load(io.BytesIO(raw(d)))
def key(excluded):
    values=tuple(sorted(set(int(v)for v in excluded)));require(all(1<=v<=8 for v in values)and len(values)<=2,'only predeclared support exclusions');return 'none'if not values else'_'.join(map(str,values))
def exclusions(k):return()if k=='none'else tuple(map(int,k.split('_')))
def prepare_arrays(native_full_frame,Z,fine,physical_groups,source_ids,R,V,Q,A,FITslots,*,encoder_state_sha256,metric_state_sha256):
    """Generic caller-owned fixed-frame source arrays; no NN/graph dependency."""
    native=np.asarray(native_full_frame,np.float64);z=np.asarray(Z,np.float64);y=np.asarray(fine);g=np.asarray(physical_groups).astype(str);ids=np.asarray(source_ids).astype(str);n=len(native)
    require(native.ndim==z.ndim==2 and native.shape[1]>0 and z.shape[1]>0 and len(z)==len(y)==len(g)==len(ids)==n and np.isfinite(native).all()and np.isfinite(z).all(),'generic finite original source views/roles')
    require(len(np.unique(g))==len(np.unique(ids))==n and np.all(g!='')and np.all(ids!='')and y.dtype.kind in'iu'and np.isin(y,np.arange(9)).all(),'unique genuine integer knownsource fine0..8')
    require(all(np.asarray(v).dtype.kind in'iu'for v in(R,V,Q,A,FITslots)),'integer source role/FT parentindices')
    roles=[np.asarray(v,np.int64)for v in(R,V,Q,A)];sets=[set(v.tolist())for v in roles];require(all(len(v)==len(s)>0 and v.min()>=0 and v.max()<n for v,s in zip(roles,sets))and set.union(*sets)==set(range(n))and all(not sets[i]&sets[j]for i in range(4)for j in range(i)),'genuine R/V/Qcal/QA disjoint whole sourcepartition')
    R,V,Q,A=roles;slots=np.asarray(FITslots,np.int64);require(len(R)<=len(slots)<=6000 and slots.min()>=0 and slots.max()<len(R)and all(np.sum(y[R][slots]==f)>=20 for f in np.unique(y[R])),'originalFULL R FITfloor20/cap; no extra support copies')
    require(encoder_state_sha256 and metric_state_sha256,'explicit frozen FULL encoder/frame and originalmetric ownership')
    return dict(native=native,Z=z,fine=y,groups=g,ids=ids,R=R,V=V,Q=Q,A=A,FITslots=slots,encoder_state_sha256=encoder_state_sha256,metric_state_sha256=metric_state_sha256,source_native_units='caller-owned ONEFULL fixed source-native frame, shared across allsupportepisodes',NN_forward_calls=0)
def build_plan(ids,groups,fine,source_indices,outer=None):
    """Known full-support views plus stable support deletions, V-only FT trace."""
    ids=np.asarray(ids).astype(str);groups=np.asarray(groups).astype(str);fine=np.asarray(fine,np.int64);indices=np.asarray(source_indices,np.int64);require(len(ids)==len(groups)==len(fine)==len(indices)and len(np.unique(groups))==len(ids),'genuine unique sourceV cohort')
    outerset=()if outer is None else(int(outer),);keep=np.ones(len(fine),bool)if outer is None else fine!=outer;ids0,groups0,fine0,indices0=ids[keep],groups[keep],fine[keep],indices[keep];rows=[];sets=[];labels=[];episode=[]
    for i,f in enumerate(fine0):
        code=int.from_bytes(hashlib.sha256(ids0[i].encode()).digest(),'big');rows.append(i);sets.append(key(outerset));labels.append(0 if f==0 else 1);episode.append('full_support_known')
        if f==0:rows.append(i);sets.append(key((*outerset,1+code%8)));labels.append(0);episode.append('hash_held_BEN')
        else:
            other=[h for h in range(1,9)if h!=f];rows.extend((i,i));sets.extend((key((*outerset,int(f))),key((*outerset,other[code%7]))));labels.extend((2,1));episode.extend(('own_support_deleted_proxy','other_support_deleted_knownK'))
    rows=np.asarray(rows,np.int64);labels=np.asarray(labels,np.int8);sets=np.asarray(sets);episode=np.asarray(episode);viewfine=fine0[rows];slots=list(range(len(rows)))
    for f in np.unique(fine0):
        members=sorted(np.flatnonzero(viewfine==f).tolist(),key=lambda j:(ids0[rows[j]],sets[j],int(labels[j]),episode[j]))
        slots.extend(members[j%len(members)]for j in range(max(0,20-len(members))))
    slots=np.asarray(slots,np.int64);require(len(slots)<=6000 and all(np.sum(viewfine[slots]==f)>=20 for f in np.unique(fine0)),'presentVfinefloor20 by traceable FTcopies only')
    if outer is not None:require(not np.any(fine0==outer)and all(outer in exclusions(k)for k in sets),'outerfamily absent fromALL headFIT views/copies andALL supportsets')
    H=module(HEAD,'V1048_fixed_HGB_operator')
    return dict(schema=H.PLAN_SCHEMA,plan_variant=SCHEMA,outer_family=outer,V_ids=ids0,V_groups=groups0,V_fine=fine0,V_source_indices=indices0,row_positions=rows,support_keys=sets,episode_kinds=episode,pretext_labels=labels,source_fine=viewfine,source_ids=ids0[rows],source_groups=groups0[rows],source_global_indices=indices0[rows],FIT_slot_view_indices=slots,FIT_slot_source_ids=ids0[rows][slots],FIT_slot_source_groups=groups0[rows][slots],FIT_slot_source_fine=viewfine[slots],FIT_slot_pretext_labels=labels[slots],base_view_count=len(rows),genuine_V_parents=len(ids0),logical_FIT_rows=len(slots),FIT_copy_rows=len(slots)-len(rows),base_pretext_counts=np.bincount(labels,minlength=3),logical_pretext_counts=np.bincount(labels[slots],minlength=3),full_support_known_views_all_V=True,views_and_copies_are_not_independent=True,proxy2_is_not_dataset_UNA=True,raw_native_Z_embedding_head_outputs_as_features=False)
def create_frame(source,path):
    G=module(SUPPORT,'V1048_fixed_shared_geometry');R=source['R'];frame=G.fit_shared_frame(source['native'][R],source['Z'][R],source['FITslots']);return dump(path,dict(frame=frame,source_encoder_state_sha256=source['encoder_state_sha256'],metric_state_sha256=source['metric_state_sha256'],R_ids=source['ids'][R],R_groups=source['groups'][R],R_fine=source['fine'][R],R_indices=R))
def ensure_support(source,frame_ref,cache,k,directory):
    if k in cache:
        value=load(cache[k]);require(value['support_key']==k and value['shared_frame_reference']==frame_ref and value['encoder_state_sha256']==source['encoder_state_sha256']and tuple(value['excluded_fines'])==exclusions(k),'exact cachedsupportkey/sharedframe/encoder');del value;gc.collect();return cache[k]
    G=module(SUPPORT,'V1048_fixed_shared_geometry');frame=load(frame_ref);R=source['R'];require(frame['source_encoder_state_sha256']==source['encoder_state_sha256']and np.array_equal(frame['R_ids'],source['ids'][R]),'one exact sharedFULL encoder frame');ex=exclusions(k);bank=G.fit_support_bank(source['native'][R],source['Z'][R],source['fine'][R],source['groups'][R],source['ids'][R],source['FITslots'],frame['frame'],ex,seed=SEED);rows=source['Q'][~np.isin(source['fine'][source['Q']],ex)];require(len(np.unique(source['groups'][rows]))==len(rows)and not set(rows)&set(source['V'])and not set(rows)&set(source['A']),'Qcal ONLY featureCDF reference, noV/QA')
    cal=G.calibrate_support(source['native'][rows],source['Z'][rows],(source['fine'][rows]>0).astype(np.int8),source['groups'][rows],bank,ids_cal=source['ids'][rows],role='Qcal');value=dict(schema=SCHEMA,support_key=k,excluded_fines=ex,bank=bank,feature_calibration=cal,Qcal_reference_source_indices=rows,Qcal_reference_ids=source['ids'][rows],Qcal_reference_fine=source['fine'][rows],encoder_state_sha256=source['encoder_state_sha256'],metric_state_sha256=source['metric_state_sha256'],shared_frame_reference=frame_ref)
    ref=dump(Path(directory)/('support_'+k+'.joblib'),value);cache[k]=ref;del bank,cal,value,frame;gc.collect();return ref
def support_features(source,rows,support_ref,*,expected_key,frame_ref):
    """Only six log geometry scores and six Qcal-CDF ranks, one fixed basis."""
    G=module(SUPPORT,'V1048_fixed_shared_geometry');value=load(support_ref);require(value['encoder_state_sha256']==source['encoder_state_sha256']and value['support_key']==expected_key and value['shared_frame_reference']==frame_ref and tuple(value['excluded_fines'])==exclusions(expected_key),'same singleencoder/support/frame for features');require(value['feature_calibration']['role']=='Qcal'and not value['feature_calibration']['source_V_used_as_reference']and not np.isin(value['Qcal_reference_fine'],exclusions(expected_key)).any(),'Qcal-only featureCDF/supportexclusions exact')
    s=G.score_support_bank(source['native'][rows],source['Z'][rows],source['groups'][rows],value['bank']);require(s['conditional_eligible'].all(),'all sourceV/Qcal/QA outsideFULLencoderR');e=G.calibrated_evidence(s,value['feature_calibration']);features=np.column_stack((np.log1p(s['raw_r']),np.log1p(s['view_scores']['native']),np.log1p(s['view_scores']['paper']),e['class_p_values'],e['view_class_p_values']['native'],e['view_class_p_values']['paper']));require(features.shape==(len(rows),12)and np.isfinite(features).all(),'exact12supportfeatures, no raw/embedding/head/bankIDs');del value;gc.collect();return features
def fit_outer(source,frame_ref,cache,cache_directory,output_directory,outer):
    """One outer-family head, or final all-V head. No outer V value is fitted."""
    started=time.perf_counter();H=module(HEAD,'V1048_fixed_HGB_operator');V=source['V'];plan=build_plan(source['ids'][V],source['groups'][V],source['fine'][V],V,outer);base=np.zeros((plan['base_view_count'],12));support_records={}
    for k in sorted(set(plan['support_keys'].tolist())):
        ref=ensure_support(source,frame_ref,cache,k,cache_directory);positions=np.flatnonzero(plan['support_keys']==k);rows=plan['source_global_indices'][positions];unique,inverse=np.unique(rows,return_inverse=True);features=support_features(source,unique,ref,expected_key=k,frame_ref=frame_ref);base[positions]=features[inverse];support_records[k]=dict(artifact=ref,base_view_positions=positions,feature_genuine_source_indices=unique,source_physical_feature_rows=len(unique),base_views=len(positions))
    if outer is not None:require(not np.any(plan['V_fine']==outer)and not np.any(plan['FIT_slot_source_fine']==outer),'outer fine absent from allV fitting/materializedcopies')
    meta=H.fit_meta(base,plan);require(meta['model'].n_features_in_==12 and meta['model'].n_iter_==80,'one fixed80HGB only12supportfeatures')
    deploykey=key(()if outer is None else(outer,));deployref=ensure_support(source,frame_ref,cache,deploykey,cache_directory);Q=source['Q'];A=source['A'];Qf=support_features(source,Q,deployref,expected_key=deploykey,frame_ref=frame_ref);Af=support_features(source,A,deployref,expected_key=deploykey,frame_ref=frame_ref);qs=H.score_meta(meta,Qf);qa=H.score_meta(meta,Af);known=np.ones(len(Q),bool)if outer is None else source['fine'][Q]!=outer;cut=H.calibrate_cut(qs['probabilities'][known],(source['fine'][Q][known]>0).astype(np.int8),source['groups'][Q][known],bank_key='full'if outer is None else str(outer));headcert=H.unknownmask(qa['score'],cut);proxytruth=(source['fine'][A]>0).astype(np.int8)
    if outer is not None:proxytruth[source['fine'][A]==outer]=2
    prediction=np.where(headcert,2,qa['probabilities'][:,:2].argmax(1)).astype(np.int8);matrix=np.zeros((3,3),np.int64);np.add.at(matrix,(prediction,proxytruth),1)
    cohort='final_full'if outer is None else'outer_'+str(outer);result=dict(schema=SCHEMA,cohort=cohort,outer_family=outer,accepted_UNA_floor=source.get('accepted_UNA_floor'),full_encoder_state_sha256=source['encoder_state_sha256'],all_episodes_shared_frame=frame_ref,all_episodes_same_encoder=True,meta=meta,view_plan=plan,source_V_base_features=base,source_support_records=support_records,deploy_support_reference=deployref,deploy_support_key=deploykey,Qcal_meta_reference_source_indices=Q[known],Qcal_meta_reference_ids=source['ids'][Q][known],Qcal_meta_reference_fine=source['fine'][Q][known],matched_action_cut=cut,Qcal_probabilities=qs['probabilities'],Qcal_headscore=qs['score'],Qaudit_source_indices=A,Qaudit_ids=source['ids'][A],Qaudit_groups=source['groups'][A],Qaudit_fine=source['fine'][A],Qaudit_features12=Af,Qaudit_probabilities=qa['probabilities'],Qaudit_headscore=qa['score'],Qaudit_head_certificate=headcert,Qaudit_point_prediction=prediction,Qaudit_proxy_truth=proxytruth,point_confusion_prediction_rows_truth_columns=matrix,point_unknown_hits=int(np.sum(headcert&(proxytruth==2))),point_unknown_support=int(np.sum(proxytruth==2)),point_known_false_UNA_B=int(np.sum(headcert&(proxytruth==0))),point_known_false_UNA_K=int(np.sum(headcert&(proxytruth==1))),head_is_not_known_license=True,no_graph_or_return_stage=True,source_Qaudit_fit_calls=0,source_NN_forward_calls=0,source_model_fit_counts=dict(proxy_HGB=1,HGB_iterations=80),entire_outer_seconds=time.perf_counter()-started,outer_head_never_fitted_outerV=outer is not None,full_representation_saw_outer_family=True,outer_unseen_claim_only_headV_and_R_support=outer is not None,performance_is_source_proxy_only=True,published=False,final_test_executed=False)
    artifact=dump(Path(output_directory)/(cohort+'_head_and_OOF_source_outputs.joblib'),result)
    return result,artifact
def nested_audit(outer_refs):
    require(set(outer_refs)==set(map(str,range(1,9))),'all8outerheads assessed once');false={0:set(),1:set()};parents={0:set(),1:set()};signal=set();per=[]
    for f in range(1,9):
        r=load(outer_refs[str(f)]);require(r['outer_family']==f and r['source_Qaudit_fit_calls']==0 and r['source_NN_forward_calls']==0,'exact nested outer head protocol');known=r['Qaudit_fine']!=f;cert=r['Qaudit_head_certificate'];groups=r['Qaudit_groups'];fine=r['Qaudit_fine']
        for c in(0,1):
            use=known&((fine>0)==bool(c));parents[c].update(groups[use]);false[c].update(groups[use&cert])
        own=fine==f;signal.update(groups[own&cert]);per.append(dict(outer=f,artifact=outer_refs[str(f)],matched_cut_enabled=r['matched_action_cut']['enabled'],matched_cut_kind=r['matched_action_cut']['kind'],matched_truecoarse_counts=r['matched_action_cut']['truecoarse_counts'],proxy_unknown_correct=int(np.sum(own&cert)),proxy_unknown_support=int(own.sum()),known_false_UNA_B=r['point_known_false_UNA_B'],known_false_UNA_K=r['point_known_false_UNA_K'],source_V_genuine_parents=r['view_plan']['genuine_V_parents'],base_views=r['view_plan']['base_view_count'],materialized_FIT_rows=r['view_plan']['logical_FIT_rows'],source_V_outer_family_count=int(np.sum(r['view_plan']['V_fine']==f)),source_proxy_confusion=r['point_confusion_prediction_rows_truth_columns']))
    risk={name:dict(unique_trueknown_parents=len(parents[c]),wrong_headcert_unique_parents=len(false[c]),false_budget=len(parents[c])//100,budget_passed=bool(parents[c])and len(false[c])<=len(parents[c])//100,worst_parent_across_outer_views=True,conservative_point_raw_upper_bound_not_final_DVC_action=True)for name,c in(('BEN',0),('KNA',1))};signalpass=len(signal)>=20;pointpass=all(v['budget_passed']for v in risk.values());decision='POINT_PRETEST_PASS'if signalpass and pointpass else'POINT_RISK_NEEDS_PIPELINE_REVIEW'if signalpass else'INSUFFICIENT_NESTED_UNKNOWN_SIGNAL_STOP'
    return dict(schema=SCHEMA,nested_pretest_passed=signalpass and pointpass,nested_generalization_signal_passed=signalpass,point_raw_upper_budget_passed=pointpass,nested_decision=decision,known_point_false_UNA_risk=risk,outer_unknown_headcert_unique=len(signal),unknown_signal20_passed=signalpass,per_outer=per,small_action_calibration_disabled_without_waiver=True,source_proxy_unknown_not_real_UNA=True,outer_headV_family_and_R_support_unseen=True,full_encoder_and_frame_not_unseen=True,graph_known_return_not_assessed=True,actual_known_current_roles_not_assessed=True,point_risk_failure_does_not_prove_full_pipeline_impossible=True,later_original_density_may_reduce_false_but_not_evaluated=True,independent_final_guarantee=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
def final_point_audit(result):
    require(result['outer_family']is None,'finalallV pointhead');fine=result['Qaudit_fine'];cert=result['Qaudit_head_certificate'];risk={}
    for name,c in(('BEN',0),('KNA',1)):
        use=(fine>0)==bool(c);n=int(use.sum());wrong=int(np.sum(use&cert));risk[name]=dict(correct_known_not_overridden=n-wrong,support=n,false_headcert=wrong,false_budget=n//100,budget_passed=wrong<=n//100)
    passed=all(v['budget_passed']for v in risk.values())and result['matched_action_cut']['enabled']
    return dict(final_point_pretest_passed=passed,final_point_decision='POINT_PRETEST_PASS'if passed else'POINT_RISK_NEEDS_PIPELINE_REVIEW',conservative_raw_point_upper_bound_only=True,full_density_pipeline_not_evaluated_or_rejected=True,known_point_risk=risk,matched_cut_enabled=result['matched_action_cut']['enabled'],actual_role_pipeline_or_graph_qualification=False,no_known_return_certificate_assessed=True,no_UNA_tradeoff_current_acceptance_floor=result.get('accepted_UNA_floor'),published=False,final_test_executed=False,status='FAIL_TARGET99')
