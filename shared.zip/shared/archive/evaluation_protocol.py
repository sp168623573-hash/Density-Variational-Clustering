"""Shared R950 protocol and reporting helpers; no model or label-store access.

The caller supplies a sealed, whole prediction and separately authorized truth.
These helpers cannot admit a source or issue final-test/publication authority.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
from typing import Any, Sequence

import numpy as np

CLASSES = ("BEN", "KNA", "UNA")
FIT_CAP = 6000
FAMILY_FLOOR = 20
SCHEMA = "target99-common-v950-1"
SCOPE_SOURCE = Path("F:/shenpeng/Experiments/Chinese Science/paper_open_set/paper_scope.py")
STRICT_FINAL_GAP = "INDEPENDENT_FULL_TABLE1_SAME_FEATURE_FOUR_SETTING_COHORT_UNAVAILABLE"


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _integer(value: Any, name: str) -> int:
    _require(isinstance(value, (int, np.integer)) and not isinstance(value, (bool, np.bool_)),
             name + " must be an integer, not a rounded value or boolean")
    return int(value)


def _ids(values: Sequence[str], name: str) -> np.ndarray:
    x = np.asarray(values)
    _require(x.ndim == 1 and x.dtype.kind in "US" and len(x) > 0,
             name + " requires a nonempty one-dimensional string inventory")
    x = x.astype(str)
    _require(all(x.tolist()) and len(set(x.tolist())) == len(x), name + " must be unique and nonempty")
    return x


def _aligned(reference: np.ndarray, values: Sequence[str], name: str) -> np.ndarray:
    x = _ids(values, name)
    _require(np.array_equal(reference, x), name + " differs from the complete sealed ID order")
    return x


def _labels(values: Sequence[int], count: int, name: str) -> np.ndarray:
    x = np.asarray(values)
    _require(x.ndim == 1 and len(x) == count and x.dtype.kind in "iu" and x.dtype.kind != "b",
             name + " must contain one integer code per complete ID")
    _require(np.all((x >= 0) & (x <= 2)), name + " must use BEN=0, KNA=1, UNA=2")
    return x.astype(np.int64, copy=False)


def integer99_gate(correct: int, support: int) -> dict[str, Any]:
    correct, support = _integer(correct, "correct"), _integer(support, "support")
    _require(0 <= correct <= support, "correct/support counts are inconsistent")
    if support == 0:
        return dict(correct=correct, support=0, required_correct=None, gap=None,
                    passed=None, gate_status="UNASSESSABLE_NO_SUPPORT", accuracy=None)
    required = (99 * support + 99) // 100
    return dict(correct=correct, support=support, required_correct=required,
                gap=max(0, required - correct), passed=correct >= required,
                gate_status="PASS" if correct >= required else "FAIL",
                accuracy=correct / support)


def canonical_roster(setting: str, scope_source: str | Path = SCOPE_SOURCE) -> dict[str, Any]:
    """Read the versioned adopted Table 1 expansion, without claiming coverage."""
    p = Path(scope_source)
    spec = importlib.util.spec_from_file_location("target99_v950_paper_scope", p)
    _require(spec is not None and spec.loader is not None, "paper_scope loader unavailable")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    missing = m.check_paper_scope(setting=setting, known_families=(), unknown_families=())
    roster = missing["missing_paper_families_by_role"]
    known, unknown = tuple(roster["known"]), tuple(roster["unknown"])
    _require(not set(known) & set(unknown), "canonical known/unknown roster overlaps")
    return dict(schema=SCHEMA, setting=setting, BEN=["BEN"], KNA=list(known), UNA=list(unknown),
                paper_scope_version=m.PAPER_SCOPE_VERSION,
                scope_source=dict(path=str(p), sha256=hashlib.sha256(p.read_bytes()).hexdigest()),
                roster_interpretation="versioned_local_expansion_of_manuscript_categories",
                ordering="lexicographic_family_names_not_model_fine_class_indices",
                cohort_family_coverage_verified=False, physical_event_independence_verified=False,
                source_admission_issued=False, final_execution_authorized=False)


def validate_fit_material(*, setting: str, original_ids: Sequence[str],
                          original_families: Sequence[str], training_parent_indices: Sequence[int]) -> dict[str, Any]:
    ids = _ids(original_ids, "original FIT IDs")
    fam = np.asarray(original_families)
    _require(fam.ndim == 1 and fam.dtype.kind in "US" and len(fam) == len(ids), "FIT family alignment required")
    allowed = {"BEN", *canonical_roster(setting)["KNA"]}
    _require(set(fam.tolist()) == allowed, "FIT must cover exactly BEN and every canonical known family; UNA forbidden")
    ix = np.asarray(training_parent_indices)
    _require(ix.ndim == 1 and ix.dtype.kind in "iu" and len(ix) <= FIT_CAP,
             "FIT optimizer material must contain at most 6000 integer parent indices")
    _require(len(ix) >= len(ids) and np.all((ix >= 0) & (ix < len(ids))), "FIT copies must refer to admitted FIT parents")
    _require(np.array_equal(ix[:len(ids)], np.arange(len(ids))), "retain each original FIT row once before optional copies")
    original_counts, effective_counts = Counter(fam.tolist()), Counter(fam[ix].tolist())
    _require(all(effective_counts[f] >= FAMILY_FLOOR for f in allowed), "each effective known FIT family needs at least 20 rows")
    copy_indices, seen = [], Counter()
    for parent in ix.tolist():
        copy_indices.append(seen[parent])
        seen[parent] += 1
    parent_ids = ids[ix].tolist()
    return dict(schema=SCHEMA, setting=setting, role="FIT", original_rows=len(ids),
                optimizer_rows=len(ix), copy_rows=len(ix) - len(ids),
                family_counts={f: dict(original=original_counts[f], effective=effective_counts[f]) for f in sorted(allowed)},
                parent_indices=ix.tolist(), parent_ids=parent_ids, copy_index=copy_indices,
                parent_sequence_sha256=hashlib.sha256("\n".join(parent_ids).encode("utf-8")).hexdigest(),
                copies_enter_DEV_or_final=False, copies_count_as_independent_events=False,
                source_admission_issued=False, training_executed=False)


def validate_evaluation_originals(*, ids: Sequence[str], role: str,
                                 origin_ids: Sequence[str] | None = None,
                                 resampling_parent_indices: Sequence[int] | None = None) -> dict[str, Any]:
    """No 6000 evaluation cap; uniqueness alone does not prove independent events."""
    _require(role in ("control", "DEV", "final"), "explicit evaluation role required")
    ids = _ids(ids, role + " IDs")
    if resampling_parent_indices is not None:
        ix = np.asarray(resampling_parent_indices)
        _require(ix.ndim == 1 and ix.dtype.kind in "iu" and np.array_equal(ix, np.arange(len(ids))),
                 "evaluation copies or reordered resampling parents are forbidden")
    if origin_ids is not None:
        origins = _ids(origin_ids, role + " origin IDs")
        _require(len(origins) == len(ids), "original event/source inventory must align with evaluation rows")
    return dict(role=role, rows=len(ids), evaluation_row_cap=None,
                resampling_permitted=False, reporting_aliases_count_as_independent=False,
                original_id_uniqueness_checked=True, origin_id_uniqueness_checked=origin_ids is not None,
                physical_event_independence_verified=False, final_execution_authorized=False)


def resource_accounting(*, gradient_seconds: float, necessary_parameter_seconds: float,
                        inference_seconds: float, io_seconds: float,
                        declared_training_budget_seconds: float | None = None) -> dict[str, Any]:
    """Record completed timings; this does not stop a process or set a deadline."""
    v = [gradient_seconds, necessary_parameter_seconds, inference_seconds, io_seconds]
    _require(all(isinstance(x, (int, float)) and not isinstance(x, bool) and np.isfinite(x) and x >= 0 for x in v),
             "finite nonnegative measured timing categories required")
    total = float(gradient_seconds + necessary_parameter_seconds)
    if declared_training_budget_seconds is not None:
        _require(np.isfinite(declared_training_budget_seconds) and declared_training_budget_seconds > 0,
                 "positive caller-declared training budget required")
    return dict(gradient_seconds=float(gradient_seconds), necessary_parameter_seconds=float(necessary_parameter_seconds),
                complete_training_parameter_seconds=total, inference_seconds=float(inference_seconds),
                io_seconds=float(io_seconds), declared_training_budget_seconds=declared_training_budget_seconds,
                within_declared_training_budget=None if declared_training_budget_seconds is None else total < declared_training_budget_seconds,
                process_timeout_coded=False, source_or_parameter_operations_must_not_be_reclassified_as_inference=True)


def evaluate_complete(*, expected_ids: Sequence[str], prediction_ids: Sequence[str],
                      prediction: Sequence[int], phase: str, setting: str, version: str,
                      parent_version: str, truth_ids: Sequence[str] | None = None,
                      truth: Sequence[int] | None = None, parent_ids: Sequence[str] | None = None,
                      parent_prediction: Sequence[int] | None = None,
                      origin_ids: Sequence[str] | None = None, control_name: str | None = None) -> dict[str, Any]:
    _require(phase in ("control", "current", "final"), "phase must be control, current, or final")
    _require(all(isinstance(s, str) and s for s in (setting, version, parent_version)), "setting/version/complete parent version required")
    _require(phase != "control" or bool(control_name), "control phase requires its exact control name")
    ids = _ids(expected_ids, "expected sealed IDs")
    _aligned(ids, prediction_ids, "prediction IDs")
    pred = _labels(prediction, len(ids), "prediction")
    inventory = validate_evaluation_originals(ids=ids, role="DEV" if phase == "current" else phase, origin_ids=origin_ids)
    _require((truth_ids is None) == (truth is None), "truth and truth IDs must be supplied together")
    _require((parent_ids is None) == (parent_prediction is None), "parent vector and parent IDs must be supplied together")
    parent = None
    if parent_prediction is not None:
        _aligned(ids, parent_ids, "parent IDs")
        parent = _labels(parent_prediction, len(ids), "parent prediction")
    result = dict(schema=SCHEMA, setting=setting, version=version, parent_version=parent_version,
                  phase=phase, evaluation_scope="development" if phase != "final" else "final_unexecuted",
                  control_name=control_name, control=phase == "control", current=phase == "current", final=phase == "final",
                  row_count=len(ids), inventory=inventory, prediction_complete=True,
                  id_order_sha256=hashlib.sha256("\n".join(ids.tolist()).encode("utf-8")).hexdigest(),
                  matrix_orientation="predicted_rows_true_columns", class_order=list(CLASSES),
                  required_gate_classes=list(CLASSES[:2] if phase == "control" else CLASSES),
                  target99_status="FAIL_TARGET99", published=False, final_test_executed=False,
                  strict_final_registration_gap=STRICT_FINAL_GAP, final_execution_authorized=False,
                  all_required_integer99_passed=None, scored=False, gates=None, confusion_matrix=None,
                  accuracy=None, weighted_precision=None, weighted_recall=None, weighted_f1=None, BEN_FPR=None,
                  EffectDelta=dict(direction="UNSCORED", per_class=None, paired_vector_compared=parent is not None))
    if truth is None:
        return result
    _require(phase != "final", "STRICT_FINAL_LOADER_NOT_REGISTERED: common helper cannot authorize final truth access")
    _aligned(ids, truth_ids, "truth IDs")
    y = _labels(truth, len(ids), "truth")
    _require(phase != "control" or np.all(y < 2), "control truth must contain only BEN/KNA")
    matrix = np.zeros((3, 3), dtype=np.int64)
    np.add.at(matrix, (pred, y), 1)
    supports, predicted = matrix.sum(axis=0), matrix.sum(axis=1)
    correct = np.diag(matrix)
    gates = {name: integer99_gate(int(correct[j]), int(supports[j])) for j, name in enumerate(CLASSES)}
    required_classes = result["required_gate_classes"]
    required_pass = all(gates[c]["passed"] is True for c in required_classes)
    precision = np.divide(correct, predicted, out=np.zeros(3, dtype=float), where=predicted > 0)
    recall = np.divide(correct, supports, out=np.zeros(3, dtype=float), where=supports > 0)
    f1 = np.divide(2 * correct, predicted + supports, out=np.zeros(3, dtype=float), where=predicted + supports > 0)
    result.update(scored=True, gates=gates, confusion_matrix=matrix.tolist(),
                  accuracy=int(correct.sum()) / len(ids),
                  weighted_precision=float(np.dot(precision, supports) / len(ids)),
                  weighted_recall=float(np.dot(recall, supports) / len(ids)),
                  weighted_f1=float(np.dot(f1, supports) / len(ids)),
                  BEN_FPR=None if supports[0] == 0 else int(supports[0] - correct[0]) / int(supports[0]),
                  all_required_integer99_passed=required_pass)
    if parent is None:
        result["EffectDelta"] = dict(direction="NOT_COMPARABLE", per_class=None, paired_vector_compared=False)
    else:
        deltas = {}
        for j, name in enumerate(CLASSES):
            mask = y == j
            gains = int(np.sum(mask & (parent != j) & (pred == j)))
            losses = int(np.sum(mask & (parent == j) & (pred != j)))
            parent_gate = integer99_gate(int(np.sum(mask & (parent == j))), int(mask.sum()))
            deltas[name] = dict(correct_delta=gains - losses, gained_correct=gains, lost_correct=losses,
                                parent_correct=parent_gate["correct"], parent_passed=parent_gate["passed"],
                                passed_class_regressed=parent_gate["passed"] is True and gates[name]["passed"] is False)
        d = [x["correct_delta"] for x in deltas.values()]
        direction = "MIXED" if min(d) < 0 < max(d) else "UP" if max(d) > 0 else "DOWN" if min(d) < 0 else "UNCHANGED"
        result["EffectDelta"] = dict(direction=direction, per_class=deltas, paired_vector_compared=True,
                                     changed_predictions=int(np.sum(pred != parent)),
                                     parent_version=parent_version, whole_vector_only=True)
    return result


def _write_new_json(path: Path, value: Any) -> None:
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def prepare_three_results(report: dict[str, Any], output_directory: str | Path) -> Path:
    """Prepare Matrix.txt plus typed specs for two Artifact-authored CSVs.

    No CSV is authored here. Run author_csv_v950.mjs once for the completed
    batch, after its single spreadsheet operation marker. Existing files fail.
    """
    _require(report.get("schema") == SCHEMA, "a common R950 evaluation report is required")
    out = Path(output_directory)
    out.mkdir(parents=True, exist_ok=True)
    paths = [out / n for n in ("Matrix.txt", "result.json", "tables.json", "experiment_B_transfer_metrics.csv", "experiment_B_transfer_accuracy.csv")]
    _require(not any(p.exists() for p in paths), "fresh result directory required; retained files must not be overwritten")
    g = report["gates"] or {c: dict(correct=None, support=None, required_correct=None, gap=None, passed=None, accuracy=None) for c in CLASSES}
    meta = [report["setting"], report["evaluation_scope"], report["version"], report["parent_version"], report["EffectDelta"]["direction"], report["target99_status"], False, False,
            report["phase"], report["control_name"], report["control"], report["current"], report["final"], report["all_required_integer99_passed"]]
    meta_head = ["Setting", "Phase", "Result_Version", "Parent_Version", "EffectDelta", "Status", "Published", "Final_Test_Executed", "Evaluation_Phase", "Control_Name", "Control", "Current", "Final", "All_Required_Integer99_Passed"]
    metrics = [["Experiment", "Model", "Accuracy", "Precision", "Recall", "F1", "FPR", "Unknown_Detected", "Unknown_Total", "Unknown_Rate", *meta_head],
               ["B-Transfer", "OursModel", report["accuracy"], report["weighted_precision"], report["weighted_recall"], report["weighted_f1"], report["BEN_FPR"], g["UNA"]["correct"], g["UNA"]["support"], g["UNA"]["accuracy"], *meta]]
    accuracy = [["Record", "Phase", "Accuracy", "BEN_Accuracy", "KNA_Accuracy", "UNA_Accuracy", "Correct", "Total", "BEN_Correct", "BEN_Total", "KNA_Correct", "KNA_Total", "UNA_Correct", "UNA_Total", "Record_Type", "Parent_Version", "EffectDelta", "Status", "Published", "Final_Test_Executed", "Evaluation_Phase", "Control_Name", "Control", "Current", "Final", "All_Required_Integer99_Passed"],
                [report["version"], report["evaluation_scope"], report["accuracy"], *(g[c]["accuracy"] for c in CLASSES),
                 sum(g[c]["correct"] for c in CLASSES) if report["scored"] else None, report["row_count"] if report["scored"] else None,
                 *(g[c][key] for c in CLASSES for key in ("correct", "support")),
                 "single_complete_prediction_snapshot_not_epoch_curve" if report["scored"] else "UNSCORED_complete_prediction_no_truth_open",
                 report["parent_version"], report["EffectDelta"]["direction"], report["target99_status"], False, False,
                 report["phase"], report["control_name"], report["control"], report["current"], report["final"], report["all_required_integer99_passed"]]]
    text = ["B-Transfer 开发实验结果", report["version"], "parent=" + report["parent_version"],
            "phase=" + report["phase"] + "; EffectDelta=" + report["EffectDelta"]["direction"],
            "status=FAIL_TARGET99; published=false; final_test_executed=false", "行=预测，列=真实", "预测\\真实 BEN KNA UNA"]
    if report["scored"]:
        text.extend(name + " " + " ".join(map(str, row)) for name, row in zip(CLASSES, report["confusion_matrix"]))
        text.append("精确99%整数门：")
        for c in CLASSES:
            x = g[c]
            text.append(f"{c}: {x['correct']}/{x['support']}; required={x['required_correct']}; gap={x['gap']}; passed={x['passed']}; gate_status={x['gate_status']}")
    else:
        text.append("UNSCORED：未打开本轮真值，数量矩阵与指标留空。")
    text.extend(["当前原始队列逐族完整性未由三类总分证明。", "strict_final_registration_gap=" + STRICT_FINAL_GAP])
    with (out / "Matrix.txt").open("x", encoding="utf-8") as handle:
        handle.write("\n".join(text) + "\n")
    _write_new_json(out / "result.json", report)
    tables = dict(schema=SCHEMA, result_json=str(out / "result.json"), tables=[
        dict(kind="metrics", path=str(out / "experiment_B_transfer_metrics.csv"), matrix=metrics),
        dict(kind="accuracy", path=str(out / "experiment_B_transfer_accuracy.csv"), matrix=accuracy)])
    _write_new_json(out / "tables.json", tables)
    return out / "tables.json"
