"""Disjoint P reference / V head fit / Q action calibration for V1051.

The learned source support geometry is unchanged. The intervention is source
role separation, not a new density score, threshold grid, or target-label rule.
"""
from pathlib import Path
import os
for k,v in dict(CUDA_VISIBLE_DEVICES='-1',TARGET99_AUX_DEVICE='cpu',OMP_NUM_THREADS='2',
                MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2').items():os.environ[k]=v
import hashlib,importlib.util,json,sys,time,gc,copy
import numpy as np
import joblib
from threadpoolctl import threadpool_limits
HERE=Path(__file__).resolve().parent;INC=HERE.parent
SCHEMA='NSL2_R4_P_REFERENCE_V_FIT_Q_ACTION_DISJOINT'
STATUS=dict(status='FAIL_TARGET99',published=False,final_test_executed=False)

def desc(p):
    p=Path(p).resolve(strict=True);data=p.read_bytes()
    return dict(path=str(p),sha256=hashlib.sha256(data).hexdigest())
def default(v):
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    raise TypeError(type(v).__name__)
def put(p,x):
    with Path(p).open('x',encoding='utf8') as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False,default=default)
    return desc(p)
def js(p):return json.loads(Path(p).read_text(encoding='utf8'))
def dump(p,x):
    with Path(p).open('xb') as f:joblib.dump(x,f,compress=3)
    return desc(p)
def load(ref):
    assert desc(ref['path'])['sha256']==ref['sha256'];return joblib.load(ref['path'])
def mod(p,name):
    s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m

D=mod(INC/'target99_v1048_20261024/core/nsl2_single_encoder_nested_v1048.py','r4_fixed_driver')
G=D.module(D.SUPPORT,'r4_support');H=D.module(D.HEAD,'r4_fixed_hgb')
G.T.CPU_THREADS=H.CPU_THREADS=2

def split_reference(fine,groups,V):
    p=[];v=[]
    for f in np.unique(fine[V]):
        rows=np.asarray(V)[fine[V]==f]
        rows=sorted(rows.tolist(),key=lambda i:(hashlib.sha256(str(groups[i]).encode()).hexdigest(),str(groups[i])))
        n=len(rows)//4 if len(rows)>=4 else 0
        p.extend(rows[:n]);v.extend(rows[n:])
    p=np.asarray(sorted(p),int);v=np.asarray(sorted(v),int)
    assert set(p).isdisjoint(v) and set(p)|set(v)==set(V)
    assert set(fine[v])==set(fine[V]) and set((fine[p]>0).tolist())=={False,True}
    return p,v

def calibrate_P(native,z,fine,groups,ids,bank,rows):
    scores=G.score_support_bank(native[rows],z[rows],groups[rows],bank)
    assert scores['conditional_eligible'].all()
    y=(fine[rows]>0).astype(np.int8);combined=G.T.calibrate_refs(scores['bounded_nonconformity'],y,groups[rows])
    views={k:G.T.calibrate_refs(scores['view_bounded_nonconformity'][k],y,groups[rows])for k in ('native','paper')}
    return dict(schema=G.T.CALIBRATION_SCHEMA,protocol=SCHEMA,combined_calibration=combined,
        view_calibrations=views,true_class_counts=np.bincount(y,minlength=2),
        genuine_reference_ids=ids[rows],genuine_reference_groups=groups[rows],true_coarse=y,
        reference_raw_r=scores['raw_r'],reference_bounded_nonconformity=scores['bounded_nonconformity'],
        reference_view_scores=scores['view_scores'],reference_view_bounded_nonconformity=scores['view_bounded_nonconformity'],
        source_R_ids_sha256=G.T._digest(bank['source_R_ids']),source_R_groups_sha256=G.T._digest(bank['source_R_groups']),
        shared_frame_sha256=bank['shared_frame_sha256'],role='P_FEATURE_REFERENCE_ONLY',
        source_Vfit_used_as_reference=False,source_Qcal_used_as_reference=False,source_QA_used_as_reference=False,
        reference_copies=False,excluded_fines_caller_enforced=bank['excluded_fines'].copy(),
        reference_small_n_only_features_not_99_action_guarantee=True,empirical_p_values_are_membership_posteriors=False)

def features(source,rows,support):
    sc=G.score_support_bank(source['native'][rows],source['Z'][rows],source['groups'][rows],support['bank'])
    ev=G.calibrated_evidence(sc,support['feature_calibration'])
    assert sc['conditional_eligible'].all()
    return np.column_stack((np.log1p(sc['raw_r']),np.log1p(sc['view_scores']['native']),
        np.log1p(sc['view_scores']['paper']),ev['class_p_values'],
        ev['view_class_p_values']['native'],ev['view_class_p_values']['paper']))

def train_heads(source,out):
    start=time.perf_counter();orig=js(INC/'target99_v1048_20261024/nsl2/SOURCE_ONLY_FINAL_HEAD_SUMMARY_V1048.json')
    original_final=js(orig['final_report']['path']);cache=js(original_final['files']['support_index']['path'])
    frame_ref=original_final['files']['shared_frame'];originalV=source['V'].copy()
    P,V=split_reference(source['fine'],source['groups'],originalV)
    roles={'R':source['R'],'P':P,'Vfit':V,'Qcal':source['Q'],'QA':source['A']}
    assert set.union(*(set(v) for v in roles.values()))==set(range(len(source['fine'])))
    assert all(set(a).isdisjoint(b) for i,a in enumerate(roles.values())for b in list(roles.values())[i+1:])
    for a in roles.values():assert len(np.unique(source['groups'][a]))==len(a)
    intersections={}
    for left,a in roles.items():
        for right,b in roles.items():
            intersections[left+'__'+right]=dict(sample_ids=len(set(source['ids'][a])&set(source['ids'][b])),
                physical_groups=len(set(source['groups'][a])&set(source['groups'][b])))
            if left!=right:assert intersections[left+'__'+right]==dict(sample_ids=0,physical_groups=0)
    partition=dict(rule='within fine SHA256(group) ascending, floor(n/4) if n>=4 to P; others Vfit',
        source_rows=len(source['fine']),roles={k:dict(rows=len(v),indices=v,ids=source['ids'][v],groups=source['groups'][v],
        fine_counts=np.bincount(source['fine'][v],minlength=9))for k,v in roles.items()},all_disjoint=True,
        intersection_table=intersections,old_V_only_split=True,Qcal_rows=len(source['Q']),QA_rows=len(source['A']),
        source_encoder_metric_geometries_historical_R_scope_unchanged=True,
        six_CDF_references='P true coarse only; rare fine not separately estimated, never borrowed Q',**STATUS)
    put(out/'SOURCE_ROLE_PARTITION.json',partition)
    src=dict(source,V=V);suprefs={};featurecache={};heads={};headrefs={};counts=[]
    def owned_support(key):
        if key not in suprefs:
            old=load(cache[key]);exclude=D.exclusions(key)
            rows=P[~np.isin(src['fine'][P],exclude)]
            assert len(rows)>0 and set((src['fine'][rows]>0).tolist())=={False,True}
            cal=calibrate_P(src['native'],src['Z'],src['fine'],src['groups'],src['ids'],old['bank'],rows)
            new=dict(old,feature_calibration=cal,P_reference_source_indices=rows,
                original_geometry_asset=cache[key],calibration_protocol=SCHEMA)
            new.pop('Qcal_reference_source_indices',None);new.pop('Qcal_reference_ids',None);new.pop('Qcal_reference_fine',None)
            suprefs[key]=dump(out/('support_P_'+key+'.joblib'),new)
        return load(suprefs[key])
    with threadpool_limits(limits=2):
        for outer in list(range(1,9))+[None]:
            tick=time.perf_counter();key='full' if outer is None else str(outer)
            plan=D.build_plan(src['ids'][V],src['groups'][V],src['fine'][V],V,outer)
            assert set(plan['source_global_indices']).issubset(set(V))
            assert not set(plan['source_global_indices'])&set(P)
            base=np.empty((plan['base_view_count'],12));support_records={}
            for skey in sorted(set(plan['support_keys'].tolist())):
                support=owned_support(skey)
                positions=np.flatnonzero(plan['support_keys']==skey)
                rows,inv=np.unique(plan['source_global_indices'][positions],return_inverse=True)
                fkey=(skey,tuple(rows))
                if fkey not in featurecache:featurecache[fkey]=features(src,rows,support)
                base[positions]=featurecache[fkey][inv]
                support_records[skey]=suprefs[skey]
            meta=H.fit_meta(base,plan)
            deploy=D.key(()if outer is None else (outer,));support=owned_support(deploy)
            Q,A=src['Q'],src['A'];Qf=features(src,Q,support);Af=features(src,A,support)
            qs=H.score_meta(meta,Qf);qa=H.score_meta(meta,Af)
            known=np.ones(len(Q),bool)if outer is None else src['fine'][Q]!=outer
            cut=H.calibrate_cut(qs['probabilities'][known],(src['fine'][Q][known]>0).astype(np.int8),src['groups'][Q][known],bank_key=key)
            qaU=H.unknownmask(qa['score'],cut);proxy=(src['fine'][A]>0).astype(np.int8)
            if outer is not None:proxy[src['fine'][A]==outer]=2
            record=dict(schema=SCHEMA,outer_family=outer,meta=meta,view_plan=plan,source_V_base_features=base,
                source_support_records=support_records,deploy_support_reference=suprefs[deploy],deploy_support_key=deploy,
                full_encoder_state_sha256=src['encoder_state_sha256'],all_episodes_shared_frame=frame_ref,
                Qcal_meta_reference_source_indices=Q[known],Qcal_meta_reference_ids=src['ids'][Q][known],
                Qcal_meta_reference_fine=src['fine'][Q][known],matched_action_cut=cut,
                Qcal_probabilities=qs['probabilities'],Qcal_headscore=qs['score'],Qaudit_source_indices=A,
                Qaudit_ids=src['ids'][A],Qaudit_groups=src['groups'][A],Qaudit_fine=src['fine'][A],
                Qaudit_features12=Af,Qaudit_probabilities=qa['probabilities'],Qaudit_headscore=qa['score'],
                Qaudit_head_certificate=qaU,Qaudit_proxy_truth=proxy,
                P_reference_only=True,Vfit_only=True,Qcal_action_only=True,QA_audit_only=True,
                source_model_fit_counts=dict(proxy_HGB=1,HGB_iterations=80),entire_head_seconds=time.perf_counter()-tick,**STATUS)
            headrefs[key]=dump(out/(key+'_head.joblib'),record);heads[key]=record
            counts.append(dict(key=key,genuine_Vfit=plan['genuine_V_parents'],logical_FIT_rows=plan['logical_FIT_rows'],
                FIT_copies=plan['FIT_copy_rows'],HGB_fits=1,HGB_iterations=80,
                fit_seconds=meta['fit_record']['fit_seconds'],entire_head_seconds=record['entire_head_seconds']))
            print('HEAD_COMPLETE',key,'genuine',plan['genuine_V_parents'],'slots',plan['logical_FIT_rows'],'seconds',record['entire_head_seconds'],flush=True)
    summary=dict(schema=SCHEMA,head_refs=headrefs,support_refs=suprefs,partition=desc(out/'SOURCE_ROLE_PARTITION.json'),
        new_HGB_fits=9,boosting_iterations=720,new_NN_epochs=0,new_geometry_fits=0,
        source_head_records=counts,current_profile_source_seconds=time.perf_counter()-start,
        P_rows=len(P),Vfit_rows=len(V),Qcal_rows=len(src['Q']),QA_rows=len(src['A']),**STATUS)
    put(out/'HEAD_SUMMARY.json',summary)
    return summary,headrefs

def pipeline(summary_path):
    C=mod(INC/'target99_v1051_20261024/core/nsl2_single_frame_graph_v1051.py','r4_original_pipeline')
    summary=js(summary_path)
    C._source_refs=lambda:(summary,summary['head_refs'])
    # Only CPU resource constants change; model/graph math remains frozen.
    C.B._setup=lambda:C.B.torch.set_num_threads(2)
    def limited_modules():
        for module in list(sys.modules.values()):
            path=getattr(module,'__file__','')or''
            if 'target99_' in path and hasattr(module,'CPU_THREADS'):module.CPU_THREADS=2
    original_module=C.module
    def load_limited(d,tag):
        result=original_module(d,tag);limited_modules();return result
    C.module=load_limited;limited_modules()
    return C
