"""Known-only recovery with query-independent labels on trusted QQ witnesses.

All graph solves, learned pair weights, MHFD/CNN-LSTM, source HGB heads and
density/noise operators are reused. Peers cannot use the candidate's graph
feedback to certify it. No new-UNA actions in this prospectively fixed trial.
"""
from pathlib import Path
import os,sys,importlib.util,time,types
for k in('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[k]='2'
os.environ['CUDA_VISIBLE_DEVICES']='-1'
import numpy as np
H=Path(__file__).resolve().parent;INC=H.parents[1]
def mod(p,name):
    s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
M=mod(INC/'target99_nsl2_20261028_r4/independent_reference_repair.py','r10_disjoint_reference')
SCHEMA='R10_SOURCE_ANCHORED_INDEPENDENT_WITNESS_KNOWN_RECOVERY_ONLY'

def margin(graph,parent_group,*,unknown_change_prior=4.):
    parent=np.asarray(parent_group);labels=np.asarray(graph['labels']);n=len(parent)
    source=np.asarray(graph['base_unary'],float)+np.asarray(graph['source_unary'],float)
    peer_label=source.argmin(1);row=np.arange(n)
    # Strict unique known winner without ANY query-query votes. Source costs
    # are the existing learned source-anchor terms, not labels of query rows.
    qualified=(parent<2)&(peer_label==parent)&(source[row,peer_label]<source[:,2])
    qualified&=source[row,peer_label]<source[row,1-np.minimum(peer_label,1)]
    left=np.asarray(graph['QQ_left']);right=np.asarray(graph['QQ_right']);weight=np.asarray(graph['QQ_weight']);cost=source.copy()
    count=np.zeros(n,int);mass=np.zeros(n);oldU_count=np.zeros(n,int);oldU_mass=np.zeros(n);rejected_known=np.zeros(n,int)
    for own,peer in((left,right),(right,left)):
        use=qualified[peer]
        for c in range(3):np.add.at(cost[:,c],own[use],weight[use]*(peer_label[peer[use]]!=c))
        np.add.at(count,own[use],1);np.add.at(mass,own[use],weight[use])
        u=parent[peer]==2;np.add.at(oldU_count,own[u],1);np.add.at(oldU_mass,own[u],weight[u])
        np.add.at(rejected_known,own[(parent[peer]<2)&~use],1)
    coarse=cost[:,:2].argmin(1).astype(np.int8);prior=float(unknown_change_prior)
    A=np.minimum(cost[row,1-coarse]+prior,cost[:,2])-(cost[row,coarse]+prior)
    proposal=(labels<2)&(labels==coarse)&(A>0)&(count>0)
    return dict(schema=SCHEMA,independent_cost=cost,independent_coarse=coarse,independent_A=A,known_proposal=proposal,
        trusted_QQ_count=count,excluded_original_U_QQ_count=oldU_count,trusted_QQ_mass=mass,excluded_original_U_QQ_mass=oldU_mass,
        source_only_peer_labels=peer_label,source_only_peer_qualified=qualified,rejected_source_inconsistent_known_peers=rejected_known,
        query_graph_labels_used_for_peer_vote=False,inference_arrays_changed=False,new_fits=0,current_truth_used=False)

def pipeline(summary_path):
    C=M.pipeline(summary_path);original_module=C.module
    def modules(d,tag):
        result=original_module(d,tag)
        if d==C.KNOWN:return types.SimpleNamespace(independent_known_margin=margin,SCHEMA=SCHEMA)
        return result
    C.module=modules;old_evidence=C._evidence
    def evidence(parent,s,admission,enabled=True):
        ev=old_evidence(parent,s,admission,enabled)
        ev['raw']=np.zeros(len(parent),bool);ev['noise']=np.zeros(len(parent),bool)
        ev['density_context']=(np.asarray(parent)==2)&~ev['actual_known']
        return ev
    C._evidence=evidence;old_fit=C.fit
    def fit(*args,**kwargs):
        b=old_fit(*args,**kwargs);a=b['source_audit'];a['inherited_all_action_eligibility']=a['development_pilot_allowed']
        # Qualification matches the ONLY planned action. A new-UNA signal floor
        # cannot qualify or disqualify a trial with zero new-UNA actions.
        a['development_pilot_allowed']=bool(a['known_return_enabled']and a['Qaudit_known_budgets_passed']and a['correct_known_certificate_coverage20']and b['matched_head_cuts']['full']['enabled'])
        a['qualification_scope']='known-recovery-only; all original known vetoes, ownheldQ99 admission and sourceQA false-known budgets required'
        a['new_UNA_actions_disabled_before_any_current_features']=True;a['query_graph_labels_used_for_peer_vote']=False
        a['status']='SOURCE_KNOWN_RECOVERY_QUALIFIED'if a['development_pilot_allowed']else'SOURCE_KNOWN_RECOVERY_RISK_STOP'
        b['actual_fit_counts'].update(new_model_fits=0,new_neural_epochs=0,new_HGB_fits=0,source_only_peer_certification=True)
        return b
    C.fit=fit;return C

def train_heads(source,raw_source,out):
    old=M.js(INC/'target99_nsl2_20261028_r4/actual_once/source/HEAD_SUMMARY.json')
    summary=dict(old,schema=SCHEMA,new_HGB_fits=0,new_NN_epochs=0,new_geometry_fits=0,current_profile_source_seconds=0.,
        note='No head refit. Reuse disjoint P-reference repaired source heads, not failedr8/r9 trained heads.',source_classes=['BEN','KNA'])
    M.put(out/'HEAD_SUMMARY.json',summary);return summary,summary['head_refs']

def checks():
    p=np.array([2,0,1,2]);g=dict(labels=np.array([0,0,1,2]),base_unary=np.array([[.3,.8,.9],[.1,.9,.9],[.9,.1,.9],[.8,.8,.1]]),
        source_unary=np.array([[.1,.9,1.],[.1,.9,1.],[.9,.1,1.],[.5,.5,1.]]),QQ_left=np.array([0,0,1,2]),QQ_right=np.array([1,3,2,3]),QQ_weight=np.array([5.,2.,1.,3.]))
    a=margin(g,p);changed=dict(g,labels=np.array([0,2,0,1]));b=margin(changed,p)
    assert np.array_equal(a['independent_cost'],b['independent_cost'])and np.array_equal(a['independent_A'],b['independent_A'])
    empty=dict(g,QQ_left=np.array([],int),QQ_right=np.array([],int),QQ_weight=np.array([],float));assert not margin(empty,p)['known_proposal'].any()
    assert not a['source_only_peer_qualified'][p==2].any()
    return dict(peer_margin_invariant_to_query_graph_peer_labels=True,original_UNA_peers_excluded=True,no_QQ_cannot_certify=True,performance_claim=False)
