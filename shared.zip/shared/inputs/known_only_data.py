"""Build BEN/KNA training roles without opening the source test file.

This path is for training a model before an independently acquired, sealed
feature-only cohort exists.  Source-train UNA rows are excluded before any
preprocessor fit, feature selection, neural fit, or calibration.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.feature_selection import SelectKBest, f_classif

from .config import CIC_FEATURE_COLUMNS, NSL_FEATURE_COLUMNS, ExperimentSpec
from .data import (
    _assign_scope,
    _build_preprocessor,
    _coerce_numeric,
    _feature_fingerprint,
    _known_role_mapping,
    _normalize_label,
    _read_source,
    sha256_file,
)
from .proportional_source_preflight import (
    MAX_ROWS_PER_ROLE, MIN_UNIQUE_ROWS_PER_FAMILY, proportional_quotas,
)


@dataclass(frozen=True)
class KnownOnlyBundle:
    x_fit: np.ndarray
    x_checkpoint: np.ndarray
    x_calibration: np.ndarray
    x_open_known: np.ndarray
    y_fit_coarse: np.ndarray
    y_checkpoint_coarse: np.ndarray
    y_calibration_coarse: np.ndarray
    y_open_known_coarse: np.ndarray
    y_fit_fine: np.ndarray
    y_calibration_fine: np.ndarray
    fit_families: np.ndarray
    checkpoint_families: np.ndarray
    calibration_families: np.ndarray
    open_known_families: np.ndarray
    fit_ids: np.ndarray
    checkpoint_ids: np.ndarray
    calibration_ids: np.ndarray
    open_known_ids: np.ndarray
    known_source_ids: np.ndarray
    fit_training_indices: np.ndarray
    preprocessor: Any
    selector: SelectKBest
    variance_mask: np.ndarray
    selected_feature_names: tuple[str, ...]
    fine_classes: tuple[str, ...]
    audit: dict[str, Any]


class CICSessionCoverageError(ValueError):
    """The verified CIC source has too few sessions for four disjoint roles."""

    def __init__(self, audit: dict[str, Any]):
        self.audit = audit
        super().__init__(
            "CIC source-isolated known roles lack four session groups per family: "
            + ", ".join(audit["families_below_four_sessions"])
        )


class KnownSourceCoverageError(ValueError):
    """A source-only BEN/KNA family cannot support the requested role split."""

    def __init__(self, audit: dict[str, Any]):
        self.audit = audit
        super().__init__(
            "known source lacks distinct feature rows for the training floor: "
            + str(audit["families_below_minimum"])
        )


def _select_known_training_cohort(
    known: pd.DataFrame, fine_classes: tuple[str, ...], *, seed: int,
    rare_fit_bootstrap: bool = False,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Deterministically cap unique BEN/KNA source rows before role splitting.

    A distinct feature vector is only a de-duplication unit, never evidence
    of an independently captured physical flow or attack event.
    """
    required = {"_fine_label", "_fingerprint", "_sample_id"}
    if not required <= set(known.columns) or known.empty:
        raise ValueError("known training source has no complete identity columns")
    if known[list(required)].isna().any().any() or known["_sample_id"].duplicated().any():
        raise ValueError("known training source has missing or repeated row identities")
    if set(known["_fine_label"]) != set(fine_classes):
        raise ValueError("known training source family set differs from Table 1")
    source_counts = {
        family: int(known["_fine_label"].eq(family).sum())
        for family in fine_classes
    }
    unique_counts = {
        family: int(known.loc[known["_fine_label"].eq(family),
                              "_fingerprint"].nunique())
        for family in fine_classes
    }
    deficits = {
        family: MIN_UNIQUE_ROWS_PER_FAMILY - count
        for family, count in unique_counts.items()
        if count < MIN_UNIQUE_ROWS_PER_FAMILY
    }
    audit = {
        "schema_version": "known-only-proportional-source-cohort-v1",
        "source_known_rows_by_family": source_counts,
        "distinct_feature_rows_by_family": unique_counts,
        "families_below_minimum": deficits,
        "minimum_distinct_feature_rows_per_family": MIN_UNIQUE_ROWS_PER_FAMILY,
        "maximum_known_training_rows": MAX_ROWS_PER_ROLE,
        "physical_flow_independence_verified": False,
        "sampling_uses_unknown_or_source_test_labels": False,
        "bootstrap_or_replacement_rows": 0,
    }
    if deficits and not rare_fit_bootstrap:
        raise KnownSourceCoverageError(audit)
    if rare_fit_bootstrap and any(count < 4 for count in unique_counts.values()):
        audit["families_below_four_distinct_role_groups"] = {
            family: 4 - count for family, count in unique_counts.items() if count < 4
        }
        raise KnownSourceCoverageError(audit)
    if rare_fit_bootstrap:
        # The quota is for distinct source rows only. Rare-family copies are
        # added later inside the fit role, after all held roles are frozen.
        augmented_counts = {
            family: max(count, MIN_UNIQUE_ROWS_PER_FAMILY)
            for family, count in unique_counts.items()
        }
        quotas = {
            family: min(unique_counts[family], count)
            for family, count in proportional_quotas(augmented_counts).items()
        }
        audit["rare_fit_bootstrap_enabled"] = True
        audit["families_requiring_fit_only_bootstrap"] = deficits
        audit["minimum_distinct_feature_groups_for_four_roles"] = 4
        audit["rare_family_copies_not_source_rows_or_independent_events"] = True
    else:
        quotas = proportional_quotas(unique_counts)
    # One stable representative per family/feature vector, then stable
    # no-replacement selection. Neither order depends on file row position.
    ranked = known.copy()
    ranked["_selection_rank"] = ranked["_sample_id"].map(
        lambda value: hashlib.sha256(
            f"{seed}|{value}".encode("utf-8")
        ).hexdigest()
    )
    representatives = ranked.sort_values(
        ["_selection_rank", "_sample_id"], kind="stable"
    ).drop_duplicates(["_fine_label", "_fingerprint"])
    selected = pd.concat([
        representatives.loc[representatives["_fine_label"].eq(family)]
        .sort_values(["_selection_rank", "_sample_id"], kind="stable")
        .head(quota)
        for family, quota in sorted(quotas.items())
    ], ignore_index=True).drop(columns="_selection_rank")
    if (len(selected) > MAX_ROWS_PER_ROLE or len(selected) != sum(quotas.values())
            or selected["_sample_id"].duplicated().any()
            or selected.duplicated(["_fine_label", "_fingerprint"]).any()):
        raise AssertionError("known-only source cohort selection violated its quota")
    audit["selected_rows_by_family"] = quotas
    audit["selected_known_training_rows"] = len(selected)
    audit["selected_sample_id_set_sha256"] = hashlib.sha256(
        "\n".join(sorted(selected["_sample_id"].astype(str))).encode("utf-8")
    ).hexdigest()
    return selected, audit


def _fit_training_indices(
    fit: pd.DataFrame, fine_classes: tuple[str, ...], *, seed: int,
    rare_fit_bootstrap: bool,
) -> tuple[np.ndarray, dict[str, Any]]:
    """Create source-only fit copies; never replicate checkpoint/control rows."""
    if fit.empty or fit["_sample_id"].duplicated().any():
        raise ValueError("fit role is empty or has repeated source identities")
    indices = list(range(len(fit)))
    added: dict[str, int] = {}
    unique_parent: dict[str, int] = {}
    for family in fine_classes:
        family_indices = [int(i) for i in np.flatnonzero(
            fit["_fine_label"].eq(family).to_numpy()
        )]
        if not family_indices:
            raise ValueError(f"fit role lacks known family {family}")
        unique_parent[family] = len(family_indices)
        count = max(0, MIN_UNIQUE_ROWS_PER_FAMILY - len(family_indices)) \
            if rare_fit_bootstrap else 0
        added[family] = count
        ranked = sorted(family_indices, key=lambda i: (
            hashlib.sha256(
                f"{seed}|fit-only|{fit.iloc[i]['_sample_id']}".encode("utf-8")
            ).hexdigest(),
            str(fit.iloc[i]["_sample_id"]),
        ))
        indices.extend(ranked[i % len(ranked)] for i in range(count))
    if len(indices) > MAX_ROWS_PER_ROLE:
        raise ValueError("fit-only bootstrap exceeds the 6000-row training cap")
    parent_ids = fit.iloc[indices]["_sample_id"].astype(str).tolist()
    audit = {
        "enabled": rare_fit_bootstrap,
        "source_role": "fit_only",
        "minimum_training_rows_per_family": MIN_UNIQUE_ROWS_PER_FAMILY,
        "unique_fit_source_rows_by_family": unique_parent,
        "bootstrap_copies_by_family": added,
        "training_rows": len(indices),
        "training_parent_id_sequence_sha256": hashlib.sha256(
            "\n".join(parent_ids).encode("utf-8")
        ).hexdigest(),
        "copies_count_as_independent_physical_flows": False,
        "copies_enter_checkpoint_calibration_or_open_known": False,
    }
    return np.asarray(indices, dtype=np.int64), audit


def _load_cic_session_index(
    *, workspace: Path, spec: ExperimentSpec, train_path: Path,
    raw: pd.DataFrame, index_dir: Path,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    if spec.dataset != "cic":
        raise ValueError("CIC session index is CIC2017-only")
    directory = index_dir.resolve()
    scratch = (workspace / "tmp").resolve()
    if directory == scratch or not directory.is_relative_to(scratch):
        raise ValueError("CIC session index must be below workspace/tmp")
    report_path = directory / "result.json"
    index_path = directory / "train_index.csv"
    report = json.loads(report_path.read_text(encoding="utf-8"))
    if (report.get("schema_version") != "cic2017-source-isolated-development-index-v1"
            or report.get("setting") != spec.name
            or report.get("status") != "DEVELOPMENT_INDEX_ONLY"
            or report.get("published") is not False
            or report.get("test_labels_read") is not False
            or report.get("final_test_executed") is not False):
        raise ValueError("CIC source identity index protocol mismatch")
    if sha256_file(train_path) != report.get("inputs", {}).get("train_csv_sha256"):
        raise ValueError("CIC source train changed after identity index creation")
    if sha256_file(index_path) != report.get("train_index", {}).get("sha256"):
        raise ValueError("CIC source identity train index changed")
    index = pd.read_csv(index_path, dtype={"session_group_id": "string"})
    required = {
        "original_train_row", "declared_known_family", "source_identity_confirmed",
        "eligible_for_future_known_roles", "session_group_id",
    }
    if not required <= set(index) or len(index) != len(raw):
        raise ValueError("CIC source identity index is incomplete")
    if index["original_train_row"].tolist() != list(range(len(raw))):
        raise ValueError("CIC source identity index row coordinates differ")
    for column in ("declared_known_family", "source_identity_confirmed",
                   "eligible_for_future_known_roles"):
        if index[column].dtype != bool:
            raise ValueError(f"CIC source identity index has non-boolean {column}")
    known = raw["_scope"].isin(("BEN", "KNA")).to_numpy(dtype=bool)
    if not np.array_equal(index["declared_known_family"].to_numpy(), known):
        raise ValueError("CIC identity index known-family mask differs from training labels")
    eligible = index["eligible_for_future_known_roles"].to_numpy(dtype=bool)
    confirmed = index["source_identity_confirmed"].to_numpy(dtype=bool)
    if np.any(eligible & (~known | ~confirmed)):
        raise ValueError("CIC identity index admits unknown or unconfirmed rows")
    sessions = index["session_group_id"].astype("string")
    if sessions.loc[eligible].isna().any() or sessions.loc[eligible].eq("").any():
        raise ValueError("CIC identity index has missing eligible session IDs")
    selected = raw.loc[eligible].copy()
    selected["_session_group_id"] = sessions.loc[eligible].to_numpy(dtype=str)
    labels = (spec.benign_label, *spec.known_families)
    counts = {
        family: int(selected.loc[selected["_label"].eq(family),
                                 "_session_group_id"].nunique())
        for family in labels
    }
    audit = {
        "schema_version": "cic-known-source-session-coverage-v1",
        "status": "DEVELOPMENT_INDEX_ONLY",
        "setting": spec.name,
        "source_train_sha256": report["inputs"]["train_csv_sha256"],
        "source_identity_result_sha256": sha256_file(report_path),
        "source_identity_train_index_sha256": sha256_file(index_path),
        "original_train_rows": len(raw),
        "eligible_known_rows": int(eligible.sum()),
        "eligible_unique_sessions": int(selected["_session_group_id"].nunique()),
        "eligible_session_groups_by_family": counts,
        "minimum_session_groups_per_family_for_four_roles": 4,
        "families_below_four_sessions": [
            family for family, count in counts.items() if count < 4
        ],
        "historical_test_previously_scored": True,
        "session_grouping_heuristic_not_independent_campaign_proof": True,
        "source_test_file_opened_during_training": False,
        "source_test_labels_read_during_training": False,
        "published": False,
        "final_test_executed": False,
    }
    if audit["families_below_four_sessions"]:
        raise CICSessionCoverageError(audit)
    return selected, audit


def prepare_known_only_data(
    workspace: str | Path,
    spec: ExperimentSpec,
    *,
    seed: int,
    feature_top_k: int = 256,
    cic_source_index_dir: str | Path | None = None,
    strict_proportional_cohort: bool = False,
    rare_fit_bootstrap: bool = False,
) -> KnownOnlyBundle:
    """Read the Table-1 train CSV only and create disjoint known-only roles."""

    if feature_top_k < 2:
        raise ValueError("feature_top_k must be at least two")
    if rare_fit_bootstrap and not strict_proportional_cohort:
        raise ValueError("rare fit bootstrap requires the strict source cohort")
    train_path, _unopened_test_path = spec.data_paths(Path(workspace))
    raw = _read_source(spec, train_path, "source_train")
    columns = CIC_FEATURE_COLUMNS if spec.dataset == "cic" else NSL_FEATURE_COLUMNS
    raw["_label"] = raw["label"].map(lambda value: _normalize_label(spec, value))
    raw["_scope"] = raw["_label"].map(lambda value: _assign_scope(spec, value))
    undeclared = sorted(set(raw.loc[raw["_scope"].eq("UNDECLARED"), "_label"]))
    if undeclared:
        raise ValueError(f"{spec.name}: undeclared source-train labels: {undeclared}")
    source_session_audit = None
    if cic_source_index_dir is not None:
        known, source_session_audit = _load_cic_session_index(
            workspace=Path(workspace).resolve(), spec=spec, train_path=train_path,
            raw=raw, index_dir=Path(cic_source_index_dir),
        )
    else:
        known = raw.loc[raw["_scope"].isin(("BEN", "KNA"))].copy()
    if set(known["_scope"]) != {"BEN", "KNA"}:
        raise ValueError(f"{spec.name}: source train lacks BEN or KNA")
    known["_fine_label"] = np.where(
        known["_scope"].eq("BEN"), "BEN", known["_label"]
    )
    known["_fingerprint"] = _feature_fingerprint(known, columns)
    known["_sample_id"] = (
        spec.dataset + ":source_train:" + known["_source_row"].astype(str)
        + ":" + known["_fingerprint"]
    )
    fine_classes = ("BEN", *spec.known_families)
    missing_fit_families = sorted(set(fine_classes) - set(known["_fine_label"]))
    if missing_fit_families:
        raise ValueError(
            f"{spec.name}: source train lacks declared known families: {missing_fit_families}"
        )
    source_cohort_audit = None
    if strict_proportional_cohort:
        known, source_cohort_audit = _select_known_training_cohort(
            known, fine_classes, seed=seed,
            rare_fit_bootstrap=rare_fit_bootstrap,
        )
    roles, role_audit = _known_role_mapping(
        known, seed=seed, validation_fraction=0.20, open_known_fraction=0.10,
        group_column=(
            "_session_group_id" if source_session_audit is not None
            else "_fingerprint"
        ),
    )
    known["_role"] = known[
        "_session_group_id" if source_session_audit is not None else "_fingerprint"
    ].map(roles)
    frames = {
        role: known.loc[known["_role"].eq(role)].reset_index(drop=True)
        for role in ("fit", "checkpoint", "calibration", "open_known")
    }
    if any(frame.empty for frame in frames.values()):
        raise ValueError(f"{spec.name}: a known-only role is empty")
    if set(frames["fit"]["_fine_label"]) != set(fine_classes):
        raise ValueError(f"{spec.name}: fit role lacks a declared known family")
    fit_training_indices, fit_training_audit = _fit_training_indices(
        frames["fit"], fine_classes, seed=seed,
        rare_fit_bootstrap=rare_fit_bootstrap,
    )
    if source_session_audit is not None:
        incomplete = {
            role: sorted(set(fine_classes) - set(frame["_fine_label"]))
            for role, frame in frames.items()
        }
        if any(incomplete.values()):
            source_session_audit["missing_families_by_role"] = incomplete
            source_session_audit["families_below_four_sessions"] = sorted({
                family for families in incomplete.values() for family in families
            })
            raise CICSessionCoverageError(source_session_audit)
    for left, right in (
        ("fit", "checkpoint"),
        ("fit", "calibration"),
        ("fit", "open_known"),
        ("checkpoint", "calibration"),
        ("checkpoint", "open_known"),
        ("calibration", "open_known"),
    ):
        if set(frames[left]["_fingerprint"]) & set(frames[right]["_fingerprint"]):
            raise AssertionError(f"{spec.name}: {left}/{right} fingerprint overlap")
        if source_session_audit is not None and (
            set(frames[left]["_session_group_id"])
            & set(frames[right]["_session_group_id"])
        ):
            raise AssertionError(f"{spec.name}: {left}/{right} source session overlap")
    frames = {
        role: _coerce_numeric(frame, spec, columns)
        for role, frame in frames.items()
    }
    preprocessor = _build_preprocessor(spec, columns)
    encoded_fit = np.asarray(
        preprocessor.fit_transform(frames["fit"]), dtype=np.float32
    )
    encoded_other = {
        role: np.asarray(preprocessor.transform(frames[role]), dtype=np.float32)
        for role in ("checkpoint", "calibration", "open_known")
    }
    variance_mask = np.var(encoded_fit, axis=0) > 0.0
    if int(np.sum(variance_mask)) < 2:
        raise ValueError(f"{spec.name}: fewer than two variable encoded features")
    fine_index = {family: index for index, family in enumerate(fine_classes)}
    y_fine = {
        role: frame["_fine_label"].map(fine_index).to_numpy(dtype=np.int64)
        for role, frame in frames.items()
    }
    selector = SelectKBest(
        score_func=f_classif,
        k=min(feature_top_k, int(np.sum(variance_mask))),
    )
    x_fit = np.asarray(
        selector.fit_transform(encoded_fit[:, variance_mask], y_fine["fit"]),
        dtype=np.float32,
    )
    x_other = {
        role: np.asarray(
            selector.transform(encoded_other[role][:, variance_mask]),
            dtype=np.float32,
        )
        for role in encoded_other
    }
    if not np.isfinite(x_fit).all() or any(
        not np.isfinite(value).all() for value in x_other.values()
    ):
        raise ValueError(f"{spec.name}: non-finite transformed known features")
    all_names = np.asarray(preprocessor.get_feature_names_out(), dtype=object)
    selected_names = tuple(
        all_names[variance_mask][selector.get_support()].astype(str)
    )
    y_coarse = {
        role: frame["_scope"].eq("KNA").to_numpy(dtype=np.int64)
        for role, frame in frames.items()
    }
    audit = {
        "schema_version": "known-only-train-file-v1",
        "setting": spec.name,
        "source_train_path": str(train_path.resolve()),
        "source_train_sha256": sha256_file(train_path),
        "source_train_rows": len(raw),
        "source_train_una_rows_excluded": int(raw["_scope"].eq("UNA").sum()),
        "source_known_proportional_cohort": source_cohort_audit,
        "source_test_file_opened": False,
        "source_test_labels_read": False,
        "target_unknown_used_for_fit_or_selection": False,
        "known_role_split": role_audit,
        "role_rows": {role: len(frame) for role, frame in frames.items()},
        "role_sample_id_set_sha256": {
            role: hashlib.sha256(
                "\n".join(sorted(frame["_sample_id"].astype(str))).encode("utf-8")
            ).hexdigest()
            for role, frame in frames.items()
        },
        "known_source_sample_id_set_sha256": hashlib.sha256(
            "\n".join(sorted(known["_sample_id"].astype(str))).encode("utf-8")
        ).hexdigest(),
        "fit_families": {
            family: int(frames["fit"]["_fine_label"].eq(family).sum())
            for family in fine_classes
        },
        "source_train_family_unique_feature_fingerprints": {
            family: int(known.loc[
                known["_fine_label"].eq(family), "_fingerprint"
            ].nunique())
            for family in fine_classes
        },
        "role_family_unique_feature_fingerprints": {
            role: {
                family: int(frame.loc[
                    frame["_fine_label"].eq(family), "_fingerprint"
                ].nunique())
                for family in fine_classes
            }
            for role, frame in frames.items()
        },
        # Distinct feature vectors are not independent capture events.
        "independent_event_count_verified": False,
        "event_or_session_id_available": source_session_audit is not None,
        "source_session_coverage": source_session_audit,
        "selected_feature_count": len(selected_names),
    }
    if rare_fit_bootstrap:
        audit["train_only_bootstrap"] = fit_training_audit
    return KnownOnlyBundle(
        x_fit=x_fit,
        x_checkpoint=x_other["checkpoint"],
        x_calibration=x_other["calibration"],
        x_open_known=x_other["open_known"],
        y_fit_coarse=y_coarse["fit"],
        y_checkpoint_coarse=y_coarse["checkpoint"],
        y_calibration_coarse=y_coarse["calibration"],
        y_open_known_coarse=y_coarse["open_known"],
        y_fit_fine=y_fine["fit"],
        y_calibration_fine=y_fine["calibration"],
        fit_families=frames["fit"]["_fine_label"].to_numpy(dtype=str),
        checkpoint_families=frames["checkpoint"]["_fine_label"].to_numpy(dtype=str),
        calibration_families=frames["calibration"]["_fine_label"].to_numpy(dtype=str),
        open_known_families=frames["open_known"]["_fine_label"].to_numpy(dtype=str),
        fit_ids=frames["fit"]["_sample_id"].to_numpy(dtype=str),
        checkpoint_ids=frames["checkpoint"]["_sample_id"].to_numpy(dtype=str),
        calibration_ids=frames["calibration"]["_sample_id"].to_numpy(dtype=str),
        open_known_ids=frames["open_known"]["_sample_id"].to_numpy(dtype=str),
        known_source_ids=known["_sample_id"].to_numpy(dtype=str),
        fit_training_indices=fit_training_indices,
        preprocessor=preprocessor,
        selector=selector,
        variance_mask=variance_mask,
        selected_feature_names=selected_names,
        fine_classes=fine_classes,
        audit=audit,
    )
