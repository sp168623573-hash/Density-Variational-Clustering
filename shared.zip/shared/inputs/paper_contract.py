"""Audit legacy contract drift and separately report complete paper scope.

The backward-compatible status and training flag compare the frozen legacy
configuration and manuscript hashes. They do not prove complete Table 1 scope.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from .config import SETTINGS
from .paper_scope import PAPER_SCOPE_SETTINGS, PAPER_SCOPE_VERSION, check_paper_scope


CONTRACT_PATH = Path(__file__).with_name("paper_contract_20260924.json")
LOCAL_MANUSCRIPT_DIR = Path("F:/shenpeng/提交论文/软件学报")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def audit_paper_contract(*, manuscript_dir: Path = LOCAL_MANUSCRIPT_DIR) -> dict[str, Any]:
    contract = json.loads(CONTRACT_PATH.read_text(encoding="utf-8"))
    roles: dict[str, Any] = {}
    settings_match = set(contract["settings"]) == set(SETTINGS)
    for name, expected in contract["settings"].items():
        spec = SETTINGS.get(name)
        known_match = spec is not None and set(expected["known"]) == set(spec.known_families)
        unknown_match = spec is not None and set(expected["unknown"]) == set(spec.unknown_families)
        no_role_overlap = spec is not None and not (
            set(spec.known_families) & set(spec.unknown_families)
        )
        roles[name] = {
            "known_match": bool(known_match),
            "unknown_match": bool(unknown_match),
            "no_known_unknown_overlap": bool(no_role_overlap),
        }
        settings_match &= bool(known_match and unknown_match and no_role_overlap)

    sources: dict[str, Any] = {}
    changed_source = False
    for kind in ("pdf", "docx"):
        path = manuscript_dir / contract[f"source_{kind}_name"]
        if path.is_file():
            observed = _sha256(path)
            matches = observed == contract[f"source_{kind}_sha256"]
            changed_source |= not matches
            sources[kind] = {
                "available": True,
                "sha256": observed,
                "matches_contract": matches,
            }
        else:
            sources[kind] = {
                "available": False,
                "sha256": None,
                "matches_contract": None,
            }

    allowed = bool(settings_match and not changed_source)
    scope_reports = {}
    for name in PAPER_SCOPE_SETTINGS:
        spec = SETTINGS.get(name)
        scope_reports[name] = check_paper_scope(
            setting=name,
            known_families=spec.known_families if spec is not None else (),
            unknown_families=spec.unknown_families if spec is not None else (),
        )
    complete_scope = (set(SETTINGS) == set(PAPER_SCOPE_SETTINGS)
                      and all(item["complete_paper_scope_verified"] for item in scope_reports.values()))
    # Preserve legacy development behavior, including partial unknown DEV.
    # A future final caller must also enforce independent-source/once-only gates.
    status = (
        "PASS_PAPER_TABLE1_AND_SOURCE_HASH"
        if allowed and all(item["available"] for item in sources.values())
        else (
            "PASS_CONFIG_ONLY_SOURCE_NOT_LOCAL"
            if allowed else "PROTOCOL_STOP_PAPER_OR_TABLE1_DRIFT"
        )
    )
    return {
        "schema_version": "paper-table1-runtime-audit-v1",
        "status": status,
        "status_semantics": "legacy_config_contract_and_available_source_hash_consistency_only",
        "development_training_allowed": allowed,
        "paper_scope_version": PAPER_SCOPE_VERSION,
        "complete_paper_scope_verified": complete_scope,
        "missing_paper_families": {
            name: item["missing_paper_families"] for name, item in scope_reports.items()
            if item["missing_paper_families"]
        },
        "unexpected_paper_families": {
            name: item["unexpected_paper_families"] for name, item in scope_reports.items()
            if item["unexpected_paper_families"]
        },
        "paper_scope_by_setting": scope_reports,
        "full_table1_final_evaluation_allowed": bool(allowed and complete_scope),
        "full_table1_final_evaluation_allowed_semantics": (
            "roster_and_legacy_contract_gate_only; independent_source_and_atomic_once_final_gates_still_required"
        ),
        "development_coverage_requirement_added": False,
        "independent_final_test_proved": False,
        "source_pdf_sha256_expected": contract["source_pdf_sha256"],
        "source_docx_sha256_expected": contract["source_docx_sha256"],
        "table_1_pdf_page": contract["table_1_pdf_page"],
        "setting_roles": roles,
        "source_files": sources,
        "target99_status": "FAIL_TARGET99",
        "published": False,
    }
