"""Read-only source census and fail-closed, no-replacement sampling quotas.

This audit is separate from model fit and one-time final scoring.  It may read
family labels to check whether a proposed cohort is *possible*, but never
exports selected test rows or passes their labels to a trainer.
"""

from __future__ import annotations

import argparse
from collections import Counter
import csv
from decimal import Decimal, InvalidOperation
import hashlib
import json
from numbers import Integral
from pathlib import Path
from typing import Iterable, Mapping

from .config import SETTINGS


MAX_ROWS_PER_ROLE = 6000
MIN_UNIQUE_ROWS_PER_FAMILY = 20
CIC_SOURCE_DIR = Path("data/external_dev/raw/cicids2017_traffic_labels_parquet")
NSL_SOURCE_DIR = Path("data/external_dev/raw/nsl_kdd_full_github_jmnwong")
NSL_ZENODO_TRAIN = Path("data/external_dev/raw/nsl_kdd_full_zenodo_17424143/KDDTrain+.txt")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _legacy_asset(path: Path) -> dict:
    with path.open("rb") as source:
        rows = sum(1 for _ in source)
    return {"path": str(path.resolve()), "sha256": _sha256(path),
            "physical_file_lines": rows, "exceeds_role_cap": rows > MAX_ROWS_PER_ROLE,
            "formal_cohort_admitted": False}


def _normalized_cic_label(value: object) -> str:
    # The publisher's Web labels contain cp1252 0x96 in the parquet conversion.
    return str(value).strip().replace("\x96", "-").replace("\u2013", "-")


def _count_cic_sources(directory: Path) -> tuple[Counter[str], list[dict]]:
    try:
        import pyarrow.parquet as pq
    except ImportError as exc:
        raise RuntimeError("pyarrow is required to census original CIC parquet") from exc
    files = sorted(directory.glob("*.parquet"))
    if len(files) != 8:
        raise ValueError(f"expected 8 original CIC parquet files, found {len(files)}")
    counts: Counter[str] = Counter()
    assets = []
    for path in files:
        parquet = pq.ParquetFile(path)
        if "Label" not in parquet.schema_arrow.names:
            raise ValueError(f"original CIC source missing Label: {path}")
        file_counts: Counter[str] = Counter()
        for batch in parquet.iter_batches(columns=["Label"]):
            file_counts.update(_normalized_cic_label(v) for v in batch.column(0).to_pylist())
        if sum(file_counts.values()) != parquet.metadata.num_rows:
            raise ValueError(f"CIC row count mismatch: {path}")
        counts.update(file_counts)
        assets.append({"path": str(path.resolve()), "sha256": _sha256(path),
                       "rows": int(parquet.metadata.num_rows)})
    return counts, assets


def _count_nsl_source(path: Path) -> tuple[Counter[str], dict]:
    counts: Counter[str] = Counter()
    with path.open("r", encoding="utf-8", newline="") as source:
        for line_number, row in enumerate(csv.reader(source), start=1):
            if len(row) != 43:
                raise ValueError(f"NSL family source requires 43 columns: {path}:{line_number}")
            counts[row[41].strip().rstrip(".")] += 1
    return counts, {"path": str(path.resolve()), "sha256": _sha256(path),
                    "rows": int(sum(counts.values()))}


def _same_nsl_cell(left: str, right: str) -> bool:
    if left == right:
        return True
    try:
        return Decimal(left) == Decimal(right)
    except InvalidOperation:
        return False


def _verify_nsl_train_mirror(github_path: Path, zenodo_path: Path) -> dict:
    rows = 0
    with github_path.open("r", encoding="utf-8", newline="") as github, \
            zenodo_path.open("r", encoding="utf-8", newline="") as zenodo:
        github_reader = csv.reader(github)
        zenodo_reader = csv.reader(zenodo, delimiter="\t")
        while True:
            left = next(github_reader, None)
            right = next(zenodo_reader, None)
            if left is None and right is None:
                break
            rows += 1
            if left is None or right is None or len(left) != 43 or len(right) != 43:
                raise ValueError(f"NSL train mirrors differ in row shape at {rows}")
            if not all(_same_nsl_cell(a, b) for a, b in zip(left, right)):
                raise ValueError(f"NSL train mirrors differ in values at row {rows}")
    return {"github_and_zenodo_numeric_semantic_rows_equal": True,
            "rows_compared": rows,
            "zenodo_path": str(zenodo_path.resolve()),
            "zenodo_sha256": _sha256(zenodo_path)}


def _exact_nonnegative_integer(value: object, name: str) -> int:
    """Accept integer scalars, never rounded values or boolean count claims."""
    if isinstance(value, bool) or not isinstance(value, Integral) or value < 0:
        raise ValueError(f"{name} must be an exact nonnegative integer")
    return int(value)


def _family_counts(values: Mapping[str, int], name: str) -> dict[str, int]:
    if not isinstance(values, Mapping) or not values:
        raise ValueError(f"{name} requires nonempty family counts")
    counts = {}
    for family, value in values.items():
        if not isinstance(family, str) or not family.strip():
            raise ValueError(f"{name} requires nonempty string family names")
        counts[family] = _exact_nonnegative_integer(value, f"{name}[{family}]")
    return counts


def proportional_quotas(
    family_counts: Mapping[str, int],
    *,
    maximum_rows: int = MAX_ROWS_PER_ROLE,
    minimum_family_rows: int = MIN_UNIQUE_ROWS_PER_FAMILY,
) -> dict[str, int]:
    """Find integer quotas q≈alpha*n with q>=minimum and q<=original count.

    A lower-bound family is intentionally overrepresented; all other families
    retain their original relative proportions up to integer rounding.  A
    missing/rare family raises instead of being duplicated or synthesized.
    """
    counts = _family_counts(family_counts, "source counts")
    maximum_rows = _exact_nonnegative_integer(maximum_rows, "maximum_rows")
    minimum_family_rows = _exact_nonnegative_integer(
        minimum_family_rows, "minimum_family_rows",
    )
    if maximum_rows < 1 or minimum_family_rows < 1:
        raise ValueError("nonempty families and positive limits are required")
    if any(count < minimum_family_rows for count in counts.values()):
        deficits = {name: minimum_family_rows - count for name, count in sorted(counts.items())
                    if count < minimum_family_rows}
        raise ValueError(f"insufficient original, non-duplicated family rows: {deficits}")
    if len(counts) * minimum_family_rows > maximum_rows:
        raise ValueError("family minimums exceed maximum_rows")
    if sum(counts.values()) <= maximum_rows:
        return dict(sorted(counts.items()))

    low, high = 0.0, 1.0
    for _ in range(80):
        alpha = (low + high) / 2
        total = sum(max(minimum_family_rows, alpha * count) for count in counts.values())
        if total < maximum_rows:
            low = alpha
        else:
            high = alpha
    target = {name: max(float(minimum_family_rows), high * count)
              for name, count in counts.items()}
    quota = {name: min(counts[name], int(value)) for name, value in target.items()}
    remaining = maximum_rows - sum(quota.values())
    if remaining < 0:
        raise AssertionError("water-fill rounding exceeded cap")
    for name in sorted(counts, key=lambda k: (-(target[k] - int(target[k])), k)):
        if remaining == 0:
            break
        if quota[name] < counts[name]:
            quota[name] += 1
            remaining -= 1
    if remaining != 0 or sum(quota.values()) != maximum_rows:
        raise AssertionError("water-fill rounding did not exhaust cap")
    return dict(sorted(quota.items()))


def select_cohort_identities(
    labeled_physical_identities: Iterable[tuple[str, str]],
    quotas: Mapping[str, int],
    *,
    excluded_physical_identities: Iterable[str] = (),
    seed: str,
) -> dict[str, list[str]]:
    """Select unique verified physical IDs; the caller must validate ID provenance.

    Source row numbers, feature fingerprints, and duplicate sample names are
    *not* physical identities. This helper never weakens that prerequisite.
    """
    quotas = _family_counts(quotas, "cohort quotas")
    excluded = set()
    for physical_id in excluded_physical_identities:
        if not isinstance(physical_id, str) or not physical_id.strip():
            raise ValueError("excluded physical identities must be nonempty strings")
        excluded.add(physical_id)
    if (not isinstance(seed, str) or not seed.strip()
            or any(value < MIN_UNIQUE_ROWS_PER_FAMILY for value in quotas.values())):
        raise ValueError("seed and minimum family quotas are required")
    if sum(quotas.values()) > MAX_ROWS_PER_ROLE:
        raise ValueError("cohort quota exceeds role maximum")
    by_family: dict[str, list[str]] = {family: [] for family in quotas}
    seen: set[str] = set()
    for physical_id, family in labeled_physical_identities:
        if (not isinstance(physical_id, str) or not physical_id.strip()
                or physical_id in seen):
            raise ValueError("missing or repeated physical identity")
        if not isinstance(family, str) or not family.strip():
            raise ValueError("physical identity requires a nonempty string family")
        seen.add(physical_id)
        if family in by_family and physical_id not in excluded:
            by_family[family].append(physical_id)
    result = {}
    for family, needed in sorted(quotas.items()):
        candidates = by_family[family]
        if len(candidates) < needed:
            raise ValueError(f"{family}: {len(candidates)} verified physical IDs < {needed}")
        result[family] = sorted(
            candidates,
            key=lambda physical_id: (
                hashlib.sha256(f"{seed}|{physical_id}".encode("utf-8")).digest(),
                physical_id,
            ),
        )[:needed]
    return result


def _role_report(counts: Mapping[str, int], families: tuple[str, ...]) -> dict:
    available = {family: int(counts.get(family, 0)) for family in families}
    denominator = sum(available.values())
    deficits = {family: MIN_UNIQUE_ROWS_PER_FAMILY - count
                for family, count in available.items()
                if count < MIN_UNIQUE_ROWS_PER_FAMILY}
    quotas = None if deficits else proportional_quotas(available)
    return {"original_family_rows": available,
            "original_role_total_rows": denominator,
            "original_role_family_percent": {
                family: 100.0 * count / denominator for family, count in available.items()
            },
            "minimum_family_deficits": deficits,
            "candidate_quotas_no_replacement": quotas,
            "candidate_total_rows": None if quotas is None else sum(quotas.values()),
            "candidate_family_percent": None if quotas is None else {
                family: 100.0 * count / sum(quotas.values()) for family, count in quotas.items()
            }}


def verify_heartbleed_session_evidence(report: dict, source_rows: int) -> None:
    """Accept only source-only negative session evidence, never an admission."""
    from .cic2017_heartbleed_session_preflight import PARQUET_SHA256, PCAP_SHA256
    if (report.get("schema_version") != "cic2017-heartbleed-session-preflight-v1"
            or report.get("status") != "ORIGINAL_HEARTBLEED_SESSION_SPLIT_NOT_ADMITTED"
            or report.get("source_parquet_sha256") != PARQUET_SHA256
            or report.get("source_pcap_sha256") != PCAP_SHA256
            or report.get("source_complete_pcap_records") != 13788878
            or report.get("source_labelled_rows") != source_rows
            or report.get("train_test_session_split_admitted") is not False
            or report.get("flow_segments_are_independent_attack_events") is not False
            or report.get("independent_attack_event_count_verified") is not False
            or report.get("frozen_target_labels_read") is not False
            or report.get("model_fit_or_scoring_performed") is not False
            or report.get("target99_status") != "FAIL_TARGET99"
            or report.get("published") is not False
            or not isinstance(report.get("source_directional_packet_totals_equal"), bool)
            or report.get("source_label_access_scope") != "aggregate_source_identity_preflight_only"):
        raise ValueError("Heartbleed session evidence is not the pinned source-only audit")
    for key in ("same_capture_five_tuple_groups", "raw_syn_without_ack_packet_count",
                "distinct_raw_syn_origin_sequence_pairs"):
        value = report.get(key)
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError("Heartbleed session evidence count is not a nonnegative integer")
    if (len(report.get("raw_syn_origin_sequence_pairs", []))
            != report["distinct_raw_syn_origin_sequence_pairs"]
            or len(report.get("raw_syn_without_ack_times_utc", []))
            != report["raw_syn_without_ack_packet_count"]):
        raise ValueError("Heartbleed session evidence has inconsistent opening identity counts")


def audit_sources(workspace: Path, *, heartbleed_session_audit: Path | None = None) -> dict:
    workspace = workspace.resolve()
    cic_counts, cic_assets = _count_cic_sources(workspace / CIC_SOURCE_DIR)
    session_evidence = None
    if heartbleed_session_audit is not None:
        report_path = heartbleed_session_audit.resolve(strict=True)
        evidence = json.loads(report_path.read_text(encoding="utf-8"))
        verify_heartbleed_session_evidence(evidence, cic_counts.get("Heartbleed", 0))
        source_pcap = workspace / "data/external_dev/raw/cicids2017_pcap/pcap/Wednesday-workingHours.pcap"
        if (_sha256(source_pcap) != evidence["source_pcap_sha256"]
                or not any(asset["sha256"] == evidence["source_parquet_sha256"]
                           for asset in cic_assets)):
            raise ValueError("Heartbleed session audit input bytes changed")
        session_evidence = {
            "report_path": str(report_path), "report_sha256": _sha256(report_path),
            **{key: evidence[key] for key in (
                "source_labelled_rows", "same_capture_five_tuple_groups",
                "raw_syn_without_ack_packet_count", "distinct_raw_syn_origin_sequence_pairs",
                "source_directional_packet_totals_equal", "train_test_session_split_admitted")},
        }
    nsl_train, nsl_train_asset = _count_nsl_source(workspace / NSL_SOURCE_DIR / "KDDTrain+.txt")
    nsl_test, nsl_test_asset = _count_nsl_source(workspace / NSL_SOURCE_DIR / "KDDTest+.txt")
    nsl_train_mirror = _verify_nsl_train_mirror(
        workspace / NSL_SOURCE_DIR / "KDDTrain+.txt", workspace / NSL_ZENODO_TRAIN)
    legacy_assets = {
        "cic_train": _legacy_asset(workspace / "data/CIC_2017/train.csv"),
        "cic_test": _legacy_asset(workspace / "data/CIC_2017/test.csv"),
        "nsl_train": _legacy_asset(workspace / "data/NSL-KDD/KDDTrain_Sample.txt"),
        "nsl_test": _legacy_asset(workspace / "data/NSL-KDD/KDDTest_Sample.txt"),
    }
    settings = {}
    for name, spec in SETTINGS.items():
        train_counts = cic_counts if spec.dataset == "cic" else nsl_train
        test_counts = cic_counts if spec.dataset == "cic" else nsl_test
        train_families = (spec.benign_label, *spec.known_families)
        test_families = (spec.benign_label, *spec.known_families, *spec.unknown_families)
        train_role = _role_report(train_counts, train_families)
        test_role = _role_report(test_counts, test_families)
        joint_deficits = {}
        if spec.dataset == "cic":
            # CIC supplies one original pool, not independent train/test files.
            demand = Counter(train_families) + Counter(test_families)
            joint_deficits = {family: occurrences * MIN_UNIQUE_ROWS_PER_FAMILY - cic_counts.get(family, 0)
                              for family, occurrences in sorted(demand.items())
                              if cic_counts.get(family, 0) < occurrences * MIN_UNIQUE_ROWS_PER_FAMILY}
        reasons = []
        if train_role["minimum_family_deficits"]:
            reasons.append("TRAIN_FAMILY_BELOW_MINIMUM")
        if test_role["minimum_family_deficits"]:
            reasons.append("TEST_FAMILY_BELOW_MINIMUM")
        if joint_deficits:
            reasons.append("SHARED_POOL_DISJOINT_ROLE_DEMAND_UNMET")
        if spec.dataset == "cic":
            reasons.append("INDEPENDENT_TRAIN_TEST_CAPTURE_NOT_ESTABLISHED")
            if (session_evidence is not None
                    and session_evidence["same_capture_five_tuple_groups"] == 1
                    and session_evidence["distinct_raw_syn_origin_sequence_pairs"] <= 1):
                reasons.append("HEARTBLEED_SEGMENTS_SHARE_AT_MOST_ONE_OBSERVED_TCP_START")
            if (session_evidence is not None
                    and session_evidence["source_directional_packet_totals_equal"] is not True):
                reasons.append("HEARTBLEED_SOURCE_PACKET_COUNTS_NOT_EXACTLY_BRIDGED")
        else:
            # Row files have no verified capture/event IDs.  Different file
            # names alone do not certify one-time campaign independence.
            reasons.append("PHYSICAL_EVENT_IDENTITY_NOT_VERIFIED")
        settings[name] = {
            "train": train_role, "test": test_role,
            "shared_pool_disjoint_minimum_deficits": joint_deficits,
            "preflight_status": "protocol_stop" if reasons else "ready_for_identity_audit",
            "reasons": reasons,
            "training_started": False, "final_test_executed": False,
        }
    return {
        "audit_type": "original_source_proportional_cohort_preflight",
        "count_interpretation": "source record counts are upper bounds, not verified unique physical flows or events; reported shortages are lower bounds",
        "limits": {"maximum_rows_per_train_or_test": MAX_ROWS_PER_ROLE,
                   "minimum_unique_rows_per_family_per_role": MIN_UNIQUE_ROWS_PER_FAMILY,
                   "sampling": "constrained_proportional_without_replacement"},
        "label_access_scope": "aggregate_preflight_only_not_model_fit_or_threshold_selection",
        "sources": {"cic_original_pool": cic_assets,
                    "nsl_original_train": nsl_train_asset,
                    "nsl_original_test": nsl_test_asset,
                    "nsl_original_train_mirror_check": nsl_train_mirror},
        "historical_sample_assets_not_formal_cohorts": legacy_assets,
        "heartbleed_source_session_evidence": session_evidence,
        "source_family_counts": {
            "cic_original_pool": dict(sorted(cic_counts.items())),
            "nsl_original_train": dict(sorted(nsl_train.items())),
            "nsl_original_test": dict(sorted(nsl_test.items())),
        },
        "settings": settings,
        "target99_status": "FAIL_TARGET99", "published": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--heartbleed-session-audit", type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f"preflight report must be new: {args.output}")
    report = audit_sources(args.workspace, heartbleed_session_audit=args.heartbleed_session_audit)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x", encoding="utf-8") as destination:
        json.dump(report, destination, ensure_ascii=False, indent=2)
        destination.write("\n")
    print(json.dumps({name: data["reasons"] for name, data in report["settings"].items()},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
