from __future__ import annotations

import hashlib
import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from .config import CIC_FEATURE_COLUMNS, NSL_FEATURE_COLUMNS, ExperimentSpec
from .nsl_duration_enrichment import ENRICHED_COLUMNS, enrich_sample_frames
from .proportional_source_preflight import (
    MAX_ROWS_PER_ROLE, MIN_UNIQUE_ROWS_PER_FAMILY, proportional_quotas,
)


CIC_COLUMNS = CIC_FEATURE_COLUMNS + ("label",)
NSL_COLUMNS = NSL_FEATURE_COLUMNS + ("label", "difficulty_level")


class MissingOpenEvaluationFamilyError(ValueError):
    """A declared Table-1 family has no physical row in the held-out source."""


class OpenEvaluationRowCapError(ValueError):
    """The raw evaluation cohort cannot satisfy the reporting floor within cap."""


class KnownSourceCohortError(ValueError):
    """Known source rows cannot form a capped Table-1 training cohort."""


@dataclass
class DataBundle:
    spec: ExperimentSpec
    train_path: Path
    test_path: Path
    x_fit: np.ndarray
    x_validation: np.ndarray
    x_open_test: np.ndarray
    y_fit_coarse: np.ndarray
    y_validation_coarse: np.ndarray
    y_open_test_coarse: np.ndarray
    y_fit_fine: np.ndarray
    y_validation_fine: np.ndarray
    y_open_test_fine_text: np.ndarray
    y_open_evaluation_coarse: np.ndarray
    y_open_evaluation_fine_text: np.ndarray
    validation_ids: np.ndarray
    open_test_ids: np.ndarray
    open_test_source: np.ndarray
    open_evaluation_indices: np.ndarray
    open_evaluation_ids: np.ndarray
    open_evaluation_raw_ids: np.ndarray
    open_evaluation_bootstrap_copy_index: np.ndarray
    open_evaluation_source_multiplicity: np.ndarray
    open_evaluation_is_bootstrap: np.ndarray
    preprocessor: Any
    selector: SelectKBest
    variance_mask: np.ndarray
    selected_feature_names: tuple[str, ...]
    fine_classes: tuple[str, ...]
    audit: dict[str, Any]
    # Explicit known-only roles.  ``x_validation`` / ``y_validation_*`` /
    # ``validation_ids`` above remain checkpoint-role aliases so existing
    # callers continue to run while the runner is migrated to consume the
    # separate calibration role.
    x_checkpoint: np.ndarray
    x_calibration: np.ndarray
    y_checkpoint_coarse: np.ndarray
    y_calibration_coarse: np.ndarray
    y_checkpoint_fine: np.ndarray
    y_calibration_fine: np.ndarray
    fit_ids: np.ndarray
    checkpoint_ids: np.ndarray
    calibration_ids: np.ndarray
    fit_fingerprints: np.ndarray
    checkpoint_fingerprints: np.ndarray
    calibration_fingerprints: np.ndarray
    open_test_fingerprints: np.ndarray
    open_test_roles: np.ndarray


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_source(spec: ExperimentSpec, path: Path, source: str) -> pd.DataFrame:
    if not path.is_file():
        raise FileNotFoundError(
            f"{spec.name}: missing dataset file {path}. Populate the paper data directory first."
        )
    names = CIC_COLUMNS if spec.dataset == "cic" else NSL_COLUMNS
    # With names=..., pandas can silently turn an extra leading field into
    # an index, or pad a short record with NaN. Check every record before
    # assigning names so malformed inputs cannot shift features or labels.
    with path.open("r", encoding="utf-8-sig", newline="") as source_handle:
        reader = csv.reader(source_handle, strict=True)
        records = 0
        for row in reader:
            if not row:  # Match pandas' default skip_blank_lines behavior.
                continue
            records += 1
            if len(row) != len(names):
                raise ValueError(
                    f"{spec.name}: {path}:{reader.line_num} has {len(row)} "
                    f"fields; expected {len(names)}"
                )
        if records == 0:
            raise ValueError(f"{spec.name}: empty dataset file {path}")
    frame = pd.read_csv(path, header=None, names=names, low_memory=False)
    if frame.shape[1] != len(names):
        raise ValueError(
            f"{spec.name}: {path} has {frame.shape[1]} columns; expected {len(names)}"
        )
    frame["_source"] = source
    frame["_source_row"] = np.arange(len(frame), dtype=np.int64)
    return frame


def _normalize_label(spec: ExperimentSpec, label: object) -> str:
    value = str(label)
    cic_aliases = {
        "Web Attack   XSS": "Web Attack - XSS",
        "Web Attack   Sql Injection": "Web Attack - Sql Injection",
    }
    if spec.dataset == "cic":
        return cic_aliases.get(value, value)
    if value.endswith("."):
        base = value[:-1]
        allowed = {
            spec.benign_label,
            *spec.known_families,
            *spec.unknown_families,
            *spec.excluded_families,
        }
        if base in allowed:
            return base
    return value


def _assign_scope(spec: ExperimentSpec, label: str) -> str:
    if label == spec.benign_label:
        return "BEN"
    if label in spec.known_families:
        return "KNA"
    if label in spec.unknown_families:
        return "UNA"
    if label in spec.excluded_families:
        return "EXCLUDED"
    return "UNDECLARED"


def _feature_fingerprint(frame: pd.DataFrame, feature_columns: tuple[str, ...]) -> pd.Series:
    text = frame.loc[:, feature_columns].astype(str)
    values = pd.util.hash_pandas_object(text, index=False).to_numpy(dtype=np.uint64)
    return pd.Series([f"{value:016x}" for value in values], index=frame.index)


KNOWN_ROLE_ORDER = ("fit", "checkpoint", "calibration", "open_known")


def _largest_remainder_counts(total: int, weights: dict[str, float]) -> dict[str, int]:
    """Allocate *total* deterministically while preserving the exact sum."""

    if total < 0:
        raise ValueError("total must be non-negative")
    weight_sum = float(sum(weights.values()))
    if weight_sum <= 0.0:
        raise ValueError("role weights must have a positive sum")
    ideals = {
        role: total * float(weights[role]) / weight_sum for role in KNOWN_ROLE_ORDER
    }
    counts = {role: int(np.floor(ideals[role])) for role in KNOWN_ROLE_ORDER}
    remainder = total - sum(counts.values())
    ranked = sorted(
        KNOWN_ROLE_ORDER,
        key=lambda role: (-(ideals[role] - counts[role]), KNOWN_ROLE_ORDER.index(role)),
    )
    for role in ranked[:remainder]:
        counts[role] += 1
    return counts


def _known_role_mapping(
    frame: pd.DataFrame,
    *,
    seed: int,
    validation_fraction: float,
    open_known_fraction: float,
    group_column: str = "_fingerprint",
) -> tuple[dict[str, str], dict[str, Any]]:
    """Assign indivisible groups to four known-only roles.

    By default groups are exact feature fingerprints.  A verified source
    identity index may instead supply session groups; no session is then
    divided between training, checkpoint, calibration and open-known roles.
    """

    if not 0.0 < validation_fraction < 1.0:
        raise ValueError("validation_fraction must be between zero and one")
    if not 0.0 < open_known_fraction < 1.0:
        raise ValueError("open_known_fraction must be between zero and one")
    checkpoint_fraction = validation_fraction / 2.0
    calibration_fraction = validation_fraction - checkpoint_fraction
    fit_fraction = 1.0 - validation_fraction - open_known_fraction
    if fit_fraction <= 0.0:
        raise ValueError(
            "validation_fraction + open_known_fraction must be less than one"
        )
    fractions = {
        "fit": fit_fraction,
        "checkpoint": checkpoint_fraction,
        "calibration": calibration_fraction,
        "open_known": open_known_fraction,
    }

    if group_column not in frame:
        raise ValueError(f"missing known-role group column: {group_column}")
    if frame[group_column].isna().any():
        raise ValueError(f"known-role group column contains missing values: {group_column}")
    grouped = frame.groupby(group_column, sort=True)["_fine_label"].agg(
        lambda values: tuple(sorted(set(str(value) for value in values)))
    )
    strata: dict[tuple[str, ...], list[str]] = {}
    for fingerprint, labels in grouped.items():
        strata.setdefault(labels, []).append(str(fingerprint))

    mapping: dict[str, str] = {}
    stratum_audit: dict[str, Any] = {}
    for labels in sorted(strata):
        fingerprints = sorted(
            strata[labels],
            key=lambda value: hashlib.sha256(
                f"{seed}|{'|'.join(labels)}|{value}".encode("utf-8")
            ).hexdigest(),
        )
        # When a stratum has at least four distinct vectors, reserve one for
        # each role first.  This matters for very small Table-1 families such
        # as NSL-KDD Setting2/xsnoop (four unique vectors).
        counts = {role: 0 for role in KNOWN_ROLE_ORDER}
        if len(fingerprints) >= len(KNOWN_ROLE_ORDER):
            counts = {role: 1 for role in KNOWN_ROLE_ORDER}
            extra = _largest_remainder_counts(
                len(fingerprints) - len(KNOWN_ROLE_ORDER), fractions
            )
            counts = {role: counts[role] + extra[role] for role in KNOWN_ROLE_ORDER}
        elif len(fingerprints) == 3:
            counts.update({"fit": 1, "checkpoint": 1, "open_known": 1})
        elif len(fingerprints) == 2:
            counts.update({"fit": 1, "open_known": 1})
        elif len(fingerprints) == 1:
            # A one-vector known stratum cannot simultaneously be learned and
            # evaluated without exact-vector leakage.  Keep it fit-only; the
            # family-level coverage assertion below raises if this leaves an
            # entire declared known family absent from open-known evaluation.
            counts["fit"] = 1

        cursor = 0
        for role in KNOWN_ROLE_ORDER:
            stop = cursor + counts[role]
            for fingerprint in fingerprints[cursor:stop]:
                mapping[fingerprint] = role
            cursor = stop
        if cursor != len(fingerprints):
            raise AssertionError("known-role allocation did not consume its stratum")
        if group_column == "_fingerprint":
            stratum_audit["|".join(labels)] = {
                "unique_fingerprints": len(fingerprints),
                "role_unique_fingerprints": counts,
            }
        else:
            stratum_audit["|".join(labels)] = {
                "unique_groups": len(fingerprints),
                "role_unique_groups": counts,
            }

    if len(mapping) != int(frame[group_column].nunique()):
        raise AssertionError("known-role mapping is incomplete")
    return mapping, {
        "policy": (
            "deterministic_exact_feature_fingerprint_group_split"
            if group_column == "_fingerprint"
            else "deterministic_source_session_group_split"
        ),
        "group_column": group_column,
        "seed": int(seed),
        "fractions": fractions,
        "strata": stratum_audit,
    }


def _build_preprocessor(
    spec: ExperimentSpec,
    feature_columns: tuple[str, ...] | None = None,
) -> ColumnTransformer:
    columns = feature_columns or (
        CIC_FEATURE_COLUMNS if spec.dataset == "cic" else NSL_FEATURE_COLUMNS
    )
    if spec.dataset == "cic":
        numeric = list(columns)
        numeric_pipeline = Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median")),
                ("scaler", StandardScaler()),
            ]
        )
        return ColumnTransformer(
            [("numeric", numeric_pipeline, numeric)],
            remainder="drop",
            verbose_feature_names_out=False,
        )

    categorical = list(NSL_FEATURE_COLUMNS[:3])
    numeric = [column for column in columns if column not in categorical]
    categorical_pipeline = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ]
    )
    numeric_pipeline = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )
    return ColumnTransformer(
        [
            ("categorical", categorical_pipeline, categorical),
            ("numeric", numeric_pipeline, numeric),
        ],
        remainder="drop",
        verbose_feature_names_out=False,
    )


def _coerce_numeric(
    frame: pd.DataFrame,
    spec: ExperimentSpec,
    feature_columns: tuple[str, ...] | None = None,
) -> pd.DataFrame:
    result = frame.copy()
    columns = feature_columns or (
        CIC_FEATURE_COLUMNS if spec.dataset == "cic" else NSL_FEATURE_COLUMNS
    )
    numeric = (
        columns
        if spec.dataset == "cic"
        else tuple(column for column in columns if column not in NSL_FEATURE_COLUMNS[:3])
    )
    for column in numeric:
        result[column] = pd.to_numeric(result[column], errors="coerce")
    result.loc[:, list(numeric)] = result.loc[:, list(numeric)].replace(
        [np.inf, -np.inf], np.nan
    )
    return result


def _deterministic_open_evaluation_resample(
    frame: pd.DataFrame,
    spec: ExperimentSpec,
    *,
    seed: int,
    minimum_family_rows: int = 100,
    maximum_evaluation_rows: int | None = 6000,
    raw_counts_before_overlap: dict[str, int] | None = None,
) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
    """Bootstrap declared attack families for evaluation only.

    The returned object is an index plan, not a feature frame.  The raw open
    set is transformed, inferred, and routed exactly once.  Only after those
    raw predictions are frozen may callers expand predictions and labels with
    this plan for a bootstrap-sensitivity matrix.
    """

    if minimum_family_rows < 1:
        raise ValueError("minimum_family_rows must be positive")
    if maximum_evaluation_rows is not None and maximum_evaluation_rows < 1:
        raise ValueError("maximum_evaluation_rows must be positive")

    raw_frame = frame.copy().reset_index(drop=True)
    raw_ids = raw_frame["_sample_id"].astype(str).tolist()
    evaluation_indices = list(range(len(raw_frame)))
    evaluation_ids = raw_ids.copy()
    evaluation_raw_ids = raw_ids.copy()
    evaluation_copy_indices = [0] * len(raw_frame)
    evaluation_is_bootstrap = [False] * len(raw_frame)
    declared_families = spec.known_families + spec.unknown_families

    missing_families = [
        family for family in declared_families
        if not raw_frame["_label"].eq(family).any()
    ]
    if missing_families:
        raise MissingOpenEvaluationFamilyError(
            f"{spec.name}: declared Table-1 families have no raw "
            f"open-evaluation rows: {missing_families}; bootstrap cannot "
            "create a missing physical family"
        )

    raw_family_counts = raw_frame["_label"].value_counts().to_dict()

    def _expanded_size(floor: int) -> int:
        return len(raw_frame) + sum(
            max(0, floor - int(raw_family_counts[family]))
            for family in declared_families
        )

    # This bootstrap is a sensitivity view, not extra physical traffic.  Do
    # not trim the raw open test or silently let repeated rows exceed the
    # user-facing per-test cap.  If even the 20-row reporting floor cannot fit,
    # a separate, predeclared raw-cohort selection is required instead.
    if maximum_evaluation_rows is None:
        # Explicit read-only replay of a previously frozen index.  New runs
        # never use this branch; it exists to verify the original bytes.
        effective_family_rows = minimum_family_rows
    else:
        minimum_reporting_floor = min(20, minimum_family_rows)
        if _expanded_size(minimum_reporting_floor) > maximum_evaluation_rows:
            raise OpenEvaluationRowCapError(
                f"{spec.name}: raw open evaluation plus bootstrap to "
                f"{minimum_reporting_floor} total rows per family exceeds "
                f"{maximum_evaluation_rows}; "
                "select a smaller raw cohort before evaluation"
            )
        low, high = minimum_reporting_floor, minimum_family_rows
        while low < high:
            middle = (low + high + 1) // 2
            if _expanded_size(middle) <= maximum_evaluation_rows:
                low = middle
            else:
                high = middle - 1
        effective_family_rows = low

    for family in declared_families:
        family_rows = raw_frame[raw_frame["_label"].eq(family)]
        needed = max(0, effective_family_rows - len(family_rows))
        if needed == 0:
            continue

        ranked_indices = sorted(
            family_rows.index.to_list(),
            key=lambda index: hashlib.sha256(
                (
                    f"{seed}|{spec.name}|{family}|"
                    f"{family_rows.at[index, '_sample_id']}"
                ).encode("utf-8")
            ).hexdigest(),
        )
        parent_copy_counts = {
            str(raw_id): 0 for raw_id in family_rows["_sample_id"].tolist()
        }
        for offset in range(needed):
            source_index = ranked_indices[offset % len(ranked_indices)]
            raw_id = str(raw_frame.at[source_index, "_sample_id"])
            parent_copy_counts[raw_id] += 1
            copy_index = parent_copy_counts[raw_id]
            evaluation_indices.append(int(source_index))
            evaluation_raw_ids.append(raw_id)
            evaluation_copy_indices.append(copy_index)
            evaluation_is_bootstrap.append(True)
            evaluation_ids.append(f"{raw_id}::bootstrap:{copy_index:04d}")

    if len(set(evaluation_ids)) != len(evaluation_ids):
        duplicates = pd.Series(evaluation_ids)[pd.Series(evaluation_ids).duplicated()].tolist()
        raise ValueError(f"{spec.name}: non-unique evaluation sample ids: {duplicates[:3]}")
    if maximum_evaluation_rows is not None and len(evaluation_ids) > maximum_evaluation_rows:
        raise AssertionError(f"{spec.name}: evaluation bootstrap exceeded row cap")

    raw_id_counts = pd.Series(evaluation_raw_ids, dtype="object").value_counts()
    evaluation_source_multiplicity = [
        int(raw_id_counts[raw_id]) for raw_id in evaluation_raw_ids
    ]
    index_array = np.asarray(evaluation_indices, dtype=np.int64)

    family_audit: dict[str, dict[str, Any]] = {}
    for family in declared_families:
        raw_family_rows = raw_frame[raw_frame["_label"].eq(family)]
        family_raw_ids = set(raw_family_rows["_sample_id"].astype(str).tolist())
        family_eval_positions = [
            position
            for position, raw_id in enumerate(evaluation_raw_ids)
            if raw_id in family_raw_ids
        ]
        family_eval_raw_ids = [evaluation_raw_ids[position] for position in family_eval_positions]
        family_eval_bootstrap = [
            evaluation_is_bootstrap[position] for position in family_eval_positions
        ]
        multiplicities = pd.Series(family_eval_raw_ids, dtype="object").value_counts()
        histogram = {
            str(int(value)): int(count)
            for value, count in multiplicities.value_counts().sort_index().items()
        }
        raw_count = int(len(raw_family_rows))
        bootstrap_rows = int(sum(family_eval_bootstrap))
        resampled_count = int(len(family_eval_positions))
        if resampled_count < effective_family_rows:
            raise AssertionError(
                f"{spec.name}: {family} has only {resampled_count} evaluation rows"
            )
        family_audit[family] = {
            "scope": "KNA" if family in spec.known_families else "UNA",
            "raw_count_before_overlap_filter": int(
                (raw_counts_before_overlap or {}).get(family, raw_count)
            ),
            "raw_count": raw_count,
            "raw_unique_rows": int(raw_family_rows["_sample_id"].nunique()),
            "raw_unique_feature_rows": int(raw_family_rows["_fingerprint"].nunique()),
            "bootstrap_rows": bootstrap_rows,
            "resampled_count": resampled_count,
            "multiplicity": {
                "minimum": int(multiplicities.min()),
                "maximum": int(multiplicities.max()),
                "mean": float(multiplicities.mean()),
                "histogram": histogram,
            },
        }

    audit = {
        "policy": "deterministic_with_replacement_for_declared_non_benign_families",
        "minimum_rows_per_declared_non_benign_family": int(effective_family_rows),
        "requested_bootstrap_rows_per_declared_non_benign_family": int(minimum_family_rows),
        "bootstrap_floor_reduced_for_row_cap": effective_family_rows < minimum_family_rows,
        "maximum_evaluation_rows": (
            int(maximum_evaluation_rows) if maximum_evaluation_rows is not None else None
        ),
        "row_cap_met": (
            len(evaluation_ids) <= maximum_evaluation_rows
            if maximum_evaluation_rows is not None else None
        ),
        "seed": int(seed),
        "evaluation_only": True,
        "used_for_fit": False,
        "used_for_validation": False,
        "used_for_preprocessing_fit": False,
        "used_for_checkpoint_or_threshold_selection": False,
        "used_for_inference": False,
        "used_for_dvc_routing": False,
        "raw_unique_rows": int(raw_frame["_sample_id"].nunique()),
        "bootstrap_rows": int(sum(evaluation_is_bootstrap)),
        "resampled_rows": int(len(evaluation_ids)),
        "family_counts": family_audit,
        "interpretation": (
            "Bootstrap rows reuse raw flows with replacement; they are not new "
            "independent traffic observations."
        ),
    }
    plan = {
        "indices": index_array,
        "evaluation_ids": np.asarray(evaluation_ids, dtype=str),
        "raw_ids": np.asarray(evaluation_raw_ids, dtype=str),
        "bootstrap_copy_index": np.asarray(evaluation_copy_indices, dtype=np.int64),
        "source_multiplicity": np.asarray(
            evaluation_source_multiplicity, dtype=np.int64
        ),
        "is_bootstrap": np.asarray(evaluation_is_bootstrap, dtype=bool),
    }
    return plan, audit


def _cap_known_source_pool(
    known: pd.DataFrame, spec: ExperimentSpec, *, seed: int,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Cap source-train BEN/KNA rows before role splitting, without copies.

    The quota is proportional to source family row counts with a 20-row
    minimum.  Repeated source feature vectors remain repeated *rows* and are
    disclosed separately; this does not certify 20 physical flows/events.
    """

    families = ("BEN", *spec.known_families)
    if known.empty or known["_sample_id"].isna().any() or known["_sample_id"].duplicated().any():
        raise ValueError(f"{spec.name}: known source row identities are missing or repeated")
    if set(known["_fine_label"]) != set(families):
        raise ValueError(f"{spec.name}: known source family set differs from Table 1")
    counts = {
        family: int(known["_fine_label"].eq(family).sum())
        for family in families
    }
    try:
        quotas = proportional_quotas(
            counts, maximum_rows=MAX_ROWS_PER_ROLE,
            minimum_family_rows=MIN_UNIQUE_ROWS_PER_FAMILY,
        )
    except ValueError as exc:
        raise KnownSourceCohortError(
            f"{spec.name}: no capped BEN/KNA source cohort: {exc}"
        ) from exc
    if len(known) <= MAX_ROWS_PER_ROLE:
        selected = known.copy()
    else:
        ranked = known.copy()
        ranked["_cohort_rank"] = ranked["_sample_id"].map(
            lambda sample_id: hashlib.sha256(
                f"{seed}|{spec.name}|known-source-cap|{sample_id}".encode("utf-8")
            ).hexdigest()
        )
        ranked = ranked.sort_values(["_cohort_rank", "_sample_id"], kind="stable")
        selected = pd.concat([
            ranked.loc[ranked["_fine_label"].eq(family)].head(quota)
            for family, quota in sorted(quotas.items())
        ], ignore_index=True).drop(columns="_cohort_rank")
    if (len(selected) > MAX_ROWS_PER_ROLE
            or selected["_sample_id"].duplicated().any()
            or any(int(selected["_fine_label"].eq(family).sum()) != quota
                   for family, quota in quotas.items())):
        raise AssertionError(f"{spec.name}: known source cohort cap violated")
    return selected, {
        "policy": "source_train_family_proportional_no_replacement",
        "maximum_known_source_rows": MAX_ROWS_PER_ROLE,
        "minimum_selected_source_rows_per_family": MIN_UNIQUE_ROWS_PER_FAMILY,
        "source_rows_by_family": counts,
        "selected_rows_by_family": quotas,
        "source_known_rows": int(len(known)),
        "selected_known_rows": int(len(selected)),
        "selected_unique_feature_vectors_by_family": {
            family: int(selected.loc[selected["_fine_label"].eq(family),
                                     "_fingerprint"].nunique())
            for family in families
        },
        "source_rows_are_not_verified_independent_physical_flows": True,
        "sampling_uses_target_or_source_test_labels": False,
        "bootstrap_or_replacement_rows_added": 0,
        "selected_sample_id_set_sha256": hashlib.sha256(
            "\n".join(sorted(selected["_sample_id"].astype(str))).encode("utf-8")
        ).hexdigest(),
    }


def _cap_open_source_cohort(
    open_frame: pd.DataFrame, spec: ExperimentSpec, *, seed: int,
    maximum_rows: int = MAX_ROWS_PER_ROLE, reporting_floor: int = 20,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Predeclare a no-replacement open cohort before any model prediction.

    This label-stratified *development benchmark construction* preserves every
    available rare source row up to the reporting floor, then allocates the
    remaining raw-row budget proportionally.  Source row IDs are not verified
    physical sessions, and the evaluation-only bootstrap never adds evidence.
    """

    if maximum_rows < 1 or reporting_floor < 1:
        raise ValueError("open cohort limits must be positive")
    families = (spec.benign_label, *spec.known_families, *spec.unknown_families)
    if (open_frame.empty or open_frame["_sample_id"].isna().any()
            or open_frame["_sample_id"].duplicated().any()):
        raise ValueError(f"{spec.name}: open source row identities are missing or repeated")
    counts = {family: int(open_frame["_label"].eq(family).sum()) for family in families}
    missing = [family for family, count in counts.items() if count == 0]
    if missing:
        raise MissingOpenEvaluationFamilyError(
            f"{spec.name}: declared Table-1 families have no raw "
            f"open-evaluation rows: {missing}; bootstrap cannot "
            "create a missing physical family"
        )
    if set(open_frame["_label"]) != set(families):
        raise ValueError(f"{spec.name}: open source family set differs from Table 1")

    # All existing rare attack rows below the reporting floor are protected.
    # Their exact shortfall is the only bootstrap reserve needed at floor 20.
    attack_families = spec.known_families + spec.unknown_families
    reserve = sum(max(0, reporting_floor - counts[family])
                  for family in attack_families)
    raw_budget = maximum_rows - reserve
    protected = {family: min(reporting_floor, count)
                 for family, count in counts.items()}
    if raw_budget < sum(protected.values()):
        raise OpenEvaluationRowCapError(
            f"{spec.name}: protected original family rows and evaluation-only "
            f"bootstrap cannot fit within {maximum_rows} rows"
        )

    if len(open_frame) <= raw_budget:
        quotas = counts.copy()
        selected = open_frame.copy()
    else:
        spare = {family: counts[family] - protected[family] for family in families}
        capacity = raw_budget - sum(protected.values())
        total_spare = sum(spare.values())
        if total_spare < capacity:
            raise AssertionError("open cohort spare rows below requested capacity")
        ideals = {family: capacity * spare[family] / total_spare
                  for family in families}
        extra = {family: int(np.floor(ideals[family])) for family in families}
        remaining = capacity - sum(extra.values())
        for family in sorted(families, key=lambda name: (
                -(ideals[name] - extra[name]), name)):
            if remaining == 0:
                break
            if extra[family] < spare[family]:
                extra[family] += 1
                remaining -= 1
        if remaining:
            raise AssertionError("open cohort proportional allocation incomplete")
        quotas = {family: protected[family] + extra[family] for family in families}
        ranked = open_frame.assign(_cohort_rank=open_frame["_sample_id"].map(
            lambda sample_id: hashlib.sha256(
                f"{seed}|{spec.name}|open-source-cap|{sample_id}".encode("utf-8")
            ).hexdigest()
        )).sort_values(["_cohort_rank", "_sample_id"], kind="stable")
        chosen_ids = set(pd.concat([
            ranked.loc[ranked["_label"].eq(family), "_sample_id"].head(quota)
            for family, quota in quotas.items()
        ]).astype(str))
        # Preserve source order so transductive DVC never sees class-sorted input.
        selected = open_frame.loc[
            open_frame["_sample_id"].astype(str).isin(chosen_ids)
        ].copy()

    if (len(selected) > maximum_rows or len(selected) > raw_budget
            or selected["_sample_id"].duplicated().any()
            or any(int(selected["_label"].eq(family).sum()) != quota
                   for family, quota in quotas.items())):
        raise AssertionError(f"{spec.name}: open source cohort cap violated")
    return selected, {
        "policy": "preprediction_family_proportional_no_replacement_development_cohort",
        "maximum_open_evaluation_rows": int(maximum_rows),
        "minimum_reporting_floor": int(reporting_floor),
        "bootstrap_rows_reserved_at_reporting_floor": int(reserve),
        "raw_row_budget": int(raw_budget),
        "source_rows_by_family": counts,
        "selected_rows_by_family": quotas,
        "source_open_rows": int(len(open_frame)),
        "selected_open_rows": int(len(selected)),
        "family_original_rows_below_20": {
            family: counts[family] for family in families
            if counts[family] < 20
        },
        "source_rows_are_not_verified_independent_physical_flows": True,
        "target_labels_used_only_for_predeclared_cohort_composition": True,
        "used_for_fit_or_threshold_selection": False,
        "bootstrap_or_replacement_rows_added": 0,
        "selected_sample_id_set_sha256": hashlib.sha256(
            "\n".join(sorted(selected["_sample_id"].astype(str))).encode("utf-8")
        ).hexdigest(),
    }


def prepare_data(
    workspace: Path,
    spec: ExperimentSpec,
    *,
    seed: int,
    validation_fraction: float = 0.20,
    open_known_fraction: float = 0.10,
    feature_top_k: int = 32,
    nsl_duration_full_paths: tuple[Path, Path] | None = None,
    split_policy: str = "legacy_pooled",
    historical_bootstrap_replay: bool = False,
    evaluation_family_floor: int = 20,
) -> DataBundle:
    if type(evaluation_family_floor) is not int or not 20 <= evaluation_family_floor <= 6000:
        raise ValueError("evaluation_family_floor must be an integer from 20 to 6000")
    if split_policy not in {
        "legacy_pooled", "train_file_holdout", "train_known_dev_unknown",
    }:
        raise ValueError(f"unsupported data split policy: {split_policy}")
    train_path, test_path = spec.data_paths(workspace)
    raw_train = _read_source(spec, train_path, "source_train")
    raw_test = _read_source(spec, test_path, "source_test")
    feature_columns = CIC_FEATURE_COLUMNS if spec.dataset == "cic" else NSL_FEATURE_COLUMNS
    duration_enrichment_audit: dict[str, Any] | None = None
    if nsl_duration_full_paths is not None:
        if spec.dataset != "nsl_kdd":
            raise ValueError("duration enrichment is valid only for NSL-KDD")
        enriched, duration_enrichment_audit = enrich_sample_frames(
            (raw_train, raw_test), full_paths=nsl_duration_full_paths
        )
        raw_train, raw_test = enriched
        feature_columns = NSL_FEATURE_COLUMNS + ENRICHED_COLUMNS

    for frame in (raw_train, raw_test):
        frame["_label"] = frame["label"].map(lambda value: _normalize_label(spec, value))
        frame["_scope"] = frame["_label"].map(lambda value: _assign_scope(spec, value))
        frame["_fine_label"] = np.where(
            frame["_scope"].eq("BEN"), "BEN", frame["_label"]
        )
        frame["_fingerprint"] = _feature_fingerprint(frame, feature_columns)
        frame["_sample_id"] = (
            spec.dataset
            + ":"
            + frame["_source"].astype(str)
            + ":"
            + frame["_source_row"].astype(str)
            + ":"
            + frame["_fingerprint"]
        )

    undeclared = sorted(
        set(raw_train.loc[raw_train["_scope"].eq("UNDECLARED"), "_label"])
        | set(raw_test.loc[raw_test["_scope"].eq("UNDECLARED"), "_label"])
    )
    if undeclared:
        raise ValueError(f"{spec.name}: undeclared source labels: {undeclared}")

    if split_policy == "legacy_pooled":
        pooled = pd.concat([raw_train, raw_test], ignore_index=True)
        known_pool = pooled[pooled["_scope"].isin(["BEN", "KNA"])].copy()
        target_unknown = pooled[pooled["_scope"].eq("UNA")].copy()
    else:
        # A development-only file holdout: no row from source_test can enter
        # fit, checkpoint, calibration, preprocessing fit, or thresholds.
        # CIC2017's original files still share physical events, so this is
        # never proof of an independent final test by itself.
        known_pool = raw_train[raw_train["_scope"].isin(["BEN", "KNA"])].copy()
        if split_policy == "train_file_holdout":
            target_unknown = raw_test[raw_test["_scope"].eq("UNA")].copy()
        else:
            target_unknown = pd.concat([
                raw_train[raw_train["_scope"].eq("UNA")],
                raw_test[raw_test["_scope"].eq("UNA")],
            ], ignore_index=True)

    known_source_cohort_audit = None
    if split_policy != "legacy_pooled":
        known_pool, known_source_cohort_audit = _cap_known_source_pool(
            known_pool, spec, seed=seed,
        )

    role_mapping, known_role_audit = _known_role_mapping(
        known_pool,
        seed=seed,
        validation_fraction=validation_fraction,
        open_known_fraction=open_known_fraction,
    )
    known_pool["_role"] = known_pool["_fingerprint"].map(role_mapping)
    if known_pool["_role"].isna().any():
        raise AssertionError(f"{spec.name}: known role assignment is incomplete")

    fit_frame = known_pool[known_pool["_role"].eq("fit")].copy()
    checkpoint_frame = known_pool[known_pool["_role"].eq("checkpoint")].copy()
    calibration_frame = known_pool[known_pool["_role"].eq("calibration")].copy()
    internal_open_known_frame = known_pool[known_pool["_role"].eq("open_known")].copy()
    if split_policy == "legacy_pooled":
        open_known_frame = internal_open_known_frame
    else:
        open_known_frame = raw_test[raw_test["_scope"].isin(["BEN", "KNA"])].copy()
        open_known_frame["_role"] = "open_known"
    target_unknown["_role"] = "target_una"
    if split_policy == "legacy_pooled":
        open_test = pd.concat([open_known_frame, target_unknown], ignore_index=True)
    elif split_policy == "train_file_holdout":
        # Keep the original file order; constructing an open batch by true
        # class would let labels influence transductive DVC tie/order effects.
        open_test = raw_test[raw_test["_scope"].isin(["BEN", "KNA", "UNA"])].copy()
        open_test["_role"] = np.where(
            open_test["_scope"].eq("UNA"), "target_una", "open_known"
        )
    else:
        # Development-only rescue for Table-1 families absent from the
        # original test file.  These source_train UNA rows never enter known
        # fitting or selection, but their target labels are not a sealed
        # once-only test and must not be used to tune the route.
        open_test = pd.concat([
            raw_train[raw_train["_scope"].eq("UNA")],
            raw_test[raw_test["_scope"].isin(["BEN", "KNA", "UNA"])],
        ], ignore_index=True)
        open_test["_role"] = np.where(
            open_test["_scope"].eq("UNA"), "target_una", "open_known"
        )

    raw_open_family_counts = {
        label: int((open_test["_label"] == label).sum())
        for label in (spec.benign_label,) + spec.known_families + spec.unknown_families
    }

    selection_fingerprints = set(
        pd.concat(
            [
                fit_frame["_fingerprint"],
                checkpoint_frame["_fingerprint"],
                calibration_frame["_fingerprint"],
            ],
            ignore_index=True,
        ).astype(str)
    )
    overlap_mask = open_test["_fingerprint"].isin(selection_fingerprints)
    overlap_by_scope = {
        scope: int(np.sum(overlap_mask & open_test["_scope"].eq(scope)))
        for scope in ("BEN", "KNA", "UNA")
    }
    # In the historical pooled policy, known fingerprints were assigned
    # atomically to open_known.  In file-holdout mode, remove *all* matching
    # held-out rows without consulting their labels for the removal decision.
    if split_policy == "legacy_pooled":
        if overlap_by_scope["BEN"] or overlap_by_scope["KNA"]:
            raise AssertionError(f"{spec.name}: known fingerprint crossed role boundary")
        overlap_remove_mask = overlap_mask & open_test["_scope"].eq("UNA")
    else:
        overlap_remove_mask = overlap_mask
    cross_split_overlap_removed = int(overlap_remove_mask.sum())
    if cross_split_overlap_removed:
        open_test = open_test.loc[~overlap_remove_mask].reset_index(drop=True)

    open_rows_after_overlap_before_source_cap = int(len(open_test))
    open_source_cohort_audit = None
    if split_policy != "legacy_pooled" and not historical_bootstrap_replay:
        open_test, open_source_cohort_audit = _cap_open_source_cohort(
            open_test, spec, seed=seed,
        )

    if split_policy in {"train_file_holdout", "train_known_dev_unknown"}:
        source_train_only = all(
            frame["_source"].eq("source_train").all()
            for frame in (fit_frame, checkpoint_frame, calibration_frame)
        )
        open_source_ok = (
            open_test["_source"].eq("source_test")
            | (
                open_test["_source"].eq("source_train")
                & open_test["_scope"].eq("UNA")
                & (split_policy == "train_known_dev_unknown")
            )
        ).all()
        if not source_train_only or not open_source_ok:
            raise AssertionError(f"{spec.name}: known-train role contamination")

    evaluation_plan, resampling_audit = _deterministic_open_evaluation_resample(
        open_test,
        spec,
        seed=seed,
        minimum_family_rows=(100 if historical_bootstrap_replay else evaluation_family_floor),
        maximum_evaluation_rows=(None if historical_bootstrap_replay else 6000),
        raw_counts_before_overlap=raw_open_family_counts,
    )

    fit_frame = fit_frame.reset_index(drop=True)
    checkpoint_frame = checkpoint_frame.reset_index(drop=True)
    calibration_frame = calibration_frame.reset_index(drop=True)
    open_test = open_test.reset_index(drop=True)
    validation_frame = checkpoint_frame

    if (
        fit_frame.empty
        or checkpoint_frame.empty
        or calibration_frame.empty
        or open_test.empty
    ):
        raise ValueError(f"{spec.name}: an experiment split is empty")
    if set(fit_frame["_scope"]) != {"BEN", "KNA"}:
        raise ValueError(f"{spec.name}: fit must contain BEN and KNA only")
    for role, frame in (
        ("fit", fit_frame),
        ("checkpoint", checkpoint_frame),
        ("calibration", calibration_frame),
    ):
        if (frame["_scope"] == "UNA").any():
            raise ValueError(f"{spec.name}: target unknown leaked into {role}")
    if set(open_test["_scope"]) != {"BEN", "KNA", "UNA"}:
        raise ValueError(f"{spec.name}: open test must contain BEN, KNA, and UNA")

    role_fingerprint_sets = {
        "fit": set(fit_frame["_fingerprint"].astype(str)),
        "checkpoint": set(checkpoint_frame["_fingerprint"].astype(str)),
        "calibration": set(calibration_frame["_fingerprint"].astype(str)),
        "open_test": set(open_test["_fingerprint"].astype(str)),
    }
    role_names = tuple(role_fingerprint_sets)
    role_overlap_counts: dict[str, int] = {}
    for left_index, left in enumerate(role_names):
        for right in role_names[left_index + 1 :]:
            count = len(role_fingerprint_sets[left] & role_fingerprint_sets[right])
            role_overlap_counts[f"{left}__{right}"] = int(count)
    if any(role_overlap_counts.values()):
        raise AssertionError(
            f"{spec.name}: exact feature fingerprints cross roles: "
            f"{role_overlap_counts}"
        )

    fit_frame = _coerce_numeric(fit_frame, spec, feature_columns)
    checkpoint_frame = _coerce_numeric(checkpoint_frame, spec, feature_columns)
    calibration_frame = _coerce_numeric(calibration_frame, spec, feature_columns)
    validation_frame = checkpoint_frame
    open_test = _coerce_numeric(open_test, spec, feature_columns)

    fine_classes = ("BEN",) + spec.known_families
    fine_to_index = {label: index for index, label in enumerate(fine_classes)}
    y_fit_fine = fit_frame["_fine_label"].map(fine_to_index).to_numpy(dtype=np.int64)
    y_checkpoint_fine = (
        checkpoint_frame["_fine_label"].map(fine_to_index).to_numpy(dtype=np.int64)
    )
    y_calibration_fine = (
        calibration_frame["_fine_label"].map(fine_to_index).to_numpy(dtype=np.int64)
    )
    y_validation_fine = y_checkpoint_fine
    if (
        np.isnan(y_fit_fine.astype(float)).any()
        or np.isnan(y_checkpoint_fine.astype(float)).any()
        or np.isnan(y_calibration_fine.astype(float)).any()
    ):
        raise ValueError(f"{spec.name}: fine-label encoding failed")

    preprocessor = _build_preprocessor(spec, feature_columns)
    x_fit_all = np.asarray(preprocessor.fit_transform(fit_frame), dtype=np.float32)
    x_checkpoint_all = np.asarray(
        preprocessor.transform(checkpoint_frame), dtype=np.float32
    )
    x_calibration_all = np.asarray(
        preprocessor.transform(calibration_frame), dtype=np.float32
    )
    x_open_test_all = np.asarray(preprocessor.transform(open_test), dtype=np.float32)

    variance_mask = np.var(x_fit_all, axis=0) > 0.0
    if int(np.sum(variance_mask)) < 2:
        raise ValueError(f"{spec.name}: fewer than two non-constant encoded features")
    x_fit_variable = x_fit_all[:, variance_mask]
    x_checkpoint_variable = x_checkpoint_all[:, variance_mask]
    x_calibration_variable = x_calibration_all[:, variance_mask]
    x_open_test_variable = x_open_test_all[:, variance_mask]
    k = min(
        feature_top_k,
        x_fit_variable.shape[1],
    )
    selector = SelectKBest(score_func=f_classif, k=k)
    x_fit = selector.fit_transform(x_fit_variable, y_fit_fine).astype(np.float32)
    x_checkpoint = selector.transform(x_checkpoint_variable).astype(np.float32)
    x_calibration = selector.transform(x_calibration_variable).astype(np.float32)
    x_validation = x_checkpoint
    x_open_test = selector.transform(x_open_test_variable).astype(np.float32)

    if not (
        np.isfinite(x_fit).all()
        and np.isfinite(x_checkpoint).all()
        and np.isfinite(x_calibration).all()
        and np.isfinite(x_open_test).all()
    ):
        raise ValueError(f"{spec.name}: preprocessing produced non-finite values")

    all_feature_names = np.asarray(preprocessor.get_feature_names_out(), dtype=object)
    variable_feature_names = all_feature_names[variance_mask]
    selected_feature_names = tuple(
        variable_feature_names[selector.get_support()].astype(str)
    )

    training_family_counts = {
        label: int((known_pool["_fine_label"] == label).sum())
        for label in fine_classes
    }
    open_test_family_counts = {
        label: int((open_test["_label"] == label).sum())
        for label in (spec.benign_label,) + spec.known_families + spec.unknown_families
    }

    audit = {
        "setting": spec.name,
        "dataset": spec.dataset,
        "split_policy": split_policy,
        "historical_bootstrap_replay_only": historical_bootstrap_replay,
        "source_file_holdout_only_not_independent_final": (
            split_policy == "train_file_holdout"
        ),
        "source_train_una_reused_for_development_only": (
            split_policy == "train_known_dev_unknown"
        ),
        "model_input_feature_columns": list(feature_columns),
        "nsl_duration_enrichment": duration_enrichment_audit,
        "known_source_cohort": known_source_cohort_audit,
        "open_source_cohort": open_source_cohort_audit,
        "source_files": {
            "train": {
                "path": str(train_path),
                "sha256": sha256_file(train_path),
                "rows": int(len(raw_train)),
            },
            "test": {
                "path": str(test_path),
                "sha256": sha256_file(test_path),
                "rows": int(len(raw_test)),
            },
        },
        "table1": {
            "known_families": list(spec.known_families),
            "unknown_families": list(spec.unknown_families),
            "excluded_families": list(spec.excluded_families),
        },
        "split": {
            "fit_rows": int(len(fit_frame)),
            "validation_rows": int(len(validation_frame)),
            "checkpoint_rows": int(len(checkpoint_frame)),
            "calibration_rows": int(len(calibration_frame)),
            "open_known_rows": int(open_test["_role"].eq("open_known").sum()),
            "open_target_una_rows": int(open_test["_role"].eq("target_una").sum()),
            "open_test_rows": int(len(open_test)),
            "fit_unknown_rows": 0,
            "validation_unknown_rows": 0,
            "checkpoint_unknown_rows": 0,
            "calibration_unknown_rows": 0,
            "open_test_raw_rows_after_overlap_filter": (
                open_rows_after_overlap_before_source_cap
            ),
            "open_test_raw_rows_after_source_cap": int(len(open_test)),
            "open_evaluation_rows_after_resampling": int(
                resampling_audit["resampled_rows"]
            ),
            "open_evaluation_bootstrap_rows": int(resampling_audit["bootstrap_rows"]),
            "cross_split_exact_feature_rows_removed": cross_split_overlap_removed,
            "cross_split_exact_feature_rows_detected_by_scope": overlap_by_scope,
            "cross_split_exact_feature_rows_removed_by_scope": {
                scope: (overlap_by_scope[scope] if split_policy != "legacy_pooled"
                        else (cross_split_overlap_removed if scope == "UNA" else 0))
                for scope in ("BEN", "KNA", "UNA")
            },
            "open_target_una_rows_from_source_train": int((
                open_test["_role"].eq("target_una")
                & open_test["_source"].eq("source_train")
            ).sum()),
            "cross_split_source_test_ben_kna_rows_retained": int(
                (
                    open_test["_role"].eq("open_known")
                    & open_test["_source"].eq("source_test")
                ).sum()
            ),
            "validation_fraction": validation_fraction,
            "open_known_fraction": open_known_fraction,
            "seed": seed,
        },
        "known_role_split": {
            **known_role_audit,
            "test_labels_loaded_during_data_preparation": True,
            "test_labels_used_for_fit_preprocessing_or_threshold": False,
            "target_label_scope_used_for_open_cohort_construction": True,
            "test_labels_used_for_evaluation_resampling_plan": True,
            "pooled_known_rows": int(len(known_pool)),
            "pooled_known_unique_fingerprints": int(
                known_pool["_fingerprint"].nunique()
            ),
            "pooled_source_rows": {
                str(source): int(count)
                for source, count in known_pool["_source"].value_counts().items()
            },
            "unused_source_train_open_known_rows": int(
                len(internal_open_known_frame)
                if split_policy == "train_file_holdout" else 0
            ),
            "fit_checkpoint_calibration_source_train_only": all(
                frame["_source"].eq("source_train").all()
                for frame in (fit_frame, checkpoint_frame, calibration_frame)
            ),
            "open_test_source_test_only": bool(
                open_test["_source"].eq("source_test").all()
            ),
            "role_rows": {
                "fit": int(len(fit_frame)),
                "checkpoint": int(len(checkpoint_frame)),
                "calibration": int(len(calibration_frame)),
                "open_known": int(open_test["_role"].eq("open_known").sum()),
            },
            "role_unique_fingerprints": {
                role: int(len(fingerprints))
                for role, fingerprints in role_fingerprint_sets.items()
                if role != "open_test"
            }
            | {
                "open_known": int(
                    open_test.loc[
                        open_test["_role"].eq("open_known"), "_fingerprint"
                    ].nunique()
                )
            },
            "role_source_rows": {
                role: {
                    str(source): int(count)
                    for source, count in frame["_source"].value_counts().items()
                }
                for role, frame in (
                    ("fit", fit_frame),
                    ("checkpoint", checkpoint_frame),
                    ("calibration", calibration_frame),
                    (
                        "open_known",
                        open_test[open_test["_role"].eq("open_known")],
                    ),
                )
            },
            "role_family_rows": {
                role: {
                    label: int(frame["_fine_label"].eq(label).sum())
                    for label in fine_classes
                }
                for role, frame in (
                    ("fit", fit_frame),
                    ("checkpoint", checkpoint_frame),
                    ("calibration", calibration_frame),
                    (
                        "open_known",
                        open_test[open_test["_role"].eq("open_known")],
                    ),
                )
            },
            "exact_fingerprint_overlap_counts_after_una_filter": role_overlap_counts,
            "target_una_role_rows": {
                "fit": 0,
                "checkpoint": 0,
                "calibration": 0,
                "open_test": int(open_test["_scope"].eq("UNA").sum()),
            },
            "target_una_used_for_fit": False,
            "target_una_used_for_checkpoint_selection": False,
            "target_una_used_for_calibration": False,
            "target_una_used_only_for_open_test_scoring": True,
            "legacy_validation_alias": "checkpoint",
        },
        "training_family_counts_before_validation_split": training_family_counts,
        "pooled_known_family_counts_before_role_split": training_family_counts,
        "open_test_family_counts": open_test_family_counts,
        "open_evaluation_resampling": resampling_audit,
        "selected_feature_count": int(x_fit.shape[1]),
        "selected_feature_names": list(selected_feature_names),
    }

    coarse_map = {"BEN": 0, "KNA": 1, "UNA": 2}
    return DataBundle(
        spec=spec,
        train_path=train_path,
        test_path=test_path,
        x_fit=x_fit,
        x_validation=x_validation,
        x_open_test=x_open_test,
        y_fit_coarse=fit_frame["_scope"].map(coarse_map).to_numpy(dtype=np.int64),
        y_validation_coarse=validation_frame["_scope"].map(coarse_map).to_numpy(dtype=np.int64),
        y_open_test_coarse=open_test["_scope"].map(coarse_map).to_numpy(dtype=np.int64),
        y_fit_fine=y_fit_fine,
        y_validation_fine=y_validation_fine,
        y_open_test_fine_text=open_test["_fine_label"].astype(str).to_numpy(),
        y_open_evaluation_coarse=open_test["_scope"].map(coarse_map).to_numpy(
            dtype=np.int64
        )[evaluation_plan["indices"]],
        y_open_evaluation_fine_text=open_test["_fine_label"].astype(str).to_numpy()[
            evaluation_plan["indices"]
        ],
        validation_ids=validation_frame["_sample_id"].astype(str).to_numpy(),
        open_test_ids=open_test["_sample_id"].astype(str).to_numpy(),
        open_test_source=open_test["_source"].astype(str).to_numpy(),
        open_evaluation_indices=evaluation_plan["indices"],
        open_evaluation_ids=evaluation_plan["evaluation_ids"],
        open_evaluation_raw_ids=evaluation_plan["raw_ids"],
        open_evaluation_bootstrap_copy_index=evaluation_plan["bootstrap_copy_index"],
        open_evaluation_source_multiplicity=evaluation_plan["source_multiplicity"],
        open_evaluation_is_bootstrap=evaluation_plan["is_bootstrap"],
        preprocessor=preprocessor,
        selector=selector,
        variance_mask=variance_mask,
        selected_feature_names=selected_feature_names,
        fine_classes=fine_classes,
        audit=audit,
        x_checkpoint=x_checkpoint,
        x_calibration=x_calibration,
        y_checkpoint_coarse=checkpoint_frame["_scope"].map(coarse_map).to_numpy(
            dtype=np.int64
        ),
        y_calibration_coarse=calibration_frame["_scope"].map(coarse_map).to_numpy(
            dtype=np.int64
        ),
        y_checkpoint_fine=y_checkpoint_fine,
        y_calibration_fine=y_calibration_fine,
        fit_ids=fit_frame["_sample_id"].astype(str).to_numpy(),
        checkpoint_ids=checkpoint_frame["_sample_id"].astype(str).to_numpy(),
        calibration_ids=calibration_frame["_sample_id"].astype(str).to_numpy(),
        fit_fingerprints=fit_frame["_fingerprint"].astype(str).to_numpy(),
        checkpoint_fingerprints=checkpoint_frame["_fingerprint"].astype(str).to_numpy(),
        calibration_fingerprints=calibration_frame["_fingerprint"].astype(str).to_numpy(),
        open_test_fingerprints=open_test["_fingerprint"].astype(str).to_numpy(),
        open_test_roles=open_test["_role"].astype(str).to_numpy(),
    )
