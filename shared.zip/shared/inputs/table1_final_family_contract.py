"""Future cropped training/final metadata contract; no data or model access.
Caller must persist final reservation atomically before any final inference.
Partial DEV is a separately declared protocol, not forced to cover Table 1.
"""
from __future__ import annotations
from .paper_scope import PAPER_SCOPE_VERSION, PAPER_SCOPE_SETTINGS, check_paper_scope

SCHEMA = 'canonical-table1-training-final-family20-cap6000-once-v1'
FAMILY_FLOOR, ROW_CAP = 20, 6000

def require(value, reason):
    if not value: raise ValueError(reason)

def is_sha(value):
    return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)

def canonical_families(setting):
    # The public scope check of empty roles exposes the complete missing roster.
    missing = check_paper_scope(setting=setting, known_families=(), unknown_families=())['missing_paper_families_by_role']
    require(check_paper_scope(setting=setting, known_families=missing['known'], unknown_families=missing['unknown'])
            ['complete_paper_scope_verified'], 'canonical paper roster must verify')
    return dict(BEN=('BEN',), KNA=tuple(missing['known']), UNA=tuple(missing['unknown']))

def legacy_scope_diagnostic(setting):
    from .config import get_spec
    spec = get_spec(setting)
    return check_paper_scope(setting=setting, known_families=spec.known_families, unknown_families=spec.unknown_families)

def validate_cohort_counts(setting, phase, family_counts):
    """Counts concern selected originals and effective rows, never source census.
    family_counts[f]={'original':n,'effective':m,'resample_map_sha256':...}.
    BEN is the canonical logical benign family. Floor applies to cropped bundle
    and final; it is not imposed separately on CP/CAL/DEV or unique groups.
    """
    require(phase in ('training', 'final'), 'this contract checks cropped training/final only')
    families = canonical_families(setting)
    roles = ('BEN', 'KNA') if phase == 'training' else ('BEN', 'KNA', 'UNA')
    expected = set().union(*(set(families[role]) for role in roles))
    require(isinstance(family_counts, dict) and set(family_counts) == expected, 'exact complete canonical role families required')
    original = effective = copies = 0
    for family in sorted(expected):
        count = family_counts[family]; n, m = count['original'], count['effective']
        require(type(n) is type(m) is int and 0 < n <= m and m >= FAMILY_FLOOR,
                'positive genuine originals and effective family20:' + family)
        if m > n: require(is_sha(count.get('resample_map_sha256')), 'sealed role-local genuine-source resampling map:' + family)
        original += n; effective += m; copies += m - n
    require(effective <= ROW_CAP, 'cropped row cap6000 includes every resampled row')
    return dict(schema_version=SCHEMA, paper_scope_version=PAPER_SCOPE_VERSION, setting=setting, phase=phase,
                family_count=len(expected), original_rows=original, effective_rows=effective, copies=copies,
                complete_phase_scope=True, complete_paper_final_scope=phase == 'final',
                source_admission_issued=False, final_execution_authorized=False)

def reserve_final_once(cohort, manifest_sha256, audit, state):
    """Check audited evidence; caller atomically saves state before execution.
    This metadata check does not certify source evidence or open final labels.
    Independence scope is declared; family disjointness is not an extra gate.
    """
    require(cohort['schema_version'] == SCHEMA and cohort['phase'] == 'final' and cohort['complete_paper_final_scope'], 'full final counts validated first')
    require(is_sha(manifest_sha256) and audit['manifest_sha256'] == manifest_sha256 and is_sha(audit['audit_sha256']), 'exact sealed cohort/audit binding')
    require(all(audit.get(k) is True for k in ('event_identity_disjoint', 'zero_final_target_selection_leak',
            'model_and_rules_frozen', 'final_label_store_sealed')), 'independent event/selection and frozen final-label audit required')
    require(isinstance(audit.get('declared_independence_scope'), str) and bool(audit['declared_independence_scope']), 'honest independence scope declaration required')
    require(state['setting'] == cohort['setting'] and state['manifest_sha256'] == manifest_sha256
            and type(state['final_execution_count']) is int and state['final_execution_count'] == 0, 'one final execution per frozen setting/cohort')
    state['final_execution_count'] = 1
    return dict(reserved=True, must_persist_atomically_before_final_open=True, source_admission_issued=False, published=False)

def integer99_gates(correct_support):
    require(set(correct_support) == {'BEN', 'KNA', 'UNA'}, 'all three original declared flow classes required')
    gates = {}
    for role, (correct, support) in correct_support.items():
        require(type(correct) is type(support) is int and 0 <= correct <= support and 0 < support <= ROW_CAP, 'honest integer flow counts')
        required = (99 * support + 99) // 100
        gates[role] = dict(correct=correct, support=support, required=required, passed=correct >= required)
    return dict(gates=gates, all99_passed=all(g['passed'] for g in gates.values()), publication_authorized=False)
