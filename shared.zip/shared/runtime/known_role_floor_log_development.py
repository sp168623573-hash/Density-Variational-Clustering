"""100 real MHFD/DVC epochs with a known-only nonnegative log representation.

New experiment directory only; never updates an accepted baseline or a
setting's formal Matrix/CSV. A known-only control is not TARGET99 completion.
"""

import argparse
import json
import os
from pathlib import Path
import time

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
os.environ.setdefault("LOKY_MAX_CPU_COUNT", "12")

import joblib
import numpy as np
from sklearn.feature_selection import SelectKBest, f_classif
import torch
from sklearn.preprocessing import FunctionTransformer

from .config import CIC_FEATURE_COLUMNS, NSL_FEATURE_COLUMNS, get_spec
from .data import (_assign_scope, _build_preprocessor as _base_build_preprocessor, _coerce_numeric,
                   _feature_fingerprint, _normalize_label, _read_source, sha256_file)
from .dvc import NoveltyCalibrator, dvc_route
from .known_only_data import KnownOnlyBundle
from .known_role_floor import ROLES, plan_known_roles
from .model import choose_coarse_threshold, infer, train_model
from .paper_contract import audit_paper_contract
from .reporting import _development_matrix_text, write_epoch_csv, write_json



BASELINE = "NSL-KDD Setting1/run/role_floor_original_train_20261002_v1"
BASELINE_SHA = "8e70a68a59dd1e83a5bed4d0bfbb930690e6d387ad09840f8a8c8a1394ff83c4"


def log1p_nonnegative(values):
    """Invertible numeric compression; no query fit, clipping or source metadata."""
    x = np.asarray(values, dtype=np.float64)
    if x.ndim != 2 or not np.isfinite(x).all() or np.any(x < 0):
        raise ValueError("finite nonnegative NSL numeric fields required; no clipping")
    return np.log1p(x)


def _build_preprocessor(spec, columns):
    if spec.name != "NSL-KDD Setting1" or tuple(columns) != NSL_FEATURE_COLUMNS:
        raise ValueError("this predeclared representation candidate is NSL Setting1 only")
    preprocessor = _base_build_preprocessor(spec, columns)
    numeric = next(p for name, p, _ in preprocessor.transformers if name == "numeric")
    numeric.steps.insert(1, ("log1p", FunctionTransformer(log1p_nonnegative,
        feature_names_out="one-to-one")))
    return preprocessor


def paired_known_delta(truth, baseline, candidate):
    old, new = exact_known_gates(truth, baseline), exact_known_gates(truth, candidate)
    delta = {label: new[label]["correct"] - old[label]["correct"] for label in ("BEN", "KNA")}
    nonzero = [v for v in delta.values() if v]
    effect = ("UNCHANGED" if not nonzero else "UP" if min(nonzero) > 0
              else "DOWN" if max(nonzero) < 0 else "MIXED")
    return {"EffectDelta": effect, "correct_count_delta_same_IDs": delta,
        "baseline": old, "candidate": new, "scope": "known-control BEN/KNA only; UNA unassessed",
        "accepted_baseline_replaced": False, "full_TARGET99_status": "FAIL_TARGET99"}


def prepare_role_floor_bundle(workspace, spec, *, seed):
    train_path, unopened_test = spec.data_paths(workspace)
    source_contract = None
    if spec.dataset == "nsl_kdd":
        contract_path = workspace / "tmp/original_source_proportional_preflight_20260929_v6.json"
        if sha256_file(contract_path) != "dffc91516a1d36197503aa4bc582afdce2c2e4fa7f8735244be19e5171934746":
            raise ValueError("sealed original-source contract hash differs")
        source_contract = json.loads(contract_path.read_text(encoding="utf-8"))["sources"]["nsl_original_train"]
        train_path = Path(source_contract["path"]).resolve()
        if workspace not in train_path.parents or sha256_file(train_path) != source_contract["sha256"]:
            raise ValueError("original NSL train path/hash differs from the sealed contract")
    source_sha = sha256_file(train_path)
    raw = _read_source(spec, train_path, "source_train")
    columns = CIC_FEATURE_COLUMNS if spec.dataset == "cic" else NSL_FEATURE_COLUMNS
    raw["_label"] = raw["label"].map(lambda v: _normalize_label(spec, v))
    raw["_scope"] = raw["_label"].map(lambda v: _assign_scope(spec, v))
    if raw["_scope"].eq("UNDECLARED").any():
        raise ValueError("source-train contains undeclared Table-1 family")
    known = raw.loc[raw["_scope"].isin(("BEN", "KNA"))].copy()
    known["_fine_label"] = np.where(known["_scope"].eq("BEN"), "BEN", known["_label"])
    known["_fingerprint"] = _feature_fingerprint(known, columns)
    known["_sample_id"] = (spec.dataset + ":original-source-train:" + source_sha + ":" + known["_source_row"].astype(str)
                           + ":" + known["_fingerprint"])
    fine_classes = ("BEN", *spec.known_families)
    records = [{"family": r["_fine_label"], "fingerprint": r["_fingerprint"],
                "sample_id": r["_sample_id"]} for r in known.to_dict("records")]
    assignments, plan = plan_known_roles(records, fine_classes, seed=seed)
    selected = known.loc[known["_sample_id"].isin(assignments)].copy()
    selected["_role"] = selected["_sample_id"].map(assignments)
    frames = {role: _coerce_numeric(selected.loc[selected["_role"].eq(role)]
        .sort_values("_sample_id").reset_index(drop=True), spec, columns) for role in ROLES}
    for i, role in enumerate(ROLES):
        for other in ROLES[i + 1:]:
            if set(frames[role]["_fingerprint"]) & set(frames[other]["_fingerprint"]):
                raise AssertionError("feature fingerprint crosses frozen roles")
    preprocessor = _build_preprocessor(spec, columns)
    encoded = {"fit": np.asarray(preprocessor.fit_transform(frames["fit"]), dtype=np.float32)}
    encoded.update({role: np.asarray(preprocessor.transform(frames[role]), dtype=np.float32)
                    for role in ROLES if role != "fit"})
    mask = np.var(encoded["fit"], axis=0) > 0
    if int(mask.sum()) < 2:
        raise ValueError("at least two variable fit-only encoded features required")
    fine_index = {family: i for i, family in enumerate(fine_classes)}
    fine = {role: frame["_fine_label"].map(fine_index).to_numpy(dtype=np.int64)
            for role, frame in frames.items()}
    coarse = {role: frame["_scope"].eq("KNA").to_numpy(dtype=np.int64)
              for role, frame in frames.items()}
    selector = SelectKBest(f_classif, k=min(256, int(mask.sum())))
    x = {"fit": np.asarray(selector.fit_transform(encoded["fit"][:, mask], fine["fit"]),
                           dtype=np.float32)}
    x.update({role: np.asarray(selector.transform(encoded[role][:, mask]), dtype=np.float32)
              for role in ROLES if role != "fit"})
    if any(not np.isfinite(v).all() for v in x.values()) or sha256_file(train_path) != source_sha:
        raise ValueError("non-finite features or source bytes changed during preparation")
    names = tuple(np.asarray(preprocessor.get_feature_names_out(), dtype=str)[mask]
                  [selector.get_support()])
    ids = {role: frame["_sample_id"].to_numpy(dtype=str) for role, frame in frames.items()}
    audit = {"setting": spec.name, "source_train_path": str(train_path.resolve()),
        "source_train_sha256": source_sha, "source_train_rows": len(raw),
        "source_is_original_full_nsl_train": spec.dataset == "nsl_kdd",
        "original_source_contract": source_contract,
        "source_train_una_rows_excluded": int(raw["_scope"].eq("UNA").sum()),
        "source_test_file_opened": False, "source_test_labels_read": False,
        "unopened_source_test_path": str(unopened_test), "role_plan": plan,
        "role_rows": {role: len(frame) for role, frame in frames.items()},
        "feature_count": len(names), "physical_event_independence_verified": False}
    return KnownOnlyBundle(x_fit=x["fit"], x_checkpoint=x["checkpoint"],
        x_calibration=x["calibration"], x_open_known=x["open_known"],
        y_fit_coarse=coarse["fit"], y_checkpoint_coarse=coarse["checkpoint"],
        y_calibration_coarse=coarse["calibration"], y_open_known_coarse=coarse["open_known"],
        y_fit_fine=fine["fit"], y_calibration_fine=fine["calibration"],
        fit_families=frames["fit"]["_fine_label"].to_numpy(dtype=str),
        checkpoint_families=frames["checkpoint"]["_fine_label"].to_numpy(dtype=str),
        calibration_families=frames["calibration"]["_fine_label"].to_numpy(dtype=str),
        open_known_families=frames["open_known"]["_fine_label"].to_numpy(dtype=str),
        fit_ids=ids["fit"], checkpoint_ids=ids["checkpoint"], calibration_ids=ids["calibration"],
        open_known_ids=ids["open_known"], known_source_ids=selected["_sample_id"].to_numpy(dtype=str),
        fit_training_indices=np.arange(len(x["fit"])), preprocessor=preprocessor,
        selector=selector, variance_mask=mask, selected_feature_names=names,
        fine_classes=fine_classes, audit=audit)


def exact_known_gates(truth, prediction):
    truth, prediction = np.asarray(truth), np.asarray(prediction)
    if (truth.ndim != 1 or prediction.shape != truth.shape
            or truth.dtype.kind not in "iu" or prediction.dtype.kind not in "iu"
            or not np.isin(truth, (0, 1)).all() or not np.isin(prediction, (0, 1, 2)).all()):
        raise ValueError("known truth and full-route integer predictions required")
    gates = {}
    for value, label in enumerate(("BEN", "KNA")):
        support = int(np.sum(truth == value))
        correct = int(np.sum((truth == value) & (prediction == value)))
        required = (99 * support + 99) // 100
        gates[label] = {"correct": correct, "support": support,
            "required_for_99pct": required, "gap_to_gate": max(0, required - correct),
            "passed": bool(support > 0 and correct >= required)}
    gates["UNA"] = {"correct": None, "support": None,
                    "required_for_99pct": None, "gap_to_gate": None, "passed": None}
    return gates


def formal_snapshot(root):
    return {f"{setting}/{name}": sha256_file(root / setting / name)
        for setting in ("CIC Setting1", "CIC Setting2", "NSL-KDD Setting1", "NSL-KDD Setting2")
        for name in ("Matrix.txt", "experiment_A_standard_accuracy.csv")}


def run(*, workspace, setting, output_directory, seed=20261002, epochs=100):
    if type(epochs) is not int or epochs != 100:
        raise ValueError("exactly 100 actual epochs required")
    root = Path(workspace).resolve()
    output = Path(output_directory).resolve()
    if root not in output.parents or output.exists():
        raise ValueError("a new workspace-contained experiment directory is required")
    before = formal_snapshot(root)
    spec = get_spec(setting)
    output.mkdir(parents=True, exist_ok=False)
    start = time.perf_counter()
    write_json(output / "status.json", {"status": "running", "setting": setting,
        "published": False, "final_test_executed": False})
    try:
        paper = audit_paper_contract()
        if not paper["development_training_allowed"]:
            raise ValueError("paper contract prohibits development fitting")
        write_json(output / "paper_contract.json", paper)
        baseline_directory = root / BASELINE
        if sha256_file(baseline_directory / "report.json") != BASELINE_SHA:
            raise ValueError("sealed known-only paired baseline differs")
        baseline_report = json.loads((baseline_directory / "report.json").read_text(encoding="utf8"))
        if (sha256_file(baseline_directory / "frozen_role_ids.npz") != baseline_report["frozen_policy"]["role_ids_sha256"]
                or sha256_file(baseline_directory / "known_query_predictions_frozen.npz") != baseline_report["known_predictions_sha256"]):
            raise ValueError("paired baseline role IDs or predictions changed")
        source_pins = {str(Path(__file__)): sha256_file(Path(__file__))}
        for name in ("report.json", "frozen_role_ids.npz", "known_query_predictions_frozen.npz"):
            p = baseline_directory / name
            source_pins[str(p)] = sha256_file(p)
        for module in ("data.py", "model.py", "dvc.py", "known_role_floor.py", "config.py", "paper_contract.py"):
            p = Path(__file__).with_name(module)
            source_pins[str(p)] = sha256_file(p)
        bundle = prepare_role_floor_bundle(root, spec, seed=seed)
        with np.load(baseline_directory / "frozen_role_ids.npz", allow_pickle=False) as old:
            if any(not np.array_equal(old[role], getattr(bundle, role + "_ids")) for role in ROLES):
                raise ValueError("original paired role IDs changed before fitting")
        bundle.audit["numeric_representation"] = "known-fit median -> deterministic log1p -> known-fit StandardScaler"
        bundle.audit["categorical_representation"] = "unchanged known-fit vocabulary; no unknown-fit"
        bundle.audit["paired_role_IDs_verified_before_fit"] = True
        bundle.audit["producer_and_model_source_sha256"] = source_pins
        write_json(output / "data_audit.json", bundle.audit)
        np.savez_compressed(output / "frozen_role_ids.npz", fit=bundle.fit_ids,
            checkpoint=bundle.checkpoint_ids, calibration=bundle.calibration_ids,
            open_known=bundle.open_known_ids)
        print(json.dumps({"phase": "roles_frozen_before_fit", "setting": setting,
            "role_rows": bundle.audit["role_rows"], "minimum_family_each_role": 20,
            "physical_event_independence_verified": False}), flush=True)
        fit_start = time.perf_counter()
        training = train_model(bundle.x_fit, bundle.y_fit_coarse, bundle.y_fit_fine,
            bundle.x_checkpoint, bundle.y_checkpoint_coarse,
            fine_class_count=len(bundle.fine_classes), epochs=epochs, seed=seed,
            progress_label=setting + " log1p-role-floor20")
        fit_seconds = time.perf_counter() - fit_start
        if len(training.history) != 100:
            raise ValueError("training did not complete 100 epochs")
        training.model.to(torch.device("cpu"))
        fitted = infer(training.model, bundle.x_fit, device=torch.device("cpu"))
        cal = infer(training.model, bundle.x_calibration, device=torch.device("cpu"))
        threshold, calibration_metrics = choose_coarse_threshold(
            bundle.y_calibration_coarse, cal.attack_probability)
        cal_prediction = (cal.attack_probability >= threshold).astype(np.int64)
        calibrator = NoveltyCalibrator(retention_quantile=0.995).fit(
            bundle.x_fit, fitted, bundle.y_fit_fine, bundle.x_calibration, cal,
            bundle.y_calibration_fine, cal_prediction)
        torch.save({"state_dict": training.model.state_dict(), "setting": setting,
            "selected_epoch": training.selected_epoch, "seed": seed,
            "feature_count": len(bundle.selected_feature_names), "fine_classes": bundle.fine_classes,
            "coarse_threshold": threshold}, output / "checkpoint_selected.pt")
        joblib.dump({"preprocessor": bundle.preprocessor, "selector": bundle.selector,
            "variance_mask": bundle.variance_mask, "novelty_calibrator": calibrator},
            output / "preprocessing_and_calibrator.joblib")
        write_epoch_csv(output / "experiment_A_standard_accuracy.csv", training.history)
        frozen_policy = {"checkpoint_sha256": sha256_file(output / "checkpoint_selected.pt"),
            "preprocessing_sha256": sha256_file(output / "preprocessing_and_calibrator.joblib"),
            "role_ids_sha256": sha256_file(output / "frozen_role_ids.npz"),
            "producer_and_model_source_sha256": source_pins,
            "predeclared_known_only_representation": "median-log1p-StandardScaler",
            "threshold_selected_from_known_calibration_only": threshold,
            "query_truth_used_for_checkpoint_or_threshold": False}
        write_json(output / "policy_frozen_before_query.json", frozen_policy)
        query = infer(training.model, bundle.x_open_known, device=torch.device("cpu"))
        stage1 = (query.attack_probability >= threshold).astype(np.int64)
        novelty = calibrator.score(bundle.x_open_known, query, stage1)
        routed = dvc_route(stage1, query, novelty, seed=seed,
            known_reference_features=bundle.x_fit, query_features=bundle.x_open_known,
            known_reference_ids=bundle.fit_ids, query_ids=bundle.open_known_ids)
        np.savez_compressed(output / "known_query_predictions_frozen.npz",
            sample_id=bundle.open_known_ids, stage1=stage1, routed=routed.final_prediction)
        prediction_sha = sha256_file(output / "known_query_predictions_frozen.npz")
        gates = exact_known_gates(bundle.y_open_known_coarse, routed.final_prediction)
        counts = np.zeros((2, 2), dtype=np.int64)
        for actual, predicted in zip(bundle.y_open_known_coarse, stage1):
            counts[predicted, actual] += 1
        text = "Known-source development only; independent final not admitted\n"
        text += "status=FAIL_TARGET99\npublished=false\nUNA actual-family score=未评估\n\n"
        text += _development_matrix_text(counts) + "\n\nDVC known-control integer gates:\n"
        text += json.dumps(gates, ensure_ascii=False, indent=2) + "\n"
        with (output / "Matrix.txt").open("x", encoding="utf-8") as stream:
            stream.write(text)
        families = {family: {"support": int(np.sum(bundle.open_known_families == family)),
            "stage1_correct": int(np.sum((bundle.open_known_families == family)
                & (stage1 == (0 if family == "BEN" else 1)))),
            "routed_correct": int(np.sum((bundle.open_known_families == family)
                & (routed.final_prediction == (0 if family == "BEN" else 1))))}
            for family in bundle.fine_classes}
        write_json(output / "dvc_manifest.json", routed.dvc_manifest)
        if sha256_file(Path(bundle.audit["source_train_path"])) != bundle.audit["source_train_sha256"]:
            raise ValueError("source-train bytes changed during development")
        if formal_snapshot(root) != before:
            raise ValueError("formal output hash changed during development")
        with np.load(baseline_directory / "known_query_predictions_frozen.npz", allow_pickle=False) as old:
            if not np.array_equal(old["sample_id"], bundle.open_known_ids):
                raise ValueError("paired known scoring IDs changed")
            paired = paired_known_delta(bundle.y_open_known_coarse, old["routed"], routed.final_prediction)
        write_json(output / "paired_known_effect_delta.json", paired)
        if any(sha256_file(Path(p)) != h for p, h in source_pins.items()):
            raise ValueError("predeclared representation/model sources changed")
        report = {"schema_version": "known-role-floor-nonnegative-log-development-v1", "setting": setting,
            "status": "FAIL_TARGET99", "execution_status": "complete", "published": False,
            "final_test_executed": False, "epochs_completed": len(training.history),
            "selected_epoch": training.selected_epoch, "training_wall_seconds": fit_seconds,
            "runtime_seconds": time.perf_counter() - start, "selected_stage1": "mhfd_neural",
            "calibration_metrics": calibration_metrics, "source_role_plan": bundle.audit["role_plan"],
            "stage1_known_control_gates": exact_known_gates(bundle.y_open_known_coarse, stage1),
            "routed_known_control_gates": gates, "known_control_family": families,
            "source_test_file_opened": False, "source_test_labels_read": False,
            "unknown_development_evaluated": False, "independent_final_scoring_admitted": False,
            "physical_event_independence_verified": False,
            "known_predictions_sha256": prediction_sha, "frozen_policy": frozen_policy,
            "formal_outputs_sha256_unchanged": before,
            "EffectDelta": paired["EffectDelta"], "paired_known_effect_delta": paired,
            "accepted_baseline_replaced": False,
            "effect_delta_reason": "same frozen role IDs; BEN/KNA known control only, not full or final TARGET99",
            "producer_sha256": {str(Path(__file__).relative_to(root)).replace('\\', '/'):
                                 sha256_file(Path(__file__))}}
        write_json(output / "report.json", report)
        write_json(output / "status.json", report)
        print(json.dumps(report, ensure_ascii=False), flush=True)
        return report
    except Exception as exc:
        write_json(output / "status.json", {"status": "FAIL_TARGET99",
            "execution_status": "execution_failed", "error_type": type(exc).__name__,
            "error": str(exc), "published": False, "final_test_executed": False,
            "runtime_seconds": time.perf_counter() - start})
        raise


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--workspace", type=Path, default=Path.cwd())
    p.add_argument("--setting", required=True)
    p.add_argument("--output-directory", type=Path, required=True)
    p.add_argument("--seed", type=int, default=20261002)
    p.add_argument("--epochs", type=int, default=100)
    args = p.parse_args()
    run(workspace=args.workspace, setting=args.setting, output_directory=args.output_directory,
        seed=args.seed, epochs=args.epochs)


if __name__ == "__main__":
    main()
