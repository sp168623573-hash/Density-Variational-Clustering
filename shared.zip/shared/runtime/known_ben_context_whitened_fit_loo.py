"""BEN context shrinkage-whitened distance with a full known-fit LOO envelope.

This is a declared implementation variant inside MHFD/DVC, not literal paper
pseudocode. All reference scaling/neighbors fit BEN fit rows. A context needs
eight fit and three correctly routed BEN calibration rows. The latter freeze
a strict distance maximum, combined with the maximum seventh-neighbour
leave-self-out distance of ALL known BEN fit rows in the same context. Unsupported contexts keep the retained parent;
they are NOT dropped from scoring or automatically unknown. Non-noise DVC
is necessary. No attack family/label/ID enters query scoring.
"""
from dataclasses import dataclass
import hashlib
import numpy as np
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
from sklearn.covariance import LedoitWolf
from .dvc import NoveltyOutput
from .local_ben_affinity_envelope_guarded import _matrix, _roles, FLOAT_BOUNDARY_ULPS

SCHEMA = "known-BEN-context-shrinkage-whitened-calibration-and-fit-LOO-distance-envelope-v1"
NEIGHBORS = 7
MIN_FIT = 8
MIN_CALIBRATION = 3
CONTEXT_FIELDS = ("protocol_type", "service", "flag")


def context_keys(features, feature_names):
    x = _matrix(features, "context features")
    names = np.asarray(feature_names, dtype=str)
    if names.shape != (x.shape[1],) or len(set(names)) != len(names):
        raise ValueError("paired distinct selected feature names required")
    labels = []
    for field in CONTEXT_FIELDS:
        columns = np.array([i for i,name in enumerate(names) if name.startswith(field+"_")],dtype=np.int64)
        if not len(columns):
            raise ValueError("all three one-hot context fields required")
        values = x[:, columns]
        if not np.isin(values, (0.,1.)).all() or np.any(values.sum(axis=1)>1):
            raise ValueError("context must be actual zero/one frozen encoding")
        labels.append([str(names[columns[np.argmax(row)]]) if row.sum() else field+"_<unseen>" for row in values])
    return [tuple(parts) for parts in zip(*labels)]



class KnownContextWhitener(StandardScaler):
    """Shrinkage correlation metric fit exclusively on same-context BEN fit."""
    def fit(self, features, y=None):
        super().fit(features, y)
        z = super().transform(features)
        self.active_columns_ = np.flatnonzero(self.var_>0)
        self.whitener_ = np.eye(z.shape[1],dtype=np.float64)
        self.covariance_ = np.empty((0,0),dtype=np.float64)
        self.shrinkage_ = 0.
        if len(self.active_columns_):
            estimated = LedoitWolf(store_precision=False, assume_centered=False).fit(z[:,self.active_columns_])
            self.covariance_ = estimated.covariance_.copy()
            self.shrinkage_ = float(estimated.shrinkage_)
            values, vectors = np.linalg.eigh(self.covariance_)
            floor = 64*np.finfo(np.float64).eps*max(1.,float(values.max()))
            inverse_root = (vectors*(1./np.sqrt(np.maximum(values,floor))))@vectors.T
            self.whitener_[np.ix_(self.active_columns_,self.active_columns_)] = inverse_root
        if not np.isfinite(self.whitener_).all():
            raise ValueError("nonfinite known-only shrinkage whitening")
        return self

    def transform(self, features):
        return super().transform(features)@self.whitener_


@dataclass
class ContextDensity:
    groups: dict
    feature_names: tuple
    calibration_ratios: np.ndarray
    manifest: dict


def _group_state_hash(group):
    digest = hashlib.sha256(float(group["cutoff"]).hex().encode("ascii"))
    for values in (group["scaler"].mean_,group["scaler"].scale_,group["scaler"].whitener_,
            group["scaler"].covariance_,group["scaler"].active_columns_,
            np.asarray([group["scaler"].shrinkage_]),group["neighbors"]._fit_X):
        data = np.asarray(values,dtype="<f8",order="C")
        digest.update(str(data.shape).encode("ascii")); digest.update(data.tobytes())
    return digest.hexdigest()


def components(profile, features):
    x = _matrix(features,"context density query")
    keys = context_keys(x,profile.feature_names)
    ratio, distance = np.zeros(len(x)), np.zeros(len(x))
    eligible = np.zeros(len(x),dtype=bool)
    for key, group in profile.groups.items():
        indices = np.array([i for i,k in enumerate(keys) if k==key],dtype=np.int64)
        if not len(indices): continue
        cutoff = group["cutoff"]
        if (type(cutoff) not in (float,int) or not np.isfinite(cutoff) or cutoff<=0
                or group["neighbors"].metric!="euclidean" or group["neighbors"].n_neighbors!=NEIGHBORS
                or _group_state_hash(group)!=group.get("frozen_state_sha256")):
            raise ValueError("frozen finite context distance policy required")
        values = group["neighbors"].kneighbors(group["scaler"].transform(x[indices]),return_distance=True)[0][:,-1]
        distance[indices], ratio[indices], eligible[indices] = values, values/cutoff, True
    if not np.isfinite(ratio).all() or not np.isfinite(distance).all():
        raise ValueError("context distance or ratio overflow")
    return ratio,distance,eligible


def fit_profile(fit_features, fit_truth, calibration_features, calibration_truth, primary, baseline, feature_names):
    x,cal = _matrix(fit_features,"BEN fit features"),_matrix(calibration_features,"known calibration features")
    y = _roles(fit_truth,len(x),"known fit truth")
    cy = _roles(calibration_truth,len(cal),"known calibration truth")
    p = _roles(primary,len(cal),"known calibration primary")
    b = np.asarray(baseline)
    if (x.shape[1]!=cal.shape[1] or b.shape!=p.shape or b.dtype.kind not in "iu"
            or not np.isin(b,(0,1,2)).all() or np.any((b!=p)&(b!=2)) or set(cy.tolist())!={0,1}):
        raise ValueError("paired known-only context calibration required")
    names = tuple(str(v) for v in feature_names)
    protected = (cy==0)&(p==0)&(b==0)
    fit_keys, cal_keys = context_keys(x,names), context_keys(cal,names)
    groups,audit = {},[]
    for key in sorted(set(k for k,label in zip(fit_keys,y) if label==0)):
        fit_indices = np.array([i for i,k in enumerate(fit_keys) if k==key and y[i]==0],dtype=np.int64)
        cal_indices = np.array([i for i,k in enumerate(cal_keys) if k==key and protected[i]],dtype=np.int64)
        row = {"context":list(key),"known_BEN_fit_rows":len(fit_indices),"correct_BEN_calibration_rows":len(cal_indices)}
        if len(fit_indices)<MIN_FIT or len(cal_indices)<MIN_CALIBRATION:
            audit.append({**row,"admitted":False,"reason":"insufficient_context_reference_keep_parent"}); continue
        known = x[fit_indices]
        order = np.lexsort(tuple(known[:,i] for i in range(known.shape[1]-1,-1,-1)))
        known = known[order]
        scaler = KnownContextWhitener().fit(known)
        nn = NearestNeighbors(n_neighbors=NEIGHBORS,metric="euclidean",n_jobs=1).fit(scaler.transform(known))
        distances = nn.kneighbors(scaler.transform(cal[cal_indices]),return_distance=True)[0][:,-1]
        graph = NearestNeighbors(n_neighbors=NEIGHBORS+1,metric="euclidean",n_jobs=1).fit(scaler.transform(known))
        fit_distance,fit_index = graph.kneighbors(scaler.transform(known),return_distance=True)
        leave_self_out = np.empty(len(known),dtype=np.float64)
        for reference_row in range(len(known)):
            remaining = fit_distance[reference_row][fit_index[reference_row]!=reference_row]
            if len(remaining)<NEIGHBORS:
                raise ValueError("insufficient actual-index leave-self-out neighbours")
            leave_self_out[reference_row] = remaining[NEIGHBORS-1]
        fit_maximum = float(leave_self_out.max())
        raw_cutoff = max(1.e-12,float(distances.max()),fit_maximum)
        cutoff = float(raw_cutoff+FLOAT_BOUNDARY_ULPS*np.finfo(np.float64).eps*max(1.,raw_cutoff))
        groups[key] = {"scaler":scaler,"neighbors":nn,"cutoff":cutoff}
        groups[key]["frozen_state_sha256"] = _group_state_hash(groups[key])
        audit.append({**row,"admitted":True,"cutoff":cutoff,"calibration_distance_range":[float(distances.min()),float(distances.max())],
            "full_known_fit_leave_self_out_distance_maximum":fit_maximum,
            "known_only_LedoitWolf_shrinkage":scaler.shrinkage_,
            "known_nonconstant_active_fields":[names[i] for i in scaler.active_columns_],
            "whitener_sha256":hashlib.sha256(np.ascontiguousarray(scaler.whitener_).tobytes()).hexdigest(),
            "fit_LOO_distance_sha256":hashlib.sha256(np.ascontiguousarray(leave_self_out).tobytes()).hexdigest(),
            "known_fit_geometry_sha256":hashlib.sha256(np.ascontiguousarray(known).tobytes()).hexdigest(),
            "frozen_state_sha256":groups[key]["frozen_state_sha256"]})
    if not groups: raise ValueError("no context has eight BEN fit and three correct calibration references")
    profile = ContextDensity(groups,names,np.empty(0),{})
    ratios,_,eligible = components(profile,cal)
    if np.any((ratios>1)&protected&eligible): raise AssertionError("strict known context envelope retention failed")
    ref = np.sort(ratios[protected&eligible])
    profile.calibration_ratios = ref
    profile.manifest = {"schema_version":SCHEMA,"context_fields":list(CONTEXT_FIELDS),"metric":"euclidean",
        "known_fit_neighbors":NEIGHBORS,"minimum_fit_reference_rows":MIN_FIT,"minimum_context_correct_calibration":MIN_CALIBRATION,
        "context_minima_are_NOT_Table1_family_or_independent_event_floors":True,"groups":audit,
        "admitted_contexts":len(groups),"known_BEN_fit_rows":int(np.sum(y==0)),
        "protected_BEN_calibration_rows":int(protected.sum()),"eligible_correct_BEN_calibration_rows":len(ref),
        "additional_correct_known_calibration_rejections":0,
        "calibration_ratio_sha256":hashlib.sha256(np.ascontiguousarray(ref).tobytes()).hexdigest(),
        "strict_greater_than":True,"cutoff_definition":"maximum of correct BEN cal and ALL BEN fit leave-self-out seventh distances in same context plus fixed float64 guard",
        "fixed_float64_boundary_ULPs":FLOAT_BOUNDARY_ULPS,"known_only_calibration":True,
        "scale_and_reference_fit_BEN_fit_only":True,
        "covariance_fit_BEN_fit_only":True,"covariance_estimator":"LedoitWolf; no query/refit/grid",
        "constant_fit_fields_retain_original_StandardScaler_units":True,
        "eigenvalue_numerical_floor":"64 float64 eps times max(1,max_eigenvalue)","query_truth_or_ID_or_family_used":False,
        "unsupported_context_action":"preserve retained parent; no new rejection; still included in denominator",
        "BEN_feature_core_component":"actual eligible correct BEN calibration normalized-distance ECDF rank/(n+1)",
        "ratio_is_not_percentile_or_probability":True,"non_noise_DVC_required":True,
        "noise_routed_directly_as_UNA":False,"Stage1_KNA_component_unchanged":True,
        "rule_chosen_after_historical_development_inspection":True,"new_query_99_NOT_guaranteed":True,
        "final_test_executed":False,"status":"FAIL_TARGET99","published":False}
    return profile


def score(profile, features, primary, original):
    m,ref = profile.manifest,profile.calibration_ratios
    if (m.get("schema_version")!=SCHEMA or m.get("known_only_calibration") is not True
            or m.get("query_truth_or_ID_or_family_used") is not False or m.get("published") is not False
            or m.get("strict_greater_than") is not True or m.get("non_noise_DVC_required") is not True
            or len(profile.groups)!=m.get("admitted_contexts") or ref.ndim!=1 or not len(ref)
            or not np.isfinite(ref).all() or np.any(ref<0) or not np.array_equal(ref,np.sort(ref))
            or hashlib.sha256(np.ascontiguousarray(ref).tobytes()).hexdigest()!=m.get("calibration_ratio_sha256")):
        raise ValueError("frozen known-only context profile required")
    ratio,distance,eligible = components(profile,features)
    p = _roles(primary,len(ratio),"query primary")
    fields = ("score","threshold","high_threshold","prototype_percentile","embedding_knn_percentile",
        "feature_knn_percentile","reconstruction_percentile","uncertainty_percentile","candidate")
    if (not isinstance(original,NoveltyOutput) or any(np.asarray(getattr(original,k)).shape!=p.shape for k in fields)
            or any(not np.isfinite(getattr(original,k)).all() for k in fields) or np.asarray(original.candidate).dtype!=bool):
        raise ValueError("paired finite original novelty required")
    updated = {k:np.asarray(getattr(original,k)).copy() for k in fields}
    ben = p==0
    updated["score"][ben]=ratio[ben]
    updated["threshold"][ben]=updated["high_threshold"][ben]=1.
    updated["candidate"][ben]=eligible[ben]&(ratio[ben]>1.)
    observed = ben&eligible
    updated["feature_knn_percentile"][observed]=np.searchsorted(ref,ratio[observed],side="right")/(len(ref)+1.)
    return NoveltyOutput(**updated,score_strategy="known_BEN_context_whitened_fit_LOO_density_KNA_unchanged_"+original.score_strategy),distance,eligible






