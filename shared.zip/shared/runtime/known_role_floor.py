"""Plan known-only feature-disjoint roles with a floor in *every* role.

This is a source-row development split, not a physical-event certificate.
No model output, unknown-development row, or source-test row is an input.
"""

from collections import Counter, defaultdict
import hashlib
import json

from .known_fit_stratified_budget import quotas


ROLES = ("fit", "checkpoint", "calibration", "open_known")
ROLE_WEIGHTS = {"fit": 0.7, "checkpoint": 0.1,
                "calibration": 0.1, "open_known": 0.1}


def _rank(seed, family, value):
    return hashlib.sha256(json.dumps([seed, family, value],
        ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()


def plan_known_roles(records, families, *, seed, maximum_source_rows=6000,
                     minimum_per_family_per_role=20):
    if (type(seed) is not int or seed < 0
            or type(maximum_source_rows) is not int
            or not 1 <= maximum_source_rows <= 6000
            or type(minimum_per_family_per_role) is not int
            or minimum_per_family_per_role < 20):
        raise ValueError("explicit seed, <=6000 source rows, and >=20 role floor required")
    families = tuple(families)
    if not families or len(set(families)) != len(families) or "BEN" not in families:
        raise ValueError("complete unique declared known family set required")
    groups, fingerprint_families, seen_ids, source_counts = {}, defaultdict(set), set(), Counter()
    for row in records:
        if set(row) != {"family", "fingerprint", "sample_id"} or any(
                not isinstance(row[k], str) or not row[k] for k in row):
            raise ValueError("complete nonempty string known row identity required")
        family, fingerprint, sample_id = row["family"], row["fingerprint"], row["sample_id"]
        if family not in families or sample_id in seen_ids:
            raise ValueError("undeclared family or repeated source row identity")
        seen_ids.add(sample_id)
        source_counts[family] += 1
        fingerprint_families[fingerprint].add(family)
        key = family, fingerprint
        if key not in groups or _rank(seed, family, sample_id) < _rank(
                seed, family, groups[key]["sample_id"]):
            groups[key] = dict(row)
    if set(source_counts) != set(families):
        raise ValueError("source lacks a declared known family; no family may be deleted")
    by_family = defaultdict(list)
    for row in groups.values():
        by_family[row["family"]].append(row)
    shared = {fp for fp, names in fingerprint_families.items() if len(names) > 1}
    shared_roles = {fp: ROLES[int(_rank(seed, "shared-feature-group", fp), 16) % len(ROLES)]
                    for fp in shared}
    forced = {family: [row for row in by_family[family] if row["fingerprint"] in shared]
              for family in families}
    forced_counts = {family: Counter(shared_roles[row["fingerprint"]]
                                    for row in forced[family]) for family in families}
    available = {family: len(by_family[family]) for family in families}
    role_minima = {family: {role: max(minimum_per_family_per_role,
                                    forced_counts[family][role]) for role in ROLES}
                   for family in families}
    minima = {family: sum(role_minima[family].values()) for family in families}
    deficits = {family: minima[family] - available[family] for family in families
                if available[family] < minima[family]}
    if deficits:
        raise ValueError("four disjoint role floors cannot be met by real feature groups: "
                         + json.dumps(deficits, sort_keys=True))
    total = min(maximum_source_rows, sum(available.values()))
    family_quotas = quotas(dict(source_counts), available, minima, total)
    assignments, role_counts, role_ids = {}, {}, {role: [] for role in ROLES}
    for family in sorted(families):
        selected = sorted((row for row in by_family[family] if row["fingerprint"] not in shared),
            key=lambda row: (
            _rank(seed, family, row["fingerprint"]), row["sample_id"]
        ))[:family_quotas[family] - len(forced[family])]
        counts = quotas(ROLE_WEIGHTS, {role: family_quotas[family] for role in ROLES},
                        role_minima[family], family_quotas[family])
        role_counts[family] = counts
        for row in forced[family]:
            role = shared_roles[row["fingerprint"]]
            assignments[row["sample_id"]] = role
            role_ids[role].append(row["sample_id"])
        begin = 0
        for role in ROLES:
            take = counts[role] - forced_counts[family][role]
            for row in selected[begin:begin + take]:
                assignments[row["sample_id"]] = role
                role_ids[role].append(row["sample_id"])
            begin += take
        if begin != len(selected):
            raise AssertionError("role quotas do not conserve the selected family")
    if len(assignments) != total:
        raise AssertionError("known cohort identity count differs from exact quota")
    audit = {
        "schema_version": "known-every-role-floor-v1", "seed": seed,
        "maximum_source_rows": maximum_source_rows, "selected_source_rows": total,
        "minimum_per_family_per_role": minimum_per_family_per_role,
        "source_rows_by_family": dict(source_counts),
        "distinct_feature_groups_by_family": available,
        "selected_source_quotas_by_family": family_quotas,
        "role_family_counts": {role: {family: role_counts[family][role]
                                     for family in sorted(families)} for role in ROLES},
        "role_sample_id_set_sha256": {role: hashlib.sha256(
            "\n".join(sorted(ids)).encode()).hexdigest() for role, ids in role_ids.items()},
        "all_role_family_feature_group_floors_met": True,
        "bootstrap_or_replacement_rows": 0,
        "cross_family_feature_groups_preserved": len(shared),
        "shared_feature_groups_locked_to_one_role_without_dropping_any_family": True,
        "selection_uses_model_scores": False, "source_test_rows_used": False,
        "unknown_development_rows_used": False,
        "feature_group_disjointness_is_NOT_physical_event_independence": True,
        "physical_event_independence_verified": False,
        "independent_final_scoring_admitted": False,
    }
    return assignments, audit
