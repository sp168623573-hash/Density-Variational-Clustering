"""Fixed BEN content dependence through a regularized conditional Gaussian.

Covariance and scaling fit real known BEN only. A single finite-sample 99%
known-BEN calibration order statistic freezes the score cutoff. No nearest
neighbor denominator, full-fit maximum or target family chooses the rule.
Algorithm 2/3 retains its known anchors and their veto: only candidate clusters
containing no known anchors may be admitted under its unchanged noise rules.
"""
from dataclasses import dataclass
import hashlib
import json
import math

import joblib
import numpy as np
from sklearn.covariance import OAS

from .config import NSL_FEATURE_COLUMNS
from .known_ben_context_whitened_fit_loo import context_keys
from .known_anchor_candidate_dvc import route as anchored_route


SCHEMA = "known-BEN-Gaussian-conditional-and-joint-fixed-controls-cal99-v2"
MODES = ('conditional', 'joint')
MIN_FIT = 20
RIDGE_RELATIVE = 1e-8
MAX_ANCHORS = 512
AUTH_FIELDS = ("logged_in", "is_guest_login")
CONTENT_FIELDS = tuple(name for name in NSL_FEATURE_COLUMNS[8:21] if name not in AUTH_FIELDS)
PREDICTOR_FIELDS = tuple(name for name in NSL_FEATURE_COLUMNS[3:] if name not in CONTENT_FIELDS and name not in AUTH_FIELDS)


def _matrix(values, width):
    result = np.asarray(values, dtype=np.float64)
    if result.ndim != 2 or result.shape[1] != width or not 0 < len(result) <= 6000 or not np.isfinite(result).all():
        raise ValueError("capped finite selected NSL features required")
    return result


def _roles(values, rows):
    result = np.asarray(values)
    if result.shape != (rows,) or result.dtype.kind not in "iu" or set(result.tolist()) != {0, 1}:
        raise ValueError("real known BEN/KNA role truth only required")
    return result


def feature_columns(names):
    names = tuple(str(value) for value in names)
    if len(set(names)) != len(names):
        raise ValueError("distinct frozen feature names required")
    content = tuple(names.index(name) for name in CONTENT_FIELDS if name in names)
    predictors = tuple(names.index(name) for name in PREDICTOR_FIELDS if name in names)
    if not content or not predictors:
        raise ValueError("actual selected content and other numeric semantic fields required")
    return content, predictors


def hierarchical_keys(features, names, auth_splits):
    base = context_keys(features, names)
    auth = [tuple(int(row[column] > cutoff) for column, cutoff in auth_splits) for row in features]
    return [(('exact', *key, *state), ('protocol_auth', key[0], *state), ('global',))
            for key, state in zip(base, auth)]


def gaussian_parameters(values, content_dimensions):
    """Schur conditional mean and precision from BEN OAS covariance."""
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 2 or len(values) < MIN_FIT or not 0 < content_dimensions < values.shape[1] or not np.isfinite(values).all():
        raise ValueError("real BEN joint coordinates and nonempty fixed blocks required")
    fitted = OAS(assume_centered=False).fit(values)
    covariance = np.asarray(fitted.covariance_, dtype=np.float64)
    ridge = RIDGE_RELATIVE * max(float(np.trace(covariance)/len(covariance)), 1.)
    covariance = covariance + ridge*np.eye(len(covariance))
    c = content_dimensions
    cross = covariance[:c, c:]
    coefficient = np.linalg.solve(covariance[c:, c:], cross.T).T
    residual_covariance = covariance[:c, :c] - coefficient @ cross.T
    residual_covariance = (residual_covariance + residual_covariance.T)/2
    # Positive-definiteness is inherited from the regularized joint matrix;
    # failure is reported, never repaired by a query-selected ridge search.
    np.linalg.cholesky(residual_covariance)
    precision = np.linalg.solve(residual_covariance, np.eye(c))
    return dict(mean=fitted.location_.copy(), coefficient=coefficient, residual_covariance=residual_covariance,
                residual_precision=precision, joint_covariance=covariance, ridge=ridge,
                predictor_precision=np.linalg.solve(covariance[c:, c:], np.eye(values.shape[1]-c)),
                OAS_shrinkage=float(fitted.shrinkage_), real_BEN_fit_rows=len(values))


def quadratic_residual(node, values, content_dimensions):
    centered = np.asarray(values, dtype=np.float64) - node['mean']
    residual = centered[:, :content_dimensions] - centered[:, content_dimensions:] @ node['coefficient'].T
    score = np.einsum('ni,ij,nj->n', residual, node['residual_precision'], residual)/content_dimensions
    if not np.isfinite(score).all() or np.any(score < -1e-10):
        raise ValueError("finite nonnegative conditional residual required")
    return np.maximum(score, 0.)


def quadratic_score(node, values, content_dimensions, mode):
    if mode not in MODES:
        raise ValueError('one predeclared conditional or joint Gaussian control required')
    conditional = quadratic_residual(node, values, content_dimensions)
    if mode == 'conditional':
        return conditional
    centered_p = np.asarray(values, dtype=np.float64)[:, content_dimensions:] - node['mean'][content_dimensions:]
    marginal = np.einsum('ni,ij,nj->n', centered_p, node['predictor_precision'], centered_p)
    score = (conditional*content_dimensions+marginal)/len(node['mean'])
    if not np.isfinite(score).all() or np.any(score < -1e-10):
        raise ValueError('finite nonnegative fixed joint Gaussian quadratic required')
    return np.maximum(score, 0.)


def _digest(profile):
    value = (profile.feature_names, profile.content, profile.predictors, profile.auth_splits,
             profile.mean, profile.scale, profile.nodes, profile.cutoff, profile.mode)
    return hashlib.sha256(joblib.hash(value, hash_name='sha1').encode('ascii')).hexdigest()


def _manifest_sha(manifest):
    value = {key: val for key, val in manifest.items() if key != 'frozen_manifest_sha256'}
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('ascii')).hexdigest()


@dataclass
class ConditionalGaussianContent:
    feature_names: tuple
    content: tuple
    predictors: tuple
    auth_splits: tuple
    mean: np.ndarray
    scale: np.ndarray
    nodes: dict
    cutoff: float
    mode: str
    manifest: dict


def check(profile):
    manifest = profile.manifest
    if (manifest.get('schema_version') != SCHEMA or manifest.get('frozen_manifest_sha256') != _manifest_sha(manifest)
            or manifest.get('frozen_state_sha256') != _digest(profile)
            or (profile.content, profile.predictors) != feature_columns(profile.feature_names)
            or manifest.get('ridge_relative') != RIDGE_RELATIVE or manifest.get('minimum_BEN_fit_rows_per_node') != MIN_FIT
            or manifest.get('calibration_truth_is_only_known_BEN_KNA') is not True
            or manifest.get('query_truth_features_or_IDs_used_for_fit') is not False
            or profile.mode not in MODES or manifest.get('fixed_score_mode') != profile.mode
            or ('global',) not in profile.nodes or not np.isfinite(profile.cutoff) or profile.cutoff <= 0):
        raise ValueError("unchanged known-only conditional Gaussian content policy required")


def assign_nodes(profile, features):
    alternatives = hierarchical_keys(features, profile.feature_names, profile.auth_splits)
    return [next(key for key in keys if key in profile.nodes) for keys in alternatives]


def raw_scores(profile, features):
    features = _matrix(features, len(profile.feature_names))
    values = (features[:, profile.content+profile.predictors] - profile.mean)/profile.scale
    assigned = assign_nodes(profile, features)
    scores = np.zeros(len(features))
    for key in sorted(set(assigned)):
        rows = np.asarray([i for i, value in enumerate(assigned) if value == key], dtype=np.int64)
        scores[rows] = quadratic_score(profile.nodes[key], values[rows], len(profile.content), profile.mode)
    return scores, assigned


def fit(feature_names, auth_splits, fit_features, fit_truth, calibration_features, calibration_truth, *, mode='conditional'):
    if mode not in MODES:
        raise ValueError('predeclared Gaussian control mode required')
    names = tuple(str(value) for value in feature_names)
    content, predictors = feature_columns(names)
    x, cal = _matrix(fit_features, len(names)), _matrix(calibration_features, len(names))
    truth, cal_truth = _roles(fit_truth, len(x)), _roles(calibration_truth, len(cal))
    splits = tuple((int(column), float(cutoff)) for column, cutoff in auth_splits)
    if (not splits or any(names[column] not in AUTH_FIELDS or not np.isfinite(cutoff) for column, cutoff in splits)
            or len({column for column, _ in splits}) != len(splits)):
        raise ValueError("frozen measured binary authentication splits required")
    ben = x[truth == 0]
    if len(ben) < MIN_FIT:
        raise ValueError("twenty real BEN fit rows required")
    order = np.lexsort(tuple(ben[:, j] for j in range(ben.shape[1]-1, -1, -1)))
    ben = ben[order]
    raw = ben[:, content+predictors]
    mean, scale = raw.mean(axis=0), raw.std(axis=0)
    scale[scale <= np.finfo(float).eps] = 1.
    z = (raw-mean)/scale
    keys = hierarchical_keys(ben, names, splits)
    nodes, audit = {}, []
    for key in sorted({key for alternatives in keys for key in alternatives}):
        indices = np.asarray([i for i, alternatives in enumerate(keys) if key in alternatives], dtype=np.int64)
        row = dict(node=list(key), real_BEN_fit_rows=len(indices), admitted=len(indices) >= MIN_FIT)
        if row['admitted']:
            nodes[key] = gaussian_parameters(z[indices], len(content))
            row.update(ridge=nodes[key]['ridge'], OAS_shrinkage=nodes[key]['OAS_shrinkage'])
        audit.append(row)
    profile = ConditionalGaussianContent(names, content, predictors, splits, mean, scale, nodes, 1., mode, {})
    calibration, assigned = raw_scores(profile, cal[cal_truth == 0])
    m = len(calibration)
    rank = math.ceil(.99*(m+1))
    if rank > m:
        raise ValueError("finite 99% known BEN calibration order statistic requires >=99 BEN rows")
    cutoff = float(np.sort(calibration)[rank-1])
    if not np.isfinite(cutoff) or cutoff <= 0:
        raise ValueError("finite positive known BEN conditional residual cutoff required")
    profile.cutoff = cutoff
    profile.manifest = dict(schema_version=SCHEMA, feature_names=list(names), content_fields=[names[i] for i in content],
        predictor_fields=[names[i] for i in predictors], response_semantics='fixed selected NSL content positions 8:21 excluding binary auth conditioning fields',
        context_order=['protocol/service/flag/auth', 'protocol/auth', 'global'],
        auth_splits=[list(value) for value in splits], nodes=audit,
        minimum_BEN_fit_rows_per_node=MIN_FIT, context_support_is_NOT_per_family_floor=True,
        covariance='BEN-fit-only OAS joint C/P covariance', ridge_relative=RIDGE_RELATIVE,
        ridge_rule='1e-8 * max(trace(OAS_cov)/joint_dimension, 1) in globally BEN-fit-standardized units',
        conditional_mean='mu_C + Sigma_CP inverse(Sigma_PP) (P-mu_P)',
        conditional_covariance='Sigma_CC - Sigma_CP inverse(Sigma_PP) Sigma_PC',
        fixed_score_mode=mode,
        score=('conditional residual quadratic / selected content dimension' if mode == 'conditional' else
               '(P marginal quadratic + C|P residual quadratic) / joint dimension; exactly joint OAS Mahalanobis'),
        joint_control_weights_are_fixed_unit_weights_NOT_fitted_or_query_selected=True,
        calibration_BEN_rows=m, calibration_rank_one_based=rank, calibration_cutoff=cutoff,
        calibration_raw_candidates=int(np.sum(calibration > cutoff)),
        calibration_rank_rule='ceil(0.99*(m+1)), strict score > cutoff, no target query tuning',
        threshold_uses_all_known_BEN_calibration_NOT_only_parent_correct=True,
        calibration_truth_is_only_known_BEN_KNA=True, query_truth_features_or_IDs_used_for_fit=False,
        full_fit_LOO_or_max_neighbor_cutoff_used=False, single_global_calibration_cutoff=True,
        finite_sample_rank_NOT_IID_or_physical_independence_certificate=True,
        physical_event_independence_verified=False, independent_final_admitted=False, published=False)
    profile.manifest['frozen_state_sha256'] = _digest(profile)
    profile.manifest['frozen_manifest_sha256'] = _manifest_sha(profile.manifest)
    check(profile)
    return profile


def evaluate(profile, features, stage1):
    check(profile)
    features = _matrix(features, len(profile.feature_names))
    stage = np.asarray(stage1)
    if stage.shape != (len(features),) or stage.dtype.kind not in 'iu' or not np.isin(stage, (0, 1)).all():
        raise ValueError("paired frozen known stage1 predictions required")
    raw, nodes = raw_scores(profile, features)
    ratio = raw/profile.cutoff
    check(profile)
    return dict(score=ratio, raw_score=raw, raw_candidate=(stage == 0)&(ratio > 1), nodes=nodes)


def coordinates(embedding, scaler, normalized_score):
    z = scaler.transform(np.asarray(embedding, dtype=np.float64))/np.sqrt(scaler.n_features_in_)
    return np.column_stack([z, 2*np.log1p(normalized_score)])


def fit_anchors(profile, fit_features, fit_truth, fit_embedding, calibration_features, calibration_truth,
                calibration_embedding, embedding_scaler):
    """Each fixed Gaussian node gets actual BEN fit+calibration anchors."""
    check(profile)
    x, cal = _matrix(fit_features, len(profile.feature_names)), _matrix(calibration_features, len(profile.feature_names))
    y, cy = _roles(fit_truth, len(x)), _roles(calibration_truth, len(cal))
    features = np.vstack([x[y == 0], cal[cy == 0]])
    embedding = np.vstack([np.asarray(fit_embedding)[y == 0], np.asarray(calibration_embedding)[cy == 0]])
    all_keys = hierarchical_keys(features, profile.feature_names, profile.auth_splits)
    values = (features[:, profile.content+profile.predictors]-profile.mean)/profile.scale
    nodes, audit = {}, []
    for key in sorted(profile.nodes):
        rows = np.asarray([i for i, alternatives in enumerate(all_keys) if key in alternatives], dtype=np.int64)
        score = quadratic_score(profile.nodes[key], values[rows], len(profile.content), profile.mode)/profile.cutoff
        q = coordinates(embedding[rows], embedding_scaler, score)
        known = features[rows]
        order = np.lexsort(tuple(q[:, j] for j in range(q.shape[1]-1, -1, -1)))
        known, q = known[order], q[order]
        _, unique = np.unique(known, axis=0, return_index=True)
        unique_coordinates = np.unique(q[unique], axis=0)
        admitted = len(unique_coordinates) >= MIN_FIT
        if admitted:
            index = np.linspace(0, len(unique_coordinates)-1, MAX_ANCHORS, dtype=np.int64) if len(unique_coordinates) > MAX_ANCHORS else np.arange(len(unique_coordinates))
            nodes[key] = unique_coordinates[index].copy()
        audit.append(dict(node=list(key), real_BEN_rows=len(rows), distinct_known_feature_rows=len(unique),
                          unique_coordinates=len(unique_coordinates), admitted=admitted, anchors=len(nodes.get(key, []))))
    state_digest = hashlib.sha256(joblib.hash(nodes, hash_name='sha1').encode('ascii')).hexdigest()
    manifest = dict(schema_version=SCHEMA+'-known-anchors', nodes=audit,
        frozen_anchor_state_sha256=state_digest, coordinate_width=embedding.shape[1]+1,
        sources='actual BEN fit and all known BEN calibration rows; exact feature/coordinate dedup then lexicographic 512-rank cap',
        known_calibration_self_anchors_NOT_held_out_validation=True,
        anchor_coordinates_NOT_physical_event_independence=True, query_truth_features_or_IDs_used=False, published=False)
    manifest['frozen_manifest_sha256'] = _manifest_sha(manifest)
    return dict(nodes=nodes, manifest=manifest)


def route(profile, anchor_policy, query_features, query_coordinates, raw_candidate):
    """Unchanged anchored Algorithm 2/3, one graph per frozen Gaussian node."""
    check(profile)
    anchors = anchor_policy['nodes']
    manifest = anchor_policy['manifest']
    expected = manifest['frozen_anchor_state_sha256']
    if (manifest.get('frozen_manifest_sha256') != _manifest_sha(manifest)
            or manifest.get('query_truth_features_or_IDs_used') is not False
            or manifest.get('schema_version') != SCHEMA+'-known-anchors'
            or hashlib.sha256(joblib.hash(anchors, hash_name='sha1').encode('ascii')).hexdigest() != expected
            or any(key not in profile.nodes or value.ndim != 2 or value.shape[1] != manifest['coordinate_width']
                   or not MIN_FIT <= len(value) <= MAX_ANCHORS or not np.isfinite(value).all()
                   for key, value in anchors.items())):
        raise ValueError("frozen known Gaussian-node anchors changed")
    x = _matrix(query_features, len(profile.feature_names))
    q = np.asarray(query_coordinates, dtype=np.float64)
    raw = np.asarray(raw_candidate)
    if (q.shape != (len(x), anchor_policy['manifest']['coordinate_width']) or not np.isfinite(q).all()
            or raw.shape != (len(x),) or raw.dtype != bool):
        raise ValueError("paired capped current features, frozen coordinates and raw candidates required")
    assigned = assign_nodes(profile, x)
    retained, supported = np.zeros(len(x), dtype=bool), np.zeros(len(x), dtype=bool)
    first, second = np.full(len(x), -2, dtype=np.int64), np.full(len(x), -2, dtype=np.int64)
    primary_free, secondary_free, suspected = (np.zeros(len(x), dtype=bool) for _ in range(3))
    evaluations, first_offset, second_offset = [], 0, 0
    for key in sorted(set(assigned)):
        rows = np.asarray([i for i, value in enumerate(assigned) if value == key], dtype=np.int64)
        if key not in anchors:
            first[rows[raw[rows]]] = -3
            evaluations.append(dict(node=list(key), query_rows=len(rows), raw_candidates=int(raw[rows].sum()),
                status='UNSUPPORTED_UNIQUE_KNOWN_ANCHORS_RETAIN_PARENT'))
            continue
        supported[rows] = True
        out = anchored_route(q[rows], raw[rows], anchors[key])
        retained[rows] = out.retained
        a, b = out.first.copy(), out.second.copy()
        a[a >= 0] += first_offset
        b[b >= 0] += second_offset
        first[rows], second[rows] = a, b
        if np.any(out.first >= 0): first_offset += int(out.first[out.first >= 0].max())+1
        if np.any(out.second >= 0): second_offset += int(out.second[out.second >= 0].max())+1
        primary_free[rows], secondary_free[rows], suspected[rows] = out.primary_anchor_free, out.secondary_anchor_free, out.suspected
        evaluations.append(dict(node=list(key), query_rows=len(rows), raw_candidates=int(raw[rows].sum()),
            retained=int(out.retained.sum()), DVC=out.manifest))
    if np.any(retained & (~raw | ~supported)):
        raise AssertionError("UNA requires a supported actual raw candidate and pure non-noise DVC")
    return dict(retained=retained, supported=supported, first=first, second=second,
        primary_anchor_free=primary_free, secondary_anchor_free=secondary_free, suspected=suspected,
        manifest=dict(schema_version=SCHEMA+'-DVC', query_rows=len(x), raw_candidates=int(raw.sum()), retained=int(retained.sum()),
            nodes=evaluations, Gaussian_and_anchors_frozen_known_only=True, existing_eps_minPts_noise_and_anchor_veto_unchanged=True,
            unsupported_contexts_keep_all_denominator_rows=True, query_truth_family_ID_used=False,
            physical_event_independence_verified=False, independent_final_admitted=False, published=False))
