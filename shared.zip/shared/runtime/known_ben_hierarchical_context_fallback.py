"""Known-only fallback for unsupported NSL BEN contexts; development variant.

The sealed three-field/four-view policy is retained. Only unsupported contexts
may use protocol+service, protocol, then global, in that fixed order. Admission,
whitening, seventh-neighbour LOO/calibration maxima and node-specific ECDFs
use known BEN only. Neither family, query identity nor query truth is an input.
The caller must retain its baseline predictions and require non-noise DVC
before a fallback can add UNA. This is not a literal paper algorithm or a
certificate of query/generalization accuracy.
"""
from dataclasses import dataclass
import hashlib
import numpy as np
from sklearn.neighbors import NearestNeighbors

from . import known_ben_context_whitened_semantic_views as deep
from .known_ben_context_whitened_fit_loo import KnownContextWhitener, context_keys
from .dvc import NoveltyOutput
from .local_ben_affinity_envelope_guarded import _matrix, _roles

SCHEMA = "known-BEN-four-view-deep-context-only-hierarchical-fallback-full-LOO-v1"
LEVELS = ((1, ("protocol_type", "service")), (2, ("protocol_type",)), (3, ()))
MIN_FIT, MIN_CALIBRATION, NEIGHBORS = 8, 3, 7
FIELDS = deep.FIELDS


def _sha(values):
    return hashlib.sha256(np.ascontiguousarray(values).tobytes()).hexdigest()


def _state_sha(group):
    h = hashlib.sha256(float(group["cutoff"]).hex().encode("ascii"))
    metric = group["metric"]
    for v in (metric.mean_, metric.scale_, metric.var_, metric.whitener_, metric.covariance_,
              metric.active_columns_, np.asarray([metric.shrinkage_]),
              np.asarray([metric.n_features_in_, metric.n_samples_seen_]), group["neighbors"]._fit_X):
        a = np.asarray(v, dtype="<f8", order="C")
        h.update(str(a.shape).encode("ascii")); h.update(a.tobytes())
    return h.hexdigest()


def _node_key(level, full_key):
    return (level,) + tuple(full_key[:3-level])


@dataclass
class HierarchicalFallback:
    feature_names: tuple
    columns: dict
    deep_profile: object
    nodes: dict
    manifest: dict


def _node_ratios(node, columns, x):
    values = []
    for view, indices in columns.items():
        group = node["views"][view]
        if (_state_sha(group) != group["state_sha256"] or group["neighbors"].metric != "euclidean"
                or group["neighbors"].n_neighbors != NEIGHBORS):
            raise ValueError("frozen hierarchical reference/metric required")
        d = group["neighbors"].kneighbors(group["metric"].transform(x[:, indices]), return_distance=True)[0][:, -1]
        values.append(d / group["cutoff"])
    return np.max(np.stack(values), axis=0)


def _check(profile):
    m = profile.manifest
    if (m.get("schema_version") != SCHEMA or m.get("frozen_manifest_sha256") != deep._manifest_sha(m)
            or profile.columns != deep.view_columns(profile.feature_names)
            or profile.deep_profile.manifest != m.get("retained_deep_profile_manifest")
            or m.get("hierarchy") != [{"level": i, "context_fields": list(f)} for i, f in LEVELS]
            or m.get("query_truth_or_ID_or_family_used") is not False
            or m.get("retained_baseline_predictions_must_not_be_removed") is not True):
        raise ValueError("frozen predeclared hierarchical policy required")
    declarations = {tuple(row["node"]): row for row in m["nodes"] if row["admitted"]}
    if set(profile.nodes) != set(declarations):
        raise ValueError("frozen hierarchical admission changed")
    for key, node in profile.nodes.items():
        row = declarations[key]
        reference = node["reference"]
        if (tuple(node["views"]) != tuple(profile.columns) or reference.ndim != 1
                or len(reference) != row["correct_BEN_calibration_rows"]
                or len(reference) < MIN_CALIBRATION or not np.isfinite(reference).all()
                or np.any(reference < 0) or np.any(reference > 1)
                or not np.array_equal(reference, np.sort(reference))
                or _sha(reference) != row["aggregate_calibration_ratio_sha256"]):
            raise ValueError("frozen hierarchical node reference changed")
        for view, group in node["views"].items():
            if group["state_sha256"] != row["views"][view]["state_sha256"]:
                raise ValueError("frozen hierarchical view declaration changed")


def fit_profile(fit_features, fit_truth, calibration_features, calibration_truth,
                primary, baseline, feature_names, deep_profile):
    x, cal = _matrix(fit_features, "known fit"), _matrix(calibration_features, "known calibration")
    y, cy = _roles(fit_truth, len(x), "known fit truth"), _roles(calibration_truth, len(cal), "known calibration truth")
    p = _roles(primary, len(cal), "known calibration primary")
    b = np.asarray(baseline)
    names = tuple(str(n) for n in feature_names)
    if (x.shape[1] != len(names) or cal.shape[1] != len(names) or b.shape != p.shape
            or b.dtype.kind not in "iu" or not np.isin(b, (0, 1, 2)).all()
            or np.any((b != p) & (b != 2)) or set(cy.tolist()) != {0, 1}
            or deep_profile.feature_names != names):
        raise ValueError("paired known-only baseline and sealed deep profile required")
    # Validate the entire retained profile before fitting any new geometry.
    deep.components(deep_profile, cal)
    columns = deep.view_columns(names)
    fk, ck = context_keys(x, names), context_keys(cal, names)
    protected = (cy == 0) & (p == 0) & (b == 0)
    nodes, audit = {}, []
    for level, _ in LEVELS:
        fkeys, ckeys = [_node_key(level, k) for k in fk], [_node_key(level, k) for k in ck]
        for key in sorted({k for k, label in zip(fkeys, y) if label == 0}):
            fi = np.array([i for i, k in enumerate(fkeys) if k == key and y[i] == 0], dtype=np.int64)
            ci = np.array([i for i, k in enumerate(ckeys) if k == key and protected[i]], dtype=np.int64)
            row = {"node": list(key), "known_BEN_fit_rows": len(fi), "correct_BEN_calibration_rows": len(ci),
                   "admitted": len(fi) >= MIN_FIT and len(ci) >= MIN_CALIBRATION}
            if not row["admitted"]:
                audit.append(row); continue
            node, view_audit = {"views": {}}, {}
            for view, indices in columns.items():
                known = x[fi][:, indices]
                order = np.lexsort(tuple(known[:, i] for i in range(known.shape[1]-1, -1, -1)))
                known = known[order]
                metric = KnownContextWhitener().fit(known)
                z = metric.transform(known)
                nn = NearestNeighbors(n_neighbors=NEIGHBORS, metric="euclidean", n_jobs=1).fit(z)
                ds = nn.kneighbors(metric.transform(cal[ci][:, indices]), return_distance=True)[0][:, -1]
                graph = NearestNeighbors(n_neighbors=NEIGHBORS+1, metric="euclidean", n_jobs=1).fit(z)
                fit_ds, fit_i = graph.kneighbors(z, return_distance=True)
                loo = np.array([fit_ds[i][fit_i[i] != i][NEIGHBORS-1] for i in range(len(known))], dtype=np.float64)
                maximum = max(1.e-12, float(ds.max()), float(loo.max()))
                cutoff = float(maximum + 64*np.finfo(np.float64).eps*max(1., maximum))
                group = {"metric": metric, "neighbors": nn, "cutoff": cutoff}
                group["state_sha256"] = _state_sha(group)
                node["views"][view] = group
                view_audit[view] = {"cutoff": cutoff, "known_fit_geometry_sha256": _sha(known),
                    "fit_LOO_distance_sha256": _sha(loo), "fit_LOO_maximum": float(loo.max()),
                    "calibration_distance_maximum": float(ds.max()), "state_sha256": group["state_sha256"]}
            reference = np.sort(_node_ratios(node, columns, cal[ci]))
            if np.any(reference > 1):
                raise AssertionError("full-view known-calibration fallback retention failed")
            node["reference"] = reference
            nodes[key] = node
            audit.append({**row, "views": view_audit, "aggregate_calibration_ratio_sha256": _sha(reference)})
    manifest = {"schema_version": SCHEMA, "hierarchy": [{"level": i, "context_fields": list(f)} for i, f in LEVELS],
        "retained_deep_profile_manifest": deep_profile.manifest, "nodes": audit,
        "view_columns": {k: list(v) for k, v in columns.items()},
        "selection": "deep support keeps baseline; otherwise first admitted node in fixed levels 1,2,3",
        "full_BEN_fit_LOO_and_correct_cal_maximum_in_each_view": True,
        "reference_ECDF": "same chosen node aggregate maximum ratio on all protected known BEN calibration rows",
        "minimum_fit": MIN_FIT, "minimum_calibration": MIN_CALIBRATION, "neighbors": NEIGHBORS,
        "context_minima_are_NOT_Table1_family_or_independent_event_floors": True,
        "omitted_context_fields_remain_in_numeric_geometry": True,
        "known_only_calibration": True, "query_truth_or_ID_or_family_used": False,
        "query_batch_refit_or_query_based_level_selection": False,
        "retained_baseline_predictions_must_not_be_removed": True,
        "non_noise_DVC_required": True, "all_query_rows_counted": True,
        "KNA_novelty_fields_unchanged": True, "strict_greater_than": True,
        "historical_development_inspection_precedes_rule_design": True,
        "new_query_99_NOT_guaranteed": True, "status": "FAIL_TARGET99", "published": False,
        "final_test_executed": False}
    manifest["frozen_manifest_sha256"] = deep._manifest_sha(manifest)
    profile = HierarchicalFallback(names, columns, deep_profile, nodes, manifest)
    _check(profile)
    ratios, _, _, eligible, _ = components(profile, cal)
    if np.any(protected & eligible & (ratios > 1)):
        raise AssertionError("chosen fallback known-calibration retention failed")
    return profile


def components(profile, features):
    _check(profile)
    x = _matrix(features, "hierarchical fallback query")
    if x.shape[1] != len(profile.feature_names):
        raise ValueError("full saved model feature width required")
    _, _, deep_supported = deep.components(profile.deep_profile, x)
    keys = context_keys(x, profile.feature_names)
    ratios, percentiles = np.zeros(len(x)), np.zeros(len(x))
    chosen = np.full(len(x), -1, dtype=np.int64)
    chosen[deep_supported] = 0
    for level, _ in LEVELS:
        node_keys = [_node_key(level, k) for k in keys]
        for key, node in profile.nodes.items():
            if key[0] != level: continue
            indices = np.array([i for i, k in enumerate(node_keys) if k == key and chosen[i] == -1], dtype=np.int64)
            if not len(indices): continue
            values = _node_ratios(node, profile.columns, x[indices])
            ratios[indices] = values
            ref = node["reference"]
            percentiles[indices] = np.searchsorted(ref, values, side="right")/(len(ref)+1.)
            chosen[indices] = level
    eligible = chosen > 0
    if not np.isfinite(ratios).all() or not np.isfinite(percentiles).all():
        raise ValueError("fallback ratio or rank overflow")
    return ratios, percentiles, chosen, eligible, deep_supported


def score(profile, features, primary, original):
    ratio, rank, level, eligible, deep_supported = components(profile, features)
    p = _roles(primary, len(ratio), "query primary")
    if (not isinstance(original, NoveltyOutput)
            or any(np.asarray(getattr(original, k)).shape != p.shape for k in FIELDS)
            or any(not np.isfinite(getattr(original, k)).all() for k in FIELDS)
            or np.asarray(original.candidate).dtype != bool):
        raise ValueError("paired finite retained novelty required")
    values = {k: np.asarray(getattr(original, k)).copy() for k in FIELDS}
    changed = (p == 0) & eligible
    values["score"][changed] = ratio[changed]
    values["threshold"][changed] = values["high_threshold"][changed] = 1.
    values["candidate"][changed] = ratio[changed] > 1.
    values["feature_knn_percentile"][changed] = rank[changed]
    return NoveltyOutput(**values, score_strategy="known_BEN_unsupported_context_hierarchical_fallback_"+original.score_strategy), ratio, level, eligible, deep_supported
