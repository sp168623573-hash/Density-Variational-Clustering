"""Audit one frozen feature-only NSL1 development replay, never a final test.

Source features and frozen role IDs reconstruct the query without loading an
old query prediction archive. Query labels and the warmed 2189 oracle are read
only after new predictions have been saved. Inference runs with file I/O
disabled and repeats the identical batch in reverse order.
"""
import argparse
import builtins
from contextlib import contextmanager, ExitStack
import hashlib
import io
import json
import os
from pathlib import Path
import pickle
import time
from unittest.mock import patch
import zipfile

import joblib
import numpy as np
import pandas as pd
import torch

from .config import NSL_FEATURE_COLUMNS, get_spec
from .data import _feature_fingerprint, sha256_file
from .external_dev import normalized_feature_fingerprints
from .known_role_floor_development import formal_snapshot
from .nsl_frozen_feature_pipeline import load_pipeline
from .reporting import _open_matrix_text, write_json


ROOT = Path(__file__).resolve().parents[1]
MODEL = "NSL-KDD Setting1/run/role_floor_log_numeric_20261002_v1"
SOURCE_CONTRACT = "tmp/original_source_proportional_preflight_20260929_v6.json"
SOURCE_CONTRACT_SHA = "dffc91516a1d36197503aa4bc582afdce2c2e4fa7f8735244be19e5171934746"
DEV_MANIFEST = "data/external_dev/processed/nsl_all_table1_setting1/setting1_all_unknown.manifest.json"
DEV_MANIFEST_SHA = "2b63f8ff7787059b45b17884fdf1b2082b5f2a31de468433742104df08cea2cb"
ORACLE = "NSL-KDD Setting1/run/auth_context_separated_dvc_20261004_v1"
HISTORICAL_BRANCHES = {
    "fused": ("role_floor_dual_log_BEN_midrank_geometry_20261002_v1", "geometry_parent"),
    "white": ("role_floor_dual_log_BEN_midrank_geometry_20261002_v1", "whiten_geometry_final"),
    "hierarchy": ("role_floor_dual_log_BEN_hierarchical_fallback_20261002_v1", "final"),
    "radius": ("role_floor_dual_log_BEN_local_radius_cover_20261002_v1", "final"),
    "reach": ("role_floor_dual_log_BEN_whitened_local_reachability_20261002_v2", "final"),
    "joint": ("role_floor_dual_log_BEN_joint_whitened_local_reachability_20261002_v1", "final"),
    "consensus": ("role_floor_dual_log_BEN_local_density_consensus_20261002_v1", "final"),
    "witness": ("retained_BEN_content_density_witness_20261003_v1", "final"),
    "content_anchors": ("content_density_known_BEN_anchor_DVC_20261003_v1", "final"),
    "covering": ("retained_covering_density_recompute_20261003_v2", "final"),
    "conditional": ("retained_conditional_density_recompute_20261003_v1", "final"),
    "sparse": ("sparse_known_reference_guard_20261003_v1", "final"),
    "greedy": ("greedy_known_reference_guard_20261003_v1", "final"),
    "auth": ("auth_context_known_reference_guard_20261003_v1", "final"),
    "quorum": ("auth_quorum_known_reference_guard_20261004_v1", "final"),
    "context": ("auth_context_separated_dvc_20261004_v1", "final"),
}
BRANCHES = ("fused", "white", "hierarchy", "radius", "reach", "joint", "consensus",
            "witness", "content_anchors", "covering", "conditional", "sparse", "greedy",
            "auth", "quorum", "context")
ROW_OUTPUTS = ("final", "stage1", "original_stage1", "log_stage1", "original_model_features",
               "log_model_features", "query_coordinates", "context_score", "context_raw_candidate",
               "context_retained", "context_supported", "context_first_cluster", "context_second_cluster")
PERMUTATION_RTOL = 1e-6
PERMUTATION_ATOL = 1e-6
FAILED_SOURCE_ARCHIVE = "tmp/target99_continuation_20261004_v2/replay_nsl_frozen_feature_pipeline.before_identity_repair.py"
FAILED_V2_HARNESS_SHA = "2dc97fcfb6124fb58be52dfe49754a1518f38a24362d363a6aa0a1cca7c9ecc9"
FAILED_V2_PREDICTION_SHA = "8ee814010ca13a936f4d8271a4732abc045fe1c452f3a473345b66e11fa90f2f"
FAILED_V2_RAW40_SHA = "5dfbcda9d2214a4aaaf0e052f762657ad04507b8c39f9de060f46a0a3b35580c"
HISTORICAL_ID_PRODUCER_SHA = "62ed42cf76ac1cae90338adc6fec8681e2092aa805336b79825337926b430038"


def integer_gates(truth, prediction):
    truth, prediction = np.asarray(truth), np.asarray(prediction)
    if (truth.ndim != 1 or truth.shape != prediction.shape or truth.dtype.kind not in "iu"
            or prediction.dtype.kind not in "iu" or not np.isin(truth, (0, 1, 2)).all()
            or not np.isin(prediction, (0, 1, 2)).all()):
        raise ValueError("equal integer three-class vectors required")
    result = {}
    for index, label in enumerate(("BEN", "KNA", "UNA")):
        support = int(np.sum(truth == index))
        correct = int(np.sum((truth == index) & (prediction == index)))
        required = (99 * support + 99) // 100
        result[label] = dict(correct=correct, support=support, required_for_99pct=required,
            gap_to_gate=max(0, required-correct), passed_on_observed_rows_only=support > 0 and correct >= required)
    return result


def paired_delta(truth, old, new):
    previous, candidate = integer_gates(truth, old), integer_gates(truth, new)
    delta = {label: candidate[label]["correct"] - previous[label]["correct"] for label in previous}
    nonzero = [value for value in delta.values() if value]
    effect = "UNCHANGED" if not nonzero else "UP" if min(nonzero) > 0 else "DOWN" if max(nonzero) < 0 else "MIXED"
    return dict(EffectDelta=effect, correct_count_delta_same_IDs=delta, baseline=previous, candidate=candidate,
                same_frozen_feature_cohort_and_denominators=True, accepted_baseline_replaced=False,
                ordering_repair_is_a_declared_policy_change=True)


@contextmanager
def forbid_inference_io():
    """A loaded policy must infer without any filesystem/archive loader call."""
    attempts = []

    def forbidden(*args, **kwargs):
        # Do not expose sensitive arguments in failure receipts.
        attempts.append("file_or_archive_access_during_predict")
        raise RuntimeError("file/archive I/O is forbidden while frozen prediction runs")

    with ExitStack() as stack:
        for owner, name in ((builtins, "open"), (io, "open"), (os, "open"), (Path, "open"),
                            (Path, "read_bytes"), (Path, "read_text"), (np, "load"), (pd, "read_csv"),
                            (joblib, "load"), (torch, "load")):
            stack.enter_context(patch.object(owner, name, forbidden))
        yield attempts


def _normalized(frame):
    result = frame.loc[:, list(NSL_FEATURE_COLUMNS)].copy()
    for name in NSL_FEATURE_COLUMNS[:3]:
        result[name] = result[name].astype(str).str.strip().str.casefold()
    for name in NSL_FEATURE_COLUMNS[3:]:
        result[name] = pd.to_numeric(result[name], errors="raise")
    return result


def _raw40(path):
    """Materialize only physical columns 1..40, excluding duration and truth."""
    frame = pd.read_csv(path, header=None, usecols=list(range(1, 41)), low_memory=False)
    frame.columns = NSL_FEATURE_COLUMNS
    return frame


def historical_ids_from_source(known_ids, unknown_raw_row_sha):
    """Reproduce the pinned old producer's fixed dev: serialization, not lookup."""
    known = np.asarray(known_ids, dtype=str)
    unknown = np.asarray(unknown_raw_row_sha, dtype=str)
    if (known.ndim != 1 or unknown.ndim != 1 or len(known) + len(unknown) > 6000
            or any(len(value) != 64 or any(c not in "0123456789abcdef" for c in value) for value in unknown)):
        raise ValueError("capped exact raw-row SHA identities required")
    result = np.concatenate([known, np.char.add("dev:", unknown)]).astype(str)
    if len(set(result)) != len(result):
        raise ValueError("source-derived historical identities must be unique")
    return result


def unicode_query_array(frame):
    """DataFrame.astype(str).to_numpy alone retains object dtype; force Unicode."""
    return frame.astype(str).to_numpy(dtype=str)


def read_sealed_generated_strings(path, key, expected_sha256, expected_shape):
    """Recover only exact, hash-sealed string members from our failed v2 NPZ.

    New output uses Unicode and never needs this recovery. Object decoding has
    an exact member, shape and SHA gate and a NumPy-only restricted unpickler.
    It does not accept arbitrary pickle globals or unsealed input artifacts.
    """
    path = Path(path)
    if sha256_file(path) != expected_sha256:
        raise ValueError("generated string archive SHA differs from its original seal")
    shape = tuple(expected_shape)
    if not ((key == "sample_id" and len(shape) == 1 or key == "raw40" and len(shape) == 2 and shape[1] == 40)
            and 1 <= shape[0] <= 6000):
        raise ValueError("bounded exact generated string shape required")
    with zipfile.ZipFile(path) as archive:
        if len(archive.namelist()) != len(set(archive.namelist())):
            raise ValueError("duplicate ZIP members forbidden in sealed generated arrays")
        member = archive.getinfo(key + ".npy")
        if member.file_size > 32 * 1024 * 1024 or member.flag_bits & 1:
            raise ValueError("bounded unencrypted generated array member required")
        data = io.BytesIO(archive.read(member))
    version = np.lib.format.read_magic(data)
    if version == (1, 0):
        stored_shape, _, dtype = np.lib.format.read_array_header_1_0(data)
    elif version == (2, 0):
        stored_shape, _, dtype = np.lib.format.read_array_header_2_0(data)
    else:
        raise ValueError("supported generated NumPy array header required")
    if stored_shape != shape:
        raise ValueError("generated string array shape differs from frozen source reconstruction")
    if dtype.kind == "U":
        with np.load(path, allow_pickle=False) as archive:
            result = archive[key].copy()
    elif dtype == np.dtype(object):
        class StringArrayOnly(pickle.Unpickler):
            def find_class(self, module, name):
                if module in ("numpy.core.multiarray", "numpy._core.multiarray") and name == "_reconstruct":
                    return np._core.multiarray._reconstruct
                if module == "numpy" and name in ("ndarray", "dtype"):
                    return getattr(np, name)
                raise pickle.UnpicklingError("non-array global forbidden in generated string recovery")
        result = StringArrayOnly(data).load()
        if data.read() != b"":
            raise ValueError("trailing pickle bytes forbidden in generated string recovery")
    else:
        raise ValueError("generated metadata must be a Unicode or string-only object array")
    if (type(result) is not np.ndarray or result.shape != shape or result.dtype != dtype
            or any(not isinstance(value, str) or len(value) > 512 for value in result.flat)):
        raise ValueError("bounded all-string generated array required")
    if sha256_file(path) != expected_sha256:
        raise ValueError("generated string archive changed during recovery")
    return result.astype(str)


def reconstruct_query(root, pin):
    """Rebuild frozen query feature cells without decoding any label column."""
    report = json.loads(pin(MODEL + "/report.json").read_text(encoding="utf8"))
    role_path = pin(MODEL + "/frozen_role_ids.npz", report["frozen_policy"]["role_ids_sha256"])
    with np.load(role_path, allow_pickle=False) as archive:
        known_ids = archive["open_known"].astype(str).copy()
    contract = json.loads(pin(SOURCE_CONTRACT, SOURCE_CONTRACT_SHA).read_text(encoding="utf8"))
    known_source = contract["sources"]["nsl_original_train"]
    known_path = pin(known_source["path"], known_source["sha256"])
    raw_known = _raw40(known_path)
    if len(raw_known) != known_source["rows"]:
        raise ValueError("known physical source row count changed")
    ordinals = []
    for identifier in known_ids:
        parts = identifier.split(":")
        if (len(parts) != 5 or parts[:2] != ["nsl_kdd", "original-source-train"]
                or parts[2] != known_source["sha256"] or not parts[3].isdigit()):
            raise ValueError("frozen known source identity contract differs")
        ordinal = int(parts[3])
        if not 0 <= ordinal < len(raw_known):
            raise ValueError("known source ordinal out of range")
        ordinals.append(ordinal)
    known_rows = np.asarray(ordinals, dtype=np.int64)
    known = raw_known.iloc[known_rows].reset_index(drop=True)
    np.testing.assert_array_equal(_feature_fingerprint(known, NSL_FEATURE_COLUMNS).to_numpy(dtype=str),
                                  np.asarray([identifier.split(":")[-1] for identifier in known_ids]))
    manifest_path = pin(DEV_MANIFEST, DEV_MANIFEST_SHA)
    manifest = json.loads(manifest_path.read_text(encoding="utf8"))
    if (manifest.get("role") != "external_unknown_dev"
            or manifest.get("status") != "admitted_zero_shared_feature_overlap_same_lineage"
            or manifest["frozen_test_overlap_audit"]["frozen_test_labels_used_for_selection"] is not False):
        raise ValueError("historically admitted nonfinal development manifest required")
    csv_path = pin(manifest["integrity"]["output_csv"], manifest["integrity"]["output_csv_sha256"])
    metadata_columns = ("source_file", "source_row_number", "raw_row_sha256", "original_sha256", "model_feature_sha256")
    frame = pd.read_csv(csv_path, usecols=[*metadata_columns, *NSL_FEATURE_COLUMNS], low_memory=False)
    if len(frame) != manifest["selection"]["selected_rows"]:
        raise ValueError("frozen full development denominator changed")
    unknown_ids = frame["raw_row_sha256"].astype(str).str.casefold().to_numpy(dtype=str)
    if len(set(unknown_ids)) != len(unknown_ids):
        raise ValueError("development physical source-row identities are not unique")
    source_paths, raw_features, raw_lines = {}, {}, {}
    declarations = {item["source_file"]: item for item in manifest["sources"]}
    if len(declarations) != len(manifest["sources"]):
        raise ValueError("duplicate development source declaration")
    for source_file in sorted(set(frame["source_file"].astype(str))):
        declaration = declarations[source_file]
        path = pin(declaration["path"], declaration["sha256"])
        source_paths[source_file] = path
        raw_features[source_file], raw_lines[source_file] = _raw40(path), path.read_bytes().splitlines(keepends=True)
        if len(raw_features[source_file]) != declaration["rows"] or len(raw_lines[source_file]) != declaration["rows"]:
            raise ValueError("development raw source row count differs")
    rebuilt = []
    for record in frame.loc[:, list(metadata_columns)].itertuples(index=False):
        ordinal = int(record.source_row_number)
        if ordinal != record.source_row_number or not 1 <= ordinal <= len(raw_lines[record.source_file]):
            raise ValueError("development physical source ordinal out of range")
        if (str(record.original_sha256).casefold() != declarations[record.source_file]["sha256"]
                or hashlib.sha256(raw_lines[record.source_file][ordinal-1]).hexdigest() != str(record.raw_row_sha256).casefold()):
            raise ValueError("development exact physical source binding differs")
        rebuilt.append(raw_features[record.source_file].iloc[ordinal-1].to_dict())
    unknown = pd.DataFrame(rebuilt, columns=NSL_FEATURE_COLUMNS)
    fingerprints = normalized_feature_fingerprints(_normalized(unknown), NSL_FEATURE_COLUMNS).astype(str).to_numpy()
    claimed = normalized_feature_fingerprints(_normalized(frame), NSL_FEATURE_COLUMNS).astype(str).to_numpy()
    np.testing.assert_array_equal(fingerprints, claimed)
    np.testing.assert_array_equal(fingerprints, frame["model_feature_sha256"].astype(str).str.casefold().to_numpy())
    if len(set(fingerprints)) != len(fingerprints):
        raise ValueError("historical one-row-per-40-feature-fingerprint cohort changed")
    ids = historical_ids_from_source(known_ids, unknown_ids)
    if len(ids) > 6000 or len(set(ids)) != len(ids):
        raise ValueError("unique capped frozen query identities required")
    query = pd.concat([known, unknown], ignore_index=True).loc[:, list(NSL_FEATURE_COLUMNS)]
    return dict(frame=query, sample_id=ids, known_ids=known_ids, known_rows=known_rows,
                known_path=known_path, unknown_metadata=frame.loc[:, list(metadata_columns)].copy(),
                unknown_csv=csv_path, unknown_source_paths=source_paths,
                audit=dict(known_rows=len(known), unknown_rows=len(unknown), total_query_rows=len(query),
                    raw_model_fields_reconstructed=40, query_label_columns_materialized=False,
                    source_SHA_and_exact_unknown_row_SHA_verified=True,
                    unknown_all_40_cells_equal_processed_manifest_cells=True,
                    old_prediction_archive_opened=False,
                    raw_byte_hashing_does_not_interpret_label_cells=True,
                    feature_rows_are_NOT_independent_physical_events=True))


def validate_prediction(result, rows):
    if set(result["branches"]) != set(BRANCHES):
        raise ValueError("every retained parent branch must be recomputed")
    for name in ROW_OUTPUTS:
        value = np.asarray(result[name])
        if len(value) != rows or (value.dtype.kind in "fc" and not np.isfinite(value).all()):
            raise ValueError("invalid frozen pipeline row output: " + name)
    for name in ("final", "stage1", "original_stage1", "log_stage1"):
        value = np.asarray(result[name])
        if value.shape != (rows,) or value.dtype.kind not in "iu" or not np.isin(value, (0, 1, 2)).all():
            raise ValueError("integer class vector required: " + name)
    for name, branch in result["branches"].items():
        if np.asarray(branch["final"]).shape != (rows,) or "DVC" not in branch:
            raise ValueError("missing recomputed full branch trace: " + name)
    protocol = result["protocol"]
    if (protocol.get("query_truth_ID_family_source_used") is not False
            or protocol.get("query_prediction_archives_used") is not False
            or protocol.get("full_chain_recomputed_from_query_model_features") is not True
            or protocol.get("covering_and_conditional_ordering_repaired_from_ID_to_numeric") is not True):
        raise ValueError("feature-only retained-parent recomputation flags required")


def permutation_check(first, reversed_result):
    checks, numeric, structural = {}, {}, {}
    for name in ROW_OUTPUTS:
        original, restored = np.asarray(first[name]), np.asarray(reversed_result[name])[::-1]
        checks[name] = bool(np.array_equal(original, restored))
        if original.dtype.kind in "fc":
            numeric[name] = dict(exact=checks[name], max_absolute_difference=float(np.max(np.abs(original-restored))),
                within_declared_tolerance=bool(np.allclose(original, restored, rtol=PERMUTATION_RTOL, atol=PERMUTATION_ATOL)))
        else:
            structural[name] = checks[name]
    for name in BRANCHES:
        checks["branch_" + name] = bool(np.array_equal(first["branches"][name]["final"],
                                                     reversed_result["branches"][name]["final"][::-1]))
        structural["branch_" + name] = checks["branch_" + name]
    return dict(all_row_outputs_exact=all(checks.values()), by_output=checks,
        all_integer_boolean_forecasts_and_clusters_exact=all(structural.values()),
        all_floating_outputs_within_declared_tolerance=all(value["within_declared_tolerance"] for value in numeric.values()),
        declared_before_query_floating_tolerance=dict(rtol=PERMUTATION_RTOL, atol=PERMUTATION_ATOL), floating_outputs=numeric)


def reject_metadata(pipeline, sample):
    checks = {}
    for name in ("sample_id", "label", "paper_target_family", "source_file"):
        frame = sample.copy()
        frame[name] = "forbidden-query-metadata"
        try:
            pipeline.predict_frame(frame)
        except ValueError:
            checks[name] = True
        else:
            checks[name] = False
    return checks


def load_truth_after_save(query, saved_path):
    if not saved_path.is_file():
        raise ValueError("predictions must exist before held truth is decoded")
    spec = get_spec("NSL-KDD Setting1")
    raw = pd.read_csv(query["known_path"], header=None, usecols=[41], low_memory=False).iloc[:, 0]
    known_families = raw.iloc[query["known_rows"]].astype(str).str.strip().str.casefold().str.removesuffix(".").to_numpy()
    if set(known_families) - {"normal", *spec.known_families}:
        raise ValueError("frozen known-open truth contains an undeclared class")
    metadata = pd.read_csv(query["unknown_csv"], usecols=["raw_row_sha256", "raw_label", "paper_target_family"], low_memory=False)
    np.testing.assert_array_equal(metadata["raw_row_sha256"].astype(str).str.casefold().to_numpy(dtype=str),
                                  query["unknown_metadata"]["raw_row_sha256"].astype(str).str.casefold().to_numpy(dtype=str))
    families = metadata["paper_target_family"].astype(str).str.strip().str.casefold().to_numpy()
    raw_label = metadata["raw_label"].astype(str).str.strip().str.casefold().str.removesuffix(".").to_numpy()
    np.testing.assert_array_equal(families, raw_label)
    if set(families) - set(spec.unknown_families):
        raise ValueError("frozen development truth contains an undeclared unknown family")
    source_truth = {name: pd.read_csv(path, header=None, usecols=[41], low_memory=False).iloc[:, 0]
                    for name, path in query["unknown_source_paths"].items()}
    actual = np.asarray([str(source_truth[row.source_file].iloc[int(row.source_row_number)-1]).strip().casefold().removesuffix(".")
                         for row in query["unknown_metadata"].itertuples(index=False)])
    np.testing.assert_array_equal(actual, families)
    truth = np.r_[(known_families != "normal").astype(np.int64), np.full(len(families), 2, dtype=np.int64)]
    counts = {name: int(np.sum(families == name)) for name in spec.unknown_families}
    coverage = dict(declared_family_counts_including_zero=counts, minimum_per_declared_family=20,
        deficit_by_family={name: 20-count for name, count in counts.items() if count < 20},
        all_declared_families_meet_feature_row_floor=all(count >= 20 for count in counts.values()),
        feature_rows_are_NOT_independent_physical_events=True)
    return truth, coverage


def align_oracle(ids, oracle_ids, oracle_final):
    ids, oracle_ids, oracle_final = np.asarray(ids, dtype=str), np.asarray(oracle_ids, dtype=str), np.asarray(oracle_final)
    if (len(ids) != len(oracle_ids) or len(oracle_ids) != len(oracle_final)
            or len(set(ids)) != len(ids) or len(set(oracle_ids)) != len(oracle_ids)
            or set(ids) != set(oracle_ids)):
        raise ValueError("historical oracle must have the exact same unique frozen query IDs")
    positions = {identifier: index for index, identifier in enumerate(oracle_ids)}
    return oracle_final[np.asarray([positions[identifier] for identifier in ids], dtype=np.int64)]


def compare_historical_branches(query, result, truth, saved_path, pin):
    """Historical cumulative forecasts are diagnostic oracles after the seal."""
    if not saved_path.is_file():
        raise ValueError("new forecasts must exist before historical branch archives are opened")
    comparison = {}
    for name in BRANCHES:
        directory, field = HISTORICAL_BRANCHES[name]
        base = ROOT / "NSL-KDD Setting1/run" / directory
        receipt = json.loads(pin(base / "report.json").read_text(encoding="utf8"))
        if receipt.get("published") is not False or receipt.get("final_test_executed") is not False:
            raise ValueError("nonfinal historical branch receipt required: " + name)
        archive_path = pin(base / "predictions_frozen_before_counting.npz", receipt["predictions_sha256"])
        with np.load(archive_path, allow_pickle=False) as archive:
            historical = align_oracle(query["sample_id"], archive["sample_id"], archive[field])
        candidate = np.asarray(result["branches"][name]["final"])
        comparison[name] = dict(archive=str(archive_path), field=field,
            exact_forecast_equal=bool(np.array_equal(candidate, historical)),
            changed_rows=int(np.sum(candidate != historical)),
            historical_cumulative_forecast_oracle_used_only_after_prediction_seal=True,
            EffectDelta=paired_delta(truth, historical, candidate))
    first = next((name for name in BRANCHES if not comparison[name]["exact_forecast_equal"]), None)
    return dict(first_differing_cumulative_branch=first, by_branch=comparison,
                no_historical_branch_used_for_current_prediction=True)


def run(compiled_directory, output_directory, oracle_directory=ORACLE):
    compiled, output, oracle = (Path(path).resolve() for path in (compiled_directory, output_directory, oracle_directory))
    if ROOT not in compiled.parents or ROOT not in output.parents or ROOT not in oracle.parents or output.exists():
        raise ValueError("contained compiler/oracle and new contained replay output required")
    started = time.perf_counter()
    formal, pins = formal_snapshot(ROOT), {}

    def pin(path, expected=None):
        path = Path(path)
        path = path if path.is_absolute() else ROOT / path
        digest = sha256_file(path)
        if expected is not None and digest != expected:
            raise ValueError("sealed replay source changed: " + str(path))
        pins[str(path.resolve())] = digest
        return path

    output.mkdir(parents=True, exist_ok=False)
    common = dict(status="FAIL_TARGET99", published=False, final_test_executed=False,
        accepted_baseline_replaced=False, new_neural_epochs=0, new_qualified_independent_Table1_flows=0,
        independent_final_admitted=False, physical_event_independence_verified=False,
        scope="frozen feature-only same-lineage development replay NOT independent final")
    phase = "freeze_compiler_before_query"
    try:
        manifest_path = pin(compiled / "manifest.json")
        manifest = json.loads(manifest_path.read_text(encoding="utf8"))
        pin(compiled / "pipeline.joblib", manifest["pipeline_sha256"])
        for path, digest in manifest.get("inference_source_sha256", {}).items():
            pin(path, digest)
        pin(Path(__file__))
        write_json(output / "compiler_manifest_frozen_before_query.json", dict(**common,
            compiled_manifest=manifest, compiler_manifest_sha256=pins[str(manifest_path.resolve())],
            input_sha256=pins.copy(), held_query_truth_or_historical_oracle_loaded=False,
            fixed_experiment="unchanged full retained recipes with numeric canonical DVC sorting",
            ordering_repair_not_selected_using_current_replay_truth=True,
            current_replay_parameters_refit_or_selected=False,
            permutation_float_tolerance_predeclared=dict(rtol=PERMUTATION_RTOL, atol=PERMUTATION_ATOL),
            historical_development_inspection_precedes_design=True))
        phase = "raw40_query_reconstruction"
        query = reconstruct_query(ROOT, pin)
        query_freeze = output / "query_raw40_frozen_before_prediction.npz"
        np.savez_compressed(query_freeze, raw40=unicode_query_array(query["frame"]),
                            feature_columns=np.asarray(NSL_FEATURE_COLUMNS, dtype=str))
        query_freeze_sha = sha256_file(query_freeze)
        write_json(output / "query_source_audit_before_prediction.json", dict(**query["audit"],
            raw40_query_array_sha256=query_freeze_sha, input_sha256=pins.copy()))
        phase = "load_sealed_policy_after_query_feature_freeze"
        pipeline = load_pipeline(compiled)
        phase = "feature_only_prediction_with_file_IO_disabled"
        with forbid_inference_io() as attempts:
            metadata_rejected = reject_metadata(pipeline, query["frame"].iloc[:1])
            if not all(metadata_rejected.values()):
                raise ValueError("query metadata was accepted by the pure feature API")
            result = pipeline.predict_frame(query["frame"])
            validate_prediction(result, len(query["frame"]))
        if attempts:
            raise ValueError("inference attempted hidden file/archive access")
        saved_path = output / "predictions_frozen_before_counting.npz"
        arrays = {name: result[name] for name in ROW_OUTPUTS}
        arrays.update({"branch_" + name: result["branches"][name]["final"] for name in BRANCHES})
        np.savez_compressed(saved_path, sample_id=query["sample_id"], **arrays)
        prediction_sha = sha256_file(saved_path)
        write_json(output / "prediction_seal_before_truth.json", dict(**common, predictions_sha256=prediction_sha,
            all_query_prediction_rows_saved=True, held_truth_or_old_oracle_loaded=False,
            metadata_ID_truth_source_columns_rejected=metadata_rejected, file_IO_during_predict_attempts=0,
            recomputed_parent_branches=list(result["branches"]), protocol=result["protocol"]))
        phase = "identical_batch_reverse_order_check"
        with forbid_inference_io() as reverse_attempts:
            reverse = pipeline.predict_frame(query["frame"].iloc[::-1].reset_index(drop=True))
            validate_prediction(reverse, len(query["frame"]))
        if reverse_attempts:
            raise ValueError("reverse inference attempted hidden file/archive access")
        permutation = permutation_check(result, reverse)
        write_json(output / "permutation_check_before_truth.json", permutation)
        phase = "held_historical_truth_count_after_prediction_seal"
        truth, coverage = load_truth_after_save(query, saved_path)
        gates = integer_gates(truth, result["final"])
        phase = "historical_2189_oracle_comparison_after_prediction_seal"
        oracle_report = json.loads(pin(oracle / "report.json").read_text(encoding="utf8"))
        if oracle_report["published"] or oracle_report["final_test_executed"]:
            raise ValueError("nonfinal historical development oracle required")
        with np.load(pin(oracle / "predictions_frozen_before_counting.npz", oracle_report["predictions_sha256"]), allow_pickle=False) as archive:
            baseline = align_oracle(query["sample_id"], archive["sample_id"], archive["final"])
        prior = integer_gates(truth, baseline)
        if prior != oracle_report["observed_development_gates"]:
            raise ValueError("historical aligned oracle truth denominator/counts differ")
        effect = paired_delta(truth, baseline, result["final"])
        phase = "historical_cumulative_branch_comparison_after_prediction_seal"
        historical_branches = compare_historical_branches(query, result, truth, saved_path, pin)
        matrix = np.bincount(3*np.asarray(result["final"]) + truth, minlength=9).reshape(3, 3)
        (output / "Matrix.txt").write_text("非独立最终测试；FAIL_TARGET99; published=false\n" + _open_matrix_text(matrix), encoding="utf8")
        if sha256_file(saved_path) != prediction_sha or sha256_file(query_freeze) != query_freeze_sha:
            raise ValueError("prediction seal changed after truth decoding")
        if formal_snapshot(ROOT) != formal or any(sha256_file(Path(path)) != digest for path, digest in pins.items()):
            raise ValueError("sealed compiler/source/formal output changed")
        report = dict(**common, execution_status="complete", experiment_status="DEVELOPMENT_EVALUATED_NOT_FINAL",
            verification_status="PASS_FEATURE_ONLY_REPLAY" if (permutation["all_integer_boolean_forecasts_and_clusters_exact"]
                and permutation["all_floating_outputs_within_declared_tolerance"]) else "FAIL_BATCH_ORDER_INVARIANCE",
            observed_development_gates=gates, EffectDelta=effect,
            predictions_sha256=prediction_sha, raw40_query_array_sha256=query_freeze_sha,
            historical_2189_oracle_prediction_rows_differ=int(np.sum(baseline != result["final"])),
            exact_historical_2189_predictions_reproduced=bool(np.array_equal(baseline, result["final"])),
            historical_branch_comparison=historical_branches,
            numeric_canonical_DVC_ordering_repair_declared_before_query=True,
            ordering_repair_not_selected_using_current_replay_truth=True, current_replay_parameters_refit_or_selected=False,
            inference_hidden_file_IO_attempts=0, query_metadata_rejection=metadata_rejected,
            query_reconstruction=query["audit"], permutation_check=permutation, coverage=coverage,
            all_retained_parent_branch_forecasts_recomputed=True, recomputed_parent_branches=list(result["branches"]),
            branch_DVC={name: result["branches"][name]["DVC"] for name in BRANCHES},
            predictions_saved_before_truth_and_oracle_read=True, oracle_used_for_prediction=False,
            input_sha256=pins, formal_outputs_sha256_unchanged=formal, wall_seconds=time.perf_counter()-started)
        write_json(output / "report.json", report)
        write_json(output / "status.json", report)
        print(json.dumps({key: report[key] for key in ("verification_status", "observed_development_gates", "EffectDelta",
                                                      "historical_2189_oracle_prediction_rows_differ", "wall_seconds")}
            | {"first_differing_cumulative_branch": historical_branches["first_differing_cumulative_branch"]}), flush=True)
        return report
    except Exception as error:
        write_json(output / "status.json", dict(**common, execution_status="execution_failed", failed_phase=phase,
            error=repr(error), input_sha256=pins, formal_outputs_unchanged=formal_snapshot(ROOT) == formal,
            wall_seconds=time.perf_counter()-started))
        raise


def finalize_saved_replay(compiled_directory, saved_directory, output_directory, *, run_reverse=False,
                          oracle_directory=ORACLE):
    """Finalize sealed v2 numeric forecasts after a source-derived ID repair.

    The failed directory is immutable. No first prediction is rerun, filled or
    altered. Optional inference executes only the one reversed identical batch;
    without it, missing permutation evidence remains explicitly unverified.
    """
    compiled, saved, output, oracle = (Path(path).resolve() for path in
        (compiled_directory, saved_directory, output_directory, oracle_directory))
    if (any(ROOT not in path.parents for path in (compiled, saved, output, oracle))
            or output.exists() or not saved.is_dir()):
        raise ValueError("contained sealed compiler/failed run and new audit output required")
    started = time.perf_counter()
    formal, pins = formal_snapshot(ROOT), {}

    def pin(path, expected=None):
        path = Path(path)
        path = path if path.is_absolute() else ROOT / path
        digest = sha256_file(path)
        if expected is not None and digest != expected:
            raise ValueError("sealed recovery input changed: " + str(path))
        pins[str(path.resolve())] = digest
        return path

    output.mkdir(parents=True, exist_ok=False)
    common = dict(status="FAIL_TARGET99", published=False, final_test_executed=False,
        accepted_baseline_replaced=False, new_neural_epochs=0, new_qualified_independent_Table1_flows=0,
        independent_final_admitted=False, physical_event_independence_verified=False,
        scope="post-seal feature-only same-lineage development recovery NOT independent final")
    phase = "verify_original_failed_forecast_and_compiler_seals"
    try:
        failed = json.loads(pin(saved / "status.json").read_text(encoding="utf8"))
        if (failed.get("execution_status") != "execution_failed"
                or failed.get("failed_phase") != "historical_2189_oracle_comparison_after_prediction_seal"
                or failed.get("formal_outputs_unchanged") is not True):
            raise ValueError("the specific v2 post-seal identity failure is required")
        old_harness_hash = failed["input_sha256"][str(Path(__file__).resolve())]
        if old_harness_hash != FAILED_V2_HARNESS_SHA:
            raise ValueError("exact archived original v2 failed harness required")
        pin(FAILED_SOURCE_ARCHIVE, old_harness_hash)
        for path, digest in failed["input_sha256"].items():
            if Path(path).resolve() != Path(__file__).resolve():
                pin(path, digest)
        pin(Path(__file__))
        snapshot = json.loads(pin(saved / "compiler_manifest_frozen_before_query.json").read_text(encoding="utf8"))
        manifest = json.loads(pin(compiled / "manifest.json", snapshot["compiler_manifest_sha256"]).read_text(encoding="utf8"))
        if manifest != snapshot["compiled_manifest"] or manifest["formal_outputs_sha256_unchanged"] != formal:
            raise ValueError("original compiler/formal snapshot changed")
        pin(compiled / "pipeline.joblib", manifest["pipeline_sha256"])
        for path, digest in manifest["inference_source_sha256"].items():
            pin(path, digest)
        seal = json.loads(pin(saved / "prediction_seal_before_truth.json").read_text(encoding="utf8"))
        if (seal.get("all_query_prediction_rows_saved") is not True
                or seal.get("held_truth_or_old_oracle_loaded") is not False
                or seal.get("file_IO_during_predict_attempts") != 0
                or seal.get("predictions_sha256") != FAILED_V2_PREDICTION_SHA):
            raise ValueError("original prediction-before-truth/I/O seal required")
        pred_path = pin(saved / "predictions_frozen_before_counting.npz", seal["predictions_sha256"])
        query_audit = json.loads(pin(saved / "query_source_audit_before_prediction.json").read_text(encoding="utf8"))
        if query_audit.get("raw40_query_array_sha256") != FAILED_V2_RAW40_SHA:
            raise ValueError("exact original v2 frozen raw40 archive required")
        raw_path = pin(saved / "query_raw40_frozen_before_prediction.npz", query_audit["raw40_query_array_sha256"])
        with np.load(pred_path, allow_pickle=False) as archive:
            result = {name: archive[name].copy() for name in ROW_OUTPUTS}
            result["branches"] = {name: dict(final=archive["branch_"+name].copy(), DVC=None) for name in BRANCHES}
        result["protocol"] = seal["protocol"]
        if len(result["final"]) != 3598:
            raise ValueError("exact original v2 3598-row first forecast required")
        validate_prediction(result, len(result["final"]))
        phase = "source_bound_identity_reconstruction_without_prediction_lookup"
        query = reconstruct_query(ROOT, pin)
        if len(query["known_ids"]) != 654 or len(query["frame"]) != 3598:
            raise ValueError("exact original v2 654-known/2944-unknown frozen cohort required")
        legacy_ids = read_sealed_generated_strings(pred_path, "sample_id", seal["predictions_sha256"], (len(query["frame"]),))
        raw40 = read_sealed_generated_strings(raw_path, "raw40", query_audit["raw40_query_array_sha256"], query["frame"].shape)
        np.testing.assert_array_equal(raw40, unicode_query_array(query["frame"]))
        legacy_source_ids = np.concatenate([query["known_ids"], query["unknown_metadata"]["raw_row_sha256"].astype(str).to_numpy(dtype=str)])
        np.testing.assert_array_equal(legacy_ids, legacy_source_ids)
        producer = pin(ROOT / "paper_open_set/role_floor_log_unknown_diagnostic.py", HISTORICAL_ID_PRODUCER_SHA)
        producer_text = producer.read_text(encoding="utf8")
        if 'np.asarray(["dev:" + v for v in dev.sample_ids])' not in producer_text:
            raise ValueError("old producer's fixed dev-prefix identity serialization changed")
        identity_path = output / "source_verified_report_identity_map.npz"
        np.savez_compressed(identity_path, sealed_legacy_sample_id=legacy_ids.astype(str),
            historical_source_derived_sample_id=query["sample_id"].astype(str),
            known_zero_based_source_row=query["known_rows"],
            unknown_source_file=query["unknown_metadata"]["source_file"].astype(str).to_numpy(dtype=str),
            unknown_one_based_source_row=query["unknown_metadata"]["source_row_number"].to_numpy(dtype=np.int64),
            unknown_original_source_SHA=query["unknown_metadata"]["original_sha256"].astype(str).to_numpy(dtype=str),
            unknown_raw_row_SHA=query["unknown_metadata"]["raw_row_sha256"].astype(str).to_numpy(dtype=str),
            unknown_raw40_fingerprint=query["unknown_metadata"]["model_feature_sha256"].astype(str).to_numpy(dtype=str))
        identity = dict(repair="fixed dev: prefix restored to report identities from pinned original producer",
            serialized_legacy_IDs_exact_source_derived_bare_IDs=True,
            all_raw40_cells_exact_original_sealed_query=True,
            all_first_numeric_prediction_arrays_exact_original_sealed_NPZ=True,
            first_prediction_NPZ_bytes_unchanged=True, raw40_freeze_NPZ_bytes_unchanged=True,
            known_ids_changed=0, unknown_report_identity_prefix_restored=len(query["frame"])-len(query["known_ids"]),
            known_rows=len(query["known_ids"]), unknown_rows=len(query["frame"])-len(query["known_ids"]),
            total_rows=len(query["frame"]), rows_dropped_added_or_reordered=0,
            identity_map_sha256=sha256_file(identity_path), identity_derived_from_historical_prediction_lookup=False,
            object_string_recovery_only_exact_SHA_member_shape_and_NumPy_allowlist=True,
            original_first_prediction_sha256=seal["predictions_sha256"], original_raw40_query_sha256=query_audit["raw40_query_array_sha256"])
        write_json(output / "recovery_frozen_before_additional_prediction.json", dict(**common,
            identity=identity, compiled_manifest=manifest, input_sha256=pins.copy(),
            first_forecast_reexecuted=False, fresh_reverse_only_requested=bool(run_reverse),
            permutation_float_tolerance_predeclared=dict(rtol=PERMUTATION_RTOL, atol=PERMUTATION_ATOL),
            historical_development_inspection_precedes_design=True))
        phase = "one_fresh_reverse_batch_with_IO_disabled" if run_reverse else "explicit_missing_reverse_proof"
        permutation = None
        reverse_sha = None
        if run_reverse:
            pipeline = load_pipeline(compiled)
            with forbid_inference_io() as attempts:
                reverse = pipeline.predict_frame(query["frame"].iloc[::-1].reset_index(drop=True))
                validate_prediction(reverse, len(query["frame"]))
            if attempts:
                raise ValueError("fresh reverse attempted hidden file/archive access")
            reverse_path = output / "reverse_predictions_frozen_before_counting.npz"
            reverse_arrays = {name: reverse[name] for name in ROW_OUTPUTS}
            reverse_arrays.update({"branch_"+name: reverse["branches"][name]["final"] for name in BRANCHES})
            np.savez_compressed(reverse_path, sample_id=query["sample_id"][::-1].astype(str), **reverse_arrays)
            reverse_sha = sha256_file(reverse_path)
            permutation = permutation_check(result, reverse)
            write_json(output / "permutation_check_before_post_counting.json", permutation)
        phase = "held_truth_and_all_historical_branch_comparisons_after_original_prediction_seal"
        truth, coverage = load_truth_after_save(query, pred_path)
        gates = integer_gates(truth, result["final"])
        oracle_report = json.loads(pin(oracle / "report.json").read_text(encoding="utf8"))
        if oracle_report.get("published") is not False or oracle_report.get("final_test_executed") is not False:
            raise ValueError("nonfinal historical development oracle required")
        with np.load(pin(oracle / "predictions_frozen_before_counting.npz", oracle_report["predictions_sha256"]), allow_pickle=False) as archive:
            baseline = align_oracle(query["sample_id"], archive["sample_id"], archive["final"])
        if integer_gates(truth, baseline) != oracle_report["observed_development_gates"]:
            raise ValueError("source-derived identity alignment does not reproduce the exact prior counts")
        effect = paired_delta(truth, baseline, result["final"])
        historical = compare_historical_branches(query, result, truth, pred_path, pin)
        matrix = np.bincount(3*result["final"]+truth, minlength=9).reshape(3, 3)
        (output / "Matrix.txt").write_text("非独立最终测试；FAIL_TARGET99; published=false\n"+_open_matrix_text(matrix), encoding="utf8")
        if formal_snapshot(ROOT) != formal or any(sha256_file(Path(path)) != digest for path, digest in pins.items()):
            raise ValueError("original failed archives/compiler/source/formal outputs changed during recovery")
        verified = (permutation is not None and permutation["all_integer_boolean_forecasts_and_clusters_exact"]
                    and permutation["all_floating_outputs_within_declared_tolerance"])
        report = dict(**common, execution_status="complete", experiment_status="DEVELOPMENT_EVALUATED_NOT_FINAL",
            verification_status="PASS_RECOVERED_FEATURE_ONLY_REPLAY" if verified else
                "FAIL_BATCH_ORDER_INVARIANCE" if permutation is not None else "POST_COUNT_COMPLETE_REVERSE_PROOF_UNVERIFIED",
            observed_development_gates=gates, EffectDelta=effect, identity_recovery=identity,
            historical_branch_comparison=historical,
            historical_2189_oracle_prediction_rows_differ=int(np.sum(baseline != result["final"])),
            exact_historical_2189_predictions_reproduced=bool(np.array_equal(baseline, result["final"])),
            first_prediction_reexecuted=False, first_numeric_forecasts_modified=False,
            new_inference_calls=int(bool(run_reverse)), fresh_reverse_only_executed=bool(run_reverse),
            permutation_check=permutation, fresh_reverse_prediction_sha256=reverse_sha,
            original_prediction_archive=str(pred_path), predictions_sha256=seal["predictions_sha256"],
            raw40_query_array_sha256=query_audit["raw40_query_array_sha256"],
            original_failed_harness_sha256=old_harness_hash, archived_failed_harness=FAILED_SOURCE_ARCHIVE,
            original_failed_directory_immutable=True, inference_hidden_file_IO_attempts=0,
            query_metadata_rejection=seal["metadata_ID_truth_source_columns_rejected"],
            branch_DVC_manifests_not_preserved_in_original_failure=True,
            all_retained_parent_branch_forecasts_recovered_exactly=True, recomputed_parent_branches=list(BRANCHES),
            query_reconstruction=query["audit"], coverage=coverage,
            held_truth_and_oracle_used_only_after_original_prediction_seal=True, oracle_used_for_prediction=False,
            no_parameters_or_ordering_tuned_during_recovery=True, accepted_baseline_promotion_admitted=False,
            input_sha256=pins, formal_outputs_sha256_unchanged=formal, wall_seconds=time.perf_counter()-started)
        write_json(output / "report.json", report)
        write_json(output / "status.json", report)
        print(json.dumps({key: report[key] for key in ("verification_status", "observed_development_gates", "EffectDelta",
            "historical_2189_oracle_prediction_rows_differ", "wall_seconds")} |
            {"first_differing_cumulative_branch": historical["first_differing_cumulative_branch"]}), flush=True)
        return report
    except Exception as error:
        write_json(output / "status.json", dict(**common, execution_status="execution_failed", failed_phase=phase,
            error=repr(error), input_sha256=pins, formal_outputs_unchanged=formal_snapshot(ROOT) == formal,
            first_prediction_reexecuted=False, wall_seconds=time.perf_counter()-started))
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--compiled-directory", required=True)
    parser.add_argument("--output-directory", required=True)
    parser.add_argument("--oracle-directory", default=str(ROOT / ORACLE))
    parser.add_argument("--resume-saved-directory")
    parser.add_argument("--reverse-saved", action="store_true")
    args = parser.parse_args()
    if args.resume_saved_directory:
        finalize_saved_replay(args.compiled_directory, args.resume_saved_directory, args.output_directory,
                             run_reverse=args.reverse_saved, oracle_directory=args.oracle_directory)
    else:
        if args.reverse_saved:
            parser.error("--reverse-saved requires --resume-saved-directory")
        run(args.compiled_directory, args.output_directory, args.oracle_directory)
