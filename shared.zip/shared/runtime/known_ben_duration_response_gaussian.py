"""Single fixed BEN-only native-duration conditional Gaussian extension.

Response C is log1p(original nonnegative duration seconds), one dimension.
P contains every selected NSL numeric field except the two auth context fields.
The parent40 and old conditional side route remain frozen. Known anchors retain
their veto: only non-noise candidate clusters with no known anchors are admitted.
"""
from dataclasses import dataclass
import hashlib
import json
import math

import joblib
import numpy as np
import pandas as pd
import torch

from .config import NSL_FEATURE_COLUMNS
from .known_ben_conditional_gaussian_content import (
    AUTH_FIELDS, MIN_FIT, MAX_ANCHORS, RIDGE_RELATIVE, gaussian_parameters,
    quadratic_residual, hierarchical_keys, coordinates, check as check_old_profile)
from .known_anchor_candidate_dvc import route as anchored_route
from .model import infer
from .nsl_conditional_gaussian_content_development import extension as old_extension


SCHEMA = 'known-BEN-native41-duration-response-conditional-Gaussian-cal99-v1'
NATIVE41_COLUMNS = ('duration',)+NSL_FEATURE_COLUMNS
PREDICTOR_FIELDS = tuple(name for name in NSL_FEATURE_COLUMNS[3:] if name not in AUTH_FIELDS)


def checked_native41(frame):
    if not isinstance(frame, pd.DataFrame) or frame.columns.tolist() != list(NATIVE41_COLUMNS) or not 0 < len(frame) <= 6000:
        raise ValueError('exact native41 feature frame with no metadata and 1..6000 rows required')
    result = frame.reset_index(drop=True).copy()
    for field in ('duration',)+NSL_FEATURE_COLUMNS[3:]:
        result[field] = pd.to_numeric(result[field], errors='raise')
        if not np.isfinite(result[field].to_numpy(dtype=np.float64)).all():
            raise ValueError('finite native numeric fields required')
    if np.any(result['duration'].to_numpy(dtype=np.float64) < 0):
        raise ValueError('native duration must be nonnegative seconds')
    return result


def _inputs(features, duration, width):
    x, d = np.asarray(features, dtype=np.float64), np.asarray(duration, dtype=np.float64)
    if (x.ndim != 2 or x.shape[1] != width or not 0 < len(x) <= 6000 or not np.isfinite(x).all()
            or d.shape != (len(x),) or not np.isfinite(d).all() or np.any(d < 0)):
        raise ValueError('paired capped finite frozen selected features and directly observed duration seconds required')
    return x, d


def _truth(values, rows):
    y = np.asarray(values)
    if y.shape != (rows,) or y.dtype.kind not in 'iu' or set(y.tolist()) != {0, 1}:
        raise ValueError('real known BEN/KNA role truth required')
    return y


def predictor_columns(names):
    if len(set(names)) != len(names):
        raise ValueError('distinct frozen selected field names required')
    columns = tuple(names.index(name) for name in PREDICTOR_FIELDS if name in names)
    if not columns:
        raise ValueError('actual selected numeric non-auth conditional predictors required')
    return columns


def joint_coordinates(profile, features, duration):
    raw = np.column_stack([np.log1p(duration), features[:, profile.predictors]])
    return (raw-profile.mean)/profile.scale


def _manifest_digest(manifest):
    clean = {key: value for key, value in manifest.items() if key != 'frozen_manifest_sha256'}
    return hashlib.sha256(json.dumps(clean, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('ascii')).hexdigest()


def _digest(profile):
    return hashlib.sha256(joblib.hash((profile.feature_names, profile.predictors, profile.auth_splits,
        profile.mean, profile.scale, profile.nodes, profile.cutoff), hash_name='sha1').encode('ascii')).hexdigest()


@dataclass
class DurationResponseGaussian:
    feature_names: tuple
    predictors: tuple
    auth_splits: tuple
    mean: np.ndarray
    scale: np.ndarray
    nodes: dict
    cutoff: float
    manifest: dict


def check(profile):
    m, width = profile.manifest, len(profile.predictors)+1
    if (m.get('schema_version') != SCHEMA or m.get('frozen_manifest_sha256') != _manifest_digest(m)
            or m.get('frozen_state_sha256') != _digest(profile)
            or m.get('native_input_fields') != list(NATIVE41_COLUMNS)
            or m.get('selected_feature_names') != list(profile.feature_names)
            or m.get('auth_splits') != [list(value) for value in profile.auth_splits]
            or profile.predictors != predictor_columns(profile.feature_names)
            or m.get('response_dimension') != 1 or m.get('response_field') != 'log1p(native duration seconds)'
            or m.get('predictor_fields') != [profile.feature_names[i] for i in profile.predictors]
            or m.get('ridge_relative') != RIDGE_RELATIVE or m.get('minimum_BEN_fit_rows_per_node') != MIN_FIT
            or m.get('query_features_truth_IDs_used_for_fit') is not False
            or profile.mean.shape != (width,) or profile.scale.shape != (width,)
            or not np.isfinite(profile.mean).all() or not np.isfinite(profile.scale).all() or np.any(profile.scale <= 0)
            or ('global',) not in profile.nodes or not np.isfinite(profile.cutoff) or profile.cutoff <= 0):
        raise ValueError('unchanged explicitly named duration response policy required')
    expected_shapes = dict(mean=(width,), coefficient=(1, width-1), residual_covariance=(1, 1),
        residual_precision=(1, 1), joint_covariance=(width, width), predictor_precision=(width-1, width-1))
    for node in profile.nodes.values():
        if (node['real_BEN_fit_rows'] < MIN_FIT or node['ridge'] < RIDGE_RELATIVE
                or any(node[field].shape != shape or not np.isfinite(node[field]).all() for field, shape in expected_shapes.items())):
            raise ValueError('frozen named response/predictor block shapes required')


def assign_nodes(profile, features):
    return [next(key for key in keys if key in profile.nodes)
            for keys in hierarchical_keys(features, profile.feature_names, profile.auth_splits)]


def raw_scores(profile, features, duration):
    x, d = _inputs(features, duration, len(profile.feature_names))
    z, assigned = joint_coordinates(profile, x, d), assign_nodes(profile, x)
    raw = np.zeros(len(x))
    for key in sorted(set(assigned)):
        rows = np.asarray([i for i, value in enumerate(assigned) if value == key], dtype=np.int64)
        raw[rows] = quadratic_residual(profile.nodes[key], z[rows], 1)
    return raw, assigned


def fit(feature_names, auth_splits, fit_features, fit_duration, fit_truth,
        calibration_features, calibration_duration, calibration_truth):
    names = tuple(str(value) for value in feature_names)
    predictors = predictor_columns(names)
    x, d = _inputs(fit_features, fit_duration, len(names))
    cal, cd = _inputs(calibration_features, calibration_duration, len(names))
    y, cy = _truth(fit_truth, len(x)), _truth(calibration_truth, len(cal))
    splits = tuple((int(column), float(cutoff)) for column, cutoff in auth_splits)
    if (not splits or len({column for column, _ in splits}) != len(splits)
            or any(not 0 <= column < len(names) or names[column] not in AUTH_FIELDS or not np.isfinite(cutoff) for column, cutoff in splits)):
        raise ValueError('frozen measured auth context fields required')
    ben, duration = x[y == 0], d[y == 0]
    if len(ben) < MIN_FIT:
        raise ValueError('twenty actual BEN fit rows required')
    sort_features = np.column_stack([ben, duration])
    order = np.lexsort(tuple(sort_features[:, j] for j in range(sort_features.shape[1]-1, -1, -1)))
    ben, duration = ben[order], duration[order]
    raw = np.column_stack([np.log1p(duration), ben[:, predictors]])
    mean, scale = raw.mean(axis=0), raw.std(axis=0)
    scale[scale <= np.finfo(float).eps] = 1.
    z = (raw-mean)/scale
    keys = hierarchical_keys(ben, names, splits)
    nodes, audit = {}, []
    for key in sorted({key for alternatives in keys for key in alternatives}):
        rows = np.asarray([i for i, alternatives in enumerate(keys) if key in alternatives], dtype=np.int64)
        item = dict(node=list(key), real_BEN_fit_rows=len(rows), admitted=len(rows) >= MIN_FIT)
        if item['admitted']:
            nodes[key] = gaussian_parameters(z[rows], 1)
            item.update(ridge=nodes[key]['ridge'], OAS_shrinkage=nodes[key]['OAS_shrinkage'])
        audit.append(item)
    profile = DurationResponseGaussian(names, predictors, splits, mean, scale, nodes, 1., {})
    calibration, _ = raw_scores(profile, cal[cy == 0], cd[cy == 0])
    m, rank = len(calibration), math.ceil(.99*(len(calibration)+1))
    if rank > m:
        raise ValueError('finite99 known BEN duration calibration rank requires >=99 rows')
    cutoff = float(np.sort(calibration)[rank-1])
    if not np.isfinite(cutoff) or cutoff <= 0:
        raise ValueError('finite positive known BEN duration cutoff required')
    profile.cutoff = cutoff
    profile.manifest = dict(schema_version=SCHEMA, native_input_fields=list(NATIVE41_COLUMNS),
        selected_feature_names=list(names), response_field='log1p(native duration seconds)', response_dimension=1,
        predictor_fields=[names[i] for i in predictors], predictor_semantics='all frozen selected NSL numeric fields except logged_in/is_guest_login; includes selected original content fields',
        context_order=['protocol/service/flag/auth', 'protocol/auth', 'global'], auth_splits=[list(value) for value in splits],
        minimum_BEN_fit_rows_per_node=MIN_FIT, nodes=audit, ridge_relative=RIDGE_RELATIVE,
        covariance='BEN-fit-only OAS joint native-duration/P, one fixed response',
        ridge_rule='1e-8 * max(trace(OAS covariance)/joint dimension, 1)',
        score='one-dimensional Schur conditional residual quadratic', calibration_BEN_rows=m,
        calibration_rank_one_based=rank, calibration_cutoff=cutoff, calibration_raw_candidates=int(np.sum(calibration > cutoff)),
        threshold='single global ceil(.99*(m+1)) known BEN order statistic; strict > cutoff',
        known_BEN_calibration_all_rows_used=True, full_fit_LOO_or_max_neighbor_guard_used=False,
        direct_duration_all_roles=True, duration_lookup_or_availability_used=False,
        query_features_truth_IDs_used_for_fit=False, fixed_single_rule_NOT_arm_or_weight_search=True,
        calibration_rank_NOT_IID_or_physical_independence_certificate=True,
        historical_development_inspection_precedes_design=True, physical_event_independence_verified=False, published=False)
    profile.manifest['frozen_state_sha256'] = _digest(profile)
    profile.manifest['frozen_manifest_sha256'] = _manifest_digest(profile.manifest)
    check(profile)
    return profile


def evaluate(profile, features, duration, stage1):
    check(profile)
    x, d = _inputs(features, duration, len(profile.feature_names))
    stage = np.asarray(stage1)
    if stage.shape != (len(x),) or stage.dtype.kind not in 'iu' or not np.isin(stage, (0, 1)).all():
        raise ValueError('paired frozen stage1 predictions required')
    raw, nodes = raw_scores(profile, x, d)
    score = raw/profile.cutoff
    check(profile)
    return dict(score=score, raw_score=raw, raw_candidate=(stage == 0)&(score > 1), nodes=nodes)


def fit_anchors(profile, fit_features, fit_duration, fit_truth, fit_embedding,
                calibration_features, calibration_duration, calibration_truth, calibration_embedding, scaler):
    check(profile)
    x, d = _inputs(fit_features, fit_duration, len(profile.feature_names))
    cal, cd = _inputs(calibration_features, calibration_duration, len(profile.feature_names))
    y, cy = _truth(fit_truth, len(x)), _truth(calibration_truth, len(cal))
    features, duration = np.vstack([x[y == 0], cal[cy == 0]]), np.r_[d[y == 0], cd[cy == 0]]
    embedding = np.vstack([np.asarray(fit_embedding)[y == 0], np.asarray(calibration_embedding)[cy == 0]])
    z = joint_coordinates(profile, features, duration)
    all_keys = hierarchical_keys(features, profile.feature_names, profile.auth_splits)
    nodes, audit = {}, []
    for key in sorted(profile.nodes):
        rows = np.asarray([i for i, alternatives in enumerate(all_keys) if key in alternatives], dtype=np.int64)
        score = quadratic_residual(profile.nodes[key], z[rows], 1)/profile.cutoff
        q = coordinates(embedding[rows], scaler, score)
        known = np.column_stack([features[rows], duration[rows]])
        order = np.lexsort(tuple(q[:, j] for j in range(q.shape[1]-1, -1, -1)))
        known, q = known[order], q[order]
        _, unique = np.unique(known, axis=0, return_index=True)
        q = np.unique(q[unique], axis=0)
        if len(q) >= MIN_FIT:
            indices = np.linspace(0, len(q)-1, MAX_ANCHORS, dtype=np.int64) if len(q) > MAX_ANCHORS else np.arange(len(q))
            nodes[key] = q[indices].copy()
        audit.append(dict(node=list(key), real_BEN_rows=len(rows), distinct_known_selected_plus_duration_rows=len(unique),
            unique_coordinates=len(q), admitted=key in nodes, anchors=len(nodes.get(key, []))))
    manifest = dict(schema_version=SCHEMA+'-anchors', nodes=audit, coordinate_width=embedding.shape[1]+1,
        frozen_anchor_state_sha256=hashlib.sha256(joblib.hash(nodes, hash_name='sha1').encode('ascii')).hexdigest(),
        sources='actual BEN fit plus all BEN calibration; exact selected+direct-duration dedup, unique coordinate sort then512 rank cap',
        known_calibration_self_anchors_NOT_held_out_validation=True, query_truth_features_IDs_used=False,
        anchor_coordinates_NOT_physical_independence=True, published=False)
    manifest['frozen_manifest_sha256'] = _manifest_digest(manifest)
    return dict(nodes=nodes, manifest=manifest)


def route(profile, anchor_policy, features, query_coordinates, raw_candidate):
    check(profile)
    anchors, m = anchor_policy['nodes'], anchor_policy['manifest']
    if (m.get('schema_version') != SCHEMA+'-anchors' or m.get('frozen_manifest_sha256') != _manifest_digest(m)
            or m.get('query_truth_features_IDs_used') is not False
            or hashlib.sha256(joblib.hash(anchors, hash_name='sha1').encode('ascii')).hexdigest() != m.get('frozen_anchor_state_sha256')
            or any(key not in profile.nodes or value.ndim != 2 or value.shape[1] != m['coordinate_width'] or
                   not MIN_FIT <= len(value) <= MAX_ANCHORS or not np.isfinite(value).all() for key, value in anchors.items())):
        raise ValueError('frozen known duration anchors changed')
    x, q, raw = np.asarray(features, dtype=float), np.asarray(query_coordinates, dtype=float), np.asarray(raw_candidate)
    if (x.ndim != 2 or x.shape[1] != len(profile.feature_names) or not 0 < len(x) <= 6000 or not np.isfinite(x).all()
            or q.shape != (len(x), m['coordinate_width']) or not np.isfinite(q).all() or raw.shape != (len(x),) or raw.dtype != bool):
        raise ValueError('paired capped selected fields, coordinates and raw candidates required')
    assigned = assign_nodes(profile, x)
    retained, supported = np.zeros(len(x), dtype=bool), np.zeros(len(x), dtype=bool)
    first, second = np.full(len(x), -2, dtype=np.int64), np.full(len(x), -2, dtype=np.int64)
    primary_free, secondary_free, suspected = (np.zeros(len(x), dtype=bool) for _ in range(3))
    nodes, first_offset, second_offset = [], 0, 0
    for key in sorted(set(assigned)):
        rows = np.asarray([i for i, value in enumerate(assigned) if value == key], dtype=np.int64)
        if key not in anchors:
            first[rows[raw[rows]]] = -3
            nodes.append(dict(node=list(key), query_rows=len(rows), status='UNSUPPORTED_UNIQUE_KNOWN_ANCHORS_KEEP_ALL_ROWS'))
            continue
        supported[rows] = True
        out = anchored_route(q[rows], raw[rows], anchors[key])
        retained[rows] = out.retained
        a, b = out.first.copy(), out.second.copy()
        a[a >= 0] += first_offset; b[b >= 0] += second_offset
        first[rows], second[rows] = a, b
        if np.any(out.first >= 0): first_offset += int(out.first[out.first >= 0].max())+1
        if np.any(out.second >= 0): second_offset += int(out.second[out.second >= 0].max())+1
        primary_free[rows], secondary_free[rows], suspected[rows] = out.primary_anchor_free, out.secondary_anchor_free, out.suspected
        nodes.append(dict(node=list(key), query_rows=len(rows), DVC=out.manifest))
    if np.any(retained & (~raw | ~supported)):
        raise AssertionError('UNA requires an actual supported raw candidate and pure non-noise DVC')
    return dict(retained=retained, supported=supported, first=first, second=second, primary_anchor_free=primary_free,
        secondary_anchor_free=secondary_free, suspected=suspected,
        manifest=dict(schema_version=SCHEMA+'-DVC', query_rows=len(x), raw_candidates=int(raw.sum()), retained=int(retained.sum()),
            nodes=nodes, existing_eps_minPts_noise_and_anchor_veto_unchanged=True, unsupported_keep_all_rows=True,
            query_truth_family_ID_used=False, physical_event_independence_verified=False, published=False))


def extension(profile, anchors, scaler, features, duration, embedding, stage, parent):
    values = evaluate(profile, features, duration, stage)
    q = coordinates(embedding, scaler, values['score'])
    dvc = route(profile, anchors, features, q, values['raw_candidate'])
    added = (stage == 0)&(parent == 0)&values['raw_candidate']&dvc['retained']
    final = parent.copy(); final[added] = 2
    return dict(final=final, added_UNA=added, score=values['score'], raw_score=values['raw_score'],
        raw_candidate=values['raw_candidate'], duration_node=np.asarray([json.dumps(node) for node in values['nodes']], dtype=str),
        query_coordinates=q, **dvc)


class FrozenNative41DurationPredictor:
    """Features-only parent40 + frozen2192 route + new duration overlay."""
    def __init__(self, parent40, parent_gaussian_state, profile, anchors):
        self.parent40, self.parent_gaussian_state = parent40, parent_gaussian_state
        self.profile, self.anchors = profile, anchors
        self.frozen_extension_digest = self._digest()
        self._check()

    def _digest(self):
        return joblib.hash((self.parent_gaussian_state, self.profile, self.anchors), hash_name='sha1')

    def _check(self):
        self.parent40._check_state()
        check(self.profile)
        old = self.parent_gaussian_state['arms']['conditional']
        check_old_profile(old['profile'])
        if (self._digest() != self.frozen_extension_digest or old['profile'].mode != 'conditional'
                or old['profile'].feature_names != self.profile.feature_names
                or old['profile'].auth_splits != self.profile.auth_splits):
            raise ValueError('unchanged pure feature duration extension and conditional2192 parent required')

    def predict_native41(self, frame):
        self._check()
        native = checked_native41(frame)
        base = self.parent40.predict_frame(native.loc[:, list(NSL_FEATURE_COLUMNS)])
        # The full16 parent is computed once; this extra frozen log inference
        # supplies its embedding without changing or training either network.
        numeric = infer(self.parent40.state['models']['log'], base['log_model_features'], device=torch.device('cpu'))
        old_state, scaler = self.parent_gaussian_state['arms']['conditional'], self.parent_gaussian_state['embedding_scaler']
        old = old_extension(old_state['profile'], old_state['anchors'], scaler,
            base['log_model_features'], numeric.embedding, base['stage1'], base['final'])
        new = extension(self.profile, self.anchors, scaler, base['log_model_features'],
            native['duration'].to_numpy(dtype=float), numeric.embedding, base['stage1'], old['final'])
        self._check()
        return dict(candidate=new, parent2192=old, parent40=base, log_embedding=numeric.embedding,
            native_duration_seconds=native['duration'].to_numpy(dtype=float))
