"""Four fixed NSL shrinkage-whitened BEN views; known-only development variant.

The blocks follow field positions, not a family lookup or query-selected view.
Each uses the frozen same-context seventh-neighbour calibration/full-fit-LOO
envelope. The maximum of four normalized distances retains ALL supported known
fit and protected calibration rows. It does not guarantee retention on queries.
The MHFD inputs and full DVC geometry are unchanged; non-noise DVC is required.
"""
from dataclasses import dataclass
import hashlib
import json
import numpy as np
from .config import NSL_FEATURE_COLUMNS
from . import known_ben_context_whitened_fit_loo as base
from .dvc import NoveltyOutput
from .local_ben_affinity_envelope_guarded import _matrix, _roles

SCHEMA = "known-BEN-fixed-four-shrinkage-whitened-semantic-context-fit-LOO-views-v1"
# These canonical positional blocks cover all 37 numeric fields exactly once.
BLOCKS = (
    ("basic_bytes_fragments", NSL_FEATURE_COLUMNS[3:8]),
    ("content_login_activity", NSL_FEATURE_COLUMNS[8:21]),
    ("recent_connection_statistics", NSL_FEATURE_COLUMNS[21:30]),
    ("host_connection_statistics", NSL_FEATURE_COLUMNS[30:40]),
)
FIELDS = ("score", "threshold", "high_threshold", "prototype_percentile",
    "embedding_knn_percentile", "feature_knn_percentile",
    "reconstruction_percentile", "uncertainty_percentile", "candidate")


def _sha(values):
    return hashlib.sha256(np.ascontiguousarray(values).tobytes()).hexdigest()


def _manifest_sha(manifest):
    return hashlib.sha256(json.dumps({k:v for k,v in manifest.items() if k!="frozen_manifest_sha256"},
        sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")).hexdigest()


def view_columns(feature_names):
    names = tuple(str(v) for v in feature_names)
    if len(set(names)) != len(names):
        raise ValueError("distinct selected feature names required")
    categorical = tuple(i for i,n in enumerate(names)
        if any(n.startswith(field+"_") for field in base.CONTEXT_FIELDS))
    supported = set(NSL_FEATURE_COLUMNS[3:])
    if set(names) - {names[i] for i in categorical} - supported:
        raise ValueError("undeclared NSL model feature in semantic projection")
    views = {}
    for key, declared in BLOCKS:
        numeric = tuple(names.index(n) for n in declared if n in names)
        if not numeric:
            raise ValueError("every canonical block needs an actual selected numeric field")
        views[key] = categorical + numeric
    return views


@dataclass
class SemanticViews:
    feature_names: tuple
    columns: dict
    profiles: dict
    calibration_ratios: np.ndarray
    manifest: dict


def _check(profile):
    if (profile.manifest.get("schema_version") != SCHEMA
            or profile.manifest.get("frozen_manifest_sha256") != _manifest_sha(profile.manifest)
            or profile.columns != view_columns(profile.feature_names)
            or tuple(profile.profiles) != tuple(k for k,_ in BLOCKS)
            or _sha(profile.calibration_ratios) != profile.manifest["calibration_ratio_sha256"]):
        raise ValueError("frozen fixed semantic-view policy required")
    for key, columns in profile.columns.items():
        child = profile.profiles[key]
        if (child.feature_names != tuple(profile.feature_names[i] for i in columns)
                or child.manifest != profile.manifest["views"][key]["context_manifest"]):
            raise ValueError("semantic projection or known-context manifest changed")


def components(profile, features):
    _check(profile)
    x = _matrix(features, "semantic-view query")
    if x.shape[1] != len(profile.feature_names):
        raise ValueError("full saved model feature width required")
    values, supported = [], []
    for key, columns in profile.columns.items():
        ratio, _, eligible = base.components(profile.profiles[key], x[:, columns])
        values.append(ratio); supported.append(eligible)
    if not all(np.array_equal(supported[0], mask) for mask in supported[1:]):
        raise ValueError("all views must share identical categorical context support")
    maximum = np.max(np.stack(values), axis=0)
    # A mixed-coordinate raw distance has no meaningful unit; report the
    # maximum normalized-distance ratio explicitly, not an invented distance.
    return maximum, maximum.copy(), supported[0]


def fit_profile(fit_features, fit_truth, calibration_features, calibration_truth,
                primary, baseline, feature_names):
    x, cal = _matrix(fit_features, "known fit"), _matrix(calibration_features, "known calibration")
    names = tuple(str(v) for v in feature_names)
    if x.shape[1] != len(names) or cal.shape[1] != len(names):
        raise ValueError("paired full known feature widths required")
    columns = view_columns(names)
    profiles, views = {}, {}
    for key, indices in columns.items():
        projected_names = tuple(names[i] for i in indices)
        child = base.fit_profile(x[:, indices], fit_truth, cal[:, indices],
            calibration_truth, primary, baseline, projected_names)
        profiles[key] = child
        declared = dict(BLOCKS)[key]
        views[key] = {"selected_columns": list(indices), "selected_feature_names": list(projected_names),
            "canonical_numeric_fields": list(declared),
            "selected_numeric_fields": [n for n in declared if n in names],
            "absent_fields_NOT_imputed_or_reintroduced": [n for n in declared if n not in names],
            "context_manifest": child.manifest}
    # Compute the aggregate reference only from known protected calibration.
    ratios, masks = [], []
    for key, indices in columns.items():
        ratio, _, mask = base.components(profiles[key], cal[:, indices])
        ratios.append(ratio); masks.append(mask)
    if not all(np.array_equal(masks[0], mask) for mask in masks[1:]):
        raise ValueError("projected known context support differs")
    cy = _roles(calibration_truth, len(cal), "known calibration truth")
    p = _roles(primary, len(cal), "known primary")
    protected = (cy==0)&(p==0)&(np.asarray(baseline)==0)&masks[0]
    maximum = np.max(np.stack(ratios), axis=0)
    reference = np.sort(maximum[protected])
    if not len(reference) or np.any(reference>1.):
        raise AssertionError("all-view known envelope retention failed")
    manifest = {"schema_version":SCHEMA, "view_order":[k for k,_ in BLOCKS], "views":views,
        "aggregation":"maximum of four per-context normalized seventh-neighbour distances",
        "reported_context_distance_is_normalized_max_ratio_NOT_raw_distance":True,
        "calibration_ratio_sha256":_sha(reference), "eligible_correct_BEN_calibration_rows":len(reference),
        "known_only_calibration":True, "full_BEN_fit_LOO_maximum_in_each_view":True,
        "query_truth_or_ID_or_family_used":False, "query_selected_view_or_weight":False,
        "all_full_query_rows_retained":True, "strict_greater_than":True,
        "non_noise_DVC_required":True, "MHFD_inputs_and_DVC_full_geometry_unchanged":True,
        "unsupported_context_action":"preserve parent, still count full denominator",
        "historical_development_inspection_precedes_rule_design":True,
        "new_query_99_NOT_guaranteed":True, "status":"FAIL_TARGET99",
        "published":False, "final_test_executed":False}
    manifest["frozen_manifest_sha256"] = _manifest_sha(manifest)
    profile = SemanticViews(names, columns, profiles, reference, manifest)
    _check(profile)
    return profile


def score(profile, features, primary, original):
    ratio, distance, eligible = components(profile, features)
    p = _roles(primary, len(ratio), "query primary")
    if (not isinstance(original, NoveltyOutput)
            or any(np.asarray(getattr(original,k)).shape != p.shape for k in FIELDS)
            or any(not np.isfinite(getattr(original,k)).all() for k in FIELDS)
            or np.asarray(original.candidate).dtype != bool):
        raise ValueError("paired finite original novelty required")
    values = {k:np.asarray(getattr(original,k)).copy() for k in FIELDS}
    ben = p==0
    values["score"][ben] = ratio[ben]
    values["threshold"][ben] = values["high_threshold"][ben] = 1.
    values["candidate"][ben] = eligible[ben]&(ratio[ben]>1.)
    observed = ben&eligible
    ref = profile.calibration_ratios
    values["feature_knn_percentile"][observed] = np.searchsorted(ref,ratio[observed],side="right")/(len(ref)+1.)
    return NoveltyOutput(**values, score_strategy="known_BEN_four_fixed_whitened_semantic_views_KNA_unchanged_"+original.score_strategy),distance,eligible


