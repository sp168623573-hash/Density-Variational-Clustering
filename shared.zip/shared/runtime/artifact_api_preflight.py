"""Metadata-only source/API contracts before an expensive experiment.

Read registered descriptors and JSON structure, never decode traffic arrays.
Make missing keys, wrong module ownership, and mutable sources explicit before
training. Existing frozen experiment modules are deliberately not rewritten.
"""
from __future__ import annotations
import hashlib
import importlib
import inspect
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class PreflightStop(ValueError):
    pass

def require(condition,reason):
    if not condition:raise PreflightStop(reason)

def checked_asset(item):
    require(isinstance(item,dict) and isinstance(item.get('path'),str) and isinstance(item.get('sha256'),str),'descriptor requires explicit path and sha256')
    p=Path(item['path']).resolve()
    require(p.is_relative_to(ROOT) and p!=ROOT,'registered workspace asset only')
    require(p.is_file(),'registered asset missing: '+str(p))
    digest=hashlib.sha256(p.read_bytes()).hexdigest()
    require(digest==item['sha256'],'registered asset bytes changed: '+str(p))
    return p

def json_fields(item,paths):
    p=checked_asset(item)
    require(p.suffix.lower()=='.json','JSON fields require a registered JSON descriptor')
    value=json.loads(p.read_text('utf8'));result={}
    for path in paths:
        require(isinstance(path,(list,tuple)) and len(path)>0,'field contract is an explicit nonempty key sequence')
        node=value
        for key in path:
            require(isinstance(node,dict),'not a JSON mapping at '+'.'.join(map(str,path)))
            require(key in node,'missing JSON field '+str(key)+'; available keys='+','.join(sorted(map(str,node.keys()))))
            node=node[key]
        result['.'.join(map(str,path))]=node
    return result

def callable_contract(module_name,function_name,required_parameters,source_sha256):
    require(module_name.startswith('paper_open_set.'),'only local experiment APIs may be bound')
    module=importlib.import_module(module_name)
    p=Path(module.__file__).resolve()
    require(p.is_relative_to(ROOT) and hashlib.sha256(p.read_bytes()).hexdigest()==source_sha256,'callable module source pin changed')
    require(hasattr(module,function_name),'missing API '+module_name+'.'+function_name+'; callable names='+','.join(sorted(k for k,v in vars(module).items() if callable(v) and not k.startswith('_'))))
    f=getattr(module,function_name);require(callable(f),'registered API is not callable')
    signature=inspect.signature(f)
    require(set(required_parameters).issubset(signature.parameters),'API parameters mismatch: '+str(signature))
    return dict(module=module_name,function=function_name,signature=str(signature),source=dict(path=str(p),sha256=source_sha256))

def preflight(*,assets=(),json_contracts=(),api_contracts=()):
    checked=[dict(path=str(checked_asset(a)),sha256=a['sha256']) for a in assets]
    fields=[dict(asset=c['asset'],fields=json_fields(c['asset'],c['paths'])) for c in json_contracts]
    apis=[callable_contract(**c) for c in api_contracts]
    return dict(schema_version='artifact-API-prefit-contract-v52',registered_assets=checked,JSON_contracts=fields,API_contracts=apis,
        traffic_array_decodes=0,model_fit=0,model_forward=0,CAL_or_DVC_replay=0,
        contract_passed=True,TARGET99_approved=False,published=False,final_test_executed=False)
