"""FIT-only native35 conditional blocks; candidates still require anchored DVC.

This module does not admit data sources or prove independent development/final
testing. Duration remains in the caller's native41 frame but is excluded from
this new score. All four conditional residual coordinates survive screening.
"""
from dataclasses import dataclass
import hashlib
import json
import math

import joblib
import numpy as np
from sklearn.covariance import OAS

from .config import NSL_FEATURE_COLUMNS
from .known_anchor_candidate_dvc import route as anchored_route
from .known_ben_conditional_gaussian_content import AUTH_FIELDS, hierarchical_keys
from .known_ben_duration_response_gaussian import checked_native41

SCHEMA = "known-BEN-native35-four-conditional-blocks-cal99-vector-DVC-v1"
BLOCKS = (
    ("basic", NSL_FEATURE_COLUMNS[3:8]),
    ("content_non_auth", tuple(n for n in NSL_FEATURE_COLUMNS[8:21] if n not in AUTH_FIELDS)),
    ("recent_connection_statistics", NSL_FEATURE_COLUMNS[21:30]),
    ("host_connection_statistics", NSL_FEATURE_COLUMNS[30:40]),
)
NUMERIC_FIELDS = tuple(n for _, fields in BLOCKS for n in fields)
RIDGE, MIN_FIT, MAX_ANCHORS = 1e-8, 20, 512
EMBEDDING_WIDTH, COORDINATE_WIDTH = 32, 36
assert len(NUMERIC_FIELDS) == len(set(NUMERIC_FIELDS)) == 35


def _matrix(value, width, name):
    a = np.asarray(value)
    if (a.dtype.kind != "f" or a.dtype.itemsize not in (4, 8) or a.ndim != 2
            or a.shape[1] != width or not 0 < len(a) <= 6000 or not np.isfinite(a).all()):
        raise ValueError(f"finite float32/64 capped {name} matrix required")
    return np.array(a, dtype=np.float64, order="C", copy=True)


def _labels(value, rows, *, known=True):
    y = np.asarray(value)
    allowed = (0, 1) if known else (0, 1, 2)
    if y.shape != (rows,) or y.dtype.kind not in "iu" or not np.isin(y, allowed).all():
        raise ValueError("integer BEN/KNA labels (no bool/unknown) required" if known else "integer parent labels required")
    return y.astype(np.int64, copy=True)


def _ids(value, rows):
    a = np.asarray(value)
    if a.ndim != 1 or a.shape != (rows,) or a.dtype.kind not in "US":
        raise ValueError("ordered string known-role IDs required")
    ids = tuple(a.astype(str).tolist())
    if len(set(ids)) != rows or any(not s or s.strip() != s for s in ids):
        raise ValueError("unique nonempty exact known-role IDs required")
    return ids


def _known_labels(value, rows):
    y = _labels(value, rows)
    if min(int((y == c).sum()) for c in (0, 1)) < MIN_FIT:
        raise ValueError("each known coarse class needs at least20 real role rows")
    return y


def numeric_values(native):
    frame = checked_native41(native)
    raw = frame.loc[:, list(NUMERIC_FIELDS)].to_numpy(dtype=np.float64)
    if np.any(raw < 0) or not np.isfinite(raw).all():
        raise ValueError("nonnegative finite direct native35 fields required")
    return np.log1p(raw)


def _hash(value):
    return hashlib.sha256(joblib.hash(value, hash_name="sha1").encode("ascii")).hexdigest()


def _manifest_hash(manifest):
    payload = {k: v for k, v in manifest.items() if k != "frozen_manifest_sha256"}
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def _role_hash(selected, native35, truth):
    return _hash((selected, native35, truth))


def _canonical(values):
    return np.lexsort(tuple(values[:, j] for j in range(values.shape[1] - 1, -1, -1)))


def _auth_splits(names, values):
    splits = []
    for column, cutoff in values:
        if isinstance(column, (bool, np.bool_)) or not isinstance(column, (int, np.integer)):
            raise ValueError("original integer auth column indices required")
        if isinstance(cutoff, (bool, np.bool_)) or not np.isfinite(cutoff):
            raise ValueError("finite original auth threshold required")
        splits.append((int(column), float(cutoff)))
    splits = tuple(splits)
    if (len(splits) != 2 or len({c for c, _ in splits}) != 2
            or any(not 0 <= c < len(names) for c, _ in splits)
            or {names[c] for c, _ in splits} != set(AUTH_FIELDS)):
        raise ValueError("both frozen original auth splits required")
    return splits


def schur_parameters(covariance, block):
    """Schur algebra for a declared block of one positive-definite joint matrix."""
    covariance = np.asarray(covariance, dtype=np.float64)
    indices = np.asarray(block, dtype=np.int64)
    if (covariance.shape != (35, 35) or not np.isfinite(covariance).all()
            or indices.ndim != 1 or not 0 < len(indices) < 35
            or len(set(indices.tolist())) != len(indices) or np.any((indices < 0) | (indices >= 35))
            or not np.allclose(covariance, covariance.T, rtol=0, atol=1e-12)):
        raise ValueError("declared unique block and finite symmetric joint covariance required")
    np.linalg.cholesky(covariance)
    other = np.asarray([j for j in range(35) if j not in set(indices.tolist())], dtype=np.int64)
    cross = covariance[np.ix_(indices, other)]
    coefficient = np.linalg.solve(covariance[np.ix_(other, other)], cross.T).T
    residual_covariance = covariance[np.ix_(indices, indices)] - coefficient @ cross.T
    residual_covariance = (residual_covariance + residual_covariance.T) / 2
    np.linalg.cholesky(residual_covariance)
    precision = np.linalg.solve(residual_covariance, np.eye(len(indices)))
    return dict(indices=tuple(indices.tolist()), other=tuple(other.tolist()),
                coefficient=coefficient, residual_covariance=residual_covariance,
                residual_precision=precision)


def _node_quadratics(node, z):
    centered = z - node["mean"]
    values = []
    for key, fields in BLOCKS:
        state = node["blocks"][key]
        b, other = state["indices"], state["other"]
        residual = centered[:, b] - centered[:, other] @ state["coefficient"].T
        q = np.einsum("ni,ij,nj->n", residual, state["residual_precision"], residual) / len(fields)
        if not np.isfinite(q).all() or np.any(q < -1e-10):
            raise ValueError("finite nonnegative conditional quadratic required")
        values.append(np.maximum(q, 0.))
    return np.column_stack(values)


def _fit_node(z):
    fitted = OAS(assume_centered=False).fit(z)
    covariance = np.asarray(fitted.covariance_, dtype=np.float64) + RIDGE * np.eye(35)
    np.linalg.cholesky(covariance)
    node = dict(mean=fitted.location_.copy(), covariance=covariance,
                real_BEN_fit_rows=len(z), OAS_shrinkage=float(fitted.shrinkage_),
                blocks={key: schur_parameters(covariance, [NUMERIC_FIELDS.index(f) for f in fields])
                        for key, fields in BLOCKS})
    q = _node_quadratics(node, z)
    center = np.median(q, axis=0)
    node["block_center"] = center
    node["block_scale"] = np.maximum(np.median(np.abs(q - center), axis=0), 1.)
    return node


@dataclass
class ConditionalBlocksProfile:
    feature_names: tuple
    auth_splits: tuple
    mean: np.ndarray
    scale: np.ndarray
    nodes: dict
    cutoff: float
    manifest: dict


def _digest(profile):
    return _hash((profile.feature_names, profile.auth_splits, profile.mean, profile.scale,
                  profile.nodes, profile.cutoff))


def check(profile):
    m = profile.manifest
    if (m.get("schema_version") != SCHEMA or m.get("frozen_manifest_sha256") != _manifest_hash(m)
            or m.get("frozen_state_sha256") != _digest(profile)
            or m.get("numeric_fields") != list(NUMERIC_FIELDS) or m.get("ridge") != RIDGE
            or m.get("duration_used_by_new_score") is not False or m.get("query_truth_features_IDs_used_for_fit") is not False
            or ("global",) not in profile.nodes or not np.isfinite(profile.cutoff)
            or profile.mean.shape != (35,) or profile.scale.shape != (35,)
            or not np.isfinite(profile.mean).all() or not np.isfinite(profile.scale).all() or np.any(profile.scale <= 0)):
        raise ValueError("unchanged frozen known-only native35 block profile required")
    for node in profile.nodes.values():
        if (node["real_BEN_fit_rows"] < MIN_FIT or node["mean"].shape != (35,)
                or node["covariance"].shape != (35, 35) or node["block_center"].shape != (4,)
                or node["block_scale"].shape != (4,) or np.any(node["block_scale"] < 1.)
                or tuple(node["blocks"]) != tuple(k for k, _ in BLOCKS)):
            raise ValueError("frozen complete four-block node required")


def assign_nodes(profile, features):
    return [next(k for k in alternatives if k in profile.nodes)
            for alternatives in hierarchical_keys(features, profile.feature_names, profile.auth_splits)]


def _score_unchecked(profile, selected, native):
    x = _matrix(selected, len(profile.feature_names), "selected")
    raw = numeric_values(native)
    if len(raw) != len(x):
        raise ValueError("selected/native row alignment required")
    z = (raw - profile.mean) / profile.scale
    assigned = assign_nodes(profile, x)
    q, signed = np.zeros((len(x), 4)), np.zeros((len(x), 4))
    for key in sorted(set(assigned)):
        rows = np.asarray([i for i, k in enumerate(assigned) if k == key], dtype=np.int64)
        node = profile.nodes[key]
        q[rows] = _node_quadratics(node, z[rows])
        signed[rows] = np.arcsinh((q[rows] - node["block_center"]) / node["block_scale"])
    if not np.isfinite(signed).all():
        raise ValueError("finite four signed coordinates required")
    return dict(block_score=q, signed_block_score=signed, score=signed.max(axis=1), nodes=assigned)


def score(profile, selected, native):
    check(profile)
    result = _score_unchecked(profile, selected, native)
    check(profile)
    return result


def fit(feature_names, auth_splits, fit_features, fit_native41, fit_truth,
        cal_features, cal_native41, cal_truth, fit_ids, cal_ids, *, role="fit"):
    if role != "fit":
        raise ValueError("only original FIT role may fit block parameters")
    names = tuple(feature_names)
    if not names or any(not isinstance(n, str) or not n for n in names) or len(set(names)) != len(names):
        raise ValueError("exact unique frozen selected feature names required")
    x, cal = (_matrix(v, len(names), "known selected") for v in (fit_features, cal_features))
    if len(x) + len(cal) > 6000:
        raise ValueError("combined FIT/CAL exceeds6000")
    y, cy = _known_labels(fit_truth, len(x)), _known_labels(cal_truth, len(cal))
    fids, cids = _ids(fit_ids, len(x)), _ids(cal_ids, len(cal))
    if set(fids) & set(cids):
        raise ValueError("FIT/CAL identities must be disjoint")
    raw, cr = numeric_values(fit_native41), numeric_values(cal_native41)
    if len(raw) != len(x) or len(cr) != len(cal):
        raise ValueError("FIT/CAL selected/native alignment required")
    splits = _auth_splits(names, auth_splits)
    ben_x, ben_raw = x[y == 0], raw[y == 0]
    order = _canonical(np.column_stack([ben_x, ben_raw]))
    ben_x, ben_raw = ben_x[order], ben_raw[order]
    mean, scale = ben_raw.mean(axis=0), ben_raw.std(axis=0)
    scale[scale <= np.finfo(float).eps] = 1.
    z = (ben_raw - mean) / scale
    alternatives = hierarchical_keys(ben_x, names, splits)
    nodes, audit = {}, []
    for key in sorted({k for keys in alternatives for k in keys}):
        rows = np.asarray([i for i, keys in enumerate(alternatives) if key in keys], dtype=np.int64)
        admitted = len(rows) >= MIN_FIT
        if admitted:
            nodes[key] = _fit_node(z[rows])
        audit.append(dict(node=list(key), BEN_fit_rows=len(rows), admitted=admitted))
    profile = ConditionalBlocksProfile(names, splits, mean, scale, nodes, 0., {})
    cal_values = _score_unchecked(profile, cal, cal_native41)
    m = int((cy == 0).sum())
    rank = (99 * (m + 1) + 99) // 100
    if rank > m:
        raise ValueError("known BEN CAL needs>=99 rows for finite strict99 rank")
    profile.cutoff = float(np.sort(cal_values["score"][cy == 0])[rank - 1])
    profile.manifest = dict(schema_version=SCHEMA, feature_names=list(names),
        numeric_fields=list(NUMERIC_FIELDS), blocks=[dict(name=k, fields=list(f)) for k, f in BLOCKS],
        auth_splits=[list(s) for s in splits], ridge=RIDGE, minimum_node_BEN_FIT=MIN_FIT,
        FIT_rows=len(x), CAL_rows=len(cal), fit_coarse_counts=[int((y == c).sum()) for c in (0, 1)],
        cal_coarse_counts=[int((cy == c).sum()) for c in (0, 1)],
        fit_ids_sha256=_hash(fids), cal_ids_sha256=_hash(cids),
        fit_values_sha256=_role_hash(x, raw, y), cal_values_sha256=_role_hash(cal, cr, cy),
        duration_used_by_new_score=False, parent_native41_storage_unchanged=True,
        fit_role="fit", calibration_BEN_rows=m, calibration_rank_one_based=rank,
        cutoff=profile.cutoff, comparator="strict greater",
        score="max4 signed asinh((conditional quadratic/block_dimension-node_BEN_FIT_median)/max(node_BEN_FIT_MAD,1))",
        coordinate="four signed asinh((q_B-node_BEN_FIT_median)/max(node_BEN_FIT_MAD,1))",
        calibration_union_nominal_all_chain99_claim=False, source_admission_or_family_floor_provided=False,
        query_truth_features_IDs_used_for_fit=False, nodes=audit,
        published=False, final_test_executed=False)
    profile.manifest["frozen_state_sha256"] = _digest(profile)
    profile.manifest["frozen_manifest_sha256"] = _manifest_hash(profile.manifest)
    check(profile)
    return profile


def evaluate(profile, selected, native41, stage1):
    values = score(profile, selected, native41)
    stage = _labels(stage1, len(values["score"]))
    return dict(**values, raw_candidate=(stage == 0) & (values["score"] > profile.cutoff))


def coordinates(embedding, scaler, signed):
    e = _matrix(embedding, EMBEDDING_WIDTH, "frozen embedding")
    s = _matrix(signed, 4, "signed blocks")
    if len(e) != len(s) or getattr(scaler, "n_features_in_", None) != EMBEDDING_WIDTH:
        raise ValueError("same rows and frozen32 embedding scaler required")
    frozen = _hash(scaler)
    scaled = _matrix(scaler.transform(e), EMBEDDING_WIDTH, "scaled embedding")
    if _hash(scaler) != frozen:
        raise ValueError("scoring cannot mutate frozen embedding scaler")
    return np.column_stack([scaled / math.sqrt(EMBEDDING_WIDTH), 2. * s / math.sqrt(4)])


def _select_anchor_coordinates(q):
    unique = np.unique(_matrix(q, COORDINATE_WIDTH, "known coordinates"), axis=0)
    if len(unique) <= MAX_ANCHORS:
        return unique.copy()
    selected = [0]
    distance = np.einsum("ij,ij->i", unique - unique[0], unique - unique[0])
    distance[0] = -np.inf
    for _ in range(1, MAX_ANCHORS):
        ix = int(np.argmax(distance))
        selected.append(ix)
        delta = unique - unique[ix]
        distance = np.minimum(distance, np.einsum("ij,ij->i", delta, delta))
        distance[np.asarray(selected)] = -np.inf
    return unique[np.asarray(selected)].copy()


def fit_anchors(profile, fit_features, fit_native41, fit_truth, fit_embedding,
                cal_features, cal_native41, cal_truth, cal_embedding, scaler):
    check(profile)
    x, cal = (_matrix(v, len(profile.feature_names), "known selected") for v in (fit_features, cal_features))
    y, cy = _known_labels(fit_truth, len(x)), _known_labels(cal_truth, len(cal))
    raw, cr = numeric_values(fit_native41), numeric_values(cal_native41)
    if (_role_hash(x, raw, y) != profile.manifest["fit_values_sha256"]
            or _role_hash(cal, cr, cy) != profile.manifest["cal_values_sha256"]):
        raise ValueError("anchors require exactly the original FIT/CAL score inputs")
    e, ce = (_matrix(v, EMBEDDING_WIDTH, "known embedding") for v in (fit_embedding, cal_embedding))
    if len(e) != len(x) or len(ce) != len(cal):
        raise ValueError("FIT/CAL known embedding alignment required")
    features, raw, embedding = np.vstack([x[y == 0], cal[cy == 0]]), np.vstack([raw[y == 0], cr[cy == 0]]), np.vstack([e[y == 0], ce[cy == 0]])
    alternatives = hierarchical_keys(features, profile.feature_names, profile.auth_splits)
    z = (raw - profile.mean) / profile.scale
    nodes, audit = {}, []
    for key in sorted(profile.nodes):
        rows = np.asarray([i for i, keys in enumerate(alternatives) if key in keys], dtype=np.int64)
        node = profile.nodes[key]
        q = _node_quadratics(node, z[rows])
        signed = np.arcsinh((q - node["block_center"]) / node["block_scale"])
        candidate_anchors = _select_anchor_coordinates(coordinates(embedding[rows], scaler, signed))
        admitted = len(candidate_anchors) >= MIN_FIT
        if admitted:
            nodes[key] = candidate_anchors
        audit.append(dict(node=list(key), real_known_BEN_rows=len(rows), anchors=len(candidate_anchors), admitted=admitted))
    manifest = dict(schema_version=SCHEMA+"-anchors", coordinate_width=COORDINATE_WIDTH,
        nodes=audit, max_anchors=MAX_ANCHORS, min_unique_anchors=MIN_FIT,
        source="exact real BEN FIT plus CAL; coordinate dedup; canonical first then farthest geometry",
        profile_state_sha256=_digest(profile), embedding_scaler_sha256=_hash(scaler),
        query_truth_features_IDs_used=False, known_CAL_anchors_NOT_heldout_validation=True,
        frozen_anchor_state_sha256=_hash(nodes), published=False)
    manifest["frozen_manifest_sha256"] = _manifest_hash(manifest)
    return dict(nodes=nodes, manifest=manifest)


def _check_anchors(profile, anchors, scaler=None):
    m, nodes = anchors["manifest"], anchors["nodes"]
    if (m.get("schema_version") != SCHEMA+"-anchors" or m.get("frozen_manifest_sha256") != _manifest_hash(m)
            or m.get("profile_state_sha256") != _digest(profile) or m.get("frozen_anchor_state_sha256") != _hash(nodes)
            or m.get("coordinate_width") != COORDINATE_WIDTH or m.get("query_truth_features_IDs_used") is not False
            or any(k not in profile.nodes or a.shape[1:] != (COORDINATE_WIDTH,)
                   or not MIN_FIT <= len(a) <= MAX_ANCHORS or not np.isfinite(a).all() for k, a in nodes.items())
            or (scaler is not None and m.get("embedding_scaler_sha256") != _hash(scaler))):
        raise ValueError("unchanged real-known matching-coordinate anchors required")


def route(profile, anchors, selected, query_coordinates, raw_candidate):
    check(profile)
    _check_anchors(profile, anchors)
    x, q = _matrix(selected, len(profile.feature_names), "selected"), _matrix(query_coordinates, COORDINATE_WIDTH, "query coordinates")
    raw = np.asarray(raw_candidate)
    if len(q) != len(x) or raw.shape != (len(x),) or raw.dtype != np.bool_:
        raise ValueError("paired boolean raw candidates required")
    assigned = assign_nodes(profile, x)
    retained, supported = np.zeros(len(x), dtype=bool), np.zeros(len(x), dtype=bool)
    first, second = np.full(len(x), -2, dtype=np.int64), np.full(len(x), -2, dtype=np.int64)
    primary, secondary, suspected = (np.zeros(len(x), dtype=bool) for _ in range(3))
    audit, first_offset, second_offset = [], 0, 0
    for key in sorted(set(assigned)):
        rows = np.asarray([i for i, k in enumerate(assigned) if k == key], dtype=np.int64)
        if key not in anchors["nodes"]:
            first[rows[raw[rows]]] = -3
            audit.append(dict(node=list(key), rows=len(rows), status="UNSUPPORTED_KNOWN_ANCHORS_KEEP_PARENT"))
            continue
        supported[rows] = True
        out = anchored_route(q[rows], raw[rows], anchors["nodes"][key])
        retained[rows] = out.retained
        a, b = out.first.copy(), out.second.copy()
        a[a >= 0] += first_offset
        b[b >= 0] += second_offset
        first[rows], second[rows] = a, b
        if np.any(out.first >= 0):
            first_offset += int(out.first[out.first >= 0].max()) + 1
        if np.any(out.second >= 0):
            second_offset += int(out.second[out.second >= 0].max()) + 1
        primary[rows], secondary[rows], suspected[rows] = out.primary_anchor_free, out.secondary_anchor_free, out.suspected
        audit.append(dict(node=list(key), rows=len(rows), DVC=out.manifest))
    if np.any(retained & (~raw | ~supported)):
        raise AssertionError("only supported actual raw nonnoise DVC can retain")
    return dict(retained=retained, supported=supported, first=first, second=second,
                primary_anchor_free=primary, secondary_anchor_free=secondary, suspected=suspected,
                manifest=dict(schema_version=SCHEMA+"-DVC", query_rows=len(x), raw_candidates=int(raw.sum()),
                              retained=int(retained.sum()), nodes=audit, old_anchor_DVC_parameters_unchanged=True,
                              unsupported_keep_parent=True, query_truth_family_ID_used=False, published=False))


def extension(profile, anchors, scaler, selected, native41, embedding, stage1, parent2244):
    check(profile)
    _check_anchors(profile, anchors, scaler)
    values = evaluate(profile, selected, native41, stage1)
    parent = _labels(parent2244, len(values["score"]), known=False)
    stage = _labels(stage1, len(parent))
    q = coordinates(embedding, scaler, values["signed_block_score"])
    dvc = route(profile, anchors, selected, q, values["raw_candidate"])
    added = (stage == 0) & (parent == 0) & values["raw_candidate"] & dvc["retained"]
    final = parent.copy()
    final[added] = 2
    check(profile)
    return dict(final=final, added_UNA=added, block_score=values["block_score"], score=values["score"],
                signed_block_score=values["signed_block_score"], raw_candidate=values["raw_candidate"],
                query_coordinates=q, **dvc)


class FrozenNative40ConditionalBlocksPredictor:
    def __init__(self, parent2244, profile, anchors, scaler):
        self.parent2244, self.profile, self.anchors, self.scaler = parent2244, profile, anchors, scaler
        self._check_parent()
        check(profile)
        _check_anchors(profile, anchors, scaler)
        self.frozen_extension_sha256 = _hash((profile, anchors, scaler))

    def _check_parent(self):
        self.parent2244._check()
        if (self.profile.feature_names != self.parent2244.profile.feature_names
                or self.profile.auth_splits != self.parent2244.profile.auth_splits
                or _hash(self.scaler) != _hash(self.parent2244.scaler)):
            raise ValueError("same frozen parent2244 features/auth/scaler required")

    def _check(self):
        self._check_parent()
        check(self.profile)
        _check_anchors(self.profile, self.anchors, self.scaler)
        if self.frozen_extension_sha256 != _hash((self.profile, self.anchors, self.scaler)):
            raise ValueError("unchanged parent2244 native35 extension required")

    def predict_native41(self, frame):
        self._check()
        native = checked_native41(frame)
        numeric_values(native)
        parent = self.parent2244.predict_native41(native)
        base = parent["parent40"]
        new = extension(self.profile, self.anchors, self.scaler, base["log_model_features"], native,
                        parent["log_embedding"], base["stage1"], parent["candidate"]["final"])
        self._check()
        return dict(candidate=new, parent2244=parent["candidate"], parent2231=parent["parent2231"],
                    parent2192=parent["parent2192"], parent40=base, log_embedding=parent["log_embedding"],
                    native_duration_seconds=parent["native_duration_seconds"])
