"""Export the complete retained NSL1 predictor without query archives.

Only twenty explicitly pinned known-policy assets and actual known FIT rows
are compiled. No query features, query truth or historical prediction vector
is loaded. The new manifest is frozen before a separate replay may query it.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import time

import joblib
import numpy as np
import pandas as pd
import torch

from .config import NSL_FEATURE_COLUMNS, SETTINGS, get_spec
from .data import sha256_file
from .model import MHFDNetwork
from .nsl_log_saved_state_loader import load_saved_log_state
from .nsl_frozen_feature_pipeline import (SCHEMA, BASELINE_NAMES, OVERLAY_NAMES,
    FrozenNSLFeaturePipeline, checked_frame, selected_coordinates, inference_source_paths, state_fingerprint)
from .nsl_frozen_feature_pipeline import runtime_versions


ROOT = Path(__file__).resolve().parents[1]
PREFIX = "NSL-KDD Setting1/run/"
ROLE_IDS_SHA = "17b5a2f93ecb3475b237176fef9311b9e36efae58b1bd6406325199aff490c3b"
SOURCE_SHA = "1b86d2f957b33082081bba410fe129b475efebcc13c9014c3f447c8271aadf95"
SOURCE_ROWS = 125973
ASSETS = (
    ('original_preprocessing', 'role_floor_original_train_20261002_v1/preprocessing_and_calibrator.joblib', 'c685dd4bcdd7621d209c71a7dd0ad1f2e3764f30b0aa6141388707d3892c8e50'),
    ('original_checkpoint', 'role_floor_original_train_20261002_v1/checkpoint_selected.pt', 'f00758df98feb038ffee5f71f7b74c7f120be579fd033531577673f5254c0b44'),
    ('log_preprocessing', 'role_floor_log_numeric_20261002_v1/preprocessing_and_calibrator.joblib', '051e1c03eff48ea0e0f5bebc73e957955301ccd694470b6771058cf52a4a6a76'),
    ('log_checkpoint', 'role_floor_log_numeric_20261002_v1/checkpoint_selected.pt', 'afae4c48677a491471333a16b45746b621fec2e82b05c2699b59c1dc4c92012e'),
    ('fused', 'role_floor_dual_log_BEN_fit99_cal_whitened_views_20261002_v1/known_only_fused_calibrator.joblib', '72a20770a5f1fd2cef551b95e194f09be00e7d47d43dc98dfd78fb566228d2c0'),
    ('white', 'role_floor_dual_log_BEN_whitened_views_20261002_v1/known_only_BEN_context_profile.joblib', 'df1ac60c0801cebd1f7f4e6488ac391e28e65a33e07481c69f51628a6e0c3b80'),
    ('hierarchy', 'role_floor_dual_log_BEN_hierarchical_fallback_20261002_v1/known_only_hierarchical_fallback_profile.joblib', '34362aa1f0ddab19b822e11acf680a6081f33d77f2f9b4f690b3e7de1290b5b0'),
    ('radius', 'role_floor_dual_log_BEN_local_radius_cover_20261002_v1/known_only_local_radius_cover_profile.joblib', '8fa08d4f8d31e710242b08530b81e4f7a55ad1ae11982d40982264a8a0490378'),
    ('reach', 'role_floor_dual_log_BEN_whitened_local_reachability_20261002_v2/known_only_local_reachability_profile.joblib', '9e4c4e33fffcd6fd7a503783817e1117be1c929c88a70a81489129d84fc922bc'),
    ('joint', 'role_floor_dual_log_BEN_joint_whitened_local_reachability_20261002_v1/known_only_local_reachability_profile.joblib', 'a0ea88c15dc0b0c20fc4fc22f41e5c44a60b256ef6a0bc0345a10d15c815d2c1'),
    ('consensus', 'role_floor_dual_log_BEN_local_density_consensus_20261002_v1/known_only_local_reachability_profile.joblib', 'b802054baa283775f1289f8bd8e13fc0b14566f2ab0cb140fa8b043c58d24973'),
    ('witness', 'retained_BEN_content_density_witness_20261003_v1/known_only_policy.joblib', '6d32a93d4ae22b6ef7f4fbbb8db632d85db6887c13a4d4d8189106602a3a4a5b'),
    ('content_anchors', 'content_density_known_BEN_anchor_DVC_20261003_v1/known_BEN_anchors_frozen_before_query.npz', '5df184bcbfb368f07c982838b204ebd591a6f80da3fd33345e2e03359b0cb517'),
    ('covering', 'known_supcon_covering_factorial_20261003_v1_w001/known_only_policy_states.joblib', '9083c77d901c1e8a6898c5d3ce252b7c79f01240a76ded9021c46066ba98a4a2'),
    ('conditional', 'known_fine_OAS_factorial_20261003_v1/known_only_policy_states.joblib', 'f67144fbadaeb7bad8e71ccf61a0d106692d8d7ffa1229d19cf10f8a595d49db'),
    ('sparse', 'sparse_known_reference_guard_20261003_v1/known_only_policy.joblib', '820097237daa46b225c1bd0e4210926f80f036d033ceb09ee3bfad69beb1387d'),
    ('greedy', 'greedy_known_reference_guard_20261003_v1/known_only_policy.joblib', 'b7e6deef02899c69b774773595ae57d17def52ec6dfc432d5da8a72e4d2d3945'),
    ('auth', 'auth_context_known_reference_guard_20261003_v1/known_only_policy.joblib', 'bc76a24843751e2aeb96f126a18132c2105fbeeb942ac510219214afb21cb0c8'),
    ('quorum', 'auth_quorum_known_reference_guard_20261004_v1/known_only_policy.joblib', 'e2e0b8aaa9889f7035e49fcc5661d1de29f7155da5a43336da8c353440792936'),
    ('context', 'auth_context_separated_dvc_20261004_v1/known_only_policy.joblib', 'fca5d536b2740a3f061738f11334258251390fc34b72e0f82cb7607729e351c2'),
)


def formal_snapshot(root):
    return {setting + "/" + name: sha256_file(root / setting / name)
            for setting in SETTINGS for name in ("Matrix.txt", "experiment_A_standard_accuracy.csv")}


def rebuild_fit_frame(source, fit_ids, source_sha, expected_rows):
    """Decode only selected known FIT lines from a hash-bound original source."""
    ids = np.asarray(fit_ids).astype(str)
    prefix = "nsl_kdd:original-source-train:" + source_sha + ":"
    if not 20 <= len(ids) <= 6000 or len(set(ids.tolist())) != len(ids):
        raise ValueError("unique capped actual known FIT row IDs required at compilation")
    ordinals = []
    for identifier in ids:
        tail = identifier.removeprefix(prefix).split(":")
        if not identifier.startswith(prefix) or len(tail) != 2 or not tail[0].isdigit() or len(tail[1]) != 16:
            raise ValueError("FIT ID is not from the pinned original training source")
        ordinals.append(int(tail[0]))
    if len(set(ordinals)) != len(ordinals) or any(i >= expected_rows for i in ordinals):
        raise ValueError("distinct bounded original source row ordinals required")
    selected, wanted, rows = {}, set(ordinals), 0
    allowed = {"normal", *get_spec("NSL-KDD Setting1").known_families}
    with Path(source).open("rb") as handle:
        for index, line in enumerate(handle):
            rows += 1
            if index not in wanted:
                continue
            cells = line.decode("utf8").strip().split(",")
            if len(cells) != 43:
                raise ValueError("original NSL known FIT row must contain exactly 43 fields")
            family = cells[41].strip().casefold().removesuffix(".")
            if family not in allowed:
                raise ValueError("UNA/excluded truth in a known-only FIT reference")
            selected[index] = (cells[1:41], family)
    if rows != expected_rows or len(selected) != len(ids):
        raise ValueError("source row contract or selected FIT coverage changed")
    counts = Counter(selected[index][1] for index in ordinals)
    if set(counts) != allowed or any(counts[family] < 20 for family in allowed):
        raise ValueError("every BEN/KNA FIT family must contain at least twenty real source rows")
    frame = checked_frame(pd.DataFrame([selected[index][0] for index in ordinals], columns=NSL_FEATURE_COLUMNS))
    # IDs/truth are compilation evidence only; neither is serialized in state.
    return frame, dict(sorted(counts.items()))


def compile_pipeline(workspace, output_directory):
    workspace, output = Path(workspace).resolve(), Path(output_directory).resolve()
    if workspace != ROOT or workspace not in output.parents or output.exists():
        raise ValueError("fresh contained export directory in this workspace required")
    started = time.perf_counter()
    formal, pins, paths, receipts = formal_snapshot(workspace), {}, {}, {}

    def pin(path, expected=None):
        path = Path(path).resolve()
        if workspace not in path.parents:
            raise ValueError("compilation input must stay in this workspace")
        digest = sha256_file(path)
        if expected is not None and digest != expected:
            raise ValueError("sealed compilation input changed: " + str(path))
        pins[str(path)] = digest
        return path

    for name, relative, expected in ASSETS:
        path = pin(workspace / PREFIX / relative, expected)
        paths[name] = path
        report_path = path.parent / "report.json"
        if str(report_path) not in receipts:
            report = json.loads(pin(report_path).read_text(encoding="utf8"))
            if report.get("published") is not False or report.get("final_test_executed") is not False:
                raise ValueError("only sealed nonfinal development receipts may be compiled")
            receipts[str(report_path)] = report
    for name in ("original", "log"):
        report = receipts[str(paths[name + "_checkpoint"].parent / "report.json")]
        frozen = report["frozen_policy"]
        if (report["epochs_completed"] != 100
                or frozen["checkpoint_sha256"] != pins[str(paths[name + "_checkpoint"])]
                or frozen["preprocessing_sha256"] != pins[str(paths[name + "_preprocessing"])]
                or frozen["role_ids_sha256"] != ROLE_IDS_SHA):
            raise ValueError("known-trained MHFD checkpoint/preprocessor/roles receipt differs")

    role_path = pin(workspace / PREFIX / "role_floor_original_train_20261002_v1/frozen_role_ids.npz", ROLE_IDS_SHA)
    with np.load(role_path, allow_pickle=False) as archive:
        if set(archive.files) != {"fit", "checkpoint", "calibration", "open_known"}:
            raise ValueError("sealed four known-role protocol required")
        fit_ids = archive["fit"].copy()
    audit_path = pin(workspace / PREFIX / "role_floor_log_numeric_20261002_v1/data_audit.json")
    audit = json.loads(audit_path.read_text(encoding="utf8"))["original_source_contract"]
    if audit["sha256"] != SOURCE_SHA or audit["rows"] != SOURCE_ROWS:
        raise ValueError("pinned original train source receipt differs")
    source = pin(audit["path"], SOURCE_SHA)
    fit_frame, fit_counts = rebuild_fit_frame(source, fit_ids, SOURCE_SHA, SOURCE_ROWS)

    preprocessing, models, thresholds, checkpoints, references = {}, {}, {}, {}, {}
    for name in ("original", "log"):
        saved = load_saved_log_state(paths[name + "_preprocessing"]) if name == "log" else joblib.load(paths[name + "_preprocessing"])
        preprocessing[name] = {key: saved[key] for key in ("preprocessor", "variance_mask", "selector")}
        references[name] = selected_coordinates(preprocessing[name], fit_frame)
        checkpoint = torch.load(paths[name + "_checkpoint"], map_location="cpu", weights_only=True)
        if references[name].shape[1] != checkpoint["feature_count"]:
            raise ValueError("rebuilt known FIT coordinates differ from checkpoint width")
        model = MHFDNetwork(checkpoint["feature_count"], len(checkpoint["fine_classes"]))
        model.load_state_dict(checkpoint["state_dict"], strict=True)
        models[name] = model.cpu().eval()
        thresholds[name] = float(checkpoint["coarse_threshold"])
        report = receipts[str(paths[name + "_checkpoint"].parent / "report.json")]
        if thresholds[name] != report["frozen_policy"]["threshold_selected_from_known_calibration_only"]:
            raise ValueError("fixed known calibration threshold differs")
        checkpoints[name] = checkpoint
    if checkpoints["original"]["seed"] != checkpoints["log"]["seed"]:
        raise ValueError("paired fixed MHFD seed differs")
    with np.load(paths["content_anchors"], allow_pickle=False) as archive:
        anchors = archive["coordinates"].copy()
    # Select only ordinary-network frozen density policies, no factorial vectors
    # and no unrelated trained representation or target matrix is exported.
    density = {}
    for name in ("covering", "conditional"):
        policy = joblib.load(paths[name])
        density[name] = dict(density=policy["raw_policies"]["ordinary"], calibrator=policy["calibrators"]["ordinary"])
    state = dict(models=models, preprocessing=preprocessing, thresholds=thresholds,
        seed=int(checkpoints["log"]["seed"]), references=references,
        fused_calibrator=joblib.load(paths["fused"]),
        baseline_profiles={name: joblib.load(paths[name]) for name in BASELINE_NAMES},
        witness=joblib.load(paths["witness"]), content_anchors=anchors,
        covering=density["covering"], conditional=density["conditional"],
        overlays={name: joblib.load(paths[name]) for name in OVERLAY_NAMES}, context=joblib.load(paths["context"]))

    source_hashes = {str(path): sha256_file(path) for path in inference_source_paths()}
    compiler_sha = sha256_file(Path(__file__))
    manifest = dict(schema_version=SCHEMA, status="FAIL_TARGET99", published=False,
        final_test_executed=False, independent_final_scoring_admitted=False,
        query_prediction_archives_used=False, query_truth_ID_family_source_used=False,
        query_model_features_loaded_during_compilation=False, full_chain_recomputed_from_query_model_features=True,
        all_full_feature_DVC_numeric_canonical_ordering=True,
        all_historically_ID_ordered_full_feature_routes_repaired_to_numeric=True,
        ordering_policy="numeric lexicographic coordinates for every full-feature DVC; ephemeral unique row indices satisfy validation only",
        exact_historical_2189_forecast_reproduction_NOT_guaranteed=True,
        inherited_historical_development_inspection_precedes_design=True,
        transductive_batch_predictor=True, physical_event_independence_verified=False,
        new_NN_training_epochs=0, neural_checkpoint_epochs={name: 100 for name in models},
        query_columns=list(NSL_FEATURE_COLUMNS), maximum_query_rows=6000,
        known_FIT_rows=len(fit_frame), known_FIT_family_counts=fit_counts,
        known_FIT_references_sha256={name: hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()
                                     for name, value in references.items()},
        only_known_FIT_source_IDs_used_for_compilation=True, no_source_IDs_or_truth_serialized_in_state=True,
        known_source_sha256=SOURCE_SHA, known_role_ids_sha256=ROLE_IDS_SHA,
        selected_known_policy_asset_count=len(ASSETS), selected_known_policy_assets={name: dict(path=str(paths[name]),sha256=digest)
                         for name, _, digest in ASSETS},
        compilation_input_sha256=pins, inference_source_sha256=source_hashes,
        compiler_source_sha256=compiler_sha, formal_outputs_sha256_unchanged=formal,
        runtime_versions=runtime_versions(),
        state_sha256=state_fingerprint(state))
    FrozenNSLFeaturePipeline(state, manifest)  # State contract only; no query runs.
    output.mkdir(parents=True, exist_ok=False)
    joblib.dump(state, output / "pipeline.joblib", compress=3)
    # Reload exported state without inference to confirm serialization stability.
    exported = joblib.load(output / "pipeline.joblib")
    if state_fingerprint(exported) != manifest["state_sha256"]:
        raise ValueError("compiled state digest changed across serialization")
    if (formal_snapshot(workspace) != formal or any(sha256_file(Path(path)) != digest for path, digest in pins.items())
            or any(sha256_file(Path(path)) != digest for path, digest in source_hashes.items())
            or sha256_file(Path(__file__)) != compiler_sha):
        raise ValueError("sealed inputs, inference sources or formal outputs changed during compilation")
    manifest.update(pipeline_sha256=sha256_file(output / "pipeline.joblib"), compilation_wall_seconds=time.perf_counter() - started)
    (output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2)+"\n", encoding="utf8")
    print(json.dumps(dict(export_directory=str(output), status="FAIL_TARGET99", published=False,
                         known_FIT_rows=len(fit_frame), selected_known_policy_assets=len(ASSETS),
                         query_rows_scored=0, wall_seconds=manifest["compilation_wall_seconds"])), flush=True)
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", default=str(ROOT))
    parser.add_argument("--output-directory", required=True)
    arguments = parser.parse_args()
    compile_pipeline(arguments.workspace, arguments.output_directory)
