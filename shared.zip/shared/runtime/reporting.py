from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix

from .model import CSV_COLUMNS


LABELS = ("BEN", "KNA", "UNA")


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )


def write_epoch_csv(path: Path, history: list[dict[str, Any]]) -> None:
    frame = pd.DataFrame(history, columns=list(CSV_COLUMNS))
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, encoding="utf-8-sig")


def confusion_counts(y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
    return confusion_matrix(y_true, y_pred, labels=[0, 1, 2]).T.astype(np.int64)


def column_percentages(counts: np.ndarray) -> np.ndarray:
    supports = counts.sum(axis=0, keepdims=True)
    return np.divide(
        counts.astype(np.float64) * 100.0,
        supports,
        out=np.zeros_like(counts, dtype=np.float64),
        where=supports > 0,
    )


def _development_matrix_text(counts_2x2: np.ndarray) -> str:
    ben_support = int(counts_2x2[:, 0].sum())
    kna_support = int(counts_2x2[:, 1].sum())
    ben_ben = int(counts_2x2[0, 0])
    ben_kna = int(counts_2x2[0, 1])
    kna_ben = int(counts_2x2[1, 0])
    kna_kna = int(counts_2x2[1, 1])
    return "\n".join(
        [
            "二、原始数量矩阵（开发；UNA 路由未执行时保持未评估）",
            "预测\\真实                      BEN         KNA         UNA",
            f"BEN                 {ben_ben:10d}  {ben_kna:10d}         未评估",
            f"KNA                 {kna_ben:10d}  {kna_kna:10d}         未评估",
            "UNA                        未评估         未评估         未评估",
            "",
            "三、识别率矩阵（%，按真实类别列归一化）",
            "预测\\真实                      BEN         KNA         UNA",
            f"BEN                 {ben_ben / max(1, ben_support) * 100:10.4f}  "
            f"{ben_kna / max(1, kna_support) * 100:10.4f}         未评估",
            f"KNA                 {kna_ben / max(1, ben_support) * 100:10.4f}  "
            f"{kna_kna / max(1, kna_support) * 100:10.4f}         未评估",
            "UNA                        未评估         未评估         未评估",
        ]
    )


def _open_matrix_text(counts: np.ndarray) -> str:
    percentages = column_percentages(counts)
    lines = [
        "二、原始数量矩阵",
        "预测\\真实                      BEN         KNA         UNA",
    ]
    for row_index, label in enumerate(LABELS):
        lines.append(
            f"{label:<3}                 "
            f"{int(counts[row_index, 0]):10d}  "
            f"{int(counts[row_index, 1]):10d}  "
            f"{int(counts[row_index, 2]):10d}"
        )
    lines.extend(
        [
            "",
            "三、识别率矩阵（%，按真实类别列归一化）",
            "预测\\真实                      BEN         KNA         UNA",
        ]
    )
    for row_index, label in enumerate(LABELS):
        lines.append(
            f"{label:<3}                 "
            f"{percentages[row_index, 0]:10.4f}  "
            f"{percentages[row_index, 1]:10.4f}  "
            f"{percentages[row_index, 2]:10.4f}"
        )
    return "\n".join(lines)


def build_matrix_report(
    *,
    run_id: str,
    setting: str,
    epochs: int,
    selected_epoch: int,
    coarse_threshold: float,
    validation_true: np.ndarray,
    validation_pred: np.ndarray,
    open_true: np.ndarray,
    open_pred: np.ndarray,
    open_families: np.ndarray,
    novelty_candidate_count: int,
    routed_una_count: int,
    lofo_proxy_recall: float | None,
    lofo_proxy_support: int,
    runtime_seconds: float,
    data_audit: dict[str, Any],
    raw_candidate_count: int | None = None,
    raw_routed_una_count: int | None = None,
    bootstrap_true: np.ndarray | None = None,
    bootstrap_pred: np.ndarray | None = None,
    bootstrap_families: np.ndarray | None = None,
    bootstrap_candidate_count: int | None = None,
    bootstrap_routed_una_count: int | None = None,
) -> tuple[str, np.ndarray, np.ndarray]:
    if len(open_true) != len(open_pred) or len(open_true) != len(open_families):
        raise ValueError("raw open-set truth, predictions and families differ in length")
    if any(value is not None for value in (bootstrap_true, bootstrap_pred, bootstrap_families)):
        if any(value is None for value in (bootstrap_true, bootstrap_pred, bootstrap_families)):
            raise ValueError("bootstrap truth, predictions and families must be supplied together")
        if len(bootstrap_true) != len(bootstrap_pred) or len(bootstrap_true) != len(bootstrap_families):
            raise ValueError("bootstrap truth, predictions and families differ in length")
        if bootstrap_candidate_count is None or bootstrap_routed_una_count is None:
            raise ValueError("bootstrap candidate and routed counts are required")
    validation_counts = confusion_matrix(
        validation_true, validation_pred, labels=[0, 1]
    ).T.astype(np.int64)
    open_counts = confusion_counts(open_true, open_pred)
    open_pct = column_percentages(open_counts)
    supports = open_counts.sum(axis=0)
    correct = np.diag(open_counts)
    recalls = np.divide(
        correct,
        supports,
        out=np.zeros(3, dtype=np.float64),
        where=supports > 0,
    )

    family_lines = []
    for family in sorted(set(open_families[open_true == 2].tolist())):
        mask = (open_true == 2) & (open_families == family)
        support = int(np.sum(mask))
        identified = int(np.sum(open_pred[mask] == 2))
        family_lines.append(
            f"{family}: UNA={identified}/{support}, "
            f"{identified / max(1, support) * 100:.4f}%"
        )

    proxy_text = (
        "未评估"
        if lofo_proxy_recall is None
        else f"{lofo_proxy_recall * 100:.4f}% ({int(round(lofo_proxy_recall * lofo_proxy_support))}/{lofo_proxy_support})"
    )
    resampling = data_audit["open_evaluation_resampling"]
    bootstrapped_families = {
        family: {
            "scope": details["scope"],
            "raw_count": details["raw_count"],
            "raw_unique_rows": details["raw_unique_rows"],
            "bootstrap_rows": details["bootstrap_rows"],
            "resampled_count": details["resampled_count"],
            "multiplicity": details["multiplicity"],
        }
        for family, details in resampling["family_counts"].items()
        if details["bootstrap_rows"] > 0
    }
    raw_candidate_count = (
        novelty_candidate_count
        if raw_candidate_count is None
        else int(raw_candidate_count)
    )
    raw_routed_una_count = (
        routed_una_count
        if raw_routed_una_count is None
        else int(raw_routed_una_count)
    )
    lines = [
        "MHFD-DVC 密度亲和力聚簇三分类识别矩阵（Matrix.txt）",
        "====================================================",
        "schema_version=2",
        f"run_id={run_id}",
        f"setting={setting}",
        f"epochs={epochs}",
        f"selected_checkpoint_epoch={selected_epoch}",
        f"coarse_threshold={coarse_threshold:.6f}",
        "实现后端：MHFD 特征令牌多头注意力 + 动态门控 + CNN-BiLSTM + DVC 密度路由",
        "类别映射：BEN=良性流量(0)，KNA=已知攻击(1)，UNA=未知攻击(2)",
        "数据角色约束：表1家族标签仅用于预声明 BEN/KNA/UNA 数据角色；fit/checkpoint/calibration 仅含 BEN 与 KNA。",
        "决策约束：评估标签在数据准备时用于预声明表1队列与重抽样计划，不进入预测器、阈值或 DVC；数值计分在预测文件冻结后执行。",
        "测试标签在数据准备阶段已加载=true；完全密封的一次性最终测试=false",
        "目标 UNA 标签用于训练=false",
        "目标 UNA 标签用于预处理=false",
        "目标 UNA 标签用于阈值选择=false",
        "目标 UNA 标签用于DVC拟合=false",
        "未标注开放批次特征用于转导式DVC联合聚簇=true",
        "DVC开放批次标签用于参数搜索=false",
        "DVC未标注开放批次特征用于minPts/eps自适应=true",
        "DVC口径=transductive（不是逐样本纯归纳推理）",
        f"runtime_seconds={runtime_seconds:.3f}",
        "",
        "===== LIVE VALIDATION =====",
        "口径：训练源内部开发验证；此处尚未执行真实 UNA 路由。",
        f"val_BEN_recall={validation_counts[0, 0]}/{int(validation_counts[:, 0].sum())}, "
        f"{validation_counts[0, 0] / max(1, validation_counts[:, 0].sum()) * 100:.4f}%",
        f"val_KNA_recall={validation_counts[1, 1]}/{int(validation_counts[:, 1].sum())}, "
        f"{validation_counts[1, 1] / max(1, validation_counts[:, 1].sum()) * 100:.4f}%",
        f"val_proxy_UNA_recall={proxy_text}",
        "",
        _development_matrix_text(validation_counts),
        "",
        "===== OPEN SET DEVELOPMENT TEST (RAW SOURCE ROWS) =====",
        "status=evaluated",
        "evaluation_scope=one prediction per raw source row; physical-event uniqueness not proven; scoring after prediction freeze",
        "evaluation_is_independent_sample_estimate=false",
        f"raw_candidate_count={raw_candidate_count}",
        f"raw_routed_UNA_count={raw_routed_una_count}",
        f"test_BEN_recall={int(correct[0])}/{int(supports[0])}, {recalls[0] * 100:.4f}%",
        f"test_KNA_recall={int(correct[1])}/{int(supports[1])}, {recalls[1] * 100:.4f}%",
        f"test_UNA_recall={int(correct[2])}/{int(supports[2])}, {recalls[2] * 100:.4f}%",
        f"test_overall_accuracy={np.trace(open_counts) / max(1, np.sum(open_counts)) * 100:.4f}%",
        "",
        _open_matrix_text(open_counts),
        "",
        "四、表1未知攻击家族识别结果（预测冻结后读取标签计分）",
        *family_lines,
    ]
    if bootstrap_true is not None:
        bootstrap_counts = confusion_counts(bootstrap_true, bootstrap_pred)
        bootstrap_support = bootstrap_counts.sum(axis=0)
        bootstrap_correct = np.diag(bootstrap_counts)
        bootstrap_family_lines = []
        for family in sorted(set(bootstrap_families[bootstrap_true == 2].tolist())):
            mask = (bootstrap_true == 2) & (bootstrap_families == family)
            support = int(np.sum(mask))
            identified = int(np.sum(bootstrap_pred[mask] == 2))
            bootstrap_family_lines.append(f"{family}: UNA={identified}/{support}")
        lines.extend([
            "",
            "===== BOOTSTRAP-SENSITIVITY (NOT INDEPENDENT) =====",
            "status=diagnostic_only",
            "evaluation_scope=raw predictions frozen first; labels and predictions then expanded by the evaluation-only bootstrap index",
            "evaluation_is_independent_sample_estimate=false",
            f"evaluation_weighted_candidate_count={bootstrap_candidate_count}",
            f"evaluation_weighted_routed_UNA_count={bootstrap_routed_una_count}",
            *(
                f"bootstrap_{label}_recall={int(bootstrap_correct[index])}/{int(bootstrap_support[index])}"
                for index, label in enumerate(LABELS)
            ),
            "",
            _open_matrix_text(bootstrap_counts),
            "",
            "重抽样后家族计数（仅敏感性诊断）",
            *bootstrap_family_lines,
        ])
    lines.extend([
        "",
        "五、数据与样本约束",
        f"fit_rows={data_audit['split']['fit_rows']}",
        *(
            (
                f"known_source_selected_rows={data_audit['known_source_cohort']['selected_known_rows']}",
                f"known_source_max_rows={data_audit['known_source_cohort']['maximum_known_source_rows']}",
                "known_source_rows_not_verified_independent_physical_flows=true",
            ) if data_audit.get("known_source_cohort") else ()
        ),
        *(
            (
                f"open_source_rows_before_cap={data_audit['open_source_cohort']['source_open_rows']}",
                f"open_source_selected_rows={data_audit['open_source_cohort']['selected_open_rows']}",
                f"open_source_raw_budget={data_audit['open_source_cohort']['raw_row_budget']}",
                f"open_source_below20_original_rows={json.dumps(data_audit['open_source_cohort']['family_original_rows_below_20'], ensure_ascii=False, sort_keys=True)}",
                "open_source_rows_not_verified_independent_physical_flows=true",
                "open_source_target_labels_used_for_predeclared_cohort_composition=true",
                "open_source_cohort_not_independent_final=true",
            ) if data_audit.get("open_source_cohort") else ()
        ),
        f"validation_rows={data_audit['split']['validation_rows']}",
        f"open_test_raw_prediction_rows={data_audit['split']['open_test_rows']}",
        f"open_test_raw_rows_after_overlap_filter={data_audit['split']['open_test_raw_rows_after_overlap_filter']}",
        *(
            (f"open_test_raw_rows_after_source_cap={data_audit['split']['open_test_raw_rows_after_source_cap']}",)
            if "open_test_raw_rows_after_source_cap" in data_audit["split"] else ()
        ),
        f"open_evaluation_rows_after_resampling={data_audit['split']['open_evaluation_rows_after_resampling']}",
        f"open_evaluation_bootstrap_rows={data_audit['split']['open_evaluation_bootstrap_rows']}",
        f"cross_split_exact_feature_rows_removed={data_audit['split']['cross_split_exact_feature_rows_removed']}",
        f"cross_split_exact_feature_rows_detected_by_scope={json.dumps(data_audit['split']['cross_split_exact_feature_rows_detected_by_scope'], ensure_ascii=False, sort_keys=True)}",
        f"open_evaluation_resampling_policy={resampling['policy']}",
        f"minimum_rows_per_declared_non_benign_family={resampling['minimum_rows_per_declared_non_benign_family']}",
        *(
            (
                f"requested_bootstrap_rows_per_family={resampling['requested_bootstrap_rows_per_declared_non_benign_family']}",
                f"open_evaluation_max_rows={resampling['maximum_evaluation_rows']}",
                f"bootstrap_floor_reduced_for_row_cap={str(resampling['bootstrap_floor_reduced_for_row_cap']).lower()}",
            ) if "maximum_evaluation_rows" in resampling else ()
        ),
        f"open_evaluation_raw_unique_rows={resampling['raw_unique_rows']}",
        "raw_unique_rows 仅表示 sample_id 不重复，不证明来源物理事件独立。",
        f"open_evaluation_bootstrap_rows={resampling['bootstrap_rows']}",
        f"bootstrapped_family_audit={json.dumps(bootstrapped_families, ensure_ascii=False, sort_keys=True)}",
        "重抽样说明：bootstrap 行为原始流量的确定性有放回复用，不是新增独立流量；它不进入预处理、模型推理或 DVC 聚簇。",
        "",
        "===== FINAL TEST =====",
        "status=未执行",
        "reason=当前可用数据用于开发与复现实验；尚未提供独立、未查看的外部最终测试集。",
    ])
    return "\n".join(lines) + "\n", open_counts, open_pct


def write_confusion_csv(path: Path, values: np.ndarray, *, percent: bool = False) -> None:
    frame = pd.DataFrame(values, index=LABELS, columns=LABELS)
    frame.index.name = "预测\\真实"
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, encoding="utf-8-sig", float_format="%.4f" if percent else None)
