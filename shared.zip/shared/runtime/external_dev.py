"""Fail-closed admission for independently sourced unknown-development flows.

This module deliberately does not train a model.  It establishes the data
boundary that must be crossed before an external unknown-development cohort
may be used for model or router selection.  The frozen paper test remains an
input to overlap checks only.

The row-level table is expected to contain provenance alongside derived
features.  Raw payload bytes must never be persisted in that table.  A caller
may calculate packet/payload summaries in memory with
``summarize_packet_flow`` and then discard the packet bytes.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import unicodedata
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
from urllib.parse import urlparse

import numpy as np
import pandas as pd


EXTERNAL_UNKNOWN_ROLE = "external_unknown_dev"
REQUIRED_PROVENANCE_COLUMNS = (
    "source_dataset",
    "capture_id",
    "original_sha256",
    "source_url",
    "license",
    "raw_label",
    "role",
)
RAW_ROW_SHA256_COLUMN = "raw_row_sha256"

# A compact, implementation-independent schema.  Extractors may supply more
# columns, but admission requires at least one column from every group by
# default so that a legacy flow-only table cannot silently masquerade as the
# requested enriched asset.
EXTENDED_FEATURE_SCHEMA: dict[str, tuple[str, ...]] = {
    "temporal": (
        "flow_duration_s",
        "packet_iat_mean_s",
        "packet_iat_std_s",
        "packet_iat_min_s",
        "packet_iat_max_s",
    ),
    "packet": (
        "packet_count",
        "fwd_packet_count",
        "bwd_packet_count",
        "packet_len_mean",
        "packet_len_std",
        "packet_len_min",
        "packet_len_max",
        "tcp_syn_count",
        "tcp_ack_count",
        "tcp_fin_count",
        "tcp_rst_count",
    ),
    "payload": (
        "payload_packet_count",
        "payload_total_bytes",
        "payload_len_mean",
        "payload_len_std",
        "payload_len_min",
        "payload_len_max",
        "payload_entropy_mean",
        "payload_entropy_std",
        "payload_entropy_min",
        "payload_entropy_max",
    ),
}

_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_FORBIDDEN_PAYLOAD_COLUMN_MARKERS = (
    "raw_payload",
    "payload_bytes",
    "payload_hex",
    "payload_text",
    "packet_bytes",
    "packet_hex",
)


class ExternalDevAdmissionError(ValueError):
    """Raised when the cohort cannot prove its external-development contract."""

    def __init__(self, message: str, *, report: Mapping[str, Any] | None = None):
        super().__init__(message)
        self.report = dict(report or {})


@dataclass(frozen=True)
class ExternalDevAdmissionReport:
    schema_version: str
    status: str
    role: str
    development_rows: int
    frozen_test_rows: int
    feature_columns: tuple[str, ...]
    overlap_feature_columns: tuple[str, ...]
    feature_groups_present: dict[str, tuple[str, ...]]
    provenance_columns: tuple[str, ...]
    raw_row_overlap_count: int
    normalized_feature_overlap_count: int
    source_file_overlap_count: int
    capture_overlap_count: int | None
    flow_identity_overlap_count: int | None
    development_raw_row_sha256: str
    development_model_feature_fingerprint_sha256: str
    development_feature_fingerprint_sha256: str
    frozen_raw_row_sha256: str
    frozen_feature_fingerprint_sha256: str
    no_raw_payload_persisted: bool
    notes: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def sha256_raw_row(raw_row: str | bytes) -> str:
    """Hash the exact serialized source row before parsing or normalization."""

    encoded = raw_row if isinstance(raw_row, bytes) else raw_row.encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _set_digest(values: Iterable[str]) -> str:
    material = "\n".join(sorted(set(str(value) for value in values)))
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def _normalize_scalar(value: Any) -> str:
    if value is None or pd.isna(value):
        return "<NA>"
    if isinstance(value, (bool, np.bool_)):
        return "1" if bool(value) else "0"
    if isinstance(value, (int, np.integer)):
        return str(int(value))
    if isinstance(value, (float, np.floating)):
        number = float(value)
        if not math.isfinite(number):
            raise ExternalDevAdmissionError("feature values must be finite")
        if number == 0.0:
            number = 0.0
        return format(number, ".17g")
    return unicodedata.normalize("NFKC", str(value)).strip().casefold()


def normalized_feature_fingerprints(
    frame: pd.DataFrame, feature_columns: Sequence[str]
) -> pd.Series:
    """Return SHA-256 fingerprints after deterministic scalar normalization."""

    columns = tuple(str(column) for column in feature_columns)
    missing = sorted(set(columns) - set(frame.columns))
    if not columns:
        raise ExternalDevAdmissionError("feature_columns must not be empty")
    if missing:
        raise ExternalDevAdmissionError(f"missing feature columns: {missing}")

    def fingerprint(row: pd.Series) -> str:
        payload = [[column, _normalize_scalar(row[column])] for column in columns]
        encoded = json.dumps(
            payload, ensure_ascii=False, separators=(",", ":")
        ).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()

    return frame.loc[:, columns].apply(fingerprint, axis=1)


def _entropy(payload: bytes) -> float:
    if not payload:
        return 0.0
    counts = Counter(payload)
    total = float(len(payload))
    return float(-sum((count / total) * math.log2(count / total) for count in counts.values()))


def _summary(
    values: Sequence[float], prefix: str, *, unit_suffix: str = ""
) -> dict[str, float]:
    array = np.asarray(values, dtype=np.float64)
    if array.size == 0:
        return {
            f"{prefix}_mean{unit_suffix}": 0.0,
            f"{prefix}_std{unit_suffix}": 0.0,
            f"{prefix}_min{unit_suffix}": 0.0,
            f"{prefix}_max{unit_suffix}": 0.0,
        }
    return {
        f"{prefix}_mean{unit_suffix}": float(array.mean()),
        f"{prefix}_std{unit_suffix}": float(array.std(ddof=0)),
        f"{prefix}_min{unit_suffix}": float(array.min()),
        f"{prefix}_max{unit_suffix}": float(array.max()),
    }


def summarize_packet_flow(packets: Iterable[Mapping[str, Any]]) -> dict[str, float | int]:
    """Summarize one flow without returning or storing raw payload bytes.

    Each packet needs ``timestamp`` and ``length``.  ``direction`` is optional
    (``fwd`` is the default), as are ``payload`` bytes and an iterable/string
    of TCP ``flags``.  Packets are sorted by timestamp for temporal summaries.
    """

    materialized = list(packets)
    if not materialized:
        raise ExternalDevAdmissionError("cannot summarize an empty packet flow")
    for required in ("timestamp", "length"):
        if any(required not in packet for packet in materialized):
            raise ExternalDevAdmissionError(f"packet is missing {required!r}")

    materialized.sort(key=lambda packet: float(packet["timestamp"]))
    timestamps = np.asarray(
        [float(packet["timestamp"]) for packet in materialized], dtype=np.float64
    )
    lengths = [float(packet["length"]) for packet in materialized]
    if not np.isfinite(timestamps).all() or not np.isfinite(lengths).all():
        raise ExternalDevAdmissionError("packet timestamp/length values must be finite")
    if any(length < 0 for length in lengths):
        raise ExternalDevAdmissionError("packet lengths must be non-negative")

    iats = np.diff(timestamps).tolist()
    if any(iat < 0 for iat in iats):  # Defensive; sorting should make this impossible.
        raise ExternalDevAdmissionError("packet timestamps are not monotonic")

    payloads: list[bytes] = []
    for packet in materialized:
        payload = packet.get("payload", b"")
        if payload is None:
            payload = b""
        if not isinstance(payload, (bytes, bytearray, memoryview)):
            raise ExternalDevAdmissionError("packet payload must be bytes-like")
        payloads.append(bytes(payload))
    nonempty_payloads = [payload for payload in payloads if payload]
    payload_lengths = [float(len(payload)) for payload in nonempty_payloads]
    payload_entropies = [_entropy(payload) for payload in nonempty_payloads]

    flag_counts = {flag: 0 for flag in ("syn", "ack", "fin", "rst")}
    for packet in materialized:
        raw_flags = packet.get("flags", ())
        if isinstance(raw_flags, str):
            normalized_flags = set(raw_flags.casefold().replace(",", " ").split())
            # Also accept compact flag strings such as "SA".
            compact = raw_flags.upper()
            normalized_flags.update(
                name for symbol, name in (("S", "syn"), ("A", "ack"), ("F", "fin"), ("R", "rst"))
                if symbol in compact
            )
        else:
            normalized_flags = {str(value).casefold() for value in raw_flags}
        for flag in flag_counts:
            flag_counts[flag] += int(flag in normalized_flags)

    result: dict[str, float | int] = {
        "flow_duration_s": float(timestamps[-1] - timestamps[0]),
        "packet_count": len(materialized),
        "fwd_packet_count": sum(
            str(packet.get("direction", "fwd")).casefold() == "fwd"
            for packet in materialized
        ),
        "bwd_packet_count": sum(
            str(packet.get("direction", "fwd")).casefold() == "bwd"
            for packet in materialized
        ),
        "payload_packet_count": len(nonempty_payloads),
        "payload_total_bytes": int(sum(payload_lengths)),
        "tcp_syn_count": flag_counts["syn"],
        "tcp_ack_count": flag_counts["ack"],
        "tcp_fin_count": flag_counts["fin"],
        "tcp_rst_count": flag_counts["rst"],
    }
    result.update(_summary(iats, "packet_iat", unit_suffix="_s"))
    result.update(_summary(lengths, "packet_len"))
    result.update(_summary(payload_lengths, "payload_len"))
    result.update(_summary(payload_entropies, "payload_entropy"))
    return result


def _validate_no_raw_payload_columns(columns: Iterable[str]) -> None:
    unsafe = sorted(
        column
        for column in map(str, columns)
        if any(marker in column.casefold() for marker in _FORBIDDEN_PAYLOAD_COLUMN_MARKERS)
    )
    if unsafe:
        raise ExternalDevAdmissionError(
            f"raw payload persistence is forbidden; unsafe columns: {unsafe}"
        )


def _validate_provenance(frame: pd.DataFrame) -> None:
    missing = sorted(set(REQUIRED_PROVENANCE_COLUMNS) - set(frame.columns))
    if missing:
        raise ExternalDevAdmissionError(f"missing provenance columns: {missing}")
    for column in REQUIRED_PROVENANCE_COLUMNS:
        empty = frame[column].isna() | frame[column].astype(str).str.strip().eq("")
        if bool(empty.any()):
            rows = frame.index[empty].tolist()[:10]
            raise ExternalDevAdmissionError(
                f"provenance column {column!r} is empty at rows {rows}"
            )
    invalid_role = frame["role"].astype(str) != EXTERNAL_UNKNOWN_ROLE
    if bool(invalid_role.any()):
        values = sorted(set(frame.loc[invalid_role, "role"].astype(str)))
        raise ExternalDevAdmissionError(
            f"role must be {EXTERNAL_UNKNOWN_ROLE!r}; found {values}"
        )
    invalid_sha = ~frame["original_sha256"].astype(str).str.casefold().map(
        lambda value: bool(_SHA256_RE.fullmatch(value))
    )
    if bool(invalid_sha.any()):
        raise ExternalDevAdmissionError("original_sha256 must contain lowercase SHA-256 hex")
    invalid_url = ~frame["source_url"].astype(str).map(
        lambda value: urlparse(value).scheme in {"https", "http"}
        and bool(urlparse(value).netloc)
    )
    if bool(invalid_url.any()):
        raise ExternalDevAdmissionError("source_url must be an absolute HTTP(S) URL")


def _validated_row_hashes(frame: pd.DataFrame, name: str) -> pd.Series:
    if RAW_ROW_SHA256_COLUMN not in frame.columns:
        raise ExternalDevAdmissionError(
            f"{name} is missing {RAW_ROW_SHA256_COLUMN!r}; hash exact serialized raw rows before parsing"
        )
    values = frame[RAW_ROW_SHA256_COLUMN].astype(str).str.casefold()
    if not bool(values.map(lambda value: bool(_SHA256_RE.fullmatch(value))).all()):
        raise ExternalDevAdmissionError(f"{name} contains invalid raw-row SHA-256 values")
    return values


def _flow_identity(frame: pd.DataFrame) -> pd.Series | None:
    if {"capture_id", "flow_5tuple", "flow_start"}.issubset(frame.columns):
        columns = ("capture_id", "flow_5tuple", "flow_start")
    elif {
        "capture_id", "src_ip", "src_port", "dst_ip", "dst_port", "protocol", "flow_start"
    }.issubset(frame.columns):
        columns = (
            "capture_id", "src_ip", "src_port", "dst_ip", "dst_port", "protocol", "flow_start"
        )
    else:
        return None
    canonical = frame.loc[:, columns].apply(
        lambda row: json.dumps(
            [[column, _normalize_scalar(row[column])] for column in columns],
            ensure_ascii=False,
            separators=(",", ":"),
        ),
        axis=1,
    )
    return canonical.map(lambda value: hashlib.sha256(value.encode("utf-8")).hexdigest())


def _feature_group_presence(feature_columns: Sequence[str]) -> dict[str, tuple[str, ...]]:
    selected = set(map(str, feature_columns))
    return {
        group: tuple(column for column in columns if column in selected)
        for group, columns in EXTENDED_FEATURE_SCHEMA.items()
    }


def admit_external_unknown_dev(
    development: pd.DataFrame,
    frozen_test: pd.DataFrame,
    *,
    feature_columns: Sequence[str],
    overlap_feature_columns: Sequence[str] | None = None,
    require_all_extended_feature_groups: bool = True,
) -> tuple[pd.DataFrame, ExternalDevAdmissionReport]:
    """Validate and admit a zero-overlap external unknown-development cohort.

    Any missing provenance, duplicated exact development row, or overlap with
    the frozen test raises :class:`ExternalDevAdmissionError`.  The returned
    frame is a copy with deterministic audit fingerprints added; callers may
    use it for development only, never as a replacement for the frozen test.
    """

    if development.empty:
        raise ExternalDevAdmissionError("external unknown-development cohort is empty")
    if frozen_test.empty:
        raise ExternalDevAdmissionError("frozen test is empty; zero overlap cannot be proven")
    _validate_no_raw_payload_columns(development.columns)
    _validate_no_raw_payload_columns(frozen_test.columns)
    _validate_provenance(development)

    columns = tuple(str(column) for column in feature_columns)
    if not columns:
        raise ExternalDevAdmissionError("feature_columns must not be empty")
    missing_development_features = sorted(set(columns) - set(development.columns))
    if missing_development_features:
        raise ExternalDevAdmissionError(
            "development is missing declared feature columns: "
            f"{missing_development_features}"
        )
    groups = _feature_group_presence(columns)
    missing_groups = sorted(group for group, present in groups.items() if not present)
    if require_all_extended_feature_groups and missing_groups:
        raise ExternalDevAdmissionError(
            f"extended feature groups are missing from feature_columns: {missing_groups}"
        )

    # Validate every declared modelling feature even when zero-overlap can only
    # be checked on a smaller, semantically shared subset.  Without this pass a
    # caller could merely *name* a payload feature that is absent from the
    # development table and still satisfy the feature-group declaration.
    development_model_features = normalized_feature_fingerprints(
        development, columns
    )

    dev_raw = _validated_row_hashes(development, "development")
    frozen_raw = _validated_row_hashes(frozen_test, "frozen_test")
    duplicate_raw = int(dev_raw.duplicated(keep=False).sum())
    if duplicate_raw:
        raise ExternalDevAdmissionError(
            f"development contains {duplicate_raw} rows participating in exact raw-row duplicates"
        )

    overlap_columns = tuple(
        str(column)
        for column in (
            overlap_feature_columns if overlap_feature_columns is not None else columns
        )
    )
    if not overlap_columns:
        raise ExternalDevAdmissionError(
            "overlap_feature_columns must contain at least one shared feature"
        )
    dev_features = normalized_feature_fingerprints(development, overlap_columns)
    frozen_features = normalized_feature_fingerprints(frozen_test, overlap_columns)
    raw_overlap = set(dev_raw) & set(frozen_raw)
    feature_overlap = set(dev_features) & set(frozen_features)

    frozen_source_hashes = (
        set(frozen_test["original_sha256"].astype(str).str.casefold())
        if "original_sha256" in frozen_test.columns
        else set()
    )
    source_overlap = set(development["original_sha256"].astype(str).str.casefold()) & frozen_source_hashes

    if "capture_id" in frozen_test.columns:
        capture_overlap_value: int | None = len(
            set(development["capture_id"].astype(str))
            & set(frozen_test["capture_id"].astype(str))
        )
    else:
        capture_overlap_value = None

    dev_flow = _flow_identity(development)
    frozen_flow = _flow_identity(frozen_test)
    flow_overlap_value = (
        len(set(dev_flow) & set(frozen_flow))
        if dev_flow is not None and frozen_flow is not None
        else None
    )

    overlap_counts = {
        "raw_row": len(raw_overlap),
        "normalized_feature": len(feature_overlap),
        "source_file": len(source_overlap),
        "capture": capture_overlap_value or 0,
        "flow_identity": flow_overlap_value or 0,
    }
    if any(overlap_counts.values()):
        report = {
            "schema_version": "external-dev-admission-v2",
            "status": "rejected_overlap",
            "overlap_counts": overlap_counts,
        }
        raise ExternalDevAdmissionError(
            f"external unknown-development cohort overlaps frozen test: {overlap_counts}",
            report=report,
        )

    notes: list[str] = []
    if capture_overlap_value is None:
        notes.append("capture overlap unavailable because frozen test lacks capture_id")
    if flow_overlap_value is None:
        notes.append("5-tuple/timestamp overlap unavailable because one side lacks flow identity fields")

    admitted = development.copy()
    admitted["normalized_feature_sha256"] = development_model_features.to_numpy()
    if dev_flow is not None:
        admitted["flow_identity_sha256"] = dev_flow.to_numpy()

    report = ExternalDevAdmissionReport(
        schema_version="external-dev-admission-v2",
        status="admitted_external_unknown_dev",
        role=EXTERNAL_UNKNOWN_ROLE,
        development_rows=len(development),
        frozen_test_rows=len(frozen_test),
        feature_columns=columns,
        overlap_feature_columns=overlap_columns,
        feature_groups_present=groups,
        provenance_columns=REQUIRED_PROVENANCE_COLUMNS,
        raw_row_overlap_count=0,
        normalized_feature_overlap_count=0,
        source_file_overlap_count=0,
        capture_overlap_count=capture_overlap_value,
        flow_identity_overlap_count=flow_overlap_value,
        development_raw_row_sha256=_set_digest(dev_raw),
        development_model_feature_fingerprint_sha256=_set_digest(
            development_model_features
        ),
        # This and the frozen digest use the same overlap columns and are
        # therefore directly comparable.  The full development-model digest
        # above may include enriched columns unavailable in the frozen table.
        development_feature_fingerprint_sha256=_set_digest(dev_features),
        frozen_raw_row_sha256=_set_digest(frozen_raw),
        frozen_feature_fingerprint_sha256=_set_digest(frozen_features),
        no_raw_payload_persisted=True,
        notes=tuple(notes),
    )
    return admitted, report


def write_external_dev_audit(
    path: str | Path, report: ExternalDevAdmissionReport
) -> Path:
    """Write a deterministic JSON receipt after a successful admission."""

    if report.status != "admitted_external_unknown_dev":
        raise ExternalDevAdmissionError("only a successful admission report may be written")
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(report.to_dict(), ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return destination


__all__ = [
    "EXTERNAL_UNKNOWN_ROLE",
    "EXTENDED_FEATURE_SCHEMA",
    "REQUIRED_PROVENANCE_COLUMNS",
    "RAW_ROW_SHA256_COLUMN",
    "ExternalDevAdmissionError",
    "ExternalDevAdmissionReport",
    "admit_external_unknown_dev",
    "normalized_feature_fingerprints",
    "sha256_raw_row",
    "summarize_packet_flow",
    "write_external_dev_audit",
]
