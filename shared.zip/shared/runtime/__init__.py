"""Reproducible MHFD-DVC open-set experiments for the paper settings."""

from .config import SETTINGS, ExperimentSpec, get_spec

__all__ = ["SETTINGS", "ExperimentSpec", "get_spec"]
