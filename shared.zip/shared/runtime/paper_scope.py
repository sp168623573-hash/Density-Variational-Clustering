"""Check declared roles against this paper's versioned explicit family scope.

This roster is deliberately independent of config.py and the frozen 20260924
contract: those legacy artifacts omit NSL Setting1's snmpgetattack. BEN is
implicit and is not included in either attack-family list. This is a roster
check, not data admission, sample coverage, or permission to open final labels.
Partial independent unknown development remains a valid declared scope.

"Complete" means agreement with the explicit mapping adopted below, not a
claim that all external NSL-KDD taxonomies agree. The manuscript's Table 1
states R2L(all), U2R(all); it does not enumerate the 22 NSL Setting1 families.
The local pre-existing expansion in NSL-KDD Setting1/plot/PCA.py:38-46 has the
same 22-family set, including snmpgetattack. This version preserves that
interpretation and treats worm as DoS, outside the R2L/U2R union.

Corroborating category evidence: Balyan et al., Sensors 2022, 22(16), 5986,
Table 5, https://www.mdpi.com/1424-8220/22/16/5986 . Its table assigns worm to
DoS and snmpgetattack/httptunnel to R2L. That external table supports these
category decisions; it is not the sole source of the local 22-family union
(the local expansion also retains the train-present spy and warezclient).
"""
from __future__ import annotations

from collections import Counter
from typing import Any, Sequence


PAPER_SCOPE_VERSION = "paper-table1-complete-family-scope-20261007-v1"

# Table 1 lists the CIC roles and NSL Setting2 roles explicitly. NSL Setting1
# uses the adopted R2L(all)/U2R(all) expansion documented above, including
# snmpgetattack despite its absence from sampled CSVs/the frozen old contract.
_COMPLETE_ROLES = {
    "CIC Setting1": (
        ("FTP-Patator", "SSH-Patator", "DoS slowloris", "DoS Slowhttptest",
         "DDoS", "DoS Hulk", "DoS GoldenEye", "PortScan"),
        ("Infiltration", "Heartbleed", "Web Attack - XSS",
         "Web Attack - Sql Injection", "Web Attack - Brute Force", "Bot"),
    ),
    "CIC Setting2": (
        ("FTP-Patator", "SSH-Patator", "PortScan", "DDoS", "Heartbleed",
         "DoS Slowhttptest", "DoS Hulk", "Bot"),
        ("DoS GoldenEye", "Infiltration", "DoS slowloris", "Web Attack - XSS",
         "Web Attack - Brute Force", "Web Attack - Sql Injection"),
    ),
    "NSL-KDD Setting1": (
        ("back", "ipsweep", "neptune", "nmap", "portsweep", "satan", "smurf", "teardrop"),
        ("buffer_overflow", "loadmodule", "perl", "ps", "rootkit", "ftp_write",
         "guess_passwd", "httptunnel", "imap", "multihop", "named", "phf",
         "sendmail", "spy", "snmpgetattack", "snmpguess", "warezclient",
         "warezmaster", "xlock", "xsnoop", "sqlattack", "xterm"),
    ),
    "NSL-KDD Setting2": (
        ("httptunnel", "ipsweep", "neptune", "nmap", "portsweep", "smurf", "teardrop", "xsnoop"),
        ("back", "land", "pod", "satan", "ftp_write", "spy", "multihop",
         "phf", "imap", "warezmaster"),
    ),
}
PAPER_SCOPE_SETTINGS = tuple(_COMPLETE_ROLES)


def check_paper_scope(*, setting: str, known_families: Sequence[str],
                      unknown_families: Sequence[str]) -> dict[str, Any]:
    """Describe completeness against the adopted mapping without changing it.

The returned completeness flag is a necessary scope condition for full Table 1
final evaluation. It is neither necessary for partial unknown development nor
sufficient for final source independence or final-label authority.
"""
    if setting not in _COMPLETE_ROLES:
        raise ValueError("unsupported paper setting")
    declared = {"known": tuple(known_families), "unknown": tuple(unknown_families)}
    if any(not isinstance(value, str) or not value
           for families in declared.values() for value in families):
        raise ValueError("nonempty canonical family names required")
    expected = dict(zip(("known", "unknown"), _COMPLETE_ROLES[setting]))
    missing = {role: sorted(set(expected[role]) - set(declared[role])) for role in expected}
    unexpected = {role: sorted(set(declared[role]) - set(expected[role])) for role in expected}
    duplicates = {role: sorted(name for name, count in Counter(declared[role]).items() if count > 1)
                  for role in expected}
    complete = not any(missing.values()) and not any(unexpected.values()) and not any(duplicates.values())
    legacy21 = (setting == "NSL-KDD Setting1"
                and missing == {"known": [], "unknown": ["snmpgetattack"]}
                and not any(unexpected.values()) and not any(duplicates.values()))
    return {
        "paper_scope_version": PAPER_SCOPE_VERSION,
        "setting": setting,
        "declared_scope": ("complete_paper_table1" if complete else
                           "legacy_nsl1_21_unknown_development" if legacy21 else
                           "incomplete_or_mismatched_paper_scope"),
        "complete_paper_scope_verified": complete,
        "missing_paper_families": sorted(set().union(*missing.values())),
        "unexpected_paper_families": sorted(set().union(*unexpected.values())),
        "missing_paper_families_by_role": missing,
        "unexpected_paper_families_by_role": unexpected,
        "duplicate_declared_families_by_role": duplicates,
        "required_attack_family_counts": {role: len(families) for role, families in expected.items()},
        "declared_attack_family_counts": {role: len(families) for role, families in declared.items()},
        "BEN_is_implicit": True,
        "development_coverage_requirement_added": False,
        "source_admission_issued": False,
        "final_label_authority_issued": False,
    }
