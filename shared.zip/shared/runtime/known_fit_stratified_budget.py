"""Known-only hash cropping; evaluation rows and labels are never inputs."""

from __future__ import annotations

from collections import Counter
import hashlib
import math


def quotas(weights, available, minimum, total):
    names = sorted(available)
    if (set(weights) != set(names) or set(minimum) != set(names)
            or any(not math.isfinite(weights[k]) or weights[k] <= 0 for k in names)
            or any(type(available[k]) is not int or type(minimum[k]) is not int
                or not 1 <= minimum[k] <= available[k] for k in names)
            or type(total) is not int or not sum(minimum.values()) <= total <= sum(available.values())):
        raise ValueError("known-fit budget cannot meet real family/source minima")
    result, active, remaining = {}, names[:], total
    while active:
        mass = sum(weights[k] for k in active)
        values = {k: remaining * weights[k] / mass for k in active}
        low = [k for k in active if values[k] < minimum[k]]
        high = [k for k in active if values[k] > available[k]]
        fixed = low if low else high
        if fixed:
            for k in fixed:
                result[k] = minimum[k] if low else available[k]
                remaining -= result[k]
                active.remove(k)
            continue
        base = {k: int(math.floor(values[k])) for k in active}
        left = remaining - sum(base.values())
        order = sorted(active, key=lambda k: (-(values[k] - base[k]), k))
        for k in order[:left]:
            base[k] += 1
        result.update(base)
        break
    if sum(result.values()) != total or any(not minimum[k] <= result[k] <= available[k] for k in names):
        raise AssertionError("known-fit integer quotas do not conserve budget")
    return result


def crop_known_fit(frame, *, original_family_counts, seed, maximum_rows=512):
    if (type(seed) is not int or seed < 0 or type(maximum_rows) is not int
            or not 1 <= maximum_rows <= 6000 or set(frame["role"]) != {"BEN", "KNA"}
            or frame["sample_id"].duplicated().any() or frame["sample_id"].isna().any()):
        raise ValueError("known-fit crop requires unique known identities and an explicit budget")
    available = dict(Counter(frame["family"]))
    ben_families = set(frame.loc[frame["role"].eq("BEN"), "family"])
    if len(ben_families) != 1 or set(original_family_counts) != set(available):
        raise ValueError("known-fit crop cannot add/drop a family or mix BEN roles")
    minima = {name: 20 for name in available}
    ben = next(iter(ben_families))
    minima[ben] = max(20, 20 * frame.loc[frame["family"].eq(ben), "capture"].nunique())
    total = min(maximum_rows, len(frame))
    family_quota = quotas(original_family_counts, available, minima, total)
    selected, source_quotas = [], {}
    for family in sorted(available):
        rows = frame.loc[frame["family"].eq(family)]
        sources = dict(Counter(rows["capture"]))
        floors = {name: 20 if family == ben else 1 for name in sources}
        counts = quotas(sources, sources, floors, family_quota[family])
        source_quotas[family] = counts
        for capture in sorted(sources):
            indices = rows.index[rows["capture"].eq(capture)].tolist()
            order = sorted(indices, key=lambda i: hashlib.sha256(
                f"{seed}|{family}|{capture}|{frame.loc[i, 'sample_id']}".encode()).hexdigest())
            selected.extend(order[:counts[capture]])
    selected = sorted(selected)
    dropped = [i for i in frame.index if i not in set(selected)]
    cropped = frame.loc[selected].reset_index(drop=True)
    if len(cropped) != total or min(Counter(cropped["family"]).values()) < 20:
        raise AssertionError("known-fit crop lost a physical family support or exact quota")
    return cropped, {"maximum_fit_rows": maximum_rows, "available_fit_rows": len(frame),
        "selected_fit_rows": len(cropped), "family_quotas": family_quota, "source_quotas": source_quotas,
        "original_known_source_family_counts": original_family_counts,
        "selected_sample_ids": cropped["sample_id"].tolist(),
        "unselected_fit_sample_ids": frame.loc[dropped, "sample_id"].tolist(),
        "selection_uses_known_labels_sources_and_hash_only": True,
        "query_features_labels_or_scores_used": False, "resampling_creates_no_independent_support": True}
