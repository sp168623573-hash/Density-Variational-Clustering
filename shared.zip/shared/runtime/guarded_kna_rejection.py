"""Known-only integer-gated rejection budget for the Stage-1 KNA branch.

This is an opt-in development candidate. The calibration input must contain
BEN/KNA only; no unknown or final-test truth may be used to choose its cutoff.
"""

from __future__ import annotations

import hashlib
import json
import math
from typing import Any

import numpy as np


SCHEMA = "known-only-kna-rejection-integer-guard-v1"


def _array_digest(values: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(values).tobytes()).hexdigest()


def fit_known_only_kna_guard(
    known_truth: np.ndarray,
    stage1_prediction: np.ndarray,
    novelty_score: np.ndarray,
    sample_ids: np.ndarray,
) -> dict[str, Any]:
    """Set a strict novelty cutoff with at most the remaining 99% KNA budget."""

    truth = np.asarray(known_truth, dtype=np.int64)
    prediction = np.asarray(stage1_prediction, dtype=np.int64)
    scores = np.asarray(novelty_score, dtype=np.float64)
    ids = np.asarray(sample_ids, dtype=str)
    if (truth.ndim != 1 or prediction.shape != truth.shape
            or scores.shape != truth.shape or ids.shape != truth.shape
            or set(truth.tolist()) != {0, 1}
            or not set(prediction.tolist()) <= {0, 1}
            or len(set(ids.tolist())) != len(ids)
            or any(not item for item in ids.tolist())
            or not np.isfinite(scores).all()):
        raise ValueError("KNA guard requires unique, finite BEN/KNA-only calibration rows")
    support = int(np.sum(truth == 1))
    correct_mask = (truth == 1) & (prediction == 1)
    correct = int(np.sum(correct_mask))
    required = (99 * support + 99) // 100
    remaining_budget = correct - required
    admitted = remaining_budget >= 0
    threshold = None
    max_calibration_rejections = 0
    if admitted:
        correct_scores = np.sort(scores[correct_mask])[::-1]
        threshold = float(correct_scores[remaining_budget])
        max_calibration_rejections = int(np.sum(correct_scores > threshold))
        if max_calibration_rejections > remaining_budget:
            raise AssertionError("strict KNA threshold exceeds remaining integer budget")
    return {
        "schema_version": SCHEMA,
        "status": "ADMITTED_KNOWN_ONLY_CALIBRATION" if admitted
                  else "REJECTED_STAGE1_KNA_BELOW_99",
        "threshold": threshold,
        "strict_comparison": "novelty_score > threshold",
        "kna_stage1_correct": correct,
        "kna_support": support,
        "kna_required_for_99pct": required,
        "remaining_kna_error_budget": max(0, remaining_budget),
        "max_calibration_kna_rejections_by_score": max_calibration_rejections,
        "calibration_rows": len(truth),
        "calibration_ids_sha256": _array_digest(ids),
        "calibration_known_truth_sha256": _array_digest(truth),
        "calibration_stage1_prediction_sha256": _array_digest(prediction),
        "calibration_novelty_score_sha256": _array_digest(scores),
        "known_labels_used": True,
        "unknown_labels_used": False,
        "final_test_labels_used": False,
        "independent_final_claim_allowed": False,
        "published": False,
    }


def validate_kna_guard(guard: dict[str, Any]) -> float:
    if (guard.get("schema_version") != SCHEMA
            or guard.get("status") != "ADMITTED_KNOWN_ONLY_CALIBRATION"
            or guard.get("known_labels_used") is not True
            or guard.get("unknown_labels_used") is not False
            or guard.get("final_test_labels_used") is not False
            or guard.get("published") is not False):
        raise ValueError("KNA rejection policy lacks known-only provenance")
    threshold = guard.get("threshold")
    if not isinstance(threshold, (int, float)) or not math.isfinite(threshold):
        raise ValueError("KNA rejection threshold is not finite")
    support = guard.get("kna_support")
    required = guard.get("kna_required_for_99pct")
    correct = guard.get("kna_stage1_correct")
    budget = guard.get("remaining_kna_error_budget")
    maximum = guard.get("max_calibration_kna_rejections_by_score")
    if (not all(isinstance(item, int) for item in (support, required, correct, budget, maximum))
            or support < 1 or required != (99 * support + 99) // 100
            or correct < required or budget != correct - required
            or maximum > budget):
        raise ValueError("KNA guard integer budget contract differs")
    return float(threshold)


def guard_json(guard: dict[str, Any]) -> str:
    """Stable serialization for provenance tests and manifests."""

    return json.dumps(guard, sort_keys=True, separators=(",", ":"))
