"""Explicit known-class and full TARGET99 status for saved count reports.

Known-only reports cannot assert full TARGET99. The caller must supply
per-class paired losses separately; count increases do not prove loss-free
predictions. This helper does not mutate a frozen report or publish results.
"""
from numbers import Integral


def _count(value, name):
    if isinstance(value, bool) or not isinstance(value, Integral) or value < 0:
        raise ValueError(name + " must be a nonnegative integer")
    return int(value)


def gate_status(class_gates, paired_known_losses=None):
    evaluated = {}
    for name in ("BEN", "KNA", "UNA"):
        if name not in class_gates:
            continue
        node = class_gates[name]
        support = _count(node["support"], name + " support")
        correct = _count(node["correct"], name + " correct")
        if correct > support:
            raise ValueError(name + " correct exceeds support")
        required = (99 * support + 99) // 100
        for field in ("required", "required_correct"):
            if field in node and _count(node[field], name + " " + field) != required:
                raise ValueError(name + " required count contradicts exact integer gate")
        passed = support > 0 and correct >= required
        if "passed" in node and node["passed"] is not passed:
            raise ValueError(name + " saved passed flag contradicts counts")
        evaluated[name] = dict(correct=correct, support=support, required_correct=required, passed=passed)
    known_pass = all(name in evaluated and evaluated[name]["passed"] for name in ("BEN", "KNA"))
    all_three = all(name in evaluated and evaluated[name]["passed"] for name in ("BEN", "KNA", "UNA"))
    loss_free = None
    if paired_known_losses is not None:
        if not all(name in paired_known_losses for name in ("BEN", "KNA")):
            raise ValueError("paired BEN and KNA losses are both required")
        loss_free = all(_count(paired_known_losses[name], name + " paired loss") == 0 for name in ("BEN", "KNA"))
    return dict(class_gates=evaluated, known_integer_gates_passed=known_pass,
                paired_known_correct_loss_free=loss_free,
                all_three_integer99_passed=all_three,
                final_independence_or_publication_approved=False)
