"""Protect known density constraints on one reference rather than all seven."""
import copy
from dataclasses import dataclass
import numpy as np
from scipy.spatial.distance import cdist
from .known_ben_whitened_local_density_guards import (check,context_keys,
    raw_geometry,reference_density_and_jackknife)


def guards_for_constraints(reference_count,constraints):
    guards=np.ones(reference_count,dtype=np.float64)
    for values,neighbors in constraints:
        values=np.asarray(values,dtype=np.float64);neighbors=np.asarray(neighbors)
        if (values.ndim!=1 or neighbors.shape!=(len(values),7) or neighbors.dtype.kind not in 'iu'
                or np.any(neighbors<0) or np.any(neighbors>=reference_count)
                or not np.isfinite(values).all() or np.any(values<0)):
            raise ValueError('finite scores and seven physical reference indices required')
        # Stable nearest-distance order, never query ID, family or truth.
        np.maximum.at(guards,neighbors[:,0],values)
    guards+=64*np.finfo(np.float64).eps*np.maximum(1.,guards)
    for values,neighbors in constraints:
        if np.any(np.asarray(values)>np.max(guards[np.asarray(neighbors)],axis=1)):
            raise AssertionError('known protection constraint lost')
    return guards


@dataclass
class SparseProfile:
    feature_names:tuple
    columns:dict
    nodes:dict
    manifest:dict


def fit_profile(original,calibration,protected_BEN):
    check(original);x=np.asarray(calibration,dtype=np.float64);protected=np.asarray(protected_BEN)
    if (x.ndim!=2 or x.shape[1]!=len(original.feature_names) or not np.isfinite(x).all()
            or protected.shape!=(len(x),) or protected.dtype!=bool):raise ValueError('known calibration BEN mask required')
    keys=context_keys(x,original.feature_names);nodes=copy.deepcopy(original.nodes);audit=[]
    for key,groups in nodes.items():
        indices=np.asarray([i for i,k in enumerate(keys) if k==key and protected[i]],dtype=np.int64)
        if len(indices)<3:raise ValueError('original correct BEN calibration role lost')
        for view,group in groups.items():
            reference=group['reference'];n=len(reference)
            kth,density,loo=reference_density_and_jackknife(reference)
            np.testing.assert_array_equal(kth,group['k_distance']);np.testing.assert_array_equal(density,group['local_density'])
            distance=cdist(reference,reference)
            actual=np.argsort(distance,axis=1,kind='stable')[:,:7]
            selected=np.take_along_axis(distance,actual,axis=1)
            raw=density[actual].mean(axis=1)*np.maximum(np.maximum(selected,kth[actual]).mean(axis=1),1e-12)
            np.fill_diagonal(distance,np.inf)
            nonself=np.argsort(distance,axis=1,kind='stable')[:,:7]
            cal,cal_nearest=raw_geometry(group,x[indices][:,original.columns[view]])
            old=group['reference_cutoff'].copy()
            group['reference_cutoff']=guards_for_constraints(n,[(raw,actual),(loo,nonself),(cal,cal_nearest)])
            if np.any(group['reference_cutoff']>old+1e-12):raise AssertionError('sparse guard unexpectedly exceeds spread guard')
            audit.append(dict(context=list(key),view=view,references=n,correct_BEN_calibration_rows=len(indices),
                references_guard_reduced=int(np.sum(group['reference_cutoff']<old)),all_known_constraints_protected=True))
    return SparseProfile(original.feature_names,original.columns,nodes,dict(
        schema_version='known-only-sparse-reference-density-guards-v1',nodes=audit,
        recipe='one stable nearest reference receives each known fit/calibration or neighbor-jackknife score',
        all_known_fit_and_correct_BEN_calibration_constraints_protected=True,
        whitener_and_density_reference_reused_without_refit=True,unknown_or_query_truth_used=False,
        held_out_known_scores_used_for_guards=False,published=False,independent_final_admitted=False))


def evaluate(profile,features,stage1):
    x=np.asarray(features,dtype=np.float64);stage=np.asarray(stage1)
    if (x.ndim!=2 or x.shape[1]!=len(profile.feature_names) or not np.isfinite(x).all()
            or not 0<len(x)<=6000 or stage.shape!=(len(x),) or not np.isin(stage,(0,1)).all()):raise ValueError('capped full query features and Stage1 required')
    ratios=np.zeros((len(x),4));eligible=np.zeros(len(x),dtype=bool);keys=context_keys(x,profile.feature_names)
    for key,groups in profile.nodes.items():
        rows=np.asarray([i for i,k in enumerate(keys) if k==key],dtype=np.int64)
        if not len(rows):continue
        eligible[rows]=True
        for j,view in enumerate(profile.columns):
            raw,neighbors=raw_geometry(groups[view],x[rows][:,profile.columns[view]])
            ratios[rows,j]=raw/np.max(groups[view]['reference_cutoff'][neighbors],axis=1)
    content=ratios[:,tuple(profile.columns).index('content_login_activity')]
    score=np.maximum(content,np.sort(ratios,axis=1)[:,-2])
    return dict(score=score,raw_candidate=(stage==0)&eligible&(score>1),eligible=eligible,per_view_ratio=ratios)
