"""Fixed last-linear-weight GradNorm from genuine cached head inputs/logits.

This adds an unknown-candidate cue; it neither trains a classifier nor replaces
the paper's MHFD, owned distance, density affinity or secondary-noise stages.
T=1, C=9, weight-only L1 and negative direction are fixed before real scores.
No traffic assets, query labels, field choice, model calls or fit live here.
"""
import numpy as np
from scipy.special import softmax

SOURCE = 'https://proceedings.neurips.cc/paper/2021/file/063e26c670d07bb7c4d30e6fc69fe056-Paper.pdf'


def recipe():
    return dict(schema_version='actual-fine-linear-weight-GradNorm-C9-T1-L1-negative-v84',
        classes=9, temperature=1.0, selected_parameters='last fine-head weight only; bias excluded',
        loss='KL(uniform9 || softmax(actual_logits9)); same gradient as uniform cross entropy',
        gradnorm='L1(h) * L1(softmax(actual_logits9)-uniform9)',
        novelty='negative_gradnorm; larger is more novel; fixed a priori',
        clipping=False, epsilon=False, hyperparameter_scan=False,
        training=False, head_forward=False, backbone_forward=False, source=SOURCE)


def scores(head_input32, logits9):
    h, z = np.asarray(head_input32), np.asarray(logits9)
    if not (h.ndim == z.ndim == 2 and h.shape == (len(z), 32) and z.shape[1] == 9
            and len(z) > 0 and h.dtype.kind == z.dtype.kind == 'f'
            and np.isfinite(h).all() and np.isfinite(z).all()):
        raise ValueError('real finite head input32 and raw fine9 logits required')
    p = softmax(z.astype(np.float64), axis=1)
    feature_l1 = np.abs(h.astype(np.float64)).sum(axis=1)
    output_uniform_l1 = np.abs(p - 1.0 / 9.0).sum(axis=1)
    gradnorm = feature_l1 * output_uniform_l1
    novelty = -gradnorm
    if not (np.isfinite(novelty).all() and (gradnorm >= 0).all()):
        raise ValueError('finite nonnegative L1 norm without clipping required')
    return novelty, dict(gradnorm=gradnorm, feature_l1=feature_l1,
                        output_uniform_l1=output_uniform_l1, probability9=p)


def synthetic_contract():
    """Autograd checks use only fixed synthetic arrays, not real record values."""
    import torch
    generator = np.random.default_rng(84)
    h = generator.normal(size=(5, 32))
    W = generator.normal(size=(9, 32))
    b = generator.normal(size=9)
    logits = h @ W.T + b
    score, detail = scores(h, logits)
    measured = []
    for row in h:
        wt = torch.tensor(W, dtype=torch.float64, requires_grad=True)
        bt = torch.tensor(b, dtype=torch.float64, requires_grad=True)
        actual = wt @ torch.tensor(row, dtype=torch.float64) + bt
        loss = -torch.nn.functional.log_softmax(actual, dim=0).mean()
        gradient = torch.autograd.grad(loss, wt)[0]
        measured.append(float(gradient.abs().sum()))
    maximum = float(np.max(np.abs(np.asarray(measured) - detail['gradnorm'])))
    tolerance = 1e-11
    if maximum > tolerance:
        raise ValueError('closed last-weight formula differs from synthetic autograd')
    perm = np.array([4, 0, 2, 1, 3])
    other, _ = scores(h[perm], logits[perm])
    zero, _ = scores(h, np.zeros((5, 9)))
    if not (np.array_equal(other, score[perm]) and np.array_equal(zero, np.zeros(5))):
        raise ValueError('row permutation and exactly uniform output contracts')
    return dict(synthetic_rows=5, real_rows=0, actual_autograd_weight_gradient=True,
        autograd_vs_closed_formula_maxabs=maximum, synthetic_absolute_tolerance=tolerance,
        temperature=1.0, classes=9, weight_only=True, bias_gradient_not_used=True,
        row_permutation_exact=True, uniform_logits_exact_zero=True,
        trained_parameters=0, real_model_forward_calls=0)
