"""Actual MHFD weights + known-fit numeric preprocessing, never output caches.

This is a development Stage-1 checkpoint, not a saved full DVC router. For
NSL this boundary starts after categorical encoding/feature selection; it
does not establish raw NSL extraction parity. No pickle objects are loaded.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import zipfile

import numpy as np
from sklearn.preprocessing import StandardScaler
import torch

from .config import SETTINGS
from .data import sha256_file
from .model import MHFDNetwork, TrainResult, infer
from .reporting import write_json


TRANSFORMS = ('identity', 'signed_log1p')
RESERVED_COLUMNS = {'sample_id', 'family', 'role', 'label', 'true_class', 'attack_type', 'capture', 'fixed_csv_row_index'}
MAX_ARCHIVE_BYTES = 25 * 1024 * 1024


def _columns(columns):
    result = tuple(columns)
    if (not 0 < len(result) <= 512 or len(set(result)) != len(result)
            or any(not isinstance(c, str) or not c or c in RESERVED_COLUMNS for c in result)):
        raise ValueError('numeric checkpoint requires unique ordered non-identity feature columns')
    return result


def _ids(values):
    values = list(values)
    if not values or len(set(values)) != len(values) or any(not isinstance(x, str) or not x for x in values):
        raise ValueError('checkpoint roles require unique nonempty sample IDs')
    return hashlib.sha256('\n'.join(values).encode('utf-8')).hexdigest()


def _numeric(values, columns):
    block = np.asarray(values, dtype=np.float64)
    if block.ndim != 2 or block.shape[1] != len(columns) or not np.isfinite(block).all():
        raise ValueError('checkpoint input must be finite, ordered two-dimensional numeric features')
    return block


def _geometry(values, transform):
    if transform not in TRANSFORMS:
        raise ValueError('numeric transform was not predeclared')
    return values if transform == 'identity' else np.sign(values) * np.log1p(np.abs(values))


def state_hash(model):
    digest = hashlib.sha256()
    for name, value in sorted(model.state_dict().items()):
        array = np.ascontiguousarray(value.detach().cpu().numpy())
        digest.update(name.encode('utf-8'))
        digest.update(str(array.shape).encode('ascii'))
        digest.update(str(array.dtype).encode('ascii'))
        digest.update(array.tobytes())
    return digest.hexdigest()


@dataclass(frozen=True)
class NumericRecipe:
    feature_columns: tuple[str, ...]
    transform: str
    mean: np.ndarray
    scale: np.ndarray
    fit_rows: int
    fit_sample_ids_sha256: str

    def apply(self, values, *, feature_columns):
        if tuple(feature_columns) != self.feature_columns:
            raise ValueError('checkpoint feature order differs')
        numeric = _numeric(values, self.feature_columns)
        result = ((_geometry(numeric, self.transform) - self.mean) / self.scale).astype(np.float32)
        if not np.isfinite(result).all():
            raise ValueError('checkpoint preprocessing produced a nonfinite feature')
        return result


def fit_recipe(known_fit_values, *, feature_columns, transform, fit_ids):
    columns = _columns(feature_columns)
    numeric = _numeric(known_fit_values, columns)
    digest = _ids(fit_ids)
    if len(numeric) != len(fit_ids) or not 0 < len(numeric) <= 6000:
        raise ValueError('checkpoint known-fit role count differs or exceeds cohort cap')
    scaler = StandardScaler().fit(_geometry(numeric, transform))
    return NumericRecipe(columns, transform, scaler.mean_.copy(), scaler.scale_.copy(), len(numeric), digest)


def _family_order(setting, families):
    if setting not in SETTINGS:
        raise ValueError('checkpoint setting is not one of the four paper settings')
    spec = SETTINGS[setting]
    families = tuple(families)
    if (not 2 <= len(families) <= 64 or families[0] not in ('BEN', spec.benign_label)
            or len(set(families)) != len(families)
            or tuple(f for f in spec.known_families if f in families[1:]) != families[1:]):
        raise ValueError('checkpoint fine-family order exposes target UNA or differs from Table 1')
    return families


def save_checkpoint(*, manifest_path: Path, trained: TrainResult, recipe: NumericRecipe,
                    threshold: float, setting: str, fine_families, fit_ids, calibration_ids,
                    source_provenance: dict, feature_extractor_id: str):
    weights_path = manifest_path.with_suffix('.weights.npz')
    if manifest_path.exists() or weights_path.exists():
        raise FileExistsError('checkpoint manifest and actual weights must both be new')
    families = _family_order(setting, fine_families)
    if (_ids(fit_ids) != recipe.fit_sample_ids_sha256 or len(fit_ids) != recipe.fit_rows
            or set(fit_ids) & set(calibration_ids) or len(fit_ids) + len(calibration_ids) > 6000):
        raise ValueError('checkpoint known fit/calibration role identity overlaps or differs')
    _ids(calibration_ids)
    if (not isinstance(trained.model, MHFDNetwork)
            or [r.get('Epochs') for r in trained.history] != list(range(1, 101))
            or not 1 <= trained.selected_epoch <= 100
            or not np.isfinite(trained.training_seconds) or trained.training_seconds <= 0
            or not np.isfinite(threshold) or not 0 <= threshold <= 1
            or trained.model.feature_count != len(recipe.feature_columns)
            or trained.model.fine_head.out_features != len(families)
            or not isinstance(feature_extractor_id, str) or not feature_extractor_id
            or not source_provenance or any(k not in source_provenance for k in ('paper_pdf_sha256',))):
        raise ValueError('checkpoint needs actual complete 100-epoch known-only training and bound numeric schema')
    if (recipe.transform not in TRANSFORMS or recipe.mean.shape != (len(recipe.feature_columns),)
            or recipe.scale.shape != recipe.mean.shape or not np.isfinite(recipe.mean).all()
            or not np.isfinite(recipe.scale).all() or np.any(recipe.scale <= 0)):
        raise ValueError('checkpoint scaler is invalid')
    config = {'feature_count': trained.model.feature_count, 'fine_class_count': len(families),
              'token_dim': trained.model.feature_weight.shape[1],
              'attention_heads': trained.model.attention.num_heads,
              'conv_dim': trained.model.conv[0].out_channels,
              'embedding_dim': trained.model.coarse_head.in_features,
              'dropout': trained.model.dropout.p}
    if {k: config[k] for k in ('token_dim', 'attention_heads', 'conv_dim', 'embedding_dim', 'dropout')} != {
            'token_dim': 16, 'attention_heads': 4, 'conv_dim': 32, 'embedding_dim': 32, 'dropout': .15}:
        raise ValueError('checkpoint architecture differs from the predeclared MHFD defaults')
    arrays = {'scale::mean': recipe.mean.copy(), 'scale::scale': recipe.scale.copy()}
    arrays.update({'weight::' + name: value.detach().cpu().numpy().copy()
                   for name, value in trained.model.state_dict().items()})
    if any(a.dtype.hasobject or not np.isfinite(a).all() for a in arrays.values()):
        raise ValueError('checkpoint weights must be finite numeric tensors')
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    with weights_path.open('xb') as stream:
        np.savez_compressed(stream, **arrays)
    manifest = {'schema_version': 'mhfd-known-numeric-checkpoint-v1',
        'status': 'DEVELOPMENT_STAGE1_ACTUAL_WEIGHTS_NOT_FULL_ROUTER', 'setting': setting,
        'weights': {'file': weights_path.name, 'sha256': sha256_file(weights_path)},
        'architecture': config, 'state_sha256': state_hash(trained.model),
        'feature_columns': list(recipe.feature_columns), 'numeric_transform': recipe.transform,
        'feature_extractor_id': feature_extractor_id, 'input_stage': 'ordered_numeric_before_known_fit_StandardScaler',
        'fine_families': list(families), 'coarse_threshold': float(threshold),
        'fit_rows': recipe.fit_rows, 'fit_sample_ids_sha256': recipe.fit_sample_ids_sha256,
        'calibration_rows': len(calibration_ids), 'calibration_sample_ids_sha256': _ids(calibration_ids),
        'epochs_completed': 100, 'selected_epoch': trained.selected_epoch, 'training_seconds': trained.training_seconds,
        'source_provenance': source_provenance,
        'implementation_sha256': {n: sha256_file(Path(__file__).with_name(n)) for n in ('model.py', 'mhfd_numeric_checkpoint.py')},
        'preprocessing_fit_only_known_train': True, 'unknown_query_used_for_fit_or_selection': False,
        'query_output_arrays_stored_instead_of_weights': False, 'pickle_objects_loaded': False,
        'full_DVC_router_saved': False, 'raw_NSL_feature_extraction_parity_proved': False,
        'final_test_executed': False, 'independent_final_test_proved': False,
        'accepted_baseline_replaced': False, 'target99_status': 'FAIL_TARGET99', 'published': False}
    write_json(manifest_path, manifest)
    return {'path': str(manifest_path.resolve()), 'sha256': sha256_file(manifest_path)}


@dataclass
class LoadedNumericCheckpoint:
    model: MHFDNetwork
    recipe: NumericRecipe
    threshold: float
    manifest: dict

    def predict(self, values, *, feature_columns):
        block = self.recipe.apply(values, feature_columns=feature_columns)
        if not len(block):
            raise ValueError('checkpoint inference needs at least one row')
        output = infer(self.model, block, device=torch.device('cpu'))
        return (output.attack_probability >= self.threshold).astype(np.int64), output, block


def load_checkpoint(receipt):
    path = Path(receipt['path']).resolve(strict=True)
    if sha256_file(path) != receipt['sha256']:
        raise ValueError('checkpoint manifest hash changed')
    manifest = json.loads(path.read_text(encoding='utf-8'))
    if (manifest.get('schema_version') != 'mhfd-known-numeric-checkpoint-v1'
            or manifest.get('status') != 'DEVELOPMENT_STAGE1_ACTUAL_WEIGHTS_NOT_FULL_ROUTER'
            or manifest.get('epochs_completed') != 100 or manifest.get('published') is not False
            or manifest.get('unknown_query_used_for_fit_or_selection') is not False
            or manifest.get('preprocessing_fit_only_known_train') is not True
            or manifest.get('full_DVC_router_saved') is not False
            or set(manifest.get('implementation_sha256', {})) != {'model.py', 'mhfd_numeric_checkpoint.py'}):
        raise ValueError('checkpoint is not the declared known-only numeric Stage-1 artifact')
    for name, digest in manifest['implementation_sha256'].items():
        if sha256_file(Path(__file__).with_name(name)) != digest:
            raise ValueError('checkpoint implementation changed')
    columns = _columns(manifest['feature_columns'])
    families = _family_order(manifest['setting'], manifest['fine_families'])
    config = manifest['architecture']
    if (set(config) != {'feature_count', 'fine_class_count', 'token_dim', 'attention_heads', 'conv_dim', 'embedding_dim', 'dropout'}
            or config != {'feature_count': len(columns), 'fine_class_count': len(families),
                          'token_dim': 16, 'attention_heads': 4, 'conv_dim': 32, 'embedding_dim': 32, 'dropout': .15}
            or manifest['numeric_transform'] not in TRANSFORMS
            or not np.isfinite(manifest['coarse_threshold']) or not 0 <= manifest['coarse_threshold'] <= 1):
        raise ValueError('checkpoint architecture, preprocessing or threshold differs')
    file = manifest['weights']['file']
    if not isinstance(file, str) or Path(file).name != file or not file.endswith('.weights.npz'):
        raise ValueError('checkpoint weights must be a sibling numeric archive')
    weights = path.with_name(file).resolve(strict=True)
    if (weights.parent != path.parent or weights.stat().st_size > MAX_ARCHIVE_BYTES
            or sha256_file(weights) != manifest['weights']['sha256']):
        raise ValueError('checkpoint weights hash or sibling boundary changed')
    with zipfile.ZipFile(weights) as archive:
        info = archive.infolist()
        if (not 0 < len(info) <= 128 or len({i.filename for i in info}) != len(info)
                or sum(i.file_size for i in info) > MAX_ARCHIVE_BYTES):
            raise ValueError('checkpoint archive is duplicated or exceeds numeric tensor bounds')
    # Avoid changing the caller's future seeded training by model reconstruction.
    with torch.random.fork_rng(devices=[]):
        model = MHFDNetwork(**config)
    expected = model.state_dict()
    with np.load(weights, allow_pickle=False) as archive:
        if set(archive.files) != {'scale::mean', 'scale::scale', *('weight::' + k for k in expected)}:
            raise ValueError('checkpoint archive is an output cache or has unexpected tensors')
        state = {}
        for name, tensor in expected.items():
            value = archive['weight::' + name]
            if value.shape != tuple(tensor.shape) or value.dtype != tensor.numpy().dtype or not np.isfinite(value).all():
                raise ValueError('checkpoint tensor shape/dtype/finiteness differs')
            state[name] = torch.from_numpy(value.copy())
        mean, scale = archive['scale::mean'].copy(), archive['scale::scale'].copy()
    if (mean.shape != (len(columns),) or scale.shape != mean.shape or mean.dtype != np.float64
            or scale.dtype != np.float64 or not np.isfinite(mean).all() or not np.isfinite(scale).all() or np.any(scale <= 0)):
        raise ValueError('checkpoint scaler tensors are invalid')
    model.load_state_dict(state, strict=True)
    model.eval()
    if state_hash(model) != manifest['state_sha256']:
        raise ValueError('checkpoint reconstructed model state differs')
    recipe = NumericRecipe(columns, manifest['numeric_transform'], mean, scale,
                           manifest['fit_rows'], manifest['fit_sample_ids_sha256'])
    return LoadedNumericCheckpoint(model, recipe, manifest['coarse_threshold'], manifest)
