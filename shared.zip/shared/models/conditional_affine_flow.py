"""Pure fixed conditional affine flow; no data assets, fitting or thresholds.

For a fixed BEN/KNA condition each coupling is a bijection. All input columns
are preserved, including constant/discrete encoded coordinates. The bounded
logscale is an explicit model constraint, not a numerical score repair.
"""
from __future__ import annotations
import hashlib
import json
import math
import torch
from torch import nn
from torch.nn import functional as F

SCHEMA='known-coarse-conditional-six-affine-coupling-flow-v68'

def require(value,reason):
    if not value:raise ValueError(reason)

def model_recipe(input_dim):
    require(type(input_dim) is int and 2<=input_dim<=512,'declared complete feature dimension2..512')
    return dict(schema_version=SCHEMA,input_dim=input_dim,conditions=2,coupling_layers=6,
        mask='alternating fixed even/odd coordinate masks; every coordinate transformed three times',
        network='[masked fullD coordinates,BEN/KNA onehot2] -> Linear128 -> SiLU -> Linear128 -> SiLU -> Linear2D',
        output='firstD unconstrained rawscale, lastD translation; active coordinates only',
        logscale='2*tanh(rawscale/2), explicit fixedmodel bound[-2,2]; no feature pruning,jitter or score clipping',
        transform='active y=x*exp(logscale)+translation; masked conditioning coordinates unchanged',
        prior='complete standardNormalD, NLL=.5*sum(z^2+log(2pi))-sum_affine_logscales',
        initialization='every final coupling network linear weight/bias zero: exact identity initially',
        dropout=0,training_dtype='float32/noAMP; fixed30 final epoch planned by setting caller',
        density_training_measure='shuffle/permutation all original optimization indices once per epoch; no finebalanced sampler',
        query_condition='frozen knownclassifier predictedcoarse, never querytruth or truefine',
        typicality='caller truegenuineFITcoarse NLL mean/std; abs(NLL-mean)/std, exactzero std unit1',
        data_assets_in_core=False,training_helper_in_core=False,negative_NLL_clipped=False,
        published=False,final_test_executed=False)

def state_digest(net):
    value=hashlib.sha256()
    for key,tensor in sorted(net.state_dict().items()):
        array=tensor.detach().cpu().numpy()
        value.update(key.encode('utf8'));value.update(json.dumps(dict(shape=list(array.shape),dtype=array.dtype.str),sort_keys=True,separators=(',',':')).encode('utf8'));value.update(array.tobytes(order='C'))
    return value.hexdigest()

class AffineCoupling(nn.Module):
    def __init__(self,input_dim,parity):
        super().__init__();self.input_dim=input_dim
        self.register_buffer('mask',(torch.arange(input_dim)%2)==parity)
        self.network=nn.Sequential(nn.Linear(input_dim+2,128),nn.SiLU(),nn.Linear(128,128),nn.SiLU(),nn.Linear(128,2*input_dim))
        nn.init.zeros_(self.network[-1].weight);nn.init.zeros_(self.network[-1].bias)

    def parameters_for(self,x,coarse):
        mask=self.mask.to(dtype=x.dtype);active=1-mask
        inputs=torch.cat((x*mask,F.one_hot(coarse,num_classes=2).to(dtype=x.dtype)),dim=1)
        rawscale,translation=self.network(inputs).split(self.input_dim,dim=1)
        logscale=2.*torch.tanh(rawscale/2.)*active
        return mask,active,logscale,translation*active

    def forward(self,x,coarse):
        mask,active,logscale,translation=self.parameters_for(x,coarse)
        result=x*mask+active*(x*torch.exp(logscale)+translation)
        return result,logscale.sum(dim=1)

    def inverse(self,y,coarse):
        mask,active,logscale,translation=self.parameters_for(y,coarse)
        result=y*mask+active*((y-translation)*torch.exp(-logscale))
        return result,-logscale.sum(dim=1)

class ConditionalAffineFlow(nn.Module):
    def __init__(self,input_dim):
        super().__init__();model_recipe(input_dim);self.input_dim=input_dim
        self.couplings=nn.ModuleList([AffineCoupling(input_dim,layer%2) for layer in range(6)])

    def _contract(self,x,coarse):
        dtype=next(self.parameters()).dtype;device=next(self.parameters()).device
        require(isinstance(x,torch.Tensor) and x.ndim==2 and len(x)>0 and x.shape[1]==self.input_dim
            and x.dtype==dtype and dtype in (torch.float32,torch.float64) and x.device==device and bool(torch.isfinite(x).all()),'finite completeD features matching model float32 or syntheticfloat64 dtype/device')
        require(isinstance(coarse,torch.Tensor) and coarse.dtype==torch.int64 and coarse.shape==(len(x),)
            and coarse.device==x.device and bool(((coarse==0)|(coarse==1)).all()),'coarse int64[N] only0/1 on same device')

    def forward(self,features,coarse):
        self._contract(features,coarse);latent=features;logdet=torch.zeros(len(features),dtype=features.dtype,device=features.device)
        for coupling in self.couplings:
            latent,change=coupling(latent,coarse);logdet=logdet+change
        base_NLL=.5*(latent.square()+math.log(2.*math.pi)).sum(dim=1);NLL=base_NLL-logdet
        require(bool(torch.isfinite(latent).all()) and bool(torch.isfinite(logdet).all()) and bool(torch.isfinite(NLL).all()),'finite complete conditional affine density, no clipping')
        return dict(latent=latent,logdet=logdet,base_NLL=base_NLL,NLL=NLL,condition=coarse)

    def inverse(self,latent,coarse):
        self._contract(latent,coarse);features=latent;logdet=torch.zeros(len(latent),dtype=latent.dtype,device=latent.device)
        for coupling in reversed(self.couplings):
            features,change=coupling.inverse(features,coarse);logdet=logdet+change
        require(bool(torch.isfinite(features).all()) and bool(torch.isfinite(logdet).all()),'finite inverse bijection')
        return dict(features=features,inverse_logdet=logdet,condition=coarse)
