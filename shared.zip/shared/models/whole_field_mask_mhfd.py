"""Declared shared-MHFD whole-original-field masked prediction ablation.

The original model file is untouched. Clean inference calls its exact forward.
Masked inference uses the same attention/gate/position/CNN/BiLSTM, classifiers
and single decoder. A mask replaces every selected column of one original
field with an explicit learned token; the hidden values cannot reach encoding.

Only small synthetic tests have exercised this core. It supplies a training
loss and candidate score, never a final UNA decision or source admission.
"""
from __future__ import annotations

import copy
import hashlib
import json
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from .model import MHFDNetwork

SCHEMA = "shared-original-MHFD-whole-present-field-mask-v1"
FIELD_SCHEMA = "whole-original-selected-field-map-v1"
ROOT_FIELD_SCHEMA = "original-MHFD-selected107-known-only-field-map-v1"
SEED = 20261009
EPOCHS = 80
BATCH = 128
MAX_ROWS = 6000
FORBIDDEN_FIELDS = {"label", "labels", "truth", "family", "role", "sample_id", "flow_id",
                    "row_id", "source_id", "source_file", "difficulty", "attack_label"}


class WholeFieldMaskProtocolStop(ValueError):
    pass


def require(value: bool, reason: str) -> None:
    if not value:
        raise WholeFieldMaskProtocolStop(reason)


def digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def array_descriptor(value: Any) -> dict:
    value = np.asarray(value)
    require(not value.dtype.hasobject, "object_arrays_forbidden")
    return dict(shape=list(value.shape), dtype=value.dtype.str,
                sha256=hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest())


class FrozenFieldMap:
    def __init__(self, raw_json: bytes, *, expected_file_sha256: str):
        require(isinstance(raw_json, bytes) and len(expected_file_sha256) == 64
                and hashlib.sha256(raw_json).hexdigest() == expected_file_sha256,
                "externally_frozen_field_map_bytes_SHA_required")
        state = json.loads(raw_json)
        require(state["schema_version"] in (FIELD_SCHEMA, ROOT_FIELD_SCHEMA), "declared_field_map_schema_required")
        width, groups = state["selected_width"], state["groups"]
        require(type(width) is int and 1 < width <= 128 and 2 <= len(groups) <= width
                and state["nonempty_group_count"] == len(groups), "finite_nonempty_original_field_groups_required")
        mapping = state["selected_column_mapping"]
        require(len(mapping) == width and [v["selected_index"] for v in mapping] == list(range(width)),
                "all_selected_columns_exactly_ordered_and_mapped_required")
        names = [v["encoded_name"] for v in mapping]
        require(len(set(names)) == width and all(isinstance(n, str) and n for n in names),
                "unique_encoded_column_names_required")
        fields = [v["field"] for v in groups]
        require(len(set(fields)) == len(fields) and all(isinstance(n, str) and n
                and n.casefold() not in FORBIDDEN_FIELDS for n in fields), "feature_fields_only_not_labels_roles_IDs")
        membership = np.zeros((len(groups), width), bool)
        all_columns = []
        for index, group in enumerate(groups):
            columns, field, kind = group["selected_columns"], group["field"], group["kind"]
            require(kind in ("numeric", "categorical") and columns and columns == sorted(set(columns))
                    and all(type(c) is int and 0 <= c < width for c in columns), "declared_whole_field_columns_required")
            require(columns == [v["selected_index"] for v in mapping if v["original_field"] == field],
                    "entire_original_field_must_include_all_its_selected_columns")
            if kind == "numeric":
                require(len(columns) == 1 and names[columns[0]] == field, "one_actual_numeric_field_column_required")
            else:
                require(all(names[c].startswith(field + "_") for c in columns), "categorical_selected_columns_must_share_original_field")
                require(columns == [c for c, name in enumerate(names) if name.startswith(field + "_")],
                        "categorical_field_cannot_be_split_or_partially_hidden")
            membership[index, columns] = True; all_columns.extend(columns)
        require(sorted(all_columns) == list(range(width)), "field_groups_must_partition_every_selected_column_once")
        self.width, self.groups, self.names = width, tuple(copy.deepcopy(groups)), tuple(names)
        self.file_sha256, self._state = expected_file_sha256, copy.deepcopy(state)
        self._canonical = digest(state)
        self.membership = np.frombuffer(membership.tobytes(), dtype=bool).reshape(membership.shape)

    def check(self) -> None:
        require(digest(self._state) == self._canonical and self.groups == tuple(self._state["groups"]),
                "frozen_original_field_map_changed")

    @property
    def count(self) -> int:
        return len(self.groups)


def recipe() -> dict:
    return dict(schema_version=SCHEMA, seed=SEED, epochs=EPOCHS, batch_size=BATCH,
        CPU_threads=4, Adam_learning_rate=.001, Adam_weight_decay=1e-6, checkpoint="fixed final epoch",
        training_roles=["FIT"], training_coarse_classes=["BEN", "KNA"],
        loss="clean coarseCE +0.35clean fineCE(label_smoothing0.01) +0.03masked-only SmoothL1",
        masking="exactly one uniformly balanced original-field group per row; all its selected columns replaced",
        missing_token="learned original-field-specific token plus existing selected-column positions; no hidden feature value/bias",
        shared_gradient="attention/gate/position/CNN/BiLSTM/embedding/single decoder are updated by masked loss",
        target_units="unique original known-FIT per-numeric-column RMS; exactzero uses1; categorical columns scale1; frozen before training",
        masked_loss="per-row mean across ONLY masked field columns, then original-row mean; target detached",
        score="mean over ALL fixed field groups of per-field mean normalized squared context-prediction error",
        CAL="actual predicted coarse, finite ceil(99*(n+1)/100) rank; strict>; unsupported finite rank disables group",
        fieldmap_from_width_guessed=False, query_units_fit=False, unknown_training=False,
        mask_views_are_new_traffic=False, score_is_final_UNA=False,
        DVC_required="real same representation paper DVC/affinity/noise by caller",
        architecture_gradient_field_scope_joint_control=True, novel_theory_claim=False,
        status="FAIL_TARGET99", published=False, final_test_executed=False)


def _numpy_known(features, coarse, roles, field_map):
    field_map.check(); x, y = np.asarray(features), np.asarray(coarse)
    require(x.ndim == 2 and x.shape[1] == field_map.width and 0 < len(x) <= MAX_ROWS
            and x.dtype == np.float32 and np.isfinite(x).all(), "finite_original_known_float32_features_cap6000")
    require(y.shape == (len(x),) and y.dtype.kind in "iu" and set(np.unique(y).tolist()) == {0, 1},
            "whole_known_FIT_pool_requires_BEN0_KNA1_no_UNA2")
    require(tuple(roles) == ("FIT",) * len(x), "target_units_only_known_FIT_roles")
    return x, y


def target_units_prefit(features, coarse, *, roles, ids, group_ids, field_map):
    x, y = _numpy_known(features, coarse, roles, field_map)
    ids, groups = tuple(ids), tuple(group_ids)
    require(len(ids) == len(groups) == len(x) and len(set(ids)) == len(x)
            and all(isinstance(v, str) and v for v in (*ids, *groups)), "original_known_FIT_IDs_groups_required")
    members = {}
    for i, group in enumerate(groups): members.setdefault(group, []).append(i)
    representatives = [min(members[g], key=lambda i: ids[i]) for g in sorted(members)]
    result = dict(schema_version=SCHEMA + "-target-units-prefit", recipe=recipe(),
        field_map_file_sha256=field_map.file_sha256, features=array_descriptor(x), coarse=array_descriptor(y),
        roles=list(roles), ids=list(ids), group_ids=list(groups), original_rows=len(x),
        representative_indices=representatives, unique_original_FIT_groups=len(representatives))
    result["prefit_sha256"] = digest(result)
    return result


class KnownFITTargetUnits:
    def __init__(self, state):
        state = copy.deepcopy(state); expected = state.pop("state_sha256", None)
        require(expected == digest(state) and state["schema_version"] == SCHEMA + "-target-units"
                and state["recipe"] == recipe(), "frozen_known_FIT_target_unit_state_required")
        scale = np.asarray(state["scale"], np.float64)
        require(scale.ndim == 1 and np.isfinite(scale).all() and np.all(scale > 0), "finite_positive_frozen_target_units")
        self.scale = np.frombuffer(scale.tobytes(), dtype=np.float64)
        self.state_sha256, self._state = expected, state

    def check(self, field_map):
        field_map.check()
        require(digest(self._state) == self.state_sha256 and self._state["field_map_file_sha256"] == field_map.file_sha256
                and self.scale.shape == (field_map.width,) and np.array_equal(self.scale, self._state["scale"]),
                "same_frozen_field_map_and_known_target_units_required")

    def to_state(self):
        require(digest(self._state) == self.state_sha256, "target_unit_state_changed")
        return dict(copy.deepcopy(self._state), state_sha256=self.state_sha256)


def fit_target_units(features, coarse, *, roles, ids, group_ids, field_map, expected_prefit_sha256):
    plan = target_units_prefit(features, coarse, roles=roles, ids=ids, group_ids=group_ids, field_map=field_map)
    require(plan["prefit_sha256"] == expected_prefit_sha256, "externally_frozen_target_units_prefit_required")
    x = np.asarray(features)[plan["representative_indices"]].astype(np.float64)
    scale = np.ones(field_map.width, np.float64); exactzero = []
    for group in field_map.groups:
        if group["kind"] == "numeric":
            column = group["selected_columns"][0]; largest = float(np.max(np.abs(x[:, column])))
            if largest > 0:
                scale[column] = largest * float(np.sqrt(np.mean((x[:, column] / largest) ** 2)))
            else: exactzero.append(column)
    state = dict(schema_version=SCHEMA + "-target-units", recipe=recipe(),
        field_map_file_sha256=field_map.file_sha256, prefit=plan, scale=scale.tolist(),
        exactzero_numeric_columns=exactzero, training_roles=["FIT"], query_fit=False,
        status="FAIL_TARGET99", published=False, final_test_executed=False)
    state["state_sha256"] = digest(state)
    return KnownFITTargetUnits(state)


def _features(features, width):
    require(isinstance(features, torch.Tensor) and features.dtype == torch.float32
            and features.ndim == 2 and features.shape[1] == width and 0 < len(features) <= MAX_ROWS
            and bool(torch.isfinite(features).all()), "finite_float32_feature_tensor_only_cap6000")


class WholeFieldMaskedMHFD(MHFDNetwork):
    def __init__(self, field_map: FrozenFieldMap, fine_class_count: int, **architecture):
        require(isinstance(field_map, FrozenFieldMap) and type(fine_class_count) is int and fine_class_count >= 2,
                "externally_frozen_real_field_map_and_known_fine_count_required")
        field_map.check()
        super().__init__(field_map.width, fine_class_count, **architecture)
        self.field_map = field_map
        self.field_mask_tokens = nn.Parameter(torch.empty(field_map.count, self.feature_weight.shape[1]))
        nn.init.normal_(self.field_mask_tokens, std=.02)
        self.register_buffer("field_column_membership", torch.from_numpy(field_map.membership.copy()))

    def _map_check(self):
        self.field_map.check()
        require(torch.equal(self.field_column_membership.cpu(), torch.from_numpy(self.field_map.membership.copy())),
                "frozen_whole_field_membership_changed")

    def forward(self, features):
        _features(features, self.feature_count); self._map_check()
        return super().forward(features)

    def masked_columns(self, fields, rows, device):
        self._map_check()
        require(isinstance(fields, torch.Tensor) and fields.dtype == torch.int64 and fields.shape == (rows,)
                and bool(((fields >= 0) & (fields < self.field_map.count)).all()), "exactly_one_valid_original_field_mask_per_row")
        return self.field_column_membership.to(device)[fields.to(device)]

    def masked_tokens(self, features, fields):
        _features(features, self.feature_count)
        hidden = self.masked_columns(fields, len(features), features.device)
        visible = torch.where(hidden, torch.zeros_like(features), features)
        tokens = visible.unsqueeze(-1) * self.feature_weight.unsqueeze(0) + self.feature_bias.unsqueeze(0) + self.position.unsqueeze(0)
        missing = self.field_mask_tokens[fields.to(features.device)].unsqueeze(1) + self.position.unsqueeze(0)
        return torch.where(hidden.unsqueeze(-1), missing, tokens), hidden

    def forward_masked(self, features, fields):
        tokens, hidden = self.masked_tokens(features, fields)
        attended, _ = self.attention(tokens, tokens, tokens, need_weights=False)
        gate = self.gate(attended)
        tokens = self.attention_norm(tokens + self.dropout(attended) * gate)
        convolved = self.conv(tokens.transpose(1, 2)).transpose(1, 2)
        sequence, _ = self.sequence(convolved)
        pool_weights = torch.softmax(self.pool_score(sequence).squeeze(-1), dim=1)
        embedding = self.embedding(torch.sum(sequence * pool_weights.unsqueeze(-1), dim=1))
        return dict(coarse_logits=self.coarse_head(embedding), fine_logits=self.fine_head(embedding),
            embedding=embedding, reconstruction=self.decoder(embedding), gate_mean=gate.mean(dim=(1, 2)),
            masked_columns=hidden)


def balanced_field_schedule(rows: int, field_count: int, *, epoch: int) -> np.ndarray:
    require(type(rows) is int and 0 < rows <= MAX_ROWS and type(field_count) is int and field_count >= 2
            and type(epoch) is int and 0 <= epoch < EPOCHS, "fixed80epoch_original_rows_uniform_mask_schedule")
    rng = np.random.default_rng(np.random.SeedSequence([SEED, epoch]))
    names = rng.permutation(field_count)
    return names[np.arange(rows) % field_count][rng.permutation(rows)].astype(np.int64)


def masked_reconstruction_loss(prediction, target, hidden, scale):
    require(prediction.shape == target.shape == hidden.shape and hidden.dtype == torch.bool
            and bool(hidden.any(dim=1).all()), "masked_only_aligned_decoder_targets_required")
    error = (prediction.to(torch.float64) - target.detach().to(torch.float64)) / scale
    errors = F.smooth_l1_loss(error, torch.zeros_like(error), reduction="none")
    return ((errors * hidden).sum(dim=1) / hidden.sum(dim=1)).mean()


def known_training_objective(model, features, coarse, fine, *, roles, masked_fields, target_units):
    require(isinstance(model, WholeFieldMaskedMHFD), "shared_whole_field_MHFD_required")
    _features(features, model.feature_count); target_units.check(model.field_map)
    require(tuple(roles) == ("FIT",) * len(features), "optimization_only_known_FIT_roles_no_DEV_CAL_query")
    require(isinstance(coarse, torch.Tensor) and isinstance(fine, torch.Tensor)
            and coarse.dtype == fine.dtype == torch.int64 and coarse.shape == fine.shape == (len(features),)
            and bool(((coarse == 0) | (coarse == 1)).all()) and bool(((fine >= 0) & (fine < model.fine_head.out_features)).all())
            and torch.equal(coarse == 0, fine == 0), "known_BEN0_KNA1_and_known_fine_targets_only_no_UNA")
    clean = model(features)
    masked = model.forward_masked(features, masked_fields)
    scale = torch.tensor(target_units.scale.copy(), dtype=torch.float64, device=features.device)
    masked_loss = masked_reconstruction_loss(masked["reconstruction"], features, masked["masked_columns"], scale)
    coarse_loss = F.cross_entropy(clean["coarse_logits"], coarse)
    fine_loss = F.cross_entropy(clean["fine_logits"], fine, label_smoothing=.01)
    loss = coarse_loss + .35 * fine_loss + .03 * masked_loss
    require(bool(torch.isfinite(loss)), "finite_shared_known_classification_and_masked_loss")
    return dict(loss=loss, coarse_loss=coarse_loss, fine_loss=fine_loss, masked_loss=masked_loss)


def model_state_sha256(model):
    h = hashlib.sha256()
    for name, value in sorted(model.state_dict().items()):
        array = value.detach().cpu().contiguous().numpy()
        h.update(name.encode()); h.update(array.dtype.str.encode()); h.update(repr(array.shape).encode()); h.update(array.tobytes())
    return h.hexdigest()


def score_all_fields(model, features, target_units, *, expected_model_state_sha256, batch_size=BATCH):
    require(isinstance(model, WholeFieldMaskedMHFD) and model.training is False,
            "frozen_eval_shared_MHFD_required_for_candidate_scoring")
    _features(features, model.feature_count); target_units.check(model.field_map)
    require(batch_size == BATCH and model_state_sha256(model) == expected_model_state_sha256,
            "fixed128_batch_and_externally_frozen_model_state_required")
    result = np.empty((len(features), model.field_map.count), np.float64)
    scale = torch.tensor(target_units.scale.copy(), dtype=torch.float64, device=features.device)
    with torch.no_grad():
        for field in range(model.field_map.count):
            columns = model.field_map.groups[field]["selected_columns"]
            for start in range(0, len(features), BATCH):
                batch = features[start:start + BATCH]
                fields = torch.full((len(batch),), field, dtype=torch.int64, device=batch.device)
                actual = model.forward_masked(batch, fields)["reconstruction"].to(torch.float64)
                squared = ((actual - batch.to(torch.float64)) / scale) ** 2
                result[start:start + len(batch), field] = squared[:, columns].mean(dim=1).cpu().numpy()
    require(np.isfinite(result).all() and model_state_sha256(model) == expected_model_state_sha256,
            "finite_all_field_score_and_unchanged_frozen_model")
    return dict(per_field_error=result, score=result.mean(axis=1), final_UNA_provided=False,
                field_map_file_sha256=model.field_map.file_sha256, query_units_fit=False)


def calibrate_known_CAL(scores, predicted_coarse, *, roles):
    s, c = np.asarray(scores), np.asarray(predicted_coarse)
    require(s.ndim == 1 and 0 < len(s) <= MAX_ROWS and np.isfinite(s).all() and np.all(s >= 0)
            and c.shape == s.shape and c.dtype.kind in "iu" and np.isin(c, (0, 1)).all()
            and tuple(roles) == ("CAL",) * len(s), "known_CAL_scores_and_actual_predicted_coarse_no_truth_required")
    rules = {}
    for label in (0, 1):
        values = np.sort(s[c == label]); n = len(values); rank = (99 * (n + 1) + 99) // 100
        enabled = bool(n and rank <= n)
        rules[str(label)] = dict(support=n, rank_one_based=rank, enabled=enabled,
            cutoff=float(values[rank - 1]) if enabled else None, strict_greater=True)
    state = dict(schema_version=SCHEMA + "-CAL-rank", rules=rules,
        source_scores=array_descriptor(s), predicted_coarse=array_descriptor(c),
        true_labels_or_families_used=False, score_is_final_UNA=False,
        status="FAIL_TARGET99", published=False, final_test_executed=False)
    state["calibration_sha256"] = digest(state)
    return state


def candidate_mask(scores, predicted_coarse, calibration):
    s, c = np.asarray(scores), np.asarray(predicted_coarse)
    unsigned = dict(calibration); signature = unsigned.pop("calibration_sha256", None)
    require(signature == digest(unsigned), "externally_frozen_CAL_state_digest_required")
    require(s.ndim == 1 and 0 < len(s) <= MAX_ROWS and c.shape == s.shape and c.dtype.kind in "iu" and np.isfinite(s).all()
            and np.all(s >= 0)
            and np.isin(c, (0, 1)).all() and calibration["schema_version"] == SCHEMA + "-CAL-rank",
            "finite_score_and_actual_coarse_with_frozen_CAL_rule_required")
    mask = np.zeros(len(s), bool)
    for label in (0, 1):
        rule = calibration["rules"][str(label)]
        n = rule["support"]; rank = (99 * (n + 1) + 99) // 100; enabled = bool(n and rank <= n)
        require(type(n) is int and n >= 0 and rule["rank_one_based"] == rank
                and rule["strict_greater"] is True and rule["enabled"] is enabled
                and ((enabled and rule["cutoff"] is not None and np.isfinite(rule["cutoff"]) and rule["cutoff"] >= 0)
                     or (not enabled and rule["cutoff"] is None)), "unchanged_exact99_CAL_rank")
        if rule["enabled"]: mask[c == label] = s[c == label] > rule["cutoff"]
    return mask
