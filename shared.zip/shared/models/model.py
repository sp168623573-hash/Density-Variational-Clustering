from __future__ import annotations

import copy
import math
import random
import time
from dataclasses import dataclass
from typing import Any

import numpy as np
import torch
from sklearn.metrics import precision_recall_fscore_support
from torch import nn
from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler


CSV_COLUMNS: tuple[str, ...] = (
    "Epochs",
    "Ours Model_Train-Accuracy",
    "Ours Model_Validation-Accuracy",
    "Ours Model_Train_Precision",
    "Ours Model_Validation_Precision",
    "Ours Model_Train_Recall",
    "Ours Model_Validation_Recall",
    "Ours Model_Train_F1",
    "Ours Model_Validation_F1",
    "Ours Model_Train_FPR",
    "Ours Model_Validation_FPR",
    "Ours Model_Train_BEN_Recall",
    "Ours Model_Train_KNA_Recall",
    "Ours Model_Validation_BEN_Recall",
    "Ours Model_Validation_KNA_Recall",
    "LOFO_Proxy_UNA_Candidate_Recall",
    "LOFO_Proxy_UNA_Support",
    "Ours Model_Train_Loss",
    "Learning_Rate",
    "SWA_Active",
)


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.use_deterministic_algorithms(True, warn_only=True)


class MHFDNetwork(nn.Module):
    """Paper-aligned feature-token attention, gating, CNN, and BiLSTM encoder."""

    def __init__(
        self,
        feature_count: int,
        fine_class_count: int,
        *,
        token_dim: int = 16,
        attention_heads: int = 4,
        conv_dim: int = 32,
        embedding_dim: int = 32,
        dropout: float = 0.15,
    ) -> None:
        super().__init__()
        if token_dim % attention_heads:
            raise ValueError("token_dim must be divisible by attention_heads")
        self.feature_count = feature_count
        self.feature_weight = nn.Parameter(torch.empty(feature_count, token_dim))
        self.feature_bias = nn.Parameter(torch.zeros(feature_count, token_dim))
        self.position = nn.Parameter(torch.empty(feature_count, token_dim))
        nn.init.xavier_uniform_(self.feature_weight)
        nn.init.normal_(self.position, std=0.02)

        self.attention = nn.MultiheadAttention(
            token_dim,
            attention_heads,
            dropout=dropout,
            batch_first=True,
        )
        self.gate = nn.Sequential(nn.Linear(token_dim, token_dim), nn.Sigmoid())
        self.attention_norm = nn.LayerNorm(token_dim)
        self.dropout = nn.Dropout(dropout)
        self.conv = nn.Sequential(
            nn.Conv1d(token_dim, conv_dim, kernel_size=3, padding=1),
            nn.GELU(),
            nn.BatchNorm1d(conv_dim),
            nn.Dropout(dropout),
        )
        self.sequence = nn.LSTM(
            input_size=conv_dim,
            hidden_size=conv_dim // 2,
            batch_first=True,
            bidirectional=True,
        )
        self.pool_score = nn.Linear(conv_dim, 1)
        self.embedding = nn.Sequential(
            nn.Linear(conv_dim, 64),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(64, embedding_dim),
        )
        self.coarse_head = nn.Linear(embedding_dim, 2)
        self.fine_head = nn.Linear(embedding_dim, fine_class_count)
        self.decoder = nn.Sequential(
            nn.Linear(embedding_dim, 64),
            nn.GELU(),
            nn.Linear(64, feature_count),
        )

    def forward(self, features: torch.Tensor) -> dict[str, torch.Tensor]:
        tokens = (
            features.unsqueeze(-1) * self.feature_weight.unsqueeze(0)
            + self.feature_bias.unsqueeze(0)
            + self.position.unsqueeze(0)
        )
        attended, _ = self.attention(tokens, tokens, tokens, need_weights=False)
        gate = self.gate(attended)
        tokens = self.attention_norm(tokens + self.dropout(attended) * gate)
        convolved = self.conv(tokens.transpose(1, 2)).transpose(1, 2)
        sequence, _ = self.sequence(convolved)
        pool_weights = torch.softmax(self.pool_score(sequence).squeeze(-1), dim=1)
        pooled = torch.sum(sequence * pool_weights.unsqueeze(-1), dim=1)
        embedding = self.embedding(pooled)
        return {
            "coarse_logits": self.coarse_head(embedding),
            "fine_logits": self.fine_head(embedding),
            "embedding": embedding,
            "reconstruction": self.decoder(embedding),
            "gate_mean": gate.mean(dim=(1, 2)),
        }


@dataclass
class InferenceOutput:
    attack_probability: np.ndarray
    fine_probability: np.ndarray
    embedding: np.ndarray
    reconstruction_error: np.ndarray
    gate_mean: np.ndarray
    coarse_attack_probability: np.ndarray | None = None
    fine_attack_probability: np.ndarray | None = None


@dataclass
class TrainResult:
    model: MHFDNetwork
    device: str
    history: list[dict[str, Any]]
    selected_epoch: int
    selected_score: dict[str, float]
    training_seconds: float


def _metric_values(y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    accuracy = float(np.mean(y_true == y_pred))
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_true,
        y_pred,
        labels=[0, 1],
        average="weighted",
        zero_division=0,
    )
    ben_support = max(1, int(np.sum(y_true == 0)))
    kna_support = max(1, int(np.sum(y_true == 1)))
    ben_recall = float(np.sum((y_true == 0) & (y_pred == 0)) / ben_support)
    kna_recall = float(np.sum((y_true == 1) & (y_pred == 1)) / kna_support)
    return {
        "accuracy": accuracy,
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "fpr": 1.0 - ben_recall,
        "ben_recall": ben_recall,
        "kna_recall": kna_recall,
    }


def known_fine_checkpoint_metrics(
    labels: np.ndarray, probabilities: np.ndarray,
) -> dict[str, float]:
    """Evaluate only declared known families for checkpoint tie-breaking."""
    truth = np.asarray(labels)
    values = np.asarray(probabilities, dtype=np.float64)
    if (truth.ndim != 1 or not len(truth)
            or not np.issubdtype(truth.dtype, np.integer)
            or values.ndim != 2 or len(values) != len(truth)
            or values.shape[1] < 2 or not np.isfinite(values).all()
            or np.any(values < 0) or np.any(values > 1)
            or not np.allclose(values.sum(axis=1), 1.0, atol=2e-3)
            or np.any(truth < 0) or np.any(truth >= values.shape[1])):
        raise ValueError("fine checkpoint requires declared known-family probabilities")
    prediction = np.argmax(values, axis=1)
    recalls = [float(np.mean(prediction[truth == family] == family))
               for family in np.unique(truth)]
    row_nll = -np.log(np.maximum(values[np.arange(len(truth)), truth], 1e-12))
    return {
        "fine_accuracy": float(np.mean(prediction == truth)),
        "fine_min_recall": min(recalls),
        "fine_macro_recall": float(np.mean(recalls)),
        "fine_macro_nll": float(np.mean([
            np.mean(row_nll[truth == family]) for family in np.unique(truth)])),
    }


def known_checkpoint_selection_key(
    coarse: dict[str, float], fine: dict[str, float] | None = None,
) -> tuple[float, ...]:
    """Preserve coarse BEN/KNA priority, then compare known-family learning."""
    primary = (min(coarse["ben_recall"], coarse["kna_recall"]),
               coarse["accuracy"], coarse["f1"])
    if fine is None:
        return primary
    return (*primary, fine["fine_min_recall"], fine["fine_macro_recall"],
            fine["fine_accuracy"], -fine["fine_macro_nll"])


def _attack_probability(
    coarse_logits: torch.Tensor, fine_logits: torch.Tensor
) -> torch.Tensor:
    coarse_attack = torch.softmax(coarse_logits, dim=1)[:, 1]
    fine_attack = 1.0 - torch.softmax(fine_logits, dim=1)[:, 0]
    return 0.55 * coarse_attack + 0.45 * fine_attack


@torch.no_grad()
def infer(
    model: MHFDNetwork,
    features: np.ndarray,
    *,
    device: torch.device,
    batch_size: int = 2048,
) -> InferenceOutput:
    model.eval()
    loader = DataLoader(
        TensorDataset(torch.from_numpy(features.astype(np.float32, copy=False))),
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
    )
    attack_probability: list[np.ndarray] = []
    coarse_attack_probability: list[np.ndarray] = []
    fine_attack_probability: list[np.ndarray] = []
    fine_probability: list[np.ndarray] = []
    embeddings: list[np.ndarray] = []
    reconstruction_error: list[np.ndarray] = []
    gate_mean: list[np.ndarray] = []
    amp_enabled = device.type == "cuda"
    for (batch,) in loader:
        batch = batch.to(device, non_blocking=True)
        with torch.autocast(
            device_type=device.type,
            dtype=torch.float16,
            enabled=amp_enabled,
        ):
            output = model(batch)
        attack_probability.append(
            _attack_probability(output["coarse_logits"], output["fine_logits"])
            .float()
            .cpu()
            .numpy()
        )
        coarse_attack_probability.append(
            torch.softmax(output["coarse_logits"], dim=1)[:, 1]
            .float().cpu().numpy()
        )
        fine_attack_probability.append(
            (1.0 - torch.softmax(output["fine_logits"], dim=1)[:, 0])
            .float().cpu().numpy()
        )
        fine_probability.append(
            torch.softmax(output["fine_logits"], dim=1).float().cpu().numpy()
        )
        embeddings.append(output["embedding"].float().cpu().numpy())
        reconstruction_error.append(
            torch.mean((output["reconstruction"].float() - batch.float()) ** 2, dim=1)
            .cpu()
            .numpy()
        )
        gate_mean.append(output["gate_mean"].float().cpu().numpy())
    return InferenceOutput(
        attack_probability=np.concatenate(attack_probability),
        fine_probability=np.concatenate(fine_probability),
        embedding=np.concatenate(embeddings),
        reconstruction_error=np.concatenate(reconstruction_error),
        gate_mean=np.concatenate(gate_mean),
        coarse_attack_probability=np.concatenate(coarse_attack_probability),
        fine_attack_probability=np.concatenate(fine_attack_probability),
    )


def _hierarchical_sample_weights(y_fine: np.ndarray) -> torch.Tensor:
    classes, counts = np.unique(y_fine, return_counts=True)
    count_by_class = dict(zip(classes.tolist(), counts.tolist(), strict=True))
    attack_classes = [value for value in classes.tolist() if value != 0]
    weights = np.zeros(len(y_fine), dtype=np.float64)
    for index, value in enumerate(y_fine.tolist()):
        if value == 0:
            weights[index] = 0.5 / count_by_class[value]
        else:
            weights[index] = 0.5 / (len(attack_classes) * count_by_class[value])
    weights /= weights.sum()
    return torch.as_tensor(weights, dtype=torch.double)


def _hierarchical_source_weights(
    y_fine: np.ndarray, source_groups: np.ndarray,
) -> torch.Tensor:
    """Keep the paper's fine-family mass, but balance capture sources within it.

    Resampling changes optimization frequency only; it does not create new
    physical flows or count duplicates as independent validation support.
    """
    if (y_fine.ndim != 1 or source_groups.ndim != 1
            or len(y_fine) != len(source_groups) or len(y_fine) == 0):
        raise ValueError("source groups must align one-to-one with fit rows")
    if any(not isinstance(value, str) or not value
           for value in source_groups.tolist()):
        raise ValueError("every fit row requires a nonempty capture source")
    family_mass = _hierarchical_sample_weights(y_fine).numpy()
    weights = np.zeros(len(y_fine), dtype=np.float64)
    for family in np.unique(y_fine):
        family_indices = np.flatnonzero(y_fine == family)
        family_sources = source_groups[family_indices]
        source_names = sorted(set(family_sources.tolist()))
        mass_per_source = float(family_mass[family_indices].sum()) / len(source_names)
        for source in source_names:
            members = family_indices[family_sources == source]
            weights[members] = mass_per_source / len(members)
    if not np.isfinite(weights).all() or np.any(weights <= 0):
        raise ValueError("source-balanced sampler weights are invalid")
    weights /= weights.sum()
    return torch.as_tensor(weights, dtype=torch.double)


def train_model(
    x_fit: np.ndarray,
    y_fit_coarse: np.ndarray,
    y_fit_fine: np.ndarray,
    x_validation: np.ndarray,
    y_validation_coarse: np.ndarray,
    *,
    fine_class_count: int,
    epochs: int,
    seed: int,
    progress_label: str,
    source_groups: np.ndarray | None = None,
    checkpoint_fine_labels: np.ndarray | None = None,
) -> TrainResult:
    if epochs < 1:
        raise ValueError("epochs must be positive")
    if checkpoint_fine_labels is not None:
        checkpoint_fine_labels = np.asarray(checkpoint_fine_labels)
        if (checkpoint_fine_labels.shape != np.asarray(y_validation_coarse).shape
                or not np.issubdtype(checkpoint_fine_labels.dtype, np.integer)
                or np.any(checkpoint_fine_labels < 0)
                or np.any(checkpoint_fine_labels >= fine_class_count)
                or not np.array_equal((checkpoint_fine_labels != 0).astype(np.int64),
                                      y_validation_coarse)):
            raise ValueError("fine checkpoint labels must align with known BEN/KNA")
    set_seed(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = MHFDNetwork(x_fit.shape[1], fine_class_count).to(device)

    sample_weights = (_hierarchical_sample_weights(y_fit_fine)
                      if source_groups is None else
                      _hierarchical_source_weights(y_fit_fine, source_groups))
    generator = torch.Generator().manual_seed(seed)
    sampler = WeightedRandomSampler(
        sample_weights,
        num_samples=len(x_fit),
        replacement=True,
        generator=generator,
    )
    batch_size = 512 if len(x_fit) >= 4000 else 256
    train_loader = DataLoader(
        TensorDataset(
            torch.from_numpy(x_fit.astype(np.float32, copy=False)),
            torch.from_numpy(y_fit_coarse),
            torch.from_numpy(y_fit_fine),
        ),
        batch_size=batch_size,
        sampler=sampler,
        num_workers=0,
        pin_memory=device.type == "cuda",
    )

    optimizer = torch.optim.AdamW(model.parameters(), lr=1.0e-3, weight_decay=2.0e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=epochs, eta_min=1.0e-4
    )
    coarse_loss = nn.CrossEntropyLoss()
    fine_loss = nn.CrossEntropyLoss(label_smoothing=0.01)
    reconstruction_loss = nn.SmoothL1Loss()
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")

    best_key: tuple[float, ...] | None = None
    best_state: dict[str, torch.Tensor] | None = None
    best_epoch = 0
    best_metrics: dict[str, float] = {}
    history: list[dict[str, Any]] = []
    start = time.perf_counter()

    for epoch in range(1, epochs + 1):
        model.train()
        running_loss = 0.0
        observed = 0
        for batch_x, batch_coarse, batch_fine in train_loader:
            batch_x = batch_x.to(device, non_blocking=True)
            batch_coarse = batch_coarse.to(device, non_blocking=True)
            batch_fine = batch_fine.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(
                device_type=device.type,
                dtype=torch.float16,
                enabled=device.type == "cuda",
            ):
                output = model(batch_x)
                loss = (
                    coarse_loss(output["coarse_logits"], batch_coarse)
                    + 0.35 * fine_loss(output["fine_logits"], batch_fine)
                    + 0.03 * reconstruction_loss(output["reconstruction"], batch_x)
                )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            scaler.step(optimizer)
            scaler.update()
            running_loss += float(loss.detach().cpu()) * len(batch_x)
            observed += len(batch_x)

        learning_rate = float(optimizer.param_groups[0]["lr"])
        scheduler.step()
        train_output = infer(model, x_fit, device=device)
        validation_output = infer(model, x_validation, device=device)
        train_pred = (train_output.attack_probability >= 0.5).astype(np.int64)
        validation_pred = (validation_output.attack_probability >= 0.5).astype(np.int64)
        train_metrics = _metric_values(y_fit_coarse, train_pred)
        validation_metrics = _metric_values(y_validation_coarse, validation_pred)
        _, calibrated_validation_metrics = choose_coarse_threshold(
            y_validation_coarse, validation_output.attack_probability
        )
        fine_metrics = (None if checkpoint_fine_labels is None else
                        known_fine_checkpoint_metrics(
                            checkpoint_fine_labels, validation_output.fine_probability))
        selection_key = known_checkpoint_selection_key(
            calibrated_validation_metrics, fine_metrics)
        if best_key is None or selection_key > best_key:
            best_key = selection_key
            best_state = copy.deepcopy(model.state_dict())
            best_epoch = epoch
            best_metrics = calibrated_validation_metrics.copy()
            if fine_metrics is not None:
                best_metrics.update(fine_metrics)

        history.append(
            {
                "Epochs": epoch,
                "Ours Model_Train-Accuracy": train_metrics["accuracy"],
                "Ours Model_Validation-Accuracy": validation_metrics["accuracy"],
                "Ours Model_Train_Precision": train_metrics["precision"],
                "Ours Model_Validation_Precision": validation_metrics["precision"],
                "Ours Model_Train_Recall": train_metrics["recall"],
                "Ours Model_Validation_Recall": validation_metrics["recall"],
                "Ours Model_Train_F1": train_metrics["f1"],
                "Ours Model_Validation_F1": validation_metrics["f1"],
                "Ours Model_Train_FPR": train_metrics["fpr"],
                "Ours Model_Validation_FPR": validation_metrics["fpr"],
                "Ours Model_Train_BEN_Recall": train_metrics["ben_recall"],
                "Ours Model_Train_KNA_Recall": train_metrics["kna_recall"],
                "Ours Model_Validation_BEN_Recall": validation_metrics["ben_recall"],
                "Ours Model_Validation_KNA_Recall": validation_metrics["kna_recall"],
                "LOFO_Proxy_UNA_Candidate_Recall": "",
                "LOFO_Proxy_UNA_Support": 0,
                "Ours Model_Train_Loss": running_loss / max(1, observed),
                "Learning_Rate": learning_rate,
                "SWA_Active": False,
            }
        )
        if fine_metrics is not None:
            history[-1].update({
                "Known_Fine_Validation_Accuracy": fine_metrics["fine_accuracy"],
                "Known_Fine_Validation_Min_Recall": fine_metrics["fine_min_recall"],
                "Known_Fine_Validation_Macro_Recall": fine_metrics["fine_macro_recall"],
                "Known_Fine_Validation_Macro_NLL": fine_metrics["fine_macro_nll"],
            })

        elapsed = time.perf_counter() - start
        if epoch == 1 or epoch % 10 == 0 or epoch == epochs:
            print(
                f"[{progress_label}] epoch={epoch}/{epochs} "
                f"val_BEN={validation_metrics['ben_recall']:.4f} "
                f"val_KNA={validation_metrics['kna_recall']:.4f} "
                f"elapsed={elapsed:.1f}s",
                flush=True,
            )
    if best_state is None:
        raise RuntimeError("checkpoint selection did not produce a model")
    model.load_state_dict(best_state)
    training_seconds = time.perf_counter() - start
    return TrainResult(
        model=model,
        device=str(device),
        history=history,
        selected_epoch=best_epoch,
        selected_score=best_metrics,
        training_seconds=training_seconds,
    )


def choose_coarse_threshold(
    y_validation: np.ndarray, attack_probability: np.ndarray
) -> tuple[float, dict[str, float]]:
    """Search every empirical BEN/KNA decision boundary on calibration only.

    The former fixed 0.005 grid could declare a false no-go when a feasible
    interval was narrower than one grid step. Tied scores remain indivisible.
    Search is O(n log n); no target-unknown or held-out labels are consulted.
    """
    truth = np.asarray(y_validation)
    scores = np.asarray(attack_probability)
    if (truth.ndim != 1 or scores.ndim != 1 or len(truth) != len(scores)
            or not len(truth) or not np.issubdtype(scores.dtype, np.floating)
            or not np.isfinite(scores).all()
            or np.any((scores < 0) | (scores > 1))
            or set(np.unique(truth).tolist()) != {0, 1}):
        raise ValueError("coarse threshold requires finite BEN/KNA calibration probabilities")

    order = np.argsort(scores, kind="mergesort")
    ordered_scores = scores[order]
    ordered_truth = truth[order]
    unique_scores, group_sizes = np.unique(ordered_scores, return_counts=True)
    group_ends = np.cumsum(group_sizes) - 1
    cumulative_ben = np.cumsum(ordered_truth == 0)
    cumulative_kna = np.cumsum(ordered_truth == 1)
    ben_support = int(cumulative_ben[-1])
    kna_support = int(cumulative_kna[-1])

    def key_for(threshold: float, ben_correct: int, kna_correct: int,
                margin: float) -> tuple[float, float, float, float]:
        return (
            min(ben_correct / ben_support, kna_correct / kna_support),
            (ben_correct + kna_correct) / len(truth),
            margin,
            -abs(threshold - 0.5),
        )

    # Each adjacent-score interval produces one distinct prediction vector.
    # Place the threshold inside its interval, away from both empirical score
    # edges. An edge threshold is vulnerable to tiny CPU batch-dependent
    # inference differences even when the calibration decision is unchanged.
    best_threshold = min(0.5, float(unique_scores[0]))  # All rows predict KNA.
    best_key = key_for(best_threshold, 0, kna_support,
                       float(unique_scores[0]) - best_threshold)
    for index, (score, end) in enumerate(zip(unique_scores, group_ends, strict=True)):
        lower = float(score)
        upper = (float(unique_scores[index + 1])
                 if index + 1 < len(unique_scores) else 1.0)
        if upper > lower:
            midpoint = lower + (upper - lower) / 2.0
            # NumPy compares a float32 array with a Python float after
            # casting the scalar to float32. Use an explicit representable
            # threshold, then check that it still separates the two groups.
            threshold = float(np.asarray(midpoint, dtype=scores.dtype))
            if threshold <= lower:
                threshold = float(np.nextafter(
                    score, np.asarray(np.inf, dtype=scores.dtype)))
            margin = min(threshold - lower, upper - threshold)
        else:
            # A score of exactly 1 has no admissible in-range all-BEN
            # boundary. Retain the previous representable successor rule.
            threshold = float(np.nextafter(
                score, np.asarray(np.inf, dtype=scores.dtype)))
            margin = 0.0
        ben_correct = int(cumulative_ben[end])
        kna_correct = kna_support - int(cumulative_kna[end])
        key = key_for(threshold, ben_correct, kna_correct, margin)
        if key > best_key:
            best_key = key
            best_threshold = threshold
    best_metrics = _metric_values(
        truth, (scores >= best_threshold).astype(np.int64)
    )
    return best_threshold, best_metrics
