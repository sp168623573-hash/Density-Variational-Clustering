"""Pure ViM16 statistics over the verified real fine-head input and raw output.

The original classifier/weights and all physical input coordinates are kept.
Higher score denotes larger virtual-unknown log odds; no decision epsilon.
"""
from __future__ import annotations
import numpy as np
from scipy.special import logsumexp


def recipe():
    return dict(schema_version='real-linear-fine-head32-raw9-ViM16-v76',
        source='https://github.com/haoqiwang/vim/blob/master/benchmark.py',
        input='actual prehook linear fine-head tensor32, verified identical to real embedding; raw actual head output9',
        origin='u=-pinv(realW9x32,rcond=1e-15)@realbias9; CPUfloat64',
        covariance='genuineFIT uncentered secondmoment (H-u).T@(H-u)/n; no FITmean subtraction, shrinkage,jitter or eigenvalue clipping',
        principal_dimension=16,residual_dimension=16,
        residual='Euclidean norm of (H-u) projected on smallest16 covariance eigenvectors',
        alpha='mean genuineFIT max actualrawfine-logit / mean genuineFIT residual; must finitepositive otherwise stop, no abs/sign change',
        score='alpha*residual - logsumexp(actualrawfine_logits9); higherOOD fixed before data',
        dimension_selection='headwidth32//2 fixed16, consistent smallwidth rule of original implementation',
        query_label_input=False,field_filter=False,parameter_grid=False,score_epsilon=False,
        full_theory_or_networktraffic_OOD_probability_claimed=False)


def require(value,reason):
    if not value:raise ValueError(reason)


def fit(head_inputs,raw_logits,real_W,real_b):
    h=np.asarray(head_inputs,np.float64);logits=np.asarray(raw_logits,np.float64)
    W=np.asarray(real_W,np.float64);b=np.asarray(real_b,np.float64)
    require(h.ndim==2 and h.shape[1]==32 and len(h)==6000 and logits.shape==(6000,9),'truegenuine6000 actual head32/raw9')
    require(W.shape==(9,32) and b.shape==(9,) and all(np.isfinite(x).all() for x in (h,logits,W,b)),'real complete finite head input/output/weights')
    origin=-np.linalg.pinv(W,rcond=1e-15)@b
    centered=h-origin;covariance=centered.T@centered/len(h)
    eig,evec=np.linalg.eigh(covariance);order=np.argsort(eig,kind='stable')[::-1]
    residual_basis=evec[:,order[16:]]
    r=np.linalg.norm(centered@residual_basis,axis=1)
    mean_max=float(logits.max(axis=1).mean());mean_r=float(r.mean())
    require(np.isfinite([mean_max,mean_r]).all() and mean_max>0 and mean_r>0,'positive genuineFIT maximum logit and residual means, failclosed not reverse')
    alpha=mean_max/mean_r;require(np.isfinite(alpha) and alpha>0,'finite positive predeclared matching scale')
    return dict(origin=origin,covariance=covariance,eigenvalues=eig,eigenvectors=evec,descending_order=order,residual_basis=residual_basis,
                W=W,b=b,alpha=np.asarray(alpha),FIT_mean_max_logit=np.asarray(mean_max),FIT_mean_residual=np.asarray(mean_r))


def scores(head_inputs,raw_logits,state):
    h=np.asarray(head_inputs,np.float64);logits=np.asarray(raw_logits,np.float64)
    require(h.ndim==2 and h.shape[1]==32 and logits.shape==(len(h),9) and np.isfinite(h).all() and np.isfinite(logits).all(),'actual full queryhead32/raw9')
    residual=np.linalg.norm((h-state['origin'])@state['residual_basis'],axis=1)
    energy=logsumexp(logits,axis=1);virtual=float(state['alpha'])*residual
    value=virtual-energy
    require(np.isfinite(value).all() and np.isfinite(residual).all(),'finite direct virtual log odds without clipping')
    return value,dict(residual=residual,energy=energy,virtual_logit=virtual)
