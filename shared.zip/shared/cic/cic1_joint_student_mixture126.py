"""Joint known-only Student3 mixture cue and preserved126 paper DVC."""
import argparse,json,sys,time,types
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from . import cic1_joint_student_mixture_core_v130 as core
from . import cic1_symmetric_collective_density126_v126 as previous
ROOT,files,require=previous.ROOT,previous.files,previous.require
old=previous.old;MODULE='paper_open_set.cic1_joint_student_mixture126_v130'
DIR=ROOT/'tmp/cic1_joint_student_mixture126_20261012_v130';BASE=ROOT/'data/external_dev/processed/cic1_joint_student_mixture126_20261012_v130';REG=DIR/'registry_before_known.json'
def policy():
    return dict(schema_version='CIC1-known-only-joint126-Student3-mixture-candidate-v130',recipe=core.recipe(),hypotheses=1,
        history='fieldconditional masked Student3 and raw78 covariance guards are not all126 proper correlated9fine density mixture; original126 flow radialmin not jointlikelihood candidate',
        graph_deferred='historical complete CAL threeclass seed prefix absent; no CALtruthknown hardzero seeds fabricated',
        trueUNA_fit=False,currenttruth_for_parameters=False,parameter_grid=False,extension_not_verbatim_paper=True,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
def closure():
    result={};todo=[sys.modules[__name__]];seen=set()
    while todo:
        m=todo.pop()
        if m is None or id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if not p or not Path(p).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        result[MODULE if m is sys.modules[__name__] else m.__name__]=files.item(p)
        for value in vars(m).values():
            child=value if isinstance(value,types.ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            if child is not None:todo.append(child)
    return result
def archive(a,keys,pins):return old.archive(a,keys,pins)
def save(out,r,name,value):return old.save(out,r,name,value)
def freeze():
    began=time.perf_counter();pins={};oldref=files.item(previous.REG);reg=files.js(oldref,pins)
    kr=files.item(previous.BASE/'known/report.json');cr=files.item(previous.BASE/'current/report.json');k=files.js(kr,pins);c=files.js(cr,pins)
    require(k['known_gate_passed'] and c['prediction_sealed'] and c['original_class_gates']['UNA']['correct']==3114,'actualpreservedwhole3114 andtrueknowncontrol')
    a=dict(reg['assets']);a.update(known_baseline=k['files']['complete_prediction_before_truth'],baseline=c['files']['complete_prediction_before_truth'],
        known_background=k['files']['complete_original126_symmetric_candidates_before_DVC'],current_background=c['files']['complete_original126_symmetric_candidates_before_DVC'])
    close=files.item(previous.OUT/'CIC1_V126_SYMMETRIC_DENSITY_3114_MIXED_COMPLETED_CLOSEOUT.json');closed=files.js(close,pins)
    src=closure();contract=core.synthetic_contract()
    import sklearn.covariance._shrunk_covariance as runtime
    runtime_source=files.item(runtime.__file__)
    for d in [*a.values(),*src.values()]:files.read(d,pins)
    require(Path(runtime_source['path']).suffix=='.py' and files.item(runtime_source['path'])==runtime_source,'exactexplicit installed OAS runtime source hash')
    pins[str(Path(runtime_source['path']).resolve())]=runtime_source['sha256']
    require(not REG.exists() and not BASE.exists(),'exclusive fixedsingle jointStudent3 candidate namespace')
    DIR.mkdir(parents=True,exist_ok=True)
    return files.write(REG,dict(policy=policy(),assets=a,sources=src,OAS_runtime_source=runtime_source,synthetic_contract=contract,
        previous_registry=oldref,previous_known=kr,previous_current=cr,previous_closeout=close,
        prior_preparation_seconds=closed['timing_seconds']['conservative_allprep_plus_ancestry'],freeze_seconds=time.perf_counter()-began,input_sha256=pins,current_numeric_decodes=0))
def bind(ref,pins):
    r=files.js(ref,pins);require(r['policy']==policy() and r['sources']==closure(),'exactfrozen all126 propermixture recipe/source')
    for p,s in r['input_sha256'].items():
        if Path(p).resolve()==Path(r['OAS_runtime_source']['path']).resolve():
            require(files.item(p)['sha256']==s,'exactregistered installed OAS source hash unchanged');pins[str(Path(p).resolve())]=s
        else:files.read(dict(path=p,sha256=s),pins)
    return r
def run(phase,ref,knownref=None):
    began=time.perf_counter();pins={};reg=bind(ref,pins);control=None
    if phase=='current':
        control=files.js(knownref,pins);require(control['known_gate_passed'] and control['prediction_sealed'] and control['registry']==ref,'onceknowninteger99 beforecurrent')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False)
    r=dict(policy=policy(),phase=phase,registry=ref,files={},NN_fit=0,NN_forward=0,metric_fit=0,R7_fit=0,mixture_fit=0,CAL_fit=0,DVC=0,
        current_numeric_decodes=0,prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        with threadpool_limits(limits=2):
            a=reg['assets'];wrapped=files.js(a['metric'],pins);metric=old.cic.learned.PaperVariationalPairMetric.from_state(wrapped['metric_payload']);require(metric.dimension==126,'unchangedreal126 metric')
            r['files']['metric']=a['metric']
            if phase=='known':
                prep=time.perf_counter();mat=archive(a['material'],('FIT_ids','FIT_groups','FIT_fine','FIT_Z126','CAL_ids','CAL_Z126'),pins)
                native=archive(a['native_known'],('FIT_ids','FIT_y_fine','CAL_ids','CAL_y_coarse'),pins)
                require(np.array_equal(mat['FIT_ids'],native['FIT_ids']) and np.array_equal(mat['FIT_fine'],native['FIT_y_fine']) and np.array_equal(mat['CAL_ids'],native['CAL_ids']),'allactualknownFIT/CAL roletruth')
                state=core.fit_state(mat['FIT_Z126'],mat['FIT_fine'],mat['FIT_groups']);r['mixture_fit']=1
                r['files']['state']=save(out,r,'genuine6000_known9fine_withinOAS_properStudent3_state_before_CAL',state)
                save(out,r,'actualknown6000_full126_FIT_before_mixture',dict(ids=mat['FIT_ids'],groups=mat['FIT_groups'],Z126=mat['FIT_Z126'],fine=mat['FIT_fine']))
                cal=core.signals(mat['CAL_Z126'],state);save(out,r,'alltrueknown900_jointStudent3_scores_before_cut',dict(ids=mat['CAL_ids'],Z126=mat['CAL_Z126'],truecoarse=native['CAL_y_coarse'],**cal))
                rule=old.cic.dvc.calibrate_known_cutoffs(cal['score'],native['CAL_y_coarse']);r['CAL_fit']=1;r['files']['rule']=files.write(out/'all900_trueknown_oncefinite99_jointStudent3.json',rule)
                r['newFIT_CAL_preparation_seconds']=time.perf_counter()-prep
            else:
                state=archive(control['files']['state'],('mean126','std126','centers9x126','L126','logdet_shape','prior9'),pins);rule=files.js(control['files']['rule'],pins)
                r['files'].update(state=control['files']['state'],rule=control['files']['rule']);r['known_report']=knownref
            q,b,_=old.query('CIC1',phase,a,pins);r['current_numeric_decodes']=len(q['ids']) if phase=='current' else 0
            cue=core.signals(q['Z126'],state);newraw=(b!=2)&old.cic.dvc.candidate_mask(cue['score'],q['stage1'],rule)
            background=archive(a['known_background' if phase=='known' else 'current_background'],('ids','raw'),pins);require(np.array_equal(background['ids'],q['ids']),'samewhole previousrawdensity background')
            density=newraw|background['raw'];save(out,r,'all126_jointStudent3_scores_and_uniformdensity_before_DVC',dict(ids=q['ids'],groups=q['groups'],Z126=q['Z126'],stage1=q['stage1'],newraw=newraw,previous_raw=background['raw'],density=density,**cue))
            routed=old.cic.dvc.route_current_candidates(metric,q['Z126'],density,seed=20261012);r['DVC']=1
            save(out,r,'same126_jointmixture_union_DVC_before_truth',{k:v for k,v in routed.items() if k!='manifest'});r['files']['DVC_manifest']=files.write(out/'same126_jointmixture_union_DVC_manifest.json',routed['manifest'])
            retained=newraw&routed['retained'];p=b.copy();p[retained]=2;require(np.all(p[b==2]==2),'wholeoldUNA2 preserved')
            v=dict(ids=q['ids'],prediction=p,baseline=b,newraw=newraw,previous_raw=background['raw'],density=density,retained=retained)
            sealed=save(out,r,'complete_prediction_before_truth',v)
            r['files']['seal']=files.write(out/'completeprediction_seal_before_truth.json',dict(predictions=sealed,registry=ref,state=r['files']['state'],rule=r['files']['rule'],metric=a['metric'],querytruth_used=False));r['prediction_sealed']=True
            if phase=='known':y=archive(a['known_truth'],('CP_truth',),pins)['CP_truth']
            else:
                truth=archive(a['truth'],('ids','truth'),pins);require(np.array_equal(truth['ids'],q['ids']),'truequery openedafterfullseal');y=truth['truth']
            r['truth_opened']=True;gates,delta,binary=old.helpers.metrics(y,b,p)
            r.update(execution_status='CIC1_jointStudent3_126_'+phase+'_completed',original_class_gates=gates,EffectDelta=delta,binary_attack_detection=binary,
                known_gate_passed=all(gates[n]['passed'] for n in ('BEN','KNA')),candidate_accepted_for_retention=False,
                newraw_by_trueclass={n:int(((y==c)&newraw).sum()) for c,n in enumerate(('BEN','KNA','UNA'))},retained_by_trueclass={n:int(((y==c)&retained).sum()) for c,n in enumerate(('BEN','KNA','UNA'))})
            save(out,r,'postseal_complete_whole_pair',dict(**v,truth=y))
            if phase=='current':r['perfect_newraw_UNA_ceiling']=int(((y==2)&((b==2)|newraw)).sum())
        for p,s in pins.items():require(files.item(p)['sha256']==s,'allold frozenbytes preserved')
    except Exception as error:r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:r.update(input_sha256=pins,wall_seconds=time.perf_counter()-began);files.write(out/'report.json',r)
    return files.item(out/'report.json')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for key in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+key)
    a=p.parse_args();ref=None if a.registry is None else dict(path=str(Path(a.registry).resolve()),sha256=a.registry_sha256);k=None if a.known_report is None else dict(path=str(Path(a.known_report).resolve()),sha256=a.known_sha256)
    print(json.dumps(freeze() if a.phase=='freeze' else run(a.phase,ref,k)))
