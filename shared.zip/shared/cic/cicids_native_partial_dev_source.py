"""Fixed original CIC1 partial DEV inventory/extraction; no model invocation.

Native78 features and IDs are separate from metric-only family truth and copy
indices. A frozen consumer policy is checked before any new numeric scan.
"""
from __future__ import annotations

import argparse
from collections import Counter
from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3
import time

import numpy as np

from . import cic2017_native_known_inventory_v1 as native
from . import cic2017_native_label_capacity_v1 as labels

ROOT = Path(__file__).resolve().parents[1]
SETTING = "CIC Setting1"
FAMILIES = tuple(labels.SPEC.unknown_families)
SOURCE_DIR, SOURCE_SPECS, BATCH_SIZE = native.SOURCE_DIR, native.SOURCE_SPECS, native.BATCH_SIZE
LABEL_REPORT = "data/external_dev/processed/cic2017_native_label_capacity_20261008_v1/report.json"
LABEL_SHA = "7f576f013c4fa2829648269b970182d39ef247b30a430e0036f745c98cd7f5a3"
DATABASE = "data/external_dev/processed/cic2017_native_known_inventory_20261008_v1/known_feature_group_counts.sqlite"
DATABASE_SHA = "c24be6c9230ac5208a708e7cdbc13dc524fc02802b6b33d012d794f5415ae47e"
RAW_TO_FAMILY = {"Infiltration": "Infiltration", "Heartbleed": "Heartbleed", "Bot": "Bot",
    "Web Attack \u0096 XSS": "Web Attack - XSS",
    "Web Attack \u0096 Sql Injection": "Web Attack - Sql Injection",
    "Web Attack \u0096 Brute Force": "Web Attack - Brute Force"}
NAMESPACE = "cic2017-native-partial-dev-v1-20261008"
POLICY = dict(schema_version="CIC2017-native-partial-development-source-v1", setting=SETTING,
    raw_label_mapping=RAW_TO_FAMILY, label_registration=LABEL_SHA, null_label_action="reject without numeric conversion",
    source_scope="same original CIC2017 mirrored dataset, record/exact-feature disjoint partial development only",
    representative_rule="minimum(source_file_sha256,zero_based_ordinal) within each surviving single-family exact native78 group",
    order_rule="SHA256(fixed namespace + '|' + canonical78 SHA), tie canonical78 SHA; no family in public row order",
    retention_rule="all eligible unique original feature groups, no score or difficulty selection",
    closure="all5800 direct unknown groups OR existing CIC1 known SQLite blocked groups OR current known6000 groups; reject entire group",
    cross_UNA_family_groups="reject every conflicting group", nonfinite_groups="reject without imputation",
    maximum_DEV_evaluation_rows=5100, paired_known_CP_rows=900, combined_evaluation_limit=6000,
    resampling="positive family below20 only, metric-index copies after prediction seal; copies never enter density/inference",
    missing_zero_families_never_copied=True, full_Table1=False, full_Table1_coverage=False,
    final_source_admitted=False, final_test_executed=False, exhaustive_history_independence_claimed=False,
    physical_event_independence_claimed=False, fresh_independent_unknown_claimed=False,
    model_training_or_inference_or_DVC=False, status="FAIL_TARGET99", published=False)


class NativePartialDevStop(ValueError):
    pass


def require(value, reason):
    if not value:
        raise NativePartialDevStop(reason)


sha, write_json = native.sha, native._write_json


def _pin(path, expected, pins):
    path = Path(path)
    path = (path if path.is_absolute() else ROOT / path).resolve()
    require(path.is_relative_to(ROOT) and path != ROOT and pins.get(str(path), expected) == expected
            and sha(path) == expected, "fixed_input_changed:" + str(path))
    pins[str(path)] = expected
    return path


def _consumer_policy(descriptor, pins):
    path = _pin(descriptor["path"], descriptor["sha256"], pins)
    policy = json.loads(path.read_text(encoding="utf-8"))
    require(policy.get("setting") == SETTING and policy.get("known_only_parameters_frozen") is True
            and policy.get("unknown_numeric_values_decoded") is False and policy.get("unknown_metric_truth_opened") is False
            and policy.get("final_test_executed") is False and policy.get("published") is False
            and type(policy.get("input_sha256")) is dict and bool(policy["input_sha256"]), "frozen_consumer_policy_before_numeric_scan")
    for file, expected in policy["input_sha256"].items():
        _pin(file, expected, pins)
    return {"path": str(path), "sha256": descriptor["sha256"]}


def _load_inputs(pins):
    _pin(Path(labels.__file__), "19226fa94736f31a3cd20ce03c89e86902ac078ca104a99514e42e7998fdf617", pins)
    footers, exclusions, known_ordinals = labels._load_registered_inputs(pins)
    label_report = json.loads(_pin(LABEL_REPORT, LABEL_SHA, pins).read_text(encoding="utf-8"))
    require(label_report["label_inventory_completed"] is True and label_report["all_input_pins_stable"] is True
            and label_report["summary"]["null_label_counts"]["all5800_ordinal_excluded_rows"] == 0,
            "completed_label_inventory_and_zero_historical_null_rows")
    records = json.loads(_pin(labels.RECORDS_REL, labels.RECORDS_SHA, pins).read_text(encoding="utf-8"))
    known_groups = {r["canonical78_sha256"] for entries in records["roles"].values() for r in entries}
    require(len(known_groups) == 6000, "all_known_roles6000_exact_groups")
    database = _pin(DATABASE, DATABASE_SHA, pins)
    original_counts = {family: label_report["summary"]["exact_raw_label_counts"][raw]["source_rows"] for raw, family in RAW_TO_FAMILY.items()}
    scan_sources = []
    for source in label_report["source_scans_completed"]:
        if any(source["exact_raw_label_counts"].get(raw, {}).get("source_rows", 0) for raw in RAW_TO_FAMILY):
            scan_sources.append(source["source_file"])
    require(len(scan_sources) == 4 and sum(original_counts.values()) == 4193, "fixed_four_source_six_family_Label_inventory")
    pins[str(Path(__file__).resolve())] = sha(__file__)
    return footers, exclusions, known_ordinals, known_groups, database, original_counts, frozenset(scan_sources)


class Collector:
    def __init__(self):
        self.groups, self.family_rows = {}, Counter()

    def consume(self, batch, *, offset, filename, source_sha, excluded, known, arrow, pc, materialized):
        require(type(offset) is int and offset >= 0 and 0 < batch.num_rows <= BATCH_SIZE, "bounded_ordinal_source_batch")
        mask = pc.is_in(batch.column("Label"), value_set=arrow.array(tuple(RAW_TO_FAMILY)))
        positions = pc.indices_nonzero(mask).to_numpy(zero_copy_only=False)
        chosen = batch.filter(mask)
        if not len(positions):
            return 0
        raw_labels = chosen.column("Label").to_pylist()
        require(chosen.num_rows == len(positions) and all(v in RAW_TO_FAMILY for v in raw_labels), "exact_registered_UNA_label_filter")
        frame = chosen.select(list(native.CIC_FEATURE_COLUMNS)).to_pandas()
        materialized(len(frame))
        values = native._canonical_matrix(frame)
        require(values.shape == (len(positions), 78) and values.dtype == np.dtype("<f8"), "canonical_native78_exact")
        fingerprints = native._feature_fingerprints(values)
        for i, (local, raw, fp) in enumerate(zip(positions, raw_labels, fingerprints)):
            ordinal, family = offset + int(local), RAW_TO_FAMILY[raw]
            self.family_rows[family] += 1
            finite, rank = bool(np.isfinite(values[i]).all()), (source_sha, ordinal)
            group = self.groups.setdefault(fp, {"families": set(), "rows": 0, "finite": finite,
                "historical_direct": False, "known_ordinal_direct": False, "representative": None})
            require(group["finite"] == finite, "digest_finiteness_consistency")
            group["families"].add(family); group["rows"] += 1
            group["historical_direct"] |= ordinal in excluded
            group["known_ordinal_direct"] |= ordinal in known
            old = group["representative"]
            if old is None or rank < old["rank"]:
                group["representative"] = {"rank": rank, "filename": filename, "values": values[i].copy()}
        return len(positions)


def _historical_known_groups(database, fingerprints):
    blocked, keys = set(), sorted(fingerprints)
    with closing(sqlite3.connect(Path(database).resolve().as_uri() + "?mode=ro", uri=True)) as connection:
        connection.execute("PRAGMA query_only=ON")
        for start in range(0, len(keys), 800):
            chunk = keys[start:start + 800]
            rows = connection.execute("SELECT fingerprint FROM feature_groups WHERE setting=? AND blocked=1 AND fingerprint IN ("
                + ",".join("?" for _ in chunk) + ")", (SETTING, *chunk))
            blocked.update(row[0] for row in rows)
    return blocked


def _ordered_outputs(collector, historical_known, known_groups, original_counts):
    stats = {family: {"source_original_rows": original_counts.get(family, 0), "retained_original_groups": 0,
        "retained_original_source_members": 0, "excluded_group_reasons_nonexclusive": Counter()} for family in FAMILIES}
    retained, reasons_by_group = [], {}
    for fp, group in collector.groups.items():
        reasons = []
        if not group["finite"]: reasons.append("nonfinite_native78")
        if group["historical_direct"]: reasons.append("all5800_unknown_source_group_closure")
        if fp in historical_known: reasons.append("all5800_known_source_group_closure")
        if group["known_ordinal_direct"] or fp in known_groups: reasons.append("current_known6000_all_roles_identity_or_feature")
        if len(group["families"]) != 1: reasons.append("cross_UNA_family_feature_conflict")
        if reasons:
            reasons_by_group[fp] = reasons
            for family in group["families"]:
                stats[family]["excluded_group_reasons_nonexclusive"].update(reasons)
        else:
            family = next(iter(group["families"]))
            retained.append((hashlib.sha256((NAMESPACE + "|" + fp).encode()).hexdigest(), fp, family, group))
            stats[family]["retained_original_groups"] += 1
            stats[family]["retained_original_source_members"] += group["rows"]
    retained.sort(key=lambda row: (row[0], row[1]))
    require(retained, "no_eligible_partial_DEV_original_groups")
    vectors, ids, families, records = [], [], [], []
    for _, fp, family, group in retained:
        representative = group["representative"]
        source_sha, ordinal = representative["rank"]
        require(hashlib.sha256(representative["values"].tobytes()).hexdigest() == fp, "representative_canonical78_binding")
        sample_id = f"cic:original-native2017:{source_sha}:{ordinal}:{fp}"
        vectors.append(representative["values"]); ids.append(sample_id); families.append(family)
        records.append(dict(sample_id=sample_id, source_file=str((ROOT / SOURCE_DIR / representative["filename"]).resolve()),
            source_file_sha256=source_sha, source_row_ordinal=ordinal, canonical78_sha256=fp,
            original_group_member_count=group["rows"], retained_after_all5800_and_known6000_closure=True,
            finite_native78=True, cross_family_conflict=False))
    indices, copies = list(range(len(ids))), {}
    for family in FAMILIES:
        positions = [i for i, value in enumerate(families) if value == family]
        needed = max(0, 20 - len(positions)) if positions else 0
        copies[family] = needed
        indices.extend(positions[j % len(positions)] for j in range(needed))
    require(len(indices) <= 5100 and len(indices) + 900 <= 6000, "raw_plus_minimum20_metric_copies_exceeds_fixed_DEV_budget")
    total_source = sum(original_counts.values())
    for family in FAMILIES:
        stats[family]["evaluation_copies"] = copies[family]
        stats[family]["evaluation_support_including_copies"] = stats[family]["retained_original_groups"] + copies[family]
        stats[family]["source_original_share_all_six_UNA"] = original_counts.get(family, 0) / total_source
        stats[family]["raw_DEV_share"] = stats[family]["retained_original_groups"] / len(ids)
        stats[family]["share_deviation_percentage_points"] = 100 * (stats[family]["raw_DEV_share"] - stats[family]["source_original_share_all_six_UNA"])
        stats[family]["excluded_group_reasons_nonexclusive"] = dict(stats[family]["excluded_group_reasons_nonexclusive"])
    arrays = {"native78": np.ascontiguousarray(vectors, dtype="<f8"), "ids": np.asarray(ids, dtype=np.str_)}
    truth = {"ids": arrays["ids"].copy(), "family": np.asarray(families, dtype=np.str_)}
    evaluation = dict(schema_version="CIC1-partial-DEV-metric-copy-index-v1", original_rows=len(ids),
        evaluation_rows=len(indices), indices=indices, original_ids_sha256=hashlib.sha256(arrays["ids"].tobytes()).hexdigest(),
        copies_by_family=copies, original_rows_only_enter_inference_and_density=True,
        permitted_phase="after original predictions and their ordered IDs are sealed; show raw and expanded denominators separately")
    return arrays, truth, records, evaluation, stats, reasons_by_group


def _save_npz(path, arrays):
    with Path(path).open("xb") as handle:
        np.savez_compressed(handle, **arrays)
    with np.load(path, allow_pickle=False) as saved:
        require(set(saved.files) == set(arrays) and len(saved.files) == len(arrays), "exact_separate_archive_members")
        for key, value in arrays.items():
            require(saved[key].dtype == value.dtype and saved[key].shape == value.shape
                    and saved[key].tobytes() == value.tobytes(), "sealed_array_live_binding:" + key)
    return {"path": str(Path(path).resolve()), "sha256": sha(path)}


def run_partial_dev_inventory(*, output_directory, frozen_consumer_policy):
    output = Path(output_directory).resolve()
    require(output.is_relative_to(ROOT) and output != ROOT, "fresh_workspace_output_required")
    output.mkdir(parents=True, exist_ok=False)
    start, stage, pins = time.perf_counter(), "consumer_policy_before_any_unknown_numeric_values", {}
    report = {**POLICY, "source_scan_started": False, "source_scans_completed": [],
        "unknown_numeric_materialized": False, "unknown_numeric_rows_materialized": 0,
        "unknown_numeric_rows_completed": 0, "inventory_completed": False, "source_extraction_completed": False,
        "partial_development_source_bound": False, "frozen_consumer_policy": None,
        "all_input_pins_stable": False, "files": {}}
    try:
        consumer = _consumer_policy(frozen_consumer_policy, pins)
        report["frozen_consumer_policy"] = consumer
        stage = "register_native_sources_exclusions_and_known6000"
        footers, excluded, known, known_groups, database, original_counts, scan_sources = _load_inputs(pins)
        # Runtime paths/hashes must agree with the registered label census lineage.
        runtime_pins = {}; arrow, pq, pc = native._load_arrow(runtime_pins)
        for path, expected in runtime_pins.items(): _pin(path, expected, pins)
        stage = "seal_numeric_inventory_policy_before_source_scan"
        policy = write_json(output / "partial_DEV_policy_before_numeric_scan.json", {**POLICY,
            "frozen_consumer_policy": consumer, "source_input_pins": dict(pins),
            "source_specs": SOURCE_SPECS, "source_original_family_rows": original_counts,
            "scan_sources": sorted(scan_sources), "known6000_feature_groups": len(known_groups)})
        pins[policy["path"]] = policy["sha256"]; report["files"]["prescan_policy"] = policy
        collector = Collector()
        def materialized(count):
            report["unknown_numeric_materialized"] = True
            report["unknown_numeric_rows_materialized"] += count
        stage = "registered_UNA_only_native78_scan"
        for filename, digest, rows in SOURCE_SPECS:
            if filename not in scan_sources: continue
            parquet = pq.ParquetFile(ROOT / SOURCE_DIR / filename); native._verify_footer(parquet, footers[filename])
            offset = completed = 0; report["source_scan_started"] = True
            for batch in parquet.iter_batches(batch_size=BATCH_SIZE, columns=[*native.CIC_FEATURE_COLUMNS, "Label"]):
                count = collector.consume(batch, offset=offset, filename=filename, source_sha=digest,
                    excluded=excluded[filename], known=known[filename], arrow=arrow, pc=pc, materialized=materialized)
                offset += batch.num_rows; completed += count; report["unknown_numeric_rows_completed"] += count
            require(offset == rows, "complete_registered_source_traversal")
            progress = dict(source_file=filename, source_sha256=digest, source_rows_traversed=offset, declared_UNA_rows=completed)
            report["source_scans_completed"].append(progress); print(json.dumps(progress), flush=True)
        require(dict(collector.family_rows) == original_counts, "all_six_source_label_counts_equal_fixed_census")
        stage = "canonical78_full_group_exclusion_closure_and_metric_only_copy_plan"
        historical_known = _historical_known_groups(database, collector.groups)
        arrays, truth, records, evaluation, stats, rejected = _ordered_outputs(collector, historical_known, known_groups, original_counts)
        stage = "seal_separate_features_truth_records_and_evaluation_index"
        files = dict(features=_save_npz(output / "partial_DEV_features.npz", arrays),
            truth=_save_npz(output / "partial_DEV_metric_truth.npz", truth),
            ordered_source_records=write_json(output / "ordered_source_records.json", dict(setting=SETTING, records=records,
                truth_family_absent=True, representative_rule=POLICY["representative_rule"])),
            evaluation_resampling_plan=write_json(output / "metric_only_resampling_indices.json", evaluation),
            excluded_group_reasons=write_json(output / "excluded_group_reasons.json", rejected))
        report["files"].update(files)
        for item in files.values(): pins[item["path"]] = item["sha256"]
        report.update(source_extraction_completed=True, family_capacity=stats, original_DEV_rows=len(records), evaluation_DEV_rows=evaluation["evaluation_rows"],
            covered_families=[f for f in FAMILIES if stats[f]["retained_original_groups"] > 0],
            missing_families=[f for f in FAMILIES if stats[f]["retained_original_groups"] == 0],
            missing_Table1_unknown_families=[f for f in FAMILIES if stats[f]["retained_original_groups"] == 0],
            original_UNA_groups_observed=len(collector.groups), rejected_UNA_groups=len(rejected),
            current_known6000_group_count=len(known_groups), historical_known_blocked_groups_matched=len(historical_known),
            model_consumer_allowed_archive_members=["native78", "ids"],
            truth_and_evaluation_plan_allowed_phase="after sealed original predictions only")
        stage = "final_all_source_consumer_policy_and_output_integrity"
        for path, expected in pins.items(): require(sha(path) == expected, "input_changed_during_partial_inventory:" + path)
        report.update(inventory_completed=True, partial_development_source_bound=True, all_input_pins_stable=True,
            execution_status="native_CIC1_partial_development_source_completed")
    except Exception as error:
        report.update(execution_status="protocol_stop" if isinstance(error, (NativePartialDevStop, native.NativeKnownInventoryStop, labels.NativeLabelCapacityStop)) else "execution_failed",
            failed_stage=stage, error_type=type(error).__name__, error_message=str(error))
    report.update(source_input_pins=pins, wall_seconds=time.perf_counter() - start)
    write_json(output / "report.json", report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-directory", required=True, type=Path)
    parser.add_argument("--consumer-policy-path", required=True, type=Path)
    parser.add_argument("--consumer-policy-sha", required=True)
    args = parser.parse_args(argv)
    report = run_partial_dev_inventory(output_directory=args.output_directory,
        frozen_consumer_policy={"path": str(args.consumer_policy_path), "sha256": args.consumer_policy_sha})
    print(json.dumps({k: report.get(k) for k in ("execution_status", "original_DEV_rows", "evaluation_DEV_rows", "missing_families", "wall_seconds", "failed_stage", "error_message")}))
    return 0 if report["inventory_completed"] else 2 if report["execution_status"] == "protocol_stop" else 1


if __name__ == "__main__":
    raise SystemExit(main())
