"""Fixed historical forest directions above new FIT6000 MHFD, known caches only.

Root freeze reads hashes/JSON/headers; Root run computes one fixed blend and one
CAL threshold. No source features, model deserialization, training or inference.
The CIC2 forest is the coverage forest referenced by the strong signedlog main;
its own old forest-blend .75 selection is not the strong main's .25 direction.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import numpy as np

from . import cic_fit6000_mhfd_training_v1 as nn

ROOT=nn.ROOT
FORESTS={
    "CIC Setting1":dict(path="data/external_dev/processed/cic2017_native_known_forest_blend_20261008_v1/CIC_Setting1/report.json",sha256="b0cf791a2e7d49ec61c911f014e0865e1172fc13682e11cad806618f2f6ffa0a"),
    "CIC Setting2":dict(path="data/external_dev/processed/cic2017_setting2_known_fit_coverage_forest_blend_20261008_v1/CIC_Setting2/report.json",sha256="4cd3996dc86d8d400f7df650668842b355d158cdd2b69749ed5c53198a2af736")}
WEIGHTS={"CIC Setting1":.75,"CIC Setting2":.25}
MAIN_PROOF={"CIC Setting1":FORESTS["CIC Setting1"],
    "CIC Setting2":dict(path="data/external_dev/processed/cic2017_setting2_signed_log_cached_blend_20261008_v1/CIC_Setting2/report.json",sha256="4286abcff8d7805e44af2d3450d8891ecdd2d43a5fa7d25ab6bd0efec17bb36d")}
require,checked,read,json_new,npz_new=nn.require,nn.checked,nn.read,nn.json_new,nn.npz_new


def policy(setting):
    require(setting in FORESTS,"own_CIC_setting")
    return dict(schema_version="CIC-FIT6000-own-fixed-historical-forest-known-cache-v1",setting=setting,
        forest_weight=WEIGHTS[setting],NN_weight=1-WEIGHTS[setting],
        fixed_formula="(1-w)*actual new NN.attack_probability + w*(1-existing forest fine[:,BENcolumn0]); float64",
        new_NN_probability="actual cached MHFD .55 coarse +.45 fine attack; preserve original AMP probabilities",
        forest_native_input="historical frozen model originalnative78 float32; no NN-preprocessor transform",
        fine_scores="fixed (1-w)*new NN fine9 +w*forest fine9 scores for transparent future argmax; no normalization repair",
        threshold_role="one CAL original known label call, after fixed blend and input binding; CP no threshold tuning",
        CP_scope="already used for NN checkpoint, historically warm; no independent final acceptance claim",
        gate="all four original CP/CAL BEN/KNA integer99 pass before next unknown query geometry",
        weight_grid_or_runnerup=False,old_threshold_reused=False,NN_train=0,forest_train=0,
        NN_inference=0,forest_inference=0,model_deserialization=0,source_numeric_reads=0,
        unknown_reads=0,score_distance_DVC=0,CAL_reporting_copies_used_for_calibration=False,
        physical_event_independence_claimed=False,accepted_baseline_replaced=False,
        status="FAIL_TARGET99",published=False,final_test_executed=False)


def freeze(setting,NN_report,output_directory):
    out=Path(output_directory).resolve()
    require(out.is_relative_to(ROOT) and out!=ROOT,"fresh_workspace_child")
    out.mkdir(parents=True,exist_ok=False)
    pins={}
    actual=read(NN_report,pins)
    require(actual["setting"]==setting and actual["execution_status"]=="CIC_own_FIT6000_MHFD_training_and_known_controls_completed"
            and actual["training_completed"] and actual["known_metrics_evaluated"]
            and not actual["published"] and not actual["final_test_executed"] and actual["unknown_forward_calls"]==0,"completed_own_FIT6000_NN")
    forest=read(FORESTS[setting],pins)
    main=read(MAIN_PROOF[setting],pins)
    require(forest["forest_training_runs"]==1 and forest["metrics_evaluated"] and not forest["published"]
            and main["selected"]["weight"]==WEIGHTS[setting],"frozen_historical_direction_and_forest")
    if setting=="CIC Setting2":
        require(main["complete_future_model_recipe"]["native78_existing_forest"]==forest["model"],"exact_strong_main_coverage_forest")
    proof=read(forest["training_proof"],pins)
    prefit=read(forest["prefit"],pins)
    require(proof["classes"]==9 and proof["model"]==forest["model"]
            and tuple(prefit["family_order"])==("BEN",*nn.get_spec(setting).known_families),"forest_fine9_BENcolumn0_class_namespace")
    checked(forest["model"],pins)
    material=read(actual["material"],pins)
    require(material["setting"]==setting and material["FIT_optimizer_rows"]==6000,"same_new_NN_material")
    checked(material["features"],pins)
    features_header=nn.header_tools.npz_headers(Path(material["features"]["path"]))
    cache={role:forest["CP_candidates" if role=="CP" else "CAL_predictions"] for role in ("CP","CAL")}
    new_outputs={role:actual["files"][role+"_complete_inference_before_guard"] for role in ("CP","CAL")}
    for role in cache:
        expected=nn.policy(setting)[role+"_original"]
        h=nn.header_tools.npz_headers(checked(cache[role],pins))
        require(h[role+"_ids"]["shape"]==[expected] and h["forest_fine_probability"]["shape"]==[expected,9],"forest_original_control_headers")
        new_h=nn.header_tools.npz_headers(checked(new_outputs[role],pins))
        require(new_h["attack_probability"]["shape"]==[expected] and new_h["fine_probability"]["shape"]==[expected,9]
                and features_header[role+"_ids"]["shape"]==[expected],"new_NN_original_control_headers")
    checked(actual["files"]["model"],pins)
    checked(material["preprocessing"],pins)
    baseline=nn.prior_specs.BASELINES[setting]
    for role in ("CP","CAL"):checked(baseline[role]["asset"],pins)
    for path in (Path(__file__),Path(nn.__file__),Path(nn.network.__file__),Path(nn.prior_specs.__file__)):
        pins[str(path.resolve())]=nn.sha(path)
    registry=dict(schema_version="CIC-FIT6000-fixed-forest-known-registry-before-probabilities-v1",
        configuration=policy(setting),setting=setting,output_directory=str(out),NN_report=NN_report,
        forest_report=FORESTS[setting],historical_weight_proof=MAIN_PROOF[setting],
        forest_model=forest["model"],new_NN_model=actual["files"]["model"],new_NN_preprocessor=material["preprocessing"],
        family_order=prefit["family_order"],new_NN_outputs=new_outputs,forest_cache=cache,
        new_known_material=material["features"],baseline=baseline,input_sha256=pins,
        probability_arrays_decoded=0,model_fit_or_forward=0,status="FAIL_TARGET99",published=False,final_test_executed=False)
    return json_new(out/"registry_before_cached_blend.json",registry)


def fixed_blend(nn_probability,forest_fine,weight):
    a,b=np.asarray(nn_probability),np.asarray(forest_fine)
    require(a.ndim==1 and b.shape==(len(a),9) and np.isfinite(a).all() and np.isfinite(b).all()
            and np.all((a>=0)&(a<=1)) and np.all((b>=0)&(b<=1))
            and np.allclose(b.sum(axis=1),1,rtol=0,atol=1e-12),"valid_original_cached_probabilities")
    require(weight in (.25,.75),"fixed_historical_weight_only")
    return (1-weight)*a.astype(np.float64)+weight*(1-b[:,0])


def same_ids(expected,actual,role):
    require(np.array_equal(expected,actual),"original_control_ID_order_mismatch:"+role)


def run(registry_item):
    pins={}
    registry=read(registry_item,pins)
    setting=registry["setting"]
    require(registry["configuration"]==policy(setting),"fixed_policy_changed")
    for path,wanted in registry["input_sha256"].items():checked(dict(path=path,sha256=wanted),pins)
    out=Path(registry["output_directory"])/"run"
    out.mkdir(exist_ok=False)
    report=dict(configuration=policy(setting),setting=setting,files={},
        NN_training_runs=0,forest_training_runs=0,NN_inference_runs=0,forest_inference_runs=0,
        model_deserializations=0,source_numeric_reads=0,unknown_reads=0,score_distance_DVC_runs=0,
        threshold_fit_calls=0,metrics_evaluated=False,all_original_known_gates_passed=False,
        unknown_query_allowed=False,accepted_baseline_replaced=False,status="FAIL_TARGET99",published=False,final_test_executed=False)
    started,stage=time.perf_counter(),"cached_control_identity_then_fixed_blend"
    try:
        meta,probabilities,fine_scores,forest_arrays={},{},{},{}
        with np.load(checked(registry["new_known_material"],pins),allow_pickle=False) as saved:
            for role in ("CP","CAL"):
                meta[role+"_ids"]=saved[role+"_ids"].copy()
                meta[nn.INDEX_FIELDS[role]]=saved[nn.INDEX_FIELDS[role]].copy()
        for role in ("CAL","CP"):
            with np.load(checked(registry["forest_cache"][role],pins),allow_pickle=False) as saved:
                ids=saved[role+"_ids"].copy()
                f=saved["forest_fine_probability"].copy()
            same_ids(meta[role+"_ids"],ids,role)
            with np.load(checked(registry["new_NN_outputs"][role],pins),allow_pickle=False) as saved:
                a=saved["attack_probability"].copy()
                fine=saved["fine_probability"].copy()
            require(fine.shape==f.shape and np.isfinite(fine).all() and np.all((fine>=0)&(fine<=1)),"new_NN_fine9")
            weight=WEIGHTS[setting]
            probabilities[role]=fixed_blend(a,f,weight)
            fine_scores[role]=(1-weight)*fine.astype(np.float64)+weight*f
            forest_arrays[role]=f
        report["files"]["fixed_probabilities_before_CAL_threshold"]=npz_new(out/"fixed_probabilities_before_CAL_threshold.npz",
            {**{role+"_probability":value for role,value in probabilities.items()},
             **{role+"_fixed_fine_scores":value for role,value in fine_scores.items()},
             **{role+"_ids":meta[role+"_ids"] for role in ("CP","CAL")}},pins)
        stage="one_CAL_original_threshold_after_fixed_blend_seal"
        with np.load(checked(registry["new_known_material"],pins),allow_pickle=False) as saved:cal_truth=saved["CAL_y_coarse"].copy()
        threshold,metrics=nn.network.choose_coarse_threshold(cal_truth,probabilities["CAL"])
        report["threshold_fit_calls"]=1
        report["files"]["threshold"]=json_new(out/"CAL_once_threshold_before_CP_truth.json",dict(threshold=float(threshold),selection_role="CAL_original",metrics=metrics,
            fixed_probabilities=report["files"]["fixed_probabilities_before_CAL_threshold"],fixed_forest_weight=WEIGHTS[setting],threshold_fit_calls=1,CP_truth_decoded=False),pins)
        predictions={role:(value>=threshold).astype(np.int64) for role,value in probabilities.items()}
        report["files"]["predictions_before_CP_truth"]=npz_new(out/"predictions_before_CP_truth.npz",{role+"_prediction":value for role,value in predictions.items()},pins)
        report["files"]["prediction_seal"]=json_new(out/"prediction_seal_before_CP_truth_and_prior.json",dict(predictions=report["files"]["predictions_before_CP_truth"],threshold=report["files"]["threshold"],CP_truth_decoded=False,prior_predictions_decoded=False),pins)
        stage="known_truth_and_prior_comparison_after_prediction_seal"
        gates,reporting,effect,paired_arrays={},{},{},{}
        with np.load(checked(registry["new_known_material"],pins),allow_pickle=False) as saved:
            truths={role:saved[role+"_y_coarse"].copy() for role in ("CP","CAL")}
        for role in ("CP","CAL"):
            with np.load(checked(registry["forest_cache"][role],pins),allow_pickle=False) as saved:
                require(np.array_equal(saved[role+"_truth"],truths[role]),"forest_known_truth_binding")
            prior=registry["baseline"][role]
            with np.load(checked(prior["asset"],pins),allow_pickle=False) as saved:
                same_ids(meta[role+"_ids"],saved[prior["ids"]],"baseline_"+role)
                require(np.array_equal(saved[prior["truth"]],truths[role]),"prior_known_truth_binding")
                before=saved[prior["prediction"]].copy()
            gates[role]=nn.gates(truths[role],predictions[role])
            index=meta[nn.INDEX_FIELDS[role]]
            reporting[role]=nn.gates(truths[role][index],predictions[role][index])
            effect[role]=nn.paired(truths[role],before,predictions[role])
            paired_arrays.update({role+"_ids":meta[role+"_ids"],role+"_truth":truths[role],role+"_candidate":predictions[role],role+"_baseline":before,
                role+"_gain":(before!=truths[role])&(predictions[role]==truths[role]),role+"_loss":(before==truths[role])&(predictions[role]!=truths[role])})
        report["files"]["paired_known_predictions"]=npz_new(out/"paired_known_predictions_after_seal.npz",paired_arrays,pins)
        passed=all(row["passed"] for values in gates.values() for row in values.values())
        report.update(execution_status="CIC_FIT6000_fixed_frozen_forest_known_blend_completed",metrics_evaluated=True,
            original_gates=gates,effective_reporting_gates=reporting,EffectDelta=effect,
            EffectDelta_scope="same controls, fresh extended NN plus frozen historical forest and new CAL threshold; joint protocol/model effect",
            all_original_known_gates_passed=passed,unknown_query_allowed=passed,
            failed_known_gate_reason=None if passed else "KNOWN_FOUR_INTEGER_GATES_FAILED_UNKNOWN_UNOPENED",
            complete_future_model_recipe=dict(new_NN_model=registry["new_NN_model"],new_NN_preprocessing=registry["new_NN_preprocessor"],
                frozen_native78_float32_forest=registry["forest_model"],family_order=registry["family_order"],forest_weight=WEIGHTS[setting],
                NN_probability_weight=1-WEIGHTS[setting],CAL_threshold=report["files"]["threshold"]))
        for path,wanted in pins.items():require(nn.sha(path)==wanted,"input_or_output_changed:"+path)
    except Exception as error:
        report.update(execution_status="protocol_stop" if isinstance(error,nn.old1.NativeKnownTrainingStop) else "execution_failed",
            failed_stage=stage,error_type=type(error).__name__,error_message=str(error))
    report["wall_seconds"]=time.perf_counter()-started
    report["input_sha256"]=pins
    report["registry"]=registry_item
    return json_new(out/"report.json",report)


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase",choices=("freeze","run"))
    parser.add_argument("--setting",choices=tuple(FORESTS))
    parser.add_argument("--NN-report",type=Path)
    parser.add_argument("--NN-report-sha256")
    parser.add_argument("--output-directory",type=Path)
    parser.add_argument("--registry",type=Path)
    parser.add_argument("--registry-sha256")
    args=parser.parse_args(argv)
    if args.phase=="freeze":item=freeze(args.setting,dict(path=str(args.NN_report.resolve()),sha256=args.NN_report_sha256),args.output_directory)
    else:item=run(dict(path=str(args.registry.resolve()),sha256=args.registry_sha256))
    print(json.dumps(item,ensure_ascii=False))
    if args.phase=="run":
        value=json.loads(Path(item["path"]).read_text(encoding="utf-8"))
        return 0 if value["execution_status"]=="CIC_FIT6000_fixed_frozen_forest_known_blend_completed" else 2 if value["execution_status"]=="protocol_stop" else 1
    return 0


if __name__=="__main__":raise SystemExit(main())
