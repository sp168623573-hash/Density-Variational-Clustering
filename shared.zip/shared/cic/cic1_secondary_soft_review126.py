"""A frozen secondary layer review, preserving primary126 and full3114."""
import argparse,json,sys,time,types
from pathlib import Path
import numpy as np
from . import cic1_secondary_soft_review_core_v138b as core
from . import cic1_soft_raw_affinity126_v133 as previous
from . import cic1_port_context_density126_v134 as timing_parent
ROOT,files,require=previous.ROOT,previous.files,previous.require
old=previous.old;MODULE='paper_open_set.cic1_secondary_soft_review126_v138b'
DIR=ROOT/'tmp/cic1_secondary_soft_review126_20261012_v138b';BASE=ROOT/'data/external_dev/processed/cic1_secondary_soft_review126_20261012_v138b';REG=DIR/'registry_before_known.json'
def policy():
    return dict(schema_version='CIC1-V133-frozen-primary126-secondary-soft-review-v138b',recipe=core.recipe(),hypotheses=1,actual_sentinel_schema_recovery='-2 unassessed and -1 primarynoise remain blocked; first>=0 review predicate unchanged',
        framework='originalMHFD -> frozenV133 candidate/knownanchorsoftsupport -> densityaffinityprimary126 -> supplementarysecondarynoise review',
        known_control='actualCPknown650/247 beforeconditionalfull, no role-based primary/review exemption; smallknown control not mixed stability guarantee',
        baseline='copycompleteV133whole646/247/3114 predictions including mistakes; allold2 maintained',
        extension_not_verbatim_paper=True,trueUNA_fit=False,query_parameters_fitted=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
def closure():
    found={};seen=set();todo=[sys.modules[__name__]]
    while todo:
        m=todo.pop()
        if m is None or id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if not p or not Path(p).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        found[MODULE if m is sys.modules[__name__] else m.__name__]=files.item(p)
        for value in vars(m).values():
            child=value if isinstance(value,types.ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            if child is not None:todo.append(child)
    return found
def archive(a,keys,pins):return old.archive(a,keys,pins)
def save(out,r,key,value):return old.save(out,r,key,value)
def freeze():
    began=time.perf_counter();pins={};pr=files.item(previous.REG);p=files.js(pr,pins);kr=files.item(previous.BASE/'known/report.json');cr=files.item(previous.BASE/'current/report.json');k=files.js(kr,pins);c=files.js(cr,pins)
    require(k['known_gate_passed'] and k['prediction_sealed'] and c['prediction_sealed'] and c['original_class_gates']['UNA']['correct']==3114,'existingrealpretruthgraph andcompleteprimary126 coupledwhole3114')
    a=dict(p['assets']);a.update(rule=k['files']['rule'],known_baseline=k['files']['complete_prediction_before_truth'],baseline=c['files']['complete_prediction_before_truth'])
    for role,r in [('CP',k),('current',c)]:
        a[role+'_graph']=r['files'][role+'_graph'];a[role+'_DVC']=r['files']['same126_softsupport_pluswholepred2_DVC_before_truth'];a[role+'_DVC_manifest']=r['files']['DVC_manifest'];a[role+'_seal']=r['files']['seal']
    priorclose=files.item(timing_parent.DIR/'CIC1_V134_ALLPORT_CONTEXT_3114_UNCHANGED_COMPLETED_CLOSEOUT.json');closed=files.js(priorclose,pins)
    failedref=files.item(ROOT/'tmp/cic1_secondary_soft_review126_20261012_v138/registry_before_known.json');files.js(failedref,pins)
    failedknown=files.item(ROOT/'data/external_dev/processed/cic1_secondary_soft_review126_20261012_v138/known/report.json');failure=files.js(failedknown,pins)
    require(failure['execution_status']=='execution_failed' and failure['prediction_sealed']==False and failure['truth_opened']==False and failure['current_numeric_decodes']==0,'original known schema guard failed before any newprediction/current/truth')
    failedseconds=0.
    for name in ('preflight','freeze','known'):
        observed=files.js(files.item(ROOT/('tmp/cic1_secondary_soft_review126_20261012_v138/'+name+'_actual_receipt.json')),pins);failedseconds+=observed['child_process_wall_seconds']
    src=closure();contract=core.synthetic_contract()
    for item in [*a.values(),*src.values()]:files.read(item,pins)
    require(not REG.exists() and not BASE.exists(),'exclusive fixed uniform secondaryreview recipe before numericaldecision')
    DIR.mkdir(parents=True,exist_ok=True)
    return files.write(REG,dict(policy=policy(),assets=a,sources=src,synthetic_contract=contract,source_registry=pr,source_known=kr,source_current=cr,
        timing_ancestry_closeout=priorclose,prior_preparation_seconds=closed['actual_preparation']['conservative_allprep_plus_ancestry_seconds']+failedseconds,original_failed_registry=failedref,original_failed_known=failedknown,original_failed_actual_process_seconds=failedseconds,
        freeze_seconds=time.perf_counter()-began,input_sha256=pins,current_numeric_decodes=0,new_prediction_decisions=0))
def bind(ref,pins):
    reg=files.js(ref,pins);require(reg['policy']==policy() and reg['sources']==closure(),'exactfrozen secondaryreview source/criteria/assetbytes')
    for p,s in reg['input_sha256'].items():files.read(dict(path=p,sha256=s),pins)
    return reg
def run(phase,ref,knownref=None):
    started=time.perf_counter();pins={};reg=bind(ref,pins);control=None
    if phase=='current':
        control=files.js(knownref,pins);require(control['known_gate_passed'] and control['prediction_sealed'] and control['registry']==ref,'newknowninteger admission beforecurrentsecondarydecision')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False);role='CP' if phase=='known' else 'current'
    r=dict(policy=policy(),phase=phase,registry=ref,files={},new_NN_fit=0,new_NN_forward=0,new_metric_fit=0,new_R7_fit=0,new_graph=0,new_DVC=0,new_CAL_fit=0,
        current_numeric_decodes=0,prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        a=reg['assets'];graph=archive(a[role+'_graph'],('ids','stage1','score_rows'),pins);pred=archive(a['known_baseline' if phase=='known' else 'baseline'],('ids','prediction','baseline','raw','retained'),pins)
        dvc=archive(a[role+'_DVC'],('retained','first','second','suspected'),pins);manifest=files.js(a[role+'_DVC_manifest'],pins);rule=files.js(a['rule'],pins)
        source=files.js(reg['source_known' if phase=='known' else 'source_current'],pins)
        require(source['prediction_sealed'] and np.array_equal(graph['ids'],pred['ids']),'actualfrozen pretruthsoftgraph/DVC/whole roleidentity')
        require(manifest['primary_and_secondary_same_metric'] and manifest['same_eps_minPts_secondary'] and manifest['matching_metric_state_sha256']==files.js(a['metric'],pins)['metric_payload']['state_sha256'],'actualsame126selectedprimary/secondary owner')
        r['current_numeric_decodes']=len(pred['ids']) if phase=='current' else 0
        # Rebuild the source soft raw mask using its original source baseline,
        # rather than removing cases merely because V133 alreadyretained them.
        raw=(pred['baseline']!=2)&old.cic.dvc.candidate_mask(graph['score_rows'],graph['stage1'],rule)
        require(np.array_equal(raw,pred['raw']) and np.array_equal(pred['retained'],raw&dvc['retained']),'same actualpretruthV133 raw andprimary/secondaryretained flags')
        reviews=core.review(raw,dvc['first'],dvc['suspected'],dvc['retained']);p=pred['prediction'].copy();p[reviews]=2
        require(np.all(p[pred['prediction']==2]==2) and not np.any(reviews&(dvc['first']==-1)),'old2 intact; primarynoise stays blocked for everyclass')
        values=dict(ids=pred['ids'],prediction=p,baseline=pred['prediction'],soft_raw=raw,score=graph['score_rows'],stage1=graph['stage1'],first=dvc['first'],second=dvc['second'],suspected=dvc['suspected'],old_DVC_retained=dvc['retained'],secondary_review=reviews)
        sealed=save(out,r,'complete_secondaryreview_prediction_before_truth',values)
        r['files']['seal']=files.write(out/'secondaryreview_prediction_seal_before_truth.json',dict(predictions=sealed,registry=ref,source_softgraph=a[role+'_graph'],source_DVC=a[role+'_DVC'],rule=a['rule'],querytruth_used=False));r['prediction_sealed']=True
        if phase=='known':y=archive(a['known_truth'],('CP_truth',),pins)['CP_truth']
        else:
            truth=archive(a['truth'],('ids','truth'),pins);require(np.array_equal(truth['ids'],pred['ids']),'truequery onlyafterfullnewsecondarypredictionsealed');y=truth['truth']
        r['truth_opened']=True;gates,delta,binary=old.helpers.metrics(y,pred['prediction'],p)
        r.update(execution_status='CIC1_frozen_primary_secondary_softreview_'+phase+'_completed',original_class_gates=gates,EffectDelta=delta,binary_attack_detection=binary,
            known_gate_passed=all(gates[n]['passed'] for n in ('BEN','KNA')),candidate_accepted_for_retention=False,
            secondary_review_by_trueclass={n:int(((y==c)&reviews).sum()) for c,n in enumerate(('BEN','KNA','UNA'))},
            primary_noise_softcandidate_by_trueclass={n:int(((y==c)&raw&(dvc['first']==-1)).sum()) for c,n in enumerate(('BEN','KNA','UNA'))})
        save(out,r,'postseal_complete_secondaryreview_pair',dict(**values,truth=y))
        if phase=='current':r['all_three_integer99_passed']=all(v['passed'] for v in gates.values())
        for p,s in pins.items():require(files.item(p)['sha256']==s,'original frozen graph/DVC/knownFIT/model/prediction allunchanged')
    except Exception as error:r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for key in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+key)
    a=p.parse_args();ref=None if a.registry is None else dict(path=str(Path(a.registry).resolve()),sha256=a.registry_sha256);k=None if a.known_report is None else dict(path=str(Path(a.known_report).resolve()),sha256=a.known_sha256)
    print(json.dumps(freeze() if a.phase=='freeze' else run(a.phase,ref,k)))
