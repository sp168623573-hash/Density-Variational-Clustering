"""Preparation only: CIC2-owned full78 coarse-conditioned Student3 decoder.

No training entry point, checkpoint load, model instantiation or automatic
numerical work runs on import. A future authorized driver must construct the
whole78 field map and use the pinned CIC2 plain78 checkpoint, not CIC1 weights.
"""
import torch
from torch import nn
from torch.nn import functional as F

FLOOR=1e-4
WARM_MODEL_SHA256='b6fd427f6cc113f2cee1efea4f0a9039e01c1d46b289cc638a18bb07d199c0d1'

def fixed_recipe():
    return dict(schema_version='CIC2-proposed-own5987-masked78-coarse2-Student3-final30-v65',hypotheses=1,
        warm='CIC2 own plainMHFD78 checkpoint from V48 completed fit; no CIC1 state imported; all original encoder/head/mean tensors retained as warminitialization',
        fieldmap='actual native78 numeric column ordering; externally pinned whole-original-field groups, one column each',
        mask='shared attention/gate/CNN/BiLSTM encoder with learned whole-field token; one of all78 actual fields masked, targetvalue absent from encoding',
        mean='maskedembedding32 plus trueFIT coarseonehot2 -> Linear34x64 -> GELU -> Linear64x78',
        variance='same34 -> Linear34x64 -> SiLU -> Linear64x78 -> softplusfloat32 plus fixed1e-4',
        initialization='mean first32 input columns, biases and final layer copied from actual CIC2 unconditional decoder; new conditioncolumns zero; variance head freshseeded, conditioncolumns initiallyzero; missingmasktoken and fieldmembership are explicit newstate',
        legacy_decoder='plain warmmean remains frozen in backbone; conditionalmean replaces reconstruction consumed by Student3 loss/scoring',
        loss='.1 clean coarseCE +.035 clean fineCE(smoothing.01) +1 masked-only Student3 NLL=.5log(V/3)+2log1p(residual_squared/V); fixed nu3; negativefiniteNLL retained',
        target='V=3*Student scale squared; proper conditional likelihood up to constant independent of models/rows',
        FIT_condition='only true-known coarseBEN0/KNA1, no truefine decoderinput',
        evaluation_condition='all CAL/CP/current masks use originalV46 primary stage1 predictedcoarse, never ownauxhead or querytruth',
        optimizer_rows=6000,genuine_FIT_groups=5987,Heart_genuine_FIT7=True,Heart_trainingcopies13=True,reference_density_copies=0,
        sampling='fixed truefine hierarchy .5BEN and .5/8 KNA, optimizer6000 includes13 authorized Heart copies; all78 fields balanced across each epoch; no target-label sampling',
        seed=20261011,epochs=30,batch_size=128,optimizer='AdamW .001 wd.0002 cosine30 min.0001 clip5',checkpoint='fixed final30, noCP/CAL epoch choice',
        geometry='fresh same110 native78 +newcleanembedding32, genuine5987 RMS fitted once and newEq9/10 fixed80 core with newmodel-specificschema; all genuine samefine references/R7, Heart7 notcopied',
        cue='unclipped equallyweighted mean78 actual conditional Student3 NLL; alloriginalCAL882 one originalpredcoarse finite99 only, no cutoffsearch/retry',
        DVC='fresh matching110 core for candidate/centre/affinity/reconstruction/localdensity/secondarynoise; ownraw OR preservedV46whole380 predictions',
        merge='append only newraw AND DVCretained UNA to originalV46; originalBEN/KNA coarse/fine classifiers unchanged',
        known_gate='CP/CAL882 AND reporting900 allBEN/KNA integer99 AND alloldcorrectloss0; strict noint-only currentexploration',
        inference='future CPUfloat32 eval/no_grad fixed512; fullFIT cleangeometry only, no expensive78maskedFIT sweep needed for directNLL cue; CP/CAL/current full78masked views required',
        old_history399_preserved_separately=True,no_parameter_grid=True,no_unknown_fit=True,no_training_timeout_in_code=True,
        training_started=False,weights_loaded_in_preparation=False,actual_training_seconds=None,
        status='FAIL_TARGET99',published=False,final_test_executed=False)

class CoarseConditionalWhole78MHFD(nn.Module):
    def __init__(self,backbone):
        super().__init__()
        if backbone.feature_count!=78 or backbone.field_map.width!=78 or backbone.field_map.count!=78:
            raise ValueError('externally pinned genuine whole78 numeric field map required')
        self.backbone=backbone
        self.mean_decoder=nn.Sequential(nn.Linear(34,64),nn.GELU(),nn.Linear(64,78))
        self.variance_decoder=nn.Sequential(nn.Linear(34,64),nn.SiLU(),nn.Linear(64,78))
        self.backbone.decoder.requires_grad_(False)

    def _condition(self,result,coarse):
        z=result['embedding']
        if coarse.dtype!=torch.int64 or coarse.shape!=(len(z),) or not bool(torch.isin(coarse,torch.tensor((0,1),device=coarse.device)).all()):
            raise ValueError('explicit trueFIT or unchanged originalprimary predictedcoarse0/1 required')
        conditioned=torch.cat((z,F.one_hot(coarse,num_classes=2).to(z.dtype)),dim=1)
        result['reconstruction']=self.mean_decoder(conditioned)
        raw=self.variance_decoder(conditioned)
        result.update(variance_raw=raw,variance=F.softplus(raw.float())+FLOOR,decoder_condition=coarse)
        return result

    def forward(self,x,coarse):return self._condition(self.backbone(x),coarse)

    def forward_masked(self,x,field,coarse):return self._condition(self.backbone.forward_masked(x,field),coarse)

    @torch.no_grad()
    def initialize_from_own_CIC2_plain78(self,saved,*,checkpoint_sha256):
        if checkpoint_sha256!=WARM_MODEL_SHA256 or saved['input_dim']!=78 or saved['fine_class_count']!=9:
            raise ValueError('pinned actual CIC2-only full78 checkpoint and class9 required')
        warm=saved['state_dict'];new_keys={'field_mask_tokens','field_column_membership'}
        if set(self.backbone.state_dict())-new_keys!=set(warm):raise ValueError('only new fieldmask token/membership may lack plainwarm keys')
        loaded=self.backbone.load_state_dict(warm,strict=False)
        if set(loaded.missing_keys)!=new_keys or loaded.unexpected_keys:raise ValueError('unexpected warmstate key differences')
        for key,value in warm.items():
            if not torch.equal(self.backbone.state_dict()[key],value):raise ValueError('oldCIC2 backbone warmtensor changed:'+key)
        self.mean_decoder[0].weight.zero_();self.mean_decoder[0].weight[:,:32].copy_(warm['decoder.0.weight'])
        self.mean_decoder[0].bias.copy_(warm['decoder.0.bias'])
        self.mean_decoder[2].weight.copy_(warm['decoder.2.weight']);self.mean_decoder[2].bias.copy_(warm['decoder.2.bias'])
        self.variance_decoder[0].weight[:,32:].zero_()
        self.backbone.decoder.requires_grad_(False)
        return dict(CIC2_only_state_identity_verified=True,original_backbone_warm_tensors_exact=True,
            newmasktokens_and_membership_only=True,new_conditional_mean_columns_zero=True,variance_fresh=True,
            new_variance_condition_columns_zero=True,optimizer_steps=0,NN_forward_calls=0)

def masked_objective(net,x,true_coarse,true_fine,field):
    if not torch.equal(true_coarse==0,true_fine==0):raise ValueError('knownFIT truecoarse/fine hierarchy required')
    clean=net.backbone(x);masked=net.forward_masked(x,field,true_coarse)
    hidden=masked['masked_columns'];mean=masked['reconstruction'].float();variance=masked['variance']
    NLL=.5*torch.log(variance/3.)+2.*torch.log1p((mean-x.detach()).square()/variance)
    if not bool(torch.isfinite(NLL).all()):raise ValueError('proper finite conditionalStudent3 NLL')
    likelihood=((NLL*hidden).sum(dim=1)/hidden.sum(dim=1)).mean()
    coarse=F.cross_entropy(clean['coarse_logits'],true_coarse);fine=F.cross_entropy(clean['fine_logits'],true_fine,label_smoothing=.01)
    return dict(loss=.1*coarse+.035*fine+likelihood,coarse_loss=coarse,fine_loss=fine,masked_loss=likelihood)
