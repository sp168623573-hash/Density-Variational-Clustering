"""Generic CIC1/CIC2 all78 known-only MHFD, fixed final epoch80.

``freeze(setting, material_report, output_dir=None)`` reads JSON and headers.
``run(receipt)`` is the Root-only real training/inference entry point. Every
family list and role map comes from that setting's registered all78 material.
No old weights, NSL namespace, unknown values, metric or DVC are consumed.
"""
from __future__ import annotations

import argparse
from dataclasses import fields
import hashlib
import json
import os
from pathlib import Path
import time
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler

from . import model
from . import cic2017_all_native78_known_material_v1 as material

ROOT = material.ROOT
SCHEMA = "CIC-own-all-native78-MHFD78-known-only-fixed80-v1"
SEED, EPOCHS = 20261009, 80
REPORTS = {
    "CIC Setting1": dict(path=str(ROOT / "data/external_dev/processed/cic1_all_native78_material_20261009_v1/report.json"),
                         sha256="23a660a319f28b79b3201945a45935afcb87ef0a976795ff61c2b39d0d8b7354"),
    "CIC Setting2": dict(path=str(ROOT / "data/external_dev/processed/cic2_all_native78_material_20261009_v1/report.json"),
                         sha256="54a8c2e736054dac2c1f4e0c6e7c4f4f5dfb92d4601113fc9e70fc7b9ba7277c"),
}
_BASE = ROOT / "data/external_dev/processed"
BASELINES = {
    "CIC Setting1": dict(
        report=dict(path=str(_BASE / "cic2017_native_known_forest_blend_20261008_v1/CIC_Setting1/report.json"),
                    sha256="b0cf791a2e7d49ec61c911f014e0865e1172fc13682e11cad806618f2f6ffa0a"),
        CAL=dict(asset=dict(path=str(_BASE / "cic2017_native_known_forest_blend_20261008_v1/CIC_Setting1/warm_CAL_fixed_pair_predictions.npz"),
                            sha256="72d91c3b5154c0901b991d457664bcb9c9a7b502c46a13351a89a6ca678b0aee"),
                 ids="CAL_ids", truth="CAL_truth", prediction="candidate_prediction"),
        CP=dict(asset=dict(path=str(_BASE / "cic2017_native_known_forest_blend_20261008_v1/CIC_Setting1/CP_candidates_before_selection.npz"),
                           sha256="3602cce24fef3b2bbb0892c7d512aa342be3bd56c62a3779ad3df6c45f55f50e"),
                ids="CP_ids", truth="CP_truth", prediction="w3_prediction"),
    ),
    "CIC Setting2": dict(
        report=dict(path=str(_BASE / "cic2017_setting2_signed_log_cached_blend_20261008_v1/CIC_Setting2/report.json"),
                    sha256="4286abcff8d7805e44af2d3450d8891ecdd2d43a5fa7d25ab6bd0efec17bb36d"),
        **{role: dict(asset=dict(path=str(_BASE / "cic2017_setting2_signed_log_cached_blend_20261008_v1/CIC_Setting2/paired_known_original_and_reporting_predictions.npz"),
                                 sha256="d6261dd656ebc822dcc91380ada0021a904584b8e275118d0672fbe37720cf1d"),
                      ids=role + "_ids", truth=role + "_truth", prediction=role + "_candidate") for role in ("CAL", "CP")},
    ),
}
OUTPUT_FIELDS = ("attack_probability", "fine_probability", "embedding", "reconstruction_error",
                 "gate_mean", "coarse_attack_probability", "fine_attack_probability")
POLICY = dict(
    schema_version=SCHEMA, input_width=78, original_fields=78, epochs=80, seed=SEED,
    model="new MHFDNetwork(78, len(own family_order)); default attention/gate/CNN/BiLSTM/32 embedding",
    loss="coarseCE + 0.35*fineCE(label_smoothing=0.01) + 0.03*cleanSmoothL1",
    optimizer="AdamW lr0.001 weight_decay0.0002; CosineAnnealingLR T_max80 eta_min0.0001; clip_norm5",
    batch_size=128, CPU_threads=4, sampling="hierarchical family-balanced replacement over4200 exact optimizer indices",
    checkpoint="fixed final epoch80; no per-epoch FIT/CP/CAL evaluation; no checkpoint selection",
    inference="original FIT then original CAL; save CAL-only threshold; only then original CP",
    attack_probability="fixed 0.55 coarse-head softmax attack + 0.45 (1-fine-head softmax BEN)",
    threshold="model.choose_coarse_threshold on original CAL only; no CP/FIT/unknown threshold selection",
    capture="each actual batch saves raw logits/decoder and all7 InferenceOutput fields before guards",
    reporting="original gates and copied reporting gates separate; report copies never affect calibration/inference/density",
    prior_use="stored known control predictions read only after new prediction seal, comparison only",
    old_checkpoint_transferred=False, statistic_or_encoder_fit=False,
    unknown_training_or_reads=False, score_distance_DVC_calls=0, time_limit_coded=False,
)


require = material.require


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _read(item, pins):
    path = material._checked(item["path"], item["sha256"])
    pins[str(path)] = item["sha256"]
    return json.loads(path.read_text(encoding="utf-8"))


def _pin(item, pins):
    path = material._checked(item["path"], item["sha256"])
    pins[str(path)] = item["sha256"]
    return path


def _write(out, name, value, report=None):
    path = out / (name + ".json")
    material._write_new(path, value)
    item = material.descriptor(path)
    if report is not None:
        report["files"][name] = item
    return item


def _persist(out, name, arrays, report):
    path = out / (name + ".npz")
    with path.open("xb") as stream:
        np.savez_compressed(stream, **arrays)
    item = material.descriptor(path)
    report["files"][name] = item
    return item


def freeze(setting, source_material_report, output_dir=None):
    """Metadata/header preflight only; returns a frozen Root run receipt."""
    require(setting in REPORTS and source_material_report == REPORTS[setting], "exact_own_actual_all78_material_report")
    pins = {}
    source = _read(source_material_report, pins)
    prefit = _read(source["files"]["prefit"], pins)
    encoder = _read(source["files"]["encoder"], pins)
    known_path = _pin(source["files"]["material"], pins)
    for path, wanted in source["source_pins"].items():
        _pin(dict(path=path, sha256=wanted), pins)
    original = material.REGISTRY[setting]["original_sizes"]
    families = material.REGISTRY[setting]["family_order"]
    require(source["setting"] == prefit["setting"] == encoder["setting"] == setting
            and source["execution_status"] == "own_CIC_all78_known_material_completed_before_new_model"
            and prefit["input_width"] == prefit["original_fields"] == 78
            and encoder["model_columns"] == list(material.COLUMNS) and encoder["recipe"] == material.RECIPE
            and prefit["family_order"] == families and len(families) == 9 and families[0] == "BEN"
            and prefit["original_role_sizes"] == original
            and prefit["effective_role_sizes"] == material.EFFECTIVE_SIZES
            and source["density_copy_rows"] == source["unknown_decodes"] == source["model_training_or_forward"] == 0
            and source["status"] == "FAIL_TARGET99" and source["published"] is False, "completed_own_all78_known_source_contract")
    headers = material.npz_headers(known_path)
    expected_keys = {r + "_" + k for r in material.ROLES for k in ("features", "ids", "y_fine", "y_coarse")} | set(material.INDEX_MEMBERS.values())
    require(set(headers) == expected_keys, "pure_known_material_members")
    for role in material.ROLES:
        require(headers[role + "_features"]["shape"] == [original[role], 78]
                and headers[role + "_features"]["dtype"] == "<f4"
                and headers[material.INDEX_MEMBERS[role]]["shape"] == [material.EFFECTIVE_SIZES[role]], "all78_original_roles_and_copy_headers")
    baseline = BASELINES[setting]
    old = _read(baseline["report"], pins)
    require(old["published"] is False and old["final_test_executed"] is False, "prior_known_development_only")
    if setting == "CIC Setting1":
        require(old["selected"]["weight"] == 0.75, "frozen_CIC1_w3_prior_predictions")
    for role in ("CAL", "CP"):
        path = _pin(baseline[role]["asset"], pins)
        h = material.npz_headers(path)
        require(all(h[baseline[role][k]]["shape"] == [original[role]] for k in ("ids", "truth", "prediction")), "prior_original_control_headers")
    require(tuple(field.name for field in fields(model.InferenceOutput)) == OUTPUT_FIELDS, "all7_current_inference_fields")
    number = 1 if setting == "CIC Setting1" else 2
    output = Path(output_dir or ROOT / f"data/external_dev/processed/cic{number}_all_native78_known80_20261009_v1").resolve()
    require(output.is_relative_to(ROOT) and output != ROOT and not output.exists(), "fresh_own_CIC_training_output")
    sources = {"runner": material.descriptor(__file__), "network": material.descriptor(model.__file__),
               "source_interface": material.descriptor(material.__file__)}
    registry = dict(schema_version=SCHEMA + "-registry", setting=setting, policy=POLICY,
                    family_order=families, original_role_sizes=original, effective_role_sizes=material.EFFECTIVE_SIZES,
                    source_material_report=source_material_report, material=source["files"]["material"],
                    encoder=source["files"]["encoder"], source_prefit=source["files"]["prefit"],
                    material_headers=headers, sources=sources, input_sha256=pins, baseline=baseline,
                    output_dir=str(output), real_NN_runs=0, known_numeric_decodes=0,
                    status="FAIL_TARGET99", source_admitted=False, published=False, final_test_executed=False)
    registry["registry_sha256"] = _digest(registry)
    directory = ROOT / "tmp/cic_all_native78_known80_registry_20261009_v1" / f"CIC_Setting{number}"
    directory.mkdir(parents=True, exist_ok=True)
    return _write(directory, "registry_before_actual", registry)


def _load_role(asset, role, prefit, pins):
    path = _pin(asset, pins)
    keys = [role + "_" + suffix for suffix in ("features", "ids", "y_fine", "y_coarse")] + [material.INDEX_MEMBERS[role]]
    with np.load(path, allow_pickle=False) as archive:
        values = {k: archive[k] for k in keys}
    for key, value in values.items():
        require(material._array_descriptor(value) == prefit["arrays"][key], "saved_exact_role_array:" + key)
    x, fine, coarse, ids = (values[role + "_" + k] for k in ("features", "y_fine", "y_coarse", "ids"))
    n = prefit["original_role_sizes"][role]
    require(x.shape == (n, 78) and x.dtype == np.float32 and np.isfinite(x).all()
            and fine.shape == coarse.shape == ids.shape == (n,) and fine.dtype == coarse.dtype == np.int64
            and np.all((fine >= 0) & (fine < len(prefit["family_order"])))
            and np.array_equal(coarse, (fine != 0).astype(np.int64)) and len(set(ids.tolist())) == n, "typed_original_role:" + role)
    indices = values[material.INDEX_MEMBERS[role]]
    require(indices.dtype == np.int64 and len(indices) == material.EFFECTIVE_SIZES[role]
            and np.array_equal(indices[:n], np.arange(n)) and np.all((indices >= 0) & (indices < n)), "exact_optimizer_or_report_indices:" + role)
    require(np.bincount(fine[indices], minlength=len(prefit["family_order"])).min() >= 20, "existing_effective_family_floor20")
    return values


def _balanced_weights(fine, family_order):
    require(len(family_order) == 9 and family_order[0] == "BEN" and set(fine.tolist()) == set(range(len(family_order))), "explicit_own_families")
    counts = np.bincount(fine, minlength=len(family_order))
    mass = np.asarray([0.5] + [0.5 / (len(family_order) - 1)] * (len(family_order) - 1))
    return torch.from_numpy((mass / counts)[fine].astype(np.float64))


def fit_fixed80(features, coarse, fine, family_order):
    """Only optimizer FIT is accepted here; no CP/CAL arguments or forwards."""
    require(features.shape == (4200, 78) and coarse.shape == fine.shape == (4200,), "exact4200_FIT_optimizer_view")
    model.set_seed(SEED)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    net = model.MHFDNetwork(78, len(family_order)).to(device)
    sampler = WeightedRandomSampler(_balanced_weights(fine, family_order), num_samples=4200, replacement=True,
                                    generator=torch.Generator().manual_seed(SEED))
    loader = DataLoader(TensorDataset(torch.from_numpy(features), torch.from_numpy(coarse), torch.from_numpy(fine)),
                        batch_size=128, sampler=sampler, num_workers=0, pin_memory=device.type == "cuda")
    optimizer = torch.optim.AdamW(net.parameters(), lr=0.001, weight_decay=0.0002)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=80, eta_min=0.0001)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    coarse_loss = nn.CrossEntropyLoss()
    fine_loss = nn.CrossEntropyLoss(label_smoothing=0.01)
    clean_loss = nn.SmoothL1Loss()
    started, history = time.perf_counter(), []
    for epoch in range(1, 81):
        net.train()
        total, rows = 0.0, 0
        for x, c, f in loader:
            x, c, f = x.to(device), c.to(device), f.to(device)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=device.type == "cuda"):
                output = net(x)
                loss = coarse_loss(output["coarse_logits"], c) + 0.35 * fine_loss(output["fine_logits"], f) + 0.03 * clean_loss(output["reconstruction"], x)
            require(torch.isfinite(loss).item(), "finite_actual_CIC_all78_training_loss")
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            nn.utils.clip_grad_norm_(net.parameters(), 5.0)
            scaler.step(optimizer)
            scaler.update()
            total += float(loss.detach()) * len(x)
            rows += len(x)
        scheduler.step()
        history.append(dict(epoch=epoch, loss=total / rows, learning_rate=scheduler.get_last_lr()[0]))
        if epoch == 1 or epoch % 10 == 0:
            print(f"[CIC own78 fixed80] epoch={epoch}/80 loss={total / rows:.6f} elapsed={time.perf_counter() - started:.1f}s", flush=True)
    return SimpleNamespace(model=net, device=str(device), history=history, training_seconds=time.perf_counter() - started)


def state_digest(net):
    digest = hashlib.sha256()
    for name, tensor in sorted(net.state_dict().items()):
        value = tensor.detach().cpu().numpy()
        digest.update(name.encode())
        digest.update(value.dtype.str.encode())
        digest.update(json.dumps(list(value.shape)).encode())
        digest.update(value.tobytes(order="C"))
    return digest.hexdigest()


@torch.no_grad()
def infer_original(net, features, device, role, output_dir, report, family_order, batch_size=2048):
    """Persist each returned batch's raw tensors and all seven derived fields."""
    net.eval()
    device = torch.device(device)
    pieces = {name: [] for name in (*OUTPUT_FIELDS, "coarse_logits", "fine_logits", "reconstruction")}
    report["counts"]["known_infer_attempts"] += 1
    for index, start in enumerate(range(0, len(features), batch_size)):
        batch = torch.from_numpy(features[start:start + batch_size]).to(device)
        with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=device.type == "cuda"):
            returned = net(batch)
        # First preserve raw returned tensors, before probability math or guards.
        raw = {name: returned[name].detach().float().cpu().numpy().copy()
               for name in ("coarse_logits", "fine_logits", "reconstruction", "embedding", "gate_mean")}
        _persist(output_dir, f"{role}_raw_batch{index}_before_guard", raw, report)
        coarse = torch.softmax(returned["coarse_logits"], dim=1)[:, 1]
        fine_probability = torch.softmax(returned["fine_logits"], dim=1)
        fine = 1.0 - fine_probability[:, 0]
        tensors = dict(attack_probability=0.55 * coarse + 0.45 * fine, fine_probability=fine_probability,
                       embedding=returned["embedding"], reconstruction_error=torch.mean((returned["reconstruction"].float() - batch.float()) ** 2, dim=1),
                       gate_mean=returned["gate_mean"], coarse_attack_probability=coarse, fine_attack_probability=fine)
        values = {name: tensor.detach().float().cpu().numpy().copy() for name, tensor in tensors.items()}
        values.update({k: raw[k] for k in ("coarse_logits", "fine_logits", "reconstruction")})
        _persist(output_dir, f"{role}_complete_batch{index}_before_guard", values, report)
        report["counts"]["known_forward_batches"] += 1
        n = len(batch)
        require(all(len(v) == n and np.isfinite(v).all() for v in values.values())
                and values["fine_probability"].shape == (n, len(family_order))
                and values["embedding"].shape == (n, 32) and values["reconstruction"].shape == (n, 78)
                and values["coarse_logits"].shape == (n, 2) and values["fine_logits"].shape == (n, len(family_order)), "complete_own_inference_batch_shapes")
        require(all(np.all((values[k] >= 0) & (values[k] <= 1)) for k in ("attack_probability", "fine_probability", "coarse_attack_probability", "fine_attack_probability"))
                and np.allclose(values["fine_probability"].sum(axis=1), 1.0, atol=2e-3), "returned_probability_fields")
        for name, value in values.items():
            pieces[name].append(value)
    values = {name: np.concatenate(parts) for name, parts in pieces.items()}
    values["embedding32"] = values["embedding"].copy()
    _persist(output_dir, role + "_complete_inference_before_guard", values, report)
    result = model.InferenceOutput(**{name: values[name] for name in OUTPUT_FIELDS})
    report["counts"]["known_infer_returns"] += 1
    return result


def gates(truth, prediction):
    return {name: dict(correct=int(np.sum((truth == label) & (prediction == label))), support=int(np.sum(truth == label)),
                       required_correct=(99 * int(np.sum(truth == label)) + 99) // 100,
                       passed=bool(np.sum(truth == label) and 100 * np.sum((truth == label) & (prediction == label)) >= 99 * np.sum(truth == label)))
            for label, name in enumerate(("BEN", "KNA"))}


def _paired_effect(previous, candidate, truth):
    old, new = gates(truth, previous), gates(truth, candidate)
    delta = {name: new[name]["correct"] - old[name]["correct"] for name in old}
    verdict = ("UP" if all(d >= 0 for d in delta.values()) and any(delta.values()) else
               "DOWN" if all(d <= 0 for d in delta.values()) and any(delta.values()) else
               "UNCHANGED" if not any(delta.values()) else "MIXED")
    return dict(verdict=verdict, correct_count_delta=delta, prior=old, candidate=new,
                gain=int(np.sum((previous != truth) & (candidate == truth))),
                loss=int(np.sum((previous == truth) & (candidate != truth))),
                same_original_IDs_and_order=True, scope="known original controls; no UNA or final evidence")


def run(receipt):
    """Root-only actual new training; checkpoint → FIT/CAL → seal theta → CP."""
    pins = {}
    registry = _read(receipt, pins)
    unsigned = dict(registry)
    signature = unsigned.pop("registry_sha256")
    setting = registry["setting"]
    require(signature == _digest(unsigned) and registry["schema_version"] == SCHEMA + "-registry"
            and registry["policy"] == POLICY and registry["source_material_report"] == REPORTS[setting]
            and registry["family_order"] == material.REGISTRY[setting]["family_order"]
            and registry["baseline"] == BASELINES[setting], "exact_frozen_own_CIC_training_registry")
    for item in registry["sources"].values():
        _pin(item, pins)
    require(registry["sources"]["runner"] == material.descriptor(__file__)
            and registry["sources"]["network"] == material.descriptor(model.__file__), "exact_current_generic_runner_and_network")
    for path, wanted in registry["input_sha256"].items():
        _pin(dict(path=path, sha256=wanted), pins)
    if torch.cuda.is_available():
        require(os.environ.get("CUBLAS_WORKSPACE_CONFIG") in (":4096:8", ":16:8"), "Root_must_set_CUBLAS_WORKSPACE_CONFIG_before_launch")
    output = Path(registry["output_dir"]).resolve()
    require(output.is_relative_to(ROOT) and output != ROOT and not output.exists(), "fresh_training_output_required")
    output.mkdir(parents=True)
    started = time.perf_counter()
    report = dict(schema_version=SCHEMA, setting=setting, registry=receipt, policy=POLICY, files={},
                  execution_status="not_completed", counts=dict(training_runs=0, known_infer_attempts=0, known_infer_returns=0, known_forward_batches=0, unknown_forward=0),
                  runtime_environment=dict(CUBLAS_WORKSPACE_CONFIG=os.environ.get("CUBLAS_WORKSPACE_CONFIG"), torch_version=torch.__version__),
                  source_admitted=False, accepted_baseline_replaced=False, unknown_numeric_decodes=0, score_distance_DVC_calls=0,
                  status="FAIL_TARGET99", published=False, final_test_executed=False)
    stage = "registered_original_FIT_only_decode"
    try:
        prefit = _read(registry["source_prefit"], pins)
        arrays = _load_role(registry["material"], "FIT", prefit, pins)
        optimizer_indices = arrays["FIT_training_indices"]
        _write(output, "training_policy_before_fit", dict(policy=POLICY, family_order=registry["family_order"],
               original_role_sizes=registry["original_role_sizes"], effective_role_sizes=registry["effective_role_sizes"],
               encoder=registry["encoder"], material=registry["material"], optimizer_indices=material._array_descriptor(optimizer_indices),
               input_sha256=pins, no_CP_CAL_training_forward=True, runtime_environment=report["runtime_environment"]), report)
        stage = "one_new_own_CIC_MHFD78_fixed80_training"
        torch.set_num_threads(4)
        report["counts"]["training_runs"] = 1
        fitted = fit_fixed80(arrays["FIT_features"][optimizer_indices], arrays["FIT_y_coarse"][optimizer_indices], arrays["FIT_y_fine"][optimizer_indices], registry["family_order"])
        state_hash = state_digest(fitted.model)
        checkpoint = output / "new_all78_known_fixed80_MHFD78.pt"
        torch.save(dict(state_dict={k: v.detach().cpu() for k, v in fitted.model.state_dict().items()}, model_class="MHFDNetwork",
                        input_dim=78, fine_classes=registry["family_order"], epochs_completed=80, seed=SEED, model_state_sha256=state_hash), checkpoint)
        report["files"]["model"] = material.descriptor(checkpoint)
        _write(output, "actual_training_history80", fitted.history, report)
        report.update(training_seconds=fitted.training_seconds, training_device=fitted.device, epochs_completed=80, model_state_sha256=state_hash)
        outputs = {}
        stage = "original_FIT_inference_after_checkpoint_save"
        outputs["FIT"] = infer_original(fitted.model, arrays["FIT_features"], fitted.device, "FIT", output, report, registry["family_order"])
        stage = "original_CAL_decode_and_inference_after_checkpoint_save"
        arrays.update(_load_role(registry["material"], "CAL", prefit, pins))
        outputs["CAL"] = infer_original(fitted.model, arrays["CAL_features"], fitted.device, "CAL", output, report, registry["family_order"])
        threshold, calibration_metrics = model.choose_coarse_threshold(arrays["CAL_y_coarse"], outputs["CAL"].attack_probability)
        _write(output, "knownCAL_threshold_before_CP", dict(threshold=float(threshold), model=report["files"]["model"],
               original_CAL_IDs=material._array_descriptor(arrays["CAL_ids"]), calibration_metrics=calibration_metrics,
               threshold_roles=["CAL"], CP_numeric_opened=False, CP_truth_used_for_selection=False), report)
        stage = "original_CP_decode_and_inference_after_CAL_threshold_seal"
        arrays.update(_load_role(registry["material"], "CP", prefit, pins))
        outputs["CP"] = infer_original(fitted.model, arrays["CP_features"], fitted.device, "CP", output, report, registry["family_order"])
        all_ids = [sid for role in material.ROLES for sid in arrays[role + "_ids"].tolist()]
        require(len(all_ids) == len(set(all_ids)) == sum(registry["original_role_sizes"].values()), "cross_role_original_ID_isolation")
        predictions = {role + "_prediction": (out.attack_probability >= threshold).astype(np.int64) for role, out in outputs.items()}
        predictions.update({role + "_ids": arrays[role + "_ids"] for role in outputs})
        _persist(output, "complete_known_predictions_before_prior", predictions, report)
        _write(output, "known_prediction_seal_before_prior", dict(model=report["files"]["model"], threshold=report["files"]["knownCAL_threshold_before_CP"],
               predictions=report["files"]["complete_known_predictions_before_prior"], prior_forecasts_opened=False), report)
        original_gates, reporting_gates, effects = {}, {}, {}
        for role in material.ROLES:
            truth, prediction = arrays[role + "_y_coarse"], predictions[role + "_prediction"]
            original_gates[role] = gates(truth, prediction)
            indices = arrays[material.INDEX_MEMBERS[role]]
            reporting_gates[role] = gates(truth[indices], prediction[indices])
        for role in ("CAL", "CP"):
            baseline = registry["baseline"][role]
            path = _pin(baseline["asset"], pins)
            with np.load(path, allow_pickle=False) as archive:
                prior = {name: archive[baseline[name]] for name in ("ids", "truth", "prediction")}
            require(np.array_equal(prior["ids"], arrays[role + "_ids"]) and np.array_equal(prior["truth"], arrays[role + "_y_coarse"]), "same_known_control_ID_and_truth_order")
            effects[role] = _paired_effect(prior["prediction"], predictions[role + "_prediction"], prior["truth"])
        require(state_digest(fitted.model) == state_hash, "new_model_state_frozen_through_known_inference")
        report.update(execution_status="own_CIC_all78_fixed80_known_training_and_original_CAL_CP_completed",
                      original_class_gates=original_gates, reporting_class_gates=reporting_gates, EffectDelta=effects,
                      coarse_threshold=float(threshold), CP_passed=all(v["passed"] for v in original_gates["CP"].values()),
                      CAL_passed=all(v["passed"] for v in original_gates["CAL"].values()),
                      original_role_sizes=registry["original_role_sizes"], effective_role_sizes=registry["effective_role_sizes"],
                      density_copy_rows=0, known_effective_cap=6000, unknown_performance_measured=False,
                      no_new_single_model_or_group99_gate=True, promotion_status="NOT_AUTOMATICALLY_PROMOTED")
        for path, wanted in pins.items():
            require(material.sha(path) == wanted, "all_bound_input_bytes_preserved")
    except Exception as error:
        report.update(execution_status="execution_failed", failed_stage=stage, error_type=type(error).__name__, error=str(error))
        raise
    finally:
        report["input_sha256"] = pins
        report["wall_seconds"] = time.perf_counter() - started
        _write(output, "report", report)
    return material.descriptor(output / "report.json")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    preflight = commands.add_parser("freeze")
    preflight.add_argument("--setting", choices=tuple(REPORTS), required=True)
    preflight.add_argument("--output", type=Path)
    execution = commands.add_parser("run")
    execution.add_argument("--registry", type=Path, required=True)
    execution.add_argument("--registry-sha256", required=True)
    args = parser.parse_args()
    result = (freeze(args.setting, REPORTS[args.setting], args.output) if args.command == "freeze" else
              run(dict(path=str(args.registry.resolve()), sha256=args.registry_sha256)))
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
