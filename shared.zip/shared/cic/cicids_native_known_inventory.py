"""Pinned native CIC2017 known-capacity inventory, not training admission.

The source Arrow label filter precedes conversion to pandas/NumPy. Arrow can
decompress pages containing unknown records; no unknown numeric record enters
the Python feature arrays. Only known feature digests and counts are persisted.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import importlib
import json
from pathlib import Path
import sqlite3
import sys
import time

import numpy as np

from .config import CIC_FEATURE_COLUMNS, SETTINGS
from .cic2017_identity_bridge import _canonical_matrix, _feature_fingerprints

ROOT = Path(__file__).resolve().parents[1]
BATCH_SIZE = 16384
SETTING_NAMES = ("CIC Setting1", "CIC Setting2")
SOURCE_DIR = "data/external_dev/raw/cicids2017_traffic_labels_parquet"
SOURCE_SPECS = (
    ("Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv.parquet", "7c5876d52189fc01af54bad6cf23afe9f7fbc0e3ca6c3595920754f0c3ba8f66", 225745),
    ("Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv.parquet", "4d78cee297c27f1a9947b9384793e587a46c7a3ea89db199553dabddc9835d4a", 286467),
    ("Friday-WorkingHours-Morning.pcap_ISCX.csv.parquet", "2c00236b13a69f4b1c222b8f4a89451dc2148cb04a8cd0c45c2a87af51471774", 191033),
    ("Monday-WorkingHours.pcap_ISCX.csv.parquet", "dfdcef4b8670e52af54dc4f82174834365a393473e877174cca46d17b12dfd02", 529918),
    ("Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv.parquet", "5da010354f0fc1040fd1fe65967096e1063475de8dd30ae4f657c07201d728a7", 288602),
    ("Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv.parquet", "d8110c04a7af91124ada1c5ad901c4210879df1af8882dc637767532e7165350", 458968),
    ("Tuesday-WorkingHours.pcap_ISCX.csv.parquet", "27e83d518cb093faefd0f883cb4df3ad8b353f150934004f28d0e7962f9f31c4", 445909),
    ("Wednesday-workingHours.pcap_ISCX.csv.parquet", "d23a259820b16e1ad54f9f3b58d5727c5032d383015f90bc7c07cebbdf8a7140", 692703),
)
METADATA_REL = "tmp/cic2017_native_known_source_design_20261008_v1/metadata_audit.json"
METADATA_SHA = "1a6a038c4c07f4b2c715768a7d03016ea242373e775dd247f7b16c2b1be74b47"
EXCLUSION_REL = "tmp/cic2017_frozen_candidate_superset_exclusion_20261001_v1.json"
EXCLUSION_SHA = "18aa5e14e078203e0e95d0bf221d87e1bd50e186f21b892a9e45d0499b884070"
EXCLUSION_SCHEMA = "cic2017-label-blind-complete-frozen-candidate-superset-exclusion-v1"
CODE_PINS = {
    "paper_open_set/cic2017_identity_bridge.py": "8a071d412e7ac4ddcd0eacc4ccf3aae740963ada512f3ce5b69b563fa3791a98",
    "paper_open_set/config.py": "a2b5a95cefc550395ba45004f1d036172a03f8b99542c38b0e3ee5ca64c80972",
    "paper_open_set/data.py": "a6274758c3940c0f0d7e32e307183a7deeed05bc67b8203c8f16524bac1a0c5c",
}
PROVENANCE_PINS = {
    "data/external_dev/raw/cic2017_mirror_conversion_origin_20261005_v1/receipt.json": "9a489407c47e0fd2852d8f9d172a037b6f0a26fb8ad5ec240b34e526ec6aad97",
    "data/external_dev/raw/cic2017_mirror_conversion_origin_20261005_v1/README.md": "5a4d4884c9c86675c65c89dfa4c4aa7201ed67a577677df16b56eb9c0edcc486",
}
POLICY = {
    "schema_version": "CIC2017-native-known-capacity-inventory-v1",
    "settings": list(SETTING_NAMES), "batch_rows_maximum": BATCH_SIZE,
    "mirror_commit": "70bac6246d99cf046186a02e1cce6883e2ffe7ea",
    "source_provenance": "third-party fixed conversion of publisher TrafficLabelling CSV; NOT publisher-original-byte authentication",
    "canonical78": "existing identity_bridge float64 little-endian C rows; no decimal rounding/tolerance; numeric conversion errors become NaN; signed zero and NaN payloads normalized; +/-Inf retained and counted nonfinite; SHA256 of each 624-byte row",
    "exclusion": "fixed all5800 native(file SHA, zero-based row ordinal) superset, then exact canonical78 closure within each setting's known records only",
    "old78_exact_feature_keys_available": False,
    "extra_five_tuple_exclusion_applied": False,
    "all_historical_exposure_exhaustively_excluded_claimed": False,
    "source_label_column_routing_required_in_Arrow": True,
    "unknown_numeric_for_current_setting_pandas_NumPy_materialized": False,
    "information_scope": "separate per-setting known inventories; a family unknown in one setting may legitimately be known in the other; no shared cross-setting feature closure or parameter selection",
    "Arrow_may_decompress_pages_containing_unknown_records": True,
    "identity_fields_in_model_features": False,
    "feature_group_store": "SQLite on disk, 16MiB page cache; no full-dataset feature matrix",
    "nonfinite_policy": "count and fingerprint; exclude from finite capacity, no imputation or fitted transform",
    "cross_family_conflicts": "report; unambiguous finite capacity excludes every conflicting group",
    "no_training_roles_assigned": True, "no_source_family_20_unique_gate": True,
    "source_or_DEV_or_final_admission_issued": False,
    "physical_event_independence_claimed": False,
    "model_training_or_inference_or_DVC": False,
    "target_Test_file_opened": False, "DEV_executed": False,
    "final_test_executed": False, "status": "FAIL_TARGET99", "published": False,
}


class NativeKnownInventoryStop(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise NativeKnownInventoryStop(reason)


def sha(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def _write_json(path, value):
    with Path(path).open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        handle.write("\n")
    return {"path": str(Path(path).resolve()), "sha256": sha(path)}


def _pin(relative, wanted, pins):
    path = (ROOT / relative).resolve()
    require(path.is_relative_to(ROOT) and path != ROOT, "pinned_path_outside_workspace")
    require(sha(path) == wanted, "input_pin_changed:" + relative)
    require(pins.get(str(path), wanted) == wanted, "conflicting_input_pin")
    pins[str(path)] = wanted
    return path


def _validate_exclusion(value, specs=SOURCE_SPECS):
    require(value.get("schema_version") == EXCLUSION_SCHEMA
            and value.get("frozen_rows_covered") == 5800
            and value.get("source_rows_scanned") == sum(r[2] for r in specs)
            and value.get("all_previous_unique_identities_excluded") is True
            and value.get("all_previous_verified_candidate_count_lower_bounds_covered") is True
            and value.get("ambiguous_frozen_identities_guessed") is False
            and value.get("exclusion_superset_not_exact_identity_resolution") is True
            and value.get("source_labels_read") is False
            and value.get("frozen_csv_opened") is False
            and value.get("published") is False, "fixed_complete_label_blind_exclusion_contract")
    expected = {name: (digest, rows) for name, digest, rows in specs}
    require(len(value.get("sources", [])) == len(expected), "exclusion_source_count")
    result = {}
    for item in value["sources"]:
        path = Path(item["source"]["path"]).resolve()
        name = path.name
        require(name in expected and name not in result
                and path == (ROOT / SOURCE_DIR / name).resolve(), "exclusion_exact_source_path")
        digest, rows = expected[name]
        require(item["source"]["sha256"] == digest and item["rows_scanned"] == rows,
                "exclusion_source_SHA_or_row_count")
        positions = item["candidate_source_row_indices"]
        require(type(positions) is list and all(type(i) is int and 0 <= i < rows for i in positions)
                and positions == sorted(set(positions))
                and item["invariant_superset_candidate_rows"] == len(positions),
                "exclusion_sorted_unique_zero_based_ordinals")
        result[name] = frozenset(positions)
    require(set(result) == set(expected), "complete_eight_source_exclusion")
    return result


def _load_fixed_inputs(pins):
    for relative, wanted in {**CODE_PINS, **PROVENANCE_PINS}.items():
        _pin(relative, wanted, pins)
    pins[str(Path(__file__).resolve())] = sha(__file__)
    metadata = json.loads(_pin(METADATA_REL, METADATA_SHA, pins).read_text(encoding="utf-8"))
    require(tuple(metadata["model_columns_in_exact_order"]) == CIC_FEATURE_COLUMNS,
            "metadata_exact78_column_order")
    expected = {name: (digest, rows) for name, digest, rows in SOURCE_SPECS}
    footer_refs = {}
    for item in metadata["sources"]:
        path = Path(item["path"]).resolve()
        require(path.name in expected and path.name not in footer_refs
                and path == (ROOT / SOURCE_DIR / path.name).resolve(), "metadata_exact_source_path")
        require((item["sha256"], item["rows_from_footer"]) == expected[path.name],
                "metadata_source_SHA_or_rows")
        footer_refs[path.name] = item
    require(set(footer_refs) == set(expected), "metadata_complete_eight_sources")
    exclusion = json.loads(_pin(EXCLUSION_REL, EXCLUSION_SHA, pins).read_text(encoding="utf-8"))
    excluded = _validate_exclusion(exclusion)
    for name, digest, _ in SOURCE_SPECS:
        _pin(SOURCE_DIR + "/" + name, digest, pins)
    return footer_refs, excluded


def _load_arrow(pins):
    runtime = ROOT / "tmp/pyarrow_wheel_expanded_20260926_v1"
    require(runtime.is_dir(), "registered_offline_Arrow_runtime_missing")
    sys.path.insert(0, str(runtime))
    arrow = importlib.import_module("pyarrow")
    pq = importlib.import_module("pyarrow.parquet")
    pc = importlib.import_module("pyarrow.compute")
    require(arrow.__version__ == "25.0.1" and Path(arrow.__file__).resolve().is_relative_to(runtime.resolve()),
            "registered_offline_Arrow_runtime_required")
    for module in (arrow, pq, pc, importlib.import_module("pyarrow.lib"),
                   importlib.import_module("pyarrow.parquet.core"), importlib.import_module("pyarrow._compute")):
        path = Path(module.__file__).resolve()
        require(path.is_relative_to(runtime.resolve()), "offline_Arrow_consumer_path")
        pins[str(path)] = sha(path)
    return arrow, pq, pc


def _create_store(path):
    require(not Path(path).exists(), "new_SQLite_store_required")
    connection = sqlite3.connect(path)
    connection.execute("PRAGMA temp_store=FILE")
    connection.execute("PRAGMA cache_size=-16384")
    connection.execute("""CREATE TABLE feature_families(
        setting TEXT NOT NULL, fingerprint TEXT NOT NULL, family TEXT NOT NULL,
        finite INTEGER NOT NULL CHECK(finite IN (0,1)), n INTEGER NOT NULL,
        direct_excluded INTEGER NOT NULL,
        PRIMARY KEY(setting,fingerprint,family)) WITHOUT ROWID""")
    return connection


def _consume_batch(connection, batch, *, setting, offset, excluded_ordinals, arrow, pc):
    """Filter native labels in Arrow before any Python numeric conversion."""
    require(setting in SETTING_NAMES and type(offset) is int and offset >= 0
            and 0 <= batch.num_rows <= BATCH_SIZE, "bounded_known_batch_contract")
    spec = SETTINGS[setting]
    labels = (spec.benign_label, *spec.known_families)
    mask = pc.is_in(batch.column("Label"), value_set=arrow.array(labels))
    # Only source positions, not source numeric features, are materialized here.
    positions = pc.indices_nonzero(mask).to_numpy(zero_copy_only=False)
    selected = batch.filter(mask)
    require(selected.num_rows == len(positions), "known_filter_position_alignment")
    if not len(positions):
        return Counter()
    selected_labels = selected.column("Label").to_pylist()
    require(all(value in labels for value in selected_labels), "known_whitelist_before_numeric_conversion")
    frame = selected.select(list(CIC_FEATURE_COLUMNS)).to_pandas()
    matrix = _canonical_matrix(frame)
    require(matrix.shape == (len(positions), 78) and matrix.dtype == np.dtype("<f8"),
            "known_canonical78_float64")
    fingerprints = _feature_fingerprints(matrix)
    finite = np.isfinite(matrix).all(axis=1)
    grouped, source_counts = {}, Counter()
    for local, label, fingerprint, is_finite in zip(positions, selected_labels, fingerprints, finite):
        family = "BEN" if label == spec.benign_label else label
        key = (str(fingerprint), family)
        excluded = int(offset + int(local) in excluded_ordinals)
        state = grouped.setdefault(key, [int(is_finite), 0, 0])
        require(state[0] == int(is_finite), "canonical_digest_finiteness_conflict")
        state[1] += 1
        state[2] += excluded
        source_counts[family] += 1
    connection.executemany("""INSERT INTO feature_families VALUES(?,?,?,?,?,?)
        ON CONFLICT(setting,fingerprint,family) DO UPDATE SET
        n=feature_families.n+excluded.n,
        direct_excluded=feature_families.direct_excluded+excluded.direct_excluded,
        finite=CASE WHEN feature_families.finite=excluded.finite THEN excluded.finite ELSE -1 END""",
        [(setting, fingerprint, family, *counts) for (fingerprint, family), counts in grouped.items()])
    return source_counts


METRIC_SQL = {
    "source_known_rows": "SUM(f.n)",
    "source_finite_rows": "SUM(CASE WHEN f.finite=1 THEN f.n ELSE 0 END)",
    "source_nonfinite_rows": "SUM(CASE WHEN f.finite=0 THEN f.n ELSE 0 END)",
    "direct_ordinal_excluded_rows": "SUM(f.direct_excluded)",
    "direct_ordinal_excluded_finite_rows": "SUM(CASE WHEN f.finite=1 THEN f.direct_excluded ELSE 0 END)",
    "direct_ordinal_excluded_nonfinite_rows": "SUM(CASE WHEN f.finite=0 THEN f.direct_excluded ELSE 0 END)",
    "same_feature_closure_additional_excluded_rows": "SUM(CASE WHEN g.blocked=1 THEN f.n-f.direct_excluded ELSE 0 END)",
    "same_feature_closure_additional_excluded_finite_rows": "SUM(CASE WHEN g.blocked=1 AND f.finite=1 THEN f.n-f.direct_excluded ELSE 0 END)",
    "same_feature_closure_additional_excluded_nonfinite_rows": "SUM(CASE WHEN g.blocked=1 AND f.finite=0 THEN f.n-f.direct_excluded ELSE 0 END)",
    "total_excluded_rows": "SUM(CASE WHEN g.blocked=1 THEN f.n ELSE 0 END)",
    "remaining_rows": "SUM(CASE WHEN g.blocked=0 THEN f.n ELSE 0 END)",
    "remaining_finite_rows": "SUM(CASE WHEN g.blocked=0 AND f.finite=1 THEN f.n ELSE 0 END)",
    "remaining_nonfinite_rows": "SUM(CASE WHEN g.blocked=0 AND f.finite=0 THEN f.n ELSE 0 END)",
    "source_unique_feature_groups": "COUNT(*)",
    "remaining_unique_feature_groups": "SUM(g.blocked=0)",
    "remaining_finite_unique_feature_groups": "SUM(g.blocked=0 AND f.finite=1)",
    "remaining_nonfinite_unique_feature_groups": "SUM(g.blocked=0 AND f.finite=0)",
    "cross_family_groups_before_exclusion": "SUM(g.family_count>1)",
    "cross_coarse_groups_before_exclusion": "SUM(g.coarse_count>1)",
    "cross_family_groups_after_exclusion": "SUM(g.blocked=0 AND g.family_count>1)",
    "cross_coarse_groups_after_exclusion": "SUM(g.blocked=0 AND g.coarse_count>1)",
    "cross_family_rows_after_exclusion": "SUM(CASE WHEN g.blocked=0 AND g.family_count>1 THEN f.n ELSE 0 END)",
    "cross_coarse_rows_after_exclusion": "SUM(CASE WHEN g.blocked=0 AND g.coarse_count>1 THEN f.n ELSE 0 END)",
    "unambiguous_finite_rows": "SUM(CASE WHEN g.blocked=0 AND f.finite=1 AND g.family_count=1 THEN f.n ELSE 0 END)",
    "unambiguous_finite_unique_feature_groups": "SUM(g.blocked=0 AND f.finite=1 AND g.family_count=1)",
}


def _summarize(connection):
    mismatch = connection.execute("""SELECT 1 FROM feature_families GROUP BY setting,fingerprint
        HAVING MIN(finite) != MAX(finite) LIMIT 1""").fetchone()
    require(mismatch is None, "canonical_digest_cross_family_finiteness_conflict")
    connection.execute("""CREATE TABLE feature_groups AS SELECT setting,fingerprint,
        MAX(direct_excluded>0) AS blocked,COUNT(*) AS family_count,
        COUNT(DISTINCT CASE WHEN family='BEN' THEN 0 ELSE 1 END) AS coarse_count
        FROM feature_families GROUP BY setting,fingerprint""")
    connection.execute("CREATE UNIQUE INDEX feature_group_key ON feature_groups(setting,fingerprint)")
    query = "SELECT f.setting,f.family," + ",".join(METRIC_SQL.values()) + """
        FROM feature_families AS f JOIN feature_groups AS g
        ON f.setting=g.setting AND f.fingerprint=g.fingerprint GROUP BY f.setting,f.family"""
    families = {s: {f: {key: 0 for key in METRIC_SQL} for f in ("BEN", *SETTINGS[s].known_families)}
                for s in SETTING_NAMES}
    for setting, family, *values in connection.execute(query):
        require(setting in families and family in families[setting], "stored_known_family_whitelist")
        families[setting][family] = dict(zip(METRIC_SQL, map(int, values)))
    output = {}
    for setting in SETTING_NAMES:
        for counts in families[setting].values():
            require(counts["source_known_rows"] == counts["total_excluded_rows"] + counts["remaining_rows"],
                    "known_capacity_row_accounting")
            counts["positive_source_after_exclusion_and_conflict_filter"] = counts["unambiguous_finite_unique_feature_groups"] > 0
            counts["role_support_or_floor20_admission_issued"] = False
        overall = connection.execute("""SELECT COUNT(*),SUM(blocked=1),SUM(family_count>1),
            SUM(coarse_count>1),SUM(blocked=0 AND family_count>1),SUM(blocked=0 AND coarse_count>1)
            FROM feature_groups WHERE setting=?""", (setting,)).fetchone()
        output[setting] = {"families": families[setting], "whole_setting_group_counts": dict(zip(
            ("source_unique_groups", "excluded_unique_groups", "cross_family_before_exclusion",
             "cross_coarse_before_exclusion", "cross_family_after_exclusion", "cross_coarse_after_exclusion"),
            (int(v or 0) for v in overall))),
            "raw_known_rows": sum(c["source_known_rows"] for c in families[setting].values()),
            "Heartbleed_is_known": "Heartbleed" in SETTINGS[setting].known_families,
            "training_role_assignment_performed": False}
    connection.commit()
    return output


def _verify_footer(parquet, expected):
    names = parquet.schema_arrow.names
    require(names == expected["columns"] and len(names) == len(set(names)) == 85
            and set(CIC_FEATURE_COLUMNS) <= set(names)
            and parquet.metadata.num_rows == expected["rows_from_footer"], "fixed85_schema_or_footer_rows")
    require({n: str(parquet.schema_arrow.field(n).type) for n in CIC_FEATURE_COLUMNS}
            == expected["model_feature_types"], "fixed78_numeric_types")


def run_inventory(*, output_directory):
    output = Path(output_directory).resolve()
    require(output.is_relative_to(ROOT) and output != ROOT, "new_workspace_child_output_required")
    output.mkdir(parents=True, exist_ok=False)
    began, stage, pins, connection = time.perf_counter(), "fixed_input_registration", {}, None
    report = {**POLICY, "inventory_completed": False, "source_scan_started": False,
              "source_scans_completed": [], "settings_inventory": None,
              "known_filter_batches_completed_by_setting": {s: 0 for s in SETTING_NAMES},
              "known_feature_rows_completed_by_setting": {s: 0 for s in SETTING_NAMES}}
    try:
        metadata, exclusions = _load_fixed_inputs(pins)
        arrow, pq, pc = _load_arrow(pins)
        policy_path = output / "policy_before_source_scan.json"
        report["policy_seal"] = _write_json(policy_path, {**POLICY,
            "source_specs": SOURCE_SPECS, "known_families": {s: ("BEN", *SETTINGS[s].known_families) for s in SETTING_NAMES},
            "model_columns": CIC_FEATURE_COLUMNS, "input_sha256": dict(pins)})
        pins[str(policy_path)] = report["policy_seal"]["sha256"]
        store = output / "known_feature_group_counts.sqlite"
        connection = _create_store(store)
        stage = "known_label_filter_then_bounded_native78_scan"
        report["source_scan_started"] = True
        for filename, source_sha, rows in SOURCE_SPECS:
            source_path = ROOT / SOURCE_DIR / filename
            parquet = pq.ParquetFile(source_path)
            _verify_footer(parquet, metadata[filename])
            offset, source_counts = 0, {setting: Counter() for setting in SETTING_NAMES}
            for batch in parquet.iter_batches(batch_size=BATCH_SIZE, columns=[*CIC_FEATURE_COLUMNS, "Label"]):
                require(batch.num_rows > 0, "nonempty_source_batch")
                for setting in SETTING_NAMES:
                    counts = _consume_batch(connection, batch, setting=setting,
                        offset=offset, excluded_ordinals=exclusions[filename], arrow=arrow, pc=pc)
                    source_counts[setting].update(counts)
                    report["known_filter_batches_completed_by_setting"][setting] += 1
                    report["known_feature_rows_completed_by_setting"][setting] += sum(counts.values())
                offset += batch.num_rows
            require(offset == rows, "complete_source_row_traversal")
            connection.commit()
            progress = {"source_file": filename, "source_sha256": source_sha, "rows_traversed_in_Arrow": offset,
                        "known_rows_by_setting_family": {s: dict(sorted(c.items())) for s, c in source_counts.items()}}
            report["source_scans_completed"].append(progress)
            print(json.dumps(progress, ensure_ascii=False), flush=True)
        stage = "known_only_exact_feature_closure_and_conflict_aggregation"
        report["settings_inventory"] = _summarize(connection)
        connection.close(); connection = None
        report["group_count_artifact"] = {"path": str(store), "sha256": sha(store),
            "contents": "only setting, known family, canonical78 SHA256, finite/exclusion flags, aggregate counts; no numeric features or unknown samples"}
        stage = "final_source_code_and_policy_hash_check"
        for path, wanted in pins.items():
            require(sha(path) == wanted, "input_changed_during_inventory:" + path)
        report.update(execution_status="native_known_capacity_inventory_completed", inventory_completed=True,
                      all_input_pins_stable=True)
    except Exception as error:
        report.update(execution_status="protocol_stop" if isinstance(error, NativeKnownInventoryStop) else "execution_failed",
                      failed_stage=stage, error_type=type(error).__name__, error_message=str(error))
    finally:
        if connection is not None:
            connection.close()
    report["input_sha256"], report["wall_seconds"] = pins, time.perf_counter() - began
    _write_json(output / "report.json", report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-directory", required=True, type=Path)
    result = run_inventory(output_directory=parser.parse_args(argv).output_directory)
    print(json.dumps({k: result[k] for k in ("execution_status", "inventory_completed", "wall_seconds", "status", "published")}))
    return 0 if result["inventory_completed"] else 2 if result["execution_status"] == "protocol_stop" else 1


if __name__ == "__main__":
    raise SystemExit(main())
