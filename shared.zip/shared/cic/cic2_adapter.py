"""CIC2 V950: warm V65 state, full V915 fallback, original158 DVC.

No data read or model work on import. Unknown truth has no loader here.
Only the own V65 embedding block78:110 changes; raw78 and paid V106
FM16/aux32 blocks keep their existing source-owned units and coordinates.
"""
from pathlib import Path
import hashlib, io, json, sys
import numpy as np

H=Path(__file__).resolve().parent
ROOT=Path('F:/shenpeng/Experiments/Chinese Science')
R900=Path('E:/Experiment/software transcition/target99_v900_20261023')
MANIFEST=H/'CIC2_V950_INPUT_AND_WARM_OWNER_MANIFEST.json'

def require(ok,why):
    if not bool(ok):raise ValueError(why)

def descriptor(path):
    p=Path(path).resolve(strict=True)
    return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def raw(d):
    b=Path(d['path']).read_bytes();require(hashlib.sha256(b).hexdigest()==d['sha256'],'immutable input '+d['path']);return b

def js(d):return json.loads(raw(d).decode('utf-8-sig'))

def arrays(d,keys):
    with np.load(io.BytesIO(raw(d)),allow_pickle=False)as z:return{k:z[k]for k in keys}

def manifest():return json.loads(MANIFEST.read_text(encoding='utf-8'))

def rawgroups(native):
    a=np.asarray(native);require(a.dtype==np.float64 and a.ndim==2 and a.shape[1]==78,'physical raw78 codec')
    return np.asarray([hashlib.sha256(np.ascontiguousarray(row).tobytes()).hexdigest()for row in a],dtype='U64')

def prepare_manifest():
    cpath=R900/'cic2_minimax_fullrole_runtime_v915/V915_FROZEN_SOURCE_ONLY_MINIMAX_FULLROLE_RUNTIME_CONTRACT.json'
    cp=descriptor(cpath);c=js(cp);rm=c['registry_material']
    op=descriptor(R900/'cic2_paid_masked78_signed_geometry_v922/V922_EXACT_CIC2_PAID_MASKED78_OWNER_API_AND_CHECKPOINT_HEADER_NO_VALUES.json')
    o=js(op);run=R900/'cic2_minimax_fullrole_runtime_v915/v915_minimax_fullrole_prediction'
    kp=descriptor(run/'known/prediction_report.json');kpj=js(kp)
    up=descriptor(run/'current/prediction_report.json');upj=js(up)
    roles={}
    for role in ('CAL','CP','current'):
        p=kpj if role!='current'else upj
        roles[role]=dict(geometry=rm['roles'][role]['geometry'],parent817=p['files'][role+'_complete_prediction_before_truth'],parent817_seal=p['files'][role+'_seal'])
    m=dict(schema='CIC2_V950_OWN_WARM_FULL817_INCREMENTAL',original_project_root=str(ROOT),parent_version='CIC2_V915_complete_MIXED817',parent_contract=cp,
        warm_owner_descriptor=op,warm_owner=o,source_assets=rm['source_assets'],roles=roles,
        fixed_pair_metric=rm['original158_metric'],known_label_authority=rm['known_label_and_alias_authority'],
        fine_counts_genuine=[4545,100,100,317,256,7,100,462,100],logical_rows=6000,
        checkpoint_strict=True,geometry=dict(width=158,replaced_embedding_slice=[78,110],preserved_native_slice=[0,78],preserved_paid_V106_slice=[110,158]),
        source_training_upper_seconds=rm['source_parameter_union_seconds'],status='FAIL_TARGET99',published=False,final_test_executed=False,
        code={name:descriptor(ROOT/'paper_open_set'/name)for name in ('cic2_coarse_conditional_masked_decoder_architecture_v65.py','whole_field_mask_mhfd_v1.py','model.py','cic2_allpair_relation158_pair_metric_v106.py','cic2_allpair_relation158_dvc_v106.py')})
    require(not MANIFEST.exists(),'new manifest only; preserve prior run')
    H.mkdir(parents=True,exist_ok=True);MANIFEST.write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8');return descriptor(MANIFEST)

def imports(m=None):
    m=manifest()if m is None else m
    for d in m['code'].values():raw(d)
    if str(ROOT)not in sys.path:sys.path.insert(0,str(ROOT))
    from paper_open_set import cic2_coarse_conditional_masked_decoder_architecture_v65 as architecture
    from paper_open_set import whole_field_mask_mhfd_v1 as mask_module
    return architecture,mask_module

def state_sha(net):
    h=hashlib.sha256()
    for k,v in sorted(net.state_dict().items()):
        a=v.detach().cpu().contiguous().numpy();h.update(k.encode());h.update(str(a.dtype).encode());h.update(str(a.shape).encode());h.update(a.tobytes())
    return h.hexdigest()

def restore_warm(m=None):
    import torch
    m=manifest()if m is None else m;o=m['warm_owner'];a,mask=imports(m)
    saved=torch.load(io.BytesIO(raw(o['checkpoint'])),map_location='cpu',weights_only=True)
    fm=mask.FrozenFieldMap(raw(o['field_map']),expected_file_sha256=o['field_map']['sha256'])
    require(saved['epoch_final']==30 and saved['fieldmap_sha256']==fm.file_sha256 and saved['encoder_preprocessing']==o['encoder_preprocessing'],'exact own checkpoint field/input owner')
    net=a.CoarseConditionalWhole78MHFD(mask.WholeFieldMaskedMHFD(fm,9)).cpu().float();net.load_state_dict(saved['state_dict'],strict=True);net.eval()
    require(state_sha(net)==saved['model_state_sha256']==o['trained_state_sha256'],'all own V65 tensors strictly restored; no reinitialization')
    return dict(net=net,architecture=a,field_columns=[list(v['selected_columns'])for v in fm.groups],field_count=78,model_state_sha256=o['trained_state_sha256'],
        clean_forward=lambda n,x:n.backbone(x),masked_forward=lambda n,x,f,c:n.forward_masked(x,f,c),objective_callback=original_objective,conditional_coarse=True)

def original_objective(net,x,coarse,fine,fields,clean):
    """Exact original V65 objective; reuse supplied clean forward once."""
    import torch
    from torch.nn import functional as F
    masked=net.forward_masked(x,fields,coarse);hidden=masked['masked_columns']
    mean=masked['reconstruction'].float();variance=masked['variance']
    nll=.5*torch.log(variance/3.)+2.*torch.log1p((mean-x.detach()).square()/variance)
    require(bool(torch.isfinite(nll).all()),'finite original conditional Student3 NLL')
    recon=((nll*hidden).sum(dim=1)/hidden.sum(dim=1)).mean()
    lc=F.cross_entropy(clean['coarse_logits'],coarse);lf=F.cross_entropy(clean['fine_logits'],fine,label_smoothing=.01)
    return dict(loss=.1*lc+.035*lf+recon,coarse_loss=lc,fine_loss=lf,masked_loss=recon)

def encoder_input(native,m=None):
    m=manifest()if m is None else m;p=arrays(m['warm_owner']['encoder_preprocessing'],('mean','std'))
    require(p['mean'].shape==p['std'].shape==(78,)and np.all(p['std']>0),'own fixed genuine source mean/std')
    x=np.ascontiguousarray((np.sign(native)*np.log1p(np.abs(native))-p['mean'])/p['std'],dtype=np.float32)
    require(np.isfinite(x).all(),'same V65 target codec finite');return x

def load_fit(m=None):
    m=manifest()if m is None else m;s=m['source_assets']
    a=arrays(s['native'],('FIT_ids','FIT_native78','FIT_y_fine','FIT_y_coarse','FIT_training_indices'))
    f=arrays(s['FIT158'],('ids','Z158','true_fine'))
    ids,native,y,c,index=[a[k]for k in ('FIT_ids','FIT_native78','FIT_y_fine','FIT_y_coarse','FIT_training_indices')]
    require(np.array_equal(ids,f['ids'])and np.array_equal(y,f['true_fine'])and len(ids)==5987 and len(np.unique(ids))==5987,'genuine source5987 exactly aligned')
    require(np.bincount(y,minlength=9).tolist()==m['fine_counts_genuine']and np.array_equal(c,(y>0).astype(np.int64)),'source true-known fine9 only')
    require(index.shape==(6000,)and index.dtype.kind in'iu'and index.min()>=0 and index.max()<5987 and np.bincount(y[index],minlength=9).min()>=20,'parent-traceable FIT6000 resampling floor20')
    groups=rawgroups(native);require(len(np.unique(groups))==5987,'one genuine physical raw78 each')
    x=encoder_input(native,m)
    return dict(training=dict(x=x,coarse=c,fine=y,parent_ids=groups,optimizer_indices=index),source=dict(x=x,fine=y,coarse=c,groups=groups,ids=ids,old_features=f['Z158']),
        trace=dict(genuine_source_rows=5987,logical_optimizer_rows=6000,logical_fine_counts=np.bincount(y[index],minlength=9).tolist(),copies_not_independent=True))

def load_role(role,m=None):
    m=manifest()if m is None else m;require(role in('CAL','CP','current'),'declared role');r=m['roles'][role]
    a=arrays(r['geometry'],('ids','native78','Z158'));p=arrays(r['parent817'],('ids','prediction'));seal=js(r['parent817_seal'])
    require(seal['query_truth_used']is False and seal['prediction']==r['parent817'],'whole817 prediction sealed before truth')
    require(np.array_equal(a['ids'],p['ids'])and len(np.unique(a['ids']))==len(a['ids'])and a['Z158'].shape==(len(a['ids']),158),'same complete physical role/order')
    return dict(x=encoder_input(a['native78'],m),ids=a['ids'],groups=rawgroups(a['native78']),old_features=a['Z158'],parent_prediction=p['prediction'],role=role,embedding_start=78)

def feature_builder(old_features):
    old=np.asarray(old_features,np.float64)
    def build(embedding,native):
        require(embedding.shape==(len(old),32),'same ordered embedding/source geometry')
        return np.concatenate((old[:,:78],embedding,old[:,110:]),axis=1)
    return build

def fixed_pair_metric(m=None):
    m=manifest()if m is None else m;imports(m)
    from paper_open_set.cic2_allpair_relation158_pair_metric_v106 import PaperVariationalPairMetric
    metric=PaperVariationalPairMetric.from_state(js(m['fixed_pair_metric']));require(metric.dimension==158,'original paid158 prior');return metric

def load_known_labels(role,m=None):
    m=manifest()if m is None else m;require(role in('CAL','CP'),'known-only authority')
    a=arrays(m['known_label_authority'],(role+'_ids',role+'_y_coarse'));y=a[role+'_y_coarse']
    require(np.isin(y,(0,1)).all(),'known-only CAL/CP BEN/KNA');return dict(ids=a[role+'_ids'],coarse=y)

def make_dvc_callback(groups):
    imports()
    from paper_open_set.cic2_allpair_relation158_dvc_v106 import route_current_candidates
    groups=np.asarray(groups)
    def route(metric,new_features,candidates):
        z=np.asarray(new_features,np.float64);mask=np.asarray(candidates)
        require(z.shape==(len(groups),158)and mask.shape==groups.shape and mask.dtype==bool,'same158 DVC source/query geometry')
        _,reps,inverse=np.unique(groups,return_index=True,return_inverse=True)
        # Original paid auxiliary caches can differ at floating point precision
        # across presentations of one raw flow. Keep every original coordinate;
        # use the first original-order physical representative, without rounding
        # or calling another view a new independent flow. Candidate context is OR.
        collapsed=np.zeros(len(reps),bool);np.logical_or.at(collapsed,inverse,mask)
        out=route_current_candidates(metric,z[reps],collapsed,seed=20261008)
        result={k:(v[inverse]if isinstance(v,np.ndarray)and v.shape==(len(reps),)else v)for k,v in out.items()}
        result['retained']=mask & result['retained']
        result['manifest']=dict(out['manifest'],physical_groups=len(reps),full_flows=len(groups),historical_U_anchors=False,newgeometry_fixedprior=True,
            physical_representative='first original cohort order; all original158 values preserved',raw_context='OR within physical raw78; only individually proposed full flows can be newly retained',
            original_view_variation_present=not np.array_equal(z,z[reps][inverse]))
        return result
    return route

if __name__=='__main__':
    print(json.dumps(prepare_manifest(),ensure_ascii=False))
