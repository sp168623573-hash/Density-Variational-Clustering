"""Complete native78 auxiliary softview and genuine matched126 layered DVC."""
import argparse,json,sys,time,types
from pathlib import Path
import numpy as np
from scipy.spatial import distance as spatial
from threadpoolctl import threadpool_limits
from . import cic1_native78_soft_affinity_core_v141 as core
from . import cic1_soft_raw_affinity126_v133 as source
from . import cic1_secondary_soft_review126_v138b as baseline_source
ROOT,files,require=source.ROOT,source.files,source.require
old=source.old;MODULE='paper_open_set.cic1_native78_soft_view126_v141'
DIR=ROOT/'tmp/cic1_native78_soft_view126_20261012_v141';BASE=ROOT/'data/external_dev/processed/cic1_native78_soft_view126_20261012_v141';REG=DIR/'registry_before_known.json'
class NativeEuclidean:
    dimension=78
    def pairwise_distances(self,q,r):
        require(q.ndim==r.ndim==2 and q.shape[1]==r.shape[1]==78 and np.isfinite(q).all() and np.isfinite(r).all(),'completeactualnative78 Euclidean inputs')
        return spatial.cdist(q,r,metric='euclidean')
def decisions(raw,first,suspected,retained,full_agree):
    require(raw.shape==first.shape==suspected.shape==retained.shape==full_agree.shape and raw.dtype==suspected.dtype==retained.dtype==full_agree.dtype==bool and np.all(first>=-2),'actualwholeprimary -2/-1/nonnegative schema')
    ordinary=raw&retained
    secondary=raw&(first>=0)&suspected&~retained
    primarynoise=raw&(first==-1)&full_agree
    return ordinary|secondary|primarynoise,secondary,primarynoise
def policy():
    return dict(schema_version='CIC1-completenative78-auxiliarysoftgraph-original126multiview-hierarchical-v141',recipe=core.recipe(),hypotheses=1,
        view='all original126[:,:78] equals genuine frozenFIT-normalized native78 source; no field deletion/subset, no metrictrain or learnedquerynormalization',
        auxiliary_metric='actual scipy.spatial.distance.cdist full78 Euclidean; auxiliary graph only, NOT paperEq9/10 and not a newlytrained distance',
        initial='same uniformV126raw candidate function for CAL/CP/current, includesfalsepositives, no truthfilter or rolezero',
        graph='trueknown6000 anchors0, k7/sigma7 Gaussian/.9/20/no hardrawclamp, oncealltrueknownCAL900finite99+fixed.5',
        DVC='newnativeviewraw OR whole3121priorpred2 matching original126 paper densityaffinity, groupsonce no copy points',
        secondary_review='only nativecuecandidate first>=0 &suspected &~oldretained, same auxiliarycandidate corroborates secondary rejection',
        primary_noise_review='nativecuecandidate first==-1 AND fulloriginal126V133softscore>frozenfullCALcut; two view agreement required, -2 unassessed neverrescued',
        baseline='copycomplete646/247/3121 includingmistakes and allold2; originals3114/3059/2402 preserved',
        limitations='two geometry cues are correlated engineering indicators, not statisticallyindependent probability or classidentity certificate; fullmixed losses measured',
        NN_fit=0,NN_forward=0,metric_fit=0,R7_fit=0,trueUNA_fit=False,query_fit=False,parameter_grid=False,timecap_coded=False,
        extension_not_verbatim_paper=True,status='FAIL_TARGET99',published=False,final_test_executed=False)
def closure():
    found={};seen=set();todo=[sys.modules[__name__]]
    while todo:
        m=todo.pop()
        if m is None or id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if not p or not Path(p).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        found[MODULE if m is sys.modules[__name__] else m.__name__]=files.item(p)
        for value in vars(m).values():
            child=value if isinstance(value,types.ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            if child is not None:todo.append(child)
    return found
def archive(a,keys,pins):return old.archive(a,keys,pins)
def save(out,r,key,value):return old.save(out,r,key,value)
def synthetic_contract():
    base=core.synthetic_contract();raw=np.ones(5,bool);first=np.array([-2,-1,-1,0,1]);suspected=np.ones(5,bool);retained=np.array([False,False,False,False,True]);agree=np.array([True,False,True,False,False])
    accepted,secondary,noise=decisions(raw,first,suspected,retained,agree)
    require(accepted.tolist()==[False,False,True,True,True] and noise.tolist()==[False,False,True,False,False],'unassessed -2 blocked, primarynoise needsbothviews, primaryvalid secondaryreview uniform')
    a=np.zeros((3,78));a[1,77]=1.;d=NativeEuclidean().pairwise_distances(a,a)
    require(d[0,1]==1 and d[1,0]==1 and np.all(np.diag(d)==0),'realcdist all78 field/self/tie API')
    return dict(base,actualcdist_all78_lastfield=True,multiview_primarynoise_doubleagreement=True,unassessed_minus2_neverrescued=True,primarysecondary_uniform=True)
def freeze():
    started=time.perf_counter();pins={};sr=files.item(source.REG);s=files.js(sr,pins);sk=files.item(source.BASE/'known/report.json');sc=files.item(source.BASE/'current/report.json');ks=files.js(sk,pins);cs=files.js(sc,pins)
    br=files.item(baseline_source.REG);b=files.js(br,pins);bk=files.item(baseline_source.BASE/'known/report.json');bc=files.item(baseline_source.BASE/'current/report.json');kb=files.js(bk,pins);cb=files.js(bc,pins)
    require(kb['known_gate_passed'] and cb['prediction_sealed'] and cb['original_class_gates']['UNA']['correct']==3121,'actualwhole3121 positivepreserved baseline')
    a=dict(s['assets']);a.update(known_baseline=kb['files']['complete_secondaryreview_prediction_before_truth'],baseline=cb['files']['complete_secondaryreview_prediction_before_truth'],
        full_cut=ks['files']['rule'],CP_fullgraph=ks['files']['CP_graph'],current_fullgraph=cs['files']['current_graph'])
    close_ref=files.item(baseline_source.DIR/'CIC1_V138B_SECONDARY_SOFT_REVIEW_3121_UP_COMPLETED_CLOSEOUT.json');close=files.js(close_ref,pins)
    import scipy.spatial._distance_pybind as binding
    runtime=dict(distance_python=files.item(spatial.__file__),distance_compiled=files.item(binding.__file__))
    src=closure();contract=synthetic_contract()
    for item in [*a.values(),*src.values()]:files.read(item,pins)
    for item in runtime.values():
        require(files.item(item['path'])==item,'explicitinstalledscipy cdist runtimebyteidentity');pins[str(Path(item['path']).resolve())]=item['sha256']
    require(not REG.exists() and not BASE.exists(),'exclusivefixednative78 auxiliaryview namespace')
    DIR.mkdir(parents=True,exist_ok=True)
    return files.write(REG,dict(policy=policy(),assets=a,sources=src,synthetic_contract=contract,cdist_runtime_sources=runtime,
        original_graph_registry=sr,original_graph_known=sk,original_graph_current=sc,baseline_registry=br,baseline_known=bk,baseline_current=bc,
        ancestry_closeout=close_ref,prior_preparation_seconds=close['actual_preparation']['conservative_allprep_plus_ancestry_seconds'],freeze_seconds=time.perf_counter()-started,input_sha256=pins,current_numeric_decodes=0))
def bind(ref,pins):
    reg=files.js(ref,pins);require(reg['policy']==policy() and reg['sources']==closure(),'exactfrozenfull78/126policy andsource')
    runtime_paths={str(Path(item['path']).resolve()) for item in reg['cdist_runtime_sources'].values()}
    for p,s in reg['input_sha256'].items():
        if str(Path(p).resolve()) in runtime_paths:require(files.item(p)['sha256']==s,'onlyexactregistered installedscipysource unchanged');pins[str(Path(p).resolve())]=s
        else:files.read(dict(path=p,sha256=s),pins)
    return reg
def anchors(reg,metric,pins):
    mat=archive(reg['assets']['material'],('FIT_ids','FIT_groups','FIT_fine','FIT_Z126'),pins);lab=archive(reg['assets']['native_known'],('FIT_ids','FIT_native78','FIT_y_fine'),pins)
    require(len(np.unique(mat['FIT_groups']))==len(mat['FIT_ids'])==6000 and np.array_equal(mat['FIT_ids'],lab['FIT_ids']) and np.array_equal(mat['FIT_fine'],lab['FIT_y_fine']) and np.bincount(mat['FIT_fine'],minlength=9).min()>=20,'actualgenuineknown6000 nativefit roleall9')
    # Parentsource126 was generated from genuineFIT native78 signedlog/RMS.
    nativeunits_ref=files.js(files.item(old.cic.BASE/'current/report.json'),pins)['registry'];oldreg=files.js(nativeunits_ref,pins)
    units=np.asarray(files.js(oldreg['assets']['native_RMS'],pins)['native78'])
    raw=(np.sign(lab['FIT_native78'])*np.log1p(np.abs(lab['FIT_native78'])))/units
    require(np.array_equal(raw,mat['FIT_Z126'][:,:78]) and metric.to_state()['prefit_descriptor']['FIT_MHFD_Z']==old.cic.learned._array_descriptor(mat['FIT_Z126']),'actualall78physicalinput prefix and126prefit owner')
    order=np.argsort(mat['FIT_groups'],kind='stable')
    return dict(ids=mat['FIT_ids'][order],groups=mat['FIT_groups'][order],Z126=mat['FIT_Z126'][order],native78=raw[order],fine=mat['FIT_fine'][order]),units,oldreg['assets']['current_native']
def role_input(reg,role,pins,units,current_native):
    if role=='CAL':
        mat=archive(reg['assets']['material'],tuple('CAL_'+k for k in ('ids','groups','Z126','stage1')),pins);q={k:mat['CAL_'+k] for k in ('ids','groups','Z126','stage1')};j=archive(reg['assets']['CAL_joint'],('ids','score'),pins);g0=archive(reg['assets']['CAL_bank0'],('ids','eligible'),pins);g1=archive(reg['assets']['CAL_bank1'],('ids','eligible'),pins)
        raw=core.raw_candidate(j['score'],g0['eligible']|g1['eligible'],q['stage1'],files.js(reg['assets']['prior_rule'],pins));baseline=None
    else:
        q,baseline,_=old.query('CIC1','known' if role=='CP' else 'current',reg['assets'],pins);j=archive(reg['assets'][role+'_joint'],('ids','score','eligible','raw'),pins);raw=core.raw_candidate(j['score'],j['eligible'],q['stage1'],files.js(reg['assets']['prior_rule'],pins));require(np.array_equal(raw,j['raw']),'samewhole actualV126raw initial no truthfilter')
    if role=='current':n=archive(current_native,('ids','native78'),pins);ids,x=n['ids'],n['native78']
    else:n=archive(reg['assets']['native_known'],(role+'_ids',role+'_native78'),pins);ids,x=n[role+'_ids'],n[role+'_native78']
    require(np.array_equal(j['ids'],q['ids']) and np.array_equal(ids,q['ids']) and np.array_equal((np.sign(x)*np.log1p(np.abs(x)))/units,q['Z126'][:,:78]),'actualcompletephysicalnative78 sameeveryrole126prefix')
    return q,raw,baseline
def graph(q,initial,anchor,out,r,role):
    nodes=core.collapse(q['Z126'][:,:78],q['groups'],q['ids'],initial);require(not set(nodes['groups'].tolist())&set(anchor['groups'].tolist()),'genuinequery/FIT disjointnativegroups')
    started=time.perf_counter();value=core.diffusion(NativeEuclidean(),anchor['native78'],nodes['Z78'],nodes['initial_raw']);r['graph_seconds'][role]=time.perf_counter()-started
    r['files'][role+'_graph']=save(out,r,role+'_actualnative78_uniformraw_softgraph_beforecut',dict(ids=q['ids'],stage1=q['stage1'],initial_raw_rows=initial,group78=nodes['Z78'],groups=nodes['groups'],representatives=nodes['representatives'],inverse=nodes['inverse'],score_rows=value['score'][nodes['inverse']],**{k:v for k,v in value.items() if k!='manifest'}))
    r['files'][role+'_graph_manifest']=files.write(out/(role+'_native78_Euclidean_softgraph_manifest.json'),dict(value['manifest'],Euclidean_auxiliary_not_paper126_metric=True,initial_raw_rows=int(initial.sum())))
    return value['score'][nodes['inverse']],nodes
def run(phase,ref,knownref=None):
    started=time.perf_counter();pins={};reg=bind(ref,pins);control=None
    if phase=='current':control=files.js(knownref,pins);require(control['known_gate_passed'] and control['prediction_sealed'] and control['registry']==ref,'onceknown gatesbefore currentnativeview')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False)
    r=dict(policy=policy(),phase=phase,registry=ref,files={},graph_seconds={},NN_fit=0,NN_forward=0,metric_fit=0,R7_fit=0,CAL_fit=0,DVC=0,current_numeric_decodes=0,prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        with threadpool_limits(limits=2):
            metric=old.cic.learned.PaperVariationalPairMetric.from_state(files.js(reg['assets']['metric'],pins)['metric_payload']);anchor,units,current_native=anchors(reg,metric,pins);r['files']['metric']=reg['assets']['metric'];r['files']['anchors']=save(out,r,'allknown6000_actualnative78_original126_anchor0_beforegraphs',dict(**anchor,anchor_zero=np.zeros(6000)))
            if phase=='known':
                q,initial,_=role_input(reg,'CAL',pins,units,current_native);score,_=graph(q,initial,anchor,out,r,'CAL');lab=archive(reg['assets']['native_known'],('CAL_ids','CAL_y_coarse'),pins);require(np.array_equal(q['ids'],lab['CAL_ids']),'alltrueknownCALorderedids')
                rank=old.cic.dvc.calibrate_known_cutoffs(score,lab['CAL_y_coarse']);rule={k:dict(v,finite99_cutoff=v['cutoff'],cutoff=max(.5,v['cutoff']) if v['enabled'] else None,fixed_majority_floor=.5) for k,v in rank.items()};r['CAL_fit']=1;r['files']['rule']=files.write(out/'all900_trueknown_oncefinite99_nativeview_fixedfloorhalf.json',rule);role='CP'
            else:rule=files.js(control['files']['rule'],pins);r['files']['rule']=control['files']['rule'];r['known_report']=knownref;role='current'
            q,initial,baseline=role_input(reg,role,pins,units,current_native);r['current_numeric_decodes']=len(q['ids']) if phase=='current' else 0;score,nodes=graph(q,initial,anchor,out,r,role)
            raw=(baseline!=2)&old.cic.dvc.candidate_mask(score,q['stage1'],rule);full=archive(reg['assets'][role+'_fullgraph'],('ids','stage1','score_rows'),pins);require(np.array_equal(full['ids'],q['ids']) and np.array_equal(full['stage1'],q['stage1']),'same original126 fullview rowordering/actualstage')
            full_agree=old.cic.dvc.candidate_mask(full['score_rows'],q['stage1'],files.js(reg['assets']['full_cut'],pins));density=raw|(baseline==2)
            _,rep,inv=np.unique(q['groups'],return_index=True,return_inverse=True);gd=np.zeros(len(rep),bool);np.logical_or.at(gd,inv,density)
            routed=old.cic.dvc.route_current_candidates(metric,q['Z126'][rep],gd,seed=20261012);r['DVC']=1;route={k:v[inv] for k,v in routed.items() if k!='manifest'}
            accepted,secondary,primarynoise=decisions(raw,route['first'],route['suspected'],route['retained'],full_agree);p=baseline.copy();p[accepted]=2;require(np.all(p[baseline==2]==2),'whole3121old2includingmistakes preserved')
            save(out,r,'matching126_nativeviewcandidate_plusold2_DVC_beforetruth',route);r['files']['DVC_manifest']=files.write(out/'matching126_nativeviewcandidate_plusold2_DVC_manifest.json',dict(routed['manifest'],matching_metric_state_sha256=metric.state_sha256,density_copies=0))
            values=dict(ids=q['ids'],prediction=p,baseline=baseline,native_score=score,full_score=full['score_rows'],native_raw=raw,full_agree=full_agree,density=density,accepted=accepted,secondary_review=secondary,primarynoise_review=primarynoise,initial_raw=initial)
            sealed=save(out,r,'complete_multiviewprediction_beforetruth',values);r['files']['seal']=files.write(out/'complete_multiviewprediction_seal_beforetruth.json',dict(predictions=sealed,registry=ref,rule=r['files']['rule'],full_rule=reg['assets']['full_cut'],metric=reg['assets']['metric'],querytruth_used=False));r['prediction_sealed']=True
            if phase=='known':y=archive(reg['assets']['known_truth'],('CP_truth',),pins)['CP_truth']
            else:t=archive(reg['assets']['truth'],('ids','truth'),pins);require(np.array_equal(t['ids'],q['ids']),'querytruth onlyafterfullnewseal');y=t['truth']
            r['truth_opened']=True;gates,delta,binary=old.helpers.metrics(y,baseline,p);r.update(execution_status='CIC1_native78_auxiliaryview126_'+phase+'_completed',original_class_gates=gates,EffectDelta=delta,binary_attack_detection=binary,known_gate_passed=all(gates[n]['passed'] for n in ('BEN','KNA')),candidate_accepted_for_retention=False,
                raw_by_trueclass={n:int(((y==c)&raw).sum()) for c,n in enumerate(('BEN','KNA','UNA'))},accepted_by_trueclass={n:int(((y==c)&accepted).sum()) for c,n in enumerate(('BEN','KNA','UNA'))},
                secondary_review_by_trueclass={n:int(((y==c)&secondary).sum()) for c,n in enumerate(('BEN','KNA','UNA'))},primarynoise_review_by_trueclass={n:int(((y==c)&primarynoise).sum()) for c,n in enumerate(('BEN','KNA','UNA'))})
            save(out,r,'postseal_complete_multiview_pair',dict(**values,truth=y))
            if phase=='current':r['perfect_native_raw_UNA_ceiling']=int(((y==2)&((baseline==2)|raw)).sum())
        for p,s in pins.items():require(files.item(p)['sha256']==s,'alloriginalstates/sources/priorwhole/cachedfullsoftgraph unchanged')
    except Exception as error:r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for key in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+key)
    a=p.parse_args();ref=None if a.registry is None else dict(path=str(Path(a.registry).resolve()),sha256=a.registry_sha256);k=None if a.known_report is None else dict(path=str(Path(a.known_report).resolve()),sha256=a.known_sha256)
    print(json.dumps(freeze() if a.phase=='freeze' else run(a.phase,ref,k)))
