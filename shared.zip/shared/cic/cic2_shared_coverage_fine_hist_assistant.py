"""One fixed known-fine histogram auxiliary for frozen CIC2 MHFD.

Train on the registered shared 5987 originals plus 13 Heartbleed optimizer
copies. CP calibrates one fixed half/half probability blend. CAL features and
cached probabilities are opened only after the CP threshold is sealed; CAL
truth and saved parent predictions are opened only after both predictions
are sealed. No unknown records, query entry, or model promotion are provided.
"""
from __future__ import annotations

import argparse
from collections import Counter
import inspect
import json
from pathlib import Path
import time

import joblib
import numpy as np
import sklearn
from sklearn.ensemble import HistGradientBoostingClassifier

from . import cic2_known6000_binary_assistant_v1 as previous
from . import cic2_shared_coverage_hierarchical_binary_assistant_v2 as hierarchy
from . import cic_fit6000_mhfd_training_v1 as helpers

ROOT = helpers.ROOT
OUT = ROOT / "data/external_dev/processed/cic2_shared_coverage_fine_hist_assistant_20261010_v1"
REGISTRY_OUT = ROOT / "tmp/cic2_shared_coverage_fine_hist_assistant_20261010_v1"
SCHEMA = "CIC2-shared-coverage-FIT6000-hist-fine9-native78-v1"
MATERIAL = dict(path="data/external_dev/processed/cic2_shared_coverage_FIT6000_20261010_v1/report.json",
                sha256="82010b9b4c47834e9d5dd7ae27d5cd82b7c91a3f5be4c54b64de617f3b83ac06")
PRIOR = dict(path="data/external_dev/processed/cic2_shared_coverage_hist_assistant_20261010_v1/report.json",
             sha256="5138b73ec9affe76f0017d69ac6c1a94badf96715eb1b2b7aebe5dd8b376dfca")
STRONG = dict(hierarchy.STRONG)
NN = dict(previous.NN)
FAMILIES = tuple(hierarchy.FAMILIES)
PARAMETERS = dict(loss="log_loss", learning_rate=.05, max_iter=200,
    max_leaf_nodes=31, max_depth=None, min_samples_leaf=10,
    l2_regularization=1.0, max_bins=255, early_stopping=False,
    random_state=20261010)
PRESERVED_SOURCE_SHA256 = {
    str(Path(previous.__file__).resolve()): "8be2345104f99594b40d18f75b40458b07af002fb8b5f3f58f7032cdb06840ee",
    str(Path(hierarchy.__file__).resolve()): "21b12ee2724440f01890e61cbd602666e25dffffabd9634c5e051aae374a80dd",
}
hierarchical_binary_weights = hierarchy.hierarchical_binary_weights


def policy():
    return dict(schema_version=SCHEMA, setting="CIC Setting2", hypotheses=1,
        classifier_parameters=PARAMETERS, classifier_target="true known fine9 including BEN index0",
        sample_weight="6000 * .5/count(BEN); 6000 * .5/(8*count(fine)) for each known attack fine, over optimizer indices",
        family_order=FAMILIES, FIT_original=5987, FIT_copies=13,
        FIT_optimizer=6000, CP_original=882, CAL_original=882,
        controls_reporting_rows=900,
        input="complete unchanged native78 float32; no clipping or feature selection",
        primary="frozen original signedlog MHFD cached .55 coarse + .45 fine attack probability",
        blend=".5 frozen original signedlog NN probability + .5 fixed fine9-HGB sum(nonBEN) probability",
        threshold="exactly one CP originals choose_coarse_threshold call; CAL never tunes threshold, weights or parameters",
        calibration_role="CP_original882", heldout_role="CAL_original882",
        intervention="single fixed fine-supervised auxiliary; same shared union, weights and half blend as binary HGB, no CAL parameter selection",
        old_model_weights_modified=False, MHFD_two_heads_retained=True,
        fine_heads_retained=True, unknown_DVC_architecture_retained=True,
        NN_fit=0, NN_forward=0, query_entry=False, unknown_reads=0,
        warm_known_controls=True, independent_final_claimed=False,
        accepted_baseline_replaced=False, status="FAIL_TARGET99",
        published=False, final_test_executed=False)


def runtime_provenance():
    """External installed runtime is provenance, never a guarded data asset."""
    return dict(sklearn_version=sklearn.__version__,
        sklearn_module=helpers.descriptor(Path(sklearn.__file__).resolve()),
        classifier_source=helpers.descriptor(Path(inspect.getfile(HistGradientBoostingClassifier)).resolve()))


def source_bindings():
    for path, wanted in PRESERVED_SOURCE_SHA256.items():
        helpers.require(helpers.sha(path) == wanted, "preceding_assistant_source_preserved:" + path)
    modules = (Path(__file__), Path(previous.__file__), Path(hierarchy.__file__),
        Path(helpers.__file__), Path(helpers.header_tools.__file__),
        Path(helpers.network.__file__), Path(previous.primary.__file__),
        Path(previous.primary.nn.__file__))
    for path in modules:
        helpers.require(path.resolve().is_relative_to(ROOT), "workspace_source_binding:" + str(path))
    return {str(path.resolve()): helpers.sha(path) for path in modules}


def load(asset, keys, pins):
    with np.load(helpers.checked(asset, pins), allow_pickle=False) as values:
        return {key: values[key].copy() for key in keys}


def save(name, values, report):
    item = helpers.npz_new(OUT / (name + ".npz"), values, {})
    report["files"][name] = item
    return item


def fine_probabilities(classifier, x):
    helpers.require(np.array_equal(classifier.classes_, np.arange(9)),
                    "actual_HGB_fine9_class_order")
    probabilities = np.asarray(classifier.predict_proba(x))
    helpers.require(probabilities.shape == (len(x), 9)
        and np.issubdtype(probabilities.dtype, np.floating)
        and np.isfinite(probabilities).all()
        and np.all((probabilities >= 0) & (probabilities <= 1))
        and np.allclose(probabilities.sum(axis=1), 1., rtol=0, atol=1e-12),
        "actual_HGB_probability_domain_and_class_custody")
    return probabilities.astype(np.float64, copy=True)


def blend_probability(neural, auxiliary):
    neural, auxiliary = np.asarray(neural), np.asarray(auxiliary)
    helpers.require(neural.ndim == 1 and neural.shape == auxiliary.shape
        and np.issubdtype(neural.dtype, np.floating)
        and np.issubdtype(auxiliary.dtype, np.floating)
        and np.isfinite(neural).all() and np.isfinite(auxiliary).all()
        and np.all((neural >= 0) & (neural <= 1))
        and np.all((auxiliary >= 0) & (auxiliary <= 1)),
        "unchanged_finite_known_probability_sources")
    return .5 * neural.astype(np.float64) + .5 * auxiliary.astype(np.float64)


def heldout_truth_after_seal(reg, pins, report):
    """CAL truth access is guarded by the complete prediction seal."""
    helpers.require(report["CP_threshold_fit"] == 1
        and report["CP_threshold_sealed"] and report["prediction_sealed"]
        and not report["CAL_truth_opened"] and not report["prior_predictions_opened"],
        "CAL_truth_only_after_CP_threshold_and_both_prediction_seal")
    truth = load(reg["native"], ("CAL_y_coarse",), pins)["CAL_y_coarse"]
    report["CAL_truth_opened"] = True
    return truth


def freeze():
    """JSON, headers and FIT labels/index metadata only; no control truth."""
    pins = {}
    material = helpers.read(MATERIAL, pins)
    nn = helpers.read(NN, pins)
    prior, strong = helpers.read(PRIOR, pins), helpers.read(STRONG, pins)
    native, cached = material["source_arrays"], nn["files"]["predictions"]
    helpers.require(material["policy"]["shared_FIT_unique"] == 5987
        and material["policy"]["optimizer_rows"] == 6000
        and material["policy"]["old_primary_FIT_groups"] == 4187
        and material["policy"]["added_unique"] == 1800
        and material["policy"]["optimizer_copies"] == 13
        and material["original_primary_training_union_exact"] == 5987
        and not material["policy"]["unknown_or_outcome_based_selection"],
        "fixed_shared_training_union5987_and_optimizer6000")
    headers = helpers.header_tools.npz_headers(helpers.checked(native, pins))
    for role, n in (("FIT", 5987), ("CP", 882), ("CAL", 882)):
        for suffix, shape in (("native78", [n, 78]), ("ids", [n]),
                              ("y_fine", [n]), ("y_coarse", [n])):
            helpers.require(headers[role + "_" + suffix]["shape"] == shape,
                            "complete_native_role_header:" + role + suffix)
    cached_headers = helpers.header_tools.npz_headers(helpers.checked(cached, pins))
    for role in ("CP", "CAL"):
        helpers.require(cached_headers[role + "_probability"]["shape"] == [882]
            and cached_headers[role + "_ids"]["shape"] == [882],
            "complete_original_NN_cached_header:" + role)
        helpers.require(headers[role + "_reporting_indices"]["shape"] == [900],
                        "reporting_only_copy_header:" + role)
    meta = load(native, ("FIT_y_fine", "FIT_y_coarse", "FIT_training_indices"), pins)
    index, fine, coarse = meta["FIT_training_indices"], meta["FIT_y_fine"], meta["FIT_y_coarse"]
    helpers.require(index.dtype == np.int64 and index.shape == (6000,)
        and np.all((index >= 0) & (index < 5987))
        and helpers.ad(index) == material["bound"]["FIT_training_indices"],
        "unchanged_fixed6000_optimizer_map")
    repetitions = np.bincount(index, minlength=5987)
    helpers.require(np.all(repetitions >= 1) and int((repetitions - 1).sum()) == 13
        and np.all(fine[repetitions > 1] == FAMILIES.index("Heartbleed")),
        "all_real_originals_once_plus_only13_Heart_optimizer_copies")
    weight = hierarchical_binary_weights(fine[index], coarse[index])
    prior_predictions = prior["files"]["fixed_known_predictions_before_CAL_truth_and_prior"]
    strong_predictions = strong["files"]["paired"]
    for item in (prior_predictions, strong_predictions):
        compare_headers = helpers.header_tools.npz_headers(helpers.checked(item, pins))
        for role in ("CP", "CAL"):
            for suffix in (("ids", "prediction") if item == prior_predictions else ("ids", "truth", "candidate")):
                helpers.require(compare_headers[role + "_" + suffix]["shape"] == [882],
                                "postseal_parent_prediction_header:" + role + suffix)
    bindings = source_bindings()
    for path, wanted in bindings.items():
        helpers.checked(dict(path=path, sha256=wanted), pins)
    reg = dict(schema_version=SCHEMA + "-registry", policy=policy(), material=MATERIAL,
        primary_NN=NN, native=native, primary_cached=cached,
        previous=PRIOR, strong=STRONG, prior_predictions=prior_predictions,
        strong_predictions=strong_predictions, source_bindings=bindings,
        runtime_provenance=runtime_provenance(),
        FIT_original_fine_counts={str(k): int(v) for k, v in Counter(fine.tolist()).items()},
        FIT_optimizer_fine_counts={str(k): int(v) for k, v in Counter(fine[index].tolist()).items()},
        FIT_family_weight_mass={str(k): float(weight[fine[index] == k].sum() / 6000) for k in range(9)},
        shared_group_union_sha256=material["shared_group_union_sha256"],
        input_sha256=pins, output=str(OUT), cached_probability_decodes=0,
        numeric_feature_decodes=0, CP_truth_opened=False, CAL_truth_opened=False,
        unknown_reads=0, status="FAIL_TARGET99", published=False, final_test_executed=False)
    helpers.require(not OUT.exists() and not REGISTRY_OUT.exists(), "fresh_once_only_HGB_registry_and_output")
    REGISTRY_OUT.mkdir(parents=True, exist_ok=False)
    return helpers.json_new(REGISTRY_OUT / "registry_before_hist_FIT.json", reg)


def run(path, sha):
    report = dict(schema_version=SCHEMA, policy=policy(), files={}, classifier_fit=0,
        classifier_forward_roles=[], CP_threshold_fit=0, CP_threshold_sealed=False,
        prediction_sealed=False, CP_truth_opened=False, CAL_truth_opened=False,
        prior_predictions_opened=False, NN_fit=0, NN_forward=0, unknown_reads=0,
        query_fit=0, accepted_baseline_replaced=False, promotion_status="NOT_PROMOTED",
        protocol_events=[], status="FAIL_TARGET99", published=False, final_test_executed=False)
    pins, began, stage = {}, time.perf_counter(), "bind_frozen_recipe_and_sources"
    registry = dict(path=str(Path(path).resolve()), sha256=sha)
    helpers.require(not OUT.exists(), "fresh_once_only_hist_output")
    OUT.mkdir(parents=True, exist_ok=False)
    try:
        reg = helpers.read(registry, pins)
        helpers.require(reg["policy"] == json.loads(json.dumps(policy()))
            and reg["source_bindings"] == source_bindings()
            and reg["runtime_provenance"] == runtime_provenance()
            and reg["output"] == str(OUT), "frozen_hist_recipe_sources_runtime_and_destination")
        for asset, wanted in reg["input_sha256"].items():
            helpers.checked(dict(path=asset, sha256=wanted), pins)
        stage = "load_fixed_FIT_features_labels_and_all_role_IDs_without_controls"
        fields = load(reg["native"], ("FIT_native78", "FIT_y_fine", "FIT_y_coarse",
            "FIT_training_indices", "FIT_ids", "CP_ids", "CAL_ids",
            "CP_reporting_indices", "CAL_reporting_indices"), pins)
        all_ids = np.concatenate([fields[role + "_ids"] for role in ("FIT", "CP", "CAL")])
        helpers.require(len(all_ids) == 7751 and len(np.unique(all_ids)) == 7751,
                        "distinct_original_known_role_IDs")
        index, fine, coarse = fields["FIT_training_indices"], fields["FIT_y_fine"], fields["FIT_y_coarse"]
        x = np.ascontiguousarray(fields["FIT_native78"], np.float32)
        helpers.require(x.shape == (5987, 78) and index.shape == (6000,)
            and np.isfinite(x).all() and np.all((index >= 0) & (index < len(x))),
            "complete_fixed_known_only_optimizer_inputs")
        weight = hierarchical_binary_weights(fine[index], coarse[index])
        helpers.require({str(k): int(v) for k, v in Counter(fine[index].tolist()).items()}
            == reg["FIT_optimizer_fine_counts"], "same_frozen_FIT_family_counts")
        weights = save("FIT_training_weights_before_classifier_fit",
            dict(indices=index, fine=fine[index], coarse=coarse[index], sample_weight=weight), report)
        report["files"]["prefit"] = helpers.json_new(OUT / "recipe_before_hist_fit.json",
            dict(policy=policy(), sample_weights=weights, material=reg["native"],
                primary_cached=reg["primary_cached"], source_bindings=reg["source_bindings"],
                runtime_provenance=reg["runtime_provenance"], CP_truth_opened=False,
                CAL_truth_opened=False, prior_predictions_opened=False))
        stage = "one_known_FIT_hist_fine9_fit_with_fixed_hierarchical_weights"
        classifier = HistGradientBoostingClassifier(**PARAMETERS)
        started = time.perf_counter()
        classifier.fit(x[index], fine[index], sample_weight=weight)
        report["classifier_fit"] = 1
        report["training_seconds"] = time.perf_counter() - started
        helpers.require(classifier.n_iter_ == PARAMETERS["max_iter"],
                        "fixed200_iterations_no_holdout_early_stopping")
        model_path = OUT / "known_only_finebalanced_fine9_native78_HistGradientBoosting200.joblib"
        joblib.dump(classifier, model_path)
        report["files"]["model"] = helpers.descriptor(model_path)
        report["protocol_events"].append("known_FIT_model_sealed")
        stage = "one_CP_probability_and_CP_threshold_before_CAL_features"
        cp_fields = load(reg["native"], ("CP_native78",), pins)
        cp_nn = load(reg["primary_cached"], ("CP_ids", "CP_probability"), pins)
        helpers.require(np.array_equal(fields["CP_ids"], cp_nn["CP_ids"]), "same_fixed_original_NN_CP_ID_order")
        cp_fine = fine_probabilities(classifier, np.ascontiguousarray(cp_fields["CP_native78"], np.float32))
        cp_hist = 1. - cp_fine[:, 0]
        report["classifier_forward_roles"].append("CP")
        cp = blend_probability(cp_nn["CP_probability"], cp_hist)
        cp_ref = save("CP_original_probabilities_before_threshold",
            dict(ids=fields["CP_ids"], probability=cp, neural=cp_nn["CP_probability"], hist=cp_hist, hist_fine=cp_fine), report)
        cp_truth = load(reg["native"], ("CP_y_coarse",), pins)["CP_y_coarse"]
        report["CP_truth_opened"] = True
        theta, metrics = helpers.network.choose_coarse_threshold(cp_truth, cp)
        report["CP_threshold_fit"] = 1
        report["files"]["threshold"] = helpers.json_new(OUT / "CP_once_theta_before_CAL.json",
            dict(threshold=float(theta), metrics=metrics, source_role="CP_original882",
                CP_probability=cp_ref, CAL_truth_used=False, CAL_features_opened=False,
                weight_or_parameter_sweep=False, threshold_fit_calls=1))
        report["CP_threshold_sealed"] = True
        report["protocol_events"].append("CP_threshold_sealed_before_CAL_features")
        stage = "one_unlabelled_CAL_probability_after_CP_threshold"
        helpers.require(report["CP_threshold_sealed"] and not report["CAL_truth_opened"],
                        "CAL_inference_only_after_CP_threshold_seal")
        cal_fields = load(reg["native"], ("CAL_native78",), pins)
        cal_nn = load(reg["primary_cached"], ("CAL_ids", "CAL_probability"), pins)
        helpers.require(np.array_equal(fields["CAL_ids"], cal_nn["CAL_ids"]), "same_fixed_original_NN_CAL_ID_order")
        cal_fine = fine_probabilities(classifier, np.ascontiguousarray(cal_fields["CAL_native78"], np.float32))
        cal_hist = 1. - cal_fine[:, 0]
        report["classifier_forward_roles"].append("CAL")
        cal = blend_probability(cal_nn["CAL_probability"], cal_hist)
        save("CAL_original_probabilities_before_truth",
            dict(ids=fields["CAL_ids"], probability=cal, neural=cal_nn["CAL_probability"], hist=cal_hist, hist_fine=cal_fine), report)
        predictions = dict(CP_prediction=(cp >= theta).astype(np.int64),
            CAL_prediction=(cal >= theta).astype(np.int64), CP_ids=fields["CP_ids"], CAL_ids=fields["CAL_ids"])
        predicted = save("fixed_known_predictions_before_CAL_truth_and_prior", predictions, report)
        report["files"]["prediction_seal"] = helpers.json_new(OUT / "known_prediction_seal_before_CAL_truth_and_prior.json",
            dict(predictions=predicted, CP_probability=cp_ref,
                CAL_probability=report["files"]["CAL_original_probabilities_before_truth"],
                model=report["files"]["model"], threshold=report["files"]["threshold"],
                CAL_truth_used=False, prior_predictions_used=False, threshold_fit_calls=1))
        report["prediction_sealed"] = True
        report["protocol_events"].append("both_known_predictions_sealed_before_CAL_truth_and_prior")
        stage = "postseal_full_known_gate_and_saved_parent_comparison"
        cal_truth = heldout_truth_after_seal(reg, pins, report)
        report["protocol_events"].append("CAL_truth_opened_after_complete_prediction_seal")
        prior = load(reg["prior_predictions"], tuple(role + "_" + key
            for role in ("CP", "CAL") for key in ("ids", "prediction")), pins)
        strong = load(reg["strong_predictions"], tuple(role + "_" + key
            for role in ("CP", "CAL") for key in ("ids", "truth", "candidate")), pins)
        report["prior_predictions_opened"] = True
        truth = dict(CP=cp_truth, CAL=cal_truth)
        gates, reporting, effects, reporting_effects, paired = {}, {}, {}, {}, {}
        for name in ("preceding_shared_binary_HGB_assistant", "original_strong_primary"):
            effects[name], reporting_effects[name] = {}, {}
        for role in ("CP", "CAL"):
            pred, idx, y = predictions[role + "_prediction"], fields[role + "_reporting_indices"], truth[role]
            helpers.require(np.array_equal(fields[role + "_ids"], prior[role + "_ids"])
                and np.array_equal(fields[role + "_ids"], strong[role + "_ids"])
                and np.array_equal(y, strong[role + "_truth"]), "postseal_full_known_ID_truth_alignment:" + role)
            helpers.require(idx.dtype == np.int64 and idx.shape == (900,)
                and np.array_equal(idx[:882], np.arange(882)) and np.all((idx >= 0) & (idx < 882)),
                "complete_originals_then_reporting_copies_only:" + role)
            gates[role], reporting[role] = helpers.gates(y, pred), helpers.gates(y[idx], pred[idx])
            paired.update({role + "_ids": fields[role + "_ids"], role + "_truth": y,
                role + "_candidate": pred, role + "_reporting_indices": idx})
            for name, before in (("preceding_shared_binary_HGB_assistant", prior[role + "_prediction"]),
                                 ("original_strong_primary", strong[role + "_candidate"])):
                effects[name][role] = helpers.paired(y, before, pred)
                reporting_effects[name][role] = helpers.paired(y[idx], before[idx], pred[idx])
                paired.update({role + "_" + name: before,
                    role + "_" + name + "_gain": (before != y) & (pred == y),
                    role + "_" + name + "_loss": (before == y) & (pred != y)})
        save("postseal_same_full_known_paired_predictions", paired, report)
        for asset, wanted in pins.items():
            helpers.require(helpers.sha(asset) == wanted, "hist_input_pin_unchanged:" + asset)
        helpers.require(reg["runtime_provenance"] == runtime_provenance(), "hist_runtime_provenance_unchanged")
        report.update(execution_status="hist_fine9_native78_assistant_known_controls_evaluated",
            known_gates=gates, effective_reporting_gates=reporting, EffectDelta=effects,
            reporting_EffectDelta=reporting_effects, coarse_threshold=float(theta),
            both_controls_integer99_passed=all(v["passed"] for group in gates.values() for v in group.values()),
            all_original_and_reporting_integer99_passed=all(v["passed"]
                for collection in (gates, reporting) for group in collection.values() for v in group.values()),
            runtime_provenance=reg["runtime_provenance"], unknown_phase_allowed=False,
            unknown_phase_requires_new_main_CAL_distance_alignment=True)
    except Exception as error:
        report.update(execution_status="execution_failed", failed_stage=stage,
            error_type=type(error).__name__, error=str(error))
        raise
    finally:
        report.update(registry=registry, input_sha256=pins, wall_seconds=time.perf_counter() - began)
        helpers.json_new(OUT / "report.json", report)
    return helpers.descriptor(OUT / "report.json")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=("freeze", "known"), required=True)
    parser.add_argument("--registry")
    parser.add_argument("--registry-sha256")
    args = parser.parse_args()
    if args.phase == "known" and (not args.registry or not args.registry_sha256):
        parser.error("known phase requires --registry and --registry-sha256")
    item = freeze() if args.phase == "freeze" else run(args.registry, args.registry_sha256)
    print(json.dumps(item, ensure_ascii=False))


if __name__ == "__main__":
    main()
