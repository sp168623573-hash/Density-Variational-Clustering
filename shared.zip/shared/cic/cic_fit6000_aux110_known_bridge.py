"""New FIT6000 AUX110 geometry, preserving the original stronger classifiers.

freeze: source metadata, headers and role ID values only. prepare/probe: Root
numerical entries for unique-FIT units, a fresh owned Eq9/10 state and a CP
known-loss probe. No unknown entry or new classifier acceptance is implemented.
The original primary CIC2 CAL KNA226/231 failure remains explicitly recorded.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import time

import numpy as np
import torch

from . import cic_fit6000_mhfd_training_v1 as nn
from . import cic_fit6000_fixed_forest_known_v1 as main
from . import cic_fit6000_aux110_pair_metric_v1 as learned
from . import cic1_hybrid110_currentcrop_v2 as geometry_core

ROOT=nn.ROOT
AUX={
    "CIC Setting1":dict(path="data/external_dev/processed/cic1_fit6000_mhfd_20261009_v1/train/report.json",sha256="a585f4a48b4ec781c6b5d326535633411380cb34fcbbccef424403eb45c70d5a"),
    "CIC Setting2":dict(path="data/external_dev/processed/cic2_fit6000_mhfd_20261009_v1/train/report.json",sha256="8ccf96010fe6196422821e5f0eba2fbab5f71ae07efeaf3db9fbe5791295b2a1")}
PRIMARY_NN={
    "CIC Setting1":dict(path="data/external_dev/processed/cic2017_native_known_training_20261008_v1/CIC_Setting1/report.json",sha256="5bde5afa2b732268ed31c5fe9937d4916a95da8f28a7e2d07249242ae6a54af7"),
    "CIC Setting2":dict(path="data/external_dev/processed/cic2017_setting2_signed_log_training_20261008_v1/CIC_Setting2/report.json",sha256="6c357bb7ed4c16308201cbf20897ea69b88c5bfb608a15636c646ceb5f00779e")}
C1_QUERY=dict(path="data/external_dev/processed/cic2017_native_partial_dev_pair_20261008_v1/CIC_Setting1/report.json",sha256="b470f0ea63d2c27a749e7188ed9b6cb57c5ae0dcec4169bf8a7b81878a89d4a7")
require,read,checked,json_new,npz_new=nn.require,nn.read,nn.checked,nn.json_new,nn.npz_new


def ids_only(item,key,pins):
    with np.load(checked(item,pins),allow_pickle=False) as saved:
        value=saved[key].copy()
    require(value.ndim==1 and value.dtype.kind=="U","ID_metadata_only")
    return value


def policy(setting):
    return dict(schema_version="CIC-own-FIT6000-MHFD50-AUX110-independent-novelty-known-bridge-v1",setting=setting,
        primary="original stronger own NN+forest; fixed old threshold and NN-only predictedfine9 argmax from original primary caches",
        new_auxiliary="new FIT6000 full-shared-loss MHFD50 frozen embedding32 only; rejected classifier heads unused",
        input110="originalnative78 signedlog/FITunique RMS, followed by new auxiliary embedding32/FITunique RMS",
        units="new original FIT groups only; zero column RMS exactly1; no copies or CP/CAL in fit",
        metric="fresh own110 Eq9/10, fixed80 CPU; original group fine memberships and new FIT IDs/source state coupling",
        reference="unique original FIT; actual fine labels; rare Heart7 originals no optimizer copies in density",
        radius="same-fine min(7,n-1) other-group radius; self excluded; no positive floor",
        score="nearest primary-NN-predictedfine learned distance d2/(d2+r2), largest radius on exact ties, bothzero0",
        cutoffs="CAL original scores, primary predictedcoarse conditional finite99 order statistic; strictgreater",
        known_probe="fixed original CP only, then prediction seal, true labels and paired loss0 vs unchanged primary",
        gate="original CP BEN/KNA integer99 AND loss0 of both classes; pure auxiliary evaluation, no new classifier gate relaxation",
        primary_CAL_gate_claim="preserve and report existing primary CAL failures; not a classifier promotion or all4 known gate certificate",
        unknown_entry=False,unknown_reads=0,unknown_roster_changed=False,new_NN_training=0,new_forest_training=0,
        old_fitted_metric_reused=False,density_copies=0,physical_independence_claimed=False,
        status="FAIL_TARGET99",published=False,final_test_executed=False,accepted_baseline_replaced=False)


def freeze(setting,output_directory):
    require(setting in AUX,"own_setting")
    out=Path(output_directory).resolve()
    require(out.is_relative_to(ROOT) and out!=ROOT,"fresh_workspace_output")
    out.mkdir(parents=True,exist_ok=False)
    pins={}
    aux=read(AUX[setting],pins)
    material=read(aux["material"],pins)
    primary=read(main.MAIN_PROOF[setting],pins)
    primary_nn=read(PRIMARY_NN[setting],pins)
    source_arrays=material["source_arrays"]
    checked(source_arrays,pins)
    headers=nn.header_tools.npz_headers(Path(source_arrays["path"]))
    cache={}
    for role in ("CP","CAL"):
        if setting=="CIC Setting1":
            item=primary["CP_candidates" if role=="CP" else "CAL_predictions"]
            cache[role]=dict(asset=item,ids=role+"_ids",prediction="w3_prediction" if role=="CP" else "candidate_prediction")
        else:
            item=primary["files"]["paired"]
            cache[role]=dict(asset=item,ids=role+"_ids",prediction=role+"_candidate")
        old_ids=ids_only(item,cache[role]["ids"],pins)
        own_ids=ids_only(source_arrays,role+"_ids",pins)
        main.same_ids(own_ids,old_ids,role)
        main.same_ids(own_ids,ids_only(primary_nn["files"]["predictions"],role+"_ids",pins),"primaryNN_"+role)
        aux_item=aux["files"][role+"_complete_inference_before_guard"]
        h=nn.header_tools.npz_headers(checked(aux_item,pins))
        require(h["embedding"]["shape"]==[len(own_ids),32],"new_auxiliary_complete_known_embedding")
    fit_count=6000 if setting=="CIC Setting1" else 5987
    require(headers["FIT_native78"]["shape"]==[fit_count,78]
            and nn.header_tools.npz_headers(checked(aux["files"]["FIT_complete_inference_before_guard"],pins))["embedding"]["shape"]==[fit_count,32],"new_true_FIT_originals_coupled_embedding_header")
    old_gates={"CP":primary["selected"]["class_gates"],"CAL":primary["CAL_class_gates"]} if setting=="CIC Setting1" else primary["original_class_gates"]
    require(all(row["passed"] for row in old_gates["CP"].values()),"primary_CP_gate_already_failed_cannot_protect")
    identity=dict(primary_CP_calibration_control_roles_distinct=True,CP_equals_old_current_query_known_prefix=None)
    if setting=="CIC Setting1":
        query_path=ROOT/C1_QUERY["path"]
        query=read(C1_QUERY,pins)
        mixed=ids_only(query["DVC_inputs"],"ids",pins)
        cp=ids_only(source_arrays,"CP_ids",pins)
        cal=ids_only(source_arrays,"CAL_ids",pins)
        require(len(mixed)==4056 and np.array_equal(mixed[:900],cp) and not np.array_equal(mixed[:900],cal)
                and not(set(cp.tolist())&set(cal.tolist())),"current4056_known900_exact_CP_not_CAL")
        identity.update(CP_equals_old_current_query_known_prefix=True,current_query_rows=4056,known_prefix_rows=900,
            CP_CAL_ID_intersection=0,current_query_metadata_report=dict(path=str(query_path),sha256=nn.sha(query_path)))
    for module in (Path(__file__),Path(learned.__file__),Path(geometry_core.__file__),Path(geometry_core.dvc.__file__),Path(nn.__file__)):
        pins[str(module.resolve())]=nn.sha(module)
    registry=dict(schema_version="CIC-FIT6000-AUX110-new-geometry-registry-before-numeric-v1",setting=setting,
        output_directory=str(out),configuration=policy(setting),new_aux_report=AUX[setting],new_aux_model=aux["files"]["model"],
        new_aux_embedding={role:aux["files"][role+"_complete_inference_before_guard"] for role in ("FIT","CP","CAL")},
        new_aux_preprocessing=material["preprocessing"],new_known_arrays=source_arrays,
        primary_report=main.MAIN_PROOF[setting],primary_NN_report=PRIMARY_NN[setting],primary_NN_known=primary_nn["files"]["predictions"],
        primary_cache=cache,primary_existing_gates=old_gates,
        primary_CAL_all_known_gates_passed=all(row["passed"] for row in old_gates["CAL"].values()),
        primary_CP_all_known_gates_passed=True,family_order=material["family_order"],known_probe_identity=identity,
        unknown_current_known_prefix_CIC2_proven=False if setting=="CIC Setting2" else None,
        original_unknown_entry_required_after_known_probe="fresh feature-only newAux embedding inference+same primary branch on fixed original query; not implemented in this known-only bridge",
        material_headers=headers,input_sha256=pins,numeric_geometry_or_models_executed=0,
        status="FAIL_TARGET99",published=False,final_test_executed=False)
    return json_new(out/"registry_before_aux110_material.json",registry)


def rms_unique(values):
    a=np.asarray(values,np.float64)
    require(a.ndim==2 and len(a)>0 and np.isfinite(a).all(),"finite_uniqueFIT_for_RMS")
    maximum=np.max(np.abs(a),axis=0)
    nonzero=maximum>0
    units=np.ones(a.shape[1],np.float64)
    units[nonzero]=maximum[nonzero]*np.sqrt(np.mean((a[:,nonzero]/maximum[nonzero])**2,axis=0))
    require(np.isfinite(units).all() and np.all(units>0),"positive_finite_FITunits")
    return units


def prepare(registry_item):
    pins={}
    reg=read(registry_item,pins)
    require(reg["configuration"]==policy(reg["setting"]),"frozen_aux110_recipe")
    for path,wanted in reg["input_sha256"].items():checked(dict(path=path,sha256=wanted),pins)
    out=Path(reg["output_directory"])/"prepare"
    out.mkdir(exist_ok=False)
    with np.load(checked(reg["new_known_arrays"],pins),allow_pickle=False) as saved:
        arrays={role+"_"+key:saved[role+"_"+key].copy() for role in ("FIT","CP","CAL") for key in ("native78","ids","y_fine","y_coarse")}
    embedding={}
    for role in ("FIT","CP","CAL"):
        with np.load(checked(reg["new_aux_embedding"][role],pins),allow_pickle=False) as saved:embedding[role]=saved["embedding"].astype(np.float64)
    fit_log=np.sign(arrays["FIT_native78"])*np.log1p(np.abs(arrays["FIT_native78"]))
    native_units,embedding_units=rms_unique(fit_log),rms_unique(embedding["FIT"])
    units=json_new(out/"new_original_FIT_native78_embedding32_units.json",dict(native78=native_units.tolist(),embedding32=embedding_units.tolist(),
        FIT_original_rows=len(fit_log),optimizer_copies_used=False,source=reg["new_known_arrays"],aux_model=reg["new_aux_model"]),pins)
    fields={}
    for role in ("FIT","CP","CAL"):
        native=arrays[role+"_native78"]
        native_scaled=(np.sign(native)*np.log1p(np.abs(native)))/native_units
        fields[role+"_Z110"]=np.concatenate((native_scaled,embedding[role]/embedding_units),axis=1)
        fields[role+"_ids"]=arrays[role+"_ids"]
        fields[role+"_fine"]=arrays[role+"_y_fine"]
        fields[role+"_truth"]=arrays[role+"_y_coarse"]
        fields[role+"_groups"]=np.asarray([hashlib.sha256(row.tobytes(order="C")).hexdigest() for row in native],dtype=np.str_)
        require(len(set(fields[role+"_groups"].tolist()))==len(native),"density_uses_unique_original_groups")
        if role!="FIT":
            cache=reg["primary_cache"][role]
            with np.load(checked(cache["asset"],pins),allow_pickle=False) as saved:
                main.same_ids(fields[role+"_ids"],saved[cache["ids"]],role)
                fields[role+"_stage1"]=saved[cache["prediction"]].copy()
            with np.load(checked(reg["primary_NN_known"],pins),allow_pickle=False) as saved:
                main.same_ids(fields[role+"_ids"],saved[role+"_ids"],"primaryfine_"+role)
                p=saved[role+"_fine_probability"].copy()
            require(p.shape==(len(native),9) and np.isfinite(p).all(),"actual_primary_NN_fine9")
            fields[role+"_predicted_fine"]=np.argmax(p,axis=1).astype(np.int64)
    kwargs=dict(known_fine_labels=list(range(9)),fit_ids=fields["FIT_ids"].tolist(),fit_group_ids=fields["FIT_groups"].tolist(),fit_roles=["FIT"]*len(fields["FIT_ids"]))
    material=npz_new(out/"new_coupled_known_AUX110_before_metric_fit.npz",fields,pins)
    prefit=learned.prefit_descriptor(fields["FIT_Z110"],fields["FIT_fine"],**kwargs)
    prefit_item=json_new(out/"new_owned110_metric_prefit.json",prefit,pins)
    return json_new(out/"prepared_before_metric_fit.json",dict(schema_version="CIC-newFIT6000-AUX110-material-before-metric-v1",registry=registry_item,
        material=material,units=units,metric_prefit=prefit_item,metric_prefit_sha256=prefit["prefit_sha256"],
        primary_existing_gates=reg["primary_existing_gates"],new_aux_model=reg["new_aux_model"],input_sha256=pins,
        unknown_reads=0,new_NN_fits=0,new_metric_fits=0,status="FAIL_TARGET99",published=False,final_test_executed=False))


def probe(registry_item,prepared_item):
    pins={}
    reg,prepared=read(registry_item,pins),read(prepared_item,pins)
    require(prepared["registry"]==registry_item,"own_aux110_material_registry")
    for path,wanted in prepared["input_sha256"].items():checked(dict(path=path,sha256=wanted),pins)
    out=Path(reg["output_directory"])/"known_probe"
    out.mkdir(exist_ok=False)
    report=dict(setting=reg["setting"],configuration=policy(reg["setting"]),files={},new_NN_fits=0,new_forest_fits=0,
        new_metric_fits=0,unknown_reads=0,unknown_query_allowed=False,primary_existing_gates=reg["primary_existing_gates"],
        primary_CAL_all_gates_passed=reg["primary_CAL_all_known_gates_passed"],classifier_promoted=False,
        accepted_baseline_replaced=False,status="FAIL_TARGET99",published=False,final_test_executed=False)
    began,stage=time.perf_counter(),"own_new110_FIT_metric_fit"
    threads=torch.get_num_threads()
    try:
        with np.load(checked(prepared["material"],pins),allow_pickle=False) as saved:fields={key:saved[key].copy() for key in saved.files}
        prefit=read(prepared["metric_prefit"],pins)
        metric=learned.fit_known_metric(fields["FIT_Z110"],fields["FIT_fine"],expected_prefit_sha256=prefit["prefit_sha256"],
            known_fine_labels=list(range(9)),fit_ids=fields["FIT_ids"].tolist(),fit_group_ids=fields["FIT_groups"].tolist(),fit_roles=["FIT"]*len(fields["FIT_ids"]))
        report["new_metric_fits"]=1
        state=json_new(out/"new_owned110_metric_state.json",dict(setting=reg["setting"],aux_model=reg["new_aux_model"],known_arrays=reg["new_known_arrays"],
            prepared=prepared_item,metric_payload=metric.to_state()),pins)
        report["files"]["metric"]=state
        refs=geometry_core.make_reference(fields)
        def sink(prefix):
            return lambda label,value: report["files"].update({prefix+str(label):npz_new(out/(prefix+str(label)+".npz"),value,pins)})
        stage="new_FIT_samefine_R7_radius"
        radius=geometry_core.fit_radii(metric,refs,sink("FIT_fine_distance_"))
        report["files"]["reference_radius"]=npz_new(out/"new_FIT110_reference_and_radius.npz",{**refs,"radius":radius},pins)
        stage="same_primary_CAL_scores_and_once_conditional99_cutoff"
        cal=geometry_core.scores(metric,fields["CAL_Z110"],fields["CAL_predicted_fine"],refs,radius,sink("CAL_fine_distance_"))
        cutoffs=geometry_core.dvc.calibrate_known_cutoffs(cal,fields["CAL_stage1"])
        report["files"]["cutoffs"]=json_new(out/"new_primaryCAL_conditional99_cutoffs_before_CP.json",dict(cutoffs=cutoffs,primary_report=reg["primary_report"],
            primary_CAL_classifier_gate=reg["primary_existing_gates"]["CAL"],primaryfine="originalNNfine argmax",unknown_used=False,metric=state),pins)
        stage="same_original_CP_metric_scores_DVC_and_prediction_seal"
        score=geometry_core.scores(metric,fields["CP_Z110"],fields["CP_predicted_fine"],refs,radius,sink("CP_fine_distance_"))
        raw=geometry_core.dvc.candidate_mask(score,fields["CP_stage1"],cutoffs)
        current=geometry_core.dvc.route_current_candidates(metric,fields["CP_Z110"],raw,seed=20261009)
        retained=raw&current["retained"]
        prediction=fields["CP_stage1"].copy();prediction[retained]=2
        report["files"]["CP_prediction_before_truth"]=npz_new(out/"original_CP_candidate_prediction_before_truth.npz",dict(ids=fields["CP_ids"],prediction=prediction,primary=fields["CP_stage1"],raw=raw,retained=retained),pins)
        report["files"]["prediction_seal"]=json_new(out/"CP_prediction_seal_before_gate.json",dict(predictions=report["files"]["CP_prediction_before_truth"],metric=state,cutoffs=report["files"]["cutoffs"],trueCP_used_for_route=False),pins)
        effect=nn.paired(fields["CP_truth"],fields["CP_stage1"],prediction)
        gates=nn.gates(fields["CP_truth"],prediction)
        loss={name:int(np.sum((fields["CP_truth"]==code)&(fields["CP_stage1"]==code)&(prediction!=code))) for code,name in enumerate(("BEN","KNA"))}
        passed=all(row["passed"] for row in gates.values()) and all(value==0 for value in loss.values())
        report.update(execution_status="CIC_newFIT6000_AUX110_independent_novelty_originalCP_probe_completed",known_CP_gates=gates,
            known_CP_loss=loss,EffectDelta_vs_unchanged_primary=effect,known_probe_passed=passed,
            unknown_query_allowed=passed,known_CP_raw=int(raw.sum()),known_CP_retained=int(retained.sum()),
            full_all4_classifier_acceptance_claimed=False,primary_classifier_gate_not_relaxed=True,
            auxiliary_state_classification_heads_unused=True,metric_training_seconds=metric.to_state()["trained"]["training_seconds"])
        for path,wanted in pins.items():require(nn.sha(path)==wanted,"new_geometry_input_or_output_changed:"+path)
    except Exception as error:
        report.update(execution_status="protocol_stop" if isinstance(error,(nn.old1.NativeKnownTrainingStop,learned.PairMetricProtocolStop)) else "execution_failed",
            failed_stage=stage,error_type=type(error).__name__,error_message=str(error))
    finally:
        torch.set_num_threads(threads)
        report["threads_restored"]=torch.get_num_threads()==threads
    report["wall_seconds"]=time.perf_counter()-began
    report["registry"]=registry_item;report["prepared"]=prepared_item;report["input_sha256"]=pins
    return json_new(out/"report.json",report)


def main_cli(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("phase",choices=("freeze","prepare","probe"))
    p.add_argument("--setting",choices=tuple(AUX));p.add_argument("--output-directory",type=Path)
    p.add_argument("--registry",type=Path);p.add_argument("--registry-sha256")
    p.add_argument("--prepared",type=Path);p.add_argument("--prepared-sha256")
    a=p.parse_args(argv)
    if a.phase=="freeze":item=freeze(a.setting,a.output_directory)
    else:
        registry=dict(path=str(a.registry.resolve()),sha256=a.registry_sha256)
        item=prepare(registry) if a.phase=="prepare" else probe(registry,dict(path=str(a.prepared.resolve()),sha256=a.prepared_sha256))
    print(json.dumps(item,ensure_ascii=False))
    if a.phase=="probe":
        result=json.loads(Path(item["path"]).read_text(encoding="utf-8"))
        return 0 if result["execution_status"]=="CIC_newFIT6000_AUX110_independent_novelty_originalCP_probe_completed" else 2 if result["execution_status"]=="protocol_stop" else 1
    return 0


if __name__=="__main__":raise SystemExit(main_cli())
