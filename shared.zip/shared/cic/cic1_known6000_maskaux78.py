"""Known-only complete78 field-mask auxiliary; original primary is frozen."""
from __future__ import annotations
import argparse
from collections import Counter
import json
from pathlib import Path
import time
import numpy as np
import torch
from torch import nn
from torch.utils.data import WeightedRandomSampler
from . import cic_fit6000_mhfd_training_v1 as helpers
from . import nsl1_expanded_fit6000_maskaux_v1 as core

ROOT=helpers.ROOT
BASE=ROOT/'data/external_dev/processed/cic1_known6000_maskaux78_20261010_v1'
SCHEMA='CIC1-known6000-full78-whole-field-maskaux-final80-v1'
MATERIAL=dict(path=str(ROOT/'data/external_dev/processed/cic1_fit6000_mhfd_20261009_v1/material/material_report_before_fit.json'),sha256='16fd31875b8eb30fc0a8362f3f9351791246f2b17cc4d87c0c764433569627bb')
GEOMETRY=dict(path=str(ROOT/'data/external_dev/processed/cic1_fit6000_aux110_known_20261010_v1/prepare/prepared_before_metric_fit.json'),sha256='f7333a04a03f18cb4f2d91d030ce29d6d8e9376262adf6aecc486d6de5674efd')
files=core.files
FAMILIES=('BEN',*helpers.get_spec('CIC Setting1').known_families)

def recipe():
    return dict(schema_version=SCHEMA,setting='CIC Setting1',input_width=78,fields=78,
        original_FIT=6000,optimizer_draws=6000,roles=dict(FIT=6000,CAL=900,CP=900),
        input='complete originalnative78 signed-log divided by already sealed uniqueFIT RMS; no selection',
        loss='clean coarseCE +.35 clean fineCE(.01 smoothing) +.03 masked-field-only SmoothL1',
        mask='balanced one originalnumeric field per draw; learned field token; exact unit1 in normalized coordinates',
        model='paper MHFD attention/gating/CNN/BiLSTM/known heads/decoder plus78 field tokens',
        seed=20261009,epochs=80,batch_size=128,optimizer='AdamW .001 wd.0002 cosine min.0001 clip5',
        checkpoint='final80, no per-epoch heldout inference',
        primary='original stronger classifier unchanged; new heads are diagnostics only',
        diagnostic_threshold='one CAL coarse-head threshold before CP; no unknown values opened',
        source_and_representation_objective_joint=True,unknown_training=False,preprocessing_fit=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)

def freeze():
    pins={};mat=files.js(MATERIAL,pins);geom=files.js(GEOMETRY,pins)
    fields=list(helpers.CIC_FEATURE_COLUMNS)
    mapping=dict(schema_version=core.mask_core.FIELD_SCHEMA,selected_width=78,nonempty_group_count=78,
        groups=[dict(field=f,kind='numeric',selected_columns=[i]) for i,f in enumerate(fields)],
        selected_column_mapping=[dict(selected_index=i,encoded_name=f,original_field=f) for i,f in enumerate(fields)])
    fmap=core.field_map_from_state(mapping)
    reg=dict(schema_version=SCHEMA+'-registry',policy=recipe(),source=files.item(__file__),
        native=mat['source_arrays'],units=geom['units'],field_map=mapping,field_map_sha256=fmap.file_sha256,
        sources={Path(m.__file__).name:files.item(m.__file__) for m in (core,core.previous,core.mask_core,helpers,helpers.network)},
        output=str(BASE),unknown_values_read=False)
    for a in (reg['native'],reg['units'],*reg['sources'].values()):files.read(a,pins)
    reg['input_sha256']=pins
    directory=ROOT/'tmp/cic1_known6000_maskaux78_20261010_v1';directory.mkdir(exist_ok=True)
    return files.write(directory/'registry_before_known_mask_training.json',reg)

def train(path,sha):
    pins={};reg_a=dict(path=str(Path(path).resolve()),sha256=sha);reg=files.js(reg_a,pins)
    files.require(reg['policy']==recipe() and reg['source']==files.item(__file__),'own frozen CIC1 mask source')
    for p,h in reg['input_sha256'].items():files.read(dict(path=p,sha256=h),pins)
    files.require(not BASE.exists(),'fresh known-mask output');BASE.mkdir(parents=True)
    before=core.capture_runtime_flags();started=time.perf_counter()
    report=dict(schema_version=SCHEMA,registry=reg_a,policy=recipe(),files={},counts=dict(training_runs=0,
        known_infer_attempts=0,known_infer_returns=0,known_forward_batches=0),unknown_values_opened=False,
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        raw=core.previous.archive(reg['native'],tuple(r+'_'+k for r in ('FIT','CAL','CP') for k in ('native78','ids'))
            +('FIT_y_fine','FIT_y_coarse','CAL_y_coarse'),pins)
        units=np.asarray(files.js(reg['units'],pins)['native78'],np.float64)
        files.require(units.shape==(78,) and np.isfinite(units).all() and np.all(units>0),'same frozen FIT-only native units')
        x={r:((np.sign(raw[r+'_native78'])*np.log1p(np.abs(raw[r+'_native78'])))/units).astype(np.float32) for r in ('FIT','CAL','CP')}
        files.require(x['FIT'].shape==(6000,78) and all(np.isfinite(v).all() for v in x.values()),'complete finite realknown roles')
        counts=Counter(raw['FIT_y_fine'].tolist());files.require(set(counts)==set(range(9)) and min(counts.values())>=20,'all9 originalFIT families')
        core.previous.save(BASE,'known78_inputs_before_training',dict(**{r+'_features':v for r,v in x.items()},
            **{r+'_ids':raw[r+'_ids'] for r in x}),report)
        fmap=core.field_map_from_state(reg['field_map']);files.require(fmap.file_sha256==reg['field_map_sha256'],'field map unchanged')
        torch.set_num_threads(4);helpers.network.set_seed(20261009)
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu');net=core.ExpandedWholeFieldMaskedMHFD(fmap,9).to(device)
        opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.0002)
        sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=80,eta_min=.0001)
        scaler=torch.amp.GradScaler('cuda',enabled=device.type=='cuda')
        sampler=WeightedRandomSampler(helpers.network._hierarchical_sample_weights(raw['FIT_y_fine']),num_samples=6000,
            replacement=True,generator=torch.Generator().manual_seed(20261009))
        report['files']['prefit']=files.write(BASE/'policy_before_fit.json',dict(registry=reg_a,policy=recipe(),
            field_map=reg['field_map'],units=reg['units'],known_inputs=report['files']['known78_inputs_before_training']))
        history=[];began=time.perf_counter();report['counts']['training_runs']=1
        for epoch in range(1,81):
            net.train();idx=np.asarray(list(sampler),np.int64);masks=core.balanced_schedule(6000,78,epoch=epoch-1);total=0.;seen=0
            for first in range(0,6000,128):
                ix=idx[first:first+128];xb=torch.from_numpy(x['FIT'][ix].copy()).to(device)
                cb=torch.from_numpy(raw['FIT_y_coarse'][ix].copy()).to(device);fb=torch.from_numpy(raw['FIT_y_fine'][ix].copy()).to(device)
                masked=torch.from_numpy(masks[first:first+len(ix)].copy()).to(device);opt.zero_grad(set_to_none=True)
                with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=device.type=='cuda'):
                    values=core.known_objective(net,xb,cb,fb,masked,roles=['FIT']*len(ix))
                scaler.scale(values['loss']).backward();scaler.unscale_(opt);nn.utils.clip_grad_norm_(net.parameters(),5.)
                scaler.step(opt);scaler.update();total+=float(values['loss'].detach())*len(ix);seen+=len(ix)
            sched.step();history.append(dict(epoch=epoch,loss=total/seen,optimizer_draws=seen))
            core.save_epoch_history(BASE,history,epoch,report)
            if epoch==1 or epoch%10==0:print(f'[CIC1 native78 maskaux] epoch={epoch}/80 loss={total/seen:.6f} elapsed={time.perf_counter()-began:.1f}s',flush=True)
        report.update(training_seconds=time.perf_counter()-began,epochs_completed=80,device=str(device))
        state=core.output_io.state_digest(net);checkpoint=BASE/'full78_maskaux_final80.pt'
        with checkpoint.open('xb') as f:torch.save(dict(state_dict={k:v.detach().cpu() for k,v in net.state_dict().items()},
            input_dim=78,classes=list(FAMILIES),field_map=reg['field_map'],field_map_sha256=fmap.file_sha256,model_state_sha256=state),f)
        report['files']['model']=files.item(checkpoint);report['model_state_sha256']=state;net.eval()
        outputs={r:core.infer_once(net,x[r],r,BASE,report) for r in ('FIT','CAL')}
        theta,metric=helpers.network.choose_coarse_threshold(raw['CAL_y_coarse'],outputs['CAL']['coarse_attack_probability'])
        report['files']['threshold']=files.write(BASE/'CAL_coarse_diagnostic_before_CP.json',dict(threshold=float(theta),metric=metric,CP_truth_used=False))
        outputs['CP']=core.infer_once(net,x['CP'],'CP',BASE,report)
        pred={r+'_prediction':(v['coarse_attack_probability']>=theta).astype(np.int64) for r,v in outputs.items()}
        pa=core.previous.save(BASE,'known_predictions_before_CP_truth',pred,report)
        report['files']['prediction_seal']=files.write(BASE/'known_prediction_seal_before_CP_truth.json',dict(prediction=pa,CP_truth_opened=False))
        truth=core.previous.archive(reg['native'],('CP_y_coarse',),pins)['CP_y_coarse']
        report.update(execution_status='CIC1_full78_maskaux_known_evaluated',known_gates={r:helpers.gates(raw[r+'_y_coarse'] if r!='CP' else truth,pred[r+'_prediction']) for r in outputs},
            primary_classifier_unchanged=True,unknown_performance_measured=False,new_geometry_or_reconstruction_CAL_required=True)
        files.require(core.output_io.state_digest(net)==state,'masked state unchanged duringclean inference')
    except Exception as error:report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        after=core.restore_runtime_flags(before);report['runtime_restoration']=dict(before=before,after=after,all_flags_restored=after==before)
        report['wall_seconds']=time.perf_counter()-started;report['input_sha256']=pins;files.write(BASE/'report.json',report)
    return files.item(BASE/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','train'),required=True)
    p.add_argument('--registry');p.add_argument('--registry-sha256');a=p.parse_args()
    print(json.dumps(freeze() if a.phase=='freeze' else train(a.registry,a.registry_sha256)))
