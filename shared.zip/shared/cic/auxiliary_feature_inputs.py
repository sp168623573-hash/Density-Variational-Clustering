"""Exact CIC2 roles/whole817, fresh-aux raw78 inputs, old249 identity only.

No role data is read on import/manifest preparation. Current raw values are
materialized only when the frozen current-predict phase calls load_role.
"""
from pathlib import Path
import hashlib,importlib.util,io,json,sys
import numpy as np
H=Path(__file__).resolve().parent;MANIFEST=H/'INPUT_MANIFEST_V1018.json'

def require(ok,message):
    if not bool(ok):raise ValueError(message)

def descriptor(path):
    p=Path(path).resolve(strict=True);return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def raw(d):
    b=Path(d['path']).read_bytes();require(hashlib.sha256(b).hexdigest()==d['sha256'],'immutable input bytes');return b

def js(d):return json.loads(raw(d).decode('utf-8-sig'))

def arrays(d,keys):
    with np.load(io.BytesIO(raw(d)),allow_pickle=False)as a:return{k:a[k].copy()for k in keys}

def module(d,tag):
    raw(d);s=importlib.util.spec_from_file_location(tag+'_'+d['sha256'],d['path']);m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m);return m

def manifest():return json.loads(MANIFEST.read_text(encoding='utf-8'))

def original():return module(manifest()['inherited_inputs'],'V1018_exact_whole817_inputs')

def _groups(native):
    a=np.asarray(native,np.float64);return np.asarray([hashlib.sha256(np.ascontiguousarray(r).tobytes()).hexdigest()for r in a],dtype='U64')

def load_source():
    m=manifest();s=original().load_source();a=arrays(m['raw_source'],('FIT_ids','FIT_native78','FIT_y_fine','FIT_training_indices'))
    require(np.array_equal(s['ids'],a['FIT_ids'])and np.array_equal(s['fine'],a['FIT_y_fine'])and
            np.array_equal(s['groups'],_groups(a['FIT_native78'])),'exact genuine source raw78/fine/physical ordering')
    require(a['FIT_native78'].shape==(5987,78)and len(np.unique(s['groups']))==5987 and
            np.array_equal(s['original_optimizer_indices'],a['FIT_training_indices']),'original genuine5987 and unchanged logical6000 parent map')
    require(np.bincount(s['fine'],minlength=9).tolist()==[4545,100,100,317,256,7,100,462,100]and
            len(s['logical_fine'])==6000,'source original9fine and FIT-only rare resampling preserved')
    return dict(s,native=np.asarray(a['FIT_native78'],np.float64),raw_native78=np.asarray(a['FIT_native78'],np.float64),
                source_trace=dict(s['source_trace'],auxiliary_input='raw78, not old frozen mean/std encoding',new_raw_preprocessing_fit_by_R_only_core=True))

def load_role(role):
    require(role in('CAL','CP','current'),'declared complete role only');m=manifest();q=original().load_role(role)
    a=arrays(m['raw_roles'][role],('ids','native78'))
    require(np.array_equal(a['ids'],q['ids'])and np.array_equal(_groups(a['native78']),q['groups'])and
            a['native78'].shape==(m['role_rows'][role],78),'same whole role raw78/IDs/physical groups, no label loading')
    return dict(q,native=np.asarray(a['native78'],np.float64),raw_native78=np.asarray(a['native78'],np.float64))

def load_known_labels(role):
    require(role in('CAL','CP'),'actual882 known controls only; alias900 not independent traffic')
    return original().load_known_labels(role)

def fixed_metric():
    m=original().fixed_metric();require(m.dimension==249,'original249 is fallback identity only');return m

def prepare_manifest():
    old=Path('E:/Experiment/software transcition/target99_v1008_20261024/cic2');m=js(descriptor(old/'INPUT_MANIFEST_V1008.json'))
    r950=descriptor('E:/Experiment/software transcition/target99_v950_20261023/cic2/CIC2_V950_INPUT_AND_WARM_OWNER_MANIFEST.json');r=js(r950)
    value=dict(m,schema='V1018_CIC2_FRESH_R_ONLY_RPL_RAW78_ON_WHOLE817',
        inherited_inputs=descriptor(old/'inputs_v1008.py'),inherited_input_manifest=descriptor(old/'INPUT_MANIFEST_V1008.json'),
        raw_owner_manifest=r950,raw_source=r['source_assets']['native'],raw_roles={role:r['roles'][role]['geometry']for role in('CAL','CP','current')},
        original_known_label_and_alias_authority=r['known_label_authority'],actual_known_role_rows=882,alias_CP900_is_not_independent=True,
        native_input_units='raw78; new auxiliary R-only transform',old_native_encoded_input_reused_for_aux=False,
        density_geometry_dimension=184,old_fallback_geometry_dimension=249,new_auxiliary_NN_models=9,new_auxiliary_metric_fit=1,
        newNNfit=9,newNNreadout='planned_auxiliary_readouts_actual_counts_in_source_report',newmetricfit=1,
        main_NN_fit=0,main_NN_readout=0,main_metric_fit=0,current_truth_requires_actual_known_controls_capacity_and_root_authority=True,
        source_role_membership_owner='immutable V1008 source bundle R/V/Q indices',no_numeric_role_read_during_manifest=True,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    H.mkdir(parents=True,exist_ok=True)
    with MANIFEST.open('x',encoding='utf-8')as f:json.dump(value,f,ensure_ascii=False,indent=2)
    return descriptor(MANIFEST)

if __name__=='__main__':print(json.dumps(prepare_manifest(),ensure_ascii=False))
