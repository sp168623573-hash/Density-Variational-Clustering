"""One fixed known-FIT joint78 masked-error model with fine/port conditioning.

CAL/CP masks are recomputed on CPU to match the complete existing current CPU
error cache. Query labels and IDs do not enter cell selection, fit or score.
"""
from __future__ import annotations

import argparse
import io
import json
from pathlib import Path
import time

import numpy as np
import torch
from sklearn.covariance import LedoitWolf
import sklearn.covariance._shrunk_covariance as runtime_covariance

from . import cic1_mask78_conditional_mean_current_v1 as previous

known_rule, trained, context = previous.known_rule, previous.trained, previous.context
ROOT, files = previous.ROOT, previous.files
BASE = ROOT/'data/external_dev/processed/cic1_mask78_joint_fine_port_20261011_v1'
SCHEMA = 'CIC1-fixed-FIT-joint78-CPU-masked-error-fine-port-LedoitWolf-v1'
PREVIOUS = dict(path=str(previous.BASE/'current/report.json'),
    sha256='f17b63a7aec3b9358b2ea7bf492fc9f40dbea240c9d9b74e8296f23a4addf51e')


def policy():
    return dict(schema_version=SCHEMA,setting='CIC Setting1',
        producer='unchanged real final80 full78 maskaux network; exact frozen native78 signedlog/FIT RMS',
        context='CPU float32 eval, threads4, all78 fields individually masked on each genuine row',
        fitting='genuine uniqueFIT6000 only; true known fine labels and observed native Destination Port',
        cell='one model per trueFIT fine and observed integral destination port if support>=20; otherwise truefine-global model',
        covariance='LedoitWolf auto shrinkage on log1p(all78 masked squared errors); empirical known-cell centre and target variance only',
        constants='exact zero FIT variance columns excluded from covariance; explicit natural unit1 squared deviations retained in joint distance; no epsilon',
        score='(joint active Mahalanobis squared distance + unit1 constant-field squared deviations)/78',
        selector='original frozen primary predicted_fine and observed original native Destination Port; no query truth or ID rule',
        CAL='one original900 predicted-coarse finite99 cutoff fitted before CP; strict greater; no sweep',
        known='complete original900 CP; paired zero known-correct loss and BEN/KNA integer99 before current cache values',
        current='all original4056; exact existing CPU all78 masked-error cache; zero current NN forward replay',
        geometry='same frozen learned110; fresh label-blind DVC/affinity/reconstruction/noise',
        merge='copy real T41_799 baseline and add only this raw AND this currentDVC retained; retain every old UNA decision',
        fixed_candidate_count=1,parameter_grid=False,NN_training_runs=0,NN_training_seconds=0,
        train_union_unique_rows=6000,metric_fit=0,native_units_fit=0,query_model_or_CAL_fit=0,
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)


def port_keys(native):
    native=np.asarray(native,np.float64)
    files.require(native.ndim==2 and native.shape[1]==78 and np.isfinite(native).all(),
        'complete finite original native78')
    port=native[:,0]
    files.require(np.all((port>=0)&(port<=65535)) and np.array_equal(port,np.floor(port)),
        'observed native Destination Port is integral uint16; no binning or guessed field')
    return port.astype(np.int64)


def cell_key(fine,port):
    return str(int(fine))+'|'+str(int(port))


def fit_cell(log_error):
    value=np.asarray(log_error,np.float64)
    files.require(value.ndim==2 and value.shape[1]==78 and len(value)>=20 and np.isfinite(value).all(),
        'genuine FIT cell minimum20 finite all78 log errors')
    centre=value.mean(axis=0)
    # Equality of original values identifies mathematical constant fields;
    # rounding of a repeated mean must not create a spurious positive variance.
    constant=np.all(value==value[0],axis=0)
    active=np.flatnonzero(~constant)
    covariance=np.empty((0,0));factor=np.empty((0,0));shrinkage=0.;target=0.
    if len(active):
        detector=LedoitWolf(store_precision=True,assume_centered=False,block_size=1000).fit(value[:,active])
        covariance=np.asarray(detector.covariance_,np.float64)
        precision=np.asarray(detector.precision_,np.float64)
        eigen,vectors=np.linalg.eigh((precision+precision.T)/2.)
        positive=eigen>0
        # PSD factorization gives a nonnegative squared distance. Zero/negative
        # numerical precision eigenvalues contribute zero; no epsilon is added.
        factor=vectors[:,positive]*np.sqrt(eigen[positive])[None,:]
        shrinkage=float(detector.shrinkage_)
        target=float(np.mean(np.var(value[:,active],axis=0)))
        files.require(np.isfinite(covariance).all() and np.isfinite(factor).all()
            and target>0 and 0<=shrinkage<=1,'finite genuine known auto-shrinkage covariance')
    centre[constant]=value[0,constant]
    return dict(support=len(value),centre=centre.tolist(),active=active.tolist(),
        constant=np.flatnonzero(constant).tolist(),covariance=covariance.tolist(),
        precision_factor=factor.tolist(),shrinkage=shrinkage,
        empirical_isotropic_target_variance=target,
        constant_field_units='exact unit1',precision_rank=int(factor.shape[1]) if len(active) else 0)


def fit_models(error,true_fine,ports):
    error=np.asarray(error,np.float64);fine=np.asarray(true_fine);ports=np.asarray(ports)
    files.require(error.shape==(6000,78) and np.isfinite(error).all() and np.all(error>=0)
        and fine.shape==ports.shape==(6000,) and np.isin(fine,range(9)).all(),
        'original6000 known masked errors and known fine only')
    log=np.log1p(error);models={};cells={}
    for label in range(9):
        rows=fine==label
        models[str(label)]=fit_cell(log[rows])
        for port in np.unique(ports[rows]):
            subset=rows&(ports==port)
            if int(subset.sum())>=20:
                cells[cell_key(label,port)]=fit_cell(log[subset])
    return dict(fine_global=models,fine_port_cells=cells,
        cell_minimum_unique_support=20,fit_rows=6000,query_used_for_fit=False,
        formula=policy()['score'],selector=policy()['selector'])


def score(error,predicted_fine,ports,model):
    error=np.asarray(error,np.float64);fine=np.asarray(predicted_fine);ports=np.asarray(ports)
    files.require(error.ndim==2 and error.shape[1]==78 and np.isfinite(error).all() and np.all(error>=0)
        and fine.shape==ports.shape==(len(error),) and np.isin(fine,range(9)).all(),
        'only fixed masked errors and predicted known fine and observed port enter score')
    log=np.log1p(error);result=np.empty(len(log));used=np.empty(len(log),dtype='<U40')
    selectors={}
    for i,(label,port) in enumerate(zip(fine,ports)):
        exact=cell_key(label,port)
        key='port:'+exact if exact in model['fine_port_cells'] else 'fine:'+str(int(label))
        selectors.setdefault(key,[]).append(i)
    for key,rows in selectors.items():
        node=model['fine_port_cells'][key[5:]] if key.startswith('port:') else model['fine_global'][key[5:]]
        delta=log[rows]-np.asarray(node['centre'])
        active=np.asarray(node['active'],np.int64);constant=np.asarray(node['constant'],np.int64)
        distance=np.square(delta[:,constant]).sum(axis=1)
        if len(active):
            factor=np.asarray(node['precision_factor'],np.float64)
            distance+=np.square(delta[:,active]@factor).sum(axis=1)
        result[rows]=distance/78.
        used[rows]=key
    files.require(np.isfinite(result).all() and np.all(result>=0),'finite fixed joint Mahalanobis distances')
    return result,used


def masked_errors(net,x,role,out,report):
    x=np.ascontiguousarray(x,np.float32);error=np.empty((len(x),78),np.float64)
    began=time.perf_counter()
    with torch.no_grad():
        for field in range(78):
            for first in range(0,len(x),1024):
                stop=min(first+1024,len(x));xb=torch.from_numpy(x[first:stop].copy())
                values=net.forward_masked(xb,torch.full((len(xb),),field,dtype=torch.int64))
                live={key:value.detach().numpy().copy() if value.dtype==torch.bool
                    else value.detach().float().numpy().copy() for key,value in values.items()}
                trained.core.previous.save(out,role+'_field'+str(field)+'_batch'+str(first),live,report)
                report['masked_forward_batches']+=1
                error[first:stop,field]=np.square(live['reconstruction'][:,field].astype(np.float64)-x[first:stop,field])
            if (field+1)%13==0:
                print(f'[CIC1 joint78 CPU] role={role} fields={field+1}/78 rows={len(x)} elapsed={time.perf_counter()-began:.1f}s',flush=True)
    files.require(np.isfinite(error).all(),'complete finite all78 masked errors after actual capture')
    report['role_masked_inference_seconds'][role]=time.perf_counter()-began
    trained.core.previous.save(out,role+'_all78_CPU_masked_errors',dict(error=error),report)
    return error


def freeze():
    pins={};old=files.js(PREVIOUS,pins);oldreg=files.js(old['registry'],pins)
    train=files.js(oldreg['producer_report'],pins);trainreg=files.js(train['registry'],pins)
    files.require(old['masked_fields_completed']==78 and old['device']=='cpu'
        and old['original_rows']==4056 and old['prediction_sealed'],
        'actual complete same-context4056 CPU masked cache')
    files.require(oldreg['original_native_field_order']==list(trained.helpers.CIC_FEATURE_COLUMNS)
        and oldreg['original_native_field_order'][0]=='Destination Port',
        'canonical native destination port field binding')
    assets=dict(known110=oldreg['assets']['known110'],native_known=trainreg['native'],
        known_inputs=train['files']['known78_inputs_before_training'],native_units=trainreg['units'],
        mask_model=oldreg['assets']['mask_model'],query110=oldreg['assets']['query110'],
        cached_current_errors=old['files']['full4056_all78_masked_field_errors_before_score'],
        cached_current_native=old['files']['full4056_native_inputs_before_masked_forward'],
        comparator=oldreg['assets']['comparator'],truth=oldreg['assets']['truth'],
        owned_metric=oldreg['assets']['owned_metric'])
    for asset in assets.values():files.read(asset,pins)
    sources={Path(module.__file__).name:files.item(module.__file__) for module in
        (previous,known_rule,trained,trained.core,trained.core.previous,context,
            context.geometry,context.geometry.dvc,context.bridge.learned,files)}
    registry=dict(schema_version=SCHEMA+'-registry-before-known-FIT-joint-model',policy=policy(),
        source=files.item(__file__),sources=sources,runtime_covariance_source=files.item(runtime_covariance.__file__),
        previous_current=PREVIOUS,producer_report=oldreg['producer_report'],geometry_registry=oldreg['geometry_registry'],
        assets=assets,comparator_key=oldreg['comparator_key'],field_map_sha256=trainreg['field_map_sha256'],
        model_state_sha256=oldreg['model_state_sha256'],native_field_order=oldreg['original_native_field_order'],
        outputs={phase:str(BASE/phase) for phase in ('known','current')},input_sha256=pins,
        freeze_numeric_arrays_decoded=0,unknown_labels_used=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    out=ROOT/'tmp/cic1_mask78_joint_fine_port_20261011_v1';out.mkdir(exist_ok=False)
    return files.write(out/'registry_before_known_CPU_joint_fine_port_fit.json',registry)


def run(phase,path,sha,known_path=None,known_sha=None):
    pins={};ref=dict(path=str(Path(path).resolve()),sha256=sha);reg=files.js(ref,pins)
    files.require(reg['source']==files.item(__file__) and reg['policy']==policy(),
        'exact fixed single joint candidate source')
    files.require(reg['runtime_covariance_source']==files.item(runtime_covariance.__file__),
        'installed LedoitWolf source unchanged')
    for asset in reg['sources'].values():files.read(asset,pins)
    if phase=='current':
        files.require(known_path and known_sha,'own actual full-known zero-loss receipt required')
        control=files.js(dict(path=str(Path(known_path).resolve()),sha256=known_sha),pins)
        files.require(control['registry']==ref and control['known_gate_passed']
            and control['known_correct_loss']==dict(BEN=0,KNA=0),'own full900 gates before current error values')
    out=Path(reg['outputs'][phase]);out.mkdir(parents=True,exist_ok=False)
    before=trained.core.capture_runtime_flags();began=time.perf_counter()
    report=dict(schema_version=SCHEMA,phase=phase,registry=ref,policy=policy(),files={},
        masked_forward_batches=0,role_masked_inference_seconds={},DVC_calls=0,
        NN_training_runs=0,NN_training_seconds=0,joint_covariance_fit=0,CAL_cutoff_fit=0,
        metric_fit=0,native_units_fit=0,current_masked_forward_replays=0,query_model_or_CAL_fit=0,
        device='cpu',CPU_threads=4,CUDA_calls=0,prediction_sealed=False,truth_opened=False,
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        torch.set_num_threads(4)
        if phase=='known':
            fields=context.selected(reg['assets']['known110'],('FIT_ids','FIT_groups','FIT_fine')+
                tuple(role+'_'+key for role in ('CAL','CP') for key in ('ids','groups','Z110','stage1','predicted_fine')),pins)
            native=context.selected(reg['assets']['native_known'],tuple(role+'_'+key
                for role in ('FIT','CAL','CP') for key in ('ids','native78')),pins)
            inputs=context.selected(reg['assets']['known_inputs'],tuple(role+'_'+key
                for role in ('FIT','CAL','CP') for key in ('ids','features')),pins)
            files.require(len(set(fields['FIT_groups'].tolist()))==6000,'genuine unique6000 FIT; copies excluded')
            sets={role:set(fields[role+'_groups'].tolist()) for role in ('FIT','CAL','CP')}
            files.require(all(not sets[a]&sets[b] for a,b in (('FIT','CAL'),('FIT','CP'),('CAL','CP'))),
                'original known role group disjointness')
            rms=np.asarray(files.js(reg['assets']['native_units'],pins)['native78'])
            for role in ('FIT','CAL','CP'):
                files.require(np.array_equal(fields[role+'_ids'],native[role+'_ids'])
                    and np.array_equal(fields[role+'_ids'],inputs[role+'_ids']), 'same original known role order')
                norm=(np.sign(native[role+'_native78'])*np.log1p(np.abs(native[role+'_native78'])))/rms
                files.require(np.array_equal(norm.astype(np.float32),inputs[role+'_features']),
                    'exact known network input signedlog and frozenRMS')
                if role!='FIT':files.require(np.array_equal(norm,fields[role+'_Z110'][:,:78]),
                    'exact known learned110 native78 context')
            stored=torch.load(io.BytesIO(files.read(reg['assets']['mask_model'],pins)),map_location='cpu',weights_only=True)
            fmap=trained.core.field_map_from_state(stored['field_map'])
            files.require(fmap.file_sha256==reg['field_map_sha256'],'exact native78 field map')
            net=trained.core.ExpandedWholeFieldMaskedMHFD(fmap,9).cpu()
            net.load_state_dict(stored['state_dict'],strict=True);net.eval()
            files.require(trained.core.output_io.state_digest(net)==reg['model_state_sha256'],'exact known producer model state')
            fit_error=masked_errors(net,inputs['FIT_features'],'FIT6000',out,report)
            fit_began=time.perf_counter()
            model=fit_models(fit_error,fields['FIT_fine'],port_keys(native['FIT_native78']))
            report['joint_covariance_fit']=1;report['known_covariance_fit_seconds']=time.perf_counter()-fit_began
            report['files']['model']=files.write(out/'genuineFIT6000_joint78_LedoitWolf_fine_port_before_CAL.json',model)
            cal_error=masked_errors(net,inputs['CAL_features'],'CAL900',out,report)
            cal_score,cal_cells=score(cal_error,fields['CAL_predicted_fine'],port_keys(native['CAL_native78']),model)
            ca=trained.core.previous.save(out,'CAL_joint_scores_before_CP',dict(ids=fields['CAL_ids'],score=cal_score,
                stage1=fields['CAL_stage1'],predicted_fine=fields['CAL_predicted_fine'],cell=cal_cells),report)
            cut=context.geometry.dvc.calibrate_known_cutoffs(cal_score,fields['CAL_stage1'])
            files.require(all(node['enabled'] for node in cut.values()),'finite original coarseCAL99')
            report['CAL_cutoff_fit']=1
            report['files']['cutoffs']=files.write(out/'once_originalCAL900_joint_cutoffs_before_CP.json',
                dict(cutoffs=cut,source=ca,model=report['files']['model'],CP_used=False,unknown_used=False))
            error=masked_errors(net,inputs['CP_features'],'CP900',out,report)
            files.require(trained.core.output_io.state_digest(net)==reg['model_state_sha256'],'masked model unchanged')
            query=context.role_query(fields,'CP');ports=port_keys(native['CP_native78'])
        else:
            model=files.js(control['files']['model'],pins)
            cut=files.js(control['files']['cutoffs'],pins)['cutoffs']
            query=context.selected(reg['assets']['query110'],('ids','groups','Z110','stage1','predicted_fine'),pins)
            cached=context.selected(reg['assets']['cached_current_errors'],('ids','error'),pins)
            native=context.selected(reg['assets']['cached_current_native'],('ids','native78','normalized78'),pins)
            files.require(len(query['ids'])==len(set(query['groups'].tolist()))==4056
                and np.array_equal(query['ids'],cached['ids']) and np.array_equal(query['ids'],native['ids'])
                and cached['error'].shape==(4056,78), 'complete existing current4056 CPU error identity and unique density')
            rms=np.asarray(files.js(reg['assets']['native_units'],pins)['native78'])
            norm=(np.sign(native['native78'])*np.log1p(np.abs(native['native78'])))/rms
            files.require(np.array_equal(norm,query['Z110'][:,:78])
                and np.array_equal(norm.astype(np.float32),native['normalized78']),
                'exact current original native fields and same-contextCPU input')
            error=cached['error'];ports=port_keys(native['native78'])
            report['current_error_cache']=reg['assets']['cached_current_errors']
        current_score,cells=score(error,query['predicted_fine'],ports,model)
        trained.core.previous.save(out,'fixed_joint_scores_and_cells_before_DVC',
            dict(ids=query['ids'],score=current_score,predicted_fine=query['predicted_fine'],destination_port=ports,cell=cells),report)
        geometry=files.js(reg['geometry_registry'],pins)
        _,raw,retained=context.geometry.route(context.metric_from_registry(geometry,pins),query,current_score,cut,
            out,'joint78',report)
        if phase=='known':
            baseline_reg=files.js(files.js(known_rule.MASK_KNOWN,pins)['registry'],pins)
            # Only the prior known seal asset is decoded before the new known seal.
            oldreport=files.js(known_rule.MASK_KNOWN,pins)
            old=context.selected(oldreport['files']['complete_increment_before_truth'],('ids','baseline'),pins)
            files.require(baseline_reg['assets']['known110']==reg['assets']['known110'],'same original preserved known900 context')
            baseline=old['baseline']
        else:
            old=context.selected(reg['assets']['comparator'],('ids',reg['comparator_key']),pins)
            baseline=old[reg['comparator_key']]
        files.require(np.array_equal(old['ids'],query['ids']),'actual preserved comparator full same IDs')
        prediction=baseline.copy();prediction[raw&retained]=2
        files.require(np.all(prediction[baseline==2]==2),'every priorUNA prediction retained')
        pa=trained.core.previous.save(out,'complete_prediction_before_truth',dict(ids=query['ids'],baseline=baseline,
            prediction=prediction,raw=raw,retained=retained),report)
        report['files']['prediction_seal']=files.write(out/'complete_prediction_seal_before_truth.json',
            dict(prediction=pa,truth_opened=False,model=report['files']['model'] if phase=='known' else control['files']['model'],
                cutoffs=report['files']['cutoffs'] if phase=='known' else control['files']['cutoffs']))
        report['prediction_sealed']=True
        if phase=='known':y=context.selected(reg['assets']['known110'],('CP_truth',),pins)['CP_truth']
        else:
            truth=context.selected(reg['assets']['truth'],('ids','truth'),pins)
            files.require(np.array_equal(truth['ids'],query['ids']),'postseal complete4056 truth IDs');y=truth['truth']
        report['truth_opened']=True
        gates=context.integer_gates(y,prediction,known_only=phase=='known')
        oldg=context.integer_gates(y,baseline,known_only=phase=='known')
        gainloss={name:dict(gain=int(np.sum((y==code)&(baseline!=code)&(prediction==code))),
            loss=int(np.sum((y==code)&(baseline==code)&(prediction!=code))))
            for code,name in enumerate(gates)}
        delta={name:gates[name]['correct']-oldg[name]['correct'] for name in gates}
        positive,negative=any(value>0 for value in delta.values()),any(value<0 for value in delta.values())
        direction='MIXED' if positive and negative else 'UP' if positive else 'DOWN' if negative else 'UNCHANGED'
        loss={name:gainloss[name]['loss'] for name in ('BEN','KNA')}
        trained.core.previous.save(out,'postseal_paired_comparison',dict(ids=query['ids'],truth=y,baseline=baseline,
            prediction=prediction,raw=raw,retained=retained),report)
        report.update(execution_status='joint78_fine_port_'+phase+'_evaluated',original_class_gates=gates,
            baseline_class_gates=oldg,EffectDelta=dict(verdict=direction,correct_count_delta=delta,gain_loss=gainloss,
                same_original_IDs_and_order=True,accepted_baseline_replaced=False),known_correct_loss=loss,
            known_gate_passed=all(gates[name]['passed'] for name in ('BEN','KNA')) and not any(loss.values()),
            known_loss0_passed=not any(loss.values()),all_three_integer99_passed=phase=='current' and all(row['passed'] for row in gates.values()),
            rows=len(y),raw_candidates=int(raw.sum()),retained_candidates=int(retained.sum()),
            raw_by_true_class={name:int(np.sum((y==code)&raw)) for code,name in enumerate(gates)},
            fine_global_models=len(model['fine_global']),fine_port_models=len(model['fine_port_cells']),
            original_NN_training_seconds=0,masked_inference_is_NN_training=False,
            reused_maskaux_actual_training_seconds=files.js(reg['producer_report'],pins)['training_seconds'])
        for bound,wanted in pins.items():files.require(files.item(bound)['sha256']==wanted,'all pinned source and assets unchanged')
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        report['runtime_restored']=trained.core.restore_runtime_flags(before)==before
        report['wall_seconds']=time.perf_counter()-began;report['input_sha256']=pins
        files.write(out/'report.json',report)
    return files.item(out/'report.json')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for name in ('registry','registry-sha256','known-report','known-sha256'):parser.add_argument('--'+name)
    args=parser.parse_args()
    print(json.dumps(freeze() if args.phase=='freeze' else run(args.phase,args.registry,args.registry_sha256,args.known_report,args.known_sha256)))
