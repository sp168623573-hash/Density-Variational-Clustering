"""Fixed CIC2 FIT-coverage forest blend with unchanged known controls."""
from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import io
import json
from pathlib import Path
import time

import joblib
import numpy as np
import sklearn
from sklearn.ensemble import ExtraTreesClassifier

from . import cic2017_setting2_known_fit_coverage_training_v1 as original

ROOT = Path(__file__).resolve().parents[1]
BASELINE = 'data/external_dev/processed/cic2017_setting2_known_fit_coverage_training_20261008_v1/CIC_Setting2/report.json'
BASELINE_SHA = '753346a9f6c9a276b9becdf5c3102b0905412c98389a8a086c82cfde607823a9'
PREVIOUS_FOREST = dict(path='data/external_dev/processed/cic2017_setting2_warm_known_forest_blend_20261008_v1/CIC_Setting2/report.json',
    sha256='e2a2c55da2d0cf8ad64164c4688bd43e0da857aee63e54bb38d266af8f83923c')
WEIGHTS = (0., .25, .5, .75)
FOREST_PARAMETERS = dict(n_estimators=256, max_features=1.0, min_samples_leaf=1, max_depth=None,
    bootstrap=False, class_weight='balanced', n_jobs=2, random_state=20261008)
POLICY = dict(schema_version='CIC2017-setting2-fixed-controls-FIT-coverage-forest-blend-v1', setting='CIC Setting2',
    datasets_used=['CIC-2017'], forest_parameters=FOREST_PARAMETERS, weights=WEIGHTS,
    actual_training_role='known_FIT_only', changed_FIT_groups=320, control_cohort_unchanged=True,
    fixed_recipe_same_as_previous_forest=True, CP_CAL_warm_same_original_IDs_and_order=True,
    primary_comparison='previous frozen forest on exactly same CP/CAL originals and report-only copy mappings', FIT_rows=4200, FIT_original_rows=4187, CP_rows=882, CAL_rows=882,
    CP_CAL_effective_reporting_rows=900, FIT_optimizer_copies=13, CP_CAL_reporting_copies_each=18,
    role_total_cap=6000, density_copy_rows=0, cross_setting_weights_transferred=False,
    selection_uses_CP_original_only=True, source_scope="explicitly warm; Heartbleed historical flags retained",
    fine_class_count=9, input='native78 numeric columns only; excludes IDs and labels',
    actual_tree_input_dtype='float32', target_dtype='int64 fine labels',
    coarse_formula='(1-w)*original_NN_attack_probability + w*(1-forest_BEN_probability)',
    minimum_NN_contribution=.25, null_weight=0., null_probability_dtype='unchanged original float32',
    nonnull_probability_dtype='float64', probability_aggregation='fixed estimator order float64 sum / 256',
    threshold_selection='unchanged model.choose_coarse_threshold on CP for each fixed weight',
    blend_selection='CP both integer99 pass, exact Fraction minimum recall, totalcorrect, smaller weight',
    calibration_scope='already observed warm CAL diagnostic; no selection or retry',
    planned_forest_training_runs=1, planned_forest_inference_roles=['CP','CAL'],
    new_NN_training_runs=0, new_NN_inference_runs=0, fine_head_and_embedding_unchanged=True,
    UNA_training_rows=0, DEV_executed=False, final_test_executed=False, published=False)
require, descriptor, checked = original.require, original.descriptor, original._checked
array_descriptor, write_json = original.array_descriptor, original._write


def _plain(value):
    if isinstance(value, dict): return {str(k): _plain(v) for k,v in value.items()}
    if isinstance(value, (list,tuple)): return [_plain(v) for v in value]
    if isinstance(value, np.generic): return value.item()
    return value


def _digest(value):
    return hashlib.sha256(json.dumps(_plain(value),sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()).hexdigest()


def _pin_json(path,value,pins):
    item=write_json(path,_plain(value));pins[item['path']]=item['sha256'];return item


def _save_npz(path,pins,**arrays):
    np.savez_compressed(path,**arrays)
    item=descriptor(path);pins[item['path']]=item['sha256'];return item


def _integrity(pins):
    for path,wanted in pins.items():require(original.sha(path)==wanted,'input_changed:'+path)


def _load_registered(pins):
    report=json.loads(checked({'path':BASELINE,'sha256':BASELINE_SHA},pins))
    require(report['execution_status']=='native_CIC2_fixed_controls_FIT_coverage_training_completed' and report['metrics_evaluated']
        and report['training_runs']==1 and report['configuration']['changed_FIT_groups']==320 and not report['DEV_executed'] and not report['final_test_executed'],
        'completed_registered_known_MHFD_baseline')
    for path,wanted in report['input_sha256'].items():
        resolved=Path(path).resolve()
        require(resolved.is_relative_to(ROOT) and original.sha(resolved)==wanted,'baseline_dependency_pin_changed:'+str(resolved))
        pins[str(resolved)]=wanted
    prefit=json.loads(checked(report['files']['prefit'],pins))
    source,arrays,records=original._load_source(prefit['source_report'],pins)
    threshold=json.loads(checked(report['files']['threshold'],pins))
    require(threshold['selection_role']=='CP' and threshold['CAL_labels_used'] is False
        and threshold['threshold']==report['coarse_threshold'],'old_CP_threshold_provenance')
    return report,arrays,records,threshold,source


def _read_cached_role(report,arrays,role,pins):
    # NPZ access is per-member: CAL probabilities are not decoded during CP selection.
    payload=checked(report['files']['predictions'],pins)
    fields=('ids','truth','fine_truth','probability','prediction')
    with np.load(io.BytesIO(payload),allow_pickle=False) as z:
        cached={name:z[role+'_'+name].copy() for name in fields}
    require(np.array_equal(cached['ids'],arrays[role+'_ids'])
        and np.array_equal(cached['truth'],arrays[role+'_y_coarse'])
        and np.array_equal(cached['fine_truth'],arrays[role+'_y_fine']),'original_NN_role_identity:'+role)
    p=cached['probability'];require(p.dtype==np.float32 and p.shape==(original.ROLES[role],)
        and np.isfinite(p).all() and np.all((p>=0)&(p<=1)),'original_NN_float32_probability:'+role)
    prediction=(p>=report['coarse_threshold']).astype(np.int64)
    require(array_descriptor(prediction)==array_descriptor(cached['prediction'])
        and original._gates(arrays[role+'_y_coarse'],prediction)==report['known_class_gates'][role],
        'exact_old_NN_prediction_and_gates:'+role)
    return cached


def _tree_input(native):
    require(native.dtype==np.float64 and native.ndim==2 and native.shape[1]==78 and np.isfinite(native).all(),
        'finite_native78_source_matrix')
    with np.errstate(over='ignore',invalid='ignore'): x=np.array(native,dtype=np.float32,order='C',copy=True)
    require(np.isfinite(x).all(),'native78_representable_as_tree_float32')
    return x


def _new_forest():return ExtraTreesClassifier(**FOREST_PARAMETERS)


def _check_fit_material(item,prefit,fit_x,fit_y,arrays,pins):
    seal=json.loads(checked(prefit,pins))
    require(array_descriptor(fit_x)==seal['actual_FIT_X'] and array_descriptor(fit_y)==seal['actual_FIT_y'],
        'live_FIT_arrays_equal_prefit_descriptors')
    with np.load(io.BytesIO(checked(item,pins)),allow_pickle=False) as z:
        require(set(z.files)=={'FIT_native78','FIT_tree_float32','FIT_y_fine','FIT_ids','FIT_training_indices'},'exact_prefit_archive_members')
        live={'FIT_native78':arrays['FIT_native78'],'FIT_tree_float32':fit_x,'FIT_y_fine':fit_y,'FIT_ids':arrays['FIT_ids'],'FIT_training_indices':arrays['FIT_training_indices']}
        require(all(array_descriptor(z[k])==array_descriptor(v) for k,v in live.items()),'live_FIT_material_equal_sealed_archive')
    require(array_descriptor(_tree_input(arrays['FIT_native78'])[arrays['FIT_training_indices']])==array_descriptor(fit_x)
        and array_descriptor(arrays['FIT_y_fine'][arrays['FIT_training_indices']])==array_descriptor(fit_y),'same_native78_to_tree_X_and_fine_target_rows')


def _forest_state(model):
    require(type(model) is ExtraTreesClassifier and len(model.estimators_)==256
        and model.n_features_in_==78 and model.n_outputs_==1
        and np.array_equal(model.classes_,np.arange(9,dtype=np.int64)), 'complete_nine_class_fixed_forest')
    trees=[]
    for tree in model.estimators_:
        state={}
        for key,value in tree.tree_.__getstate__().items():
            if isinstance(value,np.ndarray):
                state[key]=({name:array_descriptor(value[name]) for name in value.dtype.names}
                    if value.dtype.names else array_descriptor(value))
            else:state[key]=value
        trees.append(dict(parameters=tree.get_params(deep=False),tree_state=state,
            classes=array_descriptor(tree.classes_),n_classes=int(tree.n_classes_)))
    material=dict(parameters=model.get_params(deep=False),classes=array_descriptor(model.classes_),
        n_features=int(model.n_features_in_),n_outputs=int(model.n_outputs_),trees=trees)
    return {'state_sha256':_digest(material),'parameters':material['parameters'],'classes':model.classes_.tolist(),
        'tree_count':len(trees),'n_features':78,'tree_states_sha256':_digest(trees)}


def _predict_fine(model,x):
    require(x.dtype==np.float32 and x.ndim==2 and x.shape[1]==78 and np.isfinite(x).all(),'actual_forest_inference_matrix')
    require(np.array_equal(model.classes_,np.arange(9,dtype=np.int64)) and len(model.estimators_)==256,
        'BEN_is_class0_and_complete9classes')
    result=np.zeros((len(x),9),dtype=np.float64)
    for tree in model.estimators_:
        require(np.array_equal(tree.classes_,np.arange(9,dtype=np.int64)), 'every_tree_class_columns_follow_BEN0_order')
        contribution=np.asarray(tree.predict_proba(x,check_input=False),dtype=np.float64)
        require(contribution.shape==result.shape and np.isfinite(contribution).all()
            and np.all((contribution>=0)&(contribution<=1)),'valid_tree_probability')
        result+=contribution
    result/=256
    require(np.allclose(result.sum(axis=1),1.,rtol=0,atol=1e-12),'normalized_forest_probabilities')
    return result


def _blend(nn,forest_attack,weight):
    require(weight in WEIGHTS and nn.dtype==np.float32 and forest_attack.dtype==np.float64
        and nn.shape==forest_attack.shape,'fixed_weight_and_probability_precision')
    if weight==0.:return nn.copy()
    return (1.-weight)*nn.astype(np.float64)+weight*forest_attack


def _selection_key(entry):
    gates=entry['class_gates']
    return (all(g['passed'] for g in gates.values()),
        min(Fraction(g['correct'],g['support']) for g in gates.values()),
        sum(g['correct'] for g in gates.values()),-entry['weight'])


def _effect(baseline,candidate):
    require(all(baseline[k]['support']==candidate[k]['support'] for k in baseline),'same_known_EffectDelta_support')
    delta={k:candidate[k]['correct']-baseline[k]['correct'] for k in baseline};v=list(delta.values())
    verdict='UP' if min(v)>=0 and max(v)>0 else 'DOWN' if max(v)<=0 and min(v)<0 else 'UNCHANGED' if not any(v) else 'MIXED'
    return dict(verdict=verdict,correct_delta=delta,scope='same known role BEN/KNA; UNA not evaluated')


def _paired_view(truth,before,after):
    a,b=original._gates(truth,before),original._gates(truth,after)
    gain=(before!=truth)&(after==truth);loss=(before==truth)&(after!=truth)
    return dict(_effect(a,b),baseline_gates=a,candidate_gates=b,gain=int(gain.sum()),loss=int(loss.sum()),
        gained_by_class={name:int(gain[truth==i].sum()) for name,i in (('BEN',0),('KNA',1))},
        lost_by_class={name:int(loss[truth==i].sum()) for name,i in (('BEN',0),('KNA',1))})


def _paired_previous_forest(output,arrays,candidates,pins):
    """Only called after new CP selection and one CAL prediction are sealed."""
    previous=json.loads(checked(PREVIOUS_FOREST,pins))
    require(previous['execution_status']=='CIC2_warm_known_forest_blend_completed'
        and previous['metrics_evaluated'] is True and previous['selected']['weight']==.25
        and previous['configuration']['forest_parameters']==FOREST_PARAMETERS
        and tuple(previous['configuration']['weights'])==WEIGHTS,'same_fixed_previous_forest_recipe')
    results={};archive={}
    for role,item,key in (('CP',previous['CP_candidates'],'w1_prediction'),('CAL',previous['CAL_predictions'],'candidate_prediction')):
        with np.load(io.BytesIO(checked(item,pins)),allow_pickle=False) as z:
            require({key,role+'_ids',role+'_truth'}<=set(z.files),'previous_forest_control_members:'+role)
            before=z[key].copy();ids=z[role+'_ids'].copy();truth=z[role+'_truth'].copy()
        after=candidates[role];y=arrays[role+'_y_coarse'];indices=arrays[role+'_reporting_indices']
        require(array_descriptor(ids)==array_descriptor(arrays[role+'_ids'])
            and array_descriptor(truth)==array_descriptor(y),'same_previous_forest_control_ID_truth_bytes:'+role)
        require(before.dtype==after.dtype==np.int64 and before.shape==after.shape==y.shape
            and np.isin(before,[0,1]).all() and np.isin(after,[0,1]).all(),'same_known_prediction_shape_domain:'+role)
        baseline_gates=previous['selected_CP_class_gates'] if role=='CP' else previous['CAL_class_gates']
        require(original._gates(y,before)==baseline_gates
            and original._gates(y[indices],before[indices])==previous[role+'_effective_reporting_gates'],
            'previous_original_and_reporting_gates_exact:'+role)
        results[role]=dict(original=_paired_view(y,before,after),
            effective_reporting=_paired_view(y[indices],before[indices],after[indices]),
            original_rows=len(y),effective_reporting_rows=len(indices),report_only_copy_rows=len(indices)-len(y),
            same_original_IDs_and_order=True,scope='warm known controls; reporting copies do not add independent samples')
        archive.update({role+'_ids':ids,role+'_truth':y,role+'_previous_forest_prediction':before,
            role+'_candidate_prediction':after,role+'_reporting_indices':indices,
            role+'_gain':(before!=y)&(after==y),role+'_loss':(before==y)&(after!=y)})
    bound={k:array_descriptor(v) for k,v in archive.items()}
    item=_save_npz(output/'same_control_previous_forest_pair.npz',pins,**archive)
    with np.load(io.BytesIO(checked(item,pins)),allow_pickle=False) as z:
        require(set(z.files)==set(archive) and all(array_descriptor(z[k])==bound[k]==array_descriptor(v)
            for k,v in archive.items()),'paired_previous_forest_archive_exact')
    return results,item


def run_blend(*,output_directory):
    output=Path(output_directory).resolve();require(output.is_relative_to(ROOT) and output!=ROOT,'fresh_workspace_child_required')
    output.mkdir(parents=True,exist_ok=False)
    started,stage,pins=time.perf_counter(),'load_registered_known_baseline',{}
    report=dict(configuration=POLICY,status='FAIL_TARGET99',published=False,execution_status='not_completed',metrics_evaluated=False,
        DEV_executed=False,final_test_executed=False,full_Table1_final_claim=False,accepted_baseline_replaced=False,
        forest_fit_attempted=False,forest_fit_returned=False,forest_training_runs=0,
        forest_inference_roles_started=[],forest_inference_roles_returned=[],forest_inference_roles_completed=[],
        new_NN_training_runs=0,new_NN_inference_runs=0,selection_sealed=False,CAL_warm_diagnostic=True,
        CAL_cached_probability_read_attempted=False,CAL_cached_probability_read_returned=False,
        CAL_used_for_selection=False,runner_up_after_CAL_failure_allowed=False,fine_head_and_embedding_unchanged=True,
        promotion_status='NOT_PROMOTED')
    try:
        old,arrays,records,old_threshold,source=_load_registered(pins)
        for p in (Path(__file__),Path(original.__file__),Path(original.network.__file__),ROOT/'paper_open_set/config.py'):
            pins[str(p.resolve())]=original.sha(p)
        original._validate_arrays(arrays,records)
        cp=_read_cached_role(old,arrays,'CP',pins)
        null_threshold,_=original.network.choose_coarse_threshold(arrays['CP_y_coarse'],cp['probability'])
        require(null_threshold==old['coarse_threshold'] and array_descriptor(cp['probability'])==old_threshold['CP_probability'],
            'null_original_CP_threshold_and_probability_exact')
        stage='seal_actual_known_FIT_tree_inputs_before_fit'
        fit_x=_tree_input(arrays['FIT_native78'])[arrays['FIT_training_indices']];fit_y=np.array(arrays['FIT_y_fine'][arrays['FIT_training_indices']],dtype=np.int64,copy=True)
        model=_new_forest()
        fit_archive=_save_npz(output/'actual_FIT_arrays_before_forest_fit.npz',pins,
            FIT_native78=arrays['FIT_native78'],FIT_tree_float32=fit_x,FIT_y_fine=fit_y,FIT_ids=arrays['FIT_ids'],FIT_training_indices=arrays['FIT_training_indices'])
        prefit=_pin_json(output/'forest_recipe_before_fit.json',dict(configuration=POLICY,
            sklearn_version=sklearn.__version__,complete_forest_parameters=model.get_params(deep=False),
            baseline_report={'path':BASELINE,'sha256':BASELINE_SHA},source_files=source['files'],
            FIT_archive=fit_archive,actual_FIT_X=array_descriptor(fit_x),actual_FIT_y=array_descriptor(fit_y),
            family_order=original.FAMILIES,input_sha256=dict(pins)),pins)
        report.update(prefit=prefit,FIT_arrays=fit_archive)
        _integrity(pins);_check_fit_material(fit_archive,prefit,fit_x,fit_y,arrays,pins)
        before=[array_descriptor(fit_x),array_descriptor(fit_y)]
        stage='one_fixed_known_FIT_forest_fit';report.update(forest_fit_attempted=True,forest_training_runs=None)
        fit_started=time.perf_counter();model.fit(fit_x,fit_y);fit_seconds=time.perf_counter()-fit_started
        report.update(forest_fit_returned=True,forest_training_runs=1,forest_fit_seconds=float(fit_seconds))
        require(before==[array_descriptor(fit_x),array_descriptor(fit_y)],'forest_fit_inputs_unchanged')
        stage='freeze_complete_forest_before_CP_selection'
        state=_forest_state(model);model_path=output/'complete_known_forest.joblib';joblib.dump(model,model_path,compress=3)
        model_item=descriptor(model_path);pins[model_item['path']]=model_item['sha256']
        restored=joblib.load(io.BytesIO(checked(model_item,pins)))
        require(_forest_state(restored)==state,'complete_forest_roundtrip');model=restored
        proof=_pin_json(output/'actual_forest_training_proof.json',dict(actual_training_role='known_FIT_only',
            rows=4200,original_rows=4187,role_internal_Heart_copies=13,classes=9,training_runs=1,forest_fit_seconds=float(fit_seconds),prefit=prefit,
            actual_FIT_X=array_descriptor(fit_x),actual_FIT_y=array_descriptor(fit_y),model=model_item,state=state),pins)
        report.update(model=model_item,training_proof=proof)
        stage='CP_frozen_forest_inference'
        cp_x=_tree_input(arrays['CP_native78']);cp_before=array_descriptor(cp_x)
        report['forest_inference_roles_started'].append('CP');cp_fine=_predict_fine(model,cp_x)
        report['forest_inference_roles_returned'].append('CP')
        require(array_descriptor(cp_x)==cp_before and _forest_state(model)==state,'CP_input_and_model_unchanged')
        cp_attack=1.-cp_fine[:,0];candidates=[];cp_arrays=dict(CP_ids=arrays['CP_ids'],CP_truth=arrays['CP_y_coarse'],
            original_NN_probability=cp['probability'],forest_fine_probability=cp_fine,forest_attack_probability=cp_attack)
        for i,w in enumerate(WEIGHTS):
            probability=_blend(cp['probability'],cp_attack,w)
            threshold,metrics=(old['coarse_threshold'],{}) if w==0 else original.network.choose_coarse_threshold(arrays['CP_y_coarse'],probability)
            prediction=(probability>=threshold).astype(np.int64);gates=original._gates(arrays['CP_y_coarse'],prediction)
            if w==0:require(array_descriptor(prediction)==array_descriptor(cp['prediction']),'exact_null_CP_prediction')
            candidates.append(dict(weight=w,threshold=float(threshold),class_gates=gates,threshold_metrics=metrics,
                probability=array_descriptor(probability),prediction=array_descriptor(prediction)))
            cp_arrays[f'w{i}_probability']=probability;cp_arrays[f'w{i}_prediction']=prediction
        report['forest_inference_roles_completed'].append('CP')
        selected=max(candidates,key=_selection_key)
        cp_archive=_save_npz(output/'CP_candidates_before_selection.npz',pins,**cp_arrays)
        stage='seal_unique_CP_selection_before_CAL'
        selection=_pin_json(output/'selected_blend_before_CAL.json',dict(configuration=POLICY,
            candidates=candidates,selected=selected,model=model_item,model_state=state,prefit=prefit,training_proof=proof,
            CP_candidates=cp_archive,CAL_probability_opened=False,CAL_forest_inference_executed=False,
            CAL_labels_used_for_selection=False,input_sha256=dict(pins)),pins)
        report.update(selection=selection,selection_sealed=True,selected=selected,CP_candidates=cp_archive)
        _integrity(pins);require(_forest_state(model)==state,'frozen_model_before_CAL')
        stage='single_warm_CAL_forest_inference_and_frozen_comparison'
        report['CAL_cached_probability_read_attempted']=True
        cal=_read_cached_role(old,arrays,'CAL',pins)
        report['CAL_cached_probability_read_returned']=True
        cal_x=_tree_input(arrays['CAL_native78']);cal_before=array_descriptor(cal_x)
        report['forest_inference_roles_started'].append('CAL');cal_fine=_predict_fine(model,cal_x)
        report['forest_inference_roles_returned'].append('CAL')
        require(array_descriptor(cal_x)==cal_before and _forest_state(model)==state,'CAL_input_and_model_unchanged')
        cal_probability=_blend(cal['probability'],1.-cal_fine[:,0],selected['weight'])
        cal_prediction=(cal_probability>=selected['threshold']).astype(np.int64)
        cal_gates=original._gates(arrays['CAL_y_coarse'],cal_prediction)
        cal_indices=arrays['CAL_reporting_indices']
        cal_effective=original._gates(arrays['CAL_y_coarse'][cal_indices],cal_prediction[cal_indices])
        cp_index=WEIGHTS.index(selected['weight']);cp_indices=arrays['CP_reporting_indices']
        cp_effective=original._gates(arrays['CP_y_coarse'][cp_indices],cp_arrays[f'w{cp_index}_prediction'][cp_indices])
        if selected['weight']==0:require(array_descriptor(cal_prediction)==array_descriptor(cal['prediction']),'exact_null_CAL_prediction')
        report['forest_inference_roles_completed'].append('CAL')
        cal_archive=_save_npz(output/'warm_CAL_fixed_pair_predictions.npz',pins,CAL_ids=arrays['CAL_ids'],
            CAL_truth=arrays['CAL_y_coarse'],original_NN_probability=cal['probability'],baseline_prediction=cal['prediction'],
            forest_fine_probability=cal_fine,candidate_probability=cal_probability,candidate_prediction=cal_prediction)
        stage='sealed_predictions_same_fixed_controls_previous_forest_comparison'
        historical,paired_archive=_paired_previous_forest(output,arrays,
            {'CP':cp_arrays[f'w{cp_index}_prediction'],'CAL':cal_prediction},pins)
        report.update(paired_previous_forest=historical,paired_previous_forest_archive=paired_archive)
        stage='final_all_source_model_and_output_pins';_integrity(pins);require(_forest_state(model)==state,'final_forest_state')
        cp_pass=all(g['passed'] for v in (selected['class_gates'],cp_effective) for g in v.values());cal_pass=all(g['passed'] for v in (cal_gates,cal_effective) for g in v.values())
        report.update(execution_status='CIC2_fixed_controls_FIT_coverage_forest_blend_completed',metrics_evaluated=True,
            outcome='UNCHANGED_NULL_POLICY' if selected['weight']==0 else 'KNOWN_CP_CAL_PASS_NOT_UNA_OR_FINAL' if cp_pass and cal_pass else 'NO_GO_KNOWN_CLASS_GATE_FAILED',
            selected_CP_class_gates=selected['class_gates'],CAL_class_gates=cal_gates,
            CP_effective_reporting_gates=cp_effective,CAL_effective_reporting_gates=cal_effective,
            CP_passed=cp_pass,CAL_passed=cal_pass,original_roles=original.ROLES,effective_roles=original.EFFECTIVE_ROLES,
            EffectDelta={r:historical[r]['original'] for r in ('CP','CAL')},
            reporting_EffectDelta={r:historical[r]['effective_reporting'] for r in ('CP','CAL')},
            new_MHFD_EffectDelta={'CP':_effect(old['known_class_gates']['CP'],selected['class_gates']),
                'CAL':_effect(old['known_class_gates']['CAL'],cal_gates)},CAL_predictions=cal_archive,
            forest_inference_roles_count=2,old_NN_model_artifact=old['files']['model'])
    except Exception as error:
        report.update(execution_status='protocol_stop' if isinstance(error,original.NativeKnownTrainingStop) else 'execution_failed',
            failed_stage=stage,error_type=type(error).__name__,error_message=str(error),outcome='NOT_EVALUATED')
    report.update(input_sha256=pins,wall_seconds=time.perf_counter()-started)
    report=_plain(report);write_json(output/'report.json',report);return report


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output-directory',required=True)
    r=run_blend(output_directory=p.parse_args(argv).output_directory)
    print(json.dumps({k:r.get(k) for k in ('execution_status','outcome','forest_fit_seconds','selected','CAL_class_gates','failed_stage','error_message')},ensure_ascii=False))
    return 0 if r['metrics_evaluated'] else 2 if r['execution_status']=='protocol_stop' else 1


if __name__=='__main__':raise SystemExit(main())
