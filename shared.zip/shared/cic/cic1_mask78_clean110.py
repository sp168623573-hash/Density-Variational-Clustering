"""Own full78 masked-MHFD clean embedding and paper-distance novelty.

The frozen known-only field-mask model supplies clean embedding32, replacing
the older selected50 encoder in an explicitly new110 metric state. Original
primary classification and the saved799 DEV comparison are unchanged.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import time

import numpy as np
import torch

from . import cic1_label_conditional_support_v47 as previous
from . import cic1_mask78_clean110_pair_metric_v48 as learned
from . import cic_fit6000_aux110_known_bridge_v1 as bridge

ROOT, files, trained, context = previous.ROOT, previous.files, previous.trained, previous.context
geometry = context.geometry
BASE = ROOT/'data/external_dev/processed/cic1_mask78_clean110_20261011_v48'
REGDIR = ROOT/'tmp/cic1_mask78_clean110_20261011_v48'
PARENT = dict(path=str(previous.BASE/'known/report.json'),
    sha256='51ca9075ad60893f7d576d6fa388db96e080bc441a3403c2afeaf3ca37cf70d6')


def policy():
    return dict(schema_version='CIC1-full78-maskaux-clean110-owned-paper-distance-v48', hypotheses=1,
        encoder='frozen genuineFIT6000 full78 whole-field-mask MHFD final80 clean embedding32; new classification heads unused',
        main='original primary coarse/fine outputs unchanged; full original known900 and current4056',
        representation='complete signedlog native78 / frozen genuineFIT RMS plus clean maskaux embedding32 / new genuineFIT column RMS',
        inference='actual CPU float32 eval/no_grad fixed512 batch; every raw5 returned tensor captured before guards; same protocol all roles',
        metric='fresh own110 Eq9/10 metric, fixed80 CPU epochs8192 true-fine-balanced pairs; no old fitted metric',
        references='6000 genuine FIT groups, actual fine memberships; same-fine min(7,n-1) radii, no optimizer copies',
        score='nearest original-primary predictedfine learned d2/(d2+r2); exact tie uses largest same-fine radius; bothzero0',
        CAL='one finite99 cutoff per original predictedcoarse on all900 CAL, strictgreater; no query or truth cutoff tuning',
        DVC='new own110 metric, raw OR preserved predictedUNA density; original knee/SC/CH affinity/reconstruction/noise',
        merge='complete original799 comparison copy; append ownraw AND ownDVC retained only',
        known_gate='known900 BEN/KNA exact99 AND row-level correctloss0 before complete current values',
        train_union_unique_rows=6000, optimizer_traffic_rows=6000, new_NN_fit=0, query_parameter_fit=False,
        accepted_baseline_replaced=False, independent_final_claimed=False,
        status='FAIL_TARGET99', published=False, final_test_executed=False)


def freeze():
    pins = {}
    parent = files.js(PARENT, pins)
    oldreg = files.js(parent['registry'], pins)
    producer = files.js(
        dict(path=str(trained.BASE/'report.json'), sha256='7b5b0c052b4fc16aec4e944acc6c7f11d0725ec2785f1ffc9a2462a5be7a7106'), pins)
    assets = {k: oldreg['assets'][k] for k in ('native_known','native_RMS','known110','query110',
        'current_native','preserved_known_prediction','comparator','truth')}
    assets.update(mask_model=producer['files']['model'], producer_report=dict(
        path=str(trained.BASE/'report.json'), sha256='7b5b0c052b4fc16aec4e944acc6c7f11d0725ec2785f1ffc9a2462a5be7a7106'))
    files.require(producer['epochs_completed'] == 80 and not producer['unknown_values_opened'],
        'actual immutable known6000 full78 mask producer')
    for asset in assets.values(): files.read(asset, pins)
    modules = (trained, trained.core, trained.core.previous, trained.helpers, trained.helpers.network,
        learned, bridge, context, geometry, geometry.dvc, files)
    sources = {str(Path(m.__file__).resolve()): files.item(m.__file__) for m in modules}
    sources[str(Path(__file__).resolve())] = files.item(__file__)
    for asset in sources.values(): files.read(asset, pins)
    files.require(not BASE.exists() and not REGDIR.exists(), 'fresh own MASK78-CLEAN110 outputs')
    REGDIR.mkdir(parents=True, exist_ok=False)
    return files.write(REGDIR/'registry_before_mask78_clean110_known.json', dict(policy=policy(),
        assets=assets, sources=sources, parent=PARENT, mask_state_sha=producer['model_state_sha256'],
        comparator_key=oldreg['comparator_key'], metric_recipe=learned.training_recipe(110),
        outputs={phase: str(BASE/phase) for phase in ('known','current')}, input_sha256=pins,
        current_numeric_decodes=0, current_truth_decodes=0))


def network(reg, pins):
    saved = torch.load(io.BytesIO(files.read(reg['assets']['mask_model'], pins)), map_location='cpu', weights_only=True)
    fmap = trained.core.field_map_from_state(saved['field_map'])
    files.require(saved['input_dim'] == 78 and saved['field_map_sha256'] == fmap.file_sha256,
        'full78 masked checkpoint signature')
    net = trained.core.ExpandedWholeFieldMaskedMHFD(fmap, 9).cpu()
    net.load_state_dict(saved['state_dict'], strict=True)
    net.eval()
    files.require(trained.core.output_io.state_digest(net) == reg['mask_state_sha'], 'all exact masked network tensors')
    return net


@torch.no_grad()
def clean_embedding(net, value, role, out, report):
    values = []
    for start in range(0, len(value), 512):
        returned = net(torch.from_numpy(np.ascontiguousarray(value[start:start+512], np.float32)))
        raw = {key: returned[key].detach().cpu().numpy().copy() for key in (
            'coarse_logits','fine_logits','reconstruction','embedding','gate_mean')}
        trained.core.previous.save(out, role+'_clean_raw5_batch'+str(start)+'_before_guard', raw, report)
        report['clean_forward_batches'] += 1
        files.require(raw['embedding'].shape == (len(value[start:start+512]), 32)
            and all(np.isfinite(a).all() for a in raw.values()), 'actual finite full78 clean embedding32')
        values.append(raw['embedding'])
    embedding = np.concatenate(values).astype(np.float64)
    trained.core.previous.save(out, role+'_clean_embedding32_before_guard', dict(embedding32=embedding), report)
    return embedding


def group_ids(native):
    return np.asarray([hashlib.sha256(np.ascontiguousarray(row).tobytes()).hexdigest()
        for row in native], dtype=np.str_)


def distance_sink(out, report, tag):
    def sink(label, arrays):
        distance = arrays['distances']
        record = {k: v for k, v in arrays.items() if k != 'distances'}
        record.update(distance_descriptor=geometry.ad(distance), distance_shape=list(distance.shape),
            finite=bool(np.isfinite(distance).all()))
        report['files'][tag+str(label)] = files.write(out/(tag+str(label)+'.json'),
            {k: v.tolist() if isinstance(v,np.ndarray) else v for k,v in record.items()})
    return sink


def merged_route(metric, query, score, cut, baseline, out, report):
    raw = geometry.dvc.candidate_mask(score, query['stage1'], cut)
    density = raw | (baseline == 2)
    files.require(len(np.unique(query['groups'])) == len(query['groups']), 'one actual native density group per row')
    trained.core.previous.save(out, 'owned110_scores_and_density_before_DVC', dict(
        ids=query['ids'], score=score, stage1=query['stage1'], raw=raw, density=density), report)
    route = geometry.dvc.route_current_candidates(metric, query['Z110'], density, seed=20261009)
    report['DVC_calls'] += 1
    trained.core.previous.save(out, 'owned110_DVC_returns_before_truth',
        {k:v for k,v in route.items() if k != 'manifest'}, report)
    report['files']['DVC_manifest'] = files.write(out/'owned110_DVC_manifest_before_truth.json', route['manifest'])
    prediction = baseline.copy()
    prediction[raw & route['retained']] = 2
    files.require(np.all(prediction[baseline == 2] == 2), 'complete baseline predictedUNA preserved')
    return prediction, raw, density, route['retained']


def run(phase, path, sha, known_path=None, known_sha=None):
    pins = {}
    registry = dict(path=str(Path(path).resolve()), sha256=sha)
    reg = files.js(registry, pins)
    files.require(reg['policy'] == policy() and reg['metric_recipe'] == learned.training_recipe(110)
        and reg['sources'][str(Path(__file__).resolve())] == files.item(__file__), 'one own frozen full78 clean110 recipe')
    for asset in reg['sources'].values(): files.read(asset, pins)
    if phase == 'current':
        control = files.js(dict(path=str(Path(known_path).resolve()),sha256=known_sha), pins)
        files.require(control['registry'] == registry and control['known_gate_passed']
            and control['known_correct_loss'] == dict(BEN=0,KNA=0) and control['prediction_sealed'],
            'full900 integer known gate and zero correctloss before current values')
    out = Path(reg['outputs'][phase]); out.mkdir(parents=True, exist_ok=False)
    began, threads = time.perf_counter(), torch.get_num_threads()
    report = dict(policy=policy(), phase=phase, registry=registry, files={}, NN_fit=0,
        clean_forward_batches=0, metric_fit=0, units_fit=0, radius_fit=0, CAL_fit=0,
        DVC_calls=0, prediction_sealed=False, truth_opened=False, current_truth_used_for_tuning=False,
        accepted_baseline_replaced=False, status='FAIL_TARGET99', published=False, final_test_executed=False)
    try:
        torch.set_num_threads(4)
        net = network(reg,pins)
        native_units = np.asarray(files.js(reg['assets']['native_RMS'],pins)['native78'])
        if phase == 'known':
            source = context.selected(reg['assets']['native_known'],
                tuple(role+'_'+key for role in ('FIT','CAL','CP') for key in ('native78','ids')) + ('FIT_y_fine',), pins)
            old = context.selected(reg['assets']['known110'],
                tuple(role+'_'+key for role in ('CAL','CP') for key in ('ids','groups','stage1','predicted_fine')), pins)
            fields = {}
            embeddings = {}
            for role in ('FIT','CAL','CP'):
                native = source[role+'_native78']
                x = previous.raw_source.normalize(native,native_units)
                groups = group_ids(native)
                files.require(len(set(groups.tolist())) == len(native), 'real unique original '+role+' density groups')
                embeddings[role] = clean_embedding(net,x,role,out,report)
                fields.update({role+'_ids':source[role+'_ids'], role+'_groups':groups})
                if role != 'FIT':
                    files.require(np.array_equal(source[role+'_ids'],old[role+'_ids'])
                        and np.array_equal(groups,old[role+'_groups']), 'same original '+role+' native identity')
                    fields.update({role+'_'+key:old[role+'_'+key] for key in ('stage1','predicted_fine')})
            files.require(source['FIT_native78'].shape == (6000,78)
                and np.min(np.bincount(source['FIT_y_fine'],minlength=9)) >= 20, '6000 real knownFIT families min20')
            fields['FIT_fine'] = source['FIT_y_fine']
            units = bridge.rms_unique(embeddings['FIT']); report['units_fit'] = 1
            report['files']['units'] = files.write(out/'genuineFIT_clean_embedding32_units_before_metric.json',
                dict(embedding32=units.tolist(),native_units=reg['assets']['native_RMS'],
                    FIT_rows=6000,optimizer_copies_used=False,query_used=False,mask_model=reg['assets']['mask_model']))
            for role in ('FIT','CAL','CP'):
                fields[role+'_Z110'] = np.concatenate((previous.raw_source.normalize(source[role+'_native78'],native_units),
                    embeddings[role]/units),axis=1)
            trained.core.previous.save(out,'coupled_MASK78_CLEAN110_known_before_metric',fields,report)
            kw = dict(known_fine_labels=list(range(9)),fit_ids=fields['FIT_ids'].tolist(),
                fit_group_ids=fields['FIT_groups'].tolist(),fit_roles=['FIT']*6000)
            prefit = learned.prefit_descriptor(fields['FIT_Z110'],fields['FIT_fine'],**kw)
            report['files']['metric_prefit'] = files.write(out/'owned_MASK78_CLEAN110_before_metric_fit.json',prefit)
            metric = learned.fit_known_metric(fields['FIT_Z110'],fields['FIT_fine'],
                expected_prefit_sha256=prefit['prefit_sha256'],**kw); report['metric_fit'] = 1
            state = metric.to_state()
            report['metric_training_seconds'] = state['trained']['training_seconds']
            report['files']['metric'] = files.write(out/'owned_MASK78_CLEAN110_metric_state_before_CAL.json',
                dict(metric_payload=state,mask_model=reg['assets']['mask_model'],native=reg['assets']['native_known']))
            refs = geometry.make_reference(fields)
            radius = geometry.fit_radii(metric,refs,distance_sink(out,report,'FIT_fine_distance_')); report['radius_fit'] = 1
            trained.core.previous.save(out,'owned_MASK78_CLEAN110_reference_radius',dict(**refs,radius=radius),report)
            score = geometry.scores(metric,fields['CAL_Z110'],fields['CAL_predicted_fine'],refs,radius,
                distance_sink(out,report,'CAL_fine_distance_'))
            cut = geometry.dvc.calibrate_known_cutoffs(score,fields['CAL_stage1']); report['CAL_fit'] = 1
            report['files']['cutoffs'] = files.write(out/'originalCAL900_once_finite99_before_CP.json',
                dict(cutoffs=cut,CP_or_current_used=False,source=reg['assets']['native_known']))
            trained.core.previous.save(out,'CAL900_scores_before_CP',dict(ids=fields['CAL_ids'],score=score,stage1=fields['CAL_stage1']),report)
            query = context.role_query(fields,'CP')
            oldpred = context.selected(reg['assets']['preserved_known_prediction'],('ids','baseline'),pins)
            baseline = oldpred['baseline']
        else:
            units = np.asarray(files.js(control['files']['units'],pins)['embedding32'])
            metric = learned.PaperVariationalPairMetric.from_state(files.js(control['files']['metric'],pins)['metric_payload'])
            refs = context.selected(control['files']['owned_MASK78_CLEAN110_reference_radius'],
                ('Z110','membership','ids','groups','indices','radius'),pins)
            radius = refs.pop('radius')
            cut = files.js(control['files']['cutoffs'],pins)['cutoffs']
            native = context.selected(reg['assets']['current_native'],('ids','native78'),pins)
            old = context.selected(reg['assets']['query110'],('ids','groups','stage1','predicted_fine'),pins)
            files.require(np.array_equal(native['ids'],old['ids']) and len(native['ids']) == 4056
                and np.array_equal(group_ids(native['native78']),old['groups']), 'same complete4056 native groups/order')
            x = previous.raw_source.normalize(native['native78'],native_units)
            embedding = clean_embedding(net,x,'current4056',out,report)
            query = dict(old,Z110=np.concatenate((x,embedding/units),axis=1))
            trained.core.previous.save(out,'complete4056_MASK78_CLEAN110_before_scores',query,report)
            oldpred = context.selected(reg['assets']['comparator'],('ids',reg['comparator_key']),pins)
            baseline = oldpred[reg['comparator_key']]
        files.require(np.array_equal(query['ids'],oldpred['ids']), 'exact complete original comparator IDs')
        score = geometry.scores(metric,query['Z110'],query['predicted_fine'],refs,radius,
            distance_sink(out,report,phase+'_fine_distance_'))
        prediction,raw,density,retained = merged_route(metric,query,score,cut,baseline,out,report)
        pa = trained.core.previous.save(out,'complete_prediction_before_truth',dict(ids=query['ids'],prediction=prediction,
            baseline=baseline,raw=raw,density=density,retained=retained),report)
        report['files']['prediction_seal'] = files.write(out/'complete_prediction_seal_before_truth.json',
            dict(prediction=pa,truth_opened=False,model=reg['assets']['mask_model'],metric=report['files'].get('metric',None)))
        report['prediction_sealed'] = True
        if phase == 'known': y = context.selected(reg['assets']['known110'],('CP_truth',),pins)['CP_truth']
        else:
            truth = context.selected(reg['assets']['truth'],('ids','truth'),pins)
            files.require(np.array_equal(query['ids'],truth['ids']),'current truth matched after seal'); y=truth['truth']
        report['truth_opened'] = True
        gates = context.integer_gates(y,prediction,known_only=phase=='known')
        oldg = context.integer_gates(y,baseline,known_only=phase=='known')
        gainloss = {name:dict(gain=int(np.sum((y==c)&(baseline!=c)&(prediction==c))),
            loss=int(np.sum((y==c)&(baseline==c)&(prediction!=c)))) for c,name in enumerate(gates)}
        delta = {name:gl['gain']-gl['loss'] for name,gl in gainloss.items()}
        positive,negative = any(v>0 for v in delta.values()),any(v<0 for v in delta.values())
        loss = {name:gainloss[name]['loss'] for name in ('BEN','KNA')}
        trained.core.previous.save(out,'postseal_paired_comparison',dict(ids=query['ids'],truth=y,prediction=prediction,
            baseline=baseline,raw=raw,density=density,retained=retained),report)
        report.update(execution_status='MASK78_CLEAN110_'+phase+'_evaluated',original_class_gates=gates,
            baseline_class_gates=oldg,known_correct_loss=loss,
            known_gate_passed=all(gates[c]['passed'] and loss[c]==0 for c in ('BEN','KNA')),
            all_three_integer99_passed=phase=='current' and all(g['passed'] for g in gates.values()),
            EffectDelta=dict(verdict='MIXED' if positive and negative else 'UP' if positive else 'DOWN' if negative else 'UNCHANGED',
                correct_count_delta=delta,gain_loss=gainloss,same_original_IDs_and_order=True),
            raw_candidates=int(raw.sum()),density_candidates=int(density.sum()),
            new_retained_candidates=int(np.sum(raw&retained)),
            raw_by_true_class={name:int(np.sum((y==c)&raw)) for c,name in enumerate(gates)})
        files.require(trained.core.output_io.state_digest(net)==reg['mask_state_sha'],'frozen full78 mask state after forward')
        for p,wanted in pins.items(): files.require(files.item(p)['sha256']==wanted,'frozen sources and old evidence unchanged')
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error)); raise
    finally:
        torch.set_num_threads(threads)
        report.update(input_sha256=pins,threads_restored=torch.get_num_threads()==threads,wall_seconds=time.perf_counter()-began)
        files.write(out/'report.json',report)
    return files.item(out/'report.json')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for key in ('registry','registry-sha256','known-report','known-sha256'): parser.add_argument('--'+key)
    args=parser.parse_args()
    print(json.dumps(freeze() if args.phase=='freeze' else run(args.phase,args.registry,args.registry_sha256,
        args.known_report,args.known_sha256)))
