"""Uniform primary-density-supported secondary review using frozen softcue."""
import numpy as np
def require(v,why):
    if not v:raise ValueError(why)
def recipe():
    return dict(schema_version='CIC1-primary-supported-secondary-softanchor-review-v138b',
        evidence='same frozen V133 uniformrawsoftscore>sameknownCALfinite99/floor.5 and actualoriginal126 primarydensity membership',
        rule='newsoftcandidate AND primary_label>=0 AND suspected AND NOT oldDVCretained',
        primary_noise='first<0 (-2 unassessed, -1 primarynoise) always remains blocked, regardless softscore; no assignment invented',
        second_layer='separate known-anchor soft population cue corroborates primarycluster despite reconstruction/localdensity secondary rejection',
        limitation='soft indicator is not unknown probability or statistically independent class certificate; fullmixed classloss measured',
        source='only genuine saved pretruthgraph score/cut/raw and actualprimary/secondary126 DVC; no rerun or learned query rule',
        querytruth_or_family_or_UID_rule=False,new_CAL_fit=0,new_graph=0,new_NN_fit=0,new_metric_fit=0,new_DVC=0,
        parameter_grid=False,timecap_coded=False)
def review(softcandidate,primary,suspected,old_retained):
    raw=np.asarray(softcandidate);first=np.asarray(primary);suspected=np.asarray(suspected);retained=np.asarray(old_retained)
    require(raw.shape==first.shape==suspected.shape==retained.shape and raw.dtype==suspected.dtype==retained.dtype==bool and first.dtype.kind in 'iu','wholeauthentic primary/secondary arrays and predeclared softmask')
    require(np.all(first>=-2),'actualprimary label-noise or unassessed -2 representation')
    return raw&(first>=0)&suspected&~retained
def synthetic_contract():
    raw=np.array([True,True,True,False,True,True]);primary=np.array([-1,0,0,0,1,-2]);suspected=np.array([True,True,False,True,True,True]);old=np.array([False,False,True,False,True,False])
    actual=review(raw,primary,suspected,old)
    require(actual.tolist()==[False,True,False,False,False,False],'primarynoise never rescued, noncandidate never admitted, only genuinelysecondary rejected cluster member')
    return dict(synthetic_only=True,realtraffic=0,allclasses_uniform_no_trutharg=True,primarynoise_staysblocked=True,requiresactualprimarymembership=True,oldretained_unchanged=True,noncandidate_never_admitted=True)
