"""Exact inherited physical data and whole parent; no fitting on import."""
from pathlib import Path
import importlib.util,hashlib,json,sys
INHERITED_INPUTS={'path': 'E:\\Experiment\\software transcition\\target99_v1018_20261024\\cic2\\inputs_v1018.py', 'sha256': '35aef542f5501f178d054268e8b6a5285d8252357933ac3b59990ed4bced06cc'}
H=Path(__file__).resolve().parent;MANIFEST=H/'INPUT_MANIFEST_V1022.json'
if hashlib.sha256(Path(INHERITED_INPUTS['path']).read_bytes()).hexdigest()!=INHERITED_INPUTS['sha256']:raise ValueError('immutable input adapter')
sp=importlib.util.spec_from_file_location('V1022_original_data_'+INHERITED_INPUTS['sha256'],INHERITED_INPUTS['path']);O=importlib.util.module_from_spec(sp);sys.modules[sp.name]=O;sp.loader.exec_module(O)
require=O.require;descriptor=O.descriptor;raw=O.raw;js=O.js;arrays=O.arrays;module=O.module
def manifest():return json.loads(MANIFEST.read_text(encoding='utf-8'))
def load_source():
    s=O.load_source()
    return s
def load_role(role):
    q=O.load_role(role)
    return q
load_known_labels=O.load_known_labels;fixed_metric=O.fixed_metric
