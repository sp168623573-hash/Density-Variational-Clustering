"""One fixed primary-classifier-aware ViM candidate with fresh paper120 DVC."""
from __future__ import annotations
import os
os.environ['CUDA_VISIBLE_DEVICES']='-1'
import argparse
import io
import json
from pathlib import Path
import sys
import time
import joblib
import numpy as np
import pandas as pd
import torch
from torch.nn import functional as F
from . import fine_head_virtual_logit_matching_v76 as vim
from . import cic1_primary_head_vim120_pair_metric_v76 as learned
from . import cic1_primary_head_vim120_dvc_v76 as dvc
from . import cic1_conditional_flow_typicality188_v68 as helper
from . import cic2017_native_known_training_v1 as primary_source
from . import model as architecture
from . import data as preprocessing_source
from . import config

ROOT,files,context=helper.ROOT,helper.files,helper.context
MODULE='paper_open_set.cic1_primary_head_vim120_v76'
BASE=ROOT/'data/external_dev/processed/cic1_primary_head_vim120_20261012_v76'
REGDIR=ROOT/'tmp/cic1_primary_head_vim120_20261012_v76'
PRIMARY=dict(path=str(ROOT/'data/external_dev/processed/cic2017_native_known_training_20261008_v1/CIC_Setting1/report.json'),sha256='5bde5afa2b732268ed31c5fe9937d4916a95da8f28a7e2d07249242ae6a54af7')
PARENT_REG=dict(path=str(ROOT/'tmp/cic1_known_domain_radial_flow126_20261011_v69/registry_before_trueknown16component_flow_fit.json'),sha256='242008d9178e3f22f340ed16d301f05568a67596ca19e366509d8621f015ef93')
PARENT_CURRENT=dict(path=str(ROOT/'data/external_dev/processed/cic1_known_domain_radial_flow126_20261011_v69/current/report.json'),sha256='f3cf63263cd8723c037483a9728f8566ded9eb11a04c5d53c2c7129047ba259d')


def policy():
    return dict(schema_version='CIC1-real-primary-head32-raw9-ViM16-fresh120-preserved2399-v76',hypotheses=1,
        vim_recipe=vim.recipe(),primary='actual frozen originalprimary selected50 MHFD checkpoint and FIT-only oldpreprocessing; original NN+forest stage1/fine/predictions unchanged',
        head='actual nn.Linear32→9 with true forward_pre_hook input and forward_hook output; input exactly returnedembedding, output exactly returnedfine_logits; use real raw logits',
        representation='native78/originalFITRMS + actualraw primaryheadinput32/genuineFITRMS + actualrawfine logits9/genuineFITRMS + ViMresidual1/genuineFITRMS =120',
        source_stats='only originalgenuine6000 FIT; all oldfine≥20; knowncovariance/projector/positivealpha noquery labels or coordinates',
        model_fit='no neural training or newepoch selection; inherited selected67 checkpoint fixed, not auxiliary maskedhead',
        inference='every FIT/CAL/CP/current CPUfloat32/eval/no_grad fixed512; rawhook/embedding/fine/coarse outputs saved before guard; real head F.linear consistency validation counted separately',
        CAL='all900 trueknowncoarse once finite99; querycut only originalstage1; no queryfine/fields/threshold scan',
        metric='fresh owned120 Eq9/10 fixed8192 knownfinepairs/final80; physical nativegroups only; full truegenuine FIT R7 descriptive reference',
        DVC='matching120 raw OR whole2399 oldpredUNA; original affinity/reconstruction/localdensity/secondarynoise unchanged',
        merge='whole2399 copy, only ownraw AND retained appendUNA; historical799/2381/2396exploratory/2397/2399 kept',
        known_gate='BEN/KNA integer99 and oldrowcorrectloss0 before any newcurrent numeric; no integer-only extra exploration',
        new_NN_training=0,original_classifier_changes=0,virtual_class_is_real_UNA_probability=False,
        unknown_fit=False,query_fit=False,field_pruning=False,dimension_grid=False,alpha_sign_or_scale_selection=False,
        timecap_coded=False,accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)


def freeze():
    pins={};parent=files.js(PARENT_REG,pins);current=files.js(PARENT_CURRENT,pins);primary=files.js(PRIMARY,pins)
    files.require(current['original_class_gates']['UNA']['correct']==2399 and all(v['loss']==0 for v in current['EffectDelta']['gain_loss'].values()),'actual whole2399')
    assets=dict(parent['assets']);assets.update(current_baseline=current['files']['complete_prediction_before_truth'],primary_model=primary['files']['model'],primary_preprocessing=primary['files']['preprocessing'])
    src=helper.closure_helper.source_closure(sys.modules[__name__],vim,learned,dvc,helper,primary_source,architecture,preprocessing_source,config)
    for a in (*assets.values(),*src.values()):files.read(a,pins)
    preserved=dict(parent['preserved']);preserved.update(old2397=parent['current_parent'],old2399=PARENT_CURRENT)
    for a in preserved.values():files.read(a,pins)
    files.require(not BASE.exists() and not REGDIR.exists(),'single fresh realhead ViM experiment')
    REGDIR.mkdir(parents=True,exist_ok=False)
    return files.write(REGDIR/'registry_before_real_primary_head_ViM_FIT_statistics.json',dict(policy=policy(),assets=assets,sources=src,preserved=preserved,
        primary_report=PRIMARY,current_parent=PARENT_CURRENT,model_recipe=vim.recipe(),metric_recipe=learned.training_recipe(120),
        output={phase:str(BASE/phase) for phase in ('known','current')},input_sha256=pins,current_numeric_decodes=0,current_truth_decodes=0))


def bind(path,sha):
    ref=dict(path=str(Path(path).resolve()),sha256=sha);pins={};reg=files.js(ref,pins)
    files.require(reg['policy']==policy() and reg['model_recipe']==vim.recipe() and reg['metric_recipe']==learned.training_recipe(120) and reg['sources'][MODULE]==files.item(__file__),'actual selfregistry and head/math recipes')
    for a in reg['sources'].values():files.read(a,pins)
    return ref,reg,pins


def save(out,name,value,report):return helper.save(out,name,value,report)


def net_and_preproc(assets,pins):
    saved=torch.load(io.BytesIO(files.read(assets['primary_model'],pins)),map_location='cpu',weights_only=True)
    files.require(saved['input_dim']==50 and saved['fine_class_count']==9 and saved['selected_epoch']==67,'real inherited primary checkpoint metadata')
    net=architecture.MHFDNetwork(saved['input_dim'],saved['fine_class_count']).cpu();net.load_state_dict(saved['state_dict'],strict=True);net.eval()
    files.require(isinstance(net.fine_head,torch.nn.Linear) and net.fine_head.in_features==32 and net.fine_head.out_features==9 and net.fine_head.weight.dtype==torch.float32,'actual finehead linear32/9')
    prep=joblib.load(io.BytesIO(files.read(assets['primary_preprocessing'],pins)))
    files.require(set(prep)=={'transformer','variance_mask','selector','selected_feature_names','family_order'} and len(prep['selected_feature_names'])==50,'original frozen preprocess actualschema')
    return net,prep,saved


def transform(native,prep):
    matrix=np.asarray(prep['transformer'].transform(pd.DataFrame(native,columns=config.CIC_FEATURE_COLUMNS)),np.float32)
    value=np.asarray(prep['selector'].transform(matrix[:,prep['variance_mask']]),np.float32)
    files.require(value.shape==(len(native),50) and np.isfinite(value).all(),'same originalprimary transform50, no refit')
    return value


@torch.no_grad()
def actual_batch(net,features):
    captured={};counts=dict(before=0,after=0)
    def before(module,args):
        counts['before']+=1;captured['head_input']=args[0].detach().clone();captured['input_ptr']=args[0].data_ptr()
    def after(module,args,output):
        counts['after']+=1;captured['head_output']=output.detach().clone();captured['output_ptr']=output.data_ptr()
    pre=net.fine_head.register_forward_pre_hook(before);post=net.fine_head.register_forward_hook(after)
    try:returned=net(torch.from_numpy(np.ascontiguousarray(features,np.float32)))
    finally:pre.remove();post.remove()
    files.require(counts==dict(before=1,after=1) and captured['input_ptr']==returned['embedding'].data_ptr() and captured['output_ptr']==returned['fine_logits'].data_ptr(),'actual finehead call once and real input/output identity')
    files.require(torch.equal(captured['head_input'],returned['embedding']) and torch.equal(captured['head_output'],returned['fine_logits']),'actual rawembedding/head equality before guard')
    linear=F.linear(captured['head_input'],net.fine_head.weight,net.fine_head.bias)
    files.require(torch.equal(linear,captured['head_output']),'real W/b CPUfloat32 linear output exact; never substitute synthesized logits')
    raw=dict(head_input32=captured['head_input'].numpy().copy(),raw_fine_logits9=captured['head_output'].numpy().copy(),returned_embedding32=returned['embedding'].numpy().copy(),raw_coarse_logits2=returned['coarse_logits'].numpy().copy())
    files.require(all(np.isfinite(a).all() and a.dtype==np.float32 for a in raw.values()),'actual finite CPU32 packets')
    return raw


def infer(net,prep,native,ids,role,out,r):
    start=time.perf_counter();x=transform(native,prep);r['role_preprocess_seconds'][role]=time.perf_counter()-start
    start=time.perf_counter();parts=[]
    for first in range(0,len(x),512):
        raw=actual_batch(net,x[first:first+512]);save(out,role+'_real_primary_head_batch'+str(first)+'_before_guards',dict(ids=ids[first:first+len(raw['head_input32'])],**raw),r)
        parts.append(raw);r['actual_NN_forward_batches']+=1;r['linear_head_validation_calls']+=1
    value={key:np.concatenate([p[key] for p in parts]) for key in parts[0]}
    save(out,role+'_whole_actual_primary_head_before_ViM',dict(ids=ids,**value),r);r['role_CPU_forward_seconds'][role]=time.perf_counter()-start
    return value


def fit_radii(metric,fields,out,r):
    fine=fields['FIT_fine'];z=fields['FIT_Z120'];radius=np.zeros(len(z),np.float64)
    for c in range(9):
        ix=np.flatnonzero(fine==c);files.require(len(ix)>=2,'two actual samefine reference points')
        d=metric.pairwise_distances(z[ix]);save(out,'genuineFIT120_samefine'+str(c)+'_distances_before_R7',dict(indices=ix,distances=d),r)
        np.fill_diagonal(d,np.inf);k=min(7,len(ix)-1);radius[ix]=np.partition(d,k-1,axis=1)[:,k-1]
    save(out,'genuineFIT120_reference_R7',dict(ids=fields['FIT_ids'],groups=fields['FIT_groups'],Z120=z,fine=fine,radii=radius),r)


def run(phase,path,sha,known_path=None,known_sha=None):
    ref,reg,pins=bind(path,sha)
    if phase=='current':
        control=files.js(dict(path=str(Path(known_path).resolve()),sha256=known_sha),pins)
        files.require(control['registry']==ref and control['known_gate_passed'] and control['known_correct_loss']==dict(BEN=0,KNA=0) and control['prediction_sealed'],'strictknown before newcurrent features/forward')
    out=Path(reg['output'][phase]);out.mkdir(parents=True,exist_ok=False);started,threads=time.perf_counter(),torch.get_num_threads()
    r=dict(policy=policy(),phase=phase,registry=ref,files={},new_NN_training=0,actual_NN_forward_batches=0,linear_head_validation_calls=0,role_preprocess_seconds={},role_CPU_forward_seconds={},ViM_statfit=0,unitfit=0,metricfit=0,R7fit=0,CALfit=0,DVC=0,prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False,accepted_baseline_replaced=False)
    try:
        torch.set_num_threads(4);net,prep,saved=net_and_preproc(reg['assets'],pins);nativeunits=np.asarray(files.js(reg['assets']['native_RMS'],pins)['native78'])
        r['files']['actual_head_weights']=save(out,'actual_primary_fine_head_W9x32_bias9',dict(W=net.fine_head.weight.detach().numpy().copy(),b=net.fine_head.bias.detach().numpy().copy()),r)
        if phase=='known':
            native=context.selected(reg['assets']['native_known'],tuple(role+'_'+key for role in ('FIT','CAL','CP') for key in ('ids','native78'))+('FIT_y_fine','CAL_y_coarse'),pins)
            old=context.selected(reg['assets']['known110'],tuple(role+'_'+key for role in ('CAL','CP') for key in ('ids','groups','stage1','predicted_fine')),pins)
            fields={};coords={};head={};residual={};scores={}
            for role in ('FIT','CAL','CP'):
                head[role]=infer(net,prep,native[role+'_native78'],native[role+'_ids'],role,out,r)
                coords[role]=helper.geometry_helper.previous.raw_source.normalize(native[role+'_native78'],nativeunits)
                groups=helper.geometry_helper.group_ids(native[role+'_native78']);files.require(len(set(groups.tolist()))==len(groups),'genuine nativegroups, no views')
                fields.update({role+'_ids':native[role+'_ids'],role+'_groups':groups})
                if role!='FIT':
                    files.require(np.array_equal(fields[role+'_ids'],old[role+'_ids']) and np.array_equal(groups,old[role+'_groups']),'frozen originalprimary entities')
                    fields.update({role+'_'+key:old[role+'_'+key] for key in ('stage1','predicted_fine')})
            stats_start=time.perf_counter();state=vim.fit(head['FIT']['head_input32'],head['FIT']['raw_fine_logits9'],net.fine_head.weight.detach().numpy(),net.fine_head.bias.detach().numpy())
            r['ViM_statfit']=1;r['FIT_ViM_stat_seconds']=time.perf_counter()-stats_start;r['files']['ViM_state']=save(out,'genuineFIT6000_classifier_origin_covariance_ViM16_before_CAL',state,r)
            for role in ('FIT','CAL','CP'):scores[role],detail=vim.scores(head[role]['head_input32'],head[role]['raw_fine_logits9'],state);residual[role]=detail['residual'];save(out,role+'_raw_ViM_score_energy_residual_before_cut',dict(ids=fields[role+'_ids'],score=scores[role],**detail),r)
            us=time.perf_counter();hu=helper.geometry_helper.bridge.rms_unique(head['FIT']['head_input32']);lu=helper.geometry_helper.bridge.rms_unique(head['FIT']['raw_fine_logits9']);ru=helper.geometry_helper.bridge.rms_unique(residual['FIT'][:,None])
            r['unitfit']=1;r['FIT_units_seconds']=time.perf_counter()-us;r['files']['units']=files.write(out/'genuineFIT_realhead32_rawlogits9_residual1_RMS.json',dict(head32=hu.tolist(),logit9=lu.tolist(),residual1=ru.tolist(),genuine_rows=6000,queryfit=False))
            for role in ('FIT','CAL','CP'):fields[role+'_Z120']=np.concatenate((coords[role],head[role]['head_input32'].astype(np.float64)/hu,head[role]['raw_fine_logits9'].astype(np.float64)/lu,residual[role][:,None]/ru),axis=1)
            fields['FIT_fine']=native['FIT_y_fine'];files.require(min(np.bincount(fields['FIT_fine'],minlength=9))>=20,'every fine originalgenuine20')
            save(out,'actual_primaryhead_allrole_ViM120_before_metric',fields,r)
            kwargs=dict(known_fine_labels=list(range(9)),fit_ids=fields['FIT_ids'].tolist(),fit_group_ids=fields['FIT_groups'].tolist(),fit_roles=['FIT']*6000)
            ps=time.perf_counter();pre=learned.prefit_descriptor(fields['FIT_Z120'],fields['FIT_fine'],**kwargs);r['FIT_first_pairprep_seconds']=time.perf_counter()-ps;r['files']['metric_prefit']=files.write(out/'genuine120_knownfine_pair_plan_before_fit.json',pre)
            ms=time.perf_counter();metric=learned.fit_known_metric(fields['FIT_Z120'],fields['FIT_fine'],expected_prefit_sha256=pre['prefit_sha256'],**kwargs);r['metricfit']=1;r['FIT_metric_prep_gradient_seconds']=time.perf_counter()-ms;payload=metric.to_state();r['metric_gradient_seconds']=payload['trained']['training_seconds'];r['files']['metric']=files.write(out/'fresh_owned120_Eq9_10_before_CAL.json',payload)
            rs=time.perf_counter();fit_radii(metric,fields,out,r);r['R7fit']=1;r['FIT_R7_seconds']=time.perf_counter()-rs
            cut=dvc.calibrate_known_cutoffs(scores['CAL'],native['CAL_y_coarse']);r['CALfit']=1;r['files']['cutoffs']=files.write(out/'alltrueknownCAL900_once_ViM_finite99.json',dict(cutoffs=cut,all900_retained=True,queryfine_fit=False))
            query=dict(ids=fields['CP_ids'],groups=fields['CP_groups'],Z120=fields['CP_Z120'],stage1=fields['CP_stage1'],predicted_fine=fields['CP_predicted_fine']);score=scores['CP'];baseline=context.selected(reg['assets']['known_baseline'],('ids','prediction'),pins)
        else:
            state=context.selected(control['files']['ViM_state'],('origin','covariance','eigenvalues','eigenvectors','descending_order','residual_basis','W','b','alpha','FIT_mean_max_logit','FIT_mean_residual'),pins)
            units=files.js(control['files']['units'],pins);cut=files.js(control['files']['cutoffs'],pins)['cutoffs'];metric=learned.PaperVariationalPairMetric.from_state(files.js(control['files']['metric'],pins))
            native=context.selected(reg['assets']['current_native'],('ids','native78'),pins);old=context.selected(reg['assets']['query110'],('ids','groups','stage1','predicted_fine'),pins)
            groups=helper.geometry_helper.group_ids(native['native78']);files.require(len(native['ids'])==len(set(groups.tolist()))==4056 and np.array_equal(native['ids'],old['ids']) and np.array_equal(groups,old['groups']),'whole4056 genuine originalentities')
            head=infer(net,prep,native['native78'],native['ids'],'current4056',out,r);score,detail=vim.scores(head['head_input32'],head['raw_fine_logits9'],state);save(out,'current4056_raw_ViM_before_cut',dict(ids=native['ids'],score=score,**detail),r)
            coords=helper.geometry_helper.previous.raw_source.normalize(native['native78'],nativeunits)
            query=dict(old,Z120=np.concatenate((coords,head['head_input32'].astype(np.float64)/np.asarray(units['head32']),head['raw_fine_logits9'].astype(np.float64)/np.asarray(units['logit9']),detail['residual'][:,None]/np.asarray(units['residual1'])),axis=1));save(out,'whole4056_actual_primaryhead_ViM120_before_DVC',query,r);baseline=context.selected(reg['assets']['current_baseline'],('ids','prediction'),pins)
        files.require(np.array_equal(query['ids'],baseline['ids']),'whole originalbaseline2399 IDs')
        before=baseline['prediction'];raw=dvc.candidate_mask(score,query['stage1'],cut);density=raw|(before==2);save(out,'ViM_score_raw_density_before_DVC',dict(ids=query['ids'],score=score,coarse=query['stage1'],raw=raw,density=density),r)
        route=dvc.route_current_candidates(metric,query['Z120'],density,seed=20261009);r['DVC']=1;save(out,'matching120_DVC_before_truth',{k:v for k,v in route.items() if k!='manifest'},r);r['files']['DVC_manifest']=files.write(out/'matching120_DVC_manifest_before_truth.json',route['manifest'])
        pred=before.copy();pred[raw&route['retained']]=2
        sealed=save(out,'complete_prediction_before_truth',dict(ids=query['ids'],prediction=pred,baseline=before,raw=raw,density=density,retained=route['retained']),r);r['files']['seal']=files.write(out/'prediction_seal_before_truth.json',dict(predictions=sealed,truth_used=False,registry=ref));r['prediction_sealed']=True
        if phase=='known':truth=context.selected(reg['assets']['known110'],('CP_truth',),pins)['CP_truth']
        else:
            t=context.selected(reg['assets']['truth'],('ids','truth'),pins);files.require(np.array_equal(t['ids'],query['ids']),'truth only afterseal');truth=t['truth']
        r['truth_opened']=True;gates=context.integer_gates(truth,pred,known_only=phase=='known');gl={n:dict(gain=int(((truth==c)&(before!=c)&(pred==c)).sum()),loss=int(((truth==c)&(before==c)&(pred!=c)).sum())) for c,n in enumerate(gates)}
        delta={n:z['gain']-z['loss'] for n,z in gl.items()};pos,neg=any(v>0 for v in delta.values()),any(v<0 for v in delta.values());loss={n:gl[n]['loss'] for n in ('BEN','KNA')}
        save(out,'postseal_paired_comparison',dict(ids=query['ids'],truth=truth,prediction=pred,baseline=before,raw=raw,density=density,retained=route['retained']),r)
        r.update(execution_status='real_primaryhead_ViM120_'+phase+'_evaluated',original_class_gates=gates,known_correct_loss=loss,
            known_gate_passed=all(gates[n]['passed'] and loss[n]==0 for n in ('BEN','KNA')),
            EffectDelta=dict(verdict='MIXED' if pos and neg else 'UP' if pos else 'DOWN' if neg else 'UNCHANGED',correct_count_delta=delta,gain_loss=gl,same_original_IDs=True),
            raw_by_true_class={n:int(((truth==c)&raw).sum()) for c,n in enumerate(gates)},candidate_accepted_for_retention=phase=='current' and pos and not neg and all(v['loss']==0 for v in gl.values()),
            all_three_integer99_passed=phase=='current' and all(g['passed'] for g in gates.values()))
        for p,h in pins.items():files.require(files.item(p)['sha256']==h,'all original source/model/asset bytes preserved')
    except Exception as err:r.update(execution_status='execution_failed',error_type=type(err).__name__,error=str(err));raise
    finally:
        torch.set_num_threads(threads);r.update(threads_restored=torch.get_num_threads()==threads,input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for name in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+name)
    a=p.parse_args();print(json.dumps(freeze() if a.phase=='freeze' else run(a.phase,a.registry,a.registry_sha256,a.known_report,a.known_sha256)))
