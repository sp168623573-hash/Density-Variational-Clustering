"""CIC2 immutable R998 geometry/native/whole817 ownership boundary; no source or query refit."""
from pathlib import Path
import hashlib,importlib.util,io,json,sys
import numpy as np
H=Path(__file__).resolve().parent;MANIFEST=H/'INPUT_MANIFEST_V1008.json'
def require(ok,message):
    if not bool(ok):raise ValueError(message)
def descriptor(path):
    p=Path(path).resolve(strict=True);return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def raw(d):
    data=Path(d['path']).read_bytes();require(hashlib.sha256(data).hexdigest()==d['sha256'],'immutable input bytes');return data
def js(d):return json.loads(raw(d).decode('utf-8-sig'))
def arrays(d,keys):
    with np.load(io.BytesIO(raw(d)),allow_pickle=False)as a:return{k:a[k].copy()for k in keys}
def module(d,tag):
    raw(d);sp=importlib.util.spec_from_file_location(tag+'_'+d['sha256'],d['path']);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m);return m
def manifest():return json.loads(MANIFEST.read_text(encoding='utf8'))
def original():return module(manifest()['inherited_inputs'],'V1008_exactR998inputs')
def load_source():
    s=original().load_source();require(s['native'].shape==(5987,78)and s['Z249'].shape==(5987,249)and len(s['field_columns'])==78,'same genuine source/native78/F78/Z249')
    require(len(np.unique(s['ids']))==len(np.unique(s['groups']))==5987 and len(s['logical_fine'])==6000,'source actual physical and expanded logical roster')
    require(np.array_equal(np.unique(s['fine']),np.arange(9)),'original fine0..8 unchanged')
    return dict(ids=s['ids'],groups=s['groups'],fine=s['fine'],native=s['native'],Z=s['Z249'],field_columns=s['field_columns'],logical_fine=s['logical_fine'],logical_groups=s['logical_groups'],logical_slot_indices=np.arange(6000,dtype=np.int64),original_optimizer_indices=s['optimizer_indices'],source_trace=dict(s['source_trace'],logical_fine_already_expanded=True,logical_optimizer_not_reapplied=True),NN_fit=0,NN_readout=0,newmetricfit=0)
def load_role(role):
    require(role in('CAL','CP','current'),'declared CIC2 complete role');q=original().load_role(role)
    return dict(ids=q['ids'],groups=q['groups'],native=q['native'],Z=q['Z249'],parent_prediction=q['parent_prediction'],role=role,NN_fit=0,NN_readout=0,newmetricfit=0,current_truth_decodes=0)
def load_known_labels(role):
    require(role in('CAL','CP'),'known controls only');return original().load_known_labels(role)
def fixed_metric():
    metric=original().fixed_metric();require(metric.dimension==249,'exact inherited source249 metric');return metric
def prepare_manifest():
    old=Path('E:/Experiment/software transcition/target99_v998_20261024/cic2');od=descriptor(old/'inputs_v998.py');md=descriptor(old/'INPUT_MANIFEST_V998.json');require(od['sha256']=='0c96496de2c6ece643eba13b91b9ae6378db1b89766af2b9e567b6b655443841'and md['sha256']=='5762d3f28a00dfe3b10f5eda74432c001861291852ed8293975af43b0d513c1f','exact R998 owner pins');m=js(md)
    value=dict(schema='V1008_CIC2_SOURCE_SIGNED343_EXACT_NATIVE78_Z249_WHOLE817_INPUTS',setting='CIC Setting2',inherited_inputs=od,inherited_input_manifest=md,source249=m['source249'],metric_code=m['metric_code'],metric_state=m['metric_state'],source_genuine_rows=5987,logical_source_rows=6000,native_encoded_width=78,original_field_groups=78,density_geometry_dimension=249,logical_fine_already_expanded=True,original_optimizer_indices_not_reapplied_to_logical_fine=True,current_truth_authority=m['current_truth_authority'],roles=m['roles'],role_rows={'CAL':882,'CP':882,'current':3184},current_CP_disjoint_as_declared=True,current_CP_fullsubset_gate_applicable=False,fixed_current_class_support=[1465,519,1200],parent='V915_complete817',parent_correct_integer_counts=[1454,506,817],required_correct_integer_counts=[1451,514,1188],necessary_new_correct_minimum=[0,8,371],required_known_repair_classes=['KNA'],source_known_certificate_correct_physical_coverage_minimum={'BEN':20,'KNA':20},source_false_known_policy='empirical exact99 integer budget per class, not zero-error proxy gate',source_training_only=['BEN','KNA'],newNNfit=0,newNNreadout=0,newmetricfit=0,old_failed_actions_or_cuts_consumed=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    with MANIFEST.open('x',encoding='utf8')as f:json.dump(value,f,ensure_ascii=False,indent=2)
    return descriptor(MANIFEST)
if __name__=='__main__':print(json.dumps(prepare_manifest(),ensure_ascii=False))
