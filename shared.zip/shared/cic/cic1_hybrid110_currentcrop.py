"""V2 own CIC1 cropped4056, preserving original inference flags and raw returns.

freeze() hashes opaque artifacts, reads JSON/NPY headers and checks ID payload
bytes only. prepare() and run() are separate ROOT-only numerical entry points.
There is no asset discovery, source download, original CSV/Parquet reader,
historical UNA overlay, old fitted distance, alternate cohort or fallback.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import time
import zipfile

import joblib
import numpy as np
import pandas as pd
import torch

from . import cic2017_all_native78_known_material_v1 as native
from . import cic2017_all_native78_known80_v1 as producer
from . import cic2017_native_known_forest_blend_v1 as blend
from . import model
from . import cic1_hybrid110_pair_metric_v1 as learned
from . import cic1_hybrid110_current_dvc_v1 as dvc

ROOT = native.ROOT
BASE = ROOT / 'data/external_dev/processed/cic1_hybrid110_currentcrop_20261009_v2'
REG = ROOT / 'tmp/cic1_hybrid110_currentcrop_20261009_v2/registry_before_actual.json'
SCHEMA = 'CIC1-currentcrop4056-own-HYBRID110-v2'
ROWS = dict(FIT=4200, CAL=900, CP=900)
WIDTH, SEED = 110, 20261009
RAW_KEYS = ('coarse_logits','fine_logits','reconstruction','embedding','gate_mean')
OLD_CALLER_SHA256 = 'db42e6c47dbd863a4a492c7871c7407c82628a4205728020bde90124900b0ef3'
OLD_REGISTRY_SHA256 = 'eaa90d5809116294d40eaedefb611678a77a41ad92054bae2ede8d3d1a02abb8'

def registered(path, sha):
    return dict(path=str(ROOT / path), sha256=sha)

MATERIAL = producer.REPORTS['CIC Setting1']
AUX = registered('data/external_dev/processed/cic1_all_native78_known80_20261009_v1/report.json',
    '5de8f7de8bc288590bc76bca05ad492f4051bc1875a7040f96c70b83215727f4')
MAIN = producer.BASELINES['CIC Setting1']['report']
OLD_NN = registered(blend.BASELINE, blend.BASELINE_SHA)
SOURCE = registered('data/external_dev/processed/cic2017_native_partial_dev_source_20261008_v1/report.json',
    'cae42c758cc42bfc534957cbaa59de5f4ddac33ffe45885295d40b57a04adc67')
PARENT = registered('data/external_dev/processed/cic2017_native78_local_reference_20261008_v1/CIC_Setting1/report.json',
    'f90f84ba1430ccb707dac9efd5d89a9b1477bbfd314ab3302d272e06dbe1e43e')
PARENT_AUDIT = registered('tmp/cic2017_native78_local_reference_20261008_T41_v1/postexecution_audit.json',
    'a7e05b9edbeb0cd94e843c7d3f139eaceeecf8f328929ffc339c2f8f8b78c47d')

def require(value, reason):
    if not value: raise ValueError(reason)

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()

def pin(item, pins):
    path = native._checked(item['path'], item['sha256'])
    pins[str(path)] = item['sha256']
    return path

def js(item, pins):
    return json.loads(pin(item, pins).read_text(encoding='utf8'))

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    native._write_new(path, value)
    return native.descriptor(path)

def archive(item, keys, pins):
    with np.load(pin(item, pins), allow_pickle=False) as saved:
        require(set(keys).issubset(saved.files), 'declared named archive members')
        return {k: saved[k].copy() for k in keys}

def ad(value):
    a = np.asarray(value)
    require(not a.dtype.hasobject, 'no object arrays')
    return dict(shape=list(a.shape), dtype=a.dtype.str,
        sha256=hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest())

def same(a, b, reason):
    require(ad(a) == ad(b), reason)

def save(out, name, values, report):
    path = out / (name + '.npz')
    with path.open('xb') as stream: np.savez_compressed(stream, **values)
    item = native.descriptor(path)
    report['files'][name] = item
    report.setdefault('array_descriptors', {})[name] = {k: ad(v) for k, v in values.items()}
    return item

def integrity(pins):
    for path, sha in pins.items(): native._checked(path, sha)

def recipe():
    return dict(schema_version=SCHEMA, setting='CIC Setting1', query_rows=4056,
        known_CP_rows=900, original_UNA_rows=3156, known_original_cap=6000,
        main='fixed old NN50+forest w3; threshold0.30816650390625; NN fine argmax',
        main_known_gate='same exact current900 IDs/order and cached w3 coarse; BEN650/651 KNA247/249',
        auxiliary='fixed known-only MHFD78 epoch80 embedding32; failed new classification heads unused',
        inference='both branches keep default requires_grad=True; eval; torch.no_grad; original CUDA float16 AMP/2048 batches',
        raw_returns='all five raw tensor fields saved immediately for every model return, before embedding or probability guards',
        state_integrity='producer.state_digest before/after both unknown forwards; auxiliary before also equals producer known state',
        novelty='all78 signed-log/frozen native-FIT RMS then auxiliary embedding32/frozen FIT column RMS',
        novelty_width=110, original_native_fields_retained=78,
        metric='new own110 FIT-only Eq9/10 pair state, fixed80; shared local mathematical recipe',
        reference='original FIT unique native78 groups; actual fine memberships',
        radius='same-fine FIT min(7,n-1)th other neighbour; self excluded; no floor',
        score='nearest main-predicted-fine d^2/(d^2+r^2); exact ties use maximum FIT radius; bothzero0',
        CAL='CAL900 only predicted-coarse finite99 rank; strictgreater; no query threshold choice',
        DVC='current raw only, same learned110 distance, knee/SC/generalizedCH then affinity/noise',
        final_UNA='only current raw AND current DVC retained; no historical prediction overlay',
        density_copy_rows=0, native_completion_or_imputation=False,
        unknown_parameter_fit=False, old_fitted_metric_used=False, threshold_sweep=False,
        same_observed_crop=True, fresh_blind_claim=False, independent_final=False,
        accepted_baseline_replaced=False, source_admitted=False, full_Table1=False,
        status='FAIL_TARGET99', published=False, final_test_executed=False)

def member_bytes(item, member, pins, start=0, rows=None):
    """Header plus opaque row-byte hash; does not decode any array values."""
    with zipfile.ZipFile(pin(item, pins)) as archive_file:
        with archive_file.open(member + '.npy') as stream:
            version = np.lib.format.read_magic(stream)
            shape, fortran, dtype = np.lib.format._read_array_header(stream, version)
            require(not dtype.hasobject and not fortran and len(shape) >= 1, 'flat C-order nonobject NPY')
            count = shape[0] - start if rows is None else rows
            require(0 <= start <= shape[0] and 0 <= count <= shape[0]-start, 'bound byte-prefix rows')
            row_bytes = dtype.itemsize
            for dimension in shape[1:]: row_bytes *= dimension
            remaining = start * row_bytes
            while remaining:
                chunk = stream.read(min(1048576, remaining)); require(chunk, 'complete prefix bytes')
                remaining -= len(chunk)
            state, remaining = hashlib.sha256(), count * row_bytes
            while remaining:
                chunk = stream.read(min(1048576, remaining)); require(chunk, 'complete selected row bytes')
                remaining -= len(chunk); state.update(chunk)
    return dict(shape=[count, *shape[1:]], dtype=dtype.str, payload_sha256=state.hexdigest())

def freeze():
    """Source-only exact-cohort admission; no real numerical/model calls."""
    pins = {}
    old_caller=ROOT/'paper_open_set/cic1_hybrid110_currentcrop_v1.py'
    old_registry=ROOT/'tmp/cic1_hybrid110_currentcrop_20261009_v1/registry_before_actual_v2.json'
    require(native.sha(old_caller)==OLD_CALLER_SHA256 and native.sha(old_registry)==OLD_REGISTRY_SHA256,
        'old unexecuted caller and registry bytes preserved')
    mat, aux, main, old, src, parent, audit = [js(v, pins) for v in
        (MATERIAL, AUX, MAIN, OLD_NN, SOURCE, PARENT, PARENT_AUDIT)]
    require(aux['epochs_completed'] == 80 and aux['training_device'] == 'cuda' and aux['CP_passed'] is False
        and aux['CAL_passed'] is False and aux['unknown_numeric_decodes'] == 0,
        'failed auxiliary heads explicitly excluded; encoder producer known-only')
    require(main['CP_passed'] and main['CAL_passed'] and main['selected']['weight'] == .75
        and main['selected']['threshold'] == .30816650390625, 'qualified fixed w3 classifier')
    require(parent['original_query_rows'] == 4056 and parent['metrics_evaluated']
        and audit['audit_passed'] and audit['report'] == PARENT,
        'registered current4056 parent and audit')
    require(src['original_DEV_rows'] == 3156 and src['partial_development_source_bound']
        and src['source_extraction_completed'] and src['model_consumer_allowed_archive_members'] == ['native78','ids'],
        'existing full-native78 cropped3156 source')
    for r in (mat, aux, main, old, src, parent):
        require(r['published'] is False and r['final_test_executed'] is False, 'only nonfinal development sources')
    auxreg = js(aux['registry'], pins)
    require(auxreg['source_material_report'] == MATERIAL and auxreg['material'] == mat['files']['material']
        and auxreg['encoder'] == mat['files']['encoder'], 'auxiliary shares exact known material and encoder')
    known_path = next(p for p in mat['source_pins'] if p.endswith('known_roles_native78.npz'))
    known_records_path = next(p for p in mat['source_pins'] if p.endswith('ordered_source_records.json'))
    assets = dict(native_known=dict(path=known_path, sha256=mat['source_pins'][known_path]),
        known_records=dict(path=known_records_path, sha256=mat['source_pins'][known_records_path]),
        encoded_known=mat['files']['material'], encoder78=mat['files']['encoder'],
        main_model=old['files']['model'], main_preprocessor=old['files']['preprocessing'],
        main_known_nn=old['files']['predictions'], main_forest=main['model'],
        main_CP=main['CP_candidates'], main_CAL=main['CAL_predictions'],
        auxiliary_model=aux['files']['model'], source_features=src['files']['features'],
        source_records=src['files']['ordered_source_records'], source_truth=src['files']['truth'],
        copy_plan=src['files']['evaluation_resampling_plan'], parent_query=parent['query_inputs'],
        comparison_predictions=parent['predictions'], evaluation=parent['evaluation'])
    assets.update({r+'_auxiliary': aux['files'][r+'_complete_inference_before_guard'] for r in ROWS})
    headers = {}
    for name, asset in assets.items():
        path = pin(asset, pins)
        if path.suffix == '.npz': headers[name] = native.npz_headers(path)
    records, unknown = js(assets['known_records'], pins), js(assets['source_records'], pins)
    known_ids = [row['sample_id'] for r in ROWS for row in records['roles'][r]]
    unknown_ids = [row['sample_id'] for row in unknown['records']]
    require(len(set(known_ids)) == 6000 and len(set(unknown_ids)) == 3156
        and not set(known_ids).intersection(unknown_ids), 'exact6000/3156 unique metadata IDs')
    require(records['model_columns'] == list(native.COLUMNS) and records['family_order'] == native.REGISTRY['CIC Setting1']['family_order'],
        'own original78 columns and fine membership order')
    require(headers['source_features']['native78'] == dict(shape=[3156,78], dtype='<f8', fortran_order=False)
        and headers['native_known']['CP_native78'] == dict(shape=[900,78], dtype='<f8', fortran_order=False),
        'genuine original78 matrices exist; no numeric decoding')
    bytechecks = {}
    for r, count in ROWS.items():
        idbytes = member_bytes(assets['native_known'], r+'_ids', pins)
        require(idbytes == member_bytes(assets['encoded_known'], r+'_ids', pins)
            and idbytes == member_bytes(assets['main_known_nn'], r+'_ids', pins), 'same native/encoded/oldNN ID bytes:'+r)
        bytechecks[r+'_branch_ids'] = idbytes
        require(headers[r+'_auxiliary']['embedding32'] == dict(shape=[count,32],dtype='<f4',fortran_order=False),
            'own all78 saved auxiliary embedding32 header:'+r)
    require(member_bytes(assets['parent_query'],'ids',pins,rows=900) == bytechecks['CP_branch_ids']
        and member_bytes(assets['main_CP'],'CP_ids',pins) == bytechecks['CP_branch_ids'], 'same current900 IDs/order byte-for-byte')
    require(member_bytes(assets['parent_query'],'ids',pins,start=900) == member_bytes(assets['source_features'],'ids',pins),
        'same current3156 suffix IDs/order byte-for-byte')
    require(member_bytes(assets['parent_query'],'coarse',pins,rows=900)
        == member_bytes(assets['main_CP'],'w3_prediction',pins), 'same current900 exact w3 coarse predictions')
    bytechecks['current900_ids'] = member_bytes(assets['parent_query'],'ids',pins,rows=900)
    bytechecks['current3156_ids'] = member_bytes(assets['parent_query'],'ids',pins,start=900)
    ownmodules = (native, producer, blend, blend.original, model, learned, dvc)
    code = {str(Path(m.__file__).resolve()): native.sha(m.__file__) for m in ownmodules}
    code[str(Path(__file__).resolve())] = native.sha(__file__)
    knee_path = Path(dvc.__file__).with_name('dependence_candidate_paper_dvc.py')
    code[str(knee_path)] = native.sha(knee_path)
    copied_dvc_math = ROOT / 'paper_open_set/nsl_mhfd_paper_metric_warm_v1.py'
    require(native.sha(copied_dvc_math) == dvc.SOURCE_MATH_SHA256,
        'unchanged local current-DVC copied mathematics provenance')
    require(native.sha(ROOT / learned.MATH_SOURCE_MODULE) == learned.MATH_SOURCE_SHA256,
        'unchanged local shared Eq9/10 source provenance')
    reg = dict(schema_version=SCHEMA+'-registry', policy=recipe(), assets=assets,
        report_inputs=dict(material=MATERIAL, auxiliary=AUX, main=MAIN, original_nn=OLD_NN,
            cropped_source=SOURCE, comparison=PARENT, comparison_audit=PARENT_AUDIT),
        main_selected=main['selected'], auxiliary_state_sha256=aux['model_state_sha256'],
        family_order=records['family_order'], headers=headers, bytechecks=bytechecks,
        code=code, input_sha256=pins, original_native_decode=0, array_statistics=0,
        model_loads=0, numerical_runs=0, binding_gaps=[], output=str(BASE),
        geometry_innovation='signedlog78 + newly trained all78-MHFD embedding32; own110 learned FIT distance/local radius; no T37 asinh78/DeepSAD state',
        superseded_source_only=dict(caller=dict(path=str(old_caller),sha256=OLD_CALLER_SHA256),
            registry=dict(path=str(old_registry),sha256=OLD_REGISTRY_SHA256),old_numeric_executed=False),
        original_inference_source_contract=dict(main_constructor='model.train_model creates default MHFDNetwork parameters; never disables requires_grad',
            main_inference='model.infer is torch.no_grad, model.eval, CUDA autocast float16 and default batch2048',
            auxiliary_constructor='producer.fit_fixed80 default MHFDNetwork parameters; never disables requires_grad',
            auxiliary_inference='producer.infer_original is torch.no_grad, net.eval, CUDA autocast float16, batch2048',
            both_requires_grad=True,raw_fields=list(RAW_KEYS),state_digest_source='producer.state_digest'),
        published=False, final_test_executed=False, status='FAIL_TARGET99')
    reg['registry_sha256'] = digest(reg)
    return write(REG, reg)

def admit(receipt):
    pins = {}; reg = js(receipt, pins)
    unsigned = dict(reg); signature = unsigned.pop('registry_sha256')
    require(signature == digest(unsigned) and reg['schema_version'] == SCHEMA+'-registry'
        and reg['policy'] == recipe() and reg['output'] == str(BASE), 'own frozen110 registry')
    for path, sha in reg['code'].items(): native._checked(path, sha)
    for path, sha in reg['input_sha256'].items(): native._checked(path, sha)
    require(reg['code'][str(Path(__file__).resolve())] == native.sha(__file__), 'current caller source frozen')
    return reg, pins

def group_hashes(native_values):
    return np.asarray([hashlib.sha256(row.tobytes(order='C')).hexdigest() for row in native_values],dtype='U64')

def validate_native_role(arrays, records, role):
    x, ids, fine, coarse = (arrays[role+'_'+k] for k in ('native78','ids','y_fine','y_coarse'))
    require(x.dtype == np.dtype('<f8') and x.shape == (ROWS[role],78) and np.isfinite(x).all(), 'finite original native78:'+role)
    require(np.array_equal(coarse,(fine!=0).astype(np.int64)) and len(set(ids.tolist()))==ROWS[role], 'actual fine/coarse IDs:'+role)
    hashes = group_hashes(x)
    require(ids.tolist() == [r['sample_id'] for r in records['roles'][role]]
        and hashes.tolist() == [r['canonical78_sha256'] for r in records['roles'][role]], 'original native row identity:'+role)
    return hashes

def prepare(receipt):
    """ROOT ONLY: known6000 decode and FIT32 units; no unknown numeric release."""
    reg, pins = admit(receipt); out = BASE / 'prepare'
    out.mkdir(parents=True, exist_ok=False)
    report = dict(schema_version=SCHEMA+'-prepare', files={}, unknown_decodes=0, model_loads=0,
        FIT_units_fit=0, metric_fit=0, registry=receipt, published=False, final_test_executed=False, status='FAIL_TARGET99')
    a = reg['assets']; keys = [r+'_'+k for r in ROWS for k in ('native78','ids','y_fine','y_coarse')]
    original = archive(a['native_known'],keys,pins); records = js(a['known_records'],pins)
    encoder = js(a['encoder78'],pins)
    encoded = archive(a['encoded_known'],[r+'_'+k for r in ROWS for k in ('features','ids','y_fine','y_coarse')],pins)
    oldnn = archive(a['main_known_nn'],[r+'_'+k for r in ROWS for k in ('ids','fine_probability')],pins)
    cp = archive(a['main_CP'],('CP_ids','w3_prediction'),pins)
    cal = archive(a['main_CAL'],('CAL_ids','candidate_prediction'),pins)
    require(ad(cp['w3_prediction'])['sha256'] == reg['main_selected']['prediction']['C_order_bytes_sha256'], 'actual selected w3 CP state')
    fields = {}; embeddings = {}
    for r in ROWS:
        groups = validate_native_role(original,records,r)
        for k in ('ids','y_fine','y_coarse'): same(original[r+'_'+k],encoded[r+'_'+k],'native/encoded exact role '+r+k)
        same(native.encode(original[r+'_native78'],np.asarray(encoder['units'],np.float64)),encoded[r+'_features'],
            'same original all78 frozen signedlog encoding:'+r)
        same(original[r+'_ids'],oldnn[r+'_ids'],'native/mainNN exact role '+r)
        saved = archive(a[r+'_auxiliary'],('embedding32','embedding'),pins)
        same(saved['embedding32'],saved['embedding'],'aux32 exact producer embedding only')
        z = saved['embedding32']; embeddings[r] = z
        require(z.shape==(ROWS[r],32) and np.isfinite(z).all(), 'real auxiliary own78 embedding32:'+r)
        fields.update({r+'_ids':original[r+'_ids'],r+'_groups':groups,r+'_fine':original[r+'_y_fine'],
            r+'_truth':original[r+'_y_coarse'],r+'_predicted_fine':oldnn[r+'_fine_probability'].argmax(axis=1).astype(np.int64)})
    same(cp['CP_ids'],fields['CP_ids'],'same CP main ID'); same(cal['CAL_ids'],fields['CAL_ids'],'same CAL main ID')
    fields.update(CP_stage1=cp['w3_prediction'],CAL_stage1=cal['candidate_prediction'])
    gates = integer_gates(fields['CP_truth'],fields['CP_stage1'])
    require(gates['BEN']['correct']==650 and gates['BEN']['support']==651
        and gates['KNA']['correct']==247 and gates['KNA']['support']==249, 'current actual900 qualified main gate')
    z = embeddings['FIT'].astype(np.float64)
    selected = np.asarray([next(i for i,g in enumerate(fields['FIT_groups']) if g==group)
        for group in dict.fromkeys(fields['FIT_groups'].tolist())],np.int64)
    plan = dict(schema_version=SCHEMA+'-unit-prefit', FIT_embedding32=ad(embeddings['FIT']),
        FIT_groups=ad(fields['FIT_groups']), indices=selected.tolist(), rule='stable unique-FIT per-column RMS; exactzero1',
        CAL_CP_or_unknown_fit=False, registry=receipt)
    unit_prefit = write(out/'embedding32_unit_prefit_before_RMS.json',plan)
    maximum=np.max(np.abs(z[selected]),axis=0); nonzero=maximum>0; units=np.ones(32,np.float64)
    units[nonzero]=maximum[nonzero]*np.sqrt(np.mean((z[selected][:,nonzero]/maximum[nonzero])**2,axis=0))
    require(np.isfinite(units).all() and np.all(units>0),'positive FIT only embedding units')
    report['FIT_units_fit']=1
    unit = write(out/'FIT_embedding32_units_before_query.json',dict(prefit=unit_prefit,units=units.tolist(),
        source=a['FIT_auxiliary'],unique_FIT_groups=len(selected),unknown_used=False))
    for r in ROWS:
        x=encoded[r+'_features']; require(x.shape==(ROWS[r],78) and x.dtype==np.float32 and np.isfinite(x).all(),'actual encoded78:'+r)
        fields[r+'_Z110']=np.concatenate((x.astype(np.float64),embeddings[r].astype(np.float64)/units),axis=1)
    own = save(out,'known110_before_metric_fit',fields,report)
    kwargs=dict(known_fine_labels=list(range(9)),fit_ids=fields['FIT_ids'].tolist(),
        fit_group_ids=fields['FIT_groups'].tolist(),fit_roles=['FIT']*4200)
    prefit=learned.prefit_descriptor(fields['FIT_Z110'],fields['FIT_fine'],**kwargs)
    metric_prefit=write(out/'own110_metric_prefit_before_training.json',prefit)
    actual=dict(schema_version=SCHEMA+'-prepared',registry=receipt,known110=own,units=unit,
        metric_prefit=metric_prefit,metric_prefit_sha256=prefit['prefit_sha256'],known_gates=gates,
        unknown_numeric_opened=False,input_sha256=pins,report=report)
    prepared=write(out/'prepared_before_metric_fit.json',actual)
    return prepared

def integer_gates(truth,prediction):
    y,p=np.asarray(truth),np.asarray(prediction); require(y.shape==p.shape and y.ndim==1,'aligned original gates')
    result={}
    for label,name in enumerate(('BEN','KNA','UNA')):
        support=int(np.sum(y==label));correct=int(np.sum((y==label)&(p==label)))
        if support:
            required=(99*support+99)//100
            result[name]=dict(correct=correct,support=support,required=required,gap=max(required-correct,0),passed=correct>=required)
    return result

def effect(truth,before,after):
    old,new=integer_gates(truth,before),integer_gates(truth,after)
    delta={name:new[name]['correct']-old[name]['correct'] for name in old}
    verdict='UP' if all(d>=0 for d in delta.values()) and any(delta.values()) else 'DOWN' if all(d<=0 for d in delta.values()) and any(delta.values()) else 'MIXED' if any(delta.values()) else 'UNCHANGED'
    return dict(verdict=verdict,correct_count_delta=delta,prior=old,candidate=new,
        gain=int(np.sum((before!=truth)&(after==truth))),loss=int(np.sum((before==truth)&(after!=truth))),
        same_original_IDs_and_order=True)

def make_reference(fields):
    groups=fields['FIT_groups']; ids=fields['FIT_ids']; fine=fields['FIT_fine']
    selected=np.asarray([min(np.flatnonzero(groups==g).tolist(),key=lambda i:ids[i]) for g in sorted(set(groups.tolist()))],np.int64)
    membership=np.asarray([[np.any(fine[groups==g]==label) for label in range(9)] for g in groups[selected]],bool)
    return dict(Z110=fields['FIT_Z110'][selected],membership=membership,ids=ids[selected],groups=groups[selected],indices=selected)

def fit_radii(metric,refs,sink):
    radius=np.zeros(refs['membership'].shape,np.float64)
    for label in range(9):
        indices=np.flatnonzero(refs['membership'][:,label]);require(len(indices)>=2,'two actual FIT samefine groups')
        distance=metric.pairwise_distances(refs['Z110'][indices]);sink(label,dict(indices=indices,distances=distance.copy()))
        require(np.isfinite(distance).all() and np.all(distance>=0),'finite FIT distances after save')
        np.fill_diagonal(distance,np.inf);k=min(7,len(indices)-1)
        radius[indices,label]=np.partition(distance,k-1,axis=1)[:,k-1]
    require(np.isfinite(radius).all() and np.all(radius>=0),'finite natural FIT radius')
    return radius

def scores(metric,z,labels,refs,radius,sink):
    require(z.shape==(len(labels),110) and np.isin(labels,range(9)).all(),'own110/mainfine score contract')
    score=np.empty(len(z),np.float64)
    for label in np.unique(labels):
        rows=np.flatnonzero(labels==label);indices=np.flatnonzero(refs['membership'][:,label])
        distance=metric.pairwise_distances(z[rows],refs['Z110'][indices]);sink(int(label),dict(rows=rows,indices=indices,distances=distance))
        require(np.isfinite(distance).all() and np.all(distance>=0),'finite returned query distances after save')
        nearest=distance.min(axis=1);r=np.max(np.where(distance==nearest[:,None],radius[indices,label][None,:],-1),axis=1)
        scale=np.maximum(nearest,r);nonzero=scale>0;value=np.zeros(len(rows),np.float64)
        left,right=nearest[nonzero]/scale[nonzero],r[nonzero]/scale[nonzero]
        value[nonzero]=left*left/(left*left+right*right);score[rows]=value
    require(np.isfinite(score).all() and np.all((score>=0)&(score<=1)),'bounded exact local score')
    return score

def route(metric,query,score,cutoffs,out,tag,report):
    raw=dvc.candidate_mask(score,query['stage1'],cutoffs)
    save(out,tag+'_scores_before_DVC',dict(ids=query['ids'],score=score,raw=raw,stage1=query['stage1']),report)
    members={}
    for i,g in enumerate(query['groups'].tolist()):members.setdefault(g,[]).append(i)
    selected=np.asarray([next((i for i in values if raw[i]),values[0]) for values in members.values()],np.int64)
    lookup={g:i for i,g in enumerate(members)};inverse=np.asarray([lookup[g] for g in query['groups'].tolist()],np.int64)
    report['DVC_calls']+=1
    current=dvc.route_current_candidates(metric,query['Z110'][selected],raw[selected],seed=SEED)
    save(out,tag+'_returned_DVC', {k:v for k,v in current.items() if k!='manifest'},report)
    report['files'][tag+'_DVC_manifest']=write(out/(tag+'_DVC_manifest.json'),current['manifest'])
    retained=raw&current['retained'][inverse];prediction=query['stage1'].copy();prediction[retained]=2
    save(out,tag+'_current_predictions_before_truth',dict(ids=query['ids'],prediction=prediction,raw=raw,retained=retained,
        density_indices=selected,density_inverse=inverse),report)
    require(np.all(~retained|raw),'only actual current raw and DVC supported UNA')
    return prediction,raw,retained

@torch.no_grad()
def auxiliary_forward(item,x,out,report,reg,pins):
    checkpoint=torch.load(pin(item,pins),map_location='cpu',weights_only=True)
    require(checkpoint['input_dim']==78 and checkpoint['fine_classes']==reg['family_order']
        and checkpoint['model_state_sha256']==reg['auxiliary_state_sha256'],'own known78 encoder state')
    require(torch.cuda.is_available() and torch.cuda.current_device()==0,'original auxiliary CUDA mode required; no fallback')
    net=model.MHFDNetwork(78,9).cuda().eval();net.load_state_dict(checkpoint['state_dict'],strict=True)
    before=forward_state(net)
    require(all(before['parameter_requires_grad'].values()) and not any(before['module_training'].values())
        and before['model_state_sha256']==reg['auxiliary_state_sha256'],
        'original auxiliary default flags/eval and exact producer state')
    report['files']['auxiliary_state_before_forward']=write(out/'auxiliary_state_before_unknown_forward.json',
        dict(source_model=item,expected_known_producer_state_sha256=reg['auxiliary_state_sha256'],state=before))
    values=[];report['auxiliary_unknown_forward']=1
    for index,start in enumerate(range(0,len(x),2048)):
        with torch.autocast(device_type='cuda',dtype=torch.float16):
            returned=net(torch.from_numpy(x[start:start+2048]).cuda())
        raw={name:returned[name].detach().float().cpu().numpy().copy() for name in RAW_KEYS}
        save(out,'unknown_auxiliary_raw5_batch'+str(index)+'_before_guard',raw,report)
        require(set(returned)==set(RAW_KEYS),'all auxiliary raw returned fields saved')
        embedding=raw['embedding']
        require(embedding.shape==(min(2048,len(x)-start),32) and np.isfinite(embedding).all(),'actual auxiliary embedding only')
        values.append(embedding)
    after=forward_state(net)
    report['files']['auxiliary_state_after_forward']=write(out/'auxiliary_state_after_unknown_forward.json',dict(state=after))
    require(after==before,'auxiliary tensors/default gradient flags/eval unchanged by unknown inference')
    return np.concatenate(values)

def forward_state(net):
    return dict(model_state_sha256=producer.state_digest(net),
        parameter_requires_grad={name:bool(tensor.requires_grad) for name,tensor in net.named_parameters()},
        module_training={name:bool(module.training) for name,module in net.named_modules()})

@torch.no_grad()
def main_forward(a,native_values,out,report,pins):
    require(torch.cuda.is_available() and torch.cuda.current_device()==0,'original CUDA mode required; no fallback')
    torch.backends.cudnn.deterministic=True;torch.backends.cudnn.benchmark=False
    torch.use_deterministic_algorithms(True,warn_only=True)
    checkpoint=torch.load(pin(a['main_model'],pins),map_location='cpu',weights_only=True)
    require(checkpoint['input_dim']==50 and checkpoint['fine_class_count']==9 and checkpoint['selected_epoch']==67,'frozen original main50')
    net=model.MHFDNetwork(50,9).cuda().eval();net.load_state_dict(checkpoint['state_dict'],strict=True)
    before=forward_state(net)
    require(all(before['parameter_requires_grad'].values()) and not any(before['module_training'].values()),
        'original main training/infer default flags and eval')
    report['files']['main_state_before_forward']=write(out/'main_state_before_unknown_forward.json',
        dict(source_model=a['main_model'],state=before))
    prep=joblib.load(pin(a['main_preprocessor'],pins));forest=joblib.load(pin(a['main_forest'],pins))
    frame=pd.DataFrame(np.array(native_values,copy=True),columns=native.COLUMNS)
    encoded=np.asarray(prep['transformer'].transform(frame),np.float32)
    selected=np.asarray(prep['selector'].transform(encoded[:,prep['variance_mask']]),np.float32)
    save(out,'unknown_main50_input_before_forward',dict(selected50=selected),report)
    report['main_unknown_forward']=1
    raw_batches=[]
    def raw_hook(module,inputs,returned):
        raw={name:returned[name].detach().float().cpu().numpy().copy() for name in RAW_KEYS}
        index=len(raw_batches)
        raw_batches.append(save(out,'unknown_main_raw5_batch'+str(index)+'_before_probability_math',raw,report))
        require(set(returned)==set(RAW_KEYS) and not torch.is_grad_enabled(),
            'all original main raw5 immediately saved inside no_grad before probability math')
    hook=net.register_forward_hook(raw_hook)
    try:
        returned=model.infer(net,selected,device=torch.device('cuda'),batch_size=2048)
    finally:
        hook.remove()
    nn={name:np.asarray(getattr(returned,name)).copy() for name in producer.OUTPUT_FIELDS}
    save(out,'unknown_mainNN_all_returned_fields_before_guard',nn,report)
    after=forward_state(net)
    report['files']['main_state_after_forward']=write(out/'main_state_after_unknown_forward.json',dict(state=after))
    require(after==before and len(raw_batches)==(len(selected)+2047)//2048,
        'main tensors/default gradient flags/eval unchanged; every original2048 return sealed')
    fp=blend._predict_fine(forest,blend._tree_input(native_values))
    probability=blend._blend(nn['attack_probability'],1.-fp[:,0],.75)
    coarse=(probability>=.30816650390625).astype(np.int64)
    save(out,'unknown_main_w3_returned_before_guard',dict(forest_fine_probability=fp,probability=probability,coarse=coarse),report)
    require(np.isfinite(nn['fine_probability']).all() and np.isfinite(probability).all(),'finite frozen main outputs')
    return coarse,nn['fine_probability'].argmax(axis=1).astype(np.int64)

def run(prepared_receipt):
    """ROOT ONLY: new FIT110 pair -> FIT radius -> CAL cutoff -> CP gate -> crop4056."""
    pins={};prepared=js(prepared_receipt,pins);reg,pins2=admit(prepared['registry']);pins.update(pins2)
    require(prepared['schema_version']==SCHEMA+'-prepared' and prepared['unknown_numeric_opened'] is False,'own new prepared known110')
    out=BASE/'runtime';out.mkdir(parents=True,exist_ok=False);started=time.perf_counter();stage='known110_metric_fit'
    report=dict(schema_version=SCHEMA,policy=recipe(),registry=prepared['registry'],prepared=prepared_receipt,
        files={},metric_fit=0,FIT_radius_fit=0,CAL_score=0,CP_score=0,full_score=0,DVC_calls=0,
        main_unknown_forward=0,auxiliary_unknown_forward=0,unknown_numeric_opened=False,truth_opened=False,
        predictions_sealed=False,metrics_evaluated=False,accepted_baseline_replaced=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        os.environ['CUBLAS_WORKSPACE_CONFIG']=':4096:8'
        torch.set_num_threads(4)
        torch.backends.cudnn.deterministic=True;torch.backends.cudnn.benchmark=False
        torch.use_deterministic_algorithms(True,warn_only=True)
        keys=[r+'_'+k for r in ROWS for k in ('ids','groups','fine','truth','predicted_fine','Z110')]+['CP_stage1','CAL_stage1']
        fields=archive(prepared['known110'],keys,pins)
        prefit=js(prepared['metric_prefit'],pins)
        require(prefit['prefit_sha256']==prepared['metric_prefit_sha256'],'own sealed FIT110 prefit')
        report['metric_fit']=1
        metric=learned.fit_known_metric(fields['FIT_Z110'],fields['FIT_fine'],
            expected_prefit_sha256=prepared['metric_prefit_sha256'],known_fine_labels=list(range(9)),
            fit_ids=fields['FIT_ids'].tolist(),fit_group_ids=fields['FIT_groups'].tolist(),fit_roles=['FIT']*4200)
        state=write(out/'own110_metric_state_before_query.json',metric.to_state());report['files']['metric']=state
        refs=make_reference(fields);save(out,'own_FIT110_reference_before_radius',refs,report)
        report['FIT_radius_fit']=1
        radius=fit_radii(metric,refs,lambda label,v:save(out,'FIT_fine'+str(label)+'_distances',v,report))
        radius_asset=save(out,'FIT_radius_before_CAL_and_query',dict(radius=radius),report)
        report['CAL_score']=1
        cal=scores(metric,fields['CAL_Z110'],fields['CAL_predicted_fine'],refs,radius,
            lambda label,v:save(out,'CAL_fine'+str(label)+'_distances',v,report))
        save(out,'CAL_scores_before_cutoffs',dict(score=cal,stage1=fields['CAL_stage1']),report)
        cutoffs=dvc.calibrate_known_cutoffs(cal,fields['CAL_stage1'])
        cutoff=write(out/'knownCAL_only_cutoffs_before_query.json',dict(cutoffs=cutoffs,metric=state,radius=radius_asset,unknown_used=False))
        report['files']['cutoffs']=cutoff;stage='same_current900_new_novelty_gate'
        query={k:fields['CP_'+k] for k in ('ids','groups','predicted_fine','Z110','stage1')}
        report['CP_score']=1
        score=scores(metric,query['Z110'],query['predicted_fine'],refs,radius,
            lambda label,v:save(out,'CP_fine'+str(label)+'_distances',v,report))
        prediction,raw,retained=route(metric,query,score,cutoffs,out,'known900',report)
        gates=integer_gates(fields['CP_truth'],prediction);passed=all(g['passed'] for g in gates.values())
        report.update(known_gates=gates,known_passed=passed,known_raw=int(raw.sum()),known_retained=int(retained.sum()))
        gate=write(out/'known_gate_before_unknown_numeric.json',dict(passed=passed,gates=gates,metric=state,cutoffs=cutoff,
            prepared=prepared_receipt,query_ids=ad(query['ids']),unknown_opened=False))
        report['files']['known_gate']=gate
        require(passed,'KNOWN_CURRENT900_FAILED_UNKNOWN_UNOPENED')
        stage='same_current3156_native78_release';integrity(pins)
        a=reg['assets'];unknown=archive(a['source_features'],('native78','ids'),pins);report['unknown_numeric_opened']=True
        x,ids=unknown['native78'],unknown['ids'];records=js(a['source_records'],pins)
        require(x.dtype==np.float64 and x.shape==(3156,78) and np.isfinite(x).all(),'current finite3156 original78 only')
        groups=group_hashes(x)
        require(ids.tolist()==[r['sample_id'] for r in records['records']]
            and groups.tolist()==[r['canonical78_sha256'] for r in records['records']], 'exact current original3156 records')
        oldquery=archive(a['parent_query'],('ids','coarse'),pins)
        same(oldquery['ids'][:900],query['ids'],'same current900 prefix');same(oldquery['ids'][900:],ids,'same current3156 suffix')
        same(oldquery['coarse'][:900],query['stage1'],'same current900 main coarse')
        encoder=js(a['encoder78'],pins);encoded=native.encode(x,np.asarray(encoder['units'],np.float64))
        save(out,'unknown_existing_native78_encoded_before_auxiliary',dict(ids=ids,encoded78=encoded),report)
        embedding=auxiliary_forward(a['auxiliary_model'],encoded,out,report,reg,pins)
        units=np.asarray(js(prepared['units'],pins)['units'],np.float64)
        z=np.concatenate((encoded.astype(np.float64),embedding.astype(np.float64)/units),axis=1)
        coarse,fine=main_forward(a,x,out,report,pins)
        same(coarse,oldquery['coarse'][900:],'frozen main actual3156 coarse exact prior material')
        full=dict(ids=np.concatenate((query['ids'],ids)),groups=np.concatenate((query['groups'],groups)),
            Z110=np.concatenate((query['Z110'],z)),stage1=np.concatenate((query['stage1'],coarse)),
            predicted_fine=np.concatenate((query['predicted_fine'],fine)))
        same(full['ids'],oldquery['ids'],'same current4056 IDs order')
        full_asset=save(out,'same_current4056_actual110_before_score',full,report)
        stage='current4056_scores_and_same110_DVC';report['full_score']=1
        full_score=scores(metric,full['Z110'],full['predicted_fine'],refs,radius,
            lambda label,v:save(out,'full_fine'+str(label)+'_distances',v,report))
        same(full_score[:900],score,'same CP score reused unchanged in full4056')
        result,fullraw,fullretained=route(metric,full,full_score,cutoffs,out,'full4056',report)
        seal=write(out/'prediction_seal_before_comparison_truth.json',dict(metric=state,radius=radius_asset,cutoffs=cutoff,
            known_gate=gate,query=full_asset,predictions=report['files']['full4056_current_predictions_before_truth'],truth_opened=False))
        report['files']['prediction_seal']=seal;report['predictions_sealed']=True;integrity(pins)
        stage='reused_current4056_truth_and_comparison_after_seal'
        evaluation=archive(a['evaluation'],('ids','truth','unknown_family','reporting_indices'),pins)
        parent=archive(a['comparison_predictions'],('ids','candidate'),pins);report['truth_opened']=True
        same(evaluation['ids'],full['ids'],'exact current4056 metric IDs');same(parent['ids'],full['ids'],'exact parent4056 comparison IDs')
        same(evaluation['truth'][:900],fields['CP_truth'],'known prefix truth');require(np.all(evaluation['truth'][900:]==2),'original3156 UNA truth')
        parent_report=js(PARENT,pins);before=integer_gates(evaluation['truth'],parent['candidate'])
        require(before==parent_report['original_class_gates']['candidate'],'same actual T41 comparison gates')
        after=integer_gates(evaluation['truth'],result);delta=effect(evaluation['truth'],parent['candidate'],result)
        save(out,'postseal_same4056_comparison',dict(ids=full['ids'],truth=evaluation['truth'],baseline=parent['candidate'],
            candidate=result,raw=fullraw,retained=fullretained),report)
        report.update(execution_status='CIC1_HYBRID110_currentcrop4056_evaluated',metrics_evaluated=True,
            original_class_gates=after,parent_class_gates=before,EffectDelta=delta,raw_UNA=int(fullraw[900:].sum()),
            retained_UNA=int(fullretained[900:].sum()),full_mixed_known_passed=all(after[c]['passed'] for c in ('BEN','KNA')),
            UNA_required=after['UNA']['required'],UNA_gap=after['UNA']['required']-after['UNA']['correct'],
            original_rows=4056,report_only_copies=18,density_copy_rows=0,
            per_family={str(f):dict(support=int(np.sum(evaluation['unknown_family']==f)),
                correct=int(np.sum((evaluation['unknown_family']==f)&(result[900:]==2)))) for f in np.unique(evaluation['unknown_family'])})
        integrity(pins)
    except Exception as error:
        report.update(execution_status='protocol_stop' if isinstance(error,ValueError) else 'execution_failed',
            failed_stage=stage,error_type=type(error).__name__,reason=str(error))
    report.update(input_sha256=pins,wall_seconds=time.perf_counter()-started)
    write(out/'report.json',report)
    return report

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('freeze','prepare','run'))
    parser.add_argument('--receipt');parser.add_argument('--sha256');args=parser.parse_args(argv)
    if args.action=='freeze': value=freeze()
    else:
        require(args.receipt and args.sha256,'explicit externally sealed receipt required')
        receipt=dict(path=str(Path(args.receipt).resolve()),sha256=args.sha256)
        value=prepare(receipt) if args.action=='prepare' else run(receipt)
    print(json.dumps({k:value.get(k) for k in ('path','sha256','execution_status','known_gates','original_class_gates','EffectDelta','raw_UNA','reason')},ensure_ascii=False))
    return 0 if args.action!='run' or value.get('metrics_evaluated') else 2

if __name__=='__main__':raise SystemExit(main())
