"""One known-only binary forest assists the frozen strong CIC2 MHFD.

The fixed .25 forest contribution is retained. Unlike the old fine9 forest,
this assistant directly learns BEN/KNA on the expanded genuine FIT records.
CAL determines one threshold, then the fixed CP predictions are sealed before
evaluation. This module never opens current query data or fits unknown flows.
"""
from __future__ import annotations
import argparse
from collections import Counter
import json
from pathlib import Path
import time
import joblib
import numpy as np
from sklearn.ensemble import ExtraTreesClassifier

from . import cic_fit6000_mhfd_training_v1 as helpers
from . import cic2017_setting2_signed_log_cached_blend_v1 as primary

ROOT=helpers.ROOT
OUT=ROOT/'data/external_dev/processed/cic2_known6000_binary_assistant_20261010_v1'
SCHEMA='CIC2-FIT6000-binary-native78-fixed-quarter-assistant-v1'
MATERIAL=dict(path=str(ROOT/'data/external_dev/processed/cic2_fit6000_mhfd_20261009_v1/material/material_report_before_fit.json'),sha256='29dba492efd072a7552bff0200a73e26f6a85aed28601b19cbff5125ccbd8966')
NN=dict(path=str(ROOT/primary.NN_REPORT['path']),sha256=primary.NN_REPORT['sha256'])
PARAMETERS=dict(n_estimators=512,max_features='sqrt',min_samples_leaf=1,max_depth=None,
    bootstrap=False,n_jobs=4,random_state=20261010)

def policy():
    return dict(schema_version=SCHEMA,setting='CIC Setting2',forest_parameters=PARAMETERS,
        forest_target='BEN0/KNA1 binary, class masses .5/.5 over fixed6000 optimizer indices',
        input='all original78 native fields float32; no feature clipping, selection or token modification',
        FIT_original=5987,FIT_copies=13,FIT_optimizer=6000,CP_original=882,CAL_original=882,
        primary='unchanged original strong signedlog MHFD; actual cached attack probabilities',
        blend='.75 frozen MHFD + .25 new binary forest KNA probability',
        threshold='CAL originals once; CP not used for threshold or weights',
        intervention='assistant supervised target and training composition both changed; not isolated causal proof',
        main_fine_heads_unchanged=True,query_inference_entry=False,unknown_fits=0,
        old_weights_modified=False,status='FAIL_TARGET99',published=False,final_test_executed=False)

def load(asset,keys,pins):
    with np.load(helpers.checked(asset,pins),allow_pickle=False) as z:
        return {k:z[k].copy() for k in keys}

def save(out,name,data,report):
    ref=helpers.npz_new(out/(name+'.npz'),data,{})
    report['files'][name]=ref
    return ref

def freeze():
    pins={};mat=helpers.read(MATERIAL,pins);nn=helpers.read(NN,pins)
    native=mat['source_arrays'];cached=nn['files']['predictions']
    heads=helpers.header_tools.npz_headers(helpers.checked(cached,pins))
    for role in ('CP','CAL'):
        helpers.require(heads[role+'_probability']['shape']==[882], 'actual strong primary cached coarse probability:'+role)
    helpers.checked(native,pins)
    reg=dict(schema_version=SCHEMA+'-registry',policy=policy(),material=MATERIAL,primary=NN,
        native=native,primary_cached=cached,source=helpers.descriptor(__file__),
        input_sha256=pins,output=str(OUT))
    directory=ROOT/'tmp/cic2_known6000_binary_assistant_20261010_v1';directory.mkdir(exist_ok=True)
    return helpers.json_new(directory/'registry_before_binary_FIT.json',reg)

def binary_probability(forest,x):
    helpers.require(np.array_equal(forest.classes_,[0,1]) and len(forest.estimators_)==512,'actual fitted binary forest class order')
    values=np.zeros(len(x),np.float64)
    for tree in forest.estimators_:values+=tree.predict_proba(x,check_input=False)[:,1]
    return values/512

def run(path,sha):
    pins={};ra=dict(path=str(Path(path).resolve()),sha256=sha);reg=helpers.read(ra,pins)
    helpers.require(reg['policy']==policy() and reg['source']==helpers.descriptor(__file__),'frozen own binary-assistant source')
    for p,h in reg['input_sha256'].items():helpers.checked(dict(path=p,sha256=h),pins)
    helpers.require(not OUT.exists(),'fresh once-only binary-assistant output');OUT.mkdir(parents=True)
    began=time.perf_counter()
    report=dict(schema_version=SCHEMA,registry=ra,policy=policy(),files={},NN_fit=0,NN_forward=0,
        forest_fit=0,forest_forward_roles=[],CAL_threshold_fit=0,query_fit=0,unknown_reads=0,
        prediction_sealed=False,CP_truth_opened=False,accepted_baseline_replaced=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        keys=('FIT_native78','FIT_y_coarse','FIT_training_indices','FIT_ids',
            'CAL_native78','CAL_y_coarse','CAL_ids','CP_native78','CP_ids')
        source=load(reg['native'],keys,pins)
        original=load(reg['primary_cached'],('CAL_ids','CAL_probability','CP_ids','CP_probability'),pins)
        for role in ('CAL','CP'):helpers.require(np.array_equal(source[role+'_ids'],original[role+'_ids']),'same fixed primary IDs:'+role)
        index=source['FIT_training_indices']
        x=np.ascontiguousarray(source['FIT_native78'],np.float32);y=source['FIT_y_coarse']
        helpers.require(x.shape==(5987,78) and len(index)==6000 and len(y)==5987
            and np.isfinite(x).all() and set(np.unique(y))=={0,1},'known-only fixed binary source and6000 optimizer budget')
        counts=Counter(y[index].tolist());weights={label:6000/(2*count) for label,count in counts.items()}
        report['files']['prefit']=helpers.json_new(OUT/'recipe_and_classweights_before_binary_fit.json',
            dict(policy=policy(),weights=weights,native=reg['native'],primary_cached=reg['primary_cached'],query_read=False))
        started=time.perf_counter();forest=ExtraTreesClassifier(**PARAMETERS,class_weight=weights)
        forest.fit(x[index],y[index]);report['forest_fit']=1
        report['training_seconds']=time.perf_counter()-started
        destination=OUT/'known_only_binary_native78_ExtraTrees512.joblib';joblib.dump(forest,destination)
        report['files']['model']=helpers.descriptor(destination)
        cal_forest=binary_probability(forest,np.ascontiguousarray(source['CAL_native78'],np.float32));report['forest_forward_roles'].append('CAL')
        cal=.75*original['CAL_probability'].astype(np.float64)+.25*cal_forest
        save(OUT,'CAL_original_probabilities_before_threshold',dict(ids=source['CAL_ids'],probability=cal,tree=cal_forest),report)
        theta,metric=helpers.network.choose_coarse_threshold(source['CAL_y_coarse'],cal)
        report['files']['threshold']=helpers.json_new(OUT/'CAL_once_theta_before_CP.json',dict(threshold=float(theta),metrics=metric,CP_truth_used=False))
        report['CAL_threshold_fit']=1
        cp_forest=binary_probability(forest,np.ascontiguousarray(source['CP_native78'],np.float32));report['forest_forward_roles'].append('CP')
        cp=.75*original['CP_probability'].astype(np.float64)+.25*cp_forest
        predictions=dict(CAL_prediction=(cal>=theta).astype(np.int64),CP_prediction=(cp>=theta).astype(np.int64),
            CAL_ids=source['CAL_ids'],CP_ids=source['CP_ids'])
        predicted=save(OUT,'fixed_known_predictions_before_CP_truth',predictions,report)
        report['files']['prediction_seal']=helpers.json_new(OUT/'known_prediction_seal_before_CP_truth.json',dict(predictions=predicted,
            model=report['files']['model'],threshold=report['files']['threshold'],CP_truth_used=False))
        report['prediction_sealed']=True
        truth=load(reg['native'],('CP_y_coarse',),pins)['CP_y_coarse'];report['CP_truth_opened']=True
        gates=dict(CAL=helpers.gates(source['CAL_y_coarse'],predictions['CAL_prediction']),CP=helpers.gates(truth,predictions['CP_prediction']))
        report.update(execution_status='binary_native78_assistant_known_controls_evaluated',known_gates=gates,
            both_controls_integer99_passed=all(v['passed'] for g in gates.values() for v in g.values()),coarse_threshold=float(theta),
            unknown_phase_allowed=False,unknown_phase_requires_new_main_CAL_distance_alignment=True)
        for p,h in pins.items():helpers.require(helpers.sha(p)==h,'known binary source pins unchanged')
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        report['input_sha256']=pins;report['wall_seconds']=time.perf_counter()-began;helpers.json_new(OUT/'report.json',report)
    return helpers.descriptor(OUT/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','known'),required=True)
    p.add_argument('--registry');p.add_argument('--registry-sha256');a=p.parse_args()
    print(json.dumps(freeze() if a.phase=='freeze' else run(a.registry,a.registry_sha256)))
