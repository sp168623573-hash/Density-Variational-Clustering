"""Unlabelled unresolved-cohort occupancy relative to genuine known BEN.

Transfers the V120 density-ratio mechanism symmetrically to both known classes to CIC1's complete owned126 metric.
No categorical contexts are invented for CIC; this is a global population cue.
"""
import numpy as np

def require(ok, reason):
    if not ok: raise ValueError(reason)

def recipe():
    return dict(radius_k=7, minimum_query_groups=7, count_prior=1,
                closed_ball_ties=True, exclude_self=True,
                score='log((query_other+1)/NQ)-log((FIT_inball+1)/(NF+1))',
                reference='all genuine truecoarse class FIT original126',
                population='original preV123 baseline nonUNA by both BEN/KNA banks; nativegroup deduplicated',
                no_query_truth=True, no_query_fit=True)

def infer(metric, z, groups, active, reference, reference_groups):
    z=np.asarray(z,np.float64);groups=np.asarray(groups);active=np.asarray(active)
    f=np.asarray(reference,np.float64);fg=np.asarray(reference_groups)
    require(z.ndim==f.ndim==2 and z.shape[1]==f.shape[1]==126 and
            np.isfinite(z).all() and np.isfinite(f).all(), 'complete finite owned126')
    require(groups.shape==active.shape==(len(z),) and active.dtype==bool and
            len(f)==len(fg)==len(np.unique(fg)) and len(f)>=20, 'genuine trueBEN reference and scope')
    _,rep,inv=np.unique(groups,return_index=True,return_inverse=True)
    require(np.array_equal(z,z[rep][inv]) and np.array_equal(active,active[rep][inv]),
            'nativegroup duplicate coordinates and active scope consistent')
    require(not set(groups.tolist()) & set(fg.tolist()), 'query physical groups disjoint from FIT BEN')
    selected=np.flatnonzero(active[rep]);nq=len(selected);nf=len(f)
    score=np.zeros(len(rep));eligible=np.zeros(len(rep),bool)
    radii=np.zeros(len(rep));fc=np.zeros(len(rep),np.int64);qc=np.zeros(len(rep),np.int64)
    qf=np.empty((0,nf));qq=np.empty((0,0))
    if nq>=7:
        x=z[rep[selected]];qf=metric.pairwise_distances(x,f)
        r=np.partition(qf,6,axis=1)[:,6];fitcount=(qf<=r[:,None]).sum(axis=1)
        qq=metric.pairwise_distances(x)
        require(np.array_equal(np.diag(qq),np.zeros(nq)), 'actual owned self distances zero')
        other=(qq<=r[:,None]).sum(axis=1)-1
        require(np.all(fitcount>=7) and np.all(other>=0) and np.all(other<nq), 'ties and self count')
        local=np.log((other+1)/nq)-np.log((fitcount+1)/(nf+1))
        require(np.isfinite(local).all(), 'finite no epsilon count ratio')
        score[selected]=local;eligible[selected]=True;radii[selected]=r;fc[selected]=fitcount;qc[selected]=other
    return dict(score=score[inv],eligible=eligible[inv],radius=radii[inv],FIT_ball_count=fc[inv],
                query_other_ball_count=qc[inv],active=active,representatives=rep,inverse=inv,
                active_genuine_representatives=rep[selected],NQ=np.asarray(nq),NF=np.asarray(nf),
                query_to_FIT_distances=qf,query_pair_distances=qq)
