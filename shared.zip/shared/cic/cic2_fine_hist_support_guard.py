"""Add known-support agreement to the frozen fine-HGB confidence guard.

All reference coordinates and units come from genuine unique known FIT.
The added correction requires nearest KNA support closer than BEN support.
No threshold is tuned on CAL; original CP envelopes are reused unchanged.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import numpy as np
from sklearn.neighbors import NearestNeighbors

from . import cic2_fine_hist_known_guard_v1 as prior

h=prior.h;fine=prior.fine;ROOT=prior.ROOT
OUT=ROOT/'data/external_dev/processed/cic2_fine_hist_support_guard_20261010_v1'
REGISTRY_OUT=ROOT/'tmp/cic2_fine_hist_support_guard_20261010_v1'
PARENT=dict(path=str(prior.OUT/'report.json'),sha256='729e50ab2d8fc185609198243f08feff0242b9f325284125d817ee291aa12c1c')


def policy():
    return dict(schema_version='CIC2-fine-HGB-CP-envelope-known-support-guard-v1',hypotheses=1,
        base='frozen old strong MHFD/quarter fine forest classification and existing fine-HGB CP BEN envelope',
        added_rule='only supplement primary BEN to KNA if fine confidence admitted and nearest uniqueFIT KNA distance < nearest uniqueFIT BEN distance',
        coordinates='full78 signed log1p divided by per-field uniqueFIT RMS; naturally zero RMS uses native log unit1, no clipping/feature selection',
        reference='shared5987 genuineFIT groups; optimizer copies excluded',
        distance='Euclidean in those fixed units; 1nearest, exact ties keep original BEN',
        CP_envelope_reused_unchanged=True,new_CAL_threshold_fit=0,
        warm_controls=True,independent_final_asserted=False,
        no_ID_or_truth_in_decision=True,unknown_entry=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)


def bindings():
    return {str(Path(p).resolve()):h.sha(p) for p in (__file__,prior.__file__,fine.__file__,h.__file__)}


def coordinates(native,units):
    native=np.asarray(native,np.float64);units=np.asarray(units,np.float64)
    h.require(native.ndim==2 and native.shape[1]==78 and np.isfinite(native).all()
        and units.shape==(78,) and np.isfinite(units).all() and np.all(units>0),'fixed_native78_units')
    return np.ascontiguousarray(np.sign(native)*np.log1p(np.abs(native))/units,np.float64)


def agreement(candidate,nearBEN,nearKNA):
    candidate=np.asarray(candidate);nearBEN=np.asarray(nearBEN);nearKNA=np.asarray(nearKNA)
    h.require(candidate.ndim==1 and candidate.dtype==bool and candidate.shape==nearBEN.shape==nearKNA.shape
        and np.isfinite(nearBEN).all() and np.isfinite(nearKNA).all() and np.all(nearBEN>=0) and np.all(nearKNA>=0),'natural_support_distances')
    return candidate&(nearKNA<nearBEN)


def freeze():
    pins={};parent=h.read(PARENT,pins);reg=h.read(parent['registry'],pins)
    h.require(parent['execution_status']=='known_fine_BEN_envelope_guard_evaluated'
        and parent['CP_envelope_sealed'] and parent['prediction_sealed']
        and not parent['paired_strong_correct_loss_free'],'exact_unpromoted_prior_guard')
    for item in (reg['native'],reg['strong'],reg['assets']['CP'],reg['assets']['CAL'],parent['files']['envelope']):h.checked(item,pins)
    heads=h.header_tools.npz_headers(h.checked(reg['native'],pins))
    h.require(heads['FIT_native78']['shape']==[5987,78] and heads['FIT_y_coarse']['shape']==[5987],'same_shared_realFIT_reference')
    sources=bindings()
    for p,sha in sources.items():h.checked(dict(path=p,sha256=sha),pins)
    h.require(not OUT.exists() and not REGISTRY_OUT.exists(),'fresh_support_guard_output');REGISTRY_OUT.mkdir(parents=True)
    return h.json_new(REGISTRY_OUT/'registry_before_known_support_geometry.json',dict(policy=policy(),sources=sources,parent=PARENT,
        native=reg['native'],strong=reg['strong'],assets=reg['assets'],envelope=parent['files']['envelope'],
        previous_predictions=parent['files']['predictions'],input_sha256=pins,output=str(OUT),feature_decodes=0))


def run(path,sha):
    registry=dict(path=str(Path(path).resolve()),sha256=sha);pins={};started=time.perf_counter();stage='registry'
    report=dict(policy=policy(),registry=registry,files={},NN_fit=0,HGB_fit=0,NN_forward=0,HGB_forward=0,
        metric_fit=0,FIT_unit_fit=0,nearest_reference_index_fit=0,CAL_threshold_fit=0,score=0,DVC=0,
        prediction_sealed=False,CAL_truth_opened=False,unknown_reads=0,unknown_phase_allowed=False,
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    h.require(not OUT.exists(),'fresh_once_support_output');OUT.mkdir(parents=True)
    try:
        reg=h.read(registry,pins);h.require(reg['policy']==policy() and reg['sources']==bindings(),'fixed_support_source_and_policy')
        for p,wanted in reg['input_sha256'].items():h.checked(dict(path=p,sha256=wanted),pins)
        stage='unique_knownFIT_geometry_before_controls'
        fit=fine.load(reg['native'],('FIT_native78','FIT_y_coarse','FIT_ids'),pins)
        h.require(len(fit['FIT_ids'])==5987 and len(np.unique(fit['FIT_ids']))==5987,'genuine_uniqueFIT_IDs')
        native=fit['FIT_native78'].astype(np.float64);logged=np.sign(native)*np.log1p(np.abs(native))
        scale=np.sqrt(np.mean(logged**2,axis=0));units=np.where(scale>0,scale,1.)
        z=coordinates(native,units);report['FIT_unit_fit']=1
        report['files']['units']=h.json_new(OUT/'uniqueFIT_units_before_known_queries.json',dict(
            units=units.tolist(),uniqueFIT=reg['native'],copies_in_reference=0,query_fitted_units=False))
        references={}
        for label in (0,1):
            rows=z[fit['FIT_y_coarse']==label]
            h.require(len(rows)>0,'positive_known_class_reference')
            references[label]=NearestNeighbors(n_neighbors=1,algorithm='brute',metric='euclidean',n_jobs=4).fit(rows)
            report['nearest_reference_index_fit']+=1
        envelope=np.asarray(h.read(reg['envelope'],pins)['envelope'],np.float64)
        main=fine.load(reg['strong'],tuple(r+'_'+k for r in ('CP','CAL') for k in ('ids','candidate')),pins)
        values={};added={}
        stage='known_coordinates_and_outputs_before_CAL_truth'
        for role in ('CP','CAL'):
            features=fine.load(reg['native'],(role+'_ids',role+'_native78'),pins)
            auxiliary=fine.load(reg['assets'][role],('ids','hist_fine'),pins)
            h.require(np.array_equal(features[role+'_ids'],auxiliary['ids']) and np.array_equal(auxiliary['ids'],main[role+'_ids']),'known_probability_feature_ID_order:'+role)
            _,proposed=prior.correct_known(main[role+'_candidate'],auxiliary['hist_fine'],envelope)
            query=coordinates(features[role+'_native78'],units)
            dben=references[0].kneighbors(query,return_distance=True)[0][:,0]
            dkna=references[1].kneighbors(query,return_distance=True)[0][:,0]
            admitted=agreement(proposed,dben,dkna);prediction=main[role+'_candidate'].copy();prediction[admitted]=1
            added[role]=int(admitted.sum())
            values.update({role+'_ids':features[role+'_ids'],role+'_prediction':prediction,role+'_primary':main[role+'_candidate'],
                           role+'_confidence_proposed':proposed,role+'_support_admitted':admitted,role+'_nearBEN':dben,role+'_nearKNA':dkna})
        report['files']['predictions']=h.npz_new(OUT/'known_support_predictions_before_CAL_truth.npz',values,{})
        report['files']['prediction_seal']=h.json_new(OUT/'known_support_prediction_seal_before_CAL_truth.json',dict(
            predictions=report['files']['predictions'],units=report['files']['units'],envelope=reg['envelope'],CAL_truth_used=False,
            identities_or_truth_used_for_decision=False,reference_class_labels_role='knownFIT only'))
        report['prediction_sealed']=True
        stage='postseal_complete_known_evaluation'
        meta=fine.load(reg['native'],tuple(r+'_'+k for r in ('CP','CAL') for k in ('ids','y_coarse','reporting_indices')),pins)
        old=fine.load(reg['previous_predictions'],tuple(r+'_'+k for r in ('CP','CAL') for k in ('ids','prediction')),pins)
        report['CAL_truth_opened']=True
        gates,effective,effects={},{},{}
        for role in ('CP','CAL'):
            y,idx,pred=meta[role+'_y_coarse'],meta[role+'_reporting_indices'],values[role+'_prediction']
            h.require(np.array_equal(meta[role+'_ids'],values[role+'_ids']) and np.array_equal(old[role+'_ids'],values[role+'_ids']),'postseal_known_IDs:'+role)
            gates[role],effective[role]=h.gates(y,pred),h.gates(y[idx],pred[idx])
            effects[role]=dict(original_strong=h.paired(y,values[role+'_primary'],pred),confidence_only=h.paired(y,old[role+'_prediction'],pred))
            values[role+'_truth']=y
        report['files']['postseal_pair']=h.npz_new(OUT/'postseal_known_support_paired_comparison.npz',values,{})
        for p,wanted in pins.items():h.require(h.sha(p)==wanted,'support_input_pin_unchanged:'+p)
        report.update(execution_status='known_fine_and_nearest_support_guard_evaluated',known_gates=gates,effective_reporting_gates=effective,
            EffectDelta=effects,added_KNA_rows=added,
            original_and_reporting_integer99_passed=all(g['passed'] for group in (gates,effective) for role in group.values() for g in role.values()),
            paired_strong_correct_loss_free=all(e['original_strong']['loss']==0 for e in effects.values()),
            promotion_status='NOT_PROMOTED_WARM_KNOWN_DIAGNOSTIC',own_new_CAL_novelty_alignment_required_before_unknown=True)
    except Exception as error:
        report.update(execution_status='execution_failed',failed_stage=stage,error_type=type(error).__name__,error=str(error));raise
    finally:
        report.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);h.json_new(OUT/'report.json',report)
    return h.descriptor(OUT/'report.json')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','known'),required=True)
    p.add_argument('--registry');p.add_argument('--registry-sha256');a=p.parse_args()
    if a.phase=='known' and (not a.registry or not a.registry_sha256):p.error('known requires registry and SHA')
    print(json.dumps(freeze() if a.phase=='freeze' else run(a.registry,a.registry_sha256)))
