"""Uniform V126raw soft initialization -> actual126 graph -> paper DVC."""
import argparse,json,sys,time,types
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from . import cic1_soft_raw_affinity_core_v133 as core
from . import cic1_symmetric_collective_density126_v126 as previous
from . import cic1_joint_student_mixture126_v130 as timing_parent
ROOT,files,require=previous.ROOT,previous.files,previous.require
old=previous.old;MODULE='paper_open_set.cic1_soft_raw_affinity126_v133'
DIR=ROOT/'tmp/cic1_soft_raw_affinity126_20261012_v133';BASE=ROOT/'data/external_dev/processed/cic1_soft_raw_affinity126_20261012_v133';REG=DIR/'registry_before_known.json'
def policy():
    return dict(schema_version='CIC1-frozen126-uniformcandidate-softsupport-graph-DVC-v133',recipe=core.recipe(),hypotheses=1,
        differentiation='V117 had historicalpred2 seeds clamped1; this newmethod initialises uniformly from sameV126 rawcandidate flags then neverclamps query/raw nodes',
        CAL_source='actualstored V126 jointCALscore and twoeligibility banks from authorizedtrueknown-negative calibration; use samefrozen V126 raw candidate function, not CALrole-zero seeds',
        CP_current_source='actualwhole V126 saved score/eligibility/stage1/raw cue; samecandidatefunction verifiedexact, no truthor family filter',
        controls='known trueBEN/KNA controls are not a mixedquery stability certificate; fullnewwhole must be measured',
        baseline='whole646/247/3114 and known650/247 preserved, original3059/2402 retained separately',
        NN_fit=0,metric_fit=0,R7_fit=0,query_fit=False,trueUNA_fit=False,parameter_grid=False,timecap_coded=False,
        extension_not_verbatim_paper=True,status='FAIL_TARGET99',published=False,final_test_executed=False)
def closure():
    found={};seen=set();todo=[sys.modules[__name__]]
    while todo:
        m=todo.pop()
        if m is None or id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if not p or not Path(p).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        found[MODULE if m is sys.modules[__name__] else m.__name__]=files.item(p)
        for value in vars(m).values():
            child=value if isinstance(value,types.ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            if child is not None:todo.append(child)
    return found
def archive(a,keys,pins):return old.archive(a,keys,pins)
def save(out,r,key,value):return old.save(out,r,key,value)
def freeze():
    started=time.perf_counter();pins={};pr=files.item(previous.REG);p=files.js(pr,pins);kr=files.item(previous.BASE/'known/report.json');cr=files.item(previous.BASE/'current/report.json');k=files.js(kr,pins);c=files.js(cr,pins)
    require(k['known_gate_passed'] and c['prediction_sealed'] and c['original_class_gates']['UNA']['correct']==3114,'actualpreservedwhole3114 andoldknowncontrol')
    a=dict(p['assets']);a.update(known_baseline=k['files']['complete_prediction_before_truth'],baseline=c['files']['complete_prediction_before_truth'],
        prior_rule=k['files']['rule'],CAL_joint=k['files']['alltrueknown_CAL900_joint_scores_before_cut'],
        CAL_bank0=k['files']['alltrueknown_CAL900_bank0_population_before_cut'],CAL_bank1=k['files']['alltrueknown_CAL900_bank1_population_before_cut'],
        CP_joint=k['files']['complete_original126_symmetric_candidates_before_DVC'],CP_bank0=k['files']['complete_original126_bank0_population_before_DVC'],
        current_joint=c['files']['complete_original126_symmetric_candidates_before_DVC'],current_bank0=c['files']['complete_original126_bank0_population_before_DVC'])
    src=closure();contract=core.synthetic_contract()
    for item in [*a.values(),*src.values()]:files.read(item,pins)
    priorclose=files.item(timing_parent.DIR/'CIC1_V130_PROPER_JOINT_STUDENT3_3114_UNCHANGED_COMPLETED_CLOSEOUT.json');prior=files.js(priorclose,pins)
    # Metadata-only prefix parity test decodes authorizedknown CAL arrays but
    # not any current numeric arrays or labels before the frozen recipe.
    cj=archive(a['CAL_joint'],('ids','score'),pins);b0=archive(a['CAL_bank0'],('ids','eligible'),pins);b1=archive(a['CAL_bank1'],('ids','eligible'),pins)
    mat=archive(a['material'],('CAL_ids','CAL_stage1'),pins)
    require(np.array_equal(cj['ids'],mat['CAL_ids']) and np.array_equal(b0['ids'],cj['ids']) and np.array_equal(b1['ids'],cj['ids']),'actualfullCALprefix raw source identities available')
    raw=core.raw_candidate(cj['score'],b0['eligible']|b1['eligible'],mat['CAL_stage1'],files.js(a['prior_rule'],pins))
    require(not REG.exists() and not BASE.exists(),'exclusive soft raw corroboration hypothesis namespace')
    DIR.mkdir(parents=True,exist_ok=True)
    return files.write(REG,dict(policy=policy(),assets=a,sources=src,synthetic_contract=contract,previous_registry=pr,previous_known=kr,previous_current=cr,
        timing_ancestry_closeout=priorclose,prior_preparation_seconds=prior['actual_preparation']['conservative_allprep_plus_ancestry_seconds'],
        actual_CAL_prefix_parity=dict(ids=old.cic.learned._array_descriptor(mat['CAL_ids']),initial_raw_count=int(raw.sum()),initial_descriptor=core.descriptor(raw),
            CAL_raw_not_forcedzero=True,CAL_knownnegative_population_declared=True),freeze_seconds=time.perf_counter()-started,input_sha256=pins,current_numeric_decodes=0))
def bind(ref,pins):
    reg=files.js(ref,pins);require(reg['policy']==policy() and reg['sources']==closure(),'exact frozen source/softinitial formula/roles')
    for p,s in reg['input_sha256'].items():files.read(dict(path=p,sha256=s),pins)
    return reg
def anchors(reg,metric,pins):
    mat=archive(reg['assets']['material'],('FIT_ids','FIT_groups','FIT_fine','FIT_Z126'),pins)
    labels=archive(reg['assets']['native_known'],('FIT_ids','FIT_y_fine'),pins)
    require(len(mat['FIT_ids'])==6000==len(np.unique(mat['FIT_groups'])) and np.array_equal(mat['FIT_ids'],labels['FIT_ids']) and np.array_equal(mat['FIT_fine'],labels['FIT_y_fine']) and np.bincount(mat['FIT_fine'],minlength=9).min()>=20,'genuinewholeknown6000 includingall9family20')
    require(metric.to_state()['prefit_descriptor']['FIT_MHFD_Z']==old.cic.learned._array_descriptor(mat['FIT_Z126']),'exactactual126 metricprefit anchor coordinates')
    order=np.argsort(mat['FIT_groups'],kind='stable')
    return dict(ids=mat['FIT_ids'][order],groups=mat['FIT_groups'][order],Z126=mat['FIT_Z126'][order],fine=mat['FIT_fine'][order])
def role_input(reg,role,pins):
    a=reg['assets'];rule=files.js(a['prior_rule'],pins)
    if role=='CAL':
        mat=archive(a['material'],('CAL_ids','CAL_groups','CAL_Z126','CAL_stage1'),pins);q={k:mat['CAL_'+k] for k in ('ids','groups','Z126','stage1')}
        joint=archive(a['CAL_joint'],('ids','score'),pins);b0=archive(a['CAL_bank0'],('ids','eligible'),pins);b1=archive(a['CAL_bank1'],('ids','eligible'),pins)
        require(np.array_equal(q['ids'],joint['ids']) and np.array_equal(q['ids'],b0['ids']) and np.array_equal(q['ids'],b1['ids']),'actualfull CAL V126candidate prefix identities')
        raw=core.raw_candidate(joint['score'],b0['eligible']|b1['eligible'],q['stage1'],rule)
        return q,raw,None
    phase='known' if role=='CP' else 'current';q,baseline,_=old.query('CIC1',phase,a,pins)
    joint=archive(a[role+'_joint'],('ids','score','eligible','raw'),pins)
    require(np.array_equal(joint['ids'],q['ids']),'actualwhole V126prefix cue same orderedquery')
    raw=core.raw_candidate(joint['score'],joint['eligible'],q['stage1'],rule)
    require(np.array_equal(raw,joint['raw']),'CP/current exactsamecandidatefunction produces stored V126raw, no truthfilter')
    return q,raw,baseline
def graph(metric,anchor,q,initial,out,r,role):
    nodes=core.collapse(q['Z126'],q['groups'],q['ids'],initial)
    require(not set(nodes['groups'].tolist())&set(anchor['groups'].tolist()),'query genuinegroups disjointwhole knownFIT anchors')
    started=time.perf_counter();value=core.diffusion(metric,anchor['Z126'],nodes['Z126'],nodes['initial_raw']);r['graph_seconds'][role]=time.perf_counter()-started
    r['files'][role+'_graph']=save(out,r,role+'_same126_actualsoft_raw_graph_before_cut',dict(ids=q['ids'],stage1=q['stage1'],initial_raw_rows=initial,group126=nodes['Z126'],groups=nodes['groups'],representatives=nodes['representatives'],inverse=nodes['inverse'],
        score_rows=value['score'][nodes['inverse']],**{k:v for k,v in value.items() if k!='manifest'}))
    r['files'][role+'_graph_manifest']=files.write(out/(role+'_same126_uniformsoft_raw_manifest.json'),dict(value['manifest'],initial_raw_rows=nodes['raw_rows'],initial_raw_groups=nodes['raw_groups'],CAL_roletruth_zero_seed_override=False,matching_metric_state_sha256=metric.state_sha256))
    r['graph_calls']+=1
    return value['score'][nodes['inverse']],nodes
def run(phase,ref,knownref=None):
    started=time.perf_counter();pins={};reg=bind(ref,pins);control=None
    if phase=='current':
        control=files.js(knownref,pins);require(control['known_gate_passed'] and control['prediction_sealed'] and control['registry']==ref,'onceknownintegergates beforecurrent')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False)
    r=dict(policy=policy(),phase=phase,registry=ref,files={},graph_seconds={},graph_calls=0,NN_fit=0,NN_forward=0,metric_fit=0,R7_fit=0,CAL_fit=0,DVC=0,current_numeric_decodes=0,
        prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        with threadpool_limits(limits=2):
            wrapped=files.js(reg['assets']['metric'],pins);metric=old.cic.learned.PaperVariationalPairMetric.from_state(wrapped['metric_payload']);require(metric.dimension==126,'exactfrozen126 owner')
            r['files']['metric']=reg['assets']['metric'];anchor=anchors(reg,metric,pins);r['files']['anchors']=save(out,r,'allgenuineknown6000_anchor0_before_rolegraphs',dict(**anchor,anchor_zero=np.zeros(6000)))
            if phase=='known':
                q,initial,_=role_input(reg,'CAL',pins);score,_=graph(metric,anchor,q,initial,out,r,'CAL')
                labels=archive(reg['assets']['native_known'],('CAL_ids','CAL_y_coarse'),pins);require(np.array_equal(labels['CAL_ids'],q['ids']),'trueknown CAL identities for one score calibration')
                rankcut=old.cic.dvc.calibrate_known_cutoffs(score,labels['CAL_y_coarse'])
                rule={k:dict(v,finite99_cutoff=v['cutoff'],cutoff=max(core.FLOOR,v['cutoff']) if v['enabled'] else None,fixed_majority_floor=core.FLOOR) for k,v in rankcut.items()}
                r['CAL_fit']=1;r['files']['rule']=files.write(out/'all900_trueknown_oncefinite99_softscore_fixedfloor_half.json',rule)
                role='CP'
            else:rule=files.js(control['files']['rule'],pins);r['files']['rule']=control['files']['rule'];r['known_report']=knownref;role='current'
            q,initial,baseline=role_input(reg,role,pins);r['current_numeric_decodes']=len(q['ids']) if phase=='current' else 0
            score,nodes=graph(metric,anchor,q,initial,out,r,role)
            raw=(baseline!=2)&old.cic.dvc.candidate_mask(score,q['stage1'],rule);density=raw|(baseline==2)
            group_density=np.zeros(len(nodes['Z126']),bool);np.logical_or.at(group_density,nodes['inverse'],density)
            routed=old.cic.dvc.route_current_candidates(metric,nodes['Z126'],group_density,seed=20261012);r['DVC']=1
            route={k:v[nodes['inverse']] for k,v in routed.items() if k!='manifest'}
            save(out,r,'same126_softsupport_pluswholepred2_DVC_before_truth',route)
            r['files']['DVC_manifest']=files.write(out/'same126_softsupport_pluswholepred2_DVC_manifest.json',dict(routed['manifest'],matching_metric_state_sha256=metric.state_sha256,density_copies=0,raw_group_count=int(group_density.sum())))
            retained=raw&route['retained'];p=baseline.copy();p[retained]=2;require(np.all(p[baseline==2]==2),'alloldwhole3114 predictedUNA includingmistakes preserved')
            v=dict(ids=q['ids'],prediction=p,baseline=baseline,raw=raw,density=density,retained=retained,softscore=score,initial_raw=initial)
            sealed=save(out,r,'complete_prediction_before_truth',v);r['files']['seal']=files.write(out/'completeprediction_seal_beforetruth.json',dict(predictions=sealed,registry=ref,rule=r['files']['rule'],metric=reg['assets']['metric'],anchors=r['files']['anchors'],querytruth_used=False));r['prediction_sealed']=True
            if phase=='known':y=archive(reg['assets']['known_truth'],('CP_truth',),pins)['CP_truth']
            else:
                truth=archive(reg['assets']['truth'],('ids','truth'),pins);require(np.array_equal(truth['ids'],q['ids']),'completequerytruth onlyafterpredictionseal');y=truth['truth']
            r['truth_opened']=True;gates,delta,binary=old.helpers.metrics(y,baseline,p)
            r.update(execution_status='CIC1_uniformsoft_raw126_'+phase+'_completed',original_class_gates=gates,EffectDelta=delta,binary_attack_detection=binary,
                known_gate_passed=all(gates[n]['passed'] for n in ('BEN','KNA')),candidate_accepted_for_retention=False,
                soft_raw_by_trueclass={n:int(((y==c)&raw).sum()) for c,n in enumerate(('BEN','KNA','UNA'))},retained_by_trueclass={n:int(((y==c)&retained).sum()) for c,n in enumerate(('BEN','KNA','UNA'))})
            save(out,r,'postseal_complete_whole_pair',dict(**v,truth=y))
            if phase=='current':r['perfect_soft_raw_UNA_ceiling']=int(((y==2)&((baseline==2)|raw)).sum())
        for p,s in pins.items():require(files.item(p)['sha256']==s,'all frozen sources olddata/model/predictions unchanged')
    except Exception as error:r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for key in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+key)
    a=p.parse_args();ref=None if a.registry is None else dict(path=str(Path(a.registry).resolve()),sha256=a.registry_sha256);k=None if a.known_report is None else dict(path=str(Path(a.known_report).resolve()),sha256=a.known_sha256)
    print(json.dumps(freeze() if a.phase=='freeze' else run(a.phase,ref,k)))
