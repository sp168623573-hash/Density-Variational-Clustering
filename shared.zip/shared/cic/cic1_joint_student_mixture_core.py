"""Known fine mixture of full126 correlated Student-t3 densities."""
import numpy as np
from scipy.linalg import solve_triangular
from scipy.special import gammaln,logsumexp
from sklearn.covariance import OAS

NU=3
def require(v,why):
    if not v:raise ValueError(why)
def recipe():
    return dict(schema_version='CIC1-all126-known9fine-tiedwithinOAS-properStudent3-mixture-v130',
        coordinates='all original126 native78+authenticMHFD32+radial16; genuineFIT featurewise mean/std, exactzero std1',
        fit='all genuine6000 known fine0..8, all>=20; per-fine full126 mean; OAS allwithin-fine residual rows assume_centered=True',
        covariance='shared full126 OAS covariance; Student3 shape=covariance/3 so component finite covariance equals OAS covariance; no clipping/epsilon',
        prior='fixed hierarchical statisticalprior BEN.5, each knownattackfine.5/8, not physical resampling',
        joint_logpdf='gammaln((3+d)/2)-gammaln(3/2)-d/2*log(3*pi)-.5logdet(shape)-(3+d)/2*log1p(MahalanobisSquared/3)',
        score='negative logsumexp of all9(logprior+properjointlogpdf), no selected predicted/true queryfine or chosen fields',
        candidate='alltrueknownCAL900 one finite99 per truecoarse, actualoriginalstage1 cutoff bank; only oldprediction!=2 new candidates',
        density='uniform union of previous actualV126 raw candidates and newall9mixture raw, same126 legal paper DVC',
        merge='preserve whole646/247/3114 prediction vector and allold2, newraw retained may append2',
        degrees_freedom=NU,hyperparameter_grid=False,NN_fit=0,new_geometry=False,query_fit=False,timecap_coded=False)
def fit_state(z,fine,groups):
    z=np.asarray(z,np.float64);fine=np.asarray(fine,np.int64);groups=np.asarray(groups)
    require(z.shape==(6000,126) and fine.shape==groups.shape==(6000,) and len(np.unique(groups))==6000 and np.isfinite(z).all(),'allrealknown6000 full126 once')
    count=np.bincount(fine,minlength=9);require(len(count)==9 and np.all(count>=20),'all9 actualknownfine >=20')
    mean=z.mean(0);std=z.std(0);zero=std==0;std[zero]=1.;x=(z-mean)/std
    centers=np.stack([x[fine==c].mean(0) for c in range(9)]);within=x-centers[fine]
    fitted=OAS(assume_centered=True).fit(within);cov=np.asarray(fitted.covariance_,np.float64);shape=cov/NU
    L=np.linalg.cholesky(shape);logdet=2*np.log(np.diag(L)).sum();priors=np.r_[.5,np.full(8,.5/8)]
    require(np.isfinite(L).all() and np.all(np.diag(L)>0) and np.isfinite(logdet),'actualproperfull126 joint Cholesky positive shape')
    return dict(mean126=mean,std126=std,constant_columns=zero,centers9x126=centers,covariance126=cov,shape126=shape,L126=L,
        logdet_shape=np.asarray(logdet),fine_counts=count,prior9=priors,OAS_shrinkage=np.asarray(fitted.shrinkage_),genuine_groups=groups,truefine=fine)
def signals(z,state):
    z=np.asarray(z,np.float64);require(z.ndim==2 and z.shape[1]==126 and np.isfinite(z).all(),'complete finite unlabelled126 query')
    x=(z-state['mean126'])/state['std126'];mahal=[];logpdf=[];d=126
    constant=gammaln((NU+d)/2)-gammaln(NU/2)-d/2*np.log(NU*np.pi)-.5*float(state['logdet_shape'])
    for center in state['centers9x126']:
        solved=solve_triangular(state['L126'],(x-center).T,lower=True,check_finite=True)
        m=np.square(solved).sum(0);mahal.append(m);logpdf.append(constant-(NU+d)/2*np.log1p(m/NU))
    mahal=np.column_stack(mahal);logpdf=np.column_stack(logpdf);score=-logsumexp(logpdf+np.log(state['prior9'])[None,:],axis=1)
    require(np.isfinite(score).all() and np.isfinite(logpdf).all() and np.all(mahal>=0),'finite properall9 Student3 jointmixture no clipping')
    return dict(score=score,mahalanobis9=mahal,component_logpdf9=logpdf)
def synthetic_contract():
    state=dict(mean126=np.zeros(126),std126=np.ones(126),centers9x126=np.zeros((9,126)),L126=np.eye(126),logdet_shape=np.asarray(0.),prior9=np.r_[.5,np.full(8,.5/8)])
    x=np.zeros((2,126));x[1,125]=1.;value=signals(x,state)
    require(value['score'][1]>value['score'][0] and np.all(value['mahalanobis9'][1]==1),'last126 coordinate participates, all9 exactcomponents')
    samepdf=value['component_logpdf9'][:,0];require(np.allclose(value['score'],-samepdf,rtol=0,atol=1e-13),'propermixture identicalcomponents reduces to singlelogdensity')
    correlated=dict(state);L=np.eye(126);L[125,0]=.5;correlated['L126']=L
    joint=x.copy();joint[1,0]=1.;changed=signals(joint,correlated);diagonal=signals(joint,state)
    require(np.all(changed['mahalanobis9'][1]==1.25) and np.all(diagonal['mahalanobis9'][1]==2.) and changed['score'][1]!=diagonal['score'][1],
        'fullcorrelation factor changes joint behavior, no diagonal-only shortcut')
    return dict(synthetic_only=True,realtraffic=0,last126field_participates=True,properall9_identicalmixture=True,fullfactor_correlation=True,querytruth_or_fine_bank=False)
