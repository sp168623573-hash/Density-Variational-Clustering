"""One fixed native78 fine/port covariance signal; no neural forward.

The closed masked-error candidates remain unchanged. This source fits only
genuine FIT raw signedlog/RMS vectors, then fixes one originalCAL coarse cut.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import numpy as np

from . import cic1_mask78_joint_fine_port_v1 as joint

previous,known_rule,trained,context=joint.previous,joint.known_rule,joint.trained,joint.context
ROOT,files=joint.ROOT,joint.files
BASE=ROOT/'data/external_dev/processed/cic1_native78_joint_rawport_20261011_v1'
SCHEMA='CIC1-fixed-genuineFIT-native78-signedlog-RMS-fine-port-LedoitWolf-v1'


def policy():
    return dict(schema_version=SCHEMA,setting='CIC Setting1',
        signal='all original78 raw native fields transformed signedlog / existing genuineFIT6000 native RMS',
        difference='raw78 covariance, not clean reconstruction or masked-error covariance',
        fitting='genuine uniqueFIT6000 only; true known fine labels and observed native Destination Port',
        cells='truefine-global plus fine/observedport when support>=20 uniqueFIT rows; otherwise fine-global',
        covariance='same fixed LedoitWolf automatic shrinkage and empirical known target variance',
        constants='exact FIT-constant dimensions explicit natural unit1 deviations; no epsilon',
        score='(active Mahalanobis squared distance + constant-field unit1 squared deviations)/78',
        selector='original frozen primary predicted_fine and observed original native Destination Port',
        CAL='one original900 predicted-coarse finite99 cutoff; strict greater; no sweep',
        known='all original900 CP BEN/KNA integer99 and paired zero correct-known loss before current',
        current='complete original4056 raw native asset; no neural forward; no query fit',
        DVC='same frozen learned110; fresh label-blind DVC/affinity/reconstruction/noise',
        merge='actual T41_799 candidate copy plus ownraw AND currentDVC retained; retain all old predictedUNA',
        fixed_candidates=1,parameter_grid=False,NN_forward=0,NN_training=0,NN_training_seconds=0,
        metric_fit=0,native_RMS_fit=0,query_covariance_or_CAL_fit=0,train_union_unique_rows=6000,
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)


def fit_model(vectors,true_fine,ports):
    vectors=np.asarray(vectors,np.float64);fine=np.asarray(true_fine);ports=np.asarray(ports)
    files.require(vectors.shape==(6000,78) and np.isfinite(vectors).all()
        and fine.shape==ports.shape==(6000,) and np.isin(fine,range(9)).all(),
        'complete genuineFIT6000 native78 and known fine/observed port only')
    global_models={};port_models={}
    for label in range(9):
        rows=fine==label;global_models[str(label)]=joint.fit_cell(vectors[rows])
        for port in np.unique(ports[rows]):
            subset=rows&(ports==port)
            if int(subset.sum())>=20:port_models[joint.cell_key(label,port)]=joint.fit_cell(vectors[subset])
    return dict(fine_global=global_models,fine_port_cells=port_models,fit_rows=6000,
        cell_minimum_unique_support=20,input=policy()['signal'],query_used_for_fit=False,
        selector=policy()['selector'],score=policy()['score'])


def score_vectors(vectors,predicted_fine,ports,model):
    value=np.asarray(vectors,np.float64);fine=np.asarray(predicted_fine);ports=np.asarray(ports)
    files.require(value.ndim==2 and value.shape[1]==78 and np.isfinite(value).all()
        and fine.shape==ports.shape==(len(value),) and np.isin(fine,range(9)).all(),
        'fixed raw78 and original predictedfine/observedport only')
    selectors={};result=np.empty(len(value));used=np.empty(len(value),dtype='<U40')
    for i,(label,port) in enumerate(zip(fine,ports)):
        exact=joint.cell_key(label,port)
        key='port:'+exact if exact in model['fine_port_cells'] else 'fine:'+str(int(label))
        selectors.setdefault(key,[]).append(i)
    for key,rows in selectors.items():
        node=model['fine_port_cells'][key[5:]] if key.startswith('port:') else model['fine_global'][key[5:]]
        delta=value[rows]-np.asarray(node['centre'])
        active=np.asarray(node['active'],np.int64);constant=np.asarray(node['constant'],np.int64)
        distance=np.square(delta[:,constant]).sum(axis=1)
        if len(active):distance+=np.square(delta[:,active]@np.asarray(node['precision_factor'])).sum(axis=1)
        result[rows]=distance/78.;used[rows]=key
    files.require(np.isfinite(result).all() and np.all(result>=0),'finite fixed raw78 joint distance')
    return result,used


def normalize(native,rms):
    value=np.asarray(native,np.float64);rms=np.asarray(rms,np.float64)
    files.require(value.ndim==2 and value.shape[1]==78 and np.isfinite(value).all()
        and rms.shape==(78,) and np.isfinite(rms).all() and np.all(rms>0),
        'full original native78 and existing positive genuineFIT RMS')
    return (np.sign(value)*np.log1p(np.abs(value)))/rms


def freeze():
    pins={};old=files.js(joint.PREVIOUS,pins);oldreg=files.js(old['registry'],pins)
    train=files.js(oldreg['producer_report'],pins);trainreg=files.js(train['registry'],pins)
    oldmask=files.js(known_rule.MASK_KNOWN,pins)
    assets=dict(known110=oldreg['assets']['known110'],native_known=trainreg['native'],
        native_RMS=trainreg['units'],query110=oldreg['assets']['query110'],
        current_native=old['files']['full4056_native_inputs_before_masked_forward'],
        comparator=oldreg['assets']['comparator'],truth=oldreg['assets']['truth'],
        preserved_known_prediction=oldmask['files']['complete_increment_before_truth'],
        owned_metric=oldreg['assets']['owned_metric'])
    for asset in assets.values():files.read(asset,pins)
    files.require(oldreg['original_native_field_order']==list(trained.helpers.CIC_FEATURE_COLUMNS)
        and oldreg['original_native_field_order'][0]=='Destination Port',
        'bound canonical original78 order and observed native Destination Port')
    sources={Path(module.__file__).name:files.item(module.__file__) for module in
        (joint,previous,known_rule,context,context.geometry,context.geometry.dvc,
            context.bridge.learned,trained.core.previous,files)}
    registry=dict(schema_version=SCHEMA+'-registry-before-nativeFIT-covariance',policy=policy(),
        source=files.item(__file__),sources=sources,runtime_covariance_source=files.item(joint.runtime_covariance.__file__),
        assets=assets,producer_report=oldreg['producer_report'],geometry_registry=oldreg['geometry_registry'],
        comparator_key=oldreg['comparator_key'],native_field_order=oldreg['original_native_field_order'],
        outputs={phase:str(BASE/phase) for phase in ('known','current')},input_sha256=pins,
        freeze_numeric_arrays_decoded=0,status='FAIL_TARGET99',published=False,final_test_executed=False)
    out=ROOT/'tmp/cic1_native78_joint_rawport_20261011_v1';out.mkdir(exist_ok=False)
    return files.write(out/'registry_before_known_native78_joint_fit.json',registry)


def run(phase,path,sha,known_path=None,known_sha=None):
    pins={};ref=dict(path=str(Path(path).resolve()),sha256=sha);reg=files.js(ref,pins)
    files.require(reg['source']==files.item(__file__) and reg['policy']==policy(),
        'exact fixed last raw-native candidate')
    files.require(reg['runtime_covariance_source']==files.item(joint.runtime_covariance.__file__),
        'same installed known-only covariance runtime')
    for asset in reg['sources'].values():files.read(asset,pins)
    if phase=='current':
        files.require(known_path and known_sha,'own actual known zero-loss report required')
        control=files.js(dict(path=str(Path(known_path).resolve()),sha256=known_sha),pins)
        files.require(control['registry']==ref and control['known_gate_passed']
            and control['known_correct_loss']==dict(BEN=0,KNA=0),
            'own complete900 known gates before current native values')
    out=Path(reg['outputs'][phase]);out.mkdir(parents=True,exist_ok=False);began=time.perf_counter()
    report=dict(schema_version=SCHEMA,phase=phase,registry=ref,policy=policy(),files={},DVC_calls=0,
        NN_forward=0,NN_training=0,NN_training_seconds=0,joint_covariance_fit=0,CAL_cutoff_fit=0,
        metric_fit=0,native_RMS_fit=0,query_covariance_or_CAL_fit=0,
        prediction_sealed=False,truth_opened=False,accepted_baseline_replaced=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        rms=np.asarray(files.js(reg['assets']['native_RMS'],pins)['native78'])
        if phase=='known':
            fields=context.selected(reg['assets']['known110'],('FIT_ids','FIT_groups','FIT_fine')+
                tuple(role+'_'+key for role in ('CAL','CP') for key in ('ids','groups','Z110','stage1','predicted_fine')),pins)
            native=context.selected(reg['assets']['native_known'],tuple(role+'_'+key
                for role in ('FIT','CAL','CP') for key in ('ids','native78')),pins)
            files.require(len(set(fields['FIT_groups'].tolist()))==6000,'genuine unique6000 source groups; no optimizer copies')
            sets={role:set(fields[role+'_groups'].tolist()) for role in ('FIT','CAL','CP')}
            files.require(all(not sets[a]&sets[b] for a,b in (('FIT','CAL'),('FIT','CP'),('CAL','CP'))),
                'original known FIT/CAL/CP disjoint groups')
            for role in ('FIT','CAL','CP'):
                files.require(np.array_equal(fields[role+'_ids'],native[role+'_ids']),'same complete genuine original known order')
                if role!='FIT':files.require(np.array_equal(normalize(native[role+'_native78'],rms),fields[role+'_Z110'][:,:78]),
                    'exact all known original signedlogRMS native78 context')
            fit_vector=normalize(native['FIT_native78'],rms)
            fa=trained.core.previous.save(out,'genuineFIT6000_native78_before_covariance',
                dict(ids=fields['FIT_ids'],groups=fields['FIT_groups'],fine=fields['FIT_fine'],
                    native78=fit_vector,destination_port=joint.port_keys(native['FIT_native78'])),report)
            fit_began=time.perf_counter()
            model=fit_model(fit_vector,fields['FIT_fine'],joint.port_keys(native['FIT_native78']))
            report['known_covariance_fit_seconds']=time.perf_counter()-fit_began;report['joint_covariance_fit']=1
            report['files']['model']=files.write(out/'genuineFIT6000_native78_LedoitWolf_fine_port_before_CAL.json',model)
            cal_score,cal_cells=score_vectors(normalize(native['CAL_native78'],rms),
                fields['CAL_predicted_fine'],joint.port_keys(native['CAL_native78']),model)
            ca=trained.core.previous.save(out,'CAL_native_joint_scores_before_CP',dict(ids=fields['CAL_ids'],score=cal_score,
                stage1=fields['CAL_stage1'],predicted_fine=fields['CAL_predicted_fine'],cell=cal_cells),report)
            cut=context.geometry.dvc.calibrate_known_cutoffs(cal_score,fields['CAL_stage1'])
            files.require(all(node['enabled'] for node in cut.values()),'finite once-original coarseCAL99')
            report['CAL_cutoff_fit']=1
            report['files']['cutoffs']=files.write(out/'once_originalCAL900_native_joint_cutoffs_before_CP.json',
                dict(cutoffs=cut,model=report['files']['model'],source=ca,CP_used=False,unknown_used=False))
            query=context.role_query(fields,'CP');vector=normalize(native['CP_native78'],rms)
            ports=joint.port_keys(native['CP_native78'])
        else:
            model=files.js(control['files']['model'],pins);cut=files.js(control['files']['cutoffs'],pins)['cutoffs']
            query=context.selected(reg['assets']['query110'],('ids','groups','Z110','stage1','predicted_fine'),pins)
            native=context.selected(reg['assets']['current_native'],('ids','native78','normalized78'),pins)
            files.require(len(query['ids'])==len(set(query['groups'].tolist()))==4056
                and np.array_equal(query['ids'],native['ids']) and native['native78'].shape==(4056,78),
                'all original4056 ordered rows and unique density groups')
            vector=normalize(native['native78'],rms);ports=joint.port_keys(native['native78'])
            files.require(np.array_equal(vector,query['Z110'][:,:78])
                and np.array_equal(vector.astype(np.float32),native['normalized78']),
                'exact full4056 frozen native78 signedlogRMS, no field guess')
        current_score,cells=score_vectors(vector,query['predicted_fine'],ports,model)
        trained.core.previous.save(out,'fixed_native_joint_scores_and_cells_before_DVC',dict(ids=query['ids'],score=current_score,
            predicted_fine=query['predicted_fine'],destination_port=ports,cell=cells),report)
        geometry=files.js(reg['geometry_registry'],pins)
        _,raw,retained=context.geometry.route(context.metric_from_registry(geometry,pins),query,current_score,cut,
            out,'native_joint78',report)
        if phase=='known':old=context.selected(reg['assets']['preserved_known_prediction'],('ids','baseline'),pins);baseline=old['baseline']
        else:old=context.selected(reg['assets']['comparator'],('ids',reg['comparator_key']),pins);baseline=old[reg['comparator_key']]
        files.require(np.array_equal(query['ids'],old['ids']),'actual comparator exact original row order')
        prediction=baseline.copy();prediction[raw&retained]=2
        files.require(np.all(prediction[baseline==2]==2),'every original predictedUNA retained')
        pa=trained.core.previous.save(out,'complete_native_joint_prediction_before_truth',dict(ids=query['ids'],baseline=baseline,
            prediction=prediction,raw=raw,retained=retained),report)
        report['files']['prediction_seal']=files.write(out/'complete_native_joint_prediction_seal_before_truth.json',
            dict(prediction=pa,truth_opened=False,model=report['files']['model'] if phase=='known' else control['files']['model'],
                cutoffs=report['files']['cutoffs'] if phase=='known' else control['files']['cutoffs']))
        report['prediction_sealed']=True
        if phase=='known':y=context.selected(reg['assets']['known110'],('CP_truth',),pins)['CP_truth']
        else:
            truth=context.selected(reg['assets']['truth'],('ids','truth'),pins)
            files.require(np.array_equal(query['ids'],truth['ids']),'truth original full4056 IDs only after seal');y=truth['truth']
        report['truth_opened']=True
        gates=context.integer_gates(y,prediction,known_only=phase=='known');oldg=context.integer_gates(y,baseline,known_only=phase=='known')
        gainloss={name:dict(gain=int(np.sum((y==code)&(baseline!=code)&(prediction==code))),
            loss=int(np.sum((y==code)&(baseline==code)&(prediction!=code)))) for code,name in enumerate(gates)}
        delta={name:gates[name]['correct']-oldg[name]['correct'] for name in gates}
        positive,negative=any(value>0 for value in delta.values()),any(value<0 for value in delta.values())
        direction='MIXED' if positive and negative else 'UP' if positive else 'DOWN' if negative else 'UNCHANGED'
        loss={name:gainloss[name]['loss'] for name in ('BEN','KNA')}
        trained.core.previous.save(out,'postseal_native_joint_paired_comparison',dict(ids=query['ids'],truth=y,baseline=baseline,
            prediction=prediction,raw=raw,retained=retained),report)
        report.update(execution_status='native78_joint_rawport_'+phase+'_evaluated',original_class_gates=gates,baseline_class_gates=oldg,
            EffectDelta=dict(verdict=direction,correct_count_delta=delta,gain_loss=gainloss,same_original_IDs_and_order=True,
                accepted_baseline_replaced=False),known_correct_loss=loss,
            known_gate_passed=all(gates[name]['passed'] for name in ('BEN','KNA')) and not any(loss.values()),
            all_three_integer99_passed=phase=='current' and all(row['passed'] for row in gates.values()),rows=len(y),
            raw_candidates=int(raw.sum()),retained_candidates=int(retained.sum()),
            raw_by_true_class={name:int(np.sum((y==code)&raw)) for code,name in enumerate(gates)},
            fine_global_models=len(model['fine_global']),fine_port_models=len(model['fine_port_cells']),
            new_covariance_training_is_NN_training=False,reused_maskaux_actual_training_seconds=files.js(reg['producer_report'],pins)['training_seconds'])
        for bound,wanted in pins.items():files.require(files.item(bound)['sha256']==wanted,'all pinned source and assets unchanged')
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        report['input_sha256']=pins;report['wall_seconds']=time.perf_counter()-began
        files.write(out/'report.json',report)
    return files.item(out/'report.json')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for name in ('registry','registry-sha256','known-report','known-sha256'):parser.add_argument('--'+name)
    args=parser.parse_args()
    print(json.dumps(freeze() if args.phase=='freeze' else run(args.phase,args.registry,args.registry_sha256,args.known_report,args.known_sha256)))
