"""One fixed known-fine-specific support guard for frozen CIC2 outputs.

All geometry is fitted once on the shared 5987 genuine known FIT groups.
The frozen CP BEN confidence envelopes are reused without recalibration.
Both original CP/CAL predictions are sealed before any CAL truth is opened.
No unknown phase, new classifier fit, threshold sweep or promotion is offered.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import time

import numpy as np

from . import cic2_fine_hist_support_guard_v1 as support

prior = support.prior
fine = support.fine
h = support.h
ROOT = support.ROOT
OUT = ROOT / 'data/external_dev/processed/cic2_fine_hist_class_support_20261011_v1'
REGISTRY_OUT = ROOT / 'tmp/cic2_fine_hist_class_support_20261011_v1'
PARENT = dict(path=str(support.OUT / 'report.json'),
              sha256='516b1607d00ae9d17a1f9d01f09da6194b64d1c2afc98087756e01d66a28e087')
PRESERVED_SOURCES = {
    str(Path(support.__file__).resolve()): 'fd4e809aeef8156eac32bf860ba6d25716ff38ffeb73f9e996e063f9d4fd403b',
    str(Path(prior.__file__).resolve()): '6a51d0abbdfe7213053a1bb1f69dcb92ee990df8ec92c6e9bc653e2aa67ea1a7',
    str(Path(fine.__file__).resolve()): 'bd4e63f07ec70e6c91eba56c7ab5212633a8be78b473a4021730444012dcbb74',
    str(Path(h.__file__).resolve()): 'f875ec7442c8713aac7a058d6ac5730e81975d0822bf6f6efc1c2061d6efb331',
}


def policy():
    return dict(schema_version='CIC2-fine9-HGB-CP-envelope-class-Fisher-support-v1',
        hypotheses=1, base='unchanged original strong MHFD and fine forest predictions; frozen fine9 HGB200 outputs',
        decision='primary BEN becomes KNA only if unchanged CP BEN envelope admits auxiliary predicted attack fine and its nearest true fine FIT support is strictly closer than BEN FIT support',
        coordinates='all native78 signed log1p divided by per-field uniqueFIT RMS; naturally zero RMS uses native log unit1',
        Fisher='for each true attack fine versus BEN, squared coordinate mean gap divided by sum of population within-class variances; naturally zero denominator uses unit1; normalize all78 weights to mean1; if all mean gaps are zero use all unit weights',
        distance='nearest exact squared Euclidean distance under that predicted fine diagonal; strict fine<BEN; ties retain primary BEN',
        references='all shared5987 genuine unique FIT groups; true fine9 labels from FIT only; 13 optimizer copies excluded',
        training_union_unique=5987, frozen_classifier_optimizer_rows=6000,
        frozen_classifier_optimizer_copies=13, new_optimizer_rows=0,
        CP_envelope_reused_unchanged=True, CP_envelope_fit=0,
        CAL_threshold_fit=0, query_fit=0, feature_selection=False, epsilon=False,
        inference_inputs='known features and fixed classifier output arrays only; no identities or query truth',
        CPU_only=True, NN_fit=0, HGB_fit=0, NN_forward=0, HGB_forward=0,
        warm_known_controls=True, independent_final_asserted=False,
        unknown_entry=False, accepted_baseline_replaced=False,
        status='FAIL_TARGET99', published=False, final_test_executed=False)


def bindings():
    for path, wanted in PRESERVED_SOURCES.items():
        h.require(h.sha(path) == wanted, 'preserved_parent_source:' + path)
    return {str(Path(path).resolve()): h.sha(path) for path in
            (__file__, support.__file__, prior.__file__, fine.__file__, h.__file__, h.header_tools.__file__)}


def signed_log(native):
    native = np.asarray(native)
    h.require(native.ndim == 2 and native.shape[1] == 78
        and np.issubdtype(native.dtype, np.floating) and np.isfinite(native).all(), 'complete_finite_native78')
    native = native.astype(np.float64, copy=False)
    return np.sign(native) * np.log1p(np.abs(native))


def coordinates(native, units):
    logged = signed_log(native)
    units = np.asarray(units)
    h.require(units.shape == (78,) and np.issubdtype(units.dtype, np.floating)
        and np.isfinite(units).all() and np.all(units > 0), 'uniqueFIT_positive_units')
    return np.ascontiguousarray(logged / units, np.float64)


def fisher_diagonal(ben, attack):
    """No smoothing constants: native zero variance uses the declared unit1."""
    ben, attack = np.asarray(ben), np.asarray(attack)
    h.require(ben.ndim == attack.ndim == 2 and ben.shape[1] == attack.shape[1] == 78
        and len(ben) > 0 and len(attack) > 0 and np.isfinite(ben).all()
        and np.isfinite(attack).all(), 'positive_complete_known_fine_FIT_support')
    gap = attack.mean(axis=0) - ben.mean(axis=0)
    within = attack.var(axis=0, ddof=0) + ben.var(axis=0, ddof=0)
    h.require(np.isfinite(within).all() and np.all(within >= 0), 'natural_finite_pooled_variance')
    denominator = np.where(within > 0, within, 1.)
    raw = np.square(gap) / denominator
    total = float(raw.sum())
    h.require(np.isfinite(raw).all() and np.isfinite(total), 'finite_Fisher_diagonal')
    weights = raw * (78. / total) if total > 0 else np.ones(78, np.float64)
    h.require(np.isfinite(weights).all() and np.all(weights >= 0)
        and np.isclose(weights.sum(), 78., rtol=0, atol=1e-10), 'normalized_all78_Fisher_weights')
    return weights, within == 0, total == 0


def fit_geometry(native, true_fine):
    logged = signed_log(native)
    true_fine = np.asarray(true_fine)
    h.require(true_fine.dtype == np.int64 and true_fine.shape == (len(logged),)
        and set(np.unique(true_fine)) == set(range(9)), 'actual_FIT_fine9_labels')
    rms = np.sqrt(np.mean(np.square(logged), axis=0))
    units = np.where(rms > 0, rms, 1.)
    z = coordinates(native, units)
    references = {label: np.ascontiguousarray(z[true_fine == label]) for label in range(9)}
    weights, zero_variances, zero_gaps = {}, {}, {}
    for label in range(1, 9):
        weights[label], zero_variances[label], zero_gaps[label] = fisher_diagonal(references[0], references[label])
    return units, references, weights, zero_variances, zero_gaps


def nearest_squared(query, references, weights):
    query, references, weights = np.asarray(query), np.asarray(references), np.asarray(weights)
    h.require(query.ndim == references.ndim == 2 and query.shape[1] == references.shape[1] == 78
        and len(references) > 0 and weights.shape == (78,) and np.isfinite(query).all()
        and np.isfinite(references).all() and np.isfinite(weights).all()
        and np.all(weights >= 0), 'known_weighted_distance_inputs')
    # Direct differences avoid subtractive negative distances. Query batching is
    # fixed for memory use and cannot change either fitted units or the rule.
    result = np.empty(len(query), np.float64)
    for start in range(0, len(query), 16):
        delta = query[start:start + 16, None, :] - references[None, :, :]
        squared = np.sum(np.square(delta) * weights, axis=2)
        result[start:start + 16] = squared.min(axis=1)
    h.require(np.isfinite(result).all() and np.all(result >= 0), 'finite_natural_squared_distances')
    return result


def class_support(primary, probabilities, envelope, native, units, references, weights):
    """Query labels and identities are deliberately absent from this API."""
    _, proposed = prior.correct_known(primary, probabilities, envelope)
    predicted_fine = np.argmax(prior.check_fine(probabilities), axis=1).astype(np.int64)
    z = coordinates(native, units)
    h.require(len(z) == len(proposed), 'same_feature_and_classifier_output_rows')
    dben = np.zeros(len(z), np.float64)
    dfine = np.zeros(len(z), np.float64)
    for label in range(1, 9):
        selected = proposed & (predicted_fine == label)
        if np.any(selected):
            dben[selected] = nearest_squared(z[selected], references[0], weights[label])
            dfine[selected] = nearest_squared(z[selected], references[label], weights[label])
    admitted = proposed & (dfine < dben)
    prediction = np.asarray(primary).copy()
    prediction[admitted] = 1
    h.require(np.array_equal(prediction[np.asarray(primary) == 1], np.asarray(primary)[np.asarray(primary) == 1]),
        'all_primary_KNA_predictions_preserved')
    return prediction, proposed, admitted, predicted_fine, dben, dfine


def freeze():
    pins = {}
    parent = h.read(PARENT, pins)
    reg = h.read(parent['registry'], pins)
    confidence = h.read(reg['parent'], pins)
    h.require(parent['execution_status'] == 'known_fine_and_nearest_support_guard_evaluated'
        and parent['prediction_sealed'] and not parent['paired_strong_correct_loss_free']
        and not parent['original_and_reporting_integer99_passed']
        and parent['unknown_reads'] == 0 and not parent['unknown_phase_allowed'], 'exact_unpromoted_global_support_parent')
    h.require(confidence['execution_status'] == 'known_fine_BEN_envelope_guard_evaluated'
        and confidence['CP_envelope_sealed'] and confidence['prediction_sealed']
        and confidence['files']['envelope'] == reg['envelope'], 'unchanged_sealed_CP_envelope')
    for item in (reg['native'], reg['strong'], reg['assets']['CP'], reg['assets']['CAL'], reg['envelope'],
                 parent['files']['predictions'], reg['previous_predictions']):
        h.checked(item, pins)
    heads = h.header_tools.npz_headers(h.checked(reg['native'], pins))
    for role, count in (('FIT', 5987), ('CP', 882), ('CAL', 882)):
        for suffix, shape in (('native78', [count, 78]), ('ids', [count]), ('y_fine', [count]), ('y_coarse', [count])):
            h.require(heads[role + '_' + suffix]['shape'] == shape, 'actual_complete_native_header:' + role + '_' + suffix)
    h.require(heads['FIT_training_indices']['shape'] == [6000]
        and heads['CP_reporting_indices']['shape'] == heads['CAL_reporting_indices']['shape'] == [900], 'frozen_optimizer_and_reporting_map_headers')
    for role in ('CP', 'CAL'):
        probability_heads = h.header_tools.npz_headers(h.checked(reg['assets'][role], pins))
        h.require(probability_heads['hist_fine']['shape'] == [882, 9]
            and probability_heads['ids']['shape'] == [882], 'actual_saved_fine9_probability_headers:' + role)
    sources = bindings()
    for path, wanted in sources.items():
        h.checked(dict(path=path, sha256=wanted), pins)
    h.require(not OUT.exists() and not REGISTRY_OUT.exists(), 'fresh_class_support_registry_and_output')
    REGISTRY_OUT.mkdir(parents=True, exist_ok=False)
    return h.json_new(REGISTRY_OUT / 'registry_before_uniqueFIT_class_geometry.json', dict(
        policy=policy(), sources=sources, parent=PARENT, confidence_parent=reg['parent'],
        native=reg['native'], strong=reg['strong'], assets=reg['assets'], envelope=reg['envelope'],
        previous_predictions=dict(global_support=parent['files']['predictions'], confidence_only=reg['previous_predictions']),
        input_sha256=pins, output=str(OUT), feature_decodes=0, known_probability_decodes=0,
        CP_truth_opened=False, CAL_truth_opened=False, unknown_reads=0))


def run(path, sha):
    registry = dict(path=str(Path(path).resolve()), sha256=sha)
    pins, started, stage = {}, time.perf_counter(), 'bind_registry'
    report = dict(policy=policy(), registry=registry, files={}, NN_fit=0, HGB_fit=0,
        NN_forward=0, HGB_forward=0, metric_fit=0, FIT_unit_fit=0,
        nearest_reference_index_fit=0, CP_envelope_fit=0, CAL_threshold_fit=0,
        query_fit=0, score=0, DVC=0, prediction_sealed=False, CAL_truth_opened=False,
        unknown_reads=0, unknown_phase_allowed=False, accepted_baseline_replaced=False,
        protocol_events=[], status='FAIL_TARGET99', published=False, final_test_executed=False)
    h.require(not OUT.exists(), 'fresh_once_class_support_output')
    OUT.mkdir(parents=True, exist_ok=False)
    try:
        reg = h.read(registry, pins)
        h.require(reg['policy'] == policy() and reg['sources'] == bindings()
            and reg['output'] == str(OUT), 'frozen_class_support_source_policy_destination')
        for asset, wanted in reg['input_sha256'].items():
            h.checked(dict(path=asset, sha256=wanted), pins)
        stage = 'unique_knownFIT_geometry_before_any_control_features'
        fields = fine.load(reg['native'], ('FIT_native78', 'FIT_y_fine', 'FIT_y_coarse',
            'FIT_ids', 'FIT_training_indices', 'CP_ids', 'CAL_ids'), pins)
        h.require(len(fields['FIT_ids']) == 5987 and len(np.unique(fields['FIT_ids'])) == 5987, 'all_unique_genuine_FIT_groups')
        all_ids = np.concatenate([fields[role + '_ids'] for role in ('FIT', 'CP', 'CAL')])
        h.require(len(all_ids) == len(np.unique(all_ids)) == 7751, 'disjoint_genuine_known_role_IDs')
        index, truth = fields['FIT_training_indices'], fields['FIT_y_fine']
        h.require(index.dtype == np.int64 and index.shape == (6000,)
            and np.all((index >= 0) & (index < 5987))
            and np.array_equal(fields['FIT_y_coarse'], (truth > 0).astype(np.int64)), 'unchanged_fine9_coarse_labels_and_train6000')
        repeats = np.bincount(index, minlength=5987)
        h.require(np.all(repeats >= 1) and int((repeats - 1).sum()) == 13
            and np.all(truth[repeats > 1] == fine.FAMILIES.index('Heartbleed')), '5987_genuine_plus_only13_optimizer_copies')
        units, references, weights, zero_variance, zero_gap = fit_geometry(fields['FIT_native78'], truth)
        report.update(FIT_unit_fit=1, metric_fit=1, training_union_unique=5987,
            frozen_classifier_optimizer_rows=6000, new_optimizer_rows=0, reference_copies=0)
        report['files']['geometry'] = h.npz_new(OUT / 'uniqueFIT_class_geometry_before_known_queries.npz',
            dict(units=units, labels=np.arange(1, 9, dtype=np.int64),
                weights=np.stack([weights[label] for label in range(1, 9)]),
                zero_within_variance=np.stack([zero_variance[label] for label in range(1, 9)]),
                all_zero_mean_gap=np.array([zero_gap[label] for label in range(1, 9)], dtype=bool)), {})
        report['files']['geometry_seal'] = h.json_new(OUT / 'uniqueFIT_class_geometry_seal_before_known_queries.json', dict(
            geometry=report['files']['geometry'], native=reg['native'], copies_in_reference=0,
            FIT_fine_counts={str(k): int(v) for k, v in Counter(truth.tolist()).items()},
            FIT_training_indices=h.ad(index), FIT_ids=h.ad(fields['FIT_ids']),
            fit_class_labels_role='genuine_known_FIT_only', CP_features_used=False,
            CAL_features_or_truth_used=False, query_fitted_weights_or_units=False))
        report['protocol_events'].append('uniqueFIT_geometry_sealed_before_known_query_features')
        envelope = np.asarray(h.read(reg['envelope'], pins)['envelope'], np.float64)
        main = fine.load(reg['strong'], tuple(role + '_' + key for role in ('CP', 'CAL') for key in ('ids', 'candidate')), pins)
        values, added, proposed_counts = {}, {}, {}
        stage = 'complete_known_features_and_outputs_before_CAL_truth'
        for role in ('CP', 'CAL'):
            features = fine.load(reg['native'], (role + '_ids', role + '_native78'), pins)
            auxiliary = fine.load(reg['assets'][role], ('ids', 'hist_fine'), pins)
            h.require(np.array_equal(features[role + '_ids'], auxiliary['ids'])
                and np.array_equal(auxiliary['ids'], main[role + '_ids'])
                and np.array_equal(features[role + '_ids'], fields[role + '_ids']), 'same_frozen_known_feature_probability_ID_order:' + role)
            prediction, proposed, admitted, predicted_fine, dben, dfine = class_support(
                main[role + '_candidate'], auxiliary['hist_fine'], envelope,
                features[role + '_native78'], units, references, weights)
            added[role], proposed_counts[role] = int(admitted.sum()), int(proposed.sum())
            values.update({role + '_ids': features[role + '_ids'], role + '_prediction': prediction,
                role + '_primary': main[role + '_candidate'], role + '_confidence_proposed': proposed,
                role + '_support_admitted': admitted, role + '_predicted_fine': predicted_fine,
                role + '_nearBEN_squared': dben, role + '_near_predicted_fine_squared': dfine})
        report['files']['predictions'] = h.npz_new(OUT / 'known_class_support_predictions_before_CAL_truth.npz', values, {})
        report['files']['prediction_seal'] = h.json_new(OUT / 'known_class_support_prediction_seal_before_CAL_truth.json', dict(
            predictions=report['files']['predictions'], geometry=report['files']['geometry'],
            geometry_seal=report['files']['geometry_seal'], envelope=reg['envelope'], CAL_truth_used=False,
            query_identities_or_labels_used_for_decision=False, reference_class_labels_role='knownFIT_only',
            distances_for_nonproposed_rows='stored zero; excluded by confidence_proposed mask'))
        report['prediction_sealed'] = True
        report['protocol_events'].append('complete_CP_CAL_predictions_sealed_before_CAL_truth_and_previous_predictions')
        stage = 'postseal_complete_known_truth_and_paired_comparison'
        h.require(report['prediction_sealed'] and report['metric_fit'] == report['FIT_unit_fit'] == 1
            and not report['CAL_truth_opened'], 'complete_prediction_seal_required_before_truth')
        meta = fine.load(reg['native'], tuple(role + '_' + key for role in ('CP', 'CAL') for key in ('ids', 'y_coarse', 'reporting_indices')), pins)
        report['CAL_truth_opened'] = True
        comparisons = {name: fine.load(asset, tuple(role + '_' + key for role in ('CP', 'CAL') for key in ('ids', 'prediction')), pins)
            for name, asset in reg['previous_predictions'].items()}
        gates, reporting, effects, reporting_effects = {}, {}, {}, {}
        for role in ('CP', 'CAL'):
            y, idx, pred = meta[role + '_y_coarse'], meta[role + '_reporting_indices'], values[role + '_prediction']
            h.require(np.array_equal(meta[role + '_ids'], values[role + '_ids'])
                and idx.dtype == np.int64 and idx.shape == (900,)
                and np.array_equal(idx[:882], np.arange(882))
                and np.all((idx >= 0) & (idx < 882)), 'complete_original882_then_reporting_copies18:' + role)
            gates[role], reporting[role] = h.gates(y, pred), h.gates(y[idx], pred[idx])
            effects[role], reporting_effects[role] = {}, {}
            before_all = {'original_strong': values[role + '_primary']}
            for name, old in comparisons.items():
                h.require(np.array_equal(old[role + '_ids'], values[role + '_ids']), 'same_postseal_comparison_IDs:' + name + ':' + role)
                before_all[name] = old[role + '_prediction']
            for name, before in before_all.items():
                effects[role][name] = h.paired(y, before, pred)
                reporting_effects[role][name] = h.paired(y[idx], before[idx], pred[idx])
                values[role + '_' + name + '_gain'] = (before != y) & (pred == y)
                values[role + '_' + name + '_loss'] = (before == y) & (pred != y)
            values[role + '_truth'], values[role + '_reporting_indices'] = y, idx
        report['files']['postseal_pair'] = h.npz_new(OUT / 'postseal_known_class_support_paired_comparison.npz', values, {})
        for asset, wanted in pins.items():
            h.require(h.sha(asset) == wanted, 'class_support_input_unchanged:' + asset)
        all_passed = all(gate['passed'] for collection in (gates, reporting) for role in collection.values() for gate in role.values())
        loss_free = all(effect['original_strong']['loss'] == 0 for effect in effects.values())
        reasons = ['OWN_NEW_CAL_NOVELTY_ALIGNMENT_REQUIRED_BEFORE_ANY_UNKNOWN']
        for name, collection in (('original', gates), ('reporting', reporting)):
            for role, group in collection.items():
                for label, gate in group.items():
                    if not gate['passed']:
                        reasons.append(f"{name}:{role}:{label}:{gate['correct']}/{gate['support']}<required{gate['required_correct']}")
        for role, effect in effects.items():
            if effect['original_strong']['loss']:
                reasons.append(f"original_strong:{role}:paired_correct_loss={effect['original_strong']['loss']}")
        report.update(execution_status='known_fine_class_Fisher_support_guard_evaluated',
            known_gates=gates, effective_reporting_gates=reporting, EffectDelta=effects,
            reporting_EffectDelta=reporting_effects, added_KNA_rows=added,
            confidence_proposed_rows=proposed_counts, original_and_reporting_integer99_passed=all_passed,
            paired_strong_correct_loss_free=loss_free, known_gate_and_paired_loss_free=all_passed and loss_free,
            rejection_or_hold_reasons=reasons, promotion_status='NOT_PROMOTED_WARM_KNOWN_DIAGNOSTIC',
            own_new_CAL_novelty_alignment_required_before_unknown=True)
    except Exception as error:
        report.update(execution_status='execution_failed', failed_stage=stage,
            error_type=type(error).__name__, error=str(error))
        raise
    finally:
        report.update(input_sha256=pins, wall_seconds=time.perf_counter() - started)
        h.json_new(OUT / 'report.json', report)
    return h.descriptor(OUT / 'report.json')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=('freeze', 'known'), required=True)
    parser.add_argument('--registry')
    parser.add_argument('--registry-sha256')
    args = parser.parse_args()
    if args.phase == 'known' and (not args.registry or not args.registry_sha256):
        parser.error('known phase requires registry and SHA')
    print(json.dumps(freeze() if args.phase == 'freeze' else run(args.registry, args.registry_sha256), ensure_ascii=False))
