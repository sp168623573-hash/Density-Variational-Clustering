"""One full4056 CPU masked forward with frozen conditional mean78 known rule.

This new source preserves the frozen known-control module and its artifacts.
Current prediction copies the actual T41_799 candidate comparator, then adds
only this run's raw candidates retained by the owned frozen110 DVC chain.
"""
from __future__ import annotations

import argparse
import io
import json
from pathlib import Path
import time

import numpy as np
import torch

from . import cic1_mask78_conditional_mean_hint_v1 as known_rule
from . import cic2017_native_partial_dev_source_v1 as native_source

prior, trained, context = known_rule.prior, known_rule.trained, known_rule.context
ROOT, files = known_rule.ROOT, known_rule.files
BASE = ROOT/'data/external_dev/processed/cic1_mask78_conditional_mean_current_20261011_v1'
SCHEMA = 'CIC1-preserved799-frozen-conditional-mean78-full4056-CPU-current-v1'
KNOWN = dict(path=str(known_rule.BASE/'known/report.json'),
             sha256='9f5a26d490f4c430760115a140607f7662ce066cc8d7015584ac39ee1396ff5d')


def policy():
    return dict(schema_version=SCHEMA, setting='CIC Setting1',
        scope='all original4056 warm development; not independent final',
        admission='exact frozen known9f5a26 report full900 integer99 and paired zero loss',
        score=known_rule.policy()['score'], selector=known_rule.policy()['selector'],
        field_units='exact frozen known FIT conditional units; no current units fit',
        CAL='exact frozen known originalCAL coarse finite99 cutoffs; no re-calibration',
        native='all original78 in canonical producer field order, signedlog divided by same frozenFIT RMS',
        forward='same final80 full78 masked auxiliary, CPU float32 eval, each of78 fields masked once on all4056',
        geometry='exact existing110 coordinates/learned metric; no representation/metric/reference/unit fit',
        second_stage='same current raw-candidate DVC, affinity, reconstruction and noise correction',
        merge='actual complete T41_799 candidate copy plus only own raw AND current DVC retained; every previous UNA preserved',
        comparator='original T41_799 pretruth candidate asset with exact complete4056 IDs',
        truth='open original truth only after complete new prediction seal',
        CPU_threads=4, optimizer_training_runs=0, training_seconds=0,
        NN_or_forest_primary_forward=0, CAL_cutoff_fit=0, conditional_units_fit=0,
        current_parameter_fit=False, label_or_ID_rule=False,
        accepted_baseline_replaced=False, status='FAIL_TARGET99',
        published=False, final_test_executed=False)


def freeze():
    pins = {}
    control = files.js(KNOWN, pins)
    files.require(control['known_gate_passed'] and control['full_known_rows'] == 900
        and control['known_correct_loss'] == dict(BEN=0,KNA=0)
        and all(row['passed'] for row in control['original_class_gates'].values()),
        'complete frozen original900 known integer99 paired zero-loss control')
    known_reg = files.js(control['registry'], pins)
    files.require(known_reg['source'] == files.item(known_rule.__file__)
        and known_reg['policy'] == known_rule.policy(), 'original known rule source unchanged')
    train = files.js(known_reg['producer_report'], pins)
    train_reg = files.js(train['registry'], pins)
    geometry = files.js(known_reg['geometry_registry'], pins)
    query_reg = files.js(geometry['source']['query_registry'], pins)
    files.require(query_reg['known110'] == known_reg['assets']['known110']
        and query_reg['units'] == train_reg['units']
        and query_reg['known_arrays'] == train_reg['native']
        and query_reg['metric'] == known_reg['assets']['owned_metric'],
        'same original native78 units and known pool and owned110 geometry')
    field_names = list(trained.helpers.CIC_FEATURE_COLUMNS)
    files.require(field_names == list(native_source.native.CIC_FEATURE_COLUMNS)
        and field_names == [group['field'] for group in train_reg['field_map']['groups']]
        and train_reg['field_map']['selected_width'] == 78,
        'exact canonical original78 field order pinned to source and learned mask')
    assets = dict(query110=geometry['query110'], known110=geometry['known110'],
        native_known=train_reg['native'], native_unknown=query_reg['source']['unknown_features'],
        native_units=train_reg['units'], mask_model=known_reg['assets']['mask_model'],
        conditional_units=control['files']['conditional_units'], cutoffs=control['files']['cutoffs'],
        comparator=query_reg['source']['comparator'], truth=query_reg['source']['truth'],
        owned_metric=geometry['owned_metric'])
    for asset in assets.values():
        files.read(asset, pins)
    headers = {name:context.nn.header_tools.npz_headers(Path(assets[name]['path']))
        for name in ('query110','native_known','native_unknown','comparator','truth')}
    files.require(headers['query110']['Z110']['shape'] == [4056,110]
        and headers['native_unknown']['native78']['shape'] == [3156,78]
        and headers['native_known']['CP_native78']['shape'] == [900,78]
        and headers['comparator'][query_reg['source']['comparator_key']]['shape'] == [4056],
        'whole4056 original900 CP plus3156 unique current rows without sampling')
    sources = dict(known_control=files.item(known_rule.__file__),
        masked_producer=files.item(trained.__file__),
        masked_core=files.item(trained.core.__file__),
        raw_capture=files.item(trained.core.previous.__file__),
        prior_masked_control=files.item(prior.__file__),
        context=files.item(context.__file__), geometry=files.item(context.geometry.__file__),
        DVC=files.item(context.geometry.dvc.__file__), metric=files.item(context.bridge.learned.__file__),
        native_source=files.item(native_source.__file__), native_schema=files.item(native_source.native.__file__))
    registry = dict(schema_version=SCHEMA+'-registry-before-current-values',
        policy=policy(), source=files.item(__file__), sources=sources,
        known_control=KNOWN, known_registry=control['registry'],
        producer_report=known_reg['producer_report'], geometry_registry=known_reg['geometry_registry'],
        query_registry=geometry['source']['query_registry'], assets=assets,
        comparator_key=query_reg['source']['comparator_key'], original_native_field_order=field_names,
        field_map_sha256=train_reg['field_map_sha256'],
        model_state_sha256=known_reg['model_state_sha256'], output_directory=str(BASE/'current'),
        headers=headers, numeric_values_decoded=0, query_truth_decoded=False,
        input_sha256=pins, status='FAIL_TARGET99', published=False, final_test_executed=False)
    out = ROOT/'tmp/cic1_mask78_conditional_mean_current_20261011_v1'
    out.mkdir(exist_ok=False)
    return files.write(out/'registry_before_full4056_CPU_masked_forward.json', registry)


def current(path, sha):
    pins = {}
    ref = dict(path=str(Path(path).resolve()), sha256=sha)
    reg = files.js(ref, pins)
    files.require(reg['source'] == files.item(__file__) and reg['policy'] == policy(),
        'own fixed current source and zero-refit recipe')
    control = files.js(reg['known_control'], pins)
    files.require(control['known_gate_passed'] and control['known_correct_loss'] == dict(BEN=0,KNA=0),
        'frozen complete known control before current values')
    for asset in reg['sources'].values():
        files.read(asset, pins)
    out = Path(reg['output_directory'])
    out.mkdir(parents=True, exist_ok=False)
    began = time.perf_counter()
    before = trained.core.capture_runtime_flags()
    report = dict(schema_version=SCHEMA, phase='current', registry=ref,
        known_control=reg['known_control'], policy=policy(), files={},
        DVC_calls=0, masked_forward_batches=0, masked_fields_completed=0,
        optimizer_training_runs=0, training_seconds=0, primary_NN_forward=0, primary_forest_forward=0,
        model_fit=0, metric_fit=0, reference_fit=0, native_units_fit=0,
        conditional_units_fit=0, CAL_cutoff_fit=0, query_parameter_fit=0,
        device='cpu', CPU_threads=4, CUDA_calls=0,
        prediction_sealed=False, truth_opened=False, accepted_baseline_replaced=False,
        status='FAIL_TARGET99', published=False, final_test_executed=False)
    try:
        torch.set_num_threads(4)
        query = context.selected(reg['assets']['query110'],
            ('ids','groups','Z110','stage1','predicted_fine'), pins)
        known_native = context.selected(reg['assets']['native_known'], ('CP_ids','CP_native78'), pins)
        unknown_native = context.selected(reg['assets']['native_unknown'], ('ids','native78'), pins)
        native_ids = np.concatenate((known_native['CP_ids'],unknown_native['ids']))
        native = np.concatenate((known_native['CP_native78'],unknown_native['native78']),axis=0)
        files.require(len(query['ids']) == len(set(query['groups'].tolist())) == 4056
            and np.array_equal(query['ids'],native_ids) and native.shape == (4056,78)
            and np.isfinite(native).all(), 'all original4056 unique rows and original native ID order')
        unit_doc = files.js(reg['assets']['native_units'], pins)
        native_units = np.asarray(unit_doc['native78'],np.float64)
        files.require(native_units.shape == (78,) and np.all(native_units>0)
            and np.isfinite(native_units).all(), 'unchanged full78 frozenFIT positive RMS')
        normalized = (np.sign(native)*np.log1p(np.abs(native)))/native_units
        files.require(np.array_equal(normalized,query['Z110'][:,:78]),
            'exact all4056 original signedlog and model known RMS native78 geometry equality')
        x = np.ascontiguousarray(normalized,np.float32)
        trained.core.previous.save(out,'full4056_native_inputs_before_masked_forward',
            dict(ids=query['ids'], native78=native, normalized78=x),report)
        stored = torch.load(io.BytesIO(files.read(reg['assets']['mask_model'],pins)),
            map_location='cpu', weights_only=True)
        fmap = trained.core.field_map_from_state(stored['field_map'])
        files.require(fmap.file_sha256 == reg['field_map_sha256'], 'same canonical78 learned field map')
        net = trained.core.ExpandedWholeFieldMaskedMHFD(fmap,9).cpu()
        net.load_state_dict(stored['state_dict'],strict=True)
        net.eval()
        files.require(trained.core.output_io.state_digest(net) == reg['model_state_sha256'],
            'exact retained actual final80 masked state before full current forward')
        state = trained.core.output_io.state_digest(net)
        inference_began = time.perf_counter()
        error = np.empty((4056,78),np.float64)
        with torch.no_grad():
            for field in range(78):
                for first in range(0,4056,1024):
                    stop = min(first+1024,4056)
                    xb = torch.from_numpy(x[first:stop].copy())
                    mask = torch.full((len(xb),),field,dtype=torch.int64)
                    values = net.forward_masked(xb,mask)
                    live = {key:value.detach().numpy().copy() if value.dtype == torch.bool
                        else value.detach().float().numpy().copy() for key,value in values.items()}
                    trained.core.previous.save(out,'current_field'+str(field)+'_batch'+str(first),live,report)
                    report['masked_forward_batches'] += 1
                    error[first:stop,field] = np.square(live['reconstruction'][:,field].astype(np.float64)
                        - x[first:stop,field])
                report['masked_fields_completed'] += 1
                if (field+1)%13 == 0:
                    print(f'[CIC1 mean78 CPU] masked_fields={field+1}/78 all_rows=4056 elapsed={time.perf_counter()-inference_began:.1f}s',flush=True)
        report['masked_inference_seconds'] = time.perf_counter()-inference_began
        trained.core.previous.save(out,'full4056_all78_masked_field_errors_before_score',
            dict(ids=query['ids'], error=error),report)
        files.require(np.isfinite(error).all() and error.shape == (4056,78),
            'all current masked raw captures complete before field error use')
        units_doc = files.js(reg['assets']['conditional_units'],pins)
        cut_doc = files.js(reg['assets']['cutoffs'],pins)
        files.require(not units_doc['CP_used'] and not units_doc['unknown_used']
            and not cut_doc['CP_used'] and not cut_doc['unknown_used']
            and cut_doc['units'] == reg['assets']['conditional_units'],
            'exact frozen FIT units and originalCAL cutoff reused zero refits')
        score = known_rule.score_error(error,query['predicted_fine'],np.asarray(units_doc['units']))
        geometry = files.js(reg['geometry_registry'],pins)
        metric = context.metric_from_registry(geometry,pins)
        _,raw,retained = context.geometry.route(metric,query,score,cut_doc['cutoffs'],
            out,'conditional_mean78',report)
        old = context.selected(reg['assets']['comparator'],('ids',reg['comparator_key']),pins)
        files.require(np.array_equal(old['ids'],query['ids']), 'exact original T41_799 full4056 comparator IDs')
        baseline = old[reg['comparator_key']]
        files.require(baseline.shape == (4056,) and np.isin(baseline,(0,1,2)).all(),
            'complete actual pretruth original comparator prediction')
        prediction = baseline.copy()
        prediction[raw & retained] = 2
        files.require(np.all(prediction[baseline==2] == 2), 'all original predictedUNA preserved')
        pa = trained.core.previous.save(out,'complete_full4056_increment_before_truth',
            dict(ids=query['ids'],baseline=baseline,prediction=prediction,raw=raw,retained=retained),report)
        report['files']['prediction_seal'] = files.write(out/'complete_full4056_prediction_seal_before_truth.json',
            dict(prediction=pa,known_control=reg['known_control'],field_units=reg['assets']['conditional_units'],
                cutoffs=reg['assets']['cutoffs'],owned_metric=reg['assets']['owned_metric'],
                truth_opened=False,all_original4056_rows=True))
        report['prediction_sealed'] = True
        truth = context.selected(reg['assets']['truth'],('ids','truth'),pins)
        report['truth_opened'] = True
        files.require(np.array_equal(truth['ids'],query['ids']), 'original full4056 truth IDs after seal')
        y = truth['truth']
        gates = context.integer_gates(y,prediction)
        oldg = context.integer_gates(y,baseline)
        files.require({key:node['correct'] for key,node in oldg.items()} == dict(BEN=650,KNA=247,UNA=799)
            and {key:node['support'] for key,node in oldg.items()} == dict(BEN=651,KNA=249,UNA=3156),
            'actual preserved genuine T41_799 comparator supports and correct counts')
        delta = {name:gates[name]['correct']-oldg[name]['correct'] for name in gates}
        gainloss = {name:dict(gain=int(np.sum((y==code)&(baseline!=code)&(prediction==code))),
            loss=int(np.sum((y==code)&(baseline==code)&(prediction!=code))))
            for code,name in enumerate(('BEN','KNA','UNA'))}
        direction = ('MIXED' if any(value>0 for value in delta.values()) and any(value<0 for value in delta.values())
            else 'UP' if any(value>0 for value in delta.values()) else 'DOWN' if any(value<0 for value in delta.values()) else 'UNCHANGED')
        trained.core.previous.save(out,'postseal_full4056_paired_comparison',
            dict(ids=query['ids'],truth=y,baseline=baseline,prediction=prediction,raw=raw,retained=retained),report)
        report.update(execution_status='complete_original4056_conditional_mean78_CPU_evaluated',
            original_class_gates=gates,baseline_class_gates=oldg,
            EffectDelta=dict(verdict=direction,correct_count_delta=delta,gain_loss=gainloss,
                same_original_IDs_and_order=True,accepted_baseline_replaced=False),
            known_correct_loss={name:gainloss[name]['loss'] for name in ('BEN','KNA')},
            known_loss0_passed=not any(gainloss[name]['loss'] for name in ('BEN','KNA')),
            all_three_integer99_passed=all(node['passed'] for node in gates.values()),
            original_rows=4056, unique_density_rows=4056, original_predictedUNA_preserved=int((baseline==2).sum()),
            raw_candidates=int(raw.sum()),retained_candidates=int(retained.sum()),
            newly_added_UNA=int(np.sum((baseline!=2)&(prediction==2))),
            current_wall_is_training_time=False, unknown_performance_measured=True,
            reused_maskaux_actual_training_seconds=files.js(reg['producer_report'],pins)['training_seconds'])
        files.require(trained.core.output_io.state_digest(net) == state, 'masked model unchanged after inference')
        for bound,wanted in pins.items():
            files.require(files.item(bound)['sha256'] == wanted, 'pinned input and output preserved')
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error))
        raise
    finally:
        after = trained.core.restore_runtime_flags(before)
        report['runtime_restored'] = after == before
        report['input_sha256'] = pins
        report['wall_seconds'] = time.perf_counter()-began
        files.write(out/'report.json',report)
    return files.item(out/'report.json')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=('freeze','current'),required=True)
    parser.add_argument('--registry')
    parser.add_argument('--registry-sha256')
    args = parser.parse_args()
    print(json.dumps(freeze() if args.phase == 'freeze' else current(args.registry,args.registry_sha256)))
