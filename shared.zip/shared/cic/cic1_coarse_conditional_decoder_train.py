"""One frozen genuine-knownFIT continuation of the prepared conditional decoder."""
from __future__ import annotations
import argparse
from collections import Counter
import io
import json
from pathlib import Path
import sys
import time
import types
import numpy as np
import torch
from torch import nn
from . import cic1_coarse_conditional_masked_decoder_architecture_v65 as architecture
from . import cic1_known6000_student_signcells78_v60 as parent

ROOT,files,core,helpers=parent.ROOT,parent.files,parent.core,parent.helpers
MODULE='paper_open_set.cic1_coarse_conditional_decoder_train_v65'
BASE=ROOT/'data/external_dev/processed/cic1_coarse_conditional_decoder_train_20261011_v65'
REGDIR=ROOT/'tmp/cic1_coarse_conditional_decoder_train_20261011_v65'

def recipe():
    value=architecture.fixed_recipe()
    for key in ('training_started','weights_loaded_in_preparation','actual_V65_training_seconds'):value.pop(key)
    value.update(schema_version='CIC1-V65-knownFIT6000-BENKNA-conditional-decoder-final30',
        inference_roles='posttraining neural inference CPUfloat32 fixed512; trainer performs no posttraining neural forward')
    return value

def source_closure(*initial):
    pending=list(initial);seen={}
    while pending:
        module=pending.pop();name=module.__name__
        if name=='__main__' and Path(module.__file__).resolve().parent==ROOT/'paper_open_set':name='paper_open_set.'+Path(module.__file__).stem
        if not name.startswith('paper_open_set.') or name in seen:continue
        p=Path(module.__file__).resolve();files.require(p.is_relative_to(ROOT),'local closure source')
        seen[name]=files.item(p)
        for value in vars(module).values():
            if isinstance(value,types.ModuleType):target=value
            else:target=sys.modules.get(getattr(value,'__module__',''))
            if target is not None and target.__name__.startswith('paper_open_set.'):pending.append(target)
    return seen

def freeze():
    from . import cic1_coarse_conditional_decoder_geometry110_v65 as evaluator
    pins={};producer_ref=files.item(parent.BASE/'report.json');producer=files.js(producer_ref,pins);r=files.js(producer['registry'],pins)
    files.require(producer['policy']==parent.recipe() and producer['epochs_completed']==30 and producer['unknown_values_opened'] is False,'actual V60 fixedfinal30 source')
    assets=dict(native=r['assets']['native'],native_units=r['assets']['units'],warm_model=producer['files']['model'])
    closure=source_closure(sys.modules[__name__],architecture,parent,evaluator,evaluator.learned)
    for a in (*assets.values(),*closure.values()):files.read(a,pins)
    files.require(not BASE.exists() and not REGDIR.exists(),'fresh conditional FIT trainer')
    REGDIR.mkdir(parents=True,exist_ok=False)
    return files.write(REGDIR/'registry_before_conditional_knownFIT_training.json',dict(policy=recipe(),assets=assets,sources=closure,parent_report=producer_ref,
        field_map=r['field_map'],field_map_sha256=r['field_map_sha256'],warm_model_state_sha256=producer['model_state_sha256'],
        outputs=str(BASE),input_sha256=pins,unknown_numeric_decodes=0,known_query_numeric_decodes=0))

def warm_net(reg,pins,device):
    saved=torch.load(io.BytesIO(files.read(reg['assets']['warm_model'],pins)),map_location='cpu',weights_only=True)
    fmap=core.field_map_from_state(reg['field_map'])
    files.require(saved['field_map']==reg['field_map'] and saved['field_map_sha256']==reg['field_map_sha256']==fmap.file_sha256,'exact canonical original78 map')
    original=parent.StudentMaskedMHFD(core.ExpandedWholeFieldMaskedMHFD(fmap,9)).cpu();original.load_state_dict(saved['state_dict'],strict=True)
    files.require(core.output_io.state_digest(original)==reg['warm_model_state_sha256'],'exact whole V60 warm tensor digest')
    net=architecture.CoarseConditionalMaskedMHFD(core.ExpandedWholeFieldMaskedMHFD(fmap,9));proof=net.initialize_from_actual_V60(saved)
    files.require(all(torch.equal(net.backbone.state_dict()[key],value) for key,value in original.backbone.state_dict().items()),'all backbone tensors warm copied exact')
    files.require(bool((net.mean_decoder[0].weight[:,32:]==0).all()) and bool((net.variance_decoder[0].weight[:,32:]==0).all()),'new context weights exactly zero initialized')
    return net.to(device),proof

def train(path,sha):
    pins={};registry=dict(path=str(Path(path).resolve()),sha256=sha);reg=files.js(registry,pins)
    files.require(reg['policy']==recipe() and reg['sources'][MODULE]==files.item(__file__),'exact frozen training policy')
    for a in reg['sources'].values():files.read(a,pins)
    BASE.mkdir(parents=True,exist_ok=False);before=core.capture_runtime_flags();started=time.perf_counter()
    report=dict(policy=recipe(),registry=registry,files={},training_runs=0,optimizer_steps=0,epochs_completed=0,unknown_values_opened=False,known_query_numeric_decodes=0,unknown_truth_decodes=0,
        posttraining_neural_forward_batches=0,posttraining_neural_forward_seconds=0.,accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        prep=time.perf_counter();raw=core.previous.archive(reg['assets']['native'],('FIT_native78','FIT_ids','FIT_y_fine','FIT_y_coarse'),pins)
        units=np.asarray(files.js(reg['assets']['native_units'],pins)['native78']);x=((np.sign(raw['FIT_native78'])*np.log1p(np.abs(raw['FIT_native78'])))/units).astype(np.float32)
        counts=Counter(raw['FIT_y_fine'].tolist());files.require(x.shape==(6000,78) and len(np.unique(raw['FIT_ids']))==6000 and set(counts)==set(range(9)) and min(counts.values())>=20 and np.isfinite(x).all(),'all genuine6000 knownFIT fine support20')
        core.previous.save(BASE,'actual_knownFIT6000_before_conditional_optimizer',dict(features=x,ids=raw['FIT_ids'],fine=raw['FIT_y_fine'],coarse=raw['FIT_y_coarse']),report)
        torch.set_num_threads(4);helpers.network.set_seed(20261011);device=torch.device('cuda' if torch.cuda.is_available() else 'cpu');net,proof=warm_net(reg,pins,device)
        report.update(initial_state_sha256=core.output_io.state_digest(net),warm_initialization=proof,device=str(device))
        opt=torch.optim.AdamW([p for p in net.parameters() if p.requires_grad],lr=.001,weight_decay=.0002);sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=30,eta_min=.0001);scaler=torch.amp.GradScaler('cuda',enabled=device.type=='cuda')
        cells,manifest=parent.make_cells(raw['FIT_native78'],raw['FIT_y_fine']);report['files']['native_sign_cells']=files.write(BASE/'alltruefine_all78_original_signcells_before_training.json',manifest)
        report['FIT_preparation_seconds']=time.perf_counter()-prep;history=[];seen_original=np.zeros(6000,bool);began=time.perf_counter();report['training_runs']=1
        frozen_old_mean={k:v.detach().cpu().clone() for k,v in net.backbone.decoder.state_dict().items()}
        for epoch in range(1,31):
            net.train();indices,fields,draw=parent.sample_signcells(cells,epoch-1);seen_original[indices]=True
            core.previous.save(BASE,'actual_FIT_draw_indices_masked_fields_epoch'+str(epoch),dict(indices=indices,fields=fields,decoder_truecoarse=raw['FIT_y_coarse'][indices]),report)
            report['files']['draws_epoch'+str(epoch)]=files.write(BASE/('draws_epoch'+str(epoch)+'.json'),draw)
            presented=np.bincount(raw['FIT_y_fine'][indices],minlength=9);files.require(np.array_equal(presented,np.array([3000]+[375]*8)),'allfixed6000 actual optimization draws, everyfine>=20')
            sums={k:0. for k in ('loss','coarse_loss','fine_loss','masked_loss')};seen=0
            for first in range(0,6000,128):
                selected=indices[first:first+128];xb=torch.from_numpy(x[selected].copy()).to(device);cb=torch.from_numpy(raw['FIT_y_coarse'][selected].copy()).to(device);fb=torch.from_numpy(raw['FIT_y_fine'][selected].copy()).to(device);field=torch.from_numpy(fields[first:first+len(selected)].copy()).to(device)
                opt.zero_grad(set_to_none=True)
                with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=device.type=='cuda'):values=architecture.masked_objective(net,xb,cb,fb,field)
                files.require(all(bool(torch.isfinite(v)) for v in values.values()),'finite fixed conditional masked objective')
                scaler.scale(values['loss']).backward();scaler.unscale_(opt);nn.utils.clip_grad_norm_([p for p in net.parameters() if p.requires_grad],5.);scaler.step(opt);scaler.update();report['optimizer_steps']+=1;seen+=len(selected)
                for key in sums:sums[key]+=float(values[key].detach())*len(selected)
            sched.step();history.append(dict(epoch=epoch,optimizer_draws=seen,**{k:v/seen for k,v in sums.items()}));core.save_epoch_history(BASE,history,epoch,report)
            if epoch==1 or epoch%10==0:print(f'[CIC1 conditional decoder] epoch={epoch}/30 loss={sums["loss"]/seen:.6f} elapsed={time.perf_counter()-began:.1f}s',flush=True)
        report.update(training_seconds=time.perf_counter()-began,epochs_completed=30,actual_source_FINE_support=dict(counts),actual_presented_unique_FINE_rows={str(f):int(np.sum(seen_original&(raw['FIT_y_fine']==f))) for f in range(9)})
        files.require(min(report['actual_presented_unique_FINE_rows'].values())>=20,'atleast20 real source rows of everyknown family presented in training')
        files.require(all(torch.equal(v,net.backbone.decoder.state_dict()[k].detach().cpu()) for k,v in frozen_old_mean.items()),'unused original mean frozen throughout optimization')
        state=core.output_io.state_digest(net);p=BASE/'coarse_conditional_Student3_full78_final30.pt'
        with p.open('xb') as f:torch.save(dict(state_dict={k:v.detach().cpu() for k,v in net.state_dict().items()},input_dim=78,fine_classes=9,field_map=reg['field_map'],field_map_sha256=reg['field_map_sha256'],model_state_sha256=state,training_policy=recipe(),warm_model=reg['assets']['warm_model'],variance_floor=architecture.FLOOR),f)
        report.update(model_state_sha256=state,execution_status='genuine_knownFIT_conditional_decoder_final30_completed',original_primary_classifier_unchanged=True);report['files']['model']=files.item(p)
        for p,wanted in pins.items():files.require(files.item(p)['sha256']==wanted,'frozen closure/source/warm/input bytes')
    except Exception as error:report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        after=core.restore_runtime_flags(before);report.update(runtime_restoration=dict(before=before,after=after,all_flags_restored=before==after),wall_seconds=time.perf_counter()-started,input_sha256=pins);files.write(BASE/'report.json',report)
    return files.item(BASE/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','train'),required=True)
    for name in ('registry','registry-sha256'):p.add_argument('--'+name)
    a=p.parse_args();print(json.dumps(freeze() if a.phase=='freeze' else train(a.registry,a.registry_sha256)))
