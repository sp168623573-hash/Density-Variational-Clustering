"""V994 CIC2 native78+old158, complete817 parent; no NN work or implicit data reads."""
from pathlib import Path
import hashlib,importlib.util,io,json,sys
import numpy as np
H=Path(__file__).resolve().parent
MANIFEST=H/'CIC2_V994_INPUT_MANIFEST.json'
def require(ok,message):
    if not bool(ok):raise ValueError(message)
def descriptor(p):
    p=Path(p).resolve(strict=True);return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def raw(d):
    b=Path(d['path']).read_bytes();require(hashlib.sha256(b).hexdigest()==d['sha256'],'owned input bytes');return b
def js(d):return json.loads(raw(d).decode('utf-8-sig'))
def manifest():return json.loads(MANIFEST.read_text(encoding='utf-8'))
def arrays(d,keys):
    with np.load(io.BytesIO(raw(d)),allow_pickle=False)as z:return{k:z[k]for k in keys}
def module(d,tag):
    raw(d);s=importlib.util.spec_from_file_location(tag+'_'+d['sha256'],d['path']);m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m);return m
def adapter():return module(manifest()['old_adapter'],'V994_own_CIC2_frozenadapter')
def load_source():
    m=manifest();a=adapter();f=a.load_fit();t,s=f['training'],f['source'];ix=np.asarray(t['optimizer_indices']);native=s['x'].astype(np.float64);z=np.asarray(s['old_features'],np.float64)
    require(native.shape==(5987,78)and z.shape==(5987,158)and np.array_equal(native,t['x'].astype(np.float64)),'same genuine sourceencoded78 and sourceowned full158')
    require(np.array_equal(s['fine'],t['fine'])and len(np.unique(s['ids']))==5987 and len(np.unique(s['groups']))==5987,'source genuineIDs/groups and oldfine map unchanged')
    require(ix.shape==(6000,)and ix.dtype.kind in'iu'and np.all((ix>=0)&(ix<5987))and np.bincount(ix,minlength=5987).min()>=1,'original logical6000 arbitrary parent order must cover allgenuine once')
    require(np.bincount(s['fine'][ix],minlength=9).min()>=20,'FIT-only Heart copies/family20, no independent claims')
    X=np.concatenate([native,z],axis=1)
    return dict(ids=s['ids'],groups=s['groups'],fine=s['fine'],native=native,Z158=z,X=X,
                logical_X=X[ix],logical_fine=s['fine'][ix],logical_groups=s['groups'][ix],optimizer_indices=ix,
                field_columns=[g['selected_columns']for g in js(m['original_fieldmap'])['groups']],
                source_trace=dict(f['trace'],actual_optimizer_indices_C_order_sha256=hashlib.sha256(ix.tobytes()).hexdigest(),actual_optimizer_order_preserved=True,originalfineclasscode_unchanged=True))
def load_role(role):
    m=manifest();require(role in('CAL','CP','current'),'whole original role');q=adapter().load_role(role)
    parent=arrays(m['roles'][role]['parent817'],('ids','prediction'));seal=js(m['roles'][role]['parent817_seal'])
    require(seal['prediction']==m['roles'][role]['parent817']and seal['query_truth_used']is False,'whole817 parent sealed before labels')
    require(np.array_equal(parent['ids'],q['ids'])and np.array_equal(parent['prediction'],q['parent_prediction']),'complete parent817 exact role order, no metric splice')
    native=q['x'].astype(np.float64);z=np.asarray(q['old_features'],np.float64)
    require(native.shape==(len(q['ids']),78)and z.shape==(len(q['ids']),158),'same existing fullrole old geometry/native schema')
    return dict(ids=q['ids'],groups=q['groups'],native=native,Z158=z,X=np.concatenate([native,z],axis=1),
                parent_prediction=parent['prediction'],role=role,needs_original_NN_readout=False)
def load_known_labels(role):
    require(role in('CAL','CP'),'real CAL/CP original882 only, no alias900/current truth API');return adapter().load_known_labels(role)
