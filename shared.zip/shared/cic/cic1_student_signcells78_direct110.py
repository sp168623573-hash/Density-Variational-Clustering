"""Direct full78 conditional StudentT3 candidate score; frozen V48 DVC.

All78 NLLs are retained without clipping, weighted equally, calibrated only
on all actual known CAL labels. Original classifier and2381 stay unchanged.
"""
from __future__ import annotations
import argparse
import io
import json
from pathlib import Path
import time
import numpy as np
import torch
from . import cic1_known6000_student_signcells78_v60 as trained
from . import cic1_mask78_clean110_v48 as prior

ROOT,files,context=prior.ROOT,prior.files,prior.context
BASE=ROOT/'data/external_dev/processed/cic1_student_signcells78_direct110_20261011_v60'
REGDIR=ROOT/'tmp/cic1_student_signcells78_direct110_20261011_v60'
PARENT_KNOWN=dict(path=str(prior.BASE/'known/report.json'),sha256='52b769aa554fe5f32ecbb17693469169b21d2eb01a8cde670185b58641acc10d')
PARENT_CURRENT=dict(path=str(ROOT/'data/external_dev/processed/cic1_empirical_Gaussian_fieldtail78_20261011_v59/current/report.json'),sha256='f0ab5a101712802c4da35b2f1db609368c7a153cb542ebf72f3383704c0cf414')


def policy():
    return dict(schema_version='CIC1-known-StudentT3-signcells78-directNLL-original110-DVC-v60',hypotheses=1,
        producer=trained.recipe(),score='unclipped mean78 actual field-masked StudentT3 .5log(variance/3)+2log1p(squared residual/variance), CPUfloat32 network and float64score',
        CAL='all900 actual known truecoarse labels finite99 once; every row retained, no oracle predictedfine rescore',
        query='original primary predictedcoarse; original predictedfine, native groups and allrows fixed',
        DVC='original successful V48 clean110 metric on ownraw OR prior2397 predictedUNA; same knee/SC/CH affinity/noise',
        merge='complete2397 predictedcopy plus ownraw AND ownDVCretained; historic799 protected',
        known_gate='BEN/KNA900 exact99 and previous-correct loss0 before4056 current values',
        NN_fit=0,metric_fit=0,units_fit=0,oldscore_replay=0,train_union_unique_rows=6000,optimizer_traffic_rows=6000,
        variance_floor=trained.VARIANCE_FLOOR,variance_floor_binary32=float(np.float32(trained.VARIANCE_FLOOR)),field_selection=False,query_parameter_fit=False,unknown_training=False,
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)


def freeze():
    pins={};pk=files.js(PARENT_KNOWN,pins);pc=files.js(PARENT_CURRENT,pins);pr=files.js(pk['registry'],pins);pc_reg=files.js(pc['registry'],pins)
    producer_ref=files.item(trained.BASE/'report.json');producer=files.js(producer_ref,pins)
    files.require(producer['epochs_completed']==30 and producer['policy']==trained.recipe() and producer['unknown_values_opened'] is False,'real fixed30 known StudentT3 producer')
    files.require(pk['known_gate_passed'] and pc['original_class_gates']['UNA']['correct']==2397,'preserved new2397 and900 known')
    assets=dict(model=producer['files']['model'],preserved799=pr['assets']['comparator'],native_known=pr['assets']['native_known'],native_units=pr['assets']['native_RMS'],
        original_known=pr['assets']['known110'],current_native=pr['assets']['current_native'],truth=pr['assets']['truth'],
        known110=pk['files']['coupled_MASK78_CLEAN110_known_before_metric'],current110=pc_reg['assets']['current110'],
        metric=pk['files']['metric'],known_baseline=pk['files']['complete_prediction_before_truth'],current_baseline=pc['files']['complete_prediction_before_truth'])
    for a in assets.values():files.read(a,pins)
    preserved={str(p):files.item(ROOT/p) for p in ('data/external_dev/processed/cic1_mask78_clean110_20261011_v48/current/report.json','data/external_dev/processed/cic1_gaussian_mask78_integer_DEV_exploration_20261011_v57/current/report.json')}
    for a in preserved.values():files.read(a,pins)
    sources={str(Path(m.__file__).resolve()):files.item(m.__file__) for m in (trained,trained.previous,trained.core,trained.core.mask_core,trained.core.output_io,prior,prior.learned,prior.geometry,prior.geometry.dvc,context,files)}
    sources[str(Path(__file__).resolve())]=files.item(__file__)
    for a in sources.values():files.read(a,pins)
    files.require(not BASE.exists() and not REGDIR.exists(),'fresh direct StudentT3 candidate outputs')
    REGDIR.mkdir(parents=True,exist_ok=False)
    return files.write(REGDIR/'registry_before_direct_StudentT3_knownCAL.json',dict(policy=policy(),assets=assets,sources=sources,
        preserved_version_reports=preserved,producer=producer_ref,producer_registry=producer['registry'],model_state_sha256=producer['model_state_sha256'],
        outputs={p:str(BASE/p) for p in ('known','current')},input_sha256=pins,current_numeric_decodes=0,current_truth_decodes=0))


def network(reg,pins):
    saved=torch.load(io.BytesIO(files.read(reg['assets']['model'],pins)),map_location='cpu',weights_only=True)
    files.require(saved['training_policy']==trained.recipe() and saved['input_dim']==78 and saved['fine_classes']==9
        and saved['variance_floor']==trained.VARIANCE_FLOOR and saved['new_keys']==list(trained.NEW_KEYS),'exact new full StudentT3 checkpoint signature')
    fmap=trained.core.field_map_from_state(saved['field_map'])
    files.require(fmap.file_sha256==saved['field_map_sha256'],'exact original78 field map')
    net=trained.StudentMaskedMHFD(trained.core.ExpandedWholeFieldMaskedMHFD(fmap,9)).cpu()
    net.load_state_dict(saved['state_dict'],strict=True);net.backbone._map_check();net.eval()
    files.require(trained.core.output_io.state_digest(net)==reg['model_state_sha256'],'exact every StudentT3 network tensor')
    return net


@torch.no_grad()
def score_all78(net,x,ids,role,out,report):
    x=np.ascontiguousarray(x,np.float32);field_nll=np.empty((len(x),78),np.float64)
    began=time.perf_counter()
    trained.core.previous.save(out,role+'_actual_native_inputs_before_StudentT3_forward',dict(ids=ids,features=x),report)
    for field in range(78):
        for first in range(0,len(x),1024):
            stop=min(first+1024,len(x));returned=net.forward_masked(torch.from_numpy(x[first:stop].copy()),torch.full((stop-first,),field,dtype=torch.int64))
            live={k:v.detach().cpu().numpy().copy() if v.dtype==torch.bool else v.detach().float().cpu().numpy().copy() for k,v in returned.items()}
            trained.core.previous.save(out,role+'_field'+str(field)+'_batch'+str(first)+'_actual_StudentT3_raw_before_guard',live,report)
            mu=live['reconstruction'][:,field].astype(np.float64);variance=live['variance'][:,field].astype(np.float64)
            value=.5*np.log(variance/3.)+2.*np.log1p(np.square(mu-x[first:stop,field].astype(np.float64))/variance)
            trained.core.previous.save(out,role+'_field'+str(field)+'_batch'+str(first)+'_actual_fieldNLL_before_guard',dict(ids=ids[first:stop],mu=mu,variance=variance,NLL=value),report)
            report['masked_forward_batches']+=1
            files.require(np.isfinite(value).all() and np.isfinite(variance).all() and np.all(variance>=float(np.float32(trained.VARIANCE_FLOOR))),'finite true StudentT3 likelihood, no NLL clipping')
            field_nll[first:stop,field]=value
        if (field+1)%13==0:print(f'[CIC1 StudentT3 direct] role={role} fields={field+1}/78 elapsed={time.perf_counter()-began:.1f}s',flush=True)
    score=field_nll.mean(axis=1)
    trained.core.previous.save(out,role+'_all78_NLL_and_mean_before_CAL_or_DVC',dict(ids=ids,field_NLL=field_nll,score=score),report)
    report['role_masked_inference_seconds'][role]=time.perf_counter()-began
    report['role_score_range'][role]=dict(min=float(score.min()),max=float(score.max()),negative_count=int((score<0).sum()))
    return score


def run(phase,path,sha,known_path=None,known_sha=None):
    pins={};registry=dict(path=str(Path(path).resolve()),sha256=sha);reg=files.js(registry,pins)
    files.require(reg['policy']==policy() and reg['sources'][str(Path(__file__).resolve())]==files.item(__file__),'own frozen direct StudentT3 recipe')
    for a in reg['sources'].values():files.read(a,pins)
    if phase=='current':
        control=files.js(dict(path=str(Path(known_path).resolve()),sha256=known_sha),pins)
        files.require(control['registry']==registry and control['prediction_sealed'] and control['known_gate_passed']
            and control['known_correct_loss']==dict(BEN=0,KNA=0),'all known900 exact99 and zero loss before current')
    out=Path(reg['outputs'][phase]);out.mkdir(parents=True,exist_ok=False)
    began,threads=time.perf_counter(),torch.get_num_threads()
    report=dict(policy=policy(),registry=registry,phase=phase,files={},NN_fit=0,metric_fit=0,units_fit=0,CAL_fit=0,DVC_calls=0,
        masked_forward_batches=0,role_masked_inference_seconds={},role_score_range={},prediction_sealed=False,truth_opened=False,
        current_truth_used_for_tuning=False,accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        torch.set_num_threads(4);net=network(reg,pins);units=np.asarray(files.js(reg['assets']['native_units'],pins)['native78'])
        if phase=='known':
            native=context.selected(reg['assets']['native_known'],tuple(r+'_'+k for r in ('CAL','CP') for k in ('ids','native78'))+('CAL_y_coarse',),pins)
            fields=context.selected(reg['assets']['known110'],tuple(r+'_'+k for r in ('CAL','CP') for k in ('ids','groups','Z110','stage1','predicted_fine')),pins)
            scores={}
            for role in ('CAL','CP'):
                x=prior.previous.raw_source.normalize(native[role+'_native78'],units).astype(np.float32)
                files.require(np.array_equal(native[role+'_ids'],fields[role+'_ids']) and np.array_equal(x,fields[role+'_Z110'][:,:78].astype(np.float32)),'same original '+role+' signedlog inputs andIDs')
                if role=='CP':continue
                scores[role]=score_all78(net,x,native[role+'_ids'],role,out,report)
            cut=prior.geometry.dvc.calibrate_known_cutoffs(scores['CAL'],native['CAL_y_coarse']);report['CAL_fit']=1
            report['files']['cutoffs']=files.write(out/'true_known_CAL900_finite99_before_CP.json',dict(cutoffs=cut,true_coarse_labels_used=True,all900_rows_retained=True,query_parameters_fit=False))
            x=prior.previous.raw_source.normalize(native['CP_native78'],units).astype(np.float32)
            score=score_all78(net,x,native['CP_ids'],'CP',out,report);query=context.role_query(fields,'CP')
            old=context.selected(reg['assets']['known_baseline'],('ids','prediction'),pins)
        else:
            cut=files.js(control['files']['cutoffs'],pins)['cutoffs']
            native=context.selected(reg['assets']['current_native'],('ids','native78'),pins)
            query=context.selected(reg['assets']['current110'],('ids','groups','Z110','stage1','predicted_fine'),pins)
            x=prior.previous.raw_source.normalize(native['native78'],units).astype(np.float32)
            files.require(len(native['ids'])==4056 and np.array_equal(native['ids'],query['ids']) and np.array_equal(x,query['Z110'][:,:78].astype(np.float32)),'same full4056 original inputs/IDs')
            score=score_all78(net,x,native['ids'],'current4056',out,report)
            old=context.selected(reg['assets']['current_baseline'],('ids','prediction'),pins)
        files.require(np.array_equal(old['ids'],query['ids']),'same original comparison IDs')
        baseline=old['prediction'];raw=prior.geometry.dvc.candidate_mask(score,query['stage1'],cut);density=raw|(baseline==2)
        trained.core.previous.save(out,'StudentT3_scores_raw_density_before_DVC',dict(ids=query['ids'],score=score,stage1=query['stage1'],raw=raw,density=density),report)
        metric=prior.learned.PaperVariationalPairMetric.from_state(files.js(reg['assets']['metric'],pins)['metric_payload'])
        route=prior.geometry.dvc.route_current_candidates(metric,query['Z110'],density,seed=20261009);report['DVC_calls']=1
        trained.core.previous.save(out,'original110_StudentT3_DVC_before_truth',{k:v for k,v in route.items() if k!='manifest'},report)
        report['files']['DVC_manifest']=files.write(out/'original110_StudentT3_DVC_manifest_before_truth.json',route['manifest'])
        prediction=baseline.copy();prediction[raw&route['retained']]=2
        pa=trained.core.previous.save(out,'complete_prediction_before_truth',dict(ids=query['ids'],prediction=prediction,baseline=baseline,raw=raw,density=density,retained=route['retained']),report)
        report['files']['prediction_seal']=files.write(out/'StudentT3_prediction_seal_before_truth.json',dict(prediction=pa,truth_opened=False,registry=registry));report['prediction_sealed']=True
        if phase=='known':y=context.selected(reg['assets']['original_known'],('CP_truth',),pins)['CP_truth']
        else:
            truth=context.selected(reg['assets']['truth'],('ids','truth'),pins);files.require(np.array_equal(truth['ids'],query['ids']),'currenttruth sameIDs onlyafterseal');y=truth['truth']
        report['truth_opened']=True
        gates=context.integer_gates(y,prediction,known_only=phase=='known');base=context.integer_gates(y,baseline,known_only=phase=='known')
        gl={name:dict(gain=int(np.sum((y==c)&(baseline!=c)&(prediction==c))),loss=int(np.sum((y==c)&(baseline==c)&(prediction!=c)))) for c,name in enumerate(gates)}
        delta={name:a['gain']-a['loss'] for name,a in gl.items()};pos,neg=any(v>0 for v in delta.values()),any(v<0 for v in delta.values());loss={name:gl[name]['loss'] for name in ('BEN','KNA')}
        trained.core.previous.save(out,'postseal_paired_comparison',dict(ids=query['ids'],truth=y,prediction=prediction,baseline=baseline,raw=raw,density=density,retained=route['retained']),report)
        report.update(execution_status='StudentT3_direct78_'+phase+'_evaluated',original_class_gates=gates,baseline_class_gates=base,known_correct_loss=loss,
            known_integer_gates_passed=all(gates[c]['passed'] for c in ('BEN','KNA')),known_gate_passed=all(gates[c]['passed'] and loss[c]==0 for c in ('BEN','KNA')),
            all_three_integer99_passed=phase=='current' and all(g['passed'] for g in gates.values()),
            EffectDelta=dict(verdict='MIXED' if pos and neg else 'UP' if pos else 'DOWN' if neg else 'UNCHANGED',correct_count_delta=delta,gain_loss=gl,same_original_IDs_and_order=True),
            raw_by_true_class={name:int(np.sum((y==c)&raw)) for c,name in enumerate(gates)},raw_candidates=int(raw.sum()),density_candidates=int(density.sum()),new_retained_candidates=int(np.sum(raw&route['retained'])))
        files.require(trained.core.output_io.state_digest(net)==reg['model_state_sha256'],'same StudentT3 tensors throughout masked scoring')
        for p,wanted in pins.items():files.require(files.item(p)['sha256']==wanted,'frozen original data/weights/sources')
    except Exception as error:report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        torch.set_num_threads(threads);report.update(input_sha256=pins,threads_restored=torch.get_num_threads()==threads,wall_seconds=time.perf_counter()-began)
        files.write(out/'report.json',report)
    return files.item(out/'report.json')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for name in ('registry','registry-sha256','known-report','known-sha256'):parser.add_argument('--'+name)
    args=parser.parse_args();print(json.dumps(freeze() if args.phase=='freeze' else run(args.phase,args.registry,args.registry_sha256,args.known_report,args.known_sha256)))
