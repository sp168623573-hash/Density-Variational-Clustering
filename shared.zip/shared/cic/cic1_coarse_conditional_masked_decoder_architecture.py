"""Preparation only: genuine BEN/KNA-conditioned full78 Student3 decoder.

No training entry point or automatic numerical execution is provided. The
shared MHFD encoder and known heads warm-load the genuine V60 checkpoint.
Two new condition-input columns learn inside mean/variance decoder heads.
Original primary decisions remain external and frozen.
"""
from __future__ import annotations
import torch
from torch import nn
from torch.nn import functional as F
from . import cic1_known6000_student_signcells78_v60 as parent

FLOOR=1e-4

def fixed_recipe():
    return dict(schema_version='CIC1-V65-proposed-known6000-truecoarse-conditioned-all78-Student3-final30',hypotheses=1,
        warm='genuine V60 final30 all78 shared MHFD encoder/coarse2/fine9 and unconditional mean/variance tensors copied; old files unchanged',
        mean='maskedembedding32 + BEN/KNA onehot2 -> Linear34x64 -> GELU -> Linear64x78',
        variance='same maskedembedding32 + BEN/KNA onehot2 -> Linear34x64 -> SiLU -> Linear64x78 -> softplusfloat32 +1e-4',
        initialization='first32 columns and remaining tensors copied exactly from corresponding V60 mean/variance head; two new condition columns exactlyzero; initial predictions match V60 regardless of condition',
        legacy_decoder='original unconditional mean decoder remains frozen and unused for conditional prediction; no unconditional variance head substitution',
        loss='.1 clean coarseCE+.035 clean fineCE(smoothing.01)+1 masked-only Student3(.5log(var/3)+2log1p(residual2/var))',
        FIT_condition='only genuine knownFIT truecoarse0/1; no truefine is a decoder input',
        evaluation_condition='original frozen primary stage1 predictedcoarse for every CAL/CP/current masked decoder view; no truth-driven branch selection',
        FIT_sampling='reuse exact V60 truefine/field/native-sign-cell fixed law;6000 optimizer views per epoch, all78 fields and existing sourcecells',
        seed=20261011,epochs=30,batch_size=128,optimizer='AdamW .001 wd.0002 cosine30 min.0001 clip5',
        checkpoint='fixed final30; no heldout epoch selection',optimizer_traffic_rows=6000,genuine_source_rows=6000,
        learned_geometry='fresh dedicated110 allnative78 plus thisnewclean32, own genuineFIT RMS and same paperEq9/10 fixed80 recipe',
        candidate='unclipped equally-weighted mean78 actual conditional Student3 NLL; trueknown CAL900 finite99 once, query cutoff original stage1',
        DVC='newmatching110 metric on ownraw OR preserved2397 predictedUNA, original density/affinity/reconstruction/secondarynoise',
        deployment='all actual inference CPUfloat32/eval fixed512, per-role neural forward/statistic/gradient timers distinct',
        old799_2381_2396exploratory_2397_preserved=True,strict_zero_loss_gate=True,no_current_exploration=True,
        no_parameter_grid=True,no_unknown_fit=True,no_training_time_limit_in_code=True,
        training_started=False,weights_loaded_in_preparation=False,actual_V65_training_seconds=None,
        status='FAIL_TARGET99',published=False,final_test_executed=False)

class CoarseConditionalMaskedMHFD(nn.Module):
    def __init__(self,backbone):
        super().__init__();self.backbone=backbone
        self.mean_decoder=nn.Sequential(nn.Linear(34,64),nn.GELU(),nn.Linear(64,78))
        self.variance_decoder=nn.Sequential(nn.Linear(34,64),nn.SiLU(),nn.Linear(64,78))
        # Preserves original warm checkpoint structure without training an
        # unused unconditional decoder beside the actual conditional heads.
        self.backbone.decoder.requires_grad_(False)

    def _conditional(self,result,coarse):
        embedding=result['embedding']
        if coarse.dtype!=torch.int64 or coarse.shape!=(len(embedding),) or not bool(torch.isin(coarse,torch.tensor((0,1),device=coarse.device)).all()):
            raise ValueError('explicit knowncoarse or frozen-primary predictedcoarse0/1 required')
        inputs=torch.cat((embedding,F.one_hot(coarse,num_classes=2).to(embedding.dtype)),dim=1)
        result['reconstruction']=self.mean_decoder(inputs)
        raw=self.variance_decoder(inputs)
        result.update(variance_raw=raw,variance=F.softplus(raw.float())+FLOOR,decoder_condition=coarse)
        return result

    def forward(self,x,coarse):return self._conditional(self.backbone(x),coarse)

    def forward_masked(self,x,fields,coarse):return self._conditional(self.backbone.forward_masked(x,fields),coarse)

    @torch.no_grad()
    def initialize_from_actual_V60(self,saved):
        if saved['training_policy']!=parent.recipe() or saved['input_dim']!=78 or saved['fine_classes']!=9 or saved['variance_floor']!=FLOOR:
            raise ValueError('actual V60 all78 Student3 producer required')
        weights=saved['state_dict'];old={k.removeprefix('backbone.'):v for k,v in weights.items() if k.startswith('backbone.')}
        self.backbone.load_state_dict(old,strict=True)
        for target,prefix in ((self.mean_decoder,'backbone.decoder'),(self.variance_decoder,'variance_head')):
            target[0].weight.zero_();target[0].weight[:,:32].copy_(weights[prefix+'.0.weight'])
            target[0].bias.copy_(weights[prefix+'.0.bias'])
            target[2].weight.copy_(weights[prefix+'.2.weight']);target[2].bias.copy_(weights[prefix+'.2.bias'])
        self.backbone.decoder.requires_grad_(False)
        return dict(original_backbone_strict_loaded=True,conditional_mean_first32_warm_copied=True,
            conditional_variance_first32_warm_copied=True,new_condition_columns_zero=True,
            optimizer_steps=0,NN_forward_calls=0)

def masked_objective(net,x,true_coarse,true_fine,field):
    if not torch.equal(true_coarse==0,true_fine==0):raise ValueError('knownFIT truecoarse and fine hierarchy')
    clean=net(x,true_coarse);masked=net.forward_masked(x,field,true_coarse)
    hidden=masked['masked_columns'];mu=masked['reconstruction'].float();variance=masked['variance']
    NLL=.5*torch.log(variance/3.)+2.*torch.log1p((mu-x.detach()).square()/variance)
    if not bool(torch.isfinite(NLL).all()):raise ValueError('proper finite unclipped Student3 conditional NLL')
    likelihood=((NLL*hidden).sum(dim=1)/hidden.sum(dim=1)).mean()
    coarse=F.cross_entropy(clean['coarse_logits'],true_coarse)
    fine=F.cross_entropy(clean['fine_logits'],true_fine,label_smoothing=.01)
    return dict(loss=.1*coarse+.035*fine+likelihood,coarse_loss=coarse,fine_loss=fine,masked_loss=likelihood)
