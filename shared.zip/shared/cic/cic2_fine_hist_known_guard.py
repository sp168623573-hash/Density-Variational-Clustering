"""Conservative known-fine support for the unchanged CIC2 primary classifier.

One CP BEN maximum for each auxiliary known-attack posterior, followed by
full CAL verification. Rule accepts only arrays of classifier outputs; no
record IDs or truth are decision inputs. No unknown phase is provided.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import numpy as np
from . import cic2_shared_coverage_fine_hist_assistant_v1 as fine

h = fine.helpers
ROOT = fine.ROOT
OUT = ROOT / "data/external_dev/processed/cic2_fine_hist_known_guard_20261010_v1"
REGISTRY_OUT = ROOT / "tmp/cic2_fine_hist_known_guard_20261010_v1"
PARENT = dict(path=str(fine.OUT / "report.json"), sha256="8360fff6a9fa17eb540e3a1b0afa5f898466a88761b805bde6d460ab8fcc8417")
PARENT_SHA = "bd4e63f07ec70e6c91eba56c7ab5212633a8be78b473a4021730444012dcbb74"


def policy():
    return dict(schema_version="CIC2-fine9-HGB-known-BEN-envelope-guard-v1", hypotheses=1,
        primary="unchanged strong signedlog MHFD and original quarter fine forest, original CP threshold",
        auxiliary="trained known-fine9 HGB200, fixed5987+13copy shared FIT",
        CP_rule="for each attack fine1..8 use maximum posterior over all CP BEN originals; strict greater; finite minimumBEN20",
        decision="retain primary KNA; primary BEN becomes KNA only when auxiliary argmax is attack fine and posterior exceeds its CP BEN envelope",
        classifier_output_arrays_only=True, identity_or_truth_decision_input=False,
        previously_observed_CP_CAL=True, independent_final_claimed=False,
        new_threshold_or_source_selection_from_unknown=False, no_unknown_entry=True,
        accepted_baseline_replaced=False,status="FAIL_TARGET99",published=False,final_test_executed=False)


def bindings():
    h.require(h.sha(fine.__file__)==PARENT_SHA,"preserved_fine_HGB_source")
    return {str(Path(p).resolve()):h.sha(p) for p in (__file__,fine.__file__,h.__file__)}


def check_fine(probabilities):
    values=np.asarray(probabilities)
    h.require(values.ndim==2 and values.shape[1]==9 and np.issubdtype(values.dtype,np.floating)
        and np.isfinite(values).all() and np.all((values>=0)&(values<=1))
        and np.allclose(values.sum(axis=1),1,rtol=0,atol=1e-12),"actual_fine9_posterior_domain")
    return values


def calibrate(probabilities,cp_truth):
    values=check_fine(probabilities);truth=np.asarray(cp_truth)
    h.require(truth.shape==(len(values),) and truth.dtype==np.int64
        and set(np.unique(truth))=={0,1} and int(np.sum(truth==0))>=20,"known_CP_BEN_envelope_support")
    return np.max(values[truth==0,1:],axis=0).astype(np.float64)


def correct_known(primary,probabilities,envelope):
    primary=np.asarray(primary);values=check_fine(probabilities);envelope=np.asarray(envelope)
    h.require(primary.shape==(len(values),) and primary.dtype==np.int64 and np.isin(primary,[0,1]).all()
        and envelope.shape==(8,) and np.isfinite(envelope).all() and np.all((envelope>=0)&(envelope<=1)),"known_classifier_output_and_CP_envelope")
    predicted_fine=np.argmax(values,axis=1)
    posterior=values[np.arange(len(values)),predicted_fine]
    cutoff=np.ones(len(values),np.float64)
    attack=predicted_fine>0
    cutoff[attack]=envelope[predicted_fine[attack]-1]
    admitted=(primary==0)&attack&(posterior>cutoff)
    result=primary.copy();result[admitted]=1
    h.require(np.array_equal(result[primary==1],primary[primary==1]),"all_primary_KNA_predictions_preserved")
    return result,admitted


def freeze():
    pins={};parent=h.read(PARENT,pins);reg=h.read(parent['registry'],pins)
    h.require(parent['execution_status']=='hist_fine9_native78_assistant_known_controls_evaluated'
        and parent['classifier_fit']==1 and parent['prediction_sealed'] and not parent['published']
        and not parent['final_test_executed'],'completed_fine_HGB_parent')
    assets=dict(CP=parent['files']['CP_original_probabilities_before_threshold'],CAL=parent['files']['CAL_original_probabilities_before_truth'])
    for role,asset in assets.items():
        headers=h.header_tools.npz_headers(h.checked(asset,pins))
        h.require(headers['hist_fine']['shape']==[882,9] and headers['ids']['shape']==[882],'actual_saved_fine9_header:'+role)
    for asset in (reg['native'],reg['strong_predictions'],parent['files']['fixed_known_predictions_before_CAL_truth_and_prior']):h.checked(asset,pins)
    sources=bindings()
    for p,sha in sources.items():h.checked(dict(path=p,sha256=sha),pins)
    h.require(not OUT.exists() and not REGISTRY_OUT.exists(),'fresh_known_guard_output')
    REGISTRY_OUT.mkdir(parents=True)
    return h.json_new(REGISTRY_OUT/'registry_before_CP_BEN_guard.json',dict(policy=policy(),sources=sources,parent=PARENT,
        assets=assets,native=reg['native'],strong=reg['strong_predictions'],fine_classifier=parent['files']['fixed_known_predictions_before_CAL_truth_and_prior'],
        input_sha256=pins,output=str(OUT),probabilities_opened=False,CP_CAL_truth_opened=False))


def run(path,sha):
    registry=dict(path=str(Path(path).resolve()),sha256=sha);pins={};started=time.perf_counter();stage='bind_registry'
    report=dict(policy=policy(),registry=registry,files={},model_fit=0,NN_forward=0,HGB_forward=0,score=0,DVC=0,
        CP_envelope_fit=0,CP_envelope_sealed=False,prediction_sealed=False,CAL_truth_opened=False,
        query_fit=0,unknown_reads=0,unknown_phase_allowed=False,accepted_baseline_replaced=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    h.require(not OUT.exists(),'fresh_guard_actual_output');OUT.mkdir(parents=True)
    try:
        reg=h.read(registry,pins);h.require(reg['policy']==policy() and reg['sources']==bindings() and reg['output']==str(OUT),'frozen_guard_recipe')
        for p,wanted in reg['input_sha256'].items():h.checked(dict(path=p,sha256=wanted),pins)
        stage='CP_BEN_envelope_before_CAL_probabilities'
        cp=fine.load(reg['assets']['CP'],('ids','hist_fine'),pins)
        cpmeta=fine.load(reg['native'],('CP_ids','CP_y_coarse','CP_reporting_indices'),pins)
        main=fine.load(reg['strong'],('CP_ids','CP_candidate','CAL_ids','CAL_candidate'),pins)
        h.require(np.array_equal(cp['ids'],cpmeta['CP_ids']) and np.array_equal(cp['ids'],main['CP_ids']),'same_CP_ID_order')
        envelope=calibrate(cp['hist_fine'],cpmeta['CP_y_coarse']);report['CP_envelope_fit']=1
        report['files']['envelope']=h.json_new(OUT/'known_CP_BEN_envelope_before_CAL.json',dict(
            envelope=envelope.tolist(),CP_BEN_support=int(np.sum(cpmeta['CP_y_coarse']==0)),source_role='CP_original882',
            CAL_probabilities_or_truth_used=False,threshold_sweep=False,rule='strict greater than per-fine CP BEN maximum'))
        report['CP_envelope_sealed']=True
        cppred,cpadded=correct_known(main['CP_candidate'],cp['hist_fine'],envelope)
        stage='CAL_output_before_complete_prediction_seal'
        cal=fine.load(reg['assets']['CAL'],('ids','hist_fine'),pins)
        h.require(np.array_equal(cal['ids'],main['CAL_ids']),'same_CAL_ID_order')
        calpred,caladded=correct_known(main['CAL_candidate'],cal['hist_fine'],envelope)
        values=dict(CP_ids=cp['ids'],CAL_ids=cal['ids'],CP_prediction=cppred,CAL_prediction=calpred,
                    CP_added=cpadded,CAL_added=caladded,CP_primary=main['CP_candidate'],CAL_primary=main['CAL_candidate'])
        report['files']['predictions']=h.npz_new(OUT/'both_known_guard_predictions_before_CAL_truth.npz',values,{})
        report['files']['prediction_seal']=h.json_new(OUT/'known_guard_prediction_seal_before_CAL_truth.json',dict(
            predictions=report['files']['predictions'],envelope=report['files']['envelope'],CAL_truth_used=False,
            rowID_or_labels_in_decision=False))
        report['prediction_sealed']=True
        stage='postseal_CAL_truth_and_paired_metrics'
        calmeta=fine.load(reg['native'],('CAL_ids','CAL_y_coarse','CAL_reporting_indices'),pins)
        report['CAL_truth_opened']=True
        h.require(np.array_equal(calmeta['CAL_ids'],cal['ids']),'postseal_CAL_metadata_order')
        priorfine=fine.load(reg['fine_classifier'],tuple(r+'_'+k for r in ('CP','CAL') for k in ('ids','prediction')),pins)
        gates,reporting,effects={}, {}, {}
        for role,meta,pred in (('CP',cpmeta,cppred),('CAL',calmeta,calpred)):
            y,idx=meta[role+'_y_coarse'],meta[role+'_reporting_indices']
            h.require(np.array_equal(meta[role+'_ids'],priorfine[role+'_ids']),'same_fine_diagnostic_IDs')
            gates[role],reporting[role]=h.gates(y,pred),h.gates(y[idx],pred[idx])
            effects[role]=dict(original_strong=h.paired(y,main[role+'_candidate'],pred),fine_half_blend=h.paired(y,priorfine[role+'_prediction'],pred))
            values[role+'_truth']=y
        report['files']['postseal_pair']=h.npz_new(OUT/'postseal_known_guard_paired_comparison.npz',values,{})
        for p,wanted in pins.items():h.require(h.sha(p)==wanted,'known_guard_input_unchanged:'+p)
        report.update(execution_status='known_fine_BEN_envelope_guard_evaluated',known_gates=gates,effective_reporting_gates=reporting,
            EffectDelta=effects,added_KNA_rows=dict(CP=int(cpadded.sum()),CAL=int(caladded.sum())),
            original_and_reporting_integer99_passed=all(g['passed'] for collection in (gates,reporting) for role in collection.values() for g in role.values()),
            paired_strong_correct_loss_free=all(e['original_strong']['loss']==0 for e in effects.values()),
            promotion_status='NOT_PROMOTED_WARM_KNOWN_DIAGNOSTIC',own_new_CAL_novelty_alignment_required_before_unknown=True)
    except Exception as error:
        report.update(execution_status='execution_failed',failed_stage=stage,error_type=type(error).__name__,error=str(error));raise
    finally:
        report.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);h.json_new(OUT/'report.json',report)
    return h.descriptor(OUT/'report.json')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','known'),required=True)
    p.add_argument('--registry');p.add_argument('--registry-sha256');a=p.parse_args()
    if a.phase=='known' and (not a.registry or not a.registry_sha256):p.error('known requires registry and SHA')
    print(json.dumps(freeze() if a.phase=='freeze' else run(a.registry,a.registry_sha256)))
