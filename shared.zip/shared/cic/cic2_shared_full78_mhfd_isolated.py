"""Fresh known-only MHFD representation with an isolated known-class supplement.

The original detector's unknown decisions and density membership stay fixed.
Only its remaining BEN decisions can receive new known-class evidence. This
is one frozen warm-development experiment, not an independent final test.
"""
from __future__ import annotations
import argparse
from collections import Counter
import json
from pathlib import Path
import time
import numpy as np
import torch
from . import cic2_class_guard_primary110_alignment_v2 as aligned
from . import cic2_live_guard_owned110_current_v1 as current
from . import model as network

ROOT, h, fine, guard = aligned.ROOT, aligned.h, aligned.fine, aligned.guard
OUT = ROOT/'data/external_dev/processed/cic2_shared_full78_mhfd_isolated_20261011_v48'
REG = ROOT/'tmp/target99_iteration_20261011_v48/CIC2_registry_before_new_MHFD_fit.json'
MATERIAL = dict(path=str(ROOT/'data/external_dev/processed/cic2_shared_coverage_FIT6000_20261010_v1/report.json'), sha256='82010b9b4c47834e9d5dd7ae27d5cd82b7c91a3f5be4c54b64de617f3b83ac06')
KNOWN = dict(path=str(aligned.OUT/'report.json'),sha256='f9284dc1ec4b816b1513cc67457aa8e8fa35e4ed8bd00275d6f46b835764017e')
CURRENT = dict(path=str(current.OUT/'report.json'),sha256='cd8a5ac4aaf01a8668af5fd325bb89f12a43f19e91bcb94beb105919bb541ed7')
SEED, EPOCHS = 20261011, 80

def policy():
    return dict(schema_version='CIC2-shared5987-full78-fresh-MHFD-isolated-known-supplement-v48',
        hypotheses=1,seed=SEED,epochs=EPOCHS,optimizer_rows=6000,original_FIT=5987,optimizer_copies=13,
        preprocessing='all78 signedlog1p, uniqueFIT mean/std; exact zero std uses unit1; no clipping/selection',
        model='fresh original MHFD attention/gate/CNN/BiLSTM32/coarse+fine+decoder',
        loss='original coarseCE+.35 fineCE(smoothing.01)+.03 reconstructionSmoothL1',
        checkpoint='original known CP only; original coarse/fine checkpoint selection',
        supplement='new MHFD fine9 posterior strictly greater than per-fine CP BEN maximum AND nearest true-fine FIT Fisher support closer than BEN; old remaining BEN only',
        CP_envelope_fit=1,CAL_parameter_fit=0,
        isolation='original sealed detector unknown output, novelty scores, candidates, density, metric and CAL unchanged; no fine override inside detector',
        composite_training_union=5987,density_copies=0,query_fit=0,unknown_training=0,
        prediction_truth_order='complete inference and prediction seal before truth comparison',
        same_existing_DEV=True,warm_known_reuse=True,accepted_baseline_replaced=False,
        independent_final_asserted=False,status='FAIL_TARGET99',published=False,final_test_executed=False)

def sources():
    return {str(Path(m.__file__).resolve()):h.sha(m.__file__) for m in (aligned,current,network,guard,fine)}|{str(Path(__file__).resolve()):h.sha(__file__)}

def freeze():
    pins={}; material=h.read(MATERIAL,pins); known=h.read(KNOWN,pins); old=h.read(CURRENT,pins)
    kr=h.read(known['registry'],pins)
    h.require(known['own_known_alignment_passed'] and old['prediction_sealed'],'completed frozen detector')
    h.require(material['with_training_copies']==6000 and material['original_primary_training_union_exact']==5987,'exact composite known budget')
    assets=dict(native=material['source_arrays'],class_geometry=kr['class_geometry'],
        known_predictions=known['files']['predictions'],known_truth=known['files']['postseal_pair'],
        current_geometry=old['files']['geometry'],current_predictions=old['files']['predictions'],current_truth=old['files']['postseal_pair'])
    for a in assets.values():h.checked(a,pins)
    for p,s in sources().items():h.checked(dict(path=p,sha256=s),pins)
    h.require(not OUT.exists() and not REG.exists(),'fresh V48 fit and registry')
    REG.parent.mkdir(parents=True,exist_ok=True)
    return h.json_new(REG,dict(policy=policy(),sources=sources(),assets=assets,input_sha256=pins,output=str(OUT),known=KNOWN,current=CURRENT,numeric_decodes=0))

def load(item,pins):
    with np.load(h.checked(item,pins),allow_pickle=False) as z:return {k:z[k].copy() for k in z.files}

def transform(native,state):
    return np.ascontiguousarray((guard.signed_log(native)-state['mean'])/state['std'],np.float32)

@torch.no_grad()
def capture(net,x):
    net.eval(); values={k:[] for k in ('coarse_logits','fine_logits','embedding','reconstruction','gate_mean')}
    for start in range(0,len(x),512):
        raw=net(torch.from_numpy(x[start:start+512]))
        for k in values:values[k].append(raw[k].detach().float().numpy().copy())
    result={k:np.concatenate(v) for k,v in values.items()}
    result['fine_probability']=torch.softmax(torch.from_numpy(result['fine_logits']),dim=1).numpy()
    result['attack_probability']=.55*torch.softmax(torch.from_numpy(result['coarse_logits']),dim=1).numpy()[:,1]+.45*(1-result['fine_probability'][:,0])
    h.require(all(np.isfinite(v).all() and len(v)==len(x) for v in result.values()),'complete finite original MHFD outputs')
    return result

def supplement(baseline,prob,native,state,refs,weights,envelope):
    # Unknown decisions are never supplied as BEN to the binary support helper.
    binary=np.where(baseline==0,0,1).astype(np.int64)
    proposed=guard.class_support(binary,prob,envelope,native,state['units'],refs,weights)
    added=proposed[2] & (baseline==0)
    prediction=baseline.copy();prediction[added]=1
    h.require(np.array_equal(prediction[baseline==2],baseline[baseline==2]),'all original UNA retained')
    return prediction,added,proposed

def gates(y,p):return current.gates(y,p)

def run_known(registry):
    pins={};reg=h.read(registry,pins)
    h.require(reg['policy']==policy() and reg['sources']==sources(),'fixed recipe/source')
    for p,s in reg['input_sha256'].items():h.checked(dict(path=p,sha256=s),pins)
    out=OUT/'known';out.mkdir(parents=True,exist_ok=False)
    report=dict(policy=policy(),registry=registry,files={},new_MHFD_fit=0,CP_envelope_fit=0,CAL_fit=0,
        unknown_numeric_reads=0,unknown_truth_opened=False,prediction_sealed=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False,accepted_baseline_replaced=False)
    began=time.perf_counter();stage='known_native_decode'
    try:
        a=load(reg['assets']['native'],pins);idx=a['FIT_training_indices'];y=a['FIT_y_fine']
        h.require(a['FIT_native78'].shape==(5987,78) and idx.shape==(6000,) and len(np.unique(a['FIT_ids']))==5987,'genuine5987 optimizer6000')
        h.require(min(Counter(y[idx].tolist()).values())>=20 and np.array_equal(a['FIT_y_coarse'],(y>0).astype(np.int64)),'positive family floor20 and known labels')
        h.require(len(np.unique(np.concatenate([a[r+'_ids'] for r in ('FIT','CP','CAL')])))==7751,'original role IDs disjoint')
        logged=guard.signed_log(a['FIT_native78']);mean=logged.mean(0);std=logged.std(0);std=np.where(std>0,std,1.)
        pre=dict(mean=mean,std=std)
        report['files']['preprocessing']=h.npz_new(out/'uniqueFIT78_preprocessing_before_optimizer.npz',pre,{})
        x={r:transform(a[r+'_native78'],pre) for r in ('FIT','CP','CAL')}
        report['files']['training_inputs']=h.npz_new(out/'known_features_labels_indices_before_optimizer.npz',dict(**{r+'_features':v for r,v in x.items()},FIT_ids=a['FIT_ids'],FIT_fine=y,FIT_optimizer_indices=idx),{})
        report['files']['prefit']=h.json_new(out/'fixed_recipe_before_optimizer.json',dict(policy=policy(),registry=registry,preprocessing=report['files']['preprocessing'],training_inputs=report['files']['training_inputs'],source=reg['assets']['native'],CP_CAL_unknown_used_in_feature_fit=False))
        torch.set_num_threads(4);stage='one_fresh_full78_MHFD_fit';report['new_MHFD_fit']=1
        result=network.train_model(x['FIT'][idx],a['FIT_y_coarse'][idx],y[idx],x['CP'],a['CP_y_coarse'],fine_class_count=9,epochs=EPOCHS,seed=SEED,progress_label='CIC2 V48 full78 shared6000',checkpoint_fine_labels=a['CP_y_fine'])
        report.update(training_seconds=float(result.training_seconds),selected_epoch=result.selected_epoch,device=result.device)
        report['files']['history']=h.json_new(out/'training_history.json',result.history)
        model_path=out/'new_full78_MHFD_state_before_control_inference.pt'
        state={k:v.detach().cpu().clone() for k,v in result.model.state_dict().items()}
        torch.save(dict(state_dict=state,input_dim=78,fine_class_count=9,seed=SEED,selected_epoch=result.selected_epoch),model_path)
        report['files']['model']=h.descriptor(model_path)
        net=network.MHFDNetwork(78,9);net.load_state_dict(state,strict=True);net.eval()
        stage='known_CPU512_inference'
        outputs={r:capture(net,x[r]) for r in ('CP','CAL')}
        for r,o in outputs.items():report['files'][r+'_MHFD']=h.npz_new(out/(r+'_actual_new_MHFD_before_guard.npz'),dict(ids=a[r+'_ids'],**o),{})
        envelope=guard.prior.calibrate(outputs['CP']['fine_probability'],a['CP_y_coarse']);report['CP_envelope_fit']=1
        report['files']['envelope']=h.json_new(out/'CP_BEN_fine9_maximum_before_CAL_guard.json',dict(envelope=envelope.tolist(),query_used=False,CAL_used=False))
        geom=load(reg['assets']['class_geometry'],pins);z=guard.coordinates(a['FIT_native78'],geom['units'])
        refs={k:z[y==k] for k in range(9)};weights={k:geom['weights'][k-1] for k in range(1,9)}
        baseline=load(reg['assets']['known_predictions'],pins);fields={};counts={}
        for r,o in outputs.items():
            b=baseline[r+'_prediction'];h.require(np.array_equal(a[r+'_ids'],baseline[r+'_ids']),'same known IDs')
            pred,added,pr=supplement(b,o['fine_probability'],a[r+'_native78'],geom,refs,weights,envelope)
            fields.update({r+'_ids':a[r+'_ids'],r+'_baseline':b,r+'_prediction':pred,r+'_added':added,r+'_confidence_proposed':pr[1],r+'_new_fine':o['fine_probability']})
            counts[r]=dict(proposed=int(pr[1].sum()),added=int(added.sum()))
        report['files']['predictions']=h.npz_new(out/'complete_known_predictions_before_comparison.npz',fields,{})
        report['files']['prediction_seal']=h.json_new(out/'prediction_seal_before_truth_comparison.json',dict(prediction=report['files']['predictions'],model=report['files']['model'],envelope=report['files']['envelope'],truth_used_in_decision=False,original_unknown_route_unchanged=True))
        report['prediction_sealed']=True;stage='postseal_known_comparison'
        effect={r:current.compare(a[r+'_y_coarse'],fields[r+'_baseline'],fields[r+'_prediction']) for r in ('CP','CAL')}
        gs={r:gates(a[r+'_y_coarse'],fields[r+'_prediction']) for r in ('CP','CAL')}
        ok=all(v['passed'] for r in gs.values() for v in r.values() if v['support']>0) and all(e['gain_loss'][n]['loss']==0 for e in effect.values() for n in ('BEN','KNA'))
        report.update(execution_status='known_new_MHFD_isolated_supplement_evaluated',known_gates=gs,EffectDelta=effect,counts=counts,known_gate_passed=ok,current_allowed=ok)
        report['files']['postseal_pair']=h.npz_new(out/'known_postseal_pair.npz',dict(**fields,**{r+'_truth':a[r+'_y_coarse'] for r in ('CP','CAL')}),{})
    except Exception as error:
        report.update(execution_status='execution_failed',failed_stage=stage,error_type=type(error).__name__,error=str(error));raise
    finally:
        report.update(wall_seconds=time.perf_counter()-began,input_sha256=pins)
        h.json_new(out/'report.json',report)
    return h.descriptor(out/'report.json')

def run_current(registry,known_item):
    pins={};reg=h.read(registry,pins);known=h.read(known_item,pins)
    h.require(known['registry']==registry and known['known_gate_passed'] and known['prediction_sealed'],'known integer and zero loss gate precedes current')
    h.require(reg['sources']==sources() and reg['policy']==policy(),'unchanged current recipe')
    out=OUT/'current';out.mkdir(parents=True,exist_ok=False);began=time.perf_counter()
    report=dict(policy=policy(),registry=registry,known=known_item,files={},training_seconds=0,new_fit=0,query_forward=0,prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False,accepted_baseline_replaced=False)
    try:
        for p,s in reg['input_sha256'].items():h.checked(dict(path=p,sha256=s),pins)
        saved=torch.load(h.checked(known['files']['model'],pins),map_location='cpu',weights_only=True)
        net=network.MHFDNetwork(78,9);net.load_state_dict(saved['state_dict'],strict=True);torch.set_num_threads(4)
        pre=load(known['files']['preprocessing'],pins);geom=load(reg['assets']['class_geometry'],pins)
        fit=load(reg['assets']['native'],pins);z=guard.coordinates(fit['FIT_native78'],geom['units']);y=fit['FIT_y_fine']
        refs={k:z[y==k] for k in range(9)};weights={k:geom['weights'][k-1] for k in range(1,9)}
        envelope=np.asarray(h.read(known['files']['envelope'],pins)['envelope'])
        q=load(reg['assets']['current_geometry'],pins);base=load(reg['assets']['current_predictions'],pins)
        h.require(np.array_equal(q['ids'],base['ids']) and len(q['ids'])==3184,'same complete current3184')
        output=capture(net,transform(q['native78'],pre));report['query_forward']=1
        report['files']['MHFD_output']=h.npz_new(out/'actual3184_MHFD_before_guard.npz',dict(ids=q['ids'],**output),{})
        pred,added,pr=supplement(base['prediction'],output['fine_probability'],q['native78'],geom,refs,weights,envelope)
        report['files']['prediction']=h.npz_new(out/'complete3184_prediction_before_truth.npz',dict(ids=q['ids'],prediction=pred,baseline=base['prediction'],added=added,proposed=pr[1]),{})
        report['files']['prediction_seal']=h.json_new(out/'prediction_seal_before_truth.json',dict(prediction=report['files']['prediction'],known=known_item,model=known['files']['model'],truth_used=False,unknown_decisions_preserved=True,DVC_reruns=0))
        report['prediction_sealed']=True
        truth=load(reg['assets']['current_truth'],pins);report['truth_opened']=True
        h.require(np.array_equal(q['ids'],truth['ids']),'same truth order after seal')
        gs=gates(truth['truth'],pred);effect=current.compare(truth['truth'],base['prediction'],pred)
        report['files']['postseal_pair']=h.npz_new(out/'postseal_same3184_comparison.npz',dict(ids=q['ids'],truth=truth['truth'],prediction=pred,baseline=base['prediction'],historical=truth['historical'],added=added,proposed=pr[1]),{})
        report.update(execution_status='current_isolated_MHFD_evaluated',original_class_gates=gs,EffectDelta=effect,proposed=int(pr[1].sum()),added=int(added.sum()),historical_comparison=current.compare(truth['truth'],truth['historical'],pred),all_three_integer99_passed=all(v['passed'] for v in gs.values()),baseline_UNA_byte_exact=True,DVC_reruns=0)
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        report.update(wall_seconds=time.perf_counter()-began,input_sha256=pins);h.json_new(out/'report.json',report)
    return h.descriptor(out/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for key in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+key)
    a=p.parse_args();reg=dict(path=a.registry,sha256=a.registry_sha256)
    print(json.dumps(freeze() if a.phase=='freeze' else run_known(reg) if a.phase=='known' else run_current(reg,dict(path=a.known_report,sha256=a.known_sha256))))
