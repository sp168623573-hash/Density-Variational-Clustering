"""Fixed CP-selected signed-log NN / existing coverage-forest cached blend.

No raw features, model deserialization, model prediction or model training.
CAL probability members are decoded only after the unique CP selection seal.
"""
from __future__ import annotations
import argparse
import io
import json
from pathlib import Path
import time
import numpy as np
from . import cic2017_setting2_signed_log_training_v1 as nn
from . import cic2017_setting2_known_fit_coverage_forest_blend_v1 as forest

ROOT=nn.ROOT
NN_REPORT=dict(path='data/external_dev/processed/cic2017_setting2_signed_log_training_20261008_v1/CIC_Setting2/report.json',
    sha256='6c357bb7ed4c16308201cbf20897ea69b88c5bfb608a15636c646ceb5f00779e')
FOREST_REPORT=dict(path='data/external_dev/processed/cic2017_setting2_known_fit_coverage_forest_blend_20261008_v1/CIC_Setting2/report.json',
    sha256='4cd3996dc86d8d400f7df650668842b355d158cdd2b69749ed5c53198a2af736')
OLD_NN_REPORT=dict(path=forest.BASELINE,sha256=forest.BASELINE_SHA)
WEIGHTS=(0.,.25,.5,.75)
POLICY=dict(schema_version='CIC2-signed-log-existing-forest-cached-blend-v1',setting='CIC Setting2',
    weights=WEIGHTS,minimum_NN_contribution=.25,source='exact same fixed coverage5951 originals / effective6000',
    role_rows=nn.ROLES,effective_rows=nn.EFFECTIVE_ROLES,CP_selection_original_rows=882,CAL_diagnostic_original_rows=882,
    reporting_copies_only_each_control=18,FIT_optimizer_copies_in_existing_models=13,
    blend='(1-w)*signedlogNN_probability + w*(1-existing_forest_fine_probability[:,BENindex0])',
    null='w0 preserves float32 probability and signedlogNN frozen CP threshold exactly',
    nonnull='float64, unchanged choose_coarse_threshold per CP weight',
    selection='both integer99 gates, exact Fraction minimum recall,totalcorrect,smaller weight',
    CAL_usage='once after selection, already warm, no runner-up or parameter change',
    main_EffectDelta='coverageforest4cd399 candidate, not accepted baseline',
    secondary_EffectDelta='same signedlogNN6c357 candidate',NN_training_runs=0,forest_training_runs=0,
    NN_inference_runs=0,forest_inference_runs=0,preprocessing_transforms=0,raw_source_reads=0,
    model_deserializations=0,CP_threshold_searches=3,CP_blend_candidates=4,CAL_selected_blends=1,
    UNA_or_DEV_opened=False,final_test_executed=False,published=False,accepted_baseline_replaced=False,
    source_integrity='inherit original source admission from hash-pinned completed reports; do not reread original Parquet bytes')
require,checked,ad=nn.require,nn._checked,nn.array_descriptor
pin_json,integrity=forest._pin_json,forest._integrity


def _read(item,keys,pins):
    with np.load(io.BytesIO(checked(item,pins)),allow_pickle=False) as z:
        return {k:z[k].copy() for k in keys}


def _save(path,values,pins):
    bound={k:ad(v) for k,v in values.items()};item=forest._save_npz(path,pins,**values)
    saved=_read(item,tuple(values),pins)
    require(all(ad(saved[k])==bound[k] and ad(values[k])==bound[k] for k in values),'saved_live_probability_material_exact')
    return item


def _validate_metadata(meta):
    ids=[];heart=nn.FAMILIES.index('Heartbleed')
    for role,n in nn.ROLES.items():
        i,y,f=(meta[role+'_'+k] for k in ('ids','y_coarse','y_fine'));m=meta[nn.INDEX_FIELDS[role]]
        require(i.shape==y.shape==f.shape==(n,) and i.dtype.kind=='U' and y.dtype==f.dtype==np.int64
            and np.isin(f,np.arange(9)).all() and np.array_equal(y,(f!=0).astype(np.int64)), 'known_role_metadata:'+role)
        require(m.dtype==np.int64 and m.shape==(nn.EFFECTIVE_ROLES[role],)
            and np.array_equal(m[:n],np.arange(n)) and np.all((m>=0)&(m<n)), 'original_and_report_mapping:'+role)
        h=np.flatnonzero(f==heart)
        require(len(h)==(7 if role=='FIT' else 2) and np.array_equal(m[n:],np.resize(h,len(m)-n)), 'same_cyclic_Heart_parents:'+role)
        ids.extend(i.tolist())
    require(len(ids)==5951 and len(set(ids))==5951 and sum(nn.EFFECTIVE_ROLES.values())==6000,'same5951_unique6000_effective_known_cap')


def _load_registered(pins):
    n=json.loads(checked(NN_REPORT,pins));f=json.loads(checked(FOREST_REPORT,pins));o=json.loads(checked(OLD_NN_REPORT,pins))
    require(n['execution_status']=='native_CIC2_fixed_controls_signed_log_training_completed'
        and f['execution_status']=='CIC2_fixed_controls_FIT_coverage_forest_blend_completed'
        and o['execution_status']=='native_CIC2_fixed_controls_FIT_coverage_training_completed'
        and all(r['metrics_evaluated'] and not r['published'] and not r['final_test_executed'] for r in (n,f,o)),
        'three_completed_frozen_known_parents')
    npolicy=json.loads(checked(n['files']['prefit'],pins));opolicy=json.loads(checked(o['files']['prefit'],pins))
    fpolicy=json.loads(checked(f['prefit'],pins));proof=json.loads(checked(f['training_proof'],pins))
    require(npolicy['source_report']==opolicy['source_report']==nn.SOURCE_REPORT
        and npolicy['source_files']==opolicy['source_files']==fpolicy['source_files']
        and fpolicy['baseline_report']==OLD_NN_REPORT and f['old_NN_model_artifact']==o['files']['model'],
        'same_original_coverage_source_and_forest_training_parent')
    require(tuple(fpolicy['family_order'])==tuple(nn.FAMILIES) and proof['classes']==9 and proof['original_rows']==4187
        and proof['rows']==4200 and proof['role_internal_Heart_copies']==13
        and proof['model']==f['model'] and f['selected']['weight']==.75, 'same_existing_256_tree_family_order_and_optimizer_role')
    require(f['configuration']['forest_parameters']==forest.FOREST_PARAMETERS,'fixed_existing_forest_recipe')
    keys=tuple(r+'_'+suffix for r in nn.ROLES for suffix in ('ids','y_coarse','y_fine'))+tuple(nn.INDEX_FIELDS.values())
    meta=_read(n['files']['training_inputs'],keys,pins);prior_meta=_read(o['files']['training_inputs'],keys,pins)
    require(all(ad(meta[k])==ad(prior_meta[k]) for k in keys),'byte_exact_same_training_roles_and_copy_maps')
    _validate_metadata(meta)
    threshold=json.loads(checked(n['files']['threshold'],pins))
    require(threshold['selection_role']=='CP' and threshold['CAL_labels_used'] is False
        and threshold['threshold']==n['coarse_threshold'],'signedlog_frozen_CP_threshold')
    recipe=dict(signedlog_NN_model=n['files']['model'],complete_signedlog_preprocessing=n['files']['preprocessing'],
        native78_existing_forest=f['model'],family_order=nn.FAMILIES,
        future_inference='originalnative78->complete signedlog preprocessor->NN; originalnative78float32->existing forest; fixed chosen blend')
    for item in (n['files']['model'],n['files']['preprocessing'],f['model']):checked(item,pins)
    for path,parent in ((Path(nn.__file__),n),(Path(forest.__file__),f),(Path(forest.original.__file__),o),(Path(nn.network.__file__),n)):
        key=str(path.resolve());checked(dict(path=key,sha256=parent['input_sha256'][key]),pins)
    pins[str(Path(__file__).resolve())]=nn.sha(__file__)
    return n,f,meta,recipe


def _read_forest(f,meta,role,pins):
    item=f['CP_candidates' if role=='CP' else 'CAL_predictions'];key='w3_prediction' if role=='CP' else 'candidate_prediction'
    fields=(role+'_ids',role+'_truth','forest_fine_probability',key)
    values=_read(item,fields,pins)
    require(ad(values[role+'_ids'])==ad(meta[role+'_ids']) and ad(values[role+'_truth'])==ad(meta[role+'_y_coarse']), 'same_cached_forest_role:'+role)
    p=values['forest_fine_probability'];pred=values[key]
    require(p.dtype==np.float64 and p.shape==(nn.ROLES[role],9) and np.isfinite(p).all()
        and np.all((p>=0)&(p<=1)) and np.allclose(p.sum(axis=1),1.,rtol=0,atol=1e-12)
        and pred.dtype==np.int64 and pred.shape==(nn.ROLES[role],) and np.isin(pred,(0,1)).all(), 'cached_forest_probability_domain:'+role)
    gate=f['selected_CP_class_gates' if role=='CP' else 'CAL_class_gates']
    require(nn._gates(meta[role+'_y_coarse'],pred)==gate,'existing_forest_correct_count_reproduction:'+role)
    return {'fine_probability':p,'prediction':pred}


def run_blend(*,output_directory):
    out=Path(output_directory).resolve();require(out.is_relative_to(ROOT) and out!=ROOT,'fresh_workspace_output')
    out.mkdir(parents=True,exist_ok=False);start=time.perf_counter();stage='bind_completed_known_models_and_metadata';pins={}
    r=dict(configuration=POLICY,status='FAIL_TARGET99',published=False,final_test_executed=False,
        accepted_baseline_replaced=False,promotion_status='NOT_PROMOTED',metrics_evaluated=False,DEV_executed=False,
        NN_training_runs=0,forest_training_runs=0,NN_inference_runs=0,forest_inference_runs=0,model_deserializations=0,
        raw_source_reads=0,preprocessing_transforms=0,CP_threshold_searches_returned=0,CP_blends_returned=0,
        CAL_blends_returned=0,cached_role_reads_attempted=[],cached_role_reads_returned=[],selection_sealed=False,
        CAL_used_for_selection=False,CAL_warm_diagnostic=True,runner_up_after_CAL_failure_allowed=False)
    try:
        n,f,meta,recipe=_load_registered(pins)
        meta_item=_save(out/'same_known_role_metadata.npz',meta,pins)
        before=pin_json(out/'recipe_before_CP_selection.json',dict(configuration=POLICY,NN_report=NN_REPORT,forest_report=FOREST_REPORT,
            role_metadata=meta_item,complete_future_model_recipe=recipe,input_sha256=dict(pins)),pins)
        stage='read_only_CP_cached_probabilities'
        r['cached_role_reads_attempted'].append('NN_CP');cp=forest._read_cached_role(n,meta,'CP',pins);r['cached_role_reads_returned'].append('NN_CP')
        r['cached_role_reads_attempted'].append('forest_CP');fc=_read_forest(f,meta,'CP',pins);r['cached_role_reads_returned'].append('forest_CP')
        inputs=dict(CP_ids=meta['CP_ids'],CP_truth=meta['CP_y_coarse'],signedlog_NN_probability=cp['probability'],
            signedlog_NN_prediction=cp['prediction'],forest_fine_probability=fc['fine_probability'],coverage_forest_prediction=fc['prediction'])
        bound={k:ad(v) for k,v in inputs.items()};cp_input=_save(out/'CP_cached_inputs_before_selection.npz',inputs,pins)
        candidates=[];values=dict(inputs)
        stage='four_fixed_CP_blends_and_three_threshold_searches'
        for index,weight in enumerate(WEIGHTS):
            probability=forest._blend(cp['probability'],1.-fc['fine_probability'][:,0],weight)
            if weight==0:threshold,metrics=n['coarse_threshold'],{}
            else:
                threshold,metrics=nn.network.choose_coarse_threshold(meta['CP_y_coarse'],probability)
                r['CP_threshold_searches_returned']+=1
            prediction=(probability>=threshold).astype(np.int64)
            if weight==0:require(ad(probability)==ad(cp['probability']) and ad(prediction)==ad(cp['prediction']),'exact_signedlog_null_probability_and_prediction')
            candidates.append(dict(weight=weight,threshold=float(threshold),class_gates=nn._gates(meta['CP_y_coarse'],prediction),threshold_metrics=metrics))
            values[f'w{index}_probability']=probability;values[f'w{index}_prediction']=prediction;r['CP_blends_returned']+=1
            require(all(ad(v)==bound[k] for k,v in inputs.items()),'CP_live_cached_inputs_unchanged')
        selected=max(candidates,key=forest._selection_key);cp_archive=_save(out/'CP_candidates_before_CAL.npz',values,pins)
        selection=pin_json(out/'selected_recipe_before_CAL.json',dict(configuration=POLICY,recipe=recipe,selected=selected,candidates=candidates,
            preselection=before,CP_input=cp_input,CP_candidates=cp_archive,CAL_probability_members_decoded=False,input_sha256=dict(pins)),pins)
        r.update(selection_sealed=True,selection=selection,selected=selected,CP_candidates=cp_archive);integrity(pins)
        stage='one_CAL_cached_probability_read_after_selection'
        r['cached_role_reads_attempted'].append('NN_CAL');cal=forest._read_cached_role(n,meta,'CAL',pins);r['cached_role_reads_returned'].append('NN_CAL')
        r['cached_role_reads_attempted'].append('forest_CAL');fl=_read_forest(f,meta,'CAL',pins);r['cached_role_reads_returned'].append('forest_CAL')
        cal_values=dict(CAL_ids=meta['CAL_ids'],CAL_truth=meta['CAL_y_coarse'],signedlog_NN_probability=cal['probability'],
            signedlog_NN_prediction=cal['prediction'],forest_fine_probability=fl['fine_probability'],coverage_forest_prediction=fl['prediction'])
        cb={k:ad(v) for k,v in cal_values.items()};_save(out/'CAL_cached_inputs_before_frozen_blend.npz',cal_values,pins)
        probability=forest._blend(cal['probability'],1.-fl['fine_probability'][:,0],selected['weight'])
        pred=(probability>=selected['threshold']).astype(np.int64);r['CAL_blends_returned']=1
        require(all(ad(v)==cb[k] for k,v in cal_values.items()),'CAL_live_cached_inputs_unchanged')
        if selected['weight']==0:require(ad(probability)==ad(cal['probability']) and ad(pred)==ad(cal['prediction']),'exact_CAL_null')
        cal_values.update(candidate_probability=probability,candidate_prediction=pred)
        cal_archive=_save(out/'warm_CAL_selected_predictions.npz',cal_values,pins)
        stage='sealed_predictions_two_parent_paired_effects'
        chosen=WEIGHTS.index(selected['weight']);pair={};paired={name:{} for name in ('coverage_forest','signedlog_NN')}
        for role,new,fore,neural in (('CP',values[f'w{chosen}_prediction'],fc['prediction'],cp['prediction']),('CAL',pred,fl['prediction'],cal['prediction'])):
            y=meta[role+'_y_coarse'];idx=meta[nn.INDEX_FIELDS[role]]
            pair.update({role+'_ids':meta[role+'_ids'],role+'_truth':y,role+'_candidate':new,role+'_reporting_indices':idx})
            for name,old in (('coverage_forest',fore),('signedlog_NN',neural)):
                paired[name][role]=dict(original=nn._paired_view(y,old,new),effective_reporting=nn._paired_view(y[idx],old[idx],new[idx]))
                pair.update({role+'_'+name:old,role+'_'+name+'_gain':(old!=y)&(new==y),role+'_'+name+'_loss':(old==y)&(new!=y)})
        paired_item=_save(out/'paired_known_original_and_reporting_predictions.npz',pair,pins)
        stage='final_cached_artifact_integrity';integrity(pins)
        gates={role:paired['coverage_forest'][role]['original']['candidate_gates'] for role in ('CP','CAL')}
        effective={role:paired['coverage_forest'][role]['effective_reporting']['candidate_gates'] for role in ('CP','CAL')}
        passed={role:all(v['passed'] for g in (gates[role],effective[role]) for v in g.values()) for role in ('CP','CAL')}
        r.update(execution_status='CIC2_signedlog_cached_forest_blend_completed',metrics_evaluated=True,
            outcome='KNOWN_CP_CAL_PASS_NOT_UNA_OR_FINAL' if all(passed.values()) else 'NO_GO_KNOWN_CLASS_GATE_FAILED',
            CP_passed=passed['CP'],CAL_passed=passed['CAL'],original_class_gates=gates,effective_reporting_gates=effective,
            EffectDelta={role:paired['coverage_forest'][role]['original'] for role in ('CP','CAL')},
            reporting_EffectDelta={role:paired['coverage_forest'][role]['effective_reporting'] for role in ('CP','CAL')},
            paired_known_EffectDelta=paired,EffectDelta_reference='coverageforest4cd399 development candidate, not acceptedbaseline',
            files=dict(recipe=before,known_metadata=meta_item,CP_candidates=cp_archive,CAL_predictions=cal_archive,paired=paired_item),
            complete_future_model_recipe=recipe,known_total_original_rows=5951,known_total_effective_rows=6000,density_copy_rows=0)
    except Exception as error:
        r.update(execution_status='protocol_stop' if isinstance(error,(nn.NativeKnownTrainingStop,forest.original.NativeKnownTrainingStop)) else 'execution_failed',
            failed_stage=stage,error_type=type(error).__name__,error_message=str(error),outcome='NOT_EVALUATED')
    r.update(input_sha256=pins,wall_seconds=time.perf_counter()-start)
    r=forest._plain(r);nn._write(out/'report.json',r);return r


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output-directory',required=True)
    r=run_blend(output_directory=p.parse_args(argv).output_directory)
    print(json.dumps({k:r.get(k) for k in ('execution_status','selected','original_class_gates','EffectDelta','failed_stage','error_message')},ensure_ascii=False))
    return 0 if r['metrics_evaluated'] else 2 if r['execution_status']=='protocol_stop' else 1


if __name__=='__main__':raise SystemExit(main())
