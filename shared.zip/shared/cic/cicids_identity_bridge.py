"""Recover CICIDS2017 flow identity without consulting frozen target labels.

The paper's frozen CIC train/test files contain the 78 CICFlowMeter model
features and one label column, but no flow ID, endpoint, protocol, or
timestamp.  Public per-day ``traffic_labels`` Parquet files contain those
identity fields alongside the same 78 features.  This module performs a
fail-closed, label-blind join between the two representations.

Only an exact one-to-one match on all 78 normalized float64 feature cells is
admitted.  The frozen label column and the Parquet ``Label`` column are never
read.  Ambiguous and missing rows are audited, not guessed.  The resulting
bridge is diagnostic provenance only: it is not a new independent test set
and must not be used to tune a result already evaluated on the frozen split.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping, Sequence

import numpy as np
import pandas as pd

from .config import CIC_FEATURE_COLUMNS
from .data import sha256_file


IDENTITY_COLUMNS: tuple[str, ...] = (
    "Flow ID",
    "Source IP",
    "Source Port",
    "Destination IP",
    "Destination Port",
    "Protocol",
    "Timestamp",
)

# Destination Port is already part of the 78-feature model schema.
PARQUET_COLUMNS: tuple[str, ...] = IDENTITY_COLUMNS + tuple(
    column for column in CIC_FEATURE_COLUMNS if column not in IDENTITY_COLUMNS
)

# A cheap, high-cardinality screening key.  It is only an optimization; every
# admitted match is subsequently confirmed with all 78 feature cells.
QUICK_KEY_COLUMNS: tuple[str, ...] = (
    "Destination Port",
    "Flow Duration",
    "Total Fwd Packets",
    "Total Backward Packets",
    "Total Length of Fwd Packets",
    "Total Length of Bwd Packets",
    "Fwd Packet Length Max",
    "Bwd Packet Length Max",
    "Flow IAT Max",
    "Init_Win_bytes_forward",
    "Init_Win_bytes_backward",
    "min_seg_size_forward",
)

# These are algebraically derived floating-point statistics in CICFlowMeter.
# Different CSV/Parquet readers can differ by a few ulps for these cells.  No
# count, flag, port, duration, window, length-total, or IAT-extreme is allowed
# to drift in the second-stage identity bridge.
DERIVED_FLOAT_COLUMNS: frozenset[str] = frozenset(
    {
        "Fwd Packet Length Mean",
        "Fwd Packet Length Std",
        "Bwd Packet Length Mean",
        "Bwd Packet Length Std",
        "Flow Bytes/s",
        "Flow Packets/s",
        "Flow IAT Mean",
        "Flow IAT Std",
        "Fwd IAT Mean",
        "Fwd IAT Std",
        "Bwd IAT Mean",
        "Bwd IAT Std",
        "Fwd Packets/s",
        "Bwd Packets/s",
        "Packet Length Mean",
        "Packet Length Std",
        "Packet Length Variance",
        "Average Packet Size",
        "Avg Fwd Segment Size",
        "Avg Bwd Segment Size",
        "Active Mean",
        "Active Std",
        "Idle Mean",
        "Idle Std",
    }
)

PACKET_LINK_EXPECTATION_COLUMNS: tuple[str, ...] = (
    "Flow Duration",
    "Total Fwd Packets",
    "Total Backward Packets",
    "Total Length of Fwd Packets",
    "Total Length of Bwd Packets",
    "FIN Flag Count",
    "RST Flag Count",
)


class Cic2017IdentityBridgeError(ValueError):
    """Raised when the bridge cannot prove its label-blind join contract."""


@dataclass(frozen=True)
class FrozenRows:
    frame: pd.DataFrame
    paths: tuple[Path, ...]
    row_counts: Mapping[str, int]
    sha256: Mapping[str, str]


@dataclass(frozen=True)
class SourceBatch:
    source_file: str
    source_sha256: str
    source_row_start: int
    frame: pd.DataFrame


def _canonical_matrix(frame: pd.DataFrame) -> np.ndarray:
    missing = sorted(set(CIC_FEATURE_COLUMNS) - set(frame.columns))
    if missing:
        raise Cic2017IdentityBridgeError(
            f"missing CIC feature columns: {missing}"
        )
    numeric = frame.loc[:, CIC_FEATURE_COLUMNS].apply(
        pd.to_numeric, errors="coerce"
    )
    matrix = np.ascontiguousarray(numeric.to_numpy(dtype=np.float64), dtype="<f8")
    # Collapse signed zero and all NaN payload encodings to one representation.
    matrix[matrix == 0.0] = 0.0
    matrix[np.isnan(matrix)] = np.nan
    return matrix


def _feature_fingerprints(matrix: np.ndarray) -> np.ndarray:
    if matrix.ndim != 2 or matrix.shape[1] != len(CIC_FEATURE_COLUMNS):
        raise Cic2017IdentityBridgeError("feature matrix must contain exactly 78 columns")
    return np.asarray(
        [hashlib.sha256(row).hexdigest() for row in matrix], dtype=object
    )


def _quick_hashes(matrix: np.ndarray) -> np.ndarray:
    indices = [CIC_FEATURE_COLUMNS.index(column) for column in QUICK_KEY_COLUMNS]
    quick = pd.DataFrame(matrix[:, indices], columns=QUICK_KEY_COLUMNS)
    return pd.util.hash_pandas_object(quick, index=False).to_numpy(dtype=np.uint64)


def read_frozen_features(paths: Sequence[str | Path]) -> FrozenRows:
    """Read only feature columns 0..77 from one or more frozen CSV files."""

    if not paths:
        raise Cic2017IdentityBridgeError("at least one frozen file is required")
    frames: list[pd.DataFrame] = []
    resolved: list[Path] = []
    counts: dict[str, int] = {}
    hashes: dict[str, str] = {}
    for raw_path in paths:
        path = Path(raw_path).resolve()
        if not path.is_file():
            raise FileNotFoundError(path)
        # The 79th field is the frozen BEN/KNA/UNA-family label.  It is
        # deliberately absent from usecols and therefore never materialized.
        frame = pd.read_csv(
            path,
            header=None,
            usecols=list(range(len(CIC_FEATURE_COLUMNS))),
            low_memory=False,
        )
        if frame.shape[1] != len(CIC_FEATURE_COLUMNS):
            raise Cic2017IdentityBridgeError(
                f"{path}: expected 78 feature columns, got {frame.shape[1]}"
            )
        frame.columns = CIC_FEATURE_COLUMNS
        frame.insert(0, "frozen_row", np.arange(len(frame), dtype=np.int64))
        frame.insert(0, "frozen_file", path.name)
        frames.append(frame)
        resolved.append(path)
        counts[path.name] = int(len(frame))
        hashes[path.name] = sha256_file(path)
    combined = pd.concat(frames, ignore_index=True)
    return FrozenRows(
        frame=combined,
        paths=tuple(resolved),
        row_counts=counts,
        sha256=hashes,
    )


def _require_source_schema(columns: Sequence[str], source: str) -> None:
    missing = sorted(set(PARQUET_COLUMNS) - set(columns))
    if missing:
        raise Cic2017IdentityBridgeError(
            f"{source}: missing identity/model columns: {missing}"
        )
    if "Label" not in columns:
        raise Cic2017IdentityBridgeError(
            f"{source}: expected a Label field so exclusion can be audited"
        )


def iter_parquet_batches(
    paths: Sequence[str | Path], *, batch_size: int = 32768
) -> Iterator[SourceBatch]:
    """Yield identity and feature fields while explicitly excluding Label."""

    if batch_size < 1:
        raise Cic2017IdentityBridgeError("batch_size must be positive")
    try:
        import pyarrow.parquet as pq
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise Cic2017IdentityBridgeError(
            "pyarrow is required to read the CICIDS2017 identity Parquet files"
        ) from exc

    for raw_path in sorted((Path(path).resolve() for path in paths), key=str):
        if not raw_path.is_file():
            raise FileNotFoundError(raw_path)
        parquet = pq.ParquetFile(raw_path)
        _require_source_schema(parquet.schema_arrow.names, raw_path.name)
        source_hash = sha256_file(raw_path)
        offset = 0
        # Label is intentionally not included in PARQUET_COLUMNS.
        for record_batch in parquet.iter_batches(
            batch_size=batch_size, columns=list(PARQUET_COLUMNS)
        ):
            frame = record_batch.to_pandas()
            yield SourceBatch(
                source_file=raw_path.name,
                source_sha256=source_hash,
                source_row_start=offset,
                frame=frame,
            )
            offset += len(frame)
        if offset != parquet.metadata.num_rows:
            raise Cic2017IdentityBridgeError(
                f"{raw_path.name}: streamed {offset} rows, metadata declares "
                f"{parquet.metadata.num_rows}"
            )


def _identity_record(batch: SourceBatch, local_row: int, fingerprint: str) -> dict[str, Any]:
    row = batch.frame.iloc[int(local_row)]
    timestamp = pd.Timestamp(row["Timestamp"])
    return {
        "source_feature_fingerprint_sha256": fingerprint,
        "source_file": batch.source_file,
        "source_file_sha256": batch.source_sha256,
        "source_row": int(batch.source_row_start + int(local_row)),
        "Flow ID": str(row["Flow ID"]),
        "Source IP": str(row["Source IP"]),
        "Source Port": int(row["Source Port"]),
        "Destination IP": str(row["Destination IP"]),
        "Destination Port": int(row["Destination Port"]),
        "Protocol": int(row["Protocol"]),
        "Timestamp": timestamp.isoformat(),
    }


def _identity_key(record: Mapping[str, Any]) -> tuple[Any, ...]:
    """Return the packet-linkage identity, excluding a duplicated source row."""

    return (
        record["source_file"],
        record["Flow ID"],
        record["Source IP"],
        record["Source Port"],
        record["Destination IP"],
        record["Destination Port"],
        record["Protocol"],
        record["Timestamp"],
    )


IDENTITY_KEY_FIELDS: tuple[str, ...] = (
    "source_file",
    "Flow ID",
    "Source IP",
    "Source Port",
    "Destination IP",
    "Destination Port",
    "Protocol",
    "Timestamp",
)


def _identity_consensus(keys: Iterable[tuple[Any, ...]]) -> dict[str, Any]:
    distinct = tuple(sorted(set(keys), key=lambda value: tuple(map(str, value))))
    result: dict[str, Any] = {"candidate_identity_count": len(distinct)}
    for index, field in enumerate(IDENTITY_KEY_FIELDS):
        values = {key[index] for key in distinct}
        result[f"consensus_{field}"] = next(iter(values)) if len(values) == 1 else np.nan
    return result


def bridge_identity_batches(
    frozen: FrozenRows,
    batches: Iterable[SourceBatch],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Join frozen rows to source identities using features and no labels."""

    frozen_matrix = _canonical_matrix(frozen.frame)
    frozen_fingerprints = _feature_fingerprints(frozen_matrix)
    frozen_quick = _quick_hashes(frozen_matrix)
    quick_set = set(int(value) for value in frozen_quick)
    fingerprints_by_quick: dict[int, set[str]] = defaultdict(set)
    for quick, fingerprint in zip(frozen_quick, frozen_fingerprints):
        fingerprints_by_quick[int(quick)].add(str(fingerprint))

    source_counts: Counter[str] = Counter()
    source_identity_keys: dict[str, set[tuple[Any, ...]]] = defaultdict(set)
    first_identity: dict[str, dict[str, Any]] = {}
    source_quick_counts: Counter[int] = Counter()
    source_quick_first_matrix: dict[int, np.ndarray] = {}
    source_quick_candidates: dict[
        int, list[tuple[np.ndarray, dict[str, Any]]]
    ] = defaultdict(list)
    source_rows_scanned = 0
    quick_candidates = 0
    exact_candidates = 0
    source_files: dict[str, dict[str, Any]] = {}

    for batch in batches:
        if "Label" in batch.frame.columns:
            raise Cic2017IdentityBridgeError("source batch materialized forbidden Label column")
        missing_identity = sorted(set(IDENTITY_COLUMNS) - set(batch.frame.columns))
        if missing_identity:
            raise Cic2017IdentityBridgeError(
                f"{batch.source_file}: missing identity columns: {missing_identity}"
            )
        matrix = _canonical_matrix(batch.frame)
        quick = _quick_hashes(matrix)
        candidate_indices = np.flatnonzero(
            np.fromiter(
                (int(value) in quick_set for value in quick),
                dtype=bool,
                count=len(quick),
            )
        )
        source_rows_scanned += len(batch.frame)
        quick_candidates += len(candidate_indices)
        source_entry = source_files.setdefault(
            batch.source_file,
            {
                "sha256": batch.source_sha256,
                "rows_scanned": 0,
                "quick_candidates": 0,
                "exact_candidates": 0,
            },
        )
        if source_entry["sha256"] != batch.source_sha256:
            raise Cic2017IdentityBridgeError("source filename reused with a different digest")
        source_entry["rows_scanned"] += len(batch.frame)
        source_entry["quick_candidates"] += len(candidate_indices)
        for local_row in candidate_indices:
            quick_value = int(quick[int(local_row)])
            source_quick_counts[quick_value] += 1
            if source_quick_counts[quick_value] == 1:
                source_quick_first_matrix[quick_value] = matrix[int(local_row)].copy()
            fingerprint = hashlib.sha256(matrix[int(local_row)]).hexdigest()
            identity = _identity_record(batch, int(local_row), fingerprint)
            source_quick_candidates[quick_value].append(
                (matrix[int(local_row)].copy(), identity)
            )
            if fingerprint not in fingerprints_by_quick[quick_value]:
                continue
            exact_candidates += 1
            source_entry["exact_candidates"] += 1
            source_counts[fingerprint] += 1
            source_identity_keys[fingerprint].add(_identity_key(identity))
            if source_counts[fingerprint] == 1:
                first_identity[fingerprint] = identity

    frozen_counts = Counter(str(value) for value in frozen_fingerprints)
    rows: list[dict[str, Any]] = []
    outcome_counts: Counter[str] = Counter()
    drift_column_counts: Counter[str] = Counter()
    drift_cell_count_histogram: Counter[int] = Counter()
    drift_unique_quick_rows = 0
    drift_within_1e9_rows = 0
    drift_allowed_columns_rows = 0
    allowed_drift_mask = np.asarray(
        [column in DERIVED_FLOAT_COLUMNS for column in CIC_FEATURE_COLUMNS], dtype=bool
    )
    for position, frozen_row in frozen.frame.iterrows():
        fingerprint = str(frozen_fingerprints[int(position)])
        source_multiplicity = int(source_counts[fingerprint])
        source_identity_multiplicity = int(len(source_identity_keys[fingerprint]))
        frozen_multiplicity = int(frozen_counts[fingerprint])
        quick_value = int(frozen_quick[int(position)])
        drift_record: dict[str, Any] = {}
        tolerance_admitted = False
        tolerance_identity_map: dict[tuple[Any, ...], dict[str, Any]] = {}
        tolerance_candidate_rows = 0
        if source_multiplicity == 0:
            frozen_vector = frozen_matrix[int(position)]
            for source_vector, identity in source_quick_candidates[quick_value]:
                equal = (source_vector == frozen_vector) | (
                    np.isnan(source_vector) & np.isnan(frozen_vector)
                )
                within = bool(
                    np.all(
                        np.isclose(
                            source_vector,
                            frozen_vector,
                            rtol=1e-9,
                            atol=1e-9,
                            equal_nan=True,
                        )
                    )
                )
                allowed_columns_only = bool(np.all(equal | allowed_drift_mask))
                if within and allowed_columns_only:
                    tolerance_candidate_rows += 1
                    tolerance_identity_map[_identity_key(identity)] = identity
            tolerance_admitted = len(tolerance_identity_map) == 1
            drift_record["numeric_tolerance_candidate_rows"] = int(
                tolerance_candidate_rows
            )
            drift_record["numeric_tolerance_identity_multiplicity"] = int(
                len(tolerance_identity_map)
            )
        if source_multiplicity == 0 and source_quick_counts[quick_value] == 1:
            drift_unique_quick_rows += 1
            source_vector = source_quick_first_matrix[quick_value]
            frozen_vector = frozen_matrix[int(position)]
            equal = (source_vector == frozen_vector) | (
                np.isnan(source_vector) & np.isnan(frozen_vector)
            )
            differing = np.flatnonzero(~equal)
            for index in differing:
                drift_column_counts[CIC_FEATURE_COLUMNS[int(index)]] += 1
            drift_cell_count_histogram[int(len(differing))] += 1
            drift_record["unique_quick_mismatch_cells"] = int(len(differing))
            finite = np.isfinite(source_vector) & np.isfinite(frozen_vector) & ~equal
            if finite.any():
                absolute = np.abs(source_vector[finite] - frozen_vector[finite])
                denominator = np.maximum(
                    np.maximum(np.abs(source_vector[finite]), np.abs(frozen_vector[finite])),
                    1.0,
                )
                relative = absolute / denominator
                drift_record["unique_quick_max_abs_error"] = float(np.max(absolute))
                drift_record["unique_quick_max_rel_error"] = float(np.max(relative))
            else:
                drift_record["unique_quick_max_abs_error"] = np.nan
                drift_record["unique_quick_max_rel_error"] = np.nan
            within = bool(
                np.all(
                    np.isclose(
                        source_vector,
                        frozen_vector,
                        rtol=1e-9,
                        atol=1e-9,
                        equal_nan=True,
                    )
                )
            )
            allowed_columns_only = bool(np.all(equal | allowed_drift_mask))
            drift_record["unique_quick_allclose_rtol_1e9_atol_1e9"] = within
            drift_record["unique_quick_drift_only_in_derived_float_columns"] = (
                allowed_columns_only
            )
            if within:
                drift_within_1e9_rows += 1
            if allowed_columns_only:
                drift_allowed_columns_rows += 1
            if tolerance_admitted != (within and allowed_columns_only):
                raise AssertionError("unique quick-candidate tolerance audit disagrees")

        if source_multiplicity == 0 and tolerance_admitted:
            outcome = "unique_numeric_tolerance_identity"
        elif source_multiplicity == 0 and tolerance_identity_map:
            outcome = "ambiguous_numeric_tolerance_identity"
        elif source_multiplicity == 0:
            outcome = "missing"
        elif source_multiplicity == 1 and frozen_multiplicity == 1:
            outcome = "unique_one_to_one"
        elif source_identity_multiplicity == 1:
            outcome = "unique_source_identity_reused"
        else:
            outcome = "ambiguous_identity"
        outcome_counts[outcome] += 1
        record: dict[str, Any] = {
            "frozen_file": str(frozen_row["frozen_file"]),
            "frozen_row": int(frozen_row["frozen_row"]),
            "feature_fingerprint_sha256": fingerprint,
            "frozen_feature_multiplicity": frozen_multiplicity,
            "source_quick_key_multiplicity": int(source_quick_counts[quick_value]),
            "source_feature_multiplicity": source_multiplicity,
            "source_identity_multiplicity": (
                len(tolerance_identity_map)
                if source_multiplicity == 0
                else source_identity_multiplicity
            ),
            "match_status": outcome,
        }
        for column in PACKET_LINK_EXPECTATION_COLUMNS:
            record[f"expected_{column}"] = float(frozen_row[column])
        record.update(drift_record)
        if outcome in {"unique_one_to_one", "unique_source_identity_reused"}:
            record.update(first_identity[fingerprint])
        elif outcome == "unique_numeric_tolerance_identity":
            record.update(next(iter(tolerance_identity_map.values())))
        elif outcome == "ambiguous_identity":
            record.update(_identity_consensus(source_identity_keys[fingerprint]))
        elif outcome == "ambiguous_numeric_tolerance_identity":
            record.update(_identity_consensus(tolerance_identity_map))
        rows.append(record)

    result = pd.DataFrame(rows)
    for field in IDENTITY_KEY_FIELDS:
        column = f"consensus_{field}"
        if column not in result.columns:
            result[column] = np.nan
    ambiguous_mask = result["match_status"].astype(str).str.startswith("ambiguous")
    consensus_coverage = {
        field: int(result.loc[ambiguous_mask, f"consensus_{field}"].notna().sum())
        for field in IDENTITY_KEY_FIELDS
    }
    unique_count = int(outcome_counts["unique_one_to_one"])
    reused_count = int(outcome_counts["unique_source_identity_reused"])
    tolerance_count = int(outcome_counts["unique_numeric_tolerance_identity"])
    tolerance_ambiguous_count = int(
        outcome_counts["ambiguous_numeric_tolerance_identity"]
    )
    exact_enrichable_count = unique_count + reused_count
    enrichable_count = exact_enrichable_count + tolerance_count
    total = int(len(result))
    audit: dict[str, Any] = {
        "schema_version": "cicids2017-label-blind-identity-bridge-v1",
        "status": (
            "complete_unique_identity_coverage"
            if unique_count == total
            else "incomplete_unique_identity_coverage"
        ),
        "published": False,
        "claim_scope": "diagnostic_identity_recovery_not_independent_final_evaluation",
        "join_contract": {
            "frozen_columns_read": "feature_indices_0_through_77_only",
            "frozen_label_column_read": False,
            "parquet_columns_read": list(PARQUET_COLUMNS),
            "parquet_label_column_read": False,
            "quick_key_is_screening_only": True,
            "exact_confirmation": "sha256(canonical_little_endian_float64_bytes_of_all_78_features)",
            "identity_admission": (
                "one_distinct_packet_linkage_identity_after_exact_78_feature_match_or_"
                "one_unique_quick_candidate_with_only_derived_float_drift_within_1e-9"
            ),
            "numeric_tolerance": {"rtol": 1e-9, "atol": 1e-9},
            "numeric_tolerance_allowed_columns": sorted(DERIVED_FLOAT_COLUMNS),
            "strict_one_to_one_reported_separately": True,
            "ambiguous_rows_guessed": False,
            "missing_rows_imputed": False,
        },
        "frozen": {
            "rows": total,
            "files": [
                {
                    "path": str(path),
                    "rows": int(frozen.row_counts[path.name]),
                    "sha256": str(frozen.sha256[path.name]),
                }
                for path in frozen.paths
            ],
            "unique_feature_fingerprints": int(len(frozen_counts)),
        },
        "source": {
            "rows_scanned": int(source_rows_scanned),
            "quick_candidates": int(quick_candidates),
            "exact_candidates": int(exact_candidates),
            "files": source_files,
        },
        "coverage": {
            "unique_one_to_one_rows": unique_count,
            "unique_source_identity_reused_rows": reused_count,
            "exact_uniquely_enrichable_rows": exact_enrichable_count,
            "unique_numeric_tolerance_identity_rows": tolerance_count,
            "uniquely_enrichable_rows": enrichable_count,
            "uniquely_enrichable_fraction": (
                enrichable_count / total if total else 0.0
            ),
            "ambiguous_identity_rows": int(outcome_counts["ambiguous_identity"]),
            "ambiguous_numeric_tolerance_identity_rows": tolerance_ambiguous_count,
            "total_ambiguous_identity_rows": int(
                outcome_counts["ambiguous_identity"] + tolerance_ambiguous_count
            ),
            "ambiguous_rows_with_consensus_identity_fields": consensus_coverage,
            "missing_rows": int(outcome_counts["missing"]),
            "unique_one_to_one_fraction": (unique_count / total if total else 0.0),
        },
        "numeric_drift_diagnostic": {
            "labels_read": False,
            "scope": "missing_exact_match_rows_with_exactly_one_source_quick_key_candidate",
            "rows": int(drift_unique_quick_rows),
            "allclose_rtol_1e9_atol_1e9_rows": int(drift_within_1e9_rows),
            "drift_only_in_derived_float_columns_rows": int(
                drift_allowed_columns_rows
            ),
            "mismatch_cell_count_histogram": {
                str(key): int(value)
                for key, value in sorted(drift_cell_count_histogram.items())
            },
            "mismatch_counts_by_column": {
                key: int(value)
                for key, value in sorted(
                    drift_column_counts.items(), key=lambda item: (-item[1], item[0])
                )
            },
        },
        "limitations": {
            "same_dataset_lineage": True,
            "independent_capture": False,
            "target_was_historically_scored": True,
            "allowed_use": "feature_symmetry_and_packet_linkage_diagnostics_only",
            "forbidden_use": "posthoc_threshold_or_model_selection_claimed_as_independent_final",
        },
    }
    return result, audit


def build_cic2017_identity_bridge(
    *,
    frozen_paths: Sequence[str | Path],
    parquet_paths: Sequence[str | Path],
    output_csv_path: str | Path,
    manifest_path: str | Path,
    batch_size: int = 32768,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    frozen = read_frozen_features(frozen_paths)
    result, audit = bridge_identity_batches(
        frozen,
        iter_parquet_batches(parquet_paths, batch_size=batch_size),
    )
    output = Path(output_csv_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output, index=False, encoding="utf-8", lineterminator="\n")
    manifest = dict(audit)
    manifest["integrity"] = {
        "output_csv": str(output.resolve()),
        "output_csv_sha256": sha256_file(output),
    }
    destination = Path(manifest_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return result, manifest


def _parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--frozen", action="append", required=True, type=Path)
    parser.add_argument("--parquet", action="append", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--batch-size", default=32768, type=int)
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = _parse_args(argv)
    _, manifest = build_cic2017_identity_bridge(
        frozen_paths=args.frozen,
        parquet_paths=args.parquet,
        output_csv_path=args.output,
        manifest_path=args.manifest,
        batch_size=args.batch_size,
    )
    print(json.dumps(manifest["coverage"], ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "Cic2017IdentityBridgeError",
    "FrozenRows",
    "SourceBatch",
    "bridge_identity_batches",
    "build_cic2017_identity_bridge",
    "iter_parquet_batches",
    "read_frozen_features",
]
