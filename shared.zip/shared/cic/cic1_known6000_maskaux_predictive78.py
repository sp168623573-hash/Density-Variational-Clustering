"""Known-only predictive-reconstruction dominated masked MHFD continuation.

One warm continuation of the accepted full78 masked encoder. The original
primary classifier, accepted encoder, geometry and results are never replaced.
"""
from __future__ import annotations
import argparse
from collections import Counter
import io
import json
from pathlib import Path
import time
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import WeightedRandomSampler
from . import cic1_known6000_maskaux78_v1 as original

ROOT,files,core,helpers=original.ROOT,original.files,original.core,original.helpers
BASE=ROOT/'data/external_dev/processed/cic1_known6000_maskaux_predictive78_20261011_v53'
REGDIR=ROOT/'tmp/cic1_known6000_maskaux_predictive78_20261011_v53'
PARENT=dict(path=str(original.BASE/'report.json'),sha256='7b5b0c052b4fc16aec4e944acc6c7f11d0725ec2785f1ffc9a2462a5be7a7106')

def recipe():
    return dict(schema_version='CIC1-known6000-full78-MASK-MHFD-warm-Predictive-final80-v53',hypotheses=1,
        setting='CIC Setting1',input_width=78,fields=78,FIT_original=6000,optimizer_draws=6000,
        initialization='exact prior final80 full78 MASK MHFD state; known-only warm continuation on same6000 FIT, new checkpoint',
        model=original.recipe()['model'],input=original.recipe()['input'],
        loss='0.1 clean coarseCE + .035 clean fineCE(smoothing.01) + 1.0 wholefield masked-only SmoothL1',
        copies='hierarchical draws on6000 unique FIT originals; no traffic copies added',
        mask='same one-field balanced schedule with fixed seed20261011, 6000 actual draws, every78 fields; wholefield tokens/decoder retained',
        seed=20261011,epochs=80,batch_size=128,optimizer='AdamW .001 wd.0002 cosine80 min.0001 clip5',
        checkpoint='fixed final80, no per-epoch heldout inference or checkpoint selection',
        inference='new learned representation only; original primary coarse/fine/threshold remain unchanged',
        training_roles=['FIT'],train_union_unique_rows=6000,optimizer_traffic_rows=6000,
        new_geometry_required=True,unknown_training=False,unknown_values_opened=False,
        source_and_representation_objective_joint=True,preprocessing_fit=False,
        CUBLAS_WORKSPACE_CONFIG=':4096:8 supplied before Python process',
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)

def freeze():
    pins={};p=files.js(PARENT,pins);oldreg=files.js(p['registry'],pins)
    files.require(p['epochs_completed']==80 and p['unknown_values_opened'] is False,'real final80 known-only warm start')
    assets=dict(native=oldreg['native'],units=oldreg['units'],warm_model=p['files']['model'])
    for a in assets.values():files.read(a,pins)
    sources={str(Path(m.__file__).resolve()):files.item(m.__file__) for m in (
        original,core,core.previous,core.mask_core,helpers,helpers.network,core.output_io,core.model,core.config,files)}
    sources[str(Path(__file__).resolve())]=files.item(__file__)
    for a in sources.values():files.read(a,pins)
    files.require(not BASE.exists() and not REGDIR.exists(),'fresh Predictive sidecar files only')
    REGDIR.mkdir(parents=True,exist_ok=False)
    return files.write(REGDIR/'registry_before_known_only_warm_Predictive_training.json',
        dict(policy=recipe(),assets=assets,sources=sources,parent=PARENT,
            field_map=oldreg['field_map'],field_map_sha256=oldreg['field_map_sha256'],warm_model_state_sha256=p['model_state_sha256'],
            output=str(BASE),input_sha256=pins,unknown_numeric_decodes=0,unknown_truth_decodes=0))

def balanced_schedule(rows,epoch):
    rng=np.random.default_rng(np.random.SeedSequence([20261011,epoch]));names=rng.permutation(78)
    return names[np.arange(rows)%78][rng.permutation(rows)].astype(np.int64)

def objective(net,x,coarse,fine,mask,original_rows):
    core.mask_core._features(x,78)
    files.require(coarse.dtype==fine.dtype==torch.int64 and torch.equal(coarse==0,fine==0),'known BEN/KNA truefine FIT labels only')
    clean=net(x);masked=net.forward_masked(x,mask)
    scales=torch.ones(78,dtype=torch.float64,device=x.device)
    recon=core.mask_core.masked_reconstruction_loss(masked['reconstruction'],x,masked['masked_columns'],scales)
    coarse_loss=F.cross_entropy(clean['coarse_logits'],coarse)
    fine_loss=F.cross_entropy(clean['fine_logits'],fine,label_smoothing=.01)
    loss=.1*coarse_loss+.035*fine_loss+1.0*recon
    files.require(bool(torch.isfinite(loss)),'finite predictive-dominated wholefield masked and clean losses')
    return dict(loss=loss,coarse_loss=coarse_loss,fine_loss=fine_loss,masked_loss=recon)

def train(path,sha):
    pins={};ref=dict(path=str(Path(path).resolve()),sha256=sha);reg=files.js(ref,pins)
    files.require(reg['policy']==recipe() and reg['sources'][str(Path(__file__).resolve())]==files.item(__file__),'own frozen warm Predictive source')
    for a in reg['sources'].values():files.read(a,pins)
    files.require(not BASE.exists(),'fresh warm Predictive training output');BASE.mkdir(parents=True,exist_ok=False)
    before=core.capture_runtime_flags();started=time.perf_counter()
    report=dict(schema_version=recipe()['schema_version'],policy=recipe(),registry=ref,files={},counts=dict(training_runs=0),
        unknown_values_opened=False,known_query_numeric_decodes=0,unknown_truth_decodes=0,
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        report['execution_stage']='read_knownFIT'
        raw=core.previous.archive(reg['assets']['native'],('FIT_native78','FIT_ids','FIT_y_fine','FIT_y_coarse'),pins)
        units=np.asarray(files.js(reg['assets']['units'],pins)['native78'])
        x=((np.sign(raw['FIT_native78'])*np.log1p(np.abs(raw['FIT_native78'])))/units).astype(np.float32)
        counts=Counter(raw['FIT_y_fine'].tolist())
        files.require(x.shape==(6000,78) and np.isfinite(x).all() and len(np.unique(raw['FIT_ids']))==6000
            and set(counts)==set(range(9)) and min(counts.values())>=20,'real6000 knownFIT eachfamily minimum20')
        core.previous.save(BASE,'genuineFIT6000_inputs_before_warm_training',dict(features=x,ids=raw['FIT_ids'],fine=raw['FIT_y_fine'],coarse=raw['FIT_y_coarse']),report)
        report['execution_stage']='load_exact_warm_model'
        saved=torch.load(io.BytesIO(files.read(reg['assets']['warm_model'],pins)),map_location='cpu',weights_only=True)
        fmap=core.field_map_from_state(reg['field_map'])
        files.require(saved['field_map']==reg['field_map'] and fmap.file_sha256==reg['field_map_sha256'], 'original full78 field map')
        torch.set_num_threads(4);helpers.network.set_seed(20261011)
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu');net=core.ExpandedWholeFieldMaskedMHFD(fmap,9).to(device)
        net.load_state_dict(saved['state_dict'],strict=True)
        files.require(core.output_io.state_digest(net)==reg['warm_model_state_sha256'],'exact warm original final80 checkpoint')
        opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.0002)
        sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=80,eta_min=.0001)
        scaler=torch.amp.GradScaler('cuda',enabled=device.type=='cuda')
        sampler=WeightedRandomSampler(helpers.network._hierarchical_sample_weights(raw['FIT_y_fine']),num_samples=6000,
            replacement=True,generator=torch.Generator().manual_seed(20261011))
        report['files']['prefit']=files.write(BASE/'frozen_policy_before_training.json',dict(registry=ref,policy=recipe(),warm_model=reg['assets']['warm_model']))
        history=[];began=time.perf_counter();report['counts']['training_runs']=1
        for epoch in range(1,81):
            report['execution_stage']='known_training_epoch_'+str(epoch)
            net.train();idx=np.asarray(list(sampler),np.int64);masks=balanced_schedule(6000,epoch-1)
            sums={k:0. for k in ('loss','coarse_loss','fine_loss','masked_loss')};seen=0
            for first in range(0,6000,128):
                ix=idx[first:first+128];xb=torch.from_numpy(x[ix].copy()).to(device)
                cb=torch.from_numpy(raw['FIT_y_coarse'][ix].copy()).to(device);fb=torch.from_numpy(raw['FIT_y_fine'][ix].copy()).to(device)
                mask=torch.from_numpy(masks[first:first+len(ix)].copy()).to(device);oi=torch.from_numpy(ix.copy()).to(device)
                opt.zero_grad(set_to_none=True)
                with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=device.type=='cuda'):
                    values=objective(net,xb,cb,fb,mask,oi)
                scaler.scale(values['loss']).backward();scaler.unscale_(opt);nn.utils.clip_grad_norm_(net.parameters(),5.)
                scaler.step(opt);scaler.update()
                for key in sums:sums[key]+=float(values[key].detach())*len(ix)
                seen+=len(ix)
            sched.step();history.append(dict(epoch=epoch,optimizer_draws=seen,**{k:a/seen for k,a in sums.items()}))
            core.save_epoch_history(BASE,history,epoch,report)
            if epoch==1 or epoch%10==0:print(f'[CIC1 MASK78 warm Predictive] epoch={epoch}/80 loss={sums["loss"]/seen:.6f} masked={sums["masked_loss"]/seen:.6f} elapsed={time.perf_counter()-began:.1f}s',flush=True)
        report.update(training_seconds=time.perf_counter()-began,epochs_completed=80,device=str(device),actual_FIT_fine_support=dict(counts))
        state=core.output_io.state_digest(net);checkpoint=BASE/'full78_maskaux_warm_Predictive_final80.pt'
        with checkpoint.open('xb') as f:torch.save(dict(state_dict={k:a.detach().cpu() for k,a in net.state_dict().items()},
            input_dim=78,classes=list(original.FAMILIES),field_map=reg['field_map'],field_map_sha256=fmap.file_sha256,
            model_state_sha256=state,warm_model=reg['assets']['warm_model'],training_policy=recipe()),f)
        report.update(model_state_sha256=state,execution_status='knownFIT_only_warm_Predictive_training_completed',
            new_geometry_or_reconstruction_CAL_required=True,primary_classifier_unchanged=True)
        report['files']['model']=files.item(checkpoint)
        for p,wanted in pins.items():files.require(files.item(p)['sha256']==wanted,'warm source/model/input immutable')
    except Exception as error:report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        after=core.restore_runtime_flags(before);report['runtime_restoration']=dict(before=before,after=after,all_flags_restored=after==before)
        report.update(wall_seconds=time.perf_counter()-started,input_sha256=pins);files.write(BASE/'report.json',report)
    return files.item(BASE/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','train'),required=True)
    p.add_argument('--registry');p.add_argument('--registry-sha256');a=p.parse_args()
    print(json.dumps(freeze() if a.phase=='freeze' else train(a.registry,a.registry_sha256)))
