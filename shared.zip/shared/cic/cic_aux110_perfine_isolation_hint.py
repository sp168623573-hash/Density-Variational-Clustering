"""Frozen AUX110 per-known-fine density hint; Root-only known/current numeric entries.

V2 separates the one installed sklearn source pin from workspace data pins.
Only the candidate hint changes from nearest-distance ratio to negative
IsolationForest.score_samples. Existing primary classifiers, fixed110 geometry,
learned-distance DVC, affinity and noise correction remain unchanged. Metadata
freeze reads JSON/headers/IDs/groups/known FIT fine labels only, never feature
values, probabilities, query labels, or fitted models.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import joblib
import numpy as np

from . import cic_fit6000_aux110_known_bridge_v1 as bridge

nn, geometry, ROOT = bridge.nn, bridge.geometry_core, bridge.ROOT
require, checked, read = nn.require, nn.checked, nn.read
json_new, npz_new = nn.json_new, nn.npz_new
SCHEMA = "CIC-owned-AUX110-perfine-IsolationForest512-density-hint-runtime-pin-v2"
SEED = 20261010
SOURCES = {
    "CIC Setting1": dict(
        probe=dict(path="data/external_dev/processed/cic1_fit6000_aux110_known_20261010_v1/known_probe/report.json", sha256="883d12d8b023c2000124204e41ea10e9e4a63481556a2addb43ca788ee622389"),
        previous=dict(path="data/external_dev/processed/cic1_fit6000_aux110_current4056_20261010_agent_recovery_v1/report.json", sha256="1517f4724bb4a091f70e506858e0e6dede3a93cc23c7c52437d314952d8302ad"),
        query_registry=dict(path="data/external_dev/processed/cic1_fit6000_aux110_current4056_20261010_agent_v1/registry_before_existing_query_features.json", sha256="d5f6d209b907994f9c11ec3b7b933d62aa3d49c0a6814cc6918a61a9ddac84b9"),
        FIT_rows=6000, CP_rows=900, CAL_rows=900, query_rows=4056,
        query_groups=4056, known_overlap=900),
    "CIC Setting2": dict(
        probe=dict(path="data/external_dev/processed/cic2_fit6000_aux110_known_20261010_v1/known_probe/report.json", sha256="9a45c25806078769828cbc7c13b2adde9df2a509deb278e27becfab263e105ca"),
        previous=dict(path="data/external_dev/processed/cic2_fit6000_aux110_Sample3184_20261010_agent_reporting_recovery_v1/report.json", sha256="b79519bd67e1a016c82b578fe1741324e422790cb09f3ea954d68c421d276dcb"),
        query_registry=dict(path="data/external_dev/processed/cic2_fit6000_aux110_Sample3184_20261010_agent_v2/registry_before_existing_query_features.json", sha256="e1aef014e64fe2d7871ed68e9f29b80656632d49dec82c6ba117f8c997455998"),
        FIT_rows=5987, CP_rows=882, CAL_rows=882, query_rows=3184,
        query_groups=2524, known_overlap=7),
}


def recipe(setting):
    require(setting in SOURCES, "own_CIC_setting")
    return dict(schema_version=SCHEMA, setting=setting,
        original_primary_coarse="unchanged cached original NN50/native78 forest blend and threshold",
        predictor="one fixed per-true-known-fine IsolationForest fitted only on genuine unique FIT110",
        detector=dict(n_estimators=512, max_samples="min(256, unique FIT group count for this true fine)",
            contamination="auto", max_features=1.0, bootstrap=False, n_jobs=4,
            random_state="20261010 + fine index", verbose=0, warm_start=False),
        score="negative score_samples; contamination offset, decision_function and predict unused",
        selector="original primary NN predicted fine for CAL, CP and complete cached query, identically",
        geometry="same sealed native78 signedlog/FITunits first, AUX32/FITunits last; no feature/ref/metric/unit changes",
        cutoffs="one new CAL original-row predicted-coarse conditional finite99 order statistic, strict greater",
        CP_control="original known integer gates plus paired zero loss before opening cached complete query",
        second_stage="same owned110 learned-distance DVC then density affinity/reconstruction/local-density noise correction",
        source_scope="same already observed warm DEV; all IDs retained; CIC2 overlap7 disclosed and unfiltered",
        targets_or_query_used_for_fit=False, unknown_model_fit=False, cutoff_sweep=False,
        NN_or_forest_forward_replay=False, accepted_baseline_replaced=False,
        status="FAIL_TARGET99", published=False, final_test_executed=False)


def selected(item, keys, pins):
    with np.load(checked(item, pins), allow_pickle=False) as a:
        return {key: a[key].copy() for key in keys}


def integer_gates(truth, prediction, known_only=False):
    result = {}
    for code, name in enumerate(("BEN", "KNA") if known_only else ("BEN", "KNA", "UNA")):
        mask = truth == code
        support = int(mask.sum())
        correct = int(np.sum(mask & (prediction == code)))
        required = (99 * support + 99) // 100
        result[name] = dict(correct=correct, support=support, required=required,
            passed=support > 0 and correct >= required, gap=max(required-correct, 0))
    return result


def effect(truth, before, after):
    old, new = integer_gates(truth, before), integer_gates(truth, after)
    delta = {name: new[name]["correct"] - old[name]["correct"] for name in old}
    verdict = ("UP" if all(v >= 0 for v in delta.values()) and any(delta.values()) else
               "DOWN" if all(v <= 0 for v in delta.values()) and any(delta.values()) else
               "MIXED" if any(delta.values()) else "UNCHANGED")
    return dict(verdict=verdict, correct_delta=delta, same_original_IDs_and_order=True,
                previous_gates=old, candidate_gates=new,
                gain=int(np.sum((before != truth) & (after == truth))),
                loss=int(np.sum((before == truth) & (after != truth))))


class PerFineIsolationHint:
    """Known-only detector; no query/IDs/labels enter fit or detector score API."""
    def __init__(self, models):
        self.models = models

    @classmethod
    def fit_known(cls, features, true_fine, *, factory=None):
        if factory is None:
            from sklearn.ensemble import IsolationForest
            factory = IsolationForest
        require(features.dtype == np.float64 and features.ndim == 2 and features.shape[1] == 110,
                "finite_unique_original_FIT110_required")
        require(np.isfinite(features).all() and true_fine.shape == (len(features),)
                and np.isin(true_fine, range(9)).all(), "own_FIT_fine_labels_only")
        models = {}
        for label in range(9):
            rows = np.flatnonzero(true_fine == label)
            require(len(rows) >= 2, "at_least_two_unique_known_FIT_groups_per_fine")
            detector = factory(n_estimators=512, max_samples=min(256, len(rows)), contamination="auto",
                max_features=1.0, bootstrap=False, n_jobs=4, random_state=SEED+label,
                verbose=0, warm_start=False)
            detector.fit(features[rows])
            models[label] = detector
        return cls(models)

    def score(self, features, predicted_fine):
        require(features.dtype == np.float64 and features.ndim == 2 and features.shape[1] == 110
                and np.isfinite(features).all() and predicted_fine.shape == (len(features),)
                and np.isin(predicted_fine, range(9)).all(), "same_finite110_original_primary_NN_fine_selector")
        value = np.empty(len(features), np.float64)
        for label in np.unique(predicted_fine):
            rows = np.flatnonzero(predicted_fine == label)
            value[rows] = -np.asarray(self.models[int(label)].score_samples(features[rows]), np.float64)
        require(np.isfinite(value).all(), "finite_negative_score_samples_only")
        return value


def freeze(setting, output_directory):
    """Headers and metadata only, including genuine FIT fine counts; no features."""
    source, pins = SOURCES[setting], {}
    out = Path(output_directory).resolve()
    require(out.is_relative_to(ROOT) and out != ROOT, "fresh_workspace_child")
    out.mkdir(parents=True, exist_ok=False)
    probe = read(source["probe"], pins)
    previous = read(source["previous"], pins)
    query_reg = read(source["query_registry"], pins)
    known_reg = read(probe["registry"], pins)
    prepared = read(probe["prepared"], pins)
    require(probe["known_probe_passed"] and all(v == 0 for v in probe["known_CP_loss"].values()),
            "previous_same110_originalCP_has_valid_primary_identity")
    require(query_reg["setting"] == setting and query_reg["auxiliary_model"] == known_reg["new_aux_model"]
            and query_reg["metric"] == probe["files"]["metric"] and query_reg["known110"] == prepared["material"],
            "exact_same_setting_primary_auxiliary_and_owned110")
    envelope = read(probe["files"]["metric"], pins)
    require(envelope["setting"] == setting and envelope["aux_model"] == query_reg["auxiliary_model"]
            and envelope["known_arrays"] == known_reg["new_known_arrays"], "frozen_metric_source_coupling")
    if setting == "CIC Setting1":
        failed = read(previous["source_failure"], pins)
        query = failed["files"]["full_query110_before_score"]
        evaluation = previous["files"]["postseal_evaluation_and_comparison"]
        pred_seal = previous["files"]["prediction_seal_before_truth"]
    else:
        failed = read(previous["source_failed_report"], pins)
        query = failed["files"]["full_query110_before_score"]
        evaluation = previous["evaluation"]
        pred_seal = previous["prediction_seal"]
    for item in (prepared["material"], query, evaluation, pred_seal, probe["files"]["reference_radius"]):
        checked(item, pins)
    headers = dict(known110=nn.header_tools.npz_headers(Path(prepared["material"]["path"])),
                   query110=nn.header_tools.npz_headers(Path(query["path"])),
                   postseal_evaluation=nn.header_tools.npz_headers(Path(evaluation["path"])))
    for role in ("FIT", "CP", "CAL"):
        require(headers["known110"][role+"_Z110"]["shape"] == [source[role+"_rows"], 110], "own_frozen_role_width_and_rows")
    require(headers["query110"]["Z110"]["shape"] == [source["query_rows"], 110], "same_complete_cached_query110")
    meta = selected(prepared["material"], tuple(role+"_"+key for role in ("FIT","CP","CAL") for key in ("ids","groups")) + ("FIT_fine",), pins)
    qmeta = selected(query, ("ids", "groups"), pins)
    refs_meta = selected(probe["files"]["reference_radius"], ("ids", "groups"), pins)
    emeta = selected(evaluation, ("ids",), pins)
    require(np.array_equal(qmeta["ids"], emeta["ids"]) and len(qmeta["ids"]) == source["query_rows"],
            "fixed_complete_query_and_postseal_evaluation_identity_order")
    require(len(set(meta["FIT_groups"].tolist())) == source["FIT_rows"]
            and set(refs_meta["groups"].tolist()) == set(meta["FIT_groups"].tolist()),
            "only_genuine_unique_FIT_groups_no_optimizer_copies")
    counts = np.bincount(meta["FIT_fine"], minlength=9)
    require(len(counts) == 9 and np.all(counts >= 2), "all_true_known_fine_have_actual_FIT_support")
    overlap = sum(g in set().union(*(set(meta[role+"_groups"].tolist()) for role in ("FIT","CP","CAL"))) for g in qmeta["groups"].tolist())
    require(overlap == source["known_overlap"] and len(set(qmeta["groups"].tolist())) == source["query_groups"],
            "existing_overlap_and_unique_density_count_retained_unfiltered")
    if setting == "CIC Setting1":
        require(np.array_equal(qmeta["ids"][:900], meta["CP_ids"]), "same_original900_CP_prefix")
    for module in (Path(__file__), Path(bridge.__file__), Path(geometry.__file__), Path(bridge.learned.__file__), Path(nn.__file__)):
        pins[str(module.resolve())] = nn.sha(module)
    import sklearn.ensemble._iforest as sklearn_source
    pins[str(Path(sklearn_source.__file__).resolve())] = nn.sha(sklearn_source.__file__)
    registry = dict(schema_version=SCHEMA+"-registry-before-IF-fit", setting=setting,
        configuration=recipe(setting), output_directory=str(out), source=source,
        known110=prepared["material"], query110=query, previous_evaluation=evaluation,
        previous_prediction_seal=pred_seal, owned_metric=probe["files"]["metric"],
        owned_reference_radius=probe["files"]["reference_radius"], owned_auxiliary=query_reg["auxiliary_model"],
        known_array_source=known_reg["new_known_arrays"], original_primary_known_gates=query_reg["original_primary_known_gates"],
        true_FIT_fine_group_counts={str(label): int(n) for label,n in enumerate(counts)}, family_order=query_reg["family_order"],
        headers=headers, fixed_current_rows=source["query_rows"], fixed_density_unique_rows=source["query_groups"],
        known_pool_overlap_rows=overlap, overlap_rows_filtered=False, input_sha256=pins,
        primary_CAL_all_known_gates_passed=all(row["passed"] for row in query_reg["original_primary_known_gates"]["CAL"].values()),
        primary_CAL_failure_disclosed=setting == "CIC Setting2", old_truth_flag_reporting_exception_disclosed=setting == "CIC Setting2",
        metadata_known_fine_labels_read=True, feature_numeric_decodes=0, query_truth_decodes=0,
        detector_fits=0, NN_or_forest_model_loads=0, score_calls=0, DVC_calls=0,
        accepted_baseline_replaced=False, status="FAIL_TARGET99", published=False, final_test_executed=False)
    return json_new(out/"registry_before_perfine_IF_fit.json", registry)


def admit(registry_item):
    pins = {}
    reg = read(registry_item, pins)
    require(reg["schema_version"] == SCHEMA+"-registry-before-IF-fit" and reg["configuration"] == recipe(reg["setting"]), "frozen_fixed_IF_recipe")
    import sklearn.ensemble._iforest as runtime_source
    runtime_path = Path(runtime_source.__file__).resolve()
    for path, wanted in reg["input_sha256"].items():
        candidate = Path(path).resolve()
        if candidate == runtime_path:
            require(nn.sha(candidate) == wanted, "installed_IF_runtime_source_pin_changed")
            pins[str(candidate)] = wanted
        else:
            # Feature/model/label assets retain the strict workspace boundary.
            checked(dict(path=path, sha256=wanted), pins)
    return reg, pins


def metric_from_registry(reg, pins):
    envelope = read(reg["owned_metric"], pins)
    require(envelope["setting"] == reg["setting"] and envelope["aux_model"] == reg["owned_auxiliary"]
            and envelope["known_arrays"] == reg["known_array_source"], "same_setting_owned_frozen110_metric")
    return bridge.learned.PaperVariationalPairMetric.from_state(envelope["metric_payload"])


def role_query(fields, role):
    return {key: fields[role+"_"+key] for key in ("ids", "groups", "Z110", "stage1", "predicted_fine")}


def report_base(reg):
    return dict(schema_version=SCHEMA, setting=reg["setting"], configuration=reg["configuration"], files={},
        DVC_calls=0, detector_fits=0, new_metric_fits=0, new_units_fits=0, CAL_cutoff_fits=0,
        NN_forward_calls=0, forest_forward_calls=0, auxiliary_forward_calls=0,
        query_detector_or_units_or_cutoff_fits=0, prediction_sealed=False, truth_opened=False,
        accepted_baseline_replaced=False, status="FAIL_TARGET99", published=False, final_test_executed=False)


def known(registry_item):
    """ROOT ONLY: fit unique known groups, CAL one cut, CP one complete route."""
    reg, pins = admit(registry_item)
    out = Path(reg["output_directory"])/"known"
    out.mkdir(exist_ok=False)
    report, began, stage = report_base(reg), time.perf_counter(), "unique_known_FIT_perfine_IF512"
    try:
        fields = selected(reg["known110"], ("FIT_Z110", "FIT_fine", "FIT_groups", "FIT_ids")+
            tuple(role+"_"+key for role in ("CP","CAL") for key in ("ids","groups","Z110","stage1","predicted_fine")), pins)
        require(len(set(fields["FIT_groups"].tolist())) == len(fields["FIT_Z110"]) == reg["source"]["FIT_rows"], "genuine_unique_FIT_no_copies")
        counts = np.bincount(fields["FIT_fine"], minlength=9)
        require({str(i):int(n) for i,n in enumerate(counts)} == reg["true_FIT_fine_group_counts"], "same_metadata_FIT_fine_support")
        train_began = time.perf_counter()
        hint = PerFineIsolationHint.fit_known(fields["FIT_Z110"], fields["FIT_fine"])
        report["detector_training_seconds"] = time.perf_counter()-train_began
        report["detector_fits"] = 9
        model_path = out/"FIT_only_perfine_IF512.joblib"
        joblib.dump(hint, model_path)
        report["files"]["model"] = dict(path=str(model_path), sha256=nn.sha(model_path))
        before = joblib.hash(hint)
        stage = "same_primary_CAL_once_IF_scores_and_new_conditional99_cutoffs"
        cal = hint.score(fields["CAL_Z110"], fields["CAL_predicted_fine"])
        report["CAL_score_calls"] = 1
        report["files"]["CAL_scores_before_cutoffs"] = npz_new(out/"CAL_IF_scores_before_cutoffs.npz",
            dict(ids=fields["CAL_ids"], score=cal, stage1=fields["CAL_stage1"], predicted_fine=fields["CAL_predicted_fine"]), pins)
        cutoffs = geometry.dvc.calibrate_known_cutoffs(cal, fields["CAL_stage1"])
        report["CAL_cutoff_fits"] = 1
        report["files"]["cutoffs"] = json_new(out/"CAL_IF_conditional99_cutoffs_before_CP.json",
            dict(cutoffs=cutoffs, calibration_source=report["files"]["CAL_scores_before_cutoffs"], model=report["files"]["model"],
                 unknown_used=False, strict_greater=True, contamination_offset_used=False), pins)
        stage = "same_original_CP_IF_hint_owned110_DVC_and_seal_before_truth"
        cp = role_query(fields,"CP")
        score = hint.score(cp["Z110"], cp["predicted_fine"])
        report["CP_score_calls"] = 1
        prediction, raw, retained = geometry.route(metric_from_registry(reg,pins), cp, score, cutoffs, out, "original_CP", report)
        require(report["DVC_calls"] == 1, "exact_one_CP_DVC")
        report["files"]["prediction_seal"] = json_new(out/"original_CP_prediction_seal_before_truth.json",
            dict(prediction=report["files"]["original_CP_current_predictions_before_truth"], model=report["files"]["model"],
                cutoffs=report["files"]["cutoffs"], owned_metric=reg["owned_metric"], true_labels_opened=False), pins)
        report["prediction_sealed"] = True
        truth = selected(reg["known110"], ("CP_truth",), pins)["CP_truth"]
        report["truth_opened"] = True
        gates = integer_gates(truth,prediction,known_only=True)
        baseline = integer_gates(truth,cp["stage1"],known_only=True)
        loss = {name:int(np.sum((truth == code) & (cp["stage1"] == code) & (prediction != code))) for code,name in enumerate(("BEN","KNA"))}
        require(joblib.hash(hint) == before, "IF_state_unchanged_by_CAL_and_CP_scoring")
        passed = all(row["passed"] for row in gates.values()) and all(v == 0 for v in loss.values())
        report.update(execution_status="completed_known_CP_control", known_CP_gates=gates, original_primary_CP_gates=baseline,
            known_CP_correct_loss=loss, known_CP_passed=passed, current_query_allowed=passed,
            known_CP_raw=int(raw.sum()), known_CP_retained=int(retained.sum()), metrics_evaluated=True,
            primary_existing_known_gates=reg["original_primary_known_gates"],
            primary_CAL_all_known_gates_passed=reg["primary_CAL_all_known_gates_passed"], primary_CAL_failure_disclosed=reg["primary_CAL_failure_disclosed"],
            detector_state_before_scoring=before, detector_state_after_scoring=joblib.hash(hint),
            existing_complete_query_numeric_opened=False)
    except Exception as error:
        report.update(execution_status="execution_failed",failed_stage=stage,error_type=type(error).__name__,error_message=str(error))
        raise
    finally:
        report.update(wall_seconds=time.perf_counter()-began, registry=registry_item, input_sha256=pins)
        item = json_new(out/"report.json",report)
    return item


def current(registry_item, known_report_item):
    """ROOT ONLY: cached same110 once; no NN, forest, embedding, ratio replay."""
    reg, pins = admit(registry_item)
    control = read(known_report_item,pins)
    require(control["registry"] == registry_item and control["known_CP_passed"] and control["current_query_allowed"]
            and control["detector_fits"] == 9 and control["CAL_cutoff_fits"] == 1, "original_CP_integer99_and_zero_loss_before_current_query")
    out = Path(reg["output_directory"])/"current"
    out.mkdir(exist_ok=False)
    report, began, stage = report_base(reg), time.perf_counter(), "restore_frozen_IF_metric_and_closed_query"
    try:
        hint = joblib.load(checked(control["files"]["model"],pins))
        require(isinstance(hint, PerFineIsolationHint), "own_saved_IF_models_no_fit")
        state_before = joblib.hash(hint)
        cutoffs = read(control["files"]["cutoffs"],pins)["cutoffs"]
        query = selected(reg["query110"], ("ids","groups","Z110","stage1","predicted_fine"), pins)
        require(len(query["ids"]) == reg["fixed_current_rows"] and len(set(query["groups"].tolist())) == reg["fixed_density_unique_rows"], "all_original_cached_groups_and_IDs_retained")
        stage = "once_cached_complete110_IF_hint_then_same_owned110_DVC"
        score = hint.score(query["Z110"],query["predicted_fine"])
        report["query_score_calls"] = 1
        prediction, raw, retained = geometry.route(metric_from_registry(reg,pins),query,score,cutoffs,out,"complete_query",report)
        require(report["DVC_calls"] == 1, "one_complete_query_DVC_no_replay")
        require(joblib.hash(hint) == state_before, "frozen_IF_state_unchanged_by_query_scoring")
        report["files"]["prediction_seal"] = json_new(out/"complete_prediction_seal_before_truth.json",
            dict(prediction=report["files"]["complete_query_current_predictions_before_truth"], model=control["files"]["model"],
                cutoffs=control["files"]["cutoffs"], owned_metric=reg["owned_metric"], all_original_IDs_retained=True,
                true_labels_opened=False, previous_predictions_opened=False, query_model_or_cutoff_fits=0), pins)
        report["prediction_sealed"] = True
        stage = "postseal_saved_truth_and_previous_same110_comparisons"
        evaluation = selected(reg["previous_evaluation"], ("ids","truth","prediction","old_comparator"), pins)
        report["truth_opened"] = True
        require(np.array_equal(query["ids"],evaluation["ids"]), "same_fixed_query_ID_order_after_seal")
        truth, previous = evaluation["truth"], evaluation["prediction"]
        gates = integer_gates(truth,prediction)
        loss = {name:int(np.sum((truth == code) & (query["stage1"] == code) & (prediction != code))) for code,name in enumerate(("BEN","KNA"))}
        report["files"]["postseal_evaluation"] = npz_new(out/"postseal_evaluation_and_same110_comparison.npz",
            dict(ids=query["ids"],truth=truth,prediction=prediction,primary_prediction=query["stage1"], previous_same110_prediction=previous,
                 retained_baseline_or_historical_prediction=evaluation["old_comparator"]), pins)
        report.update(execution_status="completed_same110_perfine_IF_hint_current_DEV", original_gates=gates,
            all_three_original_integer99_passed=all(row["passed"] for row in gates.values()),
            EffectDelta=effect(truth,previous,prediction), comparison_scope="same frozen original primary/new6000aux/owned110 geometry; only candidate hint changed from distance ratio",
            original_query_rows=len(truth), density_unique_rows=reg["fixed_density_unique_rows"],
            raw_candidates=int(raw.sum()),retained_candidates=int(retained.sum()),
            known_correct_loss_vs_frozen_primary=loss,known_loss0_passed=all(v == 0 for v in loss.values()),
            known_pool_overlap_rows=reg["known_pool_overlap_rows"],overlap_rows_filtered=False,
            primary_existing_known_gates=reg["original_primary_known_gates"],
            primary_CAL_failure_disclosed=reg["primary_CAL_failure_disclosed"],
            current_source_warm_DEV=True,physical_event_independence_claimed=False,metrics_evaluated=True,
            detector_state_before_query_score=state_before,detector_state_after_query_score=joblib.hash(hint),
            current_wall_is_training_time=False)
        if reg["setting"] == "CIC Setting1":
            report["EffectDelta_vs_retained_T41_799"] = effect(truth,evaluation["old_comparator"],prediction)
            report["retained_baseline_comparison_scope"] = "same fixed4056 rows; representation changed from older retained799, not isolated hint effect"
        else:
            report["historical_population_comparison"] = dict(verdict="NOT_COMPARABLE",reason="historical original model/training pool differs",
                original_gates=integer_gates(truth,evaluation["old_comparator"]))
    except Exception as error:
        report.update(execution_status="execution_failed",failed_stage=stage,error_type=type(error).__name__,error_message=str(error))
        raise
    finally:
        report.update(wall_seconds=time.perf_counter()-began, registry=registry_item, known_control=known_report_item,input_sha256=pins)
        item = json_new(out/"report.json",report)
    return item


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="phase",required=True)
    f = sub.add_parser("freeze"); f.add_argument("--setting", choices=list(SOURCES),required=True); f.add_argument("--output-directory",required=True)
    k = sub.add_parser("known"); k.add_argument("--registry-path",required=True); k.add_argument("--registry-sha256",required=True)
    c = sub.add_parser("current"); c.add_argument("--registry-path",required=True); c.add_argument("--registry-sha256",required=True)
    c.add_argument("--known-report-path",required=True); c.add_argument("--known-report-sha256",required=True)
    args = parser.parse_args()
    if args.phase == "freeze":
        item = freeze(args.setting,args.output_directory)
    else:
        registry = dict(path=str(Path(args.registry_path).resolve()),sha256=args.registry_sha256)
        item = known(registry) if args.phase == "known" else current(registry,dict(path=str(Path(args.known_report_path).resolve()),sha256=args.known_report_sha256))
    print(json.dumps(item,ensure_ascii=False))


if __name__ == "__main__":
    main()
