"""Own CIC2 full78 conditional masked Student3 train/known/current runtime."""
from __future__ import annotations
import argparse
import hashlib
import inspect
import json
import os
from pathlib import Path
import time
import numpy as np
import torch
from torch import nn
from torch.utils.data import WeightedRandomSampler
from threadpoolctl import threadpool_limits
from . import cic2_coarse_conditional_masked_decoder_architecture_v65 as arch
from . import cic2_conditional78_clean110_pair_metric_v65 as learned
from . import cic2_conditional78_clean110_dvc_v65 as dvc
from . import cic2_shared_full78_mhfd_isolated_v48 as warm
from . import whole_field_mask_mhfd_v1 as mask
from . import model as network
from . import config
from . import artifact_api_preflight_v52 as api

ROOT,h,old,current=warm.ROOT,warm.h,warm.aligned,warm.current
BASE=ROOT/'data/external_dev/processed/cic2_coarse_conditional78_20261011_v65'
REG=ROOT/'tmp/target99_iteration_20261011_v65/CIC2_coarse_conditional78_registry_before_fit.json'
FIELD_MAP=ROOT/'tmp/target99_iteration_20261011_v65/CIC2_actual_native78_wholefield_map_before_fit.json'
WARM_REPORT=dict(path=str(warm.OUT/'known/report.json'),sha256='061e1930f495cbe0c581ddbee84ea55bec30699d417aca226fd96b53c187676c')
ANCESTRY_UPPER=361.64334740000777+35.77316340000834

def policy():
    actual_recipe={key:value for key,value in arch.fixed_recipe().items() if key not in ('training_started','weights_loaded_in_preparation','actual_training_seconds')}
    actual_recipe['schema_version']='CIC2-own5987-masked78-truecoarseconditional-Student3-final30-actual-v65'
    return dict(recipe=actual_recipe,schema_version='CIC2-full78-owncoarseconditional-Student3-matching110-runtime-v65',
        encoder_input='actual ownwarm signedlog/genuineFIT mean/std float32 for FIT/CP/CAL/current, unchanged frozen transforms',
        decoder_target='same standardized78 float32 encoder-input space; variance parameterV=3*Student scale squared',
        geometry_native='native78 signedlog/genuineFIT columnRMS; separate from encoder/decoder zscore targetspace',
        geometry_embedding='this ownnewencoder clean32/genuineFIT owncolumnRMS',
        old_primary='oldV46 stage1/predictedfine/baseline immutable arrays; auxiliary newheads never replace originalprimary',
        known_gate='bothoriginal882 andreport900 CP/CAL BEN/KNA integer99 AND no oldcorrect row loss',
        current_acceptance='same3184 allthree oldcorrectloss0 and UP only; no finalclaim',
        FIT_mask_views='6000 realoptimizer views per epoch, including original13 Heart trainingcopies; no density/reference copies',
        deployment='CPUfloat32 eval/no_grad512 allroles; ownraw outputcondition andhiddenfield sealed before NLL and truths',
        fixed30_no_epoch_choice=True,CAL_once_predictedcoarse99=True,no_threshold_search=True,no_target_unknown_fit=True,
        no_training_timeout_code=True,status='FAIL_TARGET99',published=False,final_test_executed=False)

def sources():
    closed=old.bindings()
    for module in (arch,learned,dvc,warm,mask,network,config,api,inspect.getmodule(dvc.knee_radius)):
        closed[str(Path(module.__file__).resolve())]=h.sha(module.__file__)
    closed[str(Path(__file__).resolve())]=h.sha(__file__)
    return closed

def load(asset,keys,pins):return old.fine.load(asset,tuple(keys),pins)

def field_map_state():
    names=list(config.CIC_FEATURE_COLUMNS)
    h.require(len(names)==len(set(names))==78,'actual canonical native78 ordering')
    return dict(schema_version=mask.FIELD_SCHEMA,selected_width=78,nonempty_group_count=78,
        selected_column_mapping=[dict(selected_index=i,encoded_name=name,original_field=name) for i,name in enumerate(names)],
        groups=[dict(field=name,kind='numeric',selected_columns=[i]) for i,name in enumerate(names)])

def bind_caller_registry(descriptor,pins):
    caller_registry=h.read(descriptor,pins)
    h.require(Path(descriptor['path']).resolve()==REG.resolve() and caller_registry['policy']==policy() and
        caller_registry['output']==str(BASE) and caller_registry['sources']==sources(),
        'actual returned owncaller registry; no source registry shadow/substitution')
    for path,sha in caller_registry['input_sha256'].items():h.checked(dict(path=path,sha256=sha),pins)
    return caller_registry

def freeze():
    pins={};parent=h.read(WARM_REPORT,pins);warm_registry=h.read(parent['registry'],pins)
    k=h.read(warm.KNOWN,pins);primary_registry=h.read(k['registry'],pins);c=h.read(warm.CURRENT,pins)
    h.require(parent['new_MHFD_fit']==1 and parent['training_seconds']>0 and parent['selected_epoch']==60 and
        parent['files']['model']['sha256']==arch.WARM_MODEL_SHA256,'actual completed ownCIC2 plain78 warmcheckpoint')
    h.require(k['own_known_alignment_passed'] and c['prediction_sealed'],'primary controls and wholeV46 baseline exist')
    a=dict(native=warm_registry['assets']['native'],warm_model=parent['files']['model'],encoder_preprocessing=parent['files']['preprocessing'],
        warm_training_inputs=parent['files']['training_inputs'],CP=k['files']['CP_geometry_scores'],CAL=k['files']['CAL_geometry_scores'],
        baseline_known=k['files']['predictions'],current_geometry=c['files']['geometry'],baseline_current=c['files']['predictions'],truth_current=c['files']['postseal_pair'])
    for item in a.values():h.checked(item,pins)
    headers=h.header_tools.npz_headers(a['native']['path']);pre_headers=h.header_tools.npz_headers(a['encoder_preprocessing']['path'])
    h.require(headers['FIT_native78']['shape']==[5987,78] and headers['FIT_training_indices']['shape']==[6000] and
        pre_headers['mean']['shape']==pre_headers['std']['shape']==[78],'actual genuineFIT/optimizer/warmunits headers')
    src=sources()
    for path,sha in src.items():h.checked(dict(path=path,sha256=sha),pins)
    api_result=api.preflight(api_contracts=[dict(module_name='paper_open_set.cic2_conditional78_clean110_pair_metric_v65',function_name='fit_known_metric',
        required_parameters=['z_fit','y_fit_fine','expected_prefit_sha256','known_fine_labels','fit_ids','fit_group_ids','fit_roles'],source_sha256=h.sha(learned.__file__))])
    h.require(not REG.exists() and not BASE.exists() and not FIELD_MAP.exists(),'fresh actualconditional78 protocol')
    REG.parent.mkdir(parents=True,exist_ok=True);a['field_map']=h.json_new(FIELD_MAP,field_map_state());h.checked(a['field_map'],pins)
    own=h.json_new(REG,dict(policy=policy(),sources=src,assets=a,input_sha256=pins,output=str(BASE),native_headers=headers,warm_units_headers=pre_headers,
        API_contract=api_result,numeric_traffic_decodes_before_freeze=0,unknown_numeric_before_known=0))
    bound=bind_caller_registry(own,{})
    h.require(bound['assets']==a and bound['policy']['schema_version']==policy()['schema_version'],'freeze returned own registry binds its own assets')
    return own

def state_sha(net):
    digest=hashlib.sha256()
    for key,value in sorted(net.state_dict().items()):
        a=value.detach().cpu().contiguous().numpy();digest.update(key.encode());digest.update(str(a.dtype).encode());digest.update(str(a.shape).encode());digest.update(a.tobytes())
    return digest.hexdigest()

def make_model(reg,pins):
    raw=Path(h.checked(reg['assets']['field_map'],pins)).read_bytes();fm=mask.FrozenFieldMap(raw,expected_file_sha256=reg['assets']['field_map']['sha256'])
    return arch.CoarseConditionalWhole78MHFD(mask.WholeFieldMaskedMHFD(fm,9))

def encode_input(native,pre):
    x=np.ascontiguousarray((old.guard.signed_log(native)-pre['mean'])/pre['std'],np.float32)
    h.require(x.shape==(len(native),78) and np.isfinite(x).all(),'sameactual ownwarm zscore78 encoder anddecoder target')
    return x

def sampler_weights(fine):
    w=np.empty(len(fine),np.float64)
    for label in range(9):
        selected=fine==label;h.require(selected.any(),'allknownfine genuinepositive');w[selected]=(.5 if label==0 else .5/8)/int(selected.sum())
    return torch.from_numpy(w)

def train(reg,registry,pins,out,r):
    h.require(os.environ.get('CUBLAS_WORKSPACE_CONFIG')==':4096:8','CUBLAS deterministic env beforeCUDA process')
    started=time.perf_counter();a=reg['assets'];fit=load(a['native'],('FIT_native78','FIT_ids','FIT_y_fine','FIT_y_coarse','FIT_training_indices'),pins)
    pre=load(a['encoder_preprocessing'],('mean','std'),pins);x=encode_input(fit['FIT_native78'],pre)
    historical=load(a['warm_training_inputs'],('FIT_features','FIT_ids','FIT_fine','FIT_optimizer_indices'),pins)
    idx=fit['FIT_training_indices'];f=fit['FIT_y_fine'];c=fit['FIT_y_coarse'];groups=old.group_hashes(fit['FIT_native78'])
    h.require(len(np.unique(groups))==5987 and np.array_equal(x,historical['FIT_features']) and np.array_equal(fit['FIT_ids'],historical['FIT_ids']) and
        np.array_equal(f,historical['FIT_fine']) and np.array_equal(idx,historical['FIT_optimizer_indices']),
        'actual warmnumeric input/fine/identity/optimization indices match exactly, notjust tensorstate')
    h.require(idx.shape==(6000,) and np.array_equal(c,(f!=0).astype(np.int64)) and min(int((f[idx]==j).sum()) for j in range(9))>=20 and
        int((np.bincount(idx,minlength=5987)-1).sum())==13,'allknown5987 plus13authorizedcopies; positivefine20 effective')
    network.set_seed(20261011);torch.set_num_threads(4);net=make_model(reg,pins)
    warm_state=torch.load(h.checked(a['warm_model'],pins),map_location='cpu',weights_only=True)
    proof=net.initialize_from_own_CIC2_plain78(warm_state,checkpoint_sha256=a['warm_model']['sha256'])
    r['files']['warm_proof']=h.json_new(out/'actual_ownwarm_tensor_and_input_proof_before_optimizer.json',dict(**proof,
        numeric_FIT_input_exact=True,FIT_fine_ID_indices_exact=True,encoder_input_space=policy()['encoder_input'],decoder_target_space=policy()['decoder_target'],
        source_preprocessing=a['encoder_preprocessing'],source_warm_model=a['warm_model']))
    r['files']['FIT_inputs']=h.npz_new(out/'genuineFIT_zscore78_labels_optimizer_before_training.npz',dict(x78=x,ids=fit['FIT_ids'],fine=f,coarse=c,groups=groups,optimizer_indices=idx),{})
    r['FIT_preprocessing_and_warm_seconds']=time.perf_counter()-started
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu');net.to(device)
    opt=torch.optim.AdamW([p for p in net.parameters() if p.requires_grad],lr=.001,weight_decay=.0002)
    schedule=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=30,eta_min=.0001);scaler=torch.amp.GradScaler('cuda',enabled=device.type=='cuda')
    sampler=WeightedRandomSampler(sampler_weights(f[idx]),num_samples=6000,replacement=True,generator=torch.Generator().manual_seed(20261011))
    r['files']['prefit']=h.json_new(out/'fixedfinal30_before_optimizer.json',dict(policy=policy(),registry=registry,optimizer_rows_per_epoch=6000,original_groups=5987,train_copies=13,
        warm_proof=r['files']['warm_proof'],noCP_CAL_epoch_selection=True,unknown_fit=False))
    if device.type=='cuda':torch.cuda.synchronize()
    started=time.perf_counter();history=[];selected_all=[];fields_all=[]
    for epoch in range(1,31):
        net.train();selected=idx[np.asarray(list(sampler),np.int64)];fields=np.arange(6000,dtype=np.int64)%78
        np.random.default_rng(20261011+epoch).shuffle(fields);selected_all.append(selected);fields_all.append(fields)
        total={name:0. for name in ('loss','coarse_loss','fine_loss','masked_loss')};seen=0
        for first in range(0,6000,128):
            use=selected[first:first+128];features=torch.from_numpy(x[use]).to(device);coarse=torch.from_numpy(c[use]).to(device);truthfine=torch.from_numpy(f[use]).to(device);field=torch.from_numpy(fields[first:first+len(use)]).to(device)
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=device.type=='cuda'):
                values=arch.masked_objective(net,features,coarse,truthfine,field)
            h.require(all(bool(torch.isfinite(v)) for v in values.values()),'finite conditionalStudent3 training objectives')
            scaler.scale(values['loss']).backward();scaler.unscale_(opt);nn.utils.clip_grad_norm_(net.parameters(),5.);scaler.step(opt);scaler.update();seen+=len(use)
            for key in total:total[key]+=float(values[key].detach())*len(use)
        schedule.step();history.append(dict(epoch=epoch,optimizer_rows=seen,**{key:value/seen for key,value in total.items()}))
        if epoch==1 or epoch%10==0:print('CIC2 conditionalStudent3 epoch '+str(epoch)+'/30 loss '+format(history[-1]['loss'],'.6f')+' elapsed '+format(time.perf_counter()-started,'.1f')+'s',flush=True)
    if device.type=='cuda':torch.cuda.synchronize()
    r['NN_training_seconds']=time.perf_counter()-started;net.cpu().eval();sha=state_sha(net)
    p=out/'ownCIC2_coarseconditional78_final30.pt'
    with p.open('xb') as stream:torch.save(dict(state_dict={key:value.detach().cpu() for key,value in net.state_dict().items()},policy=policy(),epoch_final=30,
        fieldmap_sha256=a['field_map']['sha256'],variance_floor=arch.FLOOR,model_state_sha256=sha,encoder_preprocessing=a['encoder_preprocessing'],warm_source=a['warm_model']),stream)
    r['files']['model']=h.descriptor(p);r['files']['history']=h.json_new(out/'actual_fixed30_history.json',history)
    r['files']['actual_optimizer_and_fields']=h.npz_new(out/'actual30epoch_6000_original_indices_and78_fields.npz',dict(original_indices=np.stack(selected_all),masked_fields=np.stack(fields_all)),{})
    r.update(NN_fit=1,epochs_completed=30,device=str(device),model_state_sha256=sha,unknown_fit=False,
        FIT_unique=5987,optimizer_per_epoch=6000,optimizer_copies=13,actual_optimization_encoder_forwards=30*47*2,
        execution_status='ownCIC2_conditionalStudent3_fixed30_trained')

def restore_model(reg,trained,pins):
    saved=torch.load(h.checked(trained['files']['model'],pins),map_location='cpu',weights_only=True)
    h.require(saved['policy']==policy() and saved['fieldmap_sha256']==reg['assets']['field_map']['sha256'] and
        saved['encoder_preprocessing']==reg['assets']['encoder_preprocessing'] and saved['epoch_final']==30 and saved['variance_floor']==arch.FLOOR,'actualfinal30 ownfieldmap/inputunits checkpoint')
    net=make_model(reg,pins);net.load_state_dict(saved['state_dict'],strict=True);net.eval();h.require(state_sha(net)==saved['model_state_sha256']==trained['model_state_sha256'],'wholeconditional mean/variance/encoder state exact')
    return net

@torch.no_grad()
def clean(net,x,r,role):
    before=state_sha(net);parts=[]
    calls=0
    for first in range(0,len(x),512):
        parts.append(net.backbone(torch.from_numpy(x[first:first+512]))['embedding'].detach().float().numpy().copy());calls+=1
    r['NN_forward']+=calls;r[role+'_clean_forward_calls']=calls
    embedding=np.concatenate(parts);h.require(embedding.shape==(len(x),32) and state_sha(net)==before,'actualownclean32 frozen consistentCPUfloat32')
    return embedding

@torch.no_grad()
def all78_score(net,x,condition,ids,out,role,r):
    h.require(condition.dtype==np.int64 and condition.shape==(len(x),) and np.isin(condition,(0,1)).all(),'original primary predictedcoarse packetcondition')
    before=state_sha(net);values=np.empty((len(x),78),np.float64);start=time.perf_counter();negative=0;packets=0
    for field in range(78):
        for first in range(0,len(x),512):
            batch=torch.from_numpy(x[first:first+512]);c=torch.from_numpy(condition[first:first+len(batch)].copy());fields=torch.full((len(batch),),field,dtype=torch.int64)
            raw=net.forward_masked(batch,fields,c);r['NN_forward']+=1;hidden=raw['masked_columns'];expected=torch.zeros_like(batch,dtype=torch.bool);expected[:,field]=True
            h.require(torch.equal(hidden,expected) and torch.equal(raw['decoder_condition'],c),'actual maskedfield and primarycondition tags before scoring')
            raw_arrays={name:value.detach().float().numpy().copy() for name,value in raw.items() if name not in ('masked_columns','decoder_condition')}
            raw_arrays.update(ids=ids[first:first+len(batch)],masked_columns=hidden.numpy().copy(),decoder_condition=c.numpy().copy(),field=np.asarray(field,np.int64))
            key=role+'_field'+str(field).zfill(2)+'_batch'+str(first)+'_conditionalraw_before_NLL'
            r['files'][key]=h.npz_new(out/(key+'.npz'),raw_arrays,{})
            NLL=.5*torch.log(raw['variance']/3.)+2.*torch.log1p((raw['reconstruction'].float()-batch).square()/raw['variance'])
            selected=NLL[:,field].numpy().astype(np.float64);h.require(np.isfinite(selected).all(),'finite trueownfield conditionalStudent3 NLL')
            values[first:first+len(batch),field]=selected;negative+=int(np.sum(selected<0));packets+=1
    h.require(state_sha(net)==before,'everyreal78 maskedCPU packet has unchangedmodel')
    score=values.mean(axis=1);r[role+'_masked78_inference_seconds']=time.perf_counter()-start
    r[role+'_negative_NLL_cells']=negative;r[role+'_actual_masked_packets']=packets
    r['files'][role+'_all78_NLL']=h.npz_new(out/(role+'_all78_actual_conditional_NLL_before_cutoff.npz'),dict(ids=ids,NLL78=values,score=score,original_predictedcoarse=condition),{})
    return score

def known_phase(reg,trained,pins,out,r):
    fit_started=time.perf_counter();net=restore_model(reg,trained,pins);torch.set_num_threads(4);a=reg['assets'];pre=load(a['encoder_preprocessing'],('mean','std'),pins)
    fit=load(a['native'],('FIT_ids','FIT_native78','FIT_y_fine'),pins);x=encode_input(fit['FIT_native78'],pre);embedding=clean(net,x,r,'FIT')
    native_units=old.rms_unique(old.guard.signed_log(fit['FIT_native78']));embedding_units=old.rms_unique(embedding)
    zfit=np.concatenate((old.guard.signed_log(fit['FIT_native78'])/native_units,embedding.astype(np.float64)/embedding_units),axis=1);groups=old.group_hashes(fit['FIT_native78'])
    r['FIT_clean_and_genuineRMS_seconds']=time.perf_counter()-fit_started
    r['files']['units']=h.npz_new(out/'ownconditional_genuineFIT_nativeRMS78_embeddingRMS32.npz',dict(native78=native_units,embedding32=embedding_units),{})
    r['files']['FIT_geometry']=h.npz_new(out/'ownconditional_genuine5987_clean110_before_metric.npz',dict(ids=fit['FIT_ids'],groups=groups,Z110=zfit,embedding32=embedding,true_fine=fit['FIT_y_fine']),{})
    kwargs=dict(known_fine_labels=list(range(9)),fit_ids=fit['FIT_ids'].tolist(),fit_group_ids=groups.tolist(),fit_roles=['FIT']*5987)
    started=time.perf_counter();p=learned.prefit_descriptor(zfit,fit['FIT_y_fine'],**kwargs);r['metric_prefit_seconds']=time.perf_counter()-started
    r['files']['metric_prefit']=h.json_new(out/'fresh_ownconditional110_pairplan_before_optimizer.json',p)
    started=time.perf_counter();metric=learned.fit_known_metric(zfit,fit['FIT_y_fine'],expected_prefit_sha256=p['prefit_sha256'],**kwargs)
    r['metric_fit_wall_seconds']=time.perf_counter()-started;r['metric_gradient_seconds']=metric.to_state()['trained']['training_seconds'];r['metric_fit']=1
    r['files']['metric']=h.json_new(out/'fresh_ownconditional110_Eq9_10_before_controls.json',metric.to_state())
    started=time.perf_counter();radius=old.fit_radii(metric,zfit,fit['FIT_y_fine']);r['genuineFIT_R7_reference_seconds']=time.perf_counter()-started
    r['files']['reference']=h.npz_new(out/'genuine5987_ownconditional110_truefine_R7_before_controls.npz',dict(ids=fit['FIT_ids'],groups=groups,Z110=zfit,true_fine=fit['FIT_y_fine'],radius=radius),{})
    r['known_FIT_side_complete_seconds']=time.perf_counter()-fit_started
    baseline=load(a['baseline_known'],tuple(role+'_'+key for role in ('CP','CAL') for key in ('ids','prediction')),pins);geometries={};scores={}
    for role in ('CAL','CP'):
        started=time.perf_counter();q=load(a[role],('ids','stage1','predicted_fine'),pins);source=load(a['native'],(role+'_ids',role+'_native78'),pins)
        h.require(np.array_equal(q['ids'],source[role+'_ids']) and np.array_equal(q['ids'],baseline[role+'_ids']),'sameownrole/originalprimary/baseline identity:'+role)
        x=encode_input(source[role+'_native78'],pre);e=clean(net,x,r,role)
        z=np.concatenate((old.guard.signed_log(source[role+'_native78'])/native_units,e.astype(np.float64)/embedding_units),axis=1)
        score=all78_score(net,x,q['stage1'],q['ids'],out,role,r);geometries[role]=dict(q,Z110=z,native78=source[role+'_native78']);scores[role]=score
        r['files'][role+'_geometry']=h.npz_new(out/(role+'_actualownclean110_originalprimary_before_DVC.npz'),dict(ids=q['ids'],Z110=z,embedding32=e,original_stage1=q['stage1'],original_predictedfine=q['predicted_fine']),{})
        r[role+'_pure_encoder_inference_seconds']=time.perf_counter()-started
        if role=='CAL':
            cut=dvc.calibrate_known_cutoffs(score,q['stage1']);r['CAL_fit']=1;r['files']['cutoffs']=h.json_new(out/'alloriginalCAL882_predictedcoarse_finite99_once.json',dict(cutoffs=cut,true_CAL_labels_used=False,unknown_labels_used=False))
    evaluate(reg,out,pins,r,geometries,scores,baseline,metric,cut,'known')

def current_phase(reg,known,trained,pins,out,r):
    net=restore_model(reg,trained,pins);torch.set_num_threads(4);a=reg['assets'];pre=load(a['encoder_preprocessing'],('mean','std'),pins)
    units=load(known['files']['units'],('native78','embedding32'),pins);metric=learned.PaperVariationalPairMetric.from_state(h.read(known['files']['metric'],pins));cut=h.read(known['files']['cutoffs'],pins)['cutoffs']
    for key in ('units','metric','reference','cutoffs'):r['files'][key]=known['files'][key]
    q=load(a['current_geometry'],('ids','native78','stage1','predicted_fine'),pins);b=load(a['baseline_current'],('ids','prediction'),pins)
    h.require(np.array_equal(q['ids'],b['ids']) and len(q['ids'])==3184,'complete originalwhole3184 identity')
    r['unknown_numeric_decodes']=1200;started=time.perf_counter();x=encode_input(q['native78'],pre);e=clean(net,x,r,'current')
    z=np.concatenate((old.guard.signed_log(q['native78'])/units['native78'],e.astype(np.float64)/units['embedding32']),axis=1)
    score=all78_score(net,x,q['stage1'],q['ids'],out,'current',r)
    r['current_pure_encoder_inference_seconds']=time.perf_counter()-started
    r['files']['current_geometry']=h.npz_new(out/'complete3184_actualownclean110_originalprimary_before_DVC.npz',dict(ids=q['ids'],Z110=z,embedding32=e,original_stage1=q['stage1'],original_predictedfine=q['predicted_fine']),{})
    evaluate(reg,out,pins,r,{'current':dict(q,Z110=z)},{'current':score},{'current_prediction':b['prediction']},metric,cut,'current')

def evaluate(reg,out,pins,r,geometries,scores,baseline,metric,cut,phase):
    fields={};started=time.perf_counter()
    for role,q in geometries.items():
        raw=dvc.candidate_mask(scores[role],q['stage1'],cut);b=baseline[role+'_prediction'];density=raw|(b==2)
        groups=old.group_hashes(q['native78']);u,first,inv=np.unique(groups,return_index=True,return_inverse=True)
        h.require(np.array_equal(raw,raw[first][inv]),'samecanonicalnativegroup samecondition/cue')
        route=dvc.route_current_candidates(metric,q['Z110'][first],density[first]);retained=raw&route['retained'][inv];p=b.copy();p[retained]=2;r['DVC']+=1
        fields.update({role+'_'+key:value for key,value in dict(ids=q['ids'],prediction=p,baseline=b,raw=raw,density=density,retained=retained,score=scores[role]).items()})
        r['files'][role+'_DVC']=h.npz_new(out/(role+'_actualmatching110_DVC_before_truth.npz'),{key:v for key,v in route.items() if key!='manifest'},{});r['files'][role+'_manifest']=h.json_new(out/(role+'_actualmatching110_DVC_manifest.json'),route['manifest'])
    r['role_DVC_seconds']=time.perf_counter()-started
    r['files']['prediction']=h.npz_new(out/'complete_prediction_before_truth.npz',fields,{})
    r['files']['seal']=h.json_new(out/'complete_prediction_seal_before_truth.json',dict(prediction=r['files']['prediction'],model=r['files']['model'],metric=r['files']['metric'],CAL=r['files']['cutoffs'],true_querylabels_used=False,original_stage1_fine_preserved=True))
    r['prediction_sealed']=True
    if phase=='known':
        meta=load(reg['assets']['native'],tuple(role+'_'+key for role in ('CP','CAL') for key in ('ids','y_coarse','reporting_indices')),pins);gates={};effects={};reporting={};free=True
        for role in ('CP','CAL'):
            y=meta[role+'_y_coarse'];p=fields[role+'_prediction'];b=fields[role+'_baseline'];ix=meta[role+'_reporting_indices']
            h.require(np.array_equal(fields[role+'_ids'],meta[role+'_ids']),'postseal originalknown roletruth exactidentity')
            gates[role]=current.gates(y,p);reporting[role]=current.gates(y[ix],p[ix]);effects[role]=current.compare(y,b,p);effects[role]['scope']='same original882; genuinely new conditionalmasked MHFD/metric/geometry/cue/DVC, oldmain frozen'
            free&=all(effects[role]['gain_loss'][name]['loss']==0 for name in ('BEN','KNA'));fields[role+'_truth']=y;fields[role+'_reporting_indices']=ix
        ok=free and all(g[name]['passed'] for collection in (gates,reporting) for g in collection.values() for name in ('BEN','KNA'))
        r.update(known_gates=gates,reporting_gates=reporting,EffectDelta=effects,all_old_correct_loss_free=bool(free),known_gate_passed=bool(ok),current_allowed=bool(ok))
    else:
        truth=load(reg['assets']['truth_current'],('ids','truth','historical'),pins);h.require(np.array_equal(fields['current_ids'],truth['ids']),'complete currenttruth onlyafterpredictionseal')
        y=truth['truth'];p=fields['current_prediction'];b=fields['current_baseline'];g=current.gates(y,p);e=current.compare(y,b,p);e['scope']='same3184 oldmain frozen; newly conditionalmasked MHFD/ownmatching110 metric/cue/DVC'
        free=all(v['loss']==0 for v in e['gain_loss'].values());extra=int(np.sum((y==2)&(b!=2)&fields['current_raw']))
        r.update(original_class_gates=g,EffectDelta=e,all_old_correct_loss_free=free,candidate_accepted_for_retention=free and e['verdict']=='UP',
            raw_by_class={name:int(np.sum((y==i)&fields['current_raw'])) for i,name in enumerate(('BEN','KNA','UNA'))},
            coverage=dict(external_raw_UNA=extra,perfect_raw_retention_UNA_ceiling=380+extra,baseline_UNA=380),historical_class_gates=current.gates(y,truth['historical']))
        fields.update(current_truth=y,current_historical=truth['historical'])
    r['truth_opened']=True;r['files']['postseal_pair']=h.npz_new(out/'postseal_sameoriginal_paired_comparison.npz',fields,{})

def run(phase,registry,train_item=None,known_item=None):
    pins={};caller=bind_caller_registry(registry,pins);trained=None if phase=='train' else h.read(train_item,pins)
    if phase!='train':h.require(trained['registry']==registry and trained['epochs_completed']==30 and trained['policy']==policy(),'owncaller fixed30 training lineage')
    known=None
    if phase=='current':
        known=h.read(known_item,pins);h.require(known['known_gate_passed'] and known['all_old_correct_loss_free'] and known['registry']==registry and known['prediction_sealed'],'strict dualknown gate before current numericalfeatures')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False);start=time.perf_counter()
    r=dict(policy=policy(),registry=registry,files={},NN_fit=0,NN_forward=0,metric_fit=0,CAL_fit=0,DVC=0,
        prediction_sealed=False,truth_opened=False,unknown_numeric_decodes=0,status='FAIL_TARGET99',published=False,final_test_executed=False,accepted_baseline_replaced=False)
    if trained is not None:r['files']['model']=trained['files']['model'];r['train_report']=train_item
    try:
        with threadpool_limits(limits=2):
            if phase=='train':train(caller,registry,pins,out,r)
            elif phase=='known':known_phase(caller,trained,pins,out,r)
            else:current_phase(caller,known,trained,pins,out,r)
        if phase!='train':r['execution_status']='ownCIC2_conditionalStudent3_'+phase+'_evaluated'
    except Exception as error:
        r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:r.update(input_sha256=pins,wall_seconds=time.perf_counter()-start);h.json_new(out/'report.json',r)
    return h.descriptor(out/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','train','known','current'),required=True)
    for name in ('registry','registry-sha256','train-report','train-sha256','known-report','known-sha256'):p.add_argument('--'+name)
    args=p.parse_args();registry=dict(path=args.registry,sha256=args.registry_sha256)
    train_item=None if args.train_report is None else dict(path=args.train_report,sha256=args.train_sha256)
    known_item=None if args.known_report is None else dict(path=args.known_report,sha256=args.known_sha256)
    print(json.dumps(freeze() if args.phase=='freeze' else run(args.phase,registry,train_item,known_item)))
