"""One coarse-consistent selector repair on frozen raw78 covariance states.

No covariance is refitted. Coarse BEN selects fine0. Coarse KNA keeps an
attack fine; a fine0/coarseKNA row uses the minimum existing attack distance.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import numpy as np

from . import cic1_native78_joint_rawport_v1 as raw_source

ROOT,files,trained,context=raw_source.ROOT,raw_source.files,raw_source.trained,raw_source.context
BASE=ROOT/'data/external_dev/processed/cic1_label_conditional_support_20261011_v47'
SCHEMA='CIC1-frozen-raw78-trueknown-CAL-labelconditional-support-v47'
RAW_KNOWN=dict(path=str(raw_source.BASE/'known/report.json'),
    sha256='48b29b25fb8050ae545a4c7b148526242e475b7e031ae6b759af873fdd3cd38a')


def policy():
    return dict(schema_version=SCHEMA,setting='CIC Setting1',hypotheses=1,
        model='unchanged genuineFIT6000 raw78 class/port covariance; no model/unit/metric fit',
        known_support='BEN coarse uses BENfine0; KNA coarse uses minimum existing attackfine1..8 distances',
        CAL='true known CAL coarse labels calibrate their own class support scores once, finite99; all original900 controls kept',
        rationale='primary classification mistakes must not contaminate another known class support cutoff',
        query='original primary predicted coarse selects support; no query truth or IDs in decision',
        source='same originalnative78 signedlog/FIT RMS and min20 genuineFIT per port/fine cells',
        DVC='unchanged learned110 and affinity/reconstruction/noise; raw candidate only',
        merge='preserve complete T41_799 baseline, append ownraw AND ownDVC retained',
        known_gate='original900 BEN/KNA exact99 and row-level correctloss0 before full4056',
        covariance_fit=0,metric_fit=0,NN_fit=0,NN_forward=0,query_CAL_or_unit_fit=0,
        fixed_recipes=1,threshold_sweep=False,independent_final_claimed=False,
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)


def coherent_score(vectors,coarse,predicted_fine,ports,model):
    vectors=np.asarray(vectors,np.float64);coarse=np.asarray(coarse);fine=np.asarray(predicted_fine);ports=np.asarray(ports)
    files.require(vectors.ndim==2 and vectors.shape[1]==78 and np.isfinite(vectors).all()
        and coarse.shape==fine.shape==ports.shape==(len(vectors),)
        and coarse.dtype.kind in 'iu' and fine.dtype.kind in 'iu'
        and np.isin(coarse,(0,1)).all() and np.isin(fine,range(9)).all(),
        'raw78 and original coarse/fine/observedport selector only')
    selected=fine.copy();selected[coarse==0]=0
    result=np.empty(len(vectors));cells=np.empty(len(vectors),dtype='<U40')
    ambiguous=(coarse==1);direct=np.flatnonzero(~ambiguous)
    if len(direct):
        result[direct],cells[direct]=raw_source.score_vectors(vectors[direct],selected[direct],ports[direct],model)
    rows=np.flatnonzero(ambiguous)
    if len(rows):
        scores=[];cell_list=[]
        for attack_fine in range(1,9):
            value,cell=raw_source.score_vectors(vectors[rows],np.full(len(rows),attack_fine,np.int64),ports[rows],model)
            scores.append(value);cell_list.append(cell)
        stack=np.asarray(scores);choice=np.argmin(stack,axis=0)
        result[rows]=stack[choice,np.arange(len(rows))]
        cells[rows]=np.asarray(cell_list)[choice,np.arange(len(rows))]
        selected[rows]=choice+1
    files.require(np.isfinite(result).all() and np.all(result>=0)
        and np.all(selected[coarse==0]==0) and np.isin(selected[coarse==1],range(1,9)).all(),
        'all selected covariance known fines match original predicted coarse')
    return result,cells,selected,ambiguous


def freeze():
    pins={};old=files.js(RAW_KNOWN,pins);oldreg=files.js(old['registry'],pins)
    files.require(old['known_gate_passed'] and old['known_correct_loss']==dict(BEN=0,KNA=0)
        and oldreg['source']==files.item(raw_source.__file__), 'pinned actual raw covariance known source and full900 identity')
    assets=dict(oldreg['assets']);assets['raw_covariance_model']=old['files']['model']
    for asset in assets.values():files.read(asset,pins)
    model=files.js(assets['raw_covariance_model'],pins)
    files.require(model['fit_rows']==6000 and model['query_used_for_fit'] is False
        and model['cell_minimum_unique_support']==20 and len(model['fine_global'])==9,
        'exact genuineFIT-only raw covariance reusable state')
    sources=dict(oldreg['sources']);sources['raw_covariance_source']=files.item(raw_source.__file__)
    registry=dict(schema_version=SCHEMA+'-registry-before-CAL-selector-repair',policy=policy(),
        source=files.item(__file__),sources=sources,assets=assets,
        runtime_covariance_source=oldreg['runtime_covariance_source'],raw_known_report=RAW_KNOWN,
        geometry_registry=oldreg['geometry_registry'],comparator_key=oldreg['comparator_key'],
        native_field_order=oldreg['native_field_order'],outputs={phase:str(BASE/phase) for phase in ('known','current')},
        input_sha256=pins,query_numeric_values_decoded=0,covariance_fit=0,
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    out=ROOT/'tmp/cic1_label_conditional_support_20261011_v47';out.mkdir(exist_ok=False)
    return files.write(out/'registry_before_coarse_consistent_CAL.json',registry)


def run(phase,path,sha,known_path=None,known_sha=None):
    pins={};ref=dict(path=str(Path(path).resolve()),sha256=sha);reg=files.js(ref,pins)
    files.require(reg['source']==files.item(__file__) and reg['policy']==policy(), 'one exact frozen selector repair')
    for asset in reg['sources'].values():files.read(asset,pins)
    if phase=='current':
        files.require(known_path and known_sha,'own selector-known zero-loss report required')
        control=files.js(dict(path=str(Path(known_path).resolve()),sha256=known_sha),pins)
        files.require(control['registry']==ref and control['known_gate_passed']
            and control['known_correct_loss']==dict(BEN=0,KNA=0),'same selector full900 gates before complete current native values')
    out=Path(reg['outputs'][phase]);out.mkdir(parents=True,exist_ok=False);began=time.perf_counter()
    report=dict(schema_version=SCHEMA,phase=phase,registry=ref,policy=policy(),files={},
        covariance_fit=0,CAL_cutoff_fit=0,metric_fit=0,native_RMS_fit=0,
        NN_forward=0,NN_training=0,NN_training_seconds=0,query_model_or_CAL_fit=0,DVC_calls=0,
        prediction_sealed=False,truth_opened=False,accepted_baseline_replaced=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        rms=np.asarray(files.js(reg['assets']['native_RMS'],pins)['native78'])
        model=files.js(reg['assets']['raw_covariance_model'],pins)
        if phase=='known':
            fields=context.selected(reg['assets']['known110'],tuple(role+'_'+key for role in ('CAL','CP')
                for key in ('ids','groups','Z110','stage1','predicted_fine')),pins)
            fields.update(context.selected(reg['assets']['known110'],('CAL_truth',),pins))
            native=context.selected(reg['assets']['native_known'],tuple(role+'_'+key for role in ('CAL','CP')
                for key in ('ids','native78')),pins)
            for role in ('CAL','CP'):
                files.require(np.array_equal(fields[role+'_ids'],native[role+'_ids'])
                    and np.array_equal(raw_source.normalize(native[role+'_native78'],rms),fields[role+'_Z110'][:,:78]),
                    'exact complete original known signedlogRMS role identity')
            cal_score,cal_cells,cal_selected,cal_ambiguous=coherent_score(raw_source.normalize(native['CAL_native78'],rms),
                fields['CAL_truth'],fields['CAL_predicted_fine'],raw_source.joint.port_keys(native['CAL_native78']),model)
            ca=trained.core.previous.save(out,'CAL_coherent_scores_before_CP',dict(ids=fields['CAL_ids'],score=cal_score,
                stage1=fields['CAL_stage1'],calibration_true_coarse=fields['CAL_truth'],original_fine=fields['CAL_predicted_fine'],selected_fine=cal_selected,
                cell=cal_cells,attack_minimum=cal_ambiguous),report)
            cut=context.geometry.dvc.calibrate_known_cutoffs(cal_score,fields['CAL_truth'])
            files.require(all(row['enabled'] for row in cut.values()),'finite once original CALcoarse99 after source repair')
            report['CAL_cutoff_fit']=1
            report['files']['cutoffs']=files.write(out/'once_CAL_coherent_selector_cutoffs_before_CP.json',
                dict(cutoffs=cut,model=reg['assets']['raw_covariance_model'],source=ca,CP_used=False,unknown_used=False,true_known_CAL_labels_used=True,query_labels_used=False))
            report['CAL_selector_coherence']=dict(coarseBEN_originalAttackFine=int(np.sum((fields['CAL_stage1']==0)&(fields['CAL_predicted_fine']>0))),
                coarseKNA_originalBENfine=int(cal_ambiguous.sum()),all_selected_fines_coarse_consistent=True)
            query=context.role_query(fields,'CP');vector=raw_source.normalize(native['CP_native78'],rms)
            ports=raw_source.joint.port_keys(native['CP_native78'])
        else:
            cut=files.js(control['files']['cutoffs'],pins)['cutoffs']
            query=context.selected(reg['assets']['query110'],('ids','groups','Z110','stage1','predicted_fine'),pins)
            native=context.selected(reg['assets']['current_native'],('ids','native78','normalized78'),pins)
            files.require(len(query['ids'])==len(set(query['groups'].tolist()))==4056
                and np.array_equal(query['ids'],native['ids']) and native['native78'].shape==(4056,78),
                'all original4056 rows and density groups, no filtering')
            vector=raw_source.normalize(native['native78'],rms);ports=raw_source.joint.port_keys(native['native78'])
            files.require(np.array_equal(vector,query['Z110'][:,:78])
                and np.array_equal(vector.astype(np.float32),native['normalized78']), 'exact full current canonical signedlogRMS')
        current_score,cells,selected,ambiguous=coherent_score(vector,query['stage1'],query['predicted_fine'],ports,model)
        trained.core.previous.save(out,'coherent_selector_scores_before_DVC',dict(ids=query['ids'],score=current_score,
            stage1=query['stage1'],original_fine=query['predicted_fine'],selected_fine=selected,
            destination_port=ports,cell=cells,attack_minimum=ambiguous),report)
        geometry=files.js(reg['geometry_registry'],pins)
        _,raw,retained=context.geometry.route(context.metric_from_registry(geometry,pins),query,current_score,cut,
            out,'coherent_raw78',report)
        if phase=='known':old=context.selected(reg['assets']['preserved_known_prediction'],('ids','baseline'),pins);baseline=old['baseline']
        else:old=context.selected(reg['assets']['comparator'],('ids',reg['comparator_key']),pins);baseline=old[reg['comparator_key']]
        files.require(np.array_equal(query['ids'],old['ids']),'exact same original baseline IDs')
        prediction=baseline.copy();prediction[raw&retained]=2
        files.require(np.all(prediction[baseline==2]==2),'all original predictedUNA retained')
        pa=trained.core.previous.save(out,'complete_coherent_prediction_before_truth',dict(ids=query['ids'],baseline=baseline,
            prediction=prediction,raw=raw,retained=retained),report)
        report['files']['prediction_seal']=files.write(out/'complete_coherent_prediction_seal_before_truth.json',
            dict(prediction=pa,model=reg['assets']['raw_covariance_model'],truth_opened=False,
                cutoffs=report['files']['cutoffs'] if phase=='known' else control['files']['cutoffs']))
        report['prediction_sealed']=True
        if phase=='known':y=context.selected(reg['assets']['known110'],('CP_truth',),pins)['CP_truth']
        else:
            truth=context.selected(reg['assets']['truth'],('ids','truth'),pins)
            files.require(np.array_equal(query['ids'],truth['ids']),'full4056 truth only after seal');y=truth['truth']
        report['truth_opened']=True
        gates=context.integer_gates(y,prediction,known_only=phase=='known');oldg=context.integer_gates(y,baseline,known_only=phase=='known')
        gainloss={name:dict(gain=int(np.sum((y==code)&(baseline!=code)&(prediction==code))),
            loss=int(np.sum((y==code)&(baseline==code)&(prediction!=code)))) for code,name in enumerate(gates)}
        delta={name:gates[name]['correct']-oldg[name]['correct'] for name in gates}
        positive,negative=any(value>0 for value in delta.values()),any(value<0 for value in delta.values())
        direction='MIXED' if positive and negative else 'UP' if positive else 'DOWN' if negative else 'UNCHANGED'
        loss={name:gainloss[name]['loss'] for name in ('BEN','KNA')}
        trained.core.previous.save(out,'postseal_coherent_paired_comparison',dict(ids=query['ids'],truth=y,baseline=baseline,
            prediction=prediction,raw=raw,retained=retained),report)
        report.update(execution_status='labelconditional_known_support_'+phase+'_evaluated',original_class_gates=gates,
            baseline_class_gates=oldg,EffectDelta=dict(verdict=direction,correct_count_delta=delta,gain_loss=gainloss,
                same_original_IDs_and_order=True,accepted_baseline_replaced=False),known_correct_loss=loss,
            known_gate_passed=all(gates[name]['passed'] for name in ('BEN','KNA')) and not any(loss.values()),calibration_labels_role='true_known_CAL_only',query_truth_used_before_seal=False,
            all_three_integer99_passed=phase=='current' and all(row['passed'] for row in gates.values()),rows=len(y),
            raw_candidates=int(raw.sum()),retained_candidates=int(retained.sum()),
            raw_by_true_class={name:int(np.sum((y==code)&raw)) for code,name in enumerate(gates)},
            selector_coherence=dict(coarseBEN_originalAttackFine=int(np.sum((query['stage1']==0)&(query['predicted_fine']>0))),
                coarseKNA_originalBENfine=int(ambiguous.sum()),all_selected_fines_coarse_consistent=True),
            original_raw_covariance_model=reg['assets']['raw_covariance_model'])
        for bound,wanted in pins.items():files.require(files.item(bound)['sha256']==wanted,'frozen old and new source assets unchanged')
    except Exception as error:
        report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        report['input_sha256']=pins;report['wall_seconds']=time.perf_counter()-began
        files.write(out/'report.json',report)
    return files.item(out/'report.json')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for name in ('registry','registry-sha256','known-report','known-sha256'):parser.add_argument('--'+name)
    args=parser.parse_args()
    print(json.dumps(freeze() if args.phase=='freeze' else run(args.phase,args.registry,args.registry_sha256,args.known_report,args.known_sha256)))
