"""All real raw-port contexts relative density cue -> original126 newraw DVC."""
import argparse,json,sys,time,types
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from . import cic1_port_context_density_core_v134 as core
from . import cic1_symmetric_collective_density126_v126 as previous
from . import cic1_soft_raw_affinity126_v133 as timing_parent
from . import cic1_native78_joint_rawport_v1 as native_source
ROOT,files,require=previous.ROOT,previous.files,previous.require
old=previous.old;MODULE='paper_open_set.cic1_port_context_density126_v134'
DIR=ROOT/'tmp/cic1_port_context_density126_20261012_v134';BASE=ROOT/'data/external_dev/processed/cic1_port_context_density126_20261012_v134';REG=DIR/'registry_before_known.json'
def policy():
    return dict(schema_version='CIC1-alltrueDestinationPort-knowncoarse-relative-density-original126-v134',recipe=core.recipe(),hypotheses=1,
        cue='port context supplies an auxiliary localpopulation candidate cue; originalMHFD and126geometry/metric unchanged',
        port='verifiedfull78 sourceheader index of literal Destination Port, originalrawvalues without fitted transform/binning',
        history='earlier fine/port rawcovariance and warmport DVC existed; new relative-cohort density conditioned allrealport×coarse is a structural transfer, not firstportmodel',
        CAL='onlytrueknownnegative stage-consistent coarse population, all900 oncefinite99 truecoarse labels, unavailablecontext eligiblefalse',
        query_population='fullpreV123 whole2402 predictions0/1×unlabelledrawport, nevercurrenttruecoarse',
        baseline_merge='copywhole646/247/3114 and old2 includingmistakes; onlynewrawretained append2, originals3059/2402 preserved',
        DVC='newraw-only samefrozen126 knee SC/CH primary/secondary noise, canonicalgroupsonce; no oldpred2 background in newcluster selection',
        DVC_structure_reason='V133 fulloldpred2background suppressed9alreadyraw UNA; newraw-only is one beforefreeze mechanism choice, not densityparameter sweep',
        NN_fit=0,NN_forward=0,metric_fit=0,R7_fit=0,trueUNA_fit=False,parameter_grid=False,timecap_coded=False,
        extension_not_verbatim_paper=True,status='FAIL_TARGET99',published=False,final_test_executed=False)
def closure():
    result={};seen=set();todo=[sys.modules[__name__]]
    while todo:
        m=todo.pop()
        if m is None or id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if not p or not Path(p).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        result[MODULE if m is sys.modules[__name__] else m.__name__]=files.item(p)
        for value in vars(m).values():
            child=value if isinstance(value,types.ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            if child is not None:todo.append(child)
    return result
def archive(a,keys,pins):return old.archive(a,keys,pins)
def save(out,r,key,value):return old.save(out,r,key,value)
def freeze():
    began=time.perf_counter();pins={};pr=files.item(previous.REG);p=files.js(pr,pins);kr=files.item(previous.BASE/'known/report.json');cr=files.item(previous.BASE/'current/report.json');k=files.js(kr,pins);c=files.js(cr,pins)
    require(k['known_gate_passed'] and c['prediction_sealed'] and c['original_class_gates']['UNA']['correct']==3114,'actualpreservedwhole3114 andknowncontrol')
    a=dict(p['assets']);a.update(known_baseline=k['files']['complete_prediction_before_truth'],baseline=c['files']['complete_prediction_before_truth'])
    producer_current=files.item(old.cic.BASE/'current/report.json');pc=files.js(producer_current,pins);producer_reg=files.js(pc['registry'],pins)
    a.update(current_native=producer_reg['assets']['current_native'],native_RMS=producer_reg['assets']['native_RMS'])
    portorder_ref=files.item(ROOT/'tmp/cic1_native78_joint_rawport_20261011_v1/registry_before_known_native78_joint_fit.json');portorder=files.js(portorder_ref,pins)
    fields=portorder['native_field_order'];canonical=list(native_source.trained.helpers.CIC_FEATURE_COLUMNS)
    require(len(fields)==78 and fields==canonical and fields.count('Destination Port')==1,'realfrozen source-native78 exactorderedfield semantics')
    portindex=fields.index('Destination Port')
    materialref=files.item(ROOT/'data/external_dev/processed/cic1_fit6000_mhfd_20261009_v1/material/material_report_before_fit.json');materialreport=files.js(materialref,pins);materialregistry=files.js(materialreport['registry'],pins)
    extractref=materialregistry['source_report'];extract=files.js(extractref,pins)
    require(extract['model_columns']==fields and materialreport['source_arrays']==a['native_known'],'actualcombined6000native input source fieldorder bound')
    priorclose=files.item(timing_parent.DIR/'CIC1_V133_UNIFORM_SOFT_RAW_GRAPH_COMPLETED_CLOSEOUT.json');closed=files.js(priorclose,pins)
    src=closure();contract=core.synthetic_contract()
    for item in [*a.values(),*src.values()]:files.read(item,pins)
    require(not REG.exists() and not BASE.exists(),'exclusive allportcontext density hypothesis namespace')
    DIR.mkdir(parents=True,exist_ok=True)
    return files.write(REG,dict(policy=policy(),assets=a,sources=src,synthetic_contract=contract,port_index=portindex,original_native_field_order=fields,
        port_provenance=dict(actual_native_order_registry=portorder_ref,actualcombined_known_material=materialref,combined_material_registry=materialreport['registry'],known_source_extract=extractref,
            current126_producer_report=producer_current,current126_producer_registry=pc['registry'],integer_raw_no_binning_no_inverse_transform=True),
        previous_registry=pr,previous_known=kr,previous_current=cr,ancestry_closeout=priorclose,prior_preparation_seconds=closed['actual_preparation']['conservative_allprep_plus_ancestry_seconds'],
        freeze_seconds=time.perf_counter()-began,input_sha256=pins,current_numeric_decodes=0))
def bind(ref,pins):
    reg=files.js(ref,pins);require(reg['policy']==policy() and reg['sources']==closure() and reg['original_native_field_order'][reg['port_index']]=='Destination Port','exactsource/fullport semantics/frozenrecipe')
    for p,s in reg['input_sha256'].items():files.read(dict(path=p,sha256=s),pins)
    return reg
def native_role(reg,role,pins):
    if role=='current':
        n=archive(reg['assets']['current_native'],('ids','native78'),pins);return n['ids'],n['native78']
    n=archive(reg['assets']['native_known'],(role+'_ids',role+'_native78'),pins);return n[role+'_ids'],n[role+'_native78']
def real_ports(reg,role,ids,z,pins):
    ni,native=native_role(reg,role,pins);require(np.array_equal(ni,ids),'rawnativefield source actualorderedroleids')
    units=np.asarray(files.js(reg['assets']['native_RMS'],pins)['native78'])
    require(np.array_equal(native_source.normalize(native,units),z[:,:78]),'actualoriginal allnative78 normalization reconstructs unchanged126 prefix')
    ports=core.port_values(native,int(reg['port_index']));return ports,native
def cue_save(out,r,prefix,q,cue,details):
    save(out,r,prefix,dict(ids=q['ids'],groups=q['groups'],Z126=q['Z126'],stage1=q['stage1'],**cue))
    for j,item in enumerate(details):save(out,r,prefix+'_context'+str(j)+'_actualdistances',item)
def run(phase,ref,knownref=None):
    started=time.perf_counter();pins={};reg=bind(ref,pins);control=None
    if phase=='current':
        control=files.js(knownref,pins);require(control['known_gate_passed'] and control['prediction_sealed'] and control['registry']==ref,'known exactinteger admission beforecurrent')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False)
    r=dict(policy=policy(),phase=phase,registry=ref,files={},NN_fit=0,NN_forward=0,metric_fit=0,R7_fit=0,context_background_fit=0,CAL_fit=0,DVC=0,current_numeric_decodes=0,
        prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        with threadpool_limits(limits=2):
            a=reg['assets'];wrapped=files.js(a['metric'],pins);metric=old.cic.learned.PaperVariationalPairMetric.from_state(wrapped['metric_payload']);require(metric.dimension==126,'realunchangedfull126 owner');r['files']['metric']=a['metric']
            if phase=='known':
                prep=time.perf_counter();mat=archive(a['material'],('FIT_ids','FIT_groups','FIT_fine','FIT_Z126','CAL_ids','CAL_groups','CAL_Z126','CAL_stage1'),pins)
                labels=archive(a['native_known'],('FIT_ids','FIT_y_fine','CAL_ids','CAL_y_coarse'),pins)
                require(np.array_equal(mat['FIT_ids'],labels['FIT_ids']) and np.array_equal(mat['FIT_fine'],labels['FIT_y_fine']) and np.array_equal(mat['CAL_ids'],labels['CAL_ids']) and np.bincount(mat['FIT_fine'],minlength=9).min()>=20,'genuine6000trueknownall9 floor20')
                require(metric.to_state()['prefit_descriptor']['FIT_MHFD_Z']==old.cic.learned._array_descriptor(mat['FIT_Z126']),'fullknownFIT126 exact metricprefit')
                fitports,native=real_ports(reg,'FIT',mat['FIT_ids'],mat['FIT_Z126'],pins);reference=core.background(mat['FIT_Z126'],mat['FIT_groups'],mat['FIT_fine'],fitports);r['context_background_fit']=1
                r['files']['reference']=save(out,r,'allgenuineknown6000_rawport_full126_context_reference_before_CAL',dict(ids=mat['FIT_ids'],**reference))
                cq={key:mat['CAL_'+key] for key in ('ids','groups','Z126','stage1')};calports,_=real_ports(reg,'CAL',cq['ids'],cq['Z126'],pins)
                negativepop=np.where(labels['CAL_y_coarse']==cq['stage1'],cq['stage1'],-1)
                cal,details=core.infer(metric,cq['Z126'],cq['groups'],calports,negativepop,reference);cue_save(out,r,'alltrueknownCAL900_portcontext_before_cut',cq,cal,details)
                save(out,r,'alltrueknownCAL900_negativepopulation_truth_for_oncecut',dict(ids=cq['ids'],truecoarse=labels['CAL_y_coarse'],population=negativepop))
                rule=old.cic.dvc.calibrate_known_cutoffs(cal['score'],labels['CAL_y_coarse']);r['CAL_fit']=1;r['files']['rule']=files.write(out/'all900_trueknown_oncefinite99_portcontext.json',rule);r['newFIT_CAL_preparation_seconds']=time.perf_counter()-prep
            else:
                reference=archive(control['files']['reference'],('Z126','groups','truefine','ports','contexts2','vocabulary2','context_counts'),pins);rule=files.js(control['files']['rule'],pins);r['files'].update(reference=control['files']['reference'],rule=control['files']['rule']);r['known_report']=knownref
            q,b,_=old.query('CIC1',phase,a,pins);role='CP' if phase=='known' else 'current';ports,native=real_ports(reg,role,q['ids'],q['Z126'],pins)
            population=archive(a['population_known_baseline' if phase=='known' else 'population_baseline'],('ids','prediction'),pins);require(np.array_equal(population['ids'],q['ids']),'truecompletepreV123 whole2402 population order')
            r['current_numeric_decodes']=len(q['ids']) if phase=='current' else 0;scorestart=time.perf_counter();cue,details=core.infer(metric,q['Z126'],q['groups'],ports,population['prediction'],reference);r['query_context_density_seconds']=time.perf_counter()-scorestart
            raw=(b!=2)&cue['eligible']&old.cic.dvc.candidate_mask(cue['score'],q['stage1'],rule);cue_save(out,r,'actualwhole_preV123population_allport_density_before_DVC',q,cue,details)
            nodes=np.unique(q['groups'],return_index=True,return_inverse=True);representative,inverse=nodes[1],nodes[2];group_raw=np.zeros(len(representative),bool);np.logical_or.at(group_raw,inverse,raw)
            routed=old.cic.dvc.route_current_candidates(metric,q['Z126'][representative],group_raw,seed=20261012);r['DVC']=1
            route={k:v[inverse] for k,v in routed.items() if k!='manifest'};save(out,r,'same126_newrawonly_portdensity_DVC_before_truth',route)
            r['files']['DVC_manifest']=files.write(out/'same126_newrawonly_portdensity_DVC_manifest.json',dict(routed['manifest'],matching_metric_state_sha256=metric.state_sha256,density_copy_points=0,oldpred2_background=False))
            retained=raw&route['retained'];p=b.copy();p[retained]=2;require(np.all(p[b==2]==2),'completewhole3114 originalpred2 includingmistakes preserved')
            values=dict(ids=q['ids'],prediction=p,baseline=b,raw=raw,retained=retained,score=cue['score'],eligible=cue['eligible'],ports=ports,population_prediction=population['prediction'])
            sealed=save(out,r,'complete_prediction_before_truth',values);r['files']['seal']=files.write(out/'complete_prediction_seal_beforetruth.json',dict(predictions=sealed,registry=ref,rule=r['files']['rule'],reference=r['files']['reference'],metric=a['metric'],querytruth_used=False));r['prediction_sealed']=True
            if phase=='known':y=archive(a['known_truth'],('CP_truth',),pins)['CP_truth']
            else:
                truth=archive(a['truth'],('ids','truth'),pins);require(np.array_equal(truth['ids'],q['ids']),'truequery onlyafterwholepredictionseal');y=truth['truth']
            r['truth_opened']=True;gates,delta,binary=old.helpers.metrics(y,b,p)
            r.update(execution_status='CIC1_allport_context126_'+phase+'_completed',original_class_gates=gates,EffectDelta=delta,binary_attack_detection=binary,
                known_gate_passed=all(gates[n]['passed'] for n in ('BEN','KNA')),candidate_accepted_for_retention=False,
                raw_by_trueclass={n:int(((y==c)&raw).sum()) for c,n in enumerate(('BEN','KNA','UNA'))},retained_by_trueclass={n:int(((y==c)&retained).sum()) for c,n in enumerate(('BEN','KNA','UNA'))})
            save(out,r,'postseal_complete_whole_pair',dict(**values,truth=y))
            if phase=='current':r['perfect_raw_UNA_ceiling']=int(((y==2)&((b==2)|raw)).sum())
        for p,s in pins.items():require(files.item(p)['sha256']==s,'allsource/data/frozenmodel/oldwhole byteidentity unchanged')
    except Exception as error:r.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:r.update(input_sha256=pins,wall_seconds=time.perf_counter()-started);files.write(out/'report.json',r)
    return files.item(out/'report.json')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for key in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+key)
    a=p.parse_args();ref=None if a.registry is None else dict(path=str(Path(a.registry).resolve()),sha256=a.registry_sha256);k=None if a.known_report is None else dict(path=str(Path(a.known_report).resolve()),sha256=a.known_sha256)
    print(json.dumps(freeze() if a.phase=='freeze' else run(a.phase,ref,k)))
