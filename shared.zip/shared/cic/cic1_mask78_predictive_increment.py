"""Predictive field-mask candidate supplement to preserved CIC1 T41_799 DEV."""
from __future__ import annotations
import argparse
import io
import json
from pathlib import Path
import time
import numpy as np
import torch
from . import cic1_known6000_maskaux78_v1 as trained
from . import cic_aux110_perfine_isolation_hint_v2 as context

ROOT=trained.ROOT;files=trained.files
BASE=ROOT/'data/external_dev/processed/cic1_mask78_predictive_increment_20261010_v1'
SCHEMA='CIC1-preserved-observed799-mask78-field-error-candidate-increment-v1'
TRAIN=dict(path=str(trained.BASE/'report.json'),sha256='7b5b0c052b4fc16aec4e944acc6c7f11d0725ec2785f1ffc9a2462a5be7a7106')
GEOMETRY=dict(path=str(ROOT/'data/external_dev/processed/cic1_aux110_perfine_IF512_hint_20261010_v2/registry_before_perfine_IF_fit.json'),sha256='0f4671392fbd7fc64ad3c6152f253544d6ee810566eafdef15ea7147bc2a9596')

def policy():
    return dict(schema_version=SCHEMA,scope='same observed current4056; not independent final',
        score='max normalized squared masked-field errors over all78 fields; perfield finite99 units and scalar99 cutoff fitted originalCAL only',
        model='new known6000 maskaux78; old main/forest and existing110 geometry/metric remain frozen',
        baseline='preserved genuine T41_799 old_comparator on same4056; no label or ID rule',
        calibration='original900 CAL with old primarycoarse; natural exactzero field scale1',
        DVC='same frozen110 learned-distance/affinity/noise; newmask embedding not substituted',
        merge='baselinecopy, ownraw AND currentDVCretained becomeUNA',
        gates='knownCP900 integer99 plus no correctknown loss before full4056',
        no_query_parameter_fit=True,no_target_labels_for_tuning=True,
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)

def freeze():
    pins={};model=files.js(TRAIN,pins);reg=files.js(GEOMETRY,pins)
    files.require(model['epochs_completed']==80 and model['unknown_values_opened'] is False,'actual onlyknown masked producer')
    assets=dict(mask_model=model['files']['model'],known110=reg['known110'],query110=reg['query110'],
        evaluation=reg['previous_evaluation'],old_metric=reg['owned_metric'])
    for item in assets.values():files.read(item,pins)
    result=dict(schema_version=SCHEMA+'-registry',policy=policy(),assets=assets,context_registry=GEOMETRY,
        mask_state_sha=model['model_state_sha256'],source=files.item(__file__),
        sources={Path(m.__file__).name:files.item(m.__file__) for m in (trained,trained.core,context,context.geometry,context.bridge.learned)},
        output={p:str(BASE/p) for p in ('known','current')},input_sha256=pins)
    out=ROOT/'tmp/cic1_mask78_predictive_increment_20261010_v1';out.mkdir(exist_ok=True)
    return files.write(out/'registry_before_masked_CAL.json',result)

def field_errors(net,x,role,out,report):
    result=np.empty((len(x),78));device=next(net.parameters()).device
    with torch.no_grad():
        for field in range(78):
            for first in range(0,len(x),1024):
                stop=min(first+1024,len(x));xb=torch.from_numpy(x[first:stop].copy()).to(device)
                mask=torch.full((len(xb),),field,dtype=torch.int64,device=device)
                with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=device.type=='cuda'):values=net.forward_masked(xb,mask)
                live={k:v.detach().cpu().numpy().copy() if v.dtype==torch.bool else v.detach().float().cpu().numpy().copy() for k,v in values.items()}
                trained.core.previous.save(out,role+'_field'+str(field)+'_batch'+str(first),live,report)
                report['masked_forward_batches']+=1
                result[first:stop,field]=np.square(live['reconstruction'][:,field].astype(np.float64)-x[first:stop,field])
    trained.core.previous.save(out,role+'_all_masked_field_errors',dict(error=result),report)
    files.require(np.isfinite(result).all(),'finite complete78 predictive errors after raw capture')
    return result

def scale_fit(error,stage):
    scale=np.ones((2,78))
    for f in range(78):
        rules=context.geometry.dvc.calibrate_known_cutoffs(error[:,f],stage)
        for label in (0,1):
            node=rules[str(label)];files.require(node['enabled'],'sufficient originalCAL for field normalization')
            scale[label,f]=node['cutoff'] if node['cutoff']>0 else 1
    return scale

def run(phase,path,sha,known_path=None,known_sha=None):
    pins={};ref=dict(path=str(Path(path).resolve()),sha256=sha);reg=files.js(ref,pins)
    files.require(reg['policy']==policy() and reg['source']==files.item(__file__),'fixed mask78candidate source')
    if phase=='current':
        control=files.js(dict(path=str(Path(known_path).resolve()),sha256=known_sha),pins)
        files.require(control['registry']==ref and control['known_gate_passed'],'known gate before unknown masked values')
    out=Path(reg['output'][phase]);files.require(not out.exists(),'fresh mask78 stage');out.mkdir(parents=True)
    began=time.perf_counter();before=trained.core.capture_runtime_flags()
    report=dict(schema_version=SCHEMA,phase=phase,registry=ref,policy=policy(),files={},DVC_calls=0,masked_forward_batches=0,
        model_fit=0,metric_fit=0,CAL_fit=0,query_fit=0,prediction_sealed=False,truth_opened=False,
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        torch.set_num_threads(4);stored=torch.load(io.BytesIO(files.read(reg['assets']['mask_model'],pins)),map_location='cpu',weights_only=True)
        fmap=trained.core.field_map_from_state(stored['field_map']);net=trained.core.ExpandedWholeFieldMaskedMHFD(fmap,9).to('cuda' if torch.cuda.is_available() else 'cpu')
        net.load_state_dict(stored['state_dict'],strict=True);net.eval()
        files.require(trained.core.output_io.state_digest(net)==reg['mask_state_sha'],'exact full78 learned mask network')
        if phase=='known':
            arrays=context.selected(reg['assets']['known110'],tuple(r+'_'+k for r in ('CAL','CP') for k in ('ids','groups','Z110','stage1','predicted_fine')),pins)
            cal=field_errors(net,np.ascontiguousarray(arrays['CAL_Z110'][:,:78],np.float32),'CAL900',out,report)
            stage=arrays['CAL_stage1'];scale=scale_fit(cal,stage)
            cut=context.geometry.dvc.calibrate_known_cutoffs(np.max(cal/scale[stage],axis=1),stage)
            report['files']['calibration']=files.write(out/'CAL_field_units_and_cutoffs_before_CP.json',dict(scale=scale.tolist(),cutoffs=cut,query_used=False));report['CAL_fit']=1
            query=context.role_query(arrays,'CP')
        else:
            query=context.selected(reg['assets']['query110'],('ids','groups','Z110','stage1','predicted_fine'),pins)
            cal=files.js(control['files']['calibration'],pins);scale=np.asarray(cal['scale']);cut=cal['cutoffs']
        err=field_errors(net,np.ascontiguousarray(query['Z110'][:,:78],np.float32),phase,out,report)
        score=np.max(err/scale[query['stage1']],axis=1)
        existing=files.js(reg['context_registry'],pins)
        metric=context.metric_from_registry(existing,pins)
        prediction,raw,retained=context.geometry.route(metric,query,score,cut,out,'new_mask_hint',report)
        # Preserve the former feature-derived799 output; never consult truth here.
        old=context.selected(reg['assets']['evaluation'],('ids','old_comparator'),pins)
        base=old['old_comparator'] if phase=='current' else old['old_comparator'][:900]
        files.require(np.array_equal(query['ids'],old['ids'] if phase=='current' else old['ids'][:900]),'same fixed baseline row order')
        prediction=base.copy();prediction[raw&retained]=2
        pa=trained.core.previous.save(out,'complete_increment_before_truth',dict(ids=query['ids'],prediction=prediction,baseline=base,raw=raw,retained=retained),report)
        report['files']['prediction_seal']=files.write(out/'complete_increment_seal_before_truth.json',dict(prediction=pa,truth_opened=False));report['prediction_sealed']=True
        truth=context.selected(reg['assets']['evaluation'],('ids','truth'),pins);report['truth_opened']=True
        y=truth['truth'] if phase=='current' else truth['truth'][:900]
        gates=context.integer_gates(y,prediction,known_only=phase=='known');oldg=context.integer_gates(y,base,known_only=phase=='known')
        loss={n:int(np.sum((y==i)&(base==i)&(prediction!=i))) for i,n in enumerate(('BEN','KNA'))}
        trained.core.previous.save(out,'postseal_comparison',dict(ids=query['ids'],truth=y,prediction=prediction,baseline=base,raw=raw,retained=retained),report)
        report.update(execution_status='mask78_predictive_'+phase+'_evaluated',original_class_gates=gates,baseline_class_gates=oldg,
            known_correct_loss=loss,known_gate_passed=all(v['passed'] for v in gates.values()) and not any(loss.values()),
            evaluated_class_gates_passed=all(v['passed'] for v in gates.values()),all_three_integer99_passed=phase=='current' and all(v['passed'] for v in gates.values()),
            correct_delta={n:gates[n]['correct']-oldg[n]['correct'] for n in gates},raw_candidates=int(raw.sum()),retained_candidates=int(retained.sum()))
        files.require(trained.core.output_io.state_digest(net)==reg['mask_state_sha'],'masked state unchanged')
    except Exception as error:report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        after=trained.core.restore_runtime_flags(before);report['runtime_restored']=after==before
        report['input_sha256']=pins;report['wall_seconds']=time.perf_counter()-began;files.write(out/'report.json',report)
    return files.item(out/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for n in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+n)
    a=p.parse_args();print(json.dumps(freeze() if a.phase=='freeze' else run(a.phase,a.registry,a.registry_sha256,a.known_report,a.known_sha256)))
