"""Original genuine CIC2 source/whole817 roles and original158 graph/DVC owners."""
from pathlib import Path
import hashlib,importlib.util,io,json,sys
import numpy as np
H=Path(__file__).resolve().parent;MANIFEST=H/'INPUT_MANIFEST_V1050.json'
INHERITED_INPUTS=dict(path='E:/Experiment/software transcition/target99_v1022_20261024/cic2/inputs_v1022.py',sha256='27273dacb94badb06f47f072b4da53325b5d4a229febd066413559084ad6365a')

def require(x,s):
    if not bool(x):raise ValueError(s)
def descriptor(p):
    p=Path(p).resolve(strict=True);return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def raw(d):
    a=Path(d['path']).read_bytes();require(hashlib.sha256(a).hexdigest()==d['sha256'],'immutable asset '+d['path']);return a
def js(d):return json.loads(raw(d).decode('utf-8-sig'))
def arrays(d,keys):
    with np.load(io.BytesIO(raw(d)),allow_pickle=False)as a:return{k:a[k].copy()for k in keys}
def module(d,tag):
    raw(d);s=importlib.util.spec_from_file_location(tag+'_'+d['sha256'],d['path']);m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m);return m
def manifest():return json.loads(MANIFEST.read_text(encoding='utf-8'))
def groups(native):return np.asarray([hashlib.sha256(np.ascontiguousarray(r,np.float64).tobytes()).hexdigest()for r in native],dtype='U64')

def load_source():
    m=manifest();a=arrays(m['raw_source'],('FIT_ids','FIT_native78','FIT_y_fine','FIT_training_indices'));z=arrays(m['original_source158'],('ids','groups','Z158','true_fine'))
    g=groups(a['FIT_native78']);y=a['FIT_y_fine'];slots=a['FIT_training_indices']
    require(np.array_equal(a['FIT_ids'],z['ids'])and np.array_equal(y,z['true_fine'])and np.array_equal(g,z['groups']),'same genuine raw78/original158/source family and ID ordering')
    require(a['FIT_native78'].shape==(5987,78)and z['Z158'].shape==(5987,158)and len(np.unique(g))==5987 and slots.shape==(6000,)and slots.dtype.kind in'iu'and slots.min()>=0 and slots.max()<5987,'genuine5987 and original logical6000 map')
    require(np.bincount(y,minlength=9).tolist()==[4545,100,100,317,256,7,100,462,100]and np.bincount(y[slots],minlength=9).min()>=20,'original source Table1 known family counts and FIT-only floor')
    return dict(ids=a['FIT_ids'],native=a['FIT_native78'],Z=z['Z158'],groups=g,fine=y,field_columns=[np.asarray([j],np.int64)for j in range(78)],logical_fine=y[slots],logical_groups=g[slots],optimizer_indices=slots,original_optimizer_indices=slots,
        source_trace=dict(genuine_source_rows=5987,logical_source_rows=6000,original_parentmap_unchanged=True,only_real_classes=['BEN','KNA'],reference_copies=False,graph_and_DVC_original158=True))

def load_role(role):
    m=manifest();require(role in('CAL','CP','current'),'declared whole role')
    a=arrays(m['raw_roles'][role],('ids','native78','Z158'));p=arrays(m['roles'][role]['parent817'],('ids','prediction'));g=groups(a['native78'])
    require(np.array_equal(a['ids'],p['ids'])and len(a['ids'])==m['role_rows'][role]and len(np.unique(a['ids']))==len(a['ids']),'same complete role and whole817')
    owner=m['original_density_frames'][role];require(js(owner['density_owner'])['proposal_frame']==owner['proposal_frame'],'original723 density owner retained under817 extension')
    f=arrays(owner['proposal_frame'],('ids','groups','representatives','inverse'));inv=f['inverse'];rep=f['representatives']
    require(np.array_equal(a['ids'],f['ids'])and np.array_equal(f['groups'][inv],g)and np.array_equal(inv[rep],np.arange(len(rep))),'original density frame complete physical partition, own original reps')
    return dict(ids=a['ids'],native=a['native78'],Z=a['Z158'],groups=g,parent_prediction=p['prediction'],density_frame=dict(ids=f['ids'],group_order=f['groups'],representatives=rep,inverse=inv,owner=owner))

def load_known_labels(role):
    require(role in('CAL','CP'),'pure known controls only');old=module(INHERITED_INPUTS,'V1050_known_label_owner');return old.load_known_labels(role)
def fixed_metric():
    m=manifest();M=module(m['metric_code'],'V1050_original158_metric');v=M.PaperVariationalPairMetric.from_state(js(m['metric_state']));require(v.dimension==158,'only original158 geometry owner');return v
