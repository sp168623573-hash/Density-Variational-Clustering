"""Pinned CIC2017 Label-only census and ordinal-exclusion capacity upper bounds.

No native78 values, unknown feature fingerprints, cohort selection, model calls,
or DEV/final source authority are produced. Exact raw label strings are retained.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import time

from . import cic2017_native_known_inventory_v1 as inventory
from .config import CIC_FEATURE_COLUMNS, get_spec

ROOT = Path(__file__).resolve().parents[1]
SOURCE_SPECS = inventory.SOURCE_SPECS
SOURCE_DIR = inventory.SOURCE_DIR
BATCH_SIZE = inventory.BATCH_SIZE
SETTING = "CIC Setting1"
SPEC = get_spec(SETTING)
FAMILIES = ("BEN", *SPEC.known_families, *SPEC.unknown_families)
KNOWN_FAMILIES = ("BEN", *SPEC.known_families)
KNOWN_ROLES = {"FIT": 4200, "CAL": 900, "CP": 900}
KNOWN_TOTAL = 6000
SOURCE_REPORT_REL = "data/external_dev/processed/cic2017_native_known_source_extract_20261008_v1/report.json"
SOURCE_REPORT_SHA = "6375dd3fd443320c570db263b9ec090f3daf68bce3192252b6e3d3f382de60bc"
RECORDS_REL = "data/external_dev/processed/cic2017_native_known_source_extract_20261008_v1/ordered_source_records.json"
RECORDS_SHA = "9f68a69bcac1e800c622f56d579d00ae7ceac7260b68685a9f4482c8c11e1ea0"
INVENTORY_CODE_SHA = "446bf3d04fc805016c430802cf95a6690cb0fec237a675cee99f8ea157629520"
EXPLICIT_ALIASES = {
    "Web Attack   XSS": "Web Attack - XSS",
    "Web Attack   Sql Injection": "Web Attack - Sql Injection",
}
COUNT_FIELDS = ("source_rows", "all5800_ordinal_excluded_rows", "known6000_representative_ordinal_excluded_rows",
    "both_exclusion_sets_rows", "excluded_union_rows", "remaining_ordinal_rows_upper_bound")
POLICY = {
    "schema_version": "CIC2017-native-label-capacity-upper-bound-v1", "setting": SETTING,
    "source_provenance": inventory.POLICY["source_provenance"], "mirror_commit": inventory.POLICY["mirror_commit"],
    "source_columns_read": ["Label"], "batch_rows_maximum": BATCH_SIZE,
    "raw_label_policy": "exact Python string from native Arrow Label; no strip, case conversion, filename inference, or guessed aliases; null recorded separately",
    "explicit_aliases": EXPLICIT_ALIASES, "BENIGN_canonical_family": "BEN",
    "alias_authority": "only two exact CIC aliases already explicitly present in pinned data._normalize_label",
    "exclusion_policy": "fixed all5800(file SHA, zero-based ordinal) union fixed current known6000 representative source ordinals",
    "capacity_scope": "ordinal-filtered label-row upper bounds only; no native78 equality closure, deduplication, finite-value or cross-family feature checks",
    "native78_values_read": False, "unknown_feature_fingerprints_computed": False,
    "exact_feature_closure_performed": False, "numeric_finiteness_checked": False,
    "new_DEV_rows_selected": False, "new_roles_assigned": False, "source_or_DEV_or_final_admission_issued": False,
    "physical_event_independence_claimed": False, "fresh_independent_unknown_or_final_claimed": False,
    "model_training_or_inference_or_DVC": False, "target_Test_file_opened": False,
    "raw_source_SHA_checks_are_opaque_bytes_only": True,
    "Arrow_may_read_shared_Parquet_pages": True,
    "status": "FAIL_TARGET99", "published": False, "final_test_executed": False,
}


class NativeLabelCapacityStop(ValueError):
    pass


def require(value, reason):
    if not value:
        raise NativeLabelCapacityStop(reason)


sha = inventory.sha
write_json = inventory._write_json


def _pin(path, wanted, pins):
    path = Path(path).resolve()
    require(path.is_relative_to(ROOT) and path != ROOT, "workspace_registered_input_required")
    require(sha(path) == wanted and pins.get(str(path), wanted) == wanted, "registered_input_pin_changed:" + str(path))
    pins[str(path)] = wanted
    return path


def _canonical_family(raw):
    require(type(raw) is str, "non_null_native_label_must_be_string")
    mapped = EXPLICIT_ALIASES.get(raw, raw)
    if mapped == SPEC.benign_label:
        return "BEN"
    return mapped if mapped in FAMILIES[1:] else None


def _validate_known_records(records, exclusions):
    require(records["schema_version"] == "CIC2017-native-known-ordered-source-records-v1"
            and records["setting"] == SETTING and tuple(records["family_order"]) == KNOWN_FAMILIES
            and tuple(records["model_columns"]) == CIC_FEATURE_COLUMNS
            and set(records["roles"]) == set(KNOWN_ROLES)
            and records["source_records"] == records["feature_groups"] == KNOWN_TOTAL
            and records["copies_or_resampling_rows"] == 0, "fixed_original_known6000_record_schema")
    specs = {name: (digest, rows) for name, digest, rows in SOURCE_SPECS}
    lookup, seen_ids, seen_groups = {name: {} for name in specs}, set(), set()
    for role, count in KNOWN_ROLES.items():
        rows = records["roles"][role]
        require(len(rows) == count, "fixed_known_role_count")
        families = Counter()
        for record in rows:
            path = Path(record["source_file"]).resolve()
            require(path.name in specs and path == (ROOT / SOURCE_DIR / path.name).resolve(), "known_record_registered_source")
            source_sha, source_rows = specs[path.name]
            ordinal, family, fp = record["source_row_ordinal"], record["family"], record["canonical78_sha256"]
            require(type(ordinal) is int and 0 <= ordinal < source_rows and source_sha == record["source_file_sha256"]
                    and ordinal not in exclusions[path.name] and ordinal not in lookup[path.name]
                    and record["role"] == role and family in KNOWN_FAMILIES, "known_role_original_ordinal_and_family")
            require(type(fp) is str and len(fp) == 64 and all(c in "0123456789abcdef" for c in fp)
                    and fp not in seen_groups, "unique_known_canonical_feature_metadata")
            sample_id = f"cic:original-native2017:{source_sha}:{ordinal}:{fp}"
            require(record["sample_id"] == sample_id and sample_id not in seen_ids
                    and record["fine_label"] == KNOWN_FAMILIES.index(family)
                    and record["coarse_label"] == int(family != "BEN"), "known_role_metadata_same_index")
            seen_ids.add(sample_id); seen_groups.add(fp)
            lookup[path.name][ordinal] = family
            families[family] += 1
        require(set(families) == set(KNOWN_FAMILIES) and min(families.values()) >= 20, "known_family_original_floor20_unchanged")
    require(sum(len(v) for v in lookup.values()) == len(seen_ids) == KNOWN_TOTAL, "complete_known6000_exclusion_metadata")
    return lookup


def _load_registered_inputs(pins):
    _pin(Path(inventory.__file__), INVENTORY_CODE_SHA, pins)
    # Fixed inventory mechanics only: this hashes raw files but never scans rows.
    footers, exclusions = inventory._load_fixed_inputs(pins)
    source_path = _pin(ROOT / SOURCE_REPORT_REL, SOURCE_REPORT_SHA, pins)
    source = json.loads(source_path.read_text(encoding="utf-8"))
    require(source["schema_version"] == "CIC2017-native-known-source-extract-v1"
            and source["execution_status"] == "native_CIC1_known_source_extraction_completed"
            and source["source_role_binding_verified"] is True and source["all_input_pins_stable"] is True
            and source["source_extraction_completed"] is True and source["status"] == "FAIL_TARGET99"
            and source["published"] is False and source["final_test_executed"] is False,
            "completed_pinned_native_known6000_authority")
    records_path = _pin(ROOT / RECORDS_REL, RECORDS_SHA, pins)
    require(source["files"]["ordered_source_records"] == {"path": str(records_path), "sha256": RECORDS_SHA},
            "fixed_known_records_report_binding")
    known = _validate_known_records(json.loads(records_path.read_text(encoding="utf-8")), exclusions)
    pins[str(Path(__file__).resolve())] = sha(__file__)
    return footers, exclusions, known


def _empty_counts():
    return {field: 0 for field in COUNT_FIELDS}


def _add_counts(target, addition):
    for field in COUNT_FIELDS:
        target[field] += addition[field]


def _row_counts(historical, known):
    return dict(zip(COUNT_FIELDS, (1, int(historical), int(known), int(historical and known),
                                  int(historical or known), int(not historical and not known))))


class LabelCounts:
    def __init__(self):
        self.raw_labels, self.null_label = {}, _empty_counts()
        self.rows, self.known_verified, self.materialized_rows = 0, 0, 0

    def consume(self, batch, *, offset, historical, known, on_materialized):
        require(batch.schema.names == ["Label"] and type(offset) is int and offset >= 0
                and 0 < batch.num_rows <= BATCH_SIZE, "Label_only_bounded_batch_and_source_ordinal")
        raw_labels = batch.column("Label").to_pylist()
        on_materialized(len(raw_labels))
        self.materialized_rows += len(raw_labels)
        require(len(raw_labels) == batch.num_rows, "Label_column_row_alignment")
        for index, raw in enumerate(raw_labels):
            require(raw is None or type(raw) is str, "native_Label_is_exact_string_or_null")
            ordinal = offset + index
            if ordinal in known:
                require(raw is not None and _canonical_family(raw) == known[ordinal], "known_representative_raw_label_matches_frozen_family")
                self.known_verified += 1
            counts = _row_counts(ordinal in historical, ordinal in known)
            _add_counts(self.null_label if raw is None else self.raw_labels.setdefault(raw, _empty_counts()), counts)
            self.rows += 1

    def merge(self, other):
        for raw, counts in other.raw_labels.items():
            _add_counts(self.raw_labels.setdefault(raw, _empty_counts()), counts)
        _add_counts(self.null_label, other.null_label)
        self.rows += other.rows
        self.known_verified += other.known_verified
        self.materialized_rows += other.materialized_rows

    def summary(self):
        canonical = {family: _empty_counts() for family in FAMILIES}
        unmapped, aliases = {}, {}
        for raw, counts in self.raw_labels.items():
            family = _canonical_family(raw)
            if family is None:
                unmapped[raw] = dict(counts)
            else:
                _add_counts(canonical[family], counts)
                if raw in EXPLICIT_ALIASES:
                    aliases[raw] = {"canonical_family": family, "counts": dict(counts)}
        totals = _empty_counts()
        for counts in [self.null_label, *self.raw_labels.values()]:
            _add_counts(totals, counts)
        require(totals["source_rows"] == self.rows
                and totals["source_rows"] == totals["excluded_union_rows"] + totals["remaining_ordinal_rows_upper_bound"]
                and totals["excluded_union_rows"] == totals["all5800_ordinal_excluded_rows"]
                    + totals["known6000_representative_ordinal_excluded_rows"] - totals["both_exclusion_sets_rows"],
                "exact_label_and_exclusion_row_accounting")
        return {"exact_raw_label_counts": dict(sorted(self.raw_labels.items())), "null_label_counts": dict(self.null_label),
            "Table1_canonical_family_counts": canonical, "applied_exact_aliases": dict(sorted(aliases.items())),
            "unmapped_nonnull_raw_labels": dict(sorted(unmapped.items())), "all_label_rows": totals,
            "known_representative_labels_verified": self.known_verified,
            "unmapped_and_null_not_imputed_or_assigned_to_UNA": True,
            "all_remaining_counts_are_ordinal_capacity_upper_bounds": True,
            "mapped_family_zero_does_not_rule_out_unmapped_aliases": bool(unmapped),
            "feature_closure_dedup_finiteness_or_DEV_admission_performed": False}


def run_label_inventory(*, output_directory):
    output = Path(output_directory).resolve()
    require(output.is_relative_to(ROOT) and output != ROOT, "fresh_workspace_output_required")
    output.mkdir(parents=True, exist_ok=False)
    start, stage, pins = time.perf_counter(), "register_fixed_sources_and_known_ordinals", {}
    report = {**POLICY, "label_inventory_completed": False, "source_scan_started": False,
        "source_scans_completed": [], "label_materialization_occurred": False,
        "label_rows_materialized": 0, "label_batches_completed": 0, "label_rows_completed": 0,
        "all_input_pins_stable": False, "summary": None}
    try:
        footers, exclusions, known = _load_registered_inputs(pins)
        stage = "load_registered_Arrow_and_seal_policy_before_Label_scan"
        runtime_pins = {}
        arrow, pq, _ = inventory._load_arrow(runtime_pins)
        for path, expected in runtime_pins.items():
            _pin(path, expected, pins)
        policy = write_json(output / "label_only_policy_before_scan.json", {**POLICY,
            "source_specs": SOURCE_SPECS, "Table1_family_order": FAMILIES,
            "known6000_metadata_authority": {"source_report_sha256": SOURCE_REPORT_SHA, "ordered_records_sha256": RECORDS_SHA},
            "source_ordinal_exclusion_counts": {name: {"historical_all5800": len(exclusions[name]),
                "known6000_representatives": len(known[name]), "overlap": len(set(known[name]) & exclusions[name])}
                for name, _, _ in SOURCE_SPECS}, "input_sha256": dict(pins)})
        pins[policy["path"]] = policy["sha256"]
        report["policy_before_scan"] = policy
        total = LabelCounts()
        def materialized(rows):
            report["label_materialization_occurred"] = True
            report["label_rows_materialized"] += rows
        stage = "bounded_Label_only_exact_string_and_ordinal_census"
        for filename, digest, row_count in SOURCE_SPECS:
            parquet = pq.ParquetFile(ROOT / SOURCE_DIR / filename)
            inventory._verify_footer(parquet, footers[filename])
            offset, counts = 0, LabelCounts()
            report["source_scan_started"] = True
            for batch in parquet.iter_batches(batch_size=BATCH_SIZE, columns=["Label"]):
                counts.consume(batch, offset=offset, historical=exclusions[filename], known=known[filename], on_materialized=materialized)
                offset += batch.num_rows
                report["label_batches_completed"] += 1
                report["label_rows_completed"] += batch.num_rows
            require(offset == counts.rows == row_count and counts.known_verified == len(known[filename]),
                    "complete_source_labels_and_known_ordinal_coverage")
            result = counts.summary()
            require(result["all_label_rows"]["all5800_ordinal_excluded_rows"] == len(exclusions[filename]),
                    "complete_historical_ordinal_coverage")
            progress = {"source_file": filename, "source_sha256": digest, "footer_rows": row_count,
                "label_rows_scanned": offset, "column_names_read": ["Label"], **result}
            report["source_scans_completed"].append(progress)
            total.merge(counts)
            print(json.dumps({"source_file": filename, "label_rows_completed": offset,
                "raw_distinct_nonnull_labels": len(counts.raw_labels), "null_labels": counts.null_label["source_rows"]}, ensure_ascii=False), flush=True)
        stage = "aggregate_label_capacity_upper_bounds_without_numeric_checks"
        require(total.known_verified == KNOWN_TOTAL and total.rows == sum(rows for _, _, rows in SOURCE_SPECS),
                "all_sources_and_known6000_label_coverage")
        report["summary"] = total.summary()
        summary_file = write_json(output / "exact_label_capacity_upper_bounds.json", report["summary"])
        pins[summary_file["path"]] = summary_file["sha256"]
        report["summary_artifact"] = summary_file
        stage = "final_source_code_policy_and_metadata_integrity"
        for path, expected in pins.items():
            require(sha(path) == expected, "input_changed_during_label_census:" + path)
        report.update(label_inventory_completed=True, all_input_pins_stable=True,
            execution_status="native_CIC2017_label_capacity_upper_bound_completed")
    except Exception as error:
        report.update(execution_status="protocol_stop" if isinstance(error, (NativeLabelCapacityStop, inventory.NativeKnownInventoryStop)) else "execution_failed",
            failed_stage=stage, error_type=type(error).__name__, error_message=str(error))
    report.update(input_sha256=pins, wall_seconds=time.perf_counter() - start)
    write_json(output / "report.json", report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-directory", type=Path, required=True)
    report = run_label_inventory(output_directory=parser.parse_args(argv).output_directory)
    print(json.dumps({k: report[k] for k in ("execution_status", "label_inventory_completed", "label_rows_completed", "wall_seconds", "status", "published")}))
    return 0 if report["label_inventory_completed"] else 2 if report["execution_status"] == "protocol_stop" else 1


if __name__ == "__main__":
    raise SystemExit(main())
