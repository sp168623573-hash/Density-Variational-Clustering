"""CIC2 cluster-router profile inputs; reuse source geometry, never failed actions."""
from pathlib import Path
import hashlib,importlib.util,io,json,sys
import numpy as np
H=Path(__file__).resolve().parent;MANIFEST=H/'INPUT_MANIFEST_V998.json'

def require(v,s):
    if not bool(v):raise ValueError(s)

def descriptor(path):
    p=Path(path).resolve(strict=True);return dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())

def raw(d):
    b=Path(d['path']).read_bytes();require(hashlib.sha256(b).hexdigest()==d['sha256'],'immutable '+d['path']);return b

def js(d):return json.loads(raw(d).decode('utf-8-sig'))

def arrays(d,keys):
    with np.load(io.BytesIO(raw(d)),allow_pickle=False)as a:return{k:a[k]for k in keys}

def module(d,prefix):
    raw(d);sp=importlib.util.spec_from_file_location(prefix+'_'+d['sha256'],d['path']);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m);return m

def manifest():return json.loads(MANIFEST.read_text(encoding='utf8'))

def original():return module(manifest()['inherited_inputs'],'V998_original817_inputs')

def load_source():
    a=original();s=a.load_source();z=arrays(manifest()['source249'],('ids','groups','fine','Z'))
    require(np.array_equal(z['ids'],s['ids'])and np.array_equal(z['groups'],s['groups'])and np.array_equal(z['fine'],s['fine']),'same source-only249 real parent/fine ordering')
    require(s['native'].shape==(5987,78)and z['Z'].shape==(5987,249)and len(s['field_columns'])==78,'source-native78/atomic78fields/fixed249')
    return dict(ids=s['ids'],groups=s['groups'],fine=s['fine'],native=s['native'],native78=s['native'],Z249=z['Z'],field_columns=s['field_columns'],
        logical_X=s['logical_X'],logical_fine=s['logical_fine'],logical_groups=s['logical_groups'],optimizer_indices=s['optimizer_indices'],
        source_trace=dict(s['source_trace'],genuine_source_rows=5987,logical_source_rows=6000,source_geometry_refit=False),NN_fit=0,NN_readout=0,newmetricfit=0)

def geometry_bundle():
    import joblib
    return joblib.load(io.BytesIO(raw(manifest()['geometry_bundle'])))

def load_role(role):
    require(role in('CAL','CP','current'),'declared complete CIC2 role')
    a=original();q=a.load_role(role);m=manifest();C=module(m['geometry_code'],'V998_source_owned249_geometry')
    sc=C.score(q['X'],q['Z158'],geometry_bundle());z=sc['Z']
    require(z.shape==(len(q['ids']),249),'same frozen native-to249 source geometry transform')
    return dict(ids=q['ids'],groups=q['groups'],native=q['native'],native78=q['native'],Z249=z,parent_prediction=q['parent_prediction'],role=role,
        NN_fit=0,NN_readout=0,newmetricfit=0,current_truth_decodes=0,old_failed_actions_consumed=False,old_failed_cuts_consumed=False)

def load_known_labels(role):
    require(role in('CAL','CP'),'CAL fitting or separately sealed CP only; no current truth API')
    return original().load_known_labels(role)

def fixed_metric():
    m=manifest();M=module(m['metric_code'],'V998_original249_metric_class');metric=M.PaperVariationalPairMetric.from_state(js(m['metric_state']))
    require(metric.dimension==249,'same source-fitted249 Eq9/10 metric only')
    return metric

def prepare_manifest():
    h=Path('E:/Experiment/software transcition/target99_v994_20261024/cic2');a=module(descriptor(h/'inputs_cic2_v994.py'),'V998_metadata_original817');m=a.manifest()
    c=js(descriptor(h/'CONTRACT_V994.json'));s=js(descriptor(h/'actual_once/source/report.json'))
    value=dict(schema='V998_CIC2_CLUSTER_OBJECT_PROFILE_INPUTS',setting='CIC Setting2',parent='V915_complete817',
        inherited_inputs=descriptor(h/'inputs_cic2_v994.py'),inherited_input_manifest=descriptor(a.MANIFEST),
        geometry_code=c['code']['core'],geometry_bundle=s['files']['bundle'],source249=s['files']['source_scores'],
        metric_code=c['code']['metric'],metric_state=s['files']['metric'],fieldmap_manifest=m['original_fieldmap'],roles=m['roles'],
        source_genuine_rows=5987,logical_source_rows=6000,native_encoded_width=78,original_field_groups=78,density_geometry_dimension=249,
        current_truth_authority=m['current_truth_authority'],current_support=[1465,519,1200],current_CP882_not_full_subset=True,
        source_training_only=['BEN','KNA'],newNNfit=0,newNNreadout=0,newmetricfit=0,old_failed_actions_consumed=False,old_failed_cuts_consumed=False,
        all_original_wholeversions_preserved=True,original723_preserved=True,parent_correct_integer_counts=[1454,506,817],required_correct_integer_counts=[1451,514,1188],necessary_new_correct_minimum=[0,8,371],
        pretruth_capacity='upper_c=parentcorrect_c+count(parentpred!=c and childpred==c); insufficient any class stops unscored',
        no_current_truth_read_during_preparation=True,status='FAIL_TARGET99',published=False,final_test_executed=False)
    with MANIFEST.open('x',encoding='utf8')as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
    return descriptor(MANIFEST)

if __name__=='__main__':print(json.dumps(prepare_manifest(),ensure_ascii=False))
