"""FIT-only signcell-balanced conditional StudentT3 uncertainty on full78 masked MHFD.

Exact V53 backbone warm start, four new variance-head tensors, one fixed30
continuation. Primary classifier and all historical states stay immutable.
"""
from __future__ import annotations
import argparse
from collections import Counter
import io
import json
from pathlib import Path
import time
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from . import cic1_known6000_maskaux_predictive78_v53 as previous

ROOT,files,core,helpers=previous.ROOT,previous.files,previous.core,previous.helpers
BASE=ROOT/'data/external_dev/processed/cic1_known6000_student_signcells78_20261011_v60'
REGDIR=ROOT/'tmp/cic1_known6000_student_signcells78_20261011_v60'
PARENT=dict(path=str(previous.BASE/'report.json'),sha256='1fe95ff67390a0fae9acad1dcb0a998b6ddd9318405a390cb8943be874d23b1b')
VARIANCE_FLOOR=1.e-4
NEW_KEYS=('variance_head.0.weight','variance_head.0.bias','variance_head.2.weight','variance_head.2.bias')


def recipe():
    return dict(schema_version='CIC1-full78-known6000-fine-field-signcell-StudentT3-final30-v60',hypotheses=1,
        warm='exact completed V53 predictive-dominated final80 full78 masked MHFD backbone; all old keys strict, old state unchanged',
        architecture='maskedembedding32 -> Linear64 -> SiLU -> Linear78 variance_raw; shared full78 mean decoder/encoder/field tokens',
        variance='softplus(raw.float32)+1e-4; fixed statistical minimum variance in frozen signedlog/FIT-RMS coordinates; not a CAL threshold patch',
        variance_floor=VARIANCE_FLOOR,new_keys=list(NEW_KEYS),field_count=78,input_width=78,
        loss='.1 clean coarseCE + .035 clean fineCE(smoothing.01) + 1.0 masked-only StudentT3 .5log(variance/3)+2log1p(squared residual/variance)',
        likelihood='proper Student nu3 scale2=variance/3, field-conditional NLL up to universalconstant; cost-sensitive sampling, not original-frequency MLE or claimed joint density',
        mask='exact BEN3000 and8knownKNA375each; uniformbalanced78 fields withinfine; choose native exactsign -/0/+ nonemptycell uniformly then genuinecellrow uniformly, replacement views only',
        FIT_original=6000,optimizer_draws=6000,train_union_unique_rows=6000,optimizer_traffic_rows=6000,
        seed=20261011,epochs=30,batch_size=128,optimizer='AdamW .001 wd.0002 cosine30 min.0001 clip5',
        checkpoint='fixed final30, no query-based checkpoint selection',primary_classifier_unchanged=True,
        unknown_training=False,query_numeric_decodes=0,query_parameter_fit=False,units_refit=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)


class StudentMaskedMHFD(nn.Module):
    def __init__(self,backbone):
        super().__init__();self.backbone=backbone
        self.variance_head=nn.Sequential(nn.Linear(32,64),nn.SiLU(),nn.Linear(64,78))

    def forward(self,x):
        return self.backbone(x)

    def forward_masked(self,x,fields):
        result=self.backbone.forward_masked(x,fields)
        raw=self.variance_head(result['embedding'])
        result.update(variance_raw=raw,variance=F.softplus(raw.float())+VARIANCE_FLOOR)
        return result


def freeze():
    pins={};p=files.js(PARENT,pins);r=files.js(p['registry'],pins)
    files.require(p['epochs_completed']==80 and p['unknown_values_opened'] is False and p['policy']==previous.recipe(),'actual known-only V53 final80 warm producer')
    assets=dict(native=r['assets']['native'],units=r['assets']['units'],warm_model=p['files']['model'])
    for a in assets.values():files.read(a,pins)
    sources={str(Path(m.__file__).resolve()):files.item(m.__file__) for m in (previous,core,core.previous,core.mask_core,core.output_io,helpers,helpers.network,files)}
    sources[str(Path(__file__).resolve())]=files.item(__file__)
    for a in sources.values():files.read(a,pins)
    files.require(not BASE.exists() and not REGDIR.exists(),'fresh Student signcell training files')
    REGDIR.mkdir(parents=True,exist_ok=False)
    return files.write(REGDIR/'registry_before_FIT_only_Student_signcell_training.json',dict(policy=recipe(),assets=assets,sources=sources,parent=PARENT,
        field_map=r['field_map'],field_map_sha256=r['field_map_sha256'],warm_state_sha256=p['model_state_sha256'],output=str(BASE),input_sha256=pins,
        unknown_numeric_decodes=0,unknown_truth_decodes=0))


def warm_model(reg,pins,device):
    saved=torch.load(io.BytesIO(files.read(reg['assets']['warm_model'],pins)),map_location='cpu',weights_only=True)
    for key in ('field_map','field_map_sha256','input_dim','state_dict','model_state_sha256'):
        files.require(key in saved,'missing checkpoint '+key+'; available='+','.join(sorted(saved)))
    fmap=core.field_map_from_state(reg['field_map'])
    files.require(saved['input_dim']==78 and saved['field_map']==reg['field_map'] and fmap.file_sha256==saved['field_map_sha256']==reg['field_map_sha256'], 'exact canonical78 field map of warm backbone')
    backbone=core.ExpandedWholeFieldMaskedMHFD(fmap,9)
    loaded=backbone.load_state_dict(saved['state_dict'],strict=True)
    files.require(not loaded.missing_keys and not loaded.unexpected_keys and core.output_io.state_digest(backbone)==reg['warm_state_sha256'], 'all exact V53 backbone tensors strict loaded')
    net=StudentMaskedMHFD(backbone)
    newkeys=set(net.state_dict())-{'backbone.'+k for k in saved['state_dict']}
    files.require(newkeys==set(NEW_KEYS),'exact four declared new uncertainty tensors only')
    return net.to(device)


def objective(net,x,coarse,fine,mask):
    core.mask_core._features(x,78)
    files.require(coarse.dtype==fine.dtype==torch.int64 and torch.equal(coarse==0,fine==0),'known FIT BEN/KNA labels')
    clean=net(x);masked=net.forward_masked(x,mask)
    mu=masked['reconstruction'].float();variance=masked['variance'];hidden=masked['masked_columns']
    residual=mu-x.detach();nll=.5*torch.log(variance/3.)+2.*torch.log1p(residual.square()/variance)
    files.require(bool(torch.isfinite(nll).all()) and bool((variance>=VARIANCE_FLOOR).all()),'finite unclipped conditional StudentT3 masked NLL')
    nll_loss=((nll*hidden).sum(dim=1)/hidden.sum(dim=1)).mean()
    coarse_loss=F.cross_entropy(clean['coarse_logits'],coarse);fine_loss=F.cross_entropy(clean['fine_logits'],fine,label_smoothing=.01)
    loss=.1*coarse_loss+.035*fine_loss+nll_loss
    files.require(bool(torch.isfinite(loss)),'finite fixed30 StudentT3 objective')
    return dict(loss=loss,coarse_loss=coarse_loss,fine_loss=fine_loss,masked_loss=nll_loss,
        masked_NLL_min=float(nll[hidden].detach().min()),masked_NLL_max=float(nll[hidden].detach().max()),
        variance_min=float(variance[hidden].detach().min()),variance_max=float(variance[hidden].detach().max()))


def make_cells(native,fine):
    native=np.asarray(native,np.float64);fine=np.asarray(fine)
    files.require(native.shape==(6000,78) and np.isfinite(native).all() and set(fine.tolist())==set(range(9)), 'actual native78 values and known9 fine only')
    signs=np.sign(native).astype(np.int8);cells={};manifest=[]
    for f in range(9):
        for field in range(78):
            nonempty={}
            for sign in (-1,0,1):
                rows=np.flatnonzero((fine==f)&(signs[:,field]==sign))
                if len(rows):nonempty[sign]=rows
            files.require(bool(nonempty),'every fine/field has actual nativecell')
            cells[(f,field)]=nonempty
            manifest.append(dict(fine=f,field=field,field_name=helpers.CIC_FEATURE_COLUMNS[field],sign_cell_support={str(k):len(v) for k,v in nonempty.items()}))
    return cells,dict(schema_version='fine-native78-exactsign-sourcecells-v60',cells=manifest,exact_native_sign=True,epsilon=0,original_training_rows=6000,optimizer_views_are_new_traffic=False,cost_sensitive_not_original_frequency_MLE=True)


def sample_signcells(cells,epoch):
    rng=np.random.default_rng(np.random.SeedSequence([20261011,epoch]));allrows=[];allfields=[];cell_draws=[]
    for f in range(9):
        n=3000 if f==0 else 375
        fields=rng.permutation(78)[np.arange(n)%78];fields=fields[rng.permutation(n)]
        selected=np.empty(n,np.int64);signselected=np.empty(n,np.int8)
        for i,field in enumerate(fields):
            actual=cells[(f,int(field))];options=np.asarray(sorted(actual),np.int8)
            sign=int(options[rng.integers(len(options))]);rows=actual[sign];selected[i]=rows[rng.integers(len(rows))];signselected[i]=sign
        for field in range(78):
            for sign,rows in cells[(f,field)].items():
                mask=(fields==field)&(signselected==sign)
                cell_draws.append(dict(fine=f,field=field,sign=sign,source_support=len(rows),draws=int(mask.sum()),unique_drawn_rows=int(len(np.unique(selected[mask])))))
        allrows.append(selected);allfields.append(fields.astype(np.int64))
    rows=np.concatenate(allrows);fields=np.concatenate(allfields);order=rng.permutation(6000)
    manifest=dict(epoch=epoch+1,total_draws=6000,unique_drawn_original_rows=len(np.unique(rows)),fine_draw_counts={str(f):3000 if f==0 else 375 for f in range(9)},all78_field_counts=np.bincount(fields,minlength=78).tolist(),cell_draws=cell_draws,cost_sensitive_not_original_frequency_MLE=True,additional_source_or_density_rows=0)
    return rows[order],fields[order],manifest


def train(path,sha):
    pins={};ref=dict(path=str(Path(path).resolve()),sha256=sha);reg=files.js(ref,pins)
    files.require(reg['policy']==recipe() and reg['sources'][str(Path(__file__).resolve())]==files.item(__file__),'own frozen uncertainty training source')
    for a in reg['sources'].values():files.read(a,pins)
    files.require(not BASE.exists(),'fresh actual Student signcell training output');BASE.mkdir(parents=True,exist_ok=False)
    before=core.capture_runtime_flags();started=time.perf_counter()
    report=dict(policy=recipe(),registry=ref,files={},training_runs=0,epochs_completed=0,unknown_values_opened=False,
        known_query_numeric_decodes=0,unknown_truth_decodes=0,accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        raw=core.previous.archive(reg['assets']['native'],('FIT_native78','FIT_ids','FIT_y_fine','FIT_y_coarse'),pins)
        units=np.asarray(files.js(reg['assets']['units'],pins)['native78']);x=((np.sign(raw['FIT_native78'])*np.log1p(np.abs(raw['FIT_native78'])))/units).astype(np.float32)
        counts=Counter(raw['FIT_y_fine'].tolist());files.require(x.shape==(6000,78) and len(np.unique(raw['FIT_ids']))==6000
            and set(counts)==set(range(9)) and min(counts.values())>=20 and np.isfinite(x).all(),'genuine6000 known FIT and minimum20 eachfamily')
        core.previous.save(BASE,'actual_FIT6000_before_Student_signcell_training',dict(features=x,ids=raw['FIT_ids'],fine=raw['FIT_y_fine'],coarse=raw['FIT_y_coarse']),report)
        torch.set_num_threads(4);helpers.network.set_seed(20261011)
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu');net=warm_model(reg,pins,device)
        report['warm_backbone_state_sha256']=core.output_io.state_digest(net.backbone)
        report['initial_state_sha256']=core.output_io.state_digest(net)
        opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.0002);sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=30,eta_min=.0001)
        scaler=torch.amp.GradScaler('cuda',enabled=device.type=='cuda')
        cells,cell_manifest=make_cells(raw['FIT_native78'],raw['FIT_y_fine'])
        report['files']['cells_before_optimizer']=files.write(BASE/'allfine_all78_native_exactsign_support_before_optimizer.json',cell_manifest)
        history=[];began=time.perf_counter();report['training_runs']=1
        for epoch in range(1,31):
            net.train();idx,masks,draw_manifest=sample_signcells(cells,epoch-1)
            report['files']['draws_epoch'+str(epoch)]=files.write(BASE/('signcell_draws_epoch'+str(epoch)+'.json'),draw_manifest)
            core.previous.save(BASE,'actual_draw_indices_fields_epoch'+str(epoch),dict(indices=idx,fields=masks),report)
            files.require(np.array_equal(np.bincount(raw['FIT_y_fine'][idx],minlength=9),np.asarray([3000]+[375]*8)) and len(idx)==len(masks)==6000,'actual6000 fine-balanced optimizerdraws')
            sums={key:0. for key in ('loss','coarse_loss','fine_loss','masked_loss')};seen=0
            vmin,nmin=float('inf'),float('inf');vmax,nmax=-float('inf'),-float('inf')
            for first in range(0,6000,128):
                ix=idx[first:first+128];xb=torch.from_numpy(x[ix].copy()).to(device)
                cb=torch.from_numpy(raw['FIT_y_coarse'][ix].copy()).to(device);fb=torch.from_numpy(raw['FIT_y_fine'][ix].copy()).to(device)
                mask=torch.from_numpy(masks[first:first+len(ix)].copy()).to(device);opt.zero_grad(set_to_none=True)
                with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=device.type=='cuda'):values=objective(net,xb,cb,fb,mask)
                scaler.scale(values['loss']).backward();scaler.unscale_(opt);nn.utils.clip_grad_norm_(net.parameters(),5.)
                scaler.step(opt);scaler.update();seen+=len(ix)
                for key in sums:sums[key]+=float(values[key].detach())*len(ix)
                vmin=min(vmin,values['variance_min']);vmax=max(vmax,values['variance_max']);nmin=min(nmin,values['masked_NLL_min']);nmax=max(nmax,values['masked_NLL_max'])
            sched.step();history.append(dict(epoch=epoch,optimizer_draws=seen,**{key:value/seen for key,value in sums.items()},variance_min=vmin,variance_max=vmax,masked_NLL_min=nmin,masked_NLL_max=nmax))
            core.save_epoch_history(BASE,history,epoch,report)
            if epoch==1 or epoch%10==0:print(f'[CIC1 Student signcells78] epoch={epoch}/30 NLL={sums["masked_loss"]/seen:.6f} variance=[{vmin:.4g},{vmax:.4g}] elapsed={time.perf_counter()-began:.1f}s',flush=True)
        report.update(training_seconds=time.perf_counter()-began,epochs_completed=30,device=str(device),actual_FIT_fine_support=dict(counts))
        state=core.output_io.state_digest(net);checkpoint=BASE/'Student_signcell_full78_final30.pt'
        with checkpoint.open('xb') as f:torch.save(dict(state_dict={k:a.detach().cpu() for k,a in net.state_dict().items()},input_dim=78,fine_classes=9,
            field_map=reg['field_map'],field_map_sha256=reg['field_map_sha256'],model_state_sha256=state,training_policy=recipe(),warm=reg['assets']['warm_model'],variance_floor=VARIANCE_FLOOR,new_keys=list(NEW_KEYS)),f)
        report.update(model_state_sha256=state,execution_status='known_FIT_only_Student_signcell_training_completed',primary_classifier_unchanged=True)
        report['files']['model']=files.item(checkpoint)
        for p,wanted in pins.items():files.require(files.item(p)['sha256']==wanted,'old source/input/warmstate immutable')
    except Exception as error:report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        after=core.restore_runtime_flags(before);report.update(runtime_restoration=dict(before=before,after=after,all_flags_restored=before==after),wall_seconds=time.perf_counter()-started,input_sha256=pins)
        files.write(BASE/'report.json',report)
    return files.item(BASE/'report.json')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--phase',choices=('freeze','train'),required=True)
    for name in ('registry','registry-sha256'):parser.add_argument('--'+name)
    args=parser.parse_args();print(json.dumps(freeze() if args.phase=='freeze' else train(args.registry,args.registry_sha256)))
