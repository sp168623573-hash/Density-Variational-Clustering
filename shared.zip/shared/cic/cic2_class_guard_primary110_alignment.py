"""Own shared-FIT110 novelty alignment for the sealed CIC2 class guard.

Live CPU classifiers (including the frozen fine9 HGB) produce all stage decisions. Cached old predictions never decide a new row. New
geometry uses their primary embedding32 and all native78 fields from exactly
the shared 5987 genuine FIT groups. One fresh CPU Eq9/10 metric, true-fine
references and local radii precede original CAL finite99 calibration. Both
CP/CAL DVC predictions are sealed before truth. No unknown entry is offered.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import time

import joblib
import numpy as np
import torch

from . import cic2_fine_hist_class_support_v1 as guard
from . import cic2017_setting2_signed_log_cached_blend_v1 as main
from . import cic_fit6000_aux110_pair_metric_v1 as learned
from . import cic1_hybrid110_current_dvc_v1 as dvc

h, fine, ROOT = guard.h, guard.fine, guard.ROOT
nn, forest = main.nn, main.forest
OUT = ROOT / 'data/external_dev/processed/cic2_class_guard_primary110_alignment_20261011_v2'
REGISTRY_OUT = ROOT / 'tmp/cic2_class_guard_primary110_alignment_20261011_v2'
GUARD = dict(path=str(guard.OUT / 'report.json'),
             sha256='7999d7950cec225f6a5c450faf55e0c2e65906fce38e53951764d7665de4bd31')
GUARD_SOURCE_SHA = '3036b408fbcbbb714fcb96081a17aa60aee3c6f0db4124c10d3b488406e707d5'
MATERIAL = dict(fine.MATERIAL)
STRONG = dict(path=str(ROOT / 'data/external_dev/processed/cic2017_setting2_signed_log_cached_blend_20261008_v1/CIC_Setting2/report.json'),
              sha256='4286abcff8d7805e44af2d3450d8891ecdd2d43a5fa7d25ab6bd0efec17bb36d')


def policy():
    return dict(schema_version='CIC2-class-guard-shared5987-liveCPU-primary110-owned-CAL-alignment-v2', hypotheses=1,
        classifier='sealed original strong MHFD and quarter forest plus own class-specific Fisher/HGB CP-envelope guard; actual CPU classification with original strong threshold; cached old outputs used only for postseal comparisons',
        geometry='all native78 signedlog/shared-genuineFIT column RMS followed by frozen original strong signedlog selected50 MHFD embedding32/shared-genuineFIT column RMS',
        CPU_replay='consistent fresh float32 CPU primary embeddings for FIT/CP/CAL; primary NN/forest weights preserved; no CUDA entry',
        predicted_fine='BEN coarse means fine0; existing KNA uses attack argmax of .75 NN fine9 plus .25 forest fine9; guard-admitted KNA uses frozen HGB predicted attack fine',
        units='fit only shared5987 genuine FIT; native zero column RMS unit1; copies absent',
        metric='fresh FIT-only Eq9/10 core, fixed80 CPU epochs,8192 fine-balanced pairs; source schema fixed by caller; no old fitted state',
        reference='all5987 genuine shared FIT groups, true fine9 labels, no optimizer copies and no filtering',
        radius='per-true-fine min(7,n-1) other-reference learned distance; self excluded; natural zeros retained',
        score='nearest predicted-fine learned distance d squared/(d squared+r squared); largest radius on exact nearest ties; bothzero0',
        CAL='all882 original known scores, predicted-coarse-conditional finite99 order statistic; strictgreater; no truth',
        DVC='one CP and one CAL, original features only, current candidates only; identical frozen110 metric for primary and secondary density/affinity/noise',
        gate='original and reporting CP/CAL BEN/KNA integer99 AND zero loss of originally correct sealed class-guard predictions',
        training_union_unique=5987, frozen_HGB_optimizer_rows=6000, frozen_HGB_optimizer_copies=13,
        metric_optimizer_traffic_copies=0, new_classifier_fit=0, CP_classifier_threshold_fit=0,
        unknown_entry=False, unknown_reads=0, unknown_roster_modified=False,
        independent_final_asserted=False, accepted_baseline_replaced=False,
        status='FAIL_TARGET99', published=False, final_test_executed=False)


def bindings():
    h.require(h.sha(guard.__file__) == GUARD_SOURCE_SHA, 'sealed_class_guard_source_preserved')
    guard.bindings()
    modules = (__file__, guard.__file__, main.__file__, nn.__file__, forest.__file__,
        h.__file__, h.network.__file__, h.header_tools.__file__, learned.__file__, dvc.__file__)
    return {str(Path(path).resolve()): h.sha(path) for path in modules}


def rms_unique(values):
    values = np.asarray(values, np.float64)
    h.require(values.ndim == 2 and len(values) > 0 and np.isfinite(values).all(), 'finite_uniqueFIT_RMS_input')
    maxima = np.max(np.abs(values), axis=0)
    positive = maxima > 0
    units = np.ones(values.shape[1], np.float64)
    units[positive] = maxima[positive] * np.sqrt(np.mean(np.square(values[:, positive] / maxima[positive]), axis=0))
    h.require(np.isfinite(units).all() and np.all(units > 0), 'positive_native_zero_unit1_RMS')
    return units


def group_hashes(native):
    return np.asarray([hashlib.sha256(np.ascontiguousarray(row).tobytes()).hexdigest() for row in native], dtype=np.str_)


def novelty_fine(stage1, neural_fine, forest_fine, guard_admitted, guard_predicted_fine):
    stage1, admitted, aux = np.asarray(stage1), np.asarray(guard_admitted), np.asarray(guard_predicted_fine)
    neural, trees = np.asarray(neural_fine), np.asarray(forest_fine)
    h.require(stage1.dtype == aux.dtype == np.int64 and stage1.ndim == 1
        and stage1.shape == admitted.shape == aux.shape and admitted.dtype == bool
        and neural.shape == trees.shape == (len(stage1), 9)
        and np.isin(stage1, (0, 1)).all() and np.isin(aux, range(9)).all()
        and np.isfinite(neural).all() and np.isfinite(trees).all()
        and np.all((neural >= 0) & (neural <= 1)) and np.all((trees >= 0) & (trees <= 1))
        and np.all(~admitted | ((stage1 == 1) & (aux > 0))), 'fixed_classifier_output_only_fine_semantics')
    result = np.zeros(len(stage1), np.int64)
    attacks = stage1 == 1
    blended = .75 * neural.astype(np.float64) + .25 * trees.astype(np.float64)
    result[attacks] = np.argmax(blended[attacks, 1:], axis=1) + 1
    result[admitted] = aux[admitted]
    return result


@torch.no_grad()
def frozen_outputs(net, transforms, trees, native):
    features = nn.transform_native78(transforms, native)
    embedding, probabilities, coarse = [], [], []
    net.eval()
    for start in range(0, len(features), 512):
        raw = net(torch.from_numpy(np.ascontiguousarray(features[start:start + 512], np.float32)))
        embedding.append(raw['embedding'].numpy().copy())
        probabilities.append(torch.softmax(raw['fine_logits'], dim=1).numpy().copy())
        coarse.append(torch.softmax(raw['coarse_logits'], dim=1)[:,1].numpy().copy())
    values = dict(embedding32=np.concatenate(embedding), neural_fine=np.concatenate(probabilities), neural_coarse=np.concatenate(coarse),
                  forest_fine=forest._predict_fine(trees, forest._tree_input(native)))
    h.require(values['embedding32'].shape == (len(native), 32)
        and values['neural_fine'].shape == values['forest_fine'].shape == (len(native), 9)
        and all(np.isfinite(value).all() for value in values.values()), 'complete_frozen_CPU_known_outputs')
    values['neural_probability']=.55*values['neural_coarse']+.45*(1-values['neural_fine'][:,0])
    values['main_probability']=.75*values['neural_probability'].astype(np.float64)+.25*(1-values['forest_fine'][:,0].astype(np.float64))
    values['main_prediction']=(values['main_probability']>=.7977294921875).astype(np.int64)
    return values


def fit_radii(metric, z, true_fine):
    radius = np.zeros(len(z), np.float64)
    for label in range(9):
        indices = np.flatnonzero(true_fine == label)
        h.require(len(indices) >= 2, 'truefine_two_genuine_reference_groups:' + str(label))
        # Only memory batching: every same-fine peer remains in each block.
        k = min(7, len(indices) - 1)
        for start in range(0, len(indices), 128):
            rows = indices[start:start + 128]
            distances = metric.pairwise_distances(z[rows], z[indices])
            distances[np.arange(len(rows)), np.arange(start, start + len(rows))] = np.inf
            radius[rows] = np.partition(distances, k - 1, axis=1)[:, k - 1]
    h.require(np.isfinite(radius).all() and np.all(radius >= 0), 'complete_natural_truefine_R7')
    return radius


def scores(metric, z, predicted_fine, reference, true_fine, radius):
    predicted_fine = np.asarray(predicted_fine)
    h.require(z.shape == (len(predicted_fine), 110) and predicted_fine.dtype == np.int64
        and np.isin(predicted_fine, range(9)).all(), 'label_blind_owned110_predictedfine_queries')
    result = np.empty(len(z), np.float64)
    for label in np.unique(predicted_fine):
        rows = np.flatnonzero(predicted_fine == label)
        indices = np.flatnonzero(true_fine == label)
        h.require(len(indices) > 0, 'genuine_truefine_reference_available')
        distances = metric.pairwise_distances(z[rows], reference[indices])
        nearest = distances.min(axis=1)
        local_radius = np.max(np.where(distances == nearest[:, None], radius[indices][None, :], -1.), axis=1)
        scale = np.maximum(nearest, local_radius)
        positive = scale > 0
        value = np.zeros(len(rows), np.float64)
        left, right = nearest[positive] / scale[positive], local_radius[positive] / scale[positive]
        value[positive] = left * left / (left * left + right * right)
        result[rows] = value
    h.require(np.isfinite(result).all() and np.all((result >= 0) & (result <= 1)), 'owned110_bounded_local_score')
    return result


def freeze():
    pins = {}
    parent = h.read(GUARD, pins)
    reg = h.read(parent['registry'], pins)
    material = h.read(MATERIAL, pins)
    primary, neural, trees = h.read(STRONG, pins), h.read(main.NN_REPORT, pins), h.read(main.FOREST_REPORT, pins)
    h.require(parent['known_gate_and_paired_loss_free'] and parent['prediction_sealed']
        and parent['unknown_reads'] == 0 and not parent['unknown_phase_allowed'], 'completed_zero_loss_class_guard_parent')
    h.require(material['source_arrays'] == reg['native'] and material['with_training_copies'] == 6000
        and material['original_primary_training_union_exact'] == 5987
        and material['policy']['old_primary_FIT_groups'] == 4187, 'exact_shared5987_optimizer6000_union')
    h.require(primary['selected']['weight'] == .25 and primary['selected']['threshold'] == .7977294921875
        and neural['configuration']['original_roles']['FIT'] == trees['configuration']['FIT_original_rows'] == 4187,
        'original_strong4187_NN_and_quarter_forest')
    auxiliary=h.read(dict(path=str(fine.OUT/'report.json'),sha256='8360fff6a9fa17eb540e3a1b0afa5f898466a88761b805bde6d460ab8fcc8417'),pins)
    model_assets = dict(NN=neural['files']['model'], preprocessing=neural['files']['preprocessing'], forest=trees['model'], HGB=auxiliary['files']['model'])
    class_geometry=parent['files']['geometry']
    h.checked(class_geometry,pins);h.checked(reg['envelope'],pins)
    all_assets = list(model_assets.values()) + [reg['native'], parent['files']['predictions'],
        parent['files']['prediction_seal'], reg['strong'], neural['files']['training_inputs'], trees['FIT_arrays']]
    for asset in all_assets:
        h.checked(asset, pins)
    for report in (neural, trees):
        for path, wanted in report['input_sha256'].items():
            h.checked(dict(path=path, sha256=wanted), pins)
    own_ids = fine.load(reg['native'], ('FIT_ids',), pins)['FIT_ids']
    nn_ids = fine.load(neural['files']['training_inputs'], ('FIT_ids',), pins)['FIT_ids']
    forest_ids = fine.load(trees['FIT_arrays'], ('FIT_ids',), pins)['FIT_ids']
    h.require(len(own_ids) == len(np.unique(own_ids)) == 5987 and len(nn_ids) == 4187
        and np.array_equal(nn_ids, forest_ids) and set(nn_ids.tolist()).issubset(own_ids.tolist()),
        'original_classifier_training_ID_union_subset_of_shared5987')
    headers = h.header_tools.npz_headers(h.checked(reg['native'], pins))
    h.require(headers['FIT_native78']['shape'] == [5987, 78]
        and headers['CP_native78']['shape'] == headers['CAL_native78']['shape'] == [882, 78], 'complete_genuine_known_native_headers')
    sources = bindings()
    for path, wanted in sources.items():
        h.checked(dict(path=path, sha256=wanted), pins)
    h.require(not OUT.exists() and not REGISTRY_OUT.exists(), 'fresh_owned110_alignment_outputs')
    REGISTRY_OUT.mkdir(parents=True, exist_ok=False)
    return h.json_new(REGISTRY_OUT / 'registry_before_owned110_known_alignment.json', dict(
        policy=policy(), sources=sources, parent=GUARD, material=MATERIAL, original_strong=STRONG,
        primary_NN=main.NN_REPORT, primary_forest=main.FOREST_REPORT, model_assets=model_assets,
        native=reg['native'], class_geometry=class_geometry, envelope=reg['envelope'], guard_predictions=parent['files']['predictions'],
        guard_prediction_seal=parent['files']['prediction_seal'], strong_predictions=reg['strong'],
        primary_training_inputs=neural['files']['training_inputs'], forest_training_inputs=trees['FIT_arrays'],
        shared_group_union_sha256=material['shared_group_union_sha256'], metric_recipe=learned.training_recipe(110),
        composite_unique_training_groups=5987, optimizer_rows_including_copies=6000,
        input_sha256=pins, output=str(OUT), control_truth_decodes=0, feature_decodes=0, unknown_reads=0))


def run(path, sha):
    registry = dict(path=str(Path(path).resolve()), sha256=sha)
    pins, began, stage = {}, time.perf_counter(), 'bind_registry'
    report = dict(policy=policy(), registry=registry, files={}, NN_fit=0, forest_fit=0, HGB_fit=0,
        NN_forward_roles=[], forest_forward_roles=[], metric_fit=0, FIT_radius_fit=0,
        CAL_cutoff_fit=0, CP_score=0, CAL_score=0, DVC_calls=0, prediction_sealed=False,
        control_truth_opened=False, unknown_reads=0, unknown_phase_allowed=False,
        accepted_baseline_replaced=False, protocol_events=[], status='FAIL_TARGET99',
        published=False, final_test_executed=False)
    h.require(not OUT.exists(), 'fresh_once_owned110_alignment_actual')
    OUT.mkdir(parents=True, exist_ok=False)
    try:
        reg = h.read(registry, pins)
        h.require(reg['policy'] == policy() and reg['sources'] == bindings()
            and reg['metric_recipe'] == learned.training_recipe(110)
            and reg['output'] == str(OUT), 'fixed_owned110_source_recipe_destination')
        for asset, wanted in reg['input_sha256'].items():
            h.checked(dict(path=asset, sha256=wanted), pins)
        torch.set_num_threads(4)
        stage = 'restore_original_frozen_primary_on_CPU'
        saved = torch.load(h.checked(reg['model_assets']['NN'], pins), map_location='cpu', weights_only=True)
        net = nn.network.MHFDNetwork(saved['input_dim'], saved['fine_class_count'])
        net.load_state_dict(saved['state_dict'], strict=True)
        net.eval()
        for parameter in net.parameters():
            parameter.requires_grad_(False)
        transforms = joblib.load(h.checked(reg['model_assets']['preprocessing'], pins))
        trees = joblib.load(h.checked(reg['model_assets']['forest'], pins))
        auxiliary=joblib.load(h.checked(reg['model_assets']['HGB'],pins))
        h.require(np.array_equal(auxiliary.classes_,np.arange(9)),'restored_actual_fine9_HGB_class_order')
        geom=fine.load(reg['class_geometry'],('units','weights'),pins)
        envelope=np.asarray(h.read(reg['envelope'],pins)['envelope'],np.float64)
        before_forest = forest._forest_state(trees)
        stage = 'actual_shared_genuineFIT_and_primary110_units'
        fit = fine.load(reg['native'], ('FIT_native78', 'FIT_ids', 'FIT_y_fine', 'FIT_y_coarse', 'FIT_training_indices'), pins)
        old_native = fine.load(reg['forest_training_inputs'], ('FIT_native78', 'FIT_ids'), pins)
        lookup = {sample: i for i, sample in enumerate(fit['FIT_ids'].tolist())}
        selected = np.asarray([lookup[sample] for sample in old_native['FIT_ids'].tolist()], np.int64)
        h.require(np.array_equal(fit['FIT_native78'][selected], old_native['FIT_native78']), 'exact_old_classifier_nativeFIT_subset_in_shared_union')
        class_z=guard.coordinates(fit['FIT_native78'],geom['units'])
        class_refs={label:class_z[fit['FIT_y_fine']==label] for label in range(9)}
        class_weights={label:geom['weights'][label-1] for label in range(1,9)}
        index = fit['FIT_training_indices']
        h.require(index.dtype == np.int64 and index.shape == (6000,)
            and np.all((index >= 0) & (index < 5987)), 'frozen_shared_optimizer_cap6000')
        repetition = np.bincount(index, minlength=5987)
        h.require(np.all(repetition >= 1) and int((repetition - 1).sum()) == 13
            and np.all(fit['FIT_y_fine'][repetition > 1] == fine.FAMILIES.index('Heartbleed')), 'only13_frozen_Heart_optimizer_copies')
        fit_outputs = frozen_outputs(net, transforms, trees, fit['FIT_native78'])
        report['NN_forward_roles'].append('FIT'); report['forest_forward_roles'].append('FIT')
        native_units = rms_unique(guard.signed_log(fit['FIT_native78']))
        embedding_units = rms_unique(fit_outputs['embedding32'])
        zfit = np.concatenate((guard.signed_log(fit['FIT_native78']) / native_units,
            fit_outputs['embedding32'].astype(np.float64) / embedding_units), axis=1)
        groups = group_hashes(fit['FIT_native78'])
        h.require(zfit.shape == (5987, 110) and len(np.unique(groups)) == 5987, 'all_shared5987_genuine110_feature_groups')
        report['files']['units'] = h.json_new(OUT / 'shared_genuineFIT_78plus32_units_before_metric.json', dict(
            native78=native_units.tolist(), embedding32=embedding_units.tolist(), native=reg['native'],
            primary_NN=reg['model_assets']['NN'], original_FIT_rows=5987, optimizer_copies_used=False,
            control_features_or_truth_used=False))
        report['files']['FIT_geometry'] = h.npz_new(OUT / 'shared_genuineFIT110_before_metric_and_controls.npz', dict(
            Z110=zfit, ids=fit['FIT_ids'], groups=groups, true_fine=fit['FIT_y_fine']), {})
        kwargs = dict(known_fine_labels=list(range(9)), fit_ids=fit['FIT_ids'].tolist(),
            fit_group_ids=groups.tolist(), fit_roles=['FIT'] * 5987)
        stage = 'one_sharedFIT110_pair_prefit_before_optimizer'
        prefit = learned.prefit_descriptor(zfit, fit['FIT_y_fine'], **kwargs)
        report['files']['metric_prefit'] = h.json_new(OUT / 'own_sharedFIT110_metric_prefit_before_optimizer.json', prefit)
        report['protocol_events'].append('own_metric_pair_plan_sealed_before_metric_fit_and_control_features')
        print(json.dumps(dict(stage='fresh_sharedFIT110_metric_training_started', FIT_unique=5987, epochs=80, device='cpu')), flush=True)
        stage = 'one_sharedFIT110_fixed80_CPU_metric_fit'
        metric = learned.fit_known_metric(zfit, fit['FIT_y_fine'], expected_prefit_sha256=prefit['prefit_sha256'], **kwargs)
        report['metric_fit'] = 1
        report['files']['metric'] = h.json_new(OUT / 'own_sharedFIT110_metric_state_before_controls.json', metric.to_state())
        report['metric_training_seconds'] = metric.to_state()['trained']['training_seconds']
        print(json.dumps(dict(stage='fresh_sharedFIT110_metric_training_completed', training_seconds=report['metric_training_seconds'])), flush=True)
        stage = 'all_genuine_truefine_reference_R7_before_controls'
        radius = fit_radii(metric, zfit, fit['FIT_y_fine'])
        report['FIT_radius_fit'] = 1
        report['files']['reference'] = h.npz_new(OUT / 'own_genuine5987_truefine_reference_and_R7_before_CAL.npz', dict(
            Z110=zfit, ids=fit['FIT_ids'], groups=groups, true_fine=fit['FIT_y_fine'], radius=radius), {})
        report['protocol_events'].append('own_metric_truefine_reference_and_R7_sealed_before_CAL_features')
        stage = 'complete_CAL_CP_feature_only110_before_truth'
        sealed_ids = fine.load(reg['guard_predictions'],('CP_ids','CAL_ids'),pins)
        fields = {}
        for role in ('CAL', 'CP'):
            features = fine.load(reg['native'], (role + '_ids', role + '_native78'), pins)
            h.require(np.array_equal(features[role + '_ids'], sealed_ids[role + '_ids']), 'same_sealed_classguard_known_ID_order:' + role)
            outputs = frozen_outputs(net, transforms, trees, features[role + '_native78'])
            report['NN_forward_roles'].append(role); report['forest_forward_roles'].append(role)
            z = np.concatenate((guard.signed_log(features[role + '_native78']) / native_units,
                outputs['embedding32'].astype(np.float64) / embedding_units), axis=1)
            auxiliary_probability=fine.fine_probabilities(auxiliary,np.ascontiguousarray(features[role+'_native78'],np.float32))
            stage1,proposed,admitted,aux_fine,dben,dfine=guard.class_support(outputs['main_prediction'],auxiliary_probability,envelope,
                features[role+'_native78'],geom['units'],class_refs,class_weights)
            h.npz_new(OUT/(role+'_actual_live_CPU_classifier_before_novelty.npz'),dict(ids=features[role+'_ids'],
                stage1=stage1,primary=outputs['main_prediction'],aux_fine=aux_fine,admitted=admitted,proposed=proposed,
                neural_probability=outputs['neural_probability'],main_probability=outputs['main_probability'],
                neural_coarse=outputs['neural_coarse'],neural_fine=outputs['neural_fine'],forest_fine=outputs['forest_fine'],
                auxiliary_fine=auxiliary_probability),{})
            predicted_fine = novelty_fine(stage1, outputs['neural_fine'], outputs['forest_fine'],admitted,aux_fine)
            score = scores(metric, z, predicted_fine, zfit, fit['FIT_y_fine'], radius)
            report[role + '_score'] = 1
            fields.update({role + '_ids': features[role + '_ids'], role + '_Z110': z,
                role + '_stage1': stage1, role + '_predicted_fine': predicted_fine,
                role + '_score': score})
            report['files'][role + '_geometry_scores'] = h.npz_new(OUT / (role + '_owned110_scores_before_novelty_truth.npz'), dict(
                ids=features[role + '_ids'], Z110=z, stage1=stage1, predicted_fine=predicted_fine, score=score), {})
            if role == 'CAL':
                cutoffs = dvc.calibrate_known_cutoffs(score, stage1)
                report['CAL_cutoff_fit'] = 1
                report['files']['cutoffs'] = h.json_new(OUT / 'own_CAL882_predictedcoarse_finite99_cutoffs_before_CP.json', dict(
                    cutoffs=cutoffs, metric=report['files']['metric'], reference=report['files']['reference'],
                    CAL_scores=report['files']['CAL_geometry_scores'], CAL_truth_used=False,
                    query_used=False, classifier_threshold_modified=False))
                report['protocol_events'].append('CAL_predictedcoarse_cutoffs_sealed_before_CP_features')
        stage = 'one_CP_and_one_CAL_same_metric_DVC_before_truth'
        for role in ('CP', 'CAL'):
            raw = dvc.candidate_mask(fields[role + '_score'], fields[role + '_stage1'], cutoffs)
            current = dvc.route_current_candidates(metric, fields[role + '_Z110'], raw, seed=learned.SEED)
            prediction = dvc.predict_current_main_chain(fields[role + '_stage1'], raw, current)
            report['DVC_calls'] += 1
            fields.update({role + '_raw': raw, role + '_retained': current['retained'], role + '_prediction': prediction})
            report['files'][role + '_DVC_arrays'] = h.npz_new(OUT / (role + '_owned110_current_DVC_before_truth.npz'),
                {key: value for key, value in current.items() if key != 'manifest'}, {})
            report['files'][role + '_DVC_manifest'] = h.json_new(OUT / (role + '_owned110_current_DVC_manifest_before_truth.json'), current['manifest'])
        report['files']['predictions'] = h.npz_new(OUT / 'complete_CP_CAL_owned110_DVC_predictions_before_truth.npz', fields, {})
        report['files']['prediction_seal'] = h.json_new(OUT / 'complete_owned110_DVC_prediction_seal_before_truth.json', dict(
            predictions=report['files']['predictions'], units=report['files']['units'], metric=report['files']['metric'],
            reference=report['files']['reference'], cutoffs=report['files']['cutoffs'],
            CAL_or_CP_truth_used=False, query_truth_or_ids_used_in_decision=False, unknown_reads=0))
        report['prediction_sealed'] = True
        report['protocol_events'].append('complete_CP_CAL_DVC_predictions_sealed_before_control_truth')
        stage = 'postseal_known_truth_original_reporting_and_zero_loss_gates'
        h.require(report['prediction_sealed'] and report['DVC_calls'] == 2, 'both_DVC_predictions_sealed_before_truth')
        sealed = fine.load(reg['guard_predictions'],tuple(role+'_'+key for role in ('CP','CAL') for key in ('ids','prediction','primary')),pins)
        meta = fine.load(reg['native'], tuple(role + '_' + key for role in ('CP', 'CAL') for key in ('ids', 'y_coarse', 'reporting_indices')), pins)
        report['control_truth_opened'] = True
        gates, reporting, effects, reporting_effects, counts = {}, {}, {}, {}, {}
        for role in ('CP', 'CAL'):
            y, idx, pred = meta[role + '_y_coarse'], meta[role + '_reporting_indices'], fields[role + '_prediction']
            h.require(np.array_equal(meta[role + '_ids'], fields[role + '_ids']) and idx.dtype == np.int64
                and idx.shape == (900,) and np.array_equal(idx[:882], np.arange(882))
                and np.all((idx >= 0) & (idx < 882)), 'same_complete_original882_reporting900:' + role)
            gates[role], reporting[role] = h.gates(y, pred), h.gates(y[idx], pred[idx])
            effects[role], reporting_effects[role] = {}, {}
            for name, before in (('live_class_guard',fields[role+'_stage1']),('sealed_class_guard',sealed[role+'_prediction']),('original_strong',sealed[role+'_primary'])):
                effects[role][name], reporting_effects[role][name] = h.paired(y, before, pred), h.paired(y[idx], before[idx], pred[idx])
            counts[role] = dict(raw=int(fields[role + '_raw'].sum()), retained=int(fields[role + '_retained'].sum()))
            fields[role + '_truth'], fields[role + '_reporting_indices'] = y, idx
        report['files']['postseal_pair'] = h.npz_new(OUT / 'postseal_owned110_full_known_paired_comparison.npz', fields, {})
        h.require(all(torch.equal(value.detach().cpu(), saved['state_dict'][key]) for key, value in net.state_dict().items())
            and forest._forest_state(trees) == before_forest, 'original_primary_NN_and_forest_weights_unchanged')
        for asset, wanted in pins.items():
            h.require(h.sha(asset) == wanted, 'owned110_input_pin_unchanged:' + asset)
        all_passed = all(g['passed'] for collection in (gates, reporting) for role in collection.values() for g in role.values())
        loss_free = all(e[name]['loss']==0 for e in effects.values() for name in ('live_class_guard','sealed_class_guard'))
        reasons = []
        for form, collection in (('original', gates), ('reporting', reporting)):
            for role, group in collection.items():
                for label, gate in group.items():
                    if not gate['passed']:
                        reasons.append(f"{form}:{role}:{label}:{gate['correct']}/{gate['support']}<required{gate['required_correct']}")
        for role, effect in effects.items():
            if effect['sealed_class_guard']['loss']:
                reasons.append(f"sealed_class_guard:{role}:paired_correct_loss={effect['sealed_class_guard']['loss']}")
        report.update(execution_status='CIC2_shared5987_primary110_owned_CAL_and_known_DVC_evaluated',
            known_gates=gates, effective_reporting_gates=reporting, EffectDelta=effects,
            reporting_EffectDelta=reporting_effects, known_novelty_counts=counts,
            all_original_and_reporting_integer99_passed=all_passed,
            paired_class_guard_correct_loss_free=loss_free, own_known_alignment_passed=all_passed and loss_free,
            rejection_reasons=reasons, ready_for_root_review_before_any_unknown=all_passed and loss_free,
            composite_unique_training_groups=5987, optimizer_rows_including_copies=6000,
            density_reference_rows=5987, density_reference_copies=0,
            original_primary_parameter_bytes_unchanged=True, old_fitted_metric_reused=False,
            promotion_status='NOT_PROMOTED_WARM_KNOWN_ALIGNMENT_ONLY',
            current_unknown_runtime_not_executed=True)
    except Exception as error:
        report.update(execution_status='execution_failed', failed_stage=stage,
            error_type=type(error).__name__, error=str(error))
        raise
    finally:
        report.update(input_sha256=pins, wall_seconds=time.perf_counter() - began)
        h.json_new(OUT / 'report.json', report)
    return h.descriptor(OUT / 'report.json')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=('freeze', 'known'), required=True)
    parser.add_argument('--registry'); parser.add_argument('--registry-sha256')
    args = parser.parse_args()
    if args.phase == 'known' and (not args.registry or not args.registry_sha256):
        parser.error('known requires registry and SHA')
    print(json.dumps(freeze() if args.phase == 'freeze' else run(args.registry, args.registry_sha256), ensure_ascii=False))
