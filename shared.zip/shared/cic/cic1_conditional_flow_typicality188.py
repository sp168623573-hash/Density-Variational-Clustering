"""One conditional invertible density/dual-sided typicality CIC1 candidate."""
from __future__ import annotations
import argparse
import io
import json
from pathlib import Path
import sys
import time
import numpy as np
import torch
from . import conditional_affine_flow_v68 as model
from . import cic1_conditional_flow188_pair_metric_v68 as learned
from . import cic1_conditional_flow188_dvc_v68 as dvc
from . import cic1_student_signcells78_direct110_v60 as prior
from . import cic1_student_clean110_v62 as geometry_helper
from . import cic1_coarse_conditional_decoder_train_v65 as closure_helper

ROOT,files,context=prior.ROOT,prior.files,prior.context
BASE=ROOT/'data/external_dev/processed/cic1_conditional_flow_typicality188_20261011_v68'
REGDIR=ROOT/'tmp/cic1_conditional_flow_typicality188_20261011_v68'
MODULE='paper_open_set.cic1_conditional_flow_typicality188_v68'

def policy():
    return dict(schema_version='CIC1-genuine6000-native78-conditionalflow-two-sided-typicality-fusion188-v68',hypotheses=1,
        pure_model=model.model_recipe(78),training='fixedfinal30 AdamW.001 wd.0001 cosine30 min.0001 clip5 float32/noAMP; everyepoch seed20261011 original6000 indices fullpermutation, originalcoarse/fine frequencies unchanged',
        input='all78 originalnative signedlog/originalfrozenFITRMS; no columns/constants removed, jitter or posterior BEN rescue',
        train_condition='trueFITcoarse0/1 only; genuine6000 original samples, everyfineactual20 minimum, no replicas in density/reference',
        query_condition='everyCAL/CP/current only frozen originalprimary stage1 predictedcoarse0/1',
        deployment='all FIT/CAL/CP/current actualforward CPUfloat32/eval/no_grad fixed512; rawlatent/logdet/baseNLL/NLL/condition sealed before guards',
        statistics='genuineFIT finalNLL actualCPU samecontext, truecoarse mean/std float64; exactzero stdunit1',
        score='predeclared abs(NLL-FITcoarsemean)/FITcoarsestd; two-sided high/lowdensity typicality; negativeNLL retained',
        typicality_scope='pre-registered per-flow heuristic in this experiment; not a complete reproduction of batch typicality tests or statistical coverage guarantees',
        CAL='all900 trueknowncoarse finite99 once, eachquerycutoff frozenstage1, no queryfit/weights/cutgrid',
        fusion='allnative78 + newflowlatent78/genuineFITRMS + frozenacceptedV48 MHFDclean32/genuineFITRMS =188',
        metric='freshowned188 fixedpaperEq9/10 knownfine pairs8192/final80, originalgenuinegroups; no old fittedweights',
        DVC='matching188 currentdensity ownraw OR preserved2397 predictedUNA, original affinity/reconstruction/localdensity/secondarynoise',
        known_gate='BEN/KNA exactinteger99 plus eacholdcorrectloss0 before newcurrent; no integer exploration',
        merge='copy2397 vector, append ownraw&DVCretained UNA; old799/2381/2396exploratory kept',
        MHFD_classifier_unchanged=True,NN_epochs=30,optimizer_traffic_rows=6000,genuineFIT_rows=6000,query_training=False,
        accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)

def freeze():
    pins={};pk=files.js(prior.PARENT_KNOWN,pins);pc=files.js(prior.PARENT_CURRENT,pins);kr=files.js(pk['registry'],pins)
    oldcurrent_ref=dict(path=str(prior.prior.BASE/'current/report.json'),sha256='8675431ef6a1af01918fd6fd608a95b0cfecb1383ca2a08358b7010bdc7b6be9');oldcurrent=files.js(oldcurrent_ref,pins)
    files.require(pk['known_gate_passed'] and pc['original_class_gates']['UNA']['correct']==2397,'accepted900known/2397 preserved')
    assets={k:kr['assets'][k] for k in ('native_known','native_RMS','known110','query110','current_native','truth')}
    assets.update(known_baseline=pk['files']['complete_prediction_before_truth'],current_baseline=pc['files']['complete_prediction_before_truth'],old799=kr['assets']['comparator'],
        FIT_clean32=pk['files']['FIT_clean_embedding32_before_guard'],CAL_clean32=pk['files']['CAL_clean_embedding32_before_guard'],CP_clean32=pk['files']['CP_clean_embedding32_before_guard'],current_clean32=oldcurrent['files']['current4056_clean_embedding32_before_guard'])
    sources=closure_helper.source_closure(sys.modules[__name__],model,learned,dvc,prior,geometry_helper)
    for a in (*assets.values(),*sources.values()):files.read(a,pins)
    preserved={str(p):files.item(ROOT/p) for p in ('data/external_dev/processed/cic1_mask78_clean110_20261011_v48/current/report.json','data/external_dev/processed/cic1_gaussian_mask78_integer_DEV_exploration_20261011_v57/current/report.json')}
    for a in preserved.values():files.read(a,pins)
    files.require(not BASE.exists() and not REGDIR.exists(),'fresh independent conditional flow candidate')
    REGDIR.mkdir(parents=True,exist_ok=False)
    return files.write(REGDIR/'registry_before_actual_conditional_flow_training.json',dict(policy=policy(),assets=assets,sources=sources,preserved=preserved,
        known_parent=prior.PARENT_KNOWN,current_parent=prior.PARENT_CURRENT,metric_recipe=learned.training_recipe(188),model_recipe=model.model_recipe(78),
        output={p:str(BASE/p) for p in ('train','known','current')},input_sha256=pins,current_numeric_decodes=0,current_truth_decodes=0))

def bind(path,sha):
    pins={};registry=dict(path=str(Path(path).resolve()),sha256=sha);reg=files.js(registry,pins)
    files.require(reg['policy']==policy() and reg['sources'][MODULE]==files.item(__file__) and reg['model_recipe']==model.model_recipe(78) and reg['metric_recipe']==learned.training_recipe(188),'selfregistry/source/APIrecipe bound')
    for a in reg['sources'].values():files.read(a,pins)
    return registry,reg,pins

def save(out,name,value,report):return prior.trained.core.previous.save(out,name,value,report)

def train(path,sha):
    registry,reg,pins=bind(path,sha);out=Path(reg['output']['train']);out.mkdir(parents=True,exist_ok=False);started=time.perf_counter();flags=prior.trained.core.capture_runtime_flags()
    report=dict(policy=policy(),registry=registry,files={},training_runs=0,epochs_completed=0,optimizer_steps=0,known_query_numeric_decodes=0,current_numeric_decodes=0,current_truth_decodes=0,posttrain_neural_forward=0,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        prep=time.perf_counter();native=context.selected(reg['assets']['native_known'],('FIT_ids','FIT_native78','FIT_y_coarse','FIT_y_fine'),pins)
        units=np.array(files.js(reg['assets']['native_RMS'],pins)['native78']);x=geometry_helper.previous.raw_source.normalize(native['FIT_native78'],units).astype(np.float32);c=native['FIT_y_coarse'];fine=native['FIT_y_fine']
        files.require(x.shape==(6000,78) and len(np.unique(native['FIT_ids']))==6000 and min(np.bincount(fine,minlength=9))>=20 and c.dtype==np.int64 and np.array_equal(c,(fine!=0).astype(np.int64)),'actualall6000 knownFIT originalfine/coarse')
        save(out,'genuineFIT6000_inputs_before_flow_optimizer',dict(ids=native['FIT_ids'],features=x,coarse=c,fine=fine),report)
        torch.set_num_threads(4);prior.trained.helpers.network.set_seed(20261011);device=torch.device('cuda' if torch.cuda.is_available() else 'cpu');net=model.ConditionalAffineFlow(78).to(device)
        report.update(device=str(device),initial_state_sha256=model.state_digest(net));opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.0001);scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=30,eta_min=.0001)
        report['FIT_preparation_seconds']=time.perf_counter()-prep;history=[];began=time.perf_counter();report['training_runs']=1
        for epoch in range(1,31):
            net.train();order=np.random.default_rng(np.random.SeedSequence([20261011,epoch])).permutation(6000);save(out,'actual_original6000_permutation_epoch'+str(epoch),dict(indices=order),report)
            total=0.;seen=0
            for first in range(0,6000,128):
                selected=order[first:first+128];opt.zero_grad(set_to_none=True);result=net(torch.from_numpy(x[selected].copy()).to(device),torch.from_numpy(c[selected].copy()).to(device));loss=result['NLL'].mean();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),5.);opt.step();total+=float(loss.detach())*len(selected);seen+=len(selected);report['optimizer_steps']+=1
            scheduler.step();history.append(dict(epoch=epoch,mean_NLL=total/seen,actual_original_rows_seen=seen,fine_counts=np.bincount(fine[order],minlength=9).tolist()));report['files']['history']=files.write(out/('history_fixed_epochs_through_'+str(epoch)+'.json'),dict(history=history))
            if epoch==1 or epoch%10==0:print(f'[CIC1 flow78] epoch={epoch}/30 NLL={total/seen:.6f} elapsed={time.perf_counter()-began:.1f}s',flush=True)
        report.update(training_seconds=time.perf_counter()-began,epochs_completed=30,FIT_fine_counts=np.bincount(fine,minlength=9).tolist(),actual_each_epoch_all6000_original_once=True)
        state=model.state_digest(net);p=out/'conditional_flow78_fixedfinal30.pt'
        with p.open('xb') as f:torch.save(dict(state_dict={k:v.detach().cpu() for k,v in net.state_dict().items()},model_recipe=model.model_recipe(78),model_state_sha256=state,training_policy=policy()),f)
        report.update(model_state_sha256=state,execution_status='knownFIT_conditionalflow_fixedfinal30_completed');report['files']['model']=files.item(p)
        for p,h in pins.items():files.require(files.item(p)['sha256']==h,'frozen oldsources/assets unchanged')
    except Exception as error:report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        restored=prior.trained.core.restore_runtime_flags(flags);report.update(runtime_restoration=dict(before=flags,after=restored,all_flags_restored=flags==restored),wall_seconds=time.perf_counter()-started,input_sha256=pins);files.write(out/'report.json',report)
    return files.item(out/'report.json')

def network(train_report,pins):
    saved=torch.load(io.BytesIO(files.read(train_report['files']['model'],pins)),map_location='cpu',weights_only=True)
    files.require(saved['model_recipe']==model.model_recipe(78) and saved['training_policy']==policy(),'actual fixed78flow checkpoint signature')
    net=model.ConditionalAffineFlow(78).cpu();net.load_state_dict(saved['state_dict'],strict=True);net.eval();files.require(model.state_digest(net)==saved['model_state_sha256']==train_report['model_state_sha256'],'exactflow state')
    return net

@torch.no_grad()
def infer(net,x,ids,c,role,out,report):
    began=time.perf_counter();values={k:[] for k in ('latent','logdet','base_NLL','NLL','condition')}
    for first in range(0,len(x),512):
        stop=min(first+512,len(x));returned=net(torch.from_numpy(np.ascontiguousarray(x[first:stop],np.float32)),torch.from_numpy(c[first:stop].copy()));raw={k:v.detach().cpu().numpy().copy() for k,v in returned.items()};save(out,role+'_flow_batch'+str(first)+'_actual_before_guard',raw,report)
        files.require(set(raw)==set(values) and raw['latent'].shape==(stop-first,78) and raw['condition'].dtype==np.int64 and np.array_equal(raw['condition'],c[first:stop]) and all(raw[k].dtype==np.float32 and np.isfinite(raw[k]).all() for k in values if k!='condition'),'actualCPU32 completeflow packets andintegercontext')
        for k in values:values[k].append(raw[k])
        report['neural_forward_batches']+=1
    values={k:np.concatenate(v) for k,v in values.items()};save(out,role+'_whole_actual_flow_before_statistics',dict(ids=ids,**values),report);report['CPU_flow_inference_seconds_by_role'][role]=time.perf_counter()-began
    return values

def score(NLL,c,stats):
    mean=np.asarray(stats['mean']);std=np.asarray(stats['std']);return np.abs(np.asarray(NLL,np.float64)-mean[c])/std[c]

def run(phase,path,sha,known_path=None,known_sha=None):
    registry,reg,pins=bind(path,sha);train_ref=files.item(Path(reg['output']['train'])/'report.json');producer=files.js(train_ref,pins)
    files.require(producer['registry']==registry and producer['epochs_completed']==30 and producer['execution_status']=='knownFIT_conditionalflow_fixedfinal30_completed','actualfixed30known-only flow producer')
    if phase=='current':
        control=files.js(dict(path=str(Path(known_path).resolve()),sha256=known_sha),pins);files.require(control['registry']==registry and control['prediction_sealed'] and control['known_gate_passed'] and control['known_correct_loss']==dict(BEN=0,KNA=0),'strictknown900 integer andzero-loss before currentnewfeatures')
    out=Path(reg['output'][phase]);out.mkdir(parents=True,exist_ok=False);started,threads=time.perf_counter(),torch.get_num_threads();report=dict(policy=policy(),phase=phase,registry=registry,train_report=train_ref,files={},NN_fit=0,neural_forward_batches=0,CPU_flow_inference_seconds_by_role={},units_fit=0,typicality_fit=0,metric_fit=0,reference_rows=0,CAL_fit=0,DVC_calls=0,prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False,accepted_baseline_replaced=False)
    try:
        torch.set_num_threads(4);net=network(producer,pins);nativeunits=np.array(files.js(reg['assets']['native_RMS'],pins)['native78'])
        if phase=='known':
            prep=time.perf_counter();native=context.selected(reg['assets']['native_known'],tuple(r+'_'+k for r in ('FIT','CAL','CP') for k in ('ids','native78'))+('FIT_y_coarse','FIT_y_fine','CAL_y_coarse'),pins)
            oldfields=context.selected(reg['assets']['known110'],tuple(r+'_'+k for r in ('CAL','CP') for k in ('ids','groups','stage1','predicted_fine')),pins)
            fields={};flowvalues={};cleans={};normalized={}
            for role in ('FIT','CAL','CP'):
                normalized[role]=geometry_helper.previous.raw_source.normalize(native[role+'_native78'],nativeunits);c=native['FIT_y_coarse'] if role=='FIT' else oldfields[role+'_stage1'];groups=geometry_helper.group_ids(native[role+'_native78'])
                files.require(len(np.unique(groups))==len(groups),'actualoriginalunique nativegroups '+role)
                flowvalues[role]=infer(net,normalized[role].astype(np.float32),native[role+'_ids'],c,role,out,report);cleans[role]=context.selected(reg['assets'][role+'_clean32'],('embedding32',),pins)['embedding32']
                fields.update({role+'_ids':native[role+'_ids'],role+'_groups':groups})
                if role!='FIT':
                    files.require(np.array_equal(fields[role+'_ids'],oldfields[role+'_ids']) and np.array_equal(groups,oldfields[role+'_groups']),'originalfrozen classifierentities unchanged');fields.update({role+'_'+k:oldfields[role+'_'+k] for k in ('stage1','predicted_fine')})
            report['load_and_CPU_allrole_flow_prep_seconds']=time.perf_counter()-prep
            stat_began=time.perf_counter();FIT_NLL=flowvalues['FIT']['NLL'].astype(np.float64);coarse=native['FIT_y_coarse'];means=[float(FIT_NLL[coarse==c].mean()) for c in (0,1)];rawstd=[float(FIT_NLL[coarse==c].std()) for c in (0,1)];std=[s if s!=0 else 1. for s in rawstd];stats=dict(mean=means,std=std,rawstd=rawstd,exactzero_std_unit1=[s==0 for s in rawstd],support=[int((coarse==c).sum()) for c in (0,1)],genuineFIT_only=True)
            report['typicality_fit']=1;report['FIT_typicality_fit_seconds']=time.perf_counter()-stat_began;report['files']['typicality']=files.write(out/'genuineFIT_coarse_NLL_mean_std_before_CAL.json',stats)
            scale_began=time.perf_counter();latentunits=geometry_helper.bridge.rms_unique(flowvalues['FIT']['latent']);cleanunits=geometry_helper.bridge.rms_unique(cleans['FIT']);report['units_fit']=1;report['FIT_fusion_units_seconds']=time.perf_counter()-scale_began;report['files']['units']=files.write(out/'genuineFIT_latent78_and_preserved_clean32_units.json',dict(latent78=latentunits.tolist(),clean32=cleanunits.tolist(),genuineFIT_rows=6000,queryfit=False))
            for role in ('FIT','CAL','CP'):
                fields[role+'_Z188']=np.concatenate((normalized[role],flowvalues[role]['latent'].astype(np.float64)/latentunits,cleans[role].astype(np.float64)/cleanunits),axis=1)
                files.require(fields[role+'_Z188'].shape==(len(native[role+'_ids']),188),'all78native+all78latent+32preserved MHFD')
            fields['FIT_fine']=native['FIT_y_fine'];save(out,'genuine_allrole_fusion188_before_metric',fields,report)
            kwargs=dict(known_fine_labels=list(range(9)),fit_ids=fields['FIT_ids'].tolist(),fit_group_ids=fields['FIT_groups'].tolist(),fit_roles=['FIT']*6000);pair_began=time.perf_counter();prefit=learned.prefit_descriptor(fields['FIT_Z188'],fields['FIT_fine'],**kwargs);report['FIT_pair_plan_seconds']=time.perf_counter()-pair_began;report['files']['metric_prefit']=files.write(out/'fusion188_knownfine_pair_plan_before_fit.json',prefit)
            metric_began=time.perf_counter();metric=learned.fit_known_metric(fields['FIT_Z188'],fields['FIT_fine'],expected_prefit_sha256=prefit['prefit_sha256'],**kwargs);report['metric_fit']=1;report['FIT_metric_total_prep_gradient_seconds']=time.perf_counter()-metric_began;state=metric.to_state();report['metric_gradient_seconds']=state['trained']['training_seconds'];report['files']['metric']=files.write(out/'fusion188_new_owned_metric_before_CAL.json',dict(metric_payload=state,flowmodel=producer['files']['model']))
            report['reference_rows']=6000;save(out,'genuineFIT_fusion188_references_not_training_views',dict(ids=fields['FIT_ids'],groups=fields['FIT_groups'],fine=fields['FIT_fine'],Z188=fields['FIT_Z188']),report)
            cal=score(flowvalues['CAL']['NLL'],fields['CAL_stage1'],stats);save(out,'CAL900_two_sided_typicality_before_cutoffs',dict(ids=fields['CAL_ids'],NLL=flowvalues['CAL']['NLL'],score=cal,condition=fields['CAL_stage1']),report)
            cut=dvc.calibrate_known_cutoffs(cal,native['CAL_y_coarse']);report['CAL_fit']=1;report['files']['cutoffs']=files.write(out/'all900_trueknown_CAL_once_finite99_before_CP.json',dict(cutoffs=cut,all900_retained=True,CP_currentfit=False))
            query=dict(ids=fields['CP_ids'],groups=fields['CP_groups'],Z188=fields['CP_Z188'],stage1=fields['CP_stage1'],predicted_fine=fields['CP_predicted_fine']);typical=score(flowvalues['CP']['NLL'],query['stage1'],stats);baseline=context.selected(reg['assets']['known_baseline'],('ids','prediction'),pins)
        else:
            units=files.js(control['files']['units'],pins);stats=files.js(control['files']['typicality'],pins);cut=files.js(control['files']['cutoffs'],pins)['cutoffs'];metric=learned.PaperVariationalPairMetric.from_state(files.js(control['files']['metric'],pins)['metric_payload'])
            native=context.selected(reg['assets']['current_native'],('ids','native78'),pins);oldfields=context.selected(reg['assets']['query110'],('ids','groups','stage1','predicted_fine'),pins);normalized=geometry_helper.previous.raw_source.normalize(native['native78'],nativeunits);groups=geometry_helper.group_ids(native['native78'])
            files.require(len(native['ids'])==4056 and len(np.unique(groups))==4056 and np.array_equal(native['ids'],oldfields['ids']) and np.array_equal(groups,oldfields['groups']),'actual4056 originalunique nativeentities')
            flow=infer(net,normalized.astype(np.float32),native['ids'],oldfields['stage1'],'current4056',out,report);clean=context.selected(reg['assets']['current_clean32'],('embedding32',),pins)['embedding32']
            query=dict(oldfields,Z188=np.concatenate((normalized,flow['latent'].astype(np.float64)/np.array(units['latent78']),clean.astype(np.float64)/np.array(units['clean32'])),axis=1));save(out,'whole4056_flow188_before_score',query,report);typical=score(flow['NLL'],query['stage1'],stats);baseline=context.selected(reg['assets']['current_baseline'],('ids','prediction'),pins)
        files.require(np.array_equal(query['ids'],baseline['ids']),'sameexact original baselineprediction entities');before=baseline['prediction'];raw=dvc.candidate_mask(typical,query['stage1'],cut);density=raw|(before==2);save(out,'two_sided_typicality_raw_density_before_DVC',dict(ids=query['ids'],score=typical,stage1=query['stage1'],raw=raw,density=density),report)
        route=dvc.route_current_candidates(metric,query['Z188'],density,seed=20261009);report['DVC_calls']=1;save(out,'owned_fusion188_DVC_before_truth',{k:v for k,v in route.items() if k!='manifest'},report);report['files']['DVC_manifest']=files.write(out/'owned_fusion188_DVC_manifest_before_truth.json',route['manifest']);prediction=before.copy();prediction[raw&route['retained']]=2
        p=save(out,'complete_prediction_before_truth',dict(ids=query['ids'],prediction=prediction,baseline=before,raw=raw,density=density,retained=route['retained']),report);report['files']['seal']=files.write(out/'complete_prediction_seal_before_truth.json',dict(predictions=p,truth_used=False,registry=registry));report['prediction_sealed']=True
        if phase=='known':truth=context.selected(reg['assets']['known110'],('CP_truth',),pins)['CP_truth']
        else:
            t=context.selected(reg['assets']['truth'],('ids','truth'),pins);files.require(np.array_equal(t['ids'],query['ids']),'truth matches only afterseal');truth=t['truth']
        report['truth_opened']=True;gates=context.integer_gates(truth,prediction,known_only=phase=='known');gl={n:dict(gain=int(np.sum((truth==c)&(before!=c)&(prediction==c))),loss=int(np.sum((truth==c)&(before==c)&(prediction!=c)))) for c,n in enumerate(gates)};delta={n:x['gain']-x['loss'] for n,x in gl.items()};positive,negative=any(v>0 for v in delta.values()),any(v<0 for v in delta.values());loss={n:gl[n]['loss'] for n in ('BEN','KNA')}
        save(out,'postseal_paired_comparison',dict(ids=query['ids'],truth=truth,prediction=prediction,baseline=before,raw=raw,density=density,retained=route['retained']),report)
        report.update(execution_status='flow78_typicality188_'+phase+'_evaluated',original_class_gates=gates,baseline_class_gates=context.integer_gates(truth,before,known_only=phase=='known'),known_correct_loss=loss,known_gate_passed=all(gates[n]['passed'] and loss[n]==0 for n in ('BEN','KNA')),EffectDelta=dict(verdict='MIXED' if positive and negative else 'UP' if positive else 'DOWN' if negative else 'UNCHANGED',correct_count_delta=delta,gain_loss=gl,same_original_IDs=True),raw_by_true_class={n:int(np.sum((truth==c)&raw)) for c,n in enumerate(gates)},all_three_integer99_passed=phase=='current' and all(g['passed'] for g in gates.values()))
        files.require(model.state_digest(net)==producer['model_state_sha256'],'frozenflowstate afterCPU roles')
        for p,h in pins.items():files.require(files.item(p)['sha256']==h,'frozeninputs/state/sources unchanged')
    except Exception as error:report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        torch.set_num_threads(threads);report.update(threads_restored=torch.get_num_threads()==threads,wall_seconds=time.perf_counter()-started,input_sha256=pins);files.write(out/'report.json',report)
    return files.item(out/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','train','known','current'),required=True)
    for n in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+n)
    a=p.parse_args();print(json.dumps(freeze() if a.phase=='freeze' else train(a.registry,a.registry_sha256) if a.phase=='train' else run(a.phase,a.registry,a.registry_sha256,a.known_report,a.known_sha256)))
