"""Restore CIC1/CIC2's own 78 native fields from registered pure-known assets.

Root execution sequence: ``receipt = freeze(setting, output_dir)`` (JSON,
hashes and NPY headers only), then ``build_actual(receipt)`` (actual known
decoding and FIT-only statistics). Neither entry point trains or loads a model.
There is no unknown-data entry point. The only recipe is signed-log / FIT RMS,
without centering, clipping, filling, variance filtering or label selection.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import zipfile

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
ROLES = ("FIT", "CP", "CAL")
CAP = 6000
COLUMNS = (
    "Destination Port", "Flow Duration", "Total Fwd Packets", "Total Backward Packets",
    "Total Length of Fwd Packets", "Total Length of Bwd Packets", "Fwd Packet Length Max",
    "Fwd Packet Length Min", "Fwd Packet Length Mean", "Fwd Packet Length Std",
    "Bwd Packet Length Max", "Bwd Packet Length Min", "Bwd Packet Length Mean",
    "Bwd Packet Length Std", "Flow Bytes/s", "Flow Packets/s", "Flow IAT Mean",
    "Flow IAT Std", "Flow IAT Max", "Flow IAT Min", "Fwd IAT Total", "Fwd IAT Mean",
    "Fwd IAT Std", "Fwd IAT Max", "Fwd IAT Min", "Bwd IAT Total", "Bwd IAT Mean",
    "Bwd IAT Std", "Bwd IAT Max", "Bwd IAT Min", "Fwd PSH Flags", "Bwd PSH Flags",
    "Fwd URG Flags", "Bwd URG Flags", "Fwd Header Length", "Bwd Header Length",
    "Fwd Packets/s", "Bwd Packets/s", "Min Packet Length", "Max Packet Length",
    "Packet Length Mean", "Packet Length Std", "Packet Length Variance", "FIN Flag Count",
    "SYN Flag Count", "RST Flag Count", "PSH Flag Count", "ACK Flag Count", "URG Flag Count",
    "CWE Flag Count", "ECE Flag Count", "Down/Up Ratio", "Average Packet Size",
    "Avg Fwd Segment Size", "Avg Bwd Segment Size", "Fwd Header Length.1",
    "Fwd Avg Bytes/Bulk", "Fwd Avg Packets/Bulk", "Fwd Avg Bulk Rate", "Bwd Avg Bytes/Bulk",
    "Bwd Avg Packets/Bulk", "Bwd Avg Bulk Rate", "Subflow Fwd Packets", "Subflow Fwd Bytes",
    "Subflow Bwd Packets", "Subflow Bwd Bytes", "Init_Win_bytes_forward",
    "Init_Win_bytes_backward", "act_data_pkt_fwd", "min_seg_size_forward", "Active Mean",
    "Active Std", "Active Max", "Active Min", "Idle Mean", "Idle Std", "Idle Max", "Idle Min",
)
CANONICAL_POLICY = (
    "existing identity_bridge float64 little-endian C rows; no decimal rounding/tolerance; "
    "numeric conversion errors become NaN; signed zero and NaN payloads normalized; "
    "+/-Inf retained and counted nonfinite; SHA256 of each 624-byte row"
)
RECIPE = dict(
    schema_version="CIC-all-native78-signedlog-FIT-RMS-recipe-v1",
    input_fields=78, output_fields=78,
    transform="sign(x)*log1p(abs(x)) in float64; all finite negative native values preserved",
    units="sqrt(mean(signed_log1p(original unique FIT rows)**2, axis=0)); exactly zero -> 1",
    statistics_role="original FIT canonical78 groups only; optimizer/report copies never reweight units",
    encoding="signed_log1p(native78)/frozen FIT units; no centering; float32 model input",
    validity="require finite native float64; fail on NaN/Inf; no filling, clipping or value repair",
    variance_selection=False, ANOVA_selection=False, target_label_selection=False,
    known_cap=CAP, density_uses_original_rows_only=True,
    source_admitted=False, published=False, final_test_executed=False,
)
_BASE = "data/external_dev/processed/"
REGISTRY = {
    "CIC Setting1": dict(
        directory=_BASE + "cic2017_native_known_source_extract_20261008_v1",
        report_sha256="6375dd3fd443320c570db263b9ec090f3daf68bce3192252b6e3d3f382de60bc",
        archive_sha256="496757eb6e33bc2b3ea28eeb3191b69b7905cb8ddde33c78455d4165096a66ec",
        records_sha256="9f68a69bcac1e800c622f56d579d00ae7ceac7260b68685a9f4482c8c11e1ea0",
        policy_sha256="4decb10a16e9b3e6cb8bf4d5dc25e462c6a123198bc918e42d4626037546a899",
        report_schema="CIC2017-native-known-source-extract-v1",
        record_schema="CIC2017-native-known-ordered-source-records-v1",
        original_sizes=dict(FIT=4200, CP=900, CAL=900),
        family_order=["BEN", "FTP-Patator", "SSH-Patator", "DoS slowloris", "DoS Slowhttptest",
                      "DDoS", "DoS Hulk", "DoS GoldenEye", "PortScan"],
    ),
    "CIC Setting2": dict(
        directory=_BASE + "cic2017_setting2_known_fit_coverage_extract_20261008_v1",
        report_sha256="77eaffd4fa9d35e633cb0d38ab880eff308db742bc6f9b3b6b816ba3554d09c3",
        archive_sha256="a7402cefaec42c9771e573411467a070a93d13717e2169e8bad5352d66190f4d",
        records_sha256="da767b4976a1c52c614a08786469c131589985a3f999fd4e2239091bf50d3a58",
        policy_sha256="ddc2c52b5c19a59abad31dd1b37917d3531253602ed071383fa5fa6620b2c040",
        report_schema="CIC2017-setting2-fixed-controls-FIT-coverage-source-v1",
        record_schema="CIC2-fixed-controls-FIT-coverage-ordered-source-records-v1",
        original_sizes=dict(FIT=4187, CP=882, CAL=882),
        family_order=["BEN", "FTP-Patator", "SSH-Patator", "PortScan", "DDoS", "Heartbleed",
                      "DoS Slowhttptest", "DoS Hulk", "Bot"],
        inherited_policy=dict(
            path=_BASE + "cic2017_setting2_warm_known_source_extract_20261008_v1/policy_before_source_scan.json",
            sha256="970175bd1472fec13a4c43c042d08d2898edd6290b3cde553b3eaf2a4cc54e57"),
    ),
}
EFFECTIVE_SIZES = dict(FIT=4200, CP=900, CAL=900)
INDEX_MEMBERS = dict(FIT="FIT_training_indices", CP="CP_reporting_indices", CAL="CAL_reporting_indices")


class AllNative78Stop(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise AllNative78Stop(reason)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def descriptor(path):
    return dict(path=str(Path(path).resolve()), sha256=sha(path))


def _checked(path, wanted):
    path = Path(path).resolve()
    require(path.is_relative_to(ROOT) and path != ROOT, "workspace_registered_input_required")
    require(sha(path) == wanted, "input_pin_changed:" + str(path))
    return path


def _json(path, wanted):
    return json.loads(_checked(path, wanted).read_text(encoding="utf-8"))


def _write_new(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")


def npz_headers(path):
    """Read each NPY header only; never numpy.load or decode array values."""
    result = {}
    with zipfile.ZipFile(path) as archive:
        for member in archive.infolist():
            require(member.filename.endswith(".npy") and "/" not in member.filename,
                    "flat_NPY_members_required")
            name = member.filename[:-4]
            require(name not in result, "duplicate_NPY_member")
            with archive.open(member) as stream:
                version = np.lib.format.read_magic(stream)
                require(version in ((1, 0), (2, 0)), "registered_NPY_version")
                reader = (np.lib.format.read_array_header_1_0 if version == (1, 0)
                          else np.lib.format.read_array_header_2_0)
                shape, fortran, dtype = reader(stream)
                require(not dtype.hasobject, "no_pickled_array_allowed")
                result[name] = dict(shape=list(shape), dtype=dtype.str, fortran_order=fortran)
    return result


def _inspect(setting):
    """Pinned JSON, source record metadata and headers; zero numeric decode."""
    require(setting in REGISTRY, "own_CIC_setting_registry_required")
    spec = REGISTRY[setting]
    directory = ROOT / spec["directory"]
    expected = {"report": (directory / "report.json", spec["report_sha256"]),
                "archive": (directory / "known_roles_native78.npz", spec["archive_sha256"]),
                "records": (directory / "ordered_source_records.json", spec["records_sha256"]),
                "policy": (directory / "policy_before_source_scan.json", spec["policy_sha256"])}
    paths = {k: _checked(p, h) for k, (p, h) in expected.items()}
    report, records, policy = (json.loads(paths[k].read_text(encoding="utf-8"))
                               for k in ("report", "records", "policy"))
    require(report["schema_version"] == spec["report_schema"]
            and records["schema_version"] == spec["record_schema"], "own_source_schema")
    require(report["setting"] == records["setting"] == setting
            and tuple(report["model_columns"]) == tuple(records["model_columns"]) == COLUMNS
            and report["family_order"] == records["family_order"] == spec["family_order"],
            "own_native78_order_and_family_schema")
    require(report["source_extraction_completed"] is True and report["published"] is False
            and report["final_test_executed"] is False, "completed_nonfinal_known_source")
    for kind, key in (("archive", "known_roles_archive"), ("records", "ordered_source_records"),
                      ("policy", "policy_before_source_scan")):
        require(report["files"][key] == dict(path=str(paths[kind]), sha256=expected[kind][1]),
                "report_descriptor_binding:" + kind)
    pins = {str(p): h for p, h in expected.values()}
    canonical = policy.get("canonical78")
    if "inherited_policy" in spec:
        inherited = spec["inherited_policy"]
        p = _checked(ROOT / inherited["path"], inherited["sha256"])
        canonical = json.loads(p.read_text(encoding="utf-8"))["canonical78"]
        require(policy["old_source"]["sha256"] == "411e53400ac69a026eb6b21206ed97f24e14724aaf5073cf52b9c150b160b92a",
                "declared_CIC2_ancestor_policy")
        pins[str(p)] = inherited["sha256"]
    require(canonical == CANONICAL_POLICY and "finite" in records["representative_rule"],
            "finite_native_representatives_no_nonnegative_assumption")
    sizes = spec["original_sizes"]
    require(set(records["roles"]) == set(ROLES)
            and sum(sizes.values()) <= CAP and sum(EFFECTIVE_SIZES.values()) == CAP,
            "known_original_and_effective_cap")
    seen_groups, seen_ids, seen_source = set(), set(), set()
    for role in ROLES:
        rows = records["roles"][role]
        require(len(rows) == sizes[role], "exact_original_record_count:" + role)
        for row in rows:
            identity = (row["source_file_sha256"], row["source_row_ordinal"])
            require(row["role"] == role and row["sample_id"] not in seen_ids
                    and row["canonical78_sha256"] not in seen_groups and identity not in seen_source
                    and 0 <= row["fine_label"] < len(spec["family_order"])
                    and row["family"] == spec["family_order"][row["fine_label"]]
                    and row["coarse_label"] == int(row["fine_label"] != 0),
                    "unique_original_group_role_family_identity")
            seen_groups.add(row["canonical78_sha256"])
            seen_ids.add(row["sample_id"])
            seen_source.add(identity)
    headers = npz_headers(paths["archive"])
    required = {r + "_" + suffix for r in ROLES for suffix in ("native78", "ids", "y_fine", "y_coarse")}
    if setting == "CIC Setting2":
        required |= set(INDEX_MEMBERS.values())
        require(report["original_role_sizes"] == sizes and report["effective_role_sizes"] == EFFECTIVE_SIZES
                and report["copy_total"] == 49 and report["density_copy_rows"] == 0
                and report["copies_in_native78_arrays"] == 0, "unchanged_CIC2_copy_cap_contract")
        for role in ROLES:
            mapping = records["role_effective_indices"][role]
            require(mapping == policy["role_effective_indices"][role]
                    and mapping["density_uses_original_indices_only"] is True
                    and mapping["kind"] == ("fit_optimization_indices" if role == "FIT" else "report_only_indices")
                    and len(mapping["indices"]) == EFFECTIVE_SIZES[role]
                    and len(mapping["copies"]) == EFFECTIVE_SIZES[role] - sizes[role]
                    and mapping["indices"][:sizes[role]] == list(range(sizes[role]))
                    and all(type(i) is int and 0 <= i < sizes[role] for i in mapping["indices"]),
                    "original_CIC2_optimizer_report_mapping:" + role)
            require(headers[INDEX_MEMBERS[role]]["shape"] == [EFFECTIVE_SIZES[role]]
                    and headers[INDEX_MEMBERS[role]]["dtype"] == "<i8", "index_header:" + role)
    else:
        require(records["copies_or_resampling_rows"] == report["copies_or_resampling_rows"] == 0
                and report["role_sizes"] == sizes, "CIC1_identity_maps_without_copies")
    require(set(headers) == required, "exact_pure_known_NPZ_members_no_unknown")
    for role in ROLES:
        require(headers[role + "_native78"] == dict(shape=[sizes[role], 78], dtype="<f8", fortran_order=False),
                "native78_header:" + role)
        for suffix in ("ids", "y_fine", "y_coarse"):
            h = headers[role + "_" + suffix]
            require(h["shape"] == [sizes[role]] and h["dtype"] == ("<U160" if suffix == "ids" else "<i8")
                    and h["fortran_order"] is False, "known_metadata_header:" + role + suffix)
    return dict(setting=setting, source_pins=pins, archive=str(paths["archive"]),
                original_role_sizes=sizes, effective_role_sizes=EFFECTIVE_SIZES,
                family_order=spec["family_order"], model_columns=list(COLUMNS), headers=headers,
                source_validity_policy=canonical, finite_representatives_required=True,
                nonnegative_values_proven=False, records_path=str(paths["records"])), records, report


def freeze(setting, output_dir):
    """Freeze schema, copies and one recipe before any native numeric decode."""
    metadata, _, _ = _inspect(setting)
    output = Path(output_dir).resolve()
    require(output.is_relative_to(ROOT) and output != ROOT
            and all(not output.is_relative_to(ROOT / spec["directory"]) for spec in REGISTRY.values()),
            "new_workspace_output_outside_source_required")
    output.mkdir(parents=True, exist_ok=True)
    path = output / "all78_source_registry_before_numeric_decode.json"
    manifest = dict(schema_version="CIC-all-native78-known-source-freeze-v1", **metadata,
                    recipe=RECIPE, module=descriptor(__file__), output_dir=str(output),
                    source_numeric_decodes=0, FIT_statistics_runs=0, model_calls=0,
                    unknown_allowed=False, status="FAIL_TARGET99", source_admitted=False,
                    published=False, final_test_executed=False)
    _write_new(path, manifest)
    return descriptor(path)


def signed_log1p(native):
    values = np.asarray(native)
    require(values.dtype == np.dtype("<f8") and values.ndim == 2 and values.shape[1] == 78
            and np.isfinite(values).all(), "finite_float64_native78_no_repair")
    return np.sign(values) * np.log1p(np.abs(values))


def _fit_units(roles):
    """Mathematical core: inspect FIT only; dedup exact native rows, never labels."""
    fit = roles["FIT"]
    transformed = signed_log1p(fit)
    first, seen = [], set()
    for index, row in enumerate(fit):
        fingerprint = hashlib.sha256(np.asarray(row, dtype="<f8").tobytes(order="C")).hexdigest()
        if fingerprint not in seen:
            first.append(index)
            seen.add(fingerprint)
    require(first, "nonempty_original_FIT_groups")
    rms = np.sqrt(np.mean(np.square(transformed[first]), axis=0, dtype=np.float64))
    require(np.isfinite(rms).all(), "finite_FIT_RMS")
    return np.where(rms == 0.0, 1.0, rms), len(first)


def encode(native, units):
    units = np.asarray(units, dtype=np.float64)
    require(units.shape == (78,) and np.isfinite(units).all() and np.all(units > 0), "frozen_positive_78_units")
    features = (signed_log1p(native) / units).astype(np.float32)
    require(np.isfinite(features).all(), "finite_all78_float32_without_clip")
    return features


def _array_descriptor(values):
    return dict(shape=list(values.shape), dtype=values.dtype.str,
                C_order_bytes_sha256=hashlib.sha256(values.tobytes(order="C")).hexdigest())


def build_actual(frozen_receipt):
    """ROOT ONLY: decode known arrays, validate native identities, fit FIT RMS.

    Writes material and encoder before a new model can be trained. No model,
    checkpoint, score, distance, DVC, unknown source or live continuation state
    is read. Return the completed material report descriptor.
    """
    manifest_path = _checked(frozen_receipt["path"], frozen_receipt["sha256"])
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    require(manifest["schema_version"] == "CIC-all-native78-known-source-freeze-v1"
            and manifest["recipe"] == RECIPE and manifest["unknown_allowed"] is False
            and manifest["module"] == descriptor(__file__), "frozen_recipe_and_exact_module")
    metadata, records, source_report = _inspect(manifest["setting"])
    require(all(manifest[k] == v for k, v in metadata.items()), "frozen_metadata_unchanged")
    output = Path(manifest["output_dir"]).resolve()
    require(manifest_path.parent == output, "frozen_output_directory")
    outputs = {"encoder": output / "knownFIT_all78_encoder_before_new_model.json",
               "material": output / "new_all78_known_features_before_training.npz",
               "prefit": output / "all78_new_model_prefit.json", "report": output / "report.json"}
    require(all(not p.exists() for p in outputs.values()), "new_material_outputs_only")
    # Use exactly the header-registered pure known archive after pin validation.
    with np.load(metadata["archive"], allow_pickle=False) as archive:
        arrays = {key: archive[key] for key in metadata["headers"]}
    if "array_descriptors" in source_report:
        for key in metadata["headers"]:
            saved = source_report["array_descriptors"][key]
            require(list(arrays[key].shape) == saved["shape"] and arrays[key].dtype.str == saved["dtype"]
                    and hashlib.sha256(arrays[key].tobytes(order="C")).hexdigest() == saved["sha256"],
                    "saved_source_array_descriptor:" + key)
    originals, mappings, negative_audit, groups = {}, {}, {}, set()
    for role in ROLES:
        native = arrays[role + "_native78"]
        signed_log1p(native)  # validity only; no filling or label-dependent path.
        rows = records["roles"][role]
        for index, row in enumerate(rows):
            group = hashlib.sha256(native[index].tobytes(order="C")).hexdigest()
            require(group == row["canonical78_sha256"] and group not in groups
                    and arrays[role + "_ids"][index] == row["sample_id"]
                    and int(arrays[role + "_y_fine"][index]) == row["fine_label"]
                    and int(arrays[role + "_y_coarse"][index]) == row["coarse_label"],
                    "native_original_record_value_label_identity:" + role)
            groups.add(group)
        originals[role] = native
        if manifest["setting"] == "CIC Setting2":
            mappings[role] = arrays[INDEX_MEMBERS[role]]
            require(np.array_equal(mappings[role], np.asarray(records["role_effective_indices"][role]["indices"], dtype=np.int64)),
                    "exact_saved_copy_indices:" + role)
        else:
            mappings[role] = np.arange(len(native), dtype=np.int64)
        negative_audit[role] = {name: int(count) for name, count in zip(COLUMNS, (native < 0).sum(axis=0)) if count}
    units, fit_unique = _fit_units(originals)
    require(fit_unique == metadata["original_role_sizes"]["FIT"], "original_FIT_groups_are_unique")
    encoder = dict(schema_version="CIC-native78-frozen-signedlog-RMS-encoder-v1", setting=manifest["setting"],
                   model_columns=list(COLUMNS), units=units.tolist(), recipe=RECIPE,
                   field_map=[dict(name=name, input_index=index, output_index=index, kind="native_numeric_signed",
                                   unit=float(units[index])) for index, name in enumerate(COLUMNS)],
                   original_FIT_unique_groups=fit_unique, freeze=frozen_receipt,
                   unit_sha256=_array_descriptor(units), labels_used_for_statistics=False,
                   numeric_source=metadata["archive"], native_values_modified=False,
                   zero_unit_fields=[name for name, col in zip(COLUMNS, originals["FIT"].T) if np.all(col == 0.0)])
    _write_new(outputs["encoder"], encoder)
    material = {}
    for role in ROLES:
        material[role + "_features"] = encode(originals[role], units)
        for suffix in ("ids", "y_fine", "y_coarse"):
            material[role + "_" + suffix] = arrays[role + "_" + suffix]
        material[INDEX_MEMBERS[role]] = mappings[role]
    with outputs["material"].open("xb") as stream:
        np.savez_compressed(stream, **material)
    prefit = dict(schema_version="CIC-all78-new-model-prefit-v1", setting=manifest["setting"],
                  input_width=78, original_fields=78, family_order=metadata["family_order"],
                  original_role_sizes=metadata["original_role_sizes"], effective_role_sizes=EFFECTIVE_SIZES,
                  FIT_statistics_original_groups=fit_unique, optimizer_rows=4200,
                  CP_CAL_inference_calibration_density="original rows only; reporting indices never enter density",
                  density_copy_rows=0, known_effective_cap=CAP, recipe=RECIPE,
                  encoder=descriptor(outputs["encoder"]), material=descriptor(outputs["material"]),
                  freeze=frozen_receipt, arrays={k: _array_descriptor(v) for k, v in material.items()},
                  model_training_or_forward=0, unknown_decodes=0, unknown_performance_measured=False,
                  status="FAIL_TARGET99", published=False, final_test_executed=False)
    _write_new(outputs["prefit"], prefit)
    result = dict(schema_version="CIC-all78-known-material-report-v1", setting=manifest["setting"],
                  execution_status="own_CIC_all78_known_material_completed_before_new_model",
                  files={k: descriptor(p) for k, p in outputs.items() if k != "report"},
                  freeze=frozen_receipt, source_pins=metadata["source_pins"], negative_native_counts=negative_audit,
                  all_original_fields_retained=True, FIT_statistics_runs=1, FIT_statistics_original_groups=fit_unique,
                  actual_known_decode_rows=sum(metadata["original_role_sizes"].values()),
                  original_role_sizes=metadata["original_role_sizes"], effective_role_sizes=EFFECTIVE_SIZES,
                  density_copy_rows=0, copied_native_source_rows=0, native_values_modified=False,
                  model_training_or_forward=0, score_distance_DVC_calls=0, unknown_decodes=0,
                  source_admitted=False, physical_event_independence_proven=False,
                  status="FAIL_TARGET99", published=False, final_test_executed=False)
    _write_new(outputs["report"], result)
    return descriptor(outputs["report"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    freezing = commands.add_parser("freeze")
    freezing.add_argument("--setting", choices=tuple(REGISTRY), required=True)
    freezing.add_argument("--output", type=Path, required=True)
    actual = commands.add_parser("actual", help="Root-only actual known decode/statistics, no training")
    actual.add_argument("--freeze", type=Path, required=True)
    actual.add_argument("--freeze-sha256", required=True)
    args = parser.parse_args()
    receipt = (freeze(args.setting, args.output) if args.command == "freeze"
               else build_actual(dict(path=str(args.freeze.resolve()), sha256=args.freeze_sha256)))
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == "__main__":
    main()
