"""One fixed MHFD training over a pinned native CIC1 known-only source bundle."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import time

import joblib
import numpy as np
import pandas as pd
from sklearn.feature_selection import SelectKBest, f_classif
import torch

from . import data as preprocessing
from . import model as network
from .config import CIC_FEATURE_COLUMNS, get_spec

ROOT = Path(__file__).resolve().parents[1]
ROLES = {"FIT": 4200, "CAL": 900, "CP": 900}
FAMILIES = ("BEN", *get_spec("CIC Setting1").known_families)
EPOCHS, SEED, TOP_K = 80, 20261008, 50
POLICY = {
    "schema_version": "CIC2017-native-known-MHFD-training-v1",
    "setting": "CIC Setting1", "datasets_used": ["CIC-2017"],
    "roles": ROLES, "unique_training_side_original_rows": 6000,
    "minimum_family_rows_per_role": 20, "epochs": EPOCHS, "seed": SEED,
    "preprocessing": "existing median imputer/StandardScaler FIT only; FIT positive variance; FIT fine-label ANOVA top50",
    "checkpoint_selection": "existing model.train_model known CP coarse/fine selection",
    "coarse_threshold_role": "CP after restoring selected checkpoint",
    "CAL_usage": "post-freeze known diagnostic only; no checkpoint or coarse threshold tuning",
    "fit_sampler": "existing hierarchical family-balanced replacement; one epoch has4200 draws from4200 originals",
    "physical_source_copies_added": 0, "source_groups_balanced": False,
    "model": "existing MHFDNetwork and unchanged train_model losses/optimizer",
    "DEV_feature_or_truth_opened": False, "UNA_training_rows": 0,
    "final_test_executed": False, "independent_final_admitted": False,
    "historical_baseline_comparison": "NOT_COMPARABLE", "published": False,
}


class NativeKnownTrainingStop(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise NativeKnownTrainingStop(reason)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def descriptor(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": sha(path)}


def array_descriptor(value):
    value = np.asarray(value)
    return {"shape": list(value.shape), "dtype": str(value.dtype),
            "C_order_bytes_sha256": hashlib.sha256(value.tobytes(order="C")).hexdigest()}


def _write(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
    return descriptor(path)


def _checked(item, pins):
    path = Path(item["path"])
    path = (path if path.is_absolute() else ROOT / path).resolve()
    require(path.is_relative_to(ROOT) and path != ROOT, "workspace_input_required")
    payload = path.read_bytes()
    require(hashlib.sha256(payload).hexdigest() == item["sha256"], "input_pin_changed:" + str(path))
    require(pins.get(str(path), item["sha256"]) == item["sha256"], "conflicting_input_pin")
    pins[str(path)] = item["sha256"]
    return payload


def _load_source(source_report, pins):
    source = json.loads(_checked(source_report, pins))
    require(source.get("schema_version") == "CIC2017-native-known-source-extract-v1"
            and source.get("execution_status") == "native_CIC1_known_source_extraction_completed"
            and source.get("setting") == "CIC Setting1"
            and source.get("source_extraction_completed") is True
            and source.get("all_input_pins_stable") is True
            and source.get("source_role_binding_verified") is True
            and source.get("status") == "FAIL_TARGET99" and source.get("published") is False
            and source.get("final_test_executed") is False, "completed_native_known_source_required")
    for path, expected in source["input_sha256"].items():
        _checked({"path": path, "sha256": expected}, pins)
    files = source["files"]
    with np.load(io.BytesIO(_checked(files["known_roles_archive"], pins)), allow_pickle=False) as saved:
        arrays = {name: saved[name].copy() for name in saved.files}
    records = json.loads(_checked(files["ordered_source_records"], pins))
    _validate_arrays(arrays, records)
    return source, arrays, records


def _validate_arrays(arrays, records):
    required = {role + "_" + name for role in ROLES for name in ("native78", "ids", "y_fine", "y_coarse")}
    require(set(arrays) == required and set(records["roles"]) == set(ROLES)
            and records["schema_version"] == "CIC2017-native-known-ordered-source-records-v1"
            and records["setting"] == "CIC Setting1" and tuple(records["family_order"]) == FAMILIES
            and tuple(records["model_columns"]) == CIC_FEATURE_COLUMNS, "exact_three_native_known_roles")
    seen_ids, seen_groups = set(), set()
    for role, count in ROLES.items():
        matrix, ids, fine, coarse = (arrays[role + "_" + name] for name in ("native78", "ids", "y_fine", "y_coarse"))
        require(matrix.dtype == np.dtype("<f8") and matrix.shape == (count, 78)
                and np.isfinite(matrix).all(), "finite_canonical_native78:" + role)
        require(ids.dtype.kind == "U" and ids.shape == (count,)
                and fine.dtype == coarse.dtype == np.int64 and fine.shape == coarse.shape == (count,)
                and np.all((fine >= 0) & (fine < len(FAMILIES)))
                and np.array_equal(coarse, (fine != 0).astype(np.int64)), "known_role_labels:" + role)
        require(len(set(ids.tolist())) == count and not seen_ids.intersection(ids.tolist()), "cross_role_source_ID_overlap")
        seen_ids.update(ids.tolist())
        counts = Counter(fine.tolist())
        require(set(counts) == set(range(len(FAMILIES))) and min(counts.values()) >= 20, "every_known_family_role_floor")
        rows = records["roles"][role]
        require(len(rows) == count, "ordered_source_record_count")
        for index, row in enumerate(rows):
            fingerprint = hashlib.sha256(matrix[index].tobytes(order="C")).hexdigest()
            require(row["sample_id"] == ids[index] and row["family"] == FAMILIES[int(fine[index])]
                    and row["canonical78_sha256"] == fingerprint, "source_record_feature_label_identity_binding")
            require(fingerprint not in seen_groups, "cross_role_or_within_role_feature_group_repeat")
            seen_groups.add(fingerprint)
    require(len(seen_groups) == len(seen_ids) == 6000, "exact_unique_training_side_6000")


def _prepare(arrays):
    frames = {r: pd.DataFrame(arrays[r + "_native78"], columns=CIC_FEATURE_COLUMNS) for r in ROLES}
    transformer = preprocessing._build_preprocessor(get_spec("CIC Setting1"))
    transformed = {"FIT": np.asarray(transformer.fit_transform(frames["FIT"]), dtype=np.float32)}
    for role in ("CAL", "CP"):
        transformed[role] = np.asarray(transformer.transform(frames[role]), dtype=np.float32)
    variance_mask = np.var(transformed["FIT"], axis=0) > 0.0
    require(int(variance_mask.sum()) >= 2, "two_nonconstant_FIT_features_required")
    selector = SelectKBest(f_classif, k=min(TOP_K, int(variance_mask.sum())))
    features = {"FIT": selector.fit_transform(transformed["FIT"][:, variance_mask], arrays["FIT_y_fine"]).astype(np.float32)}
    for role in ("CAL", "CP"):
        features[role] = selector.transform(transformed[role][:, variance_mask]).astype(np.float32)
    require(all(x.shape[0] == ROLES[r] and np.isfinite(x).all() for r, x in features.items()), "finite_paper_preprocessed_known_features")
    names = tuple(np.asarray(transformer.get_feature_names_out())[variance_mask][selector.get_support()].tolist())
    return features, {"transformer": transformer, "variance_mask": variance_mask,
                      "selector": selector, "selected_feature_names": names, "family_order": FAMILIES}


def _gates(truth, prediction):
    result = {}
    for name, code in (("BEN", 0), ("KNA", 1)):
        mask = truth == code
        n, correct = int(mask.sum()), int(np.sum(prediction[mask] == code))
        require(n > 0, "nonempty_known_gate")
        result[name] = {"correct": correct, "support": n, "required_correct": (99 * n + 99) // 100,
                        "passed": 100 * correct >= 99 * n}
    return result


def run_training(*, source_report, output_directory):
    output = Path(output_directory).resolve()
    require(output.is_relative_to(ROOT) and output != ROOT, "fresh_workspace_child_required")
    output.mkdir(parents=True, exist_ok=False)
    started, stage, pins = time.perf_counter(), "native_known_source_binding", {}
    report = {"configuration": POLICY, "status": "FAIL_TARGET99", "published": False,
              "final_test_executed": False, "training_started": False, "training_completed": False,
              "training_runs": 0, "metrics_evaluated": False, "DEV_executed": False,
              "known_inference_roles_started": [], "known_inference_roles_returned": [],
              "coarse_threshold_sealed": False, "CAL_inference_attempted": False, "CAL_inference_returned": False,
              "accepted_baseline_replaced": False, "EffectDelta": {"verdict": "NOT_COMPARABLE"}}
    try:
        source, arrays, records = _load_source(source_report, pins)
        for path in (Path(__file__), Path(network.__file__), Path(preprocessing.__file__), ROOT / "paper_open_set/config.py"):
            pins[str(path.resolve())] = sha(path)
        stage = "FIT_only_paper_preprocessing"
        features, transforms = _prepare(arrays)
        preprocessing_path = output / "complete_FIT_preprocessing.joblib"
        joblib.dump(transforms, preprocessing_path, compress=3)
        preprocessing_artifact = descriptor(preprocessing_path)
        pins[preprocessing_artifact["path"]] = preprocessing_artifact["sha256"]
        feature_path = output / "exact_known_training_inputs_before_fit.npz"
        np.savez_compressed(feature_path, **{r + "_features": x for r, x in features.items()},
                            **{k: v for k, v in arrays.items() if not k.endswith("_native78")})
        feature_artifact = descriptor(feature_path)
        pins[feature_artifact["path"]] = feature_artifact["sha256"]
        prefit = _write(output / "training_policy_before_fit.json", {"configuration": POLICY,
            "source_report": source_report, "source_files": source["files"], "known_inputs": feature_artifact,
            "preprocessing": preprocessing_artifact, "features": {r: array_descriptor(x) for r, x in features.items()},
            "selected_feature_names": transforms["selected_feature_names"], "family_order": FAMILIES,
            "input_sha256": dict(pins), "CAL_used_in_training_or_selection": False})
        pins[prefit["path"]] = prefit["sha256"]
        stage = "one_fixed_MHFD_known_FIT_training"
        torch.set_num_threads(4)
        report["training_started"], report["training_runs"] = True, None
        result = network.train_model(features["FIT"], arrays["FIT_y_coarse"], arrays["FIT_y_fine"],
            features["CP"], arrays["CP_y_coarse"], fine_class_count=len(FAMILIES), epochs=EPOCHS,
            seed=SEED, progress_label="CIC1 native known", checkpoint_fine_labels=arrays["CP_y_fine"])
        report.update(training_completed=True, training_runs=1, training_seconds=float(result.training_seconds),
                      selected_epoch=int(result.selected_epoch), device=result.device)
        stage = "freeze_selected_model_then_infer_known_roles"
        model_path = output / "selected_MHFD_state.pt"
        state = {k: v.detach().cpu() for k, v in result.model.state_dict().items()}
        torch.save({"state_dict": state, "input_dim": features["FIT"].shape[1], "fine_class_count": len(FAMILIES),
                    "selected_epoch": result.selected_epoch, "seed": SEED}, model_path)
        restored = torch.load(model_path, map_location="cpu", weights_only=True)
        require(set(restored["state_dict"]) == set(state)
                and all(torch.equal(v, restored["state_dict"][k]) for k, v in state.items()), "selected_model_roundtrip")
        model_artifact = descriptor(model_path)
        pins[model_artifact["path"]] = model_artifact["sha256"]
        outputs = {}
        for role in ("FIT", "CP"):
            stage = "post_training_known_inference_" + role
            report["known_inference_roles_started"].append(role)
            outputs[role] = network.infer(result.model, features[role], device=torch.device(result.device))
            report["known_inference_roles_returned"].append(role)
        stage = "freeze_coarse_threshold_from_CP"
        threshold, threshold_metrics = network.choose_coarse_threshold(arrays["CP_y_coarse"], outputs["CP"].attack_probability)
        threshold_artifact = _write(output / "coarse_threshold_from_known_CP.json", {"threshold": float(threshold),
            "selection_role": "CP", "model": model_artifact, "CP_probability": array_descriptor(outputs["CP"].attack_probability),
            "known_CP_metrics": threshold_metrics, "CAL_labels_used": False})
        pins[threshold_artifact["path"]] = threshold_artifact["sha256"]
        report["coarse_threshold_sealed"] = True
        stage = "post_threshold_CAL_known_diagnostic_inference"
        report["CAL_inference_attempted"] = True
        report["known_inference_roles_started"].append("CAL")
        outputs["CAL"] = network.infer(result.model, features["CAL"], device=torch.device(result.device))
        report["CAL_inference_returned"] = True
        report["known_inference_roles_returned"].append("CAL")
        stage = "validate_known_outputs_and_calculate_integer_gates"
        prediction_arrays, gates = {}, {}
        for role, values in outputs.items():
            require(values.attack_probability.shape == (ROLES[role],)
                    and np.isfinite(values.attack_probability).all()
                    and np.all((values.attack_probability >= 0) & (values.attack_probability <= 1))
                    and values.fine_probability.shape == (ROLES[role], len(FAMILIES))
                    and np.isfinite(values.fine_probability).all()
                    and values.embedding.shape[0] == ROLES[role]
                    and np.isfinite(values.embedding).all()
                    and values.reconstruction_error.shape == (ROLES[role],)
                    and np.isfinite(values.reconstruction_error).all(), "finite_known_inference_outputs:" + role)
            pred = (values.attack_probability >= threshold).astype(np.int64)
            gates[role] = _gates(arrays[role + "_y_coarse"], pred)
            prediction_arrays.update({role + "_prediction": pred, role + "_ids": arrays[role + "_ids"],
                role + "_truth": arrays[role + "_y_coarse"], role + "_fine_truth": arrays[role + "_y_fine"],
                role + "_probability": values.attack_probability, role + "_fine_probability": values.fine_probability,
                role + "_embedding": values.embedding, role + "_reconstruction_error": values.reconstruction_error})
        prediction_path = output / "post_training_known_predictions.npz"
        np.savez_compressed(prediction_path, **prediction_arrays)
        predictions = descriptor(prediction_path)
        pins[predictions["path"]] = predictions["sha256"]
        history = _write(output / "training_history.json", result.history)
        pins[history["path"]] = history["sha256"]
        stage = "final_source_model_and_training_input_integrity"
        for path, expected in pins.items():
            require(sha(path) == expected, "pinned_input_changed_during_training:" + path)
        report.update(execution_status="native_CIC1_known_training_completed", metrics_evaluated=True,
            known_class_gates=gates, coarse_threshold=float(threshold),
            CAL_known_diagnostic_passed=all(v["passed"] for v in gates["CAL"].values()),
            post_training_known_inference_roles=list(outputs), training_internal_inference="FIT and CP each epoch in existing trainer",
            files={"prefit": prefit, "preprocessing": preprocessing_artifact, "training_inputs": feature_artifact,
                   "model": model_artifact, "threshold": threshold_artifact, "predictions": predictions, "history": history})
    except Exception as error:
        report.update(execution_status="protocol_stop" if isinstance(error, NativeKnownTrainingStop) else "execution_failed",
                      failed_stage=stage, error_type=type(error).__name__, error_message=str(error))
    report.update(input_sha256=pins, wall_seconds=time.perf_counter() - started)
    _write(output / "report.json", report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-report", required=True)
    parser.add_argument("--source-report-sha256", required=True)
    parser.add_argument("--output-directory", required=True)
    args = parser.parse_args(argv)
    report = run_training(source_report={"path": args.source_report, "sha256": args.source_report_sha256}, output_directory=args.output_directory)
    print(json.dumps({k: report.get(k) for k in ("execution_status", "training_seconds", "selected_epoch", "known_class_gates", "failed_stage", "error_message")}, ensure_ascii=False))
    return 0 if report["metrics_evaluated"] else 2 if report["execution_status"] == "protocol_stop" else 1


if __name__ == "__main__":
    raise SystemExit(main())
