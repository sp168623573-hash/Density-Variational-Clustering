"""All observed genuine DestinationPort x knowncoarse relative occupancy."""
import numpy as np
NF_MIN=20;NQ_MIN=7;K=7;PRIOR=1
def require(v,why):
    if not v:raise ValueError(why)
def recipe():
    return dict(schema_version='CIC1-allrawDestinationPort-knowncoarse-context-relative-density126-v134',
        context='every exact raw DestinationPort integer0..65535 crossedwith knowncoarse0/1, no portbin or selectedport',
        FIT='all6000 genuine known FIT; contexts built trueknowncoarse0/1, entire126 preserved',
        query='preV123 completewhole2402 predictedcoarse0/1 population within allobservedrawport; no truequeryclass',
        support='NFcontext>=20 and NQcontext>=7; unavailablecontext score0 eligiblefalse, not normal identity proof',
        radius='samecontext FIT learned126 seventhnearest closedball all exactties',
        score='log((query_other_closedball+1)/NQctx)-log((FIT_closedball+1)/(NFctx+1))',
        calibration='trueknownnegative CAL originalstage-consistent classpopulation; all900truecoarse oncefinite99; originalquery stage1 cutbank',
        parameters=dict(NF=NF_MIN,NQ=NQ_MIN,k=K,count_prior=PRIOR),query_fit=False,parameter_grid=False,timecap_coded=False)
def port_values(native,index):
    x=np.asarray(native,np.float64);require(x.ndim==2 and x.shape[1]==78 and type(index) is int and 0<=index<78 and np.isfinite(x).all(),'actualcomplete78 and verifiedsource portindex')
    p=x[:,index];require(np.all((p>=0)&(p<=65535)) and np.array_equal(p,np.floor(p)),'originalobservedrawport is integer uint16, no learnttransform')
    return p.astype(np.int64)
def background(z,groups,fine,ports):
    z=np.asarray(z,np.float64);groups=np.asarray(groups);fine=np.asarray(fine);ports=np.asarray(ports)
    require(z.shape==(6000,126) and groups.shape==fine.shape==ports.shape==(6000,) and len(np.unique(groups))==6000 and np.isfinite(z).all() and np.isin(fine,np.arange(9)).all(),'genuinewholeknown6000 nooptimizercopy references')
    contexts=np.column_stack(((fine>0).astype(np.int64),ports));vocabulary,code=np.unique(contexts,axis=0,return_inverse=True);counts=np.bincount(code,minlength=len(vocabulary))
    return dict(Z126=z,groups=groups,truefine=fine,ports=ports,contexts2=contexts,vocabulary2=vocabulary,context_counts=counts)
def infer(metric,z,groups,ports,population,reference):
    z=np.asarray(z,np.float64);groups=np.asarray(groups);ports=np.asarray(ports);population=np.asarray(population)
    require(metric.dimension==126 and z.shape==(len(groups),126) and ports.shape==population.shape==(len(groups),) and np.isfinite(z).all() and np.isin(population,(-1,0,1,2)).all(),'complete126 exactport/unlabelledpop source')
    unique,rep,inv=np.unique(groups,return_index=True,return_inverse=True)
    require(np.array_equal(z,z[rep][inv]) and np.array_equal(ports,ports[rep][inv]) and np.array_equal(population,population[rep][inv]),'canonicalphysicalcopies sharegeometry port population, no counts amplification')
    require(not set(groups.tolist())&set(reference['groups'].tolist()),'querygenuinegroups disjointknownFIT')
    ctx=np.column_stack((population,ports));n=len(rep);score=np.zeros(n);eligible=np.zeros(n,bool);radius=np.zeros(n);nfball=np.zeros(n,np.int64);nqball=np.zeros(n,np.int64);nfctx=np.zeros(n,np.int64);nqctx=np.zeros(n,np.int64);details=[]
    for c,nf in zip(reference['vocabulary2'],reference['context_counts']):
        qi=np.flatnonzero(np.all(ctx[rep]==c,axis=1));fi=np.flatnonzero(np.all(reference['contexts2']==c,axis=1));require(len(fi)==int(nf),'actualallcoarseport NFcount')
        nfctx[qi]=len(fi);nqctx[qi]=len(qi)
        if len(fi)<NF_MIN or len(qi)<NQ_MIN:continue
        qz=z[rep[qi]];f=reference['Z126'][fi];qf=metric.pairwise_distances(qz,f);ball=np.partition(qf,K-1,axis=1)[:,K-1];fc=(qf<=ball[:,None]).sum(1)
        qq=metric.pairwise_distances(qz);require(np.array_equal(np.diag(qq),np.zeros(len(qi))),'owned126 actualselfzero');qc=(qq<=ball[:,None]).sum(1)-1
        require(np.all(fc>=K) and np.all(qc>=0) and np.all(qc<len(qi)),'allclosedties and queryself exactlyexcluded')
        score[qi]=np.log((qc+PRIOR)/len(qi))-np.log((fc+PRIOR)/(len(fi)+PRIOR));eligible[qi]=True;radius[qi]=ball;nfball[qi]=fc;nqball[qi]=qc
        details.append(dict(context2=c,query_native_indices=qi,query_original_indices=rep[qi],FIT_indices=fi,query_to_FIT_distances=qf,query_pair_distances=qq))
    require(np.isfinite(score).all(),'finite actualdensity ratio no epsilon/clipping')
    return dict(score=score[inv],eligible=eligible[inv],radius=radius[inv],FIT_ball_count=nfball[inv],query_other_ball_count=nqball[inv],FIT_context_count=nfctx[inv],query_context_count=nqctx[inv],
        ports=ports,population=population,contexts2=ctx,representatives=rep,inverse=inv,genuine_score=score,genuine_eligible=eligible,native_groups=np.asarray(len(unique))),details
def synthetic_contract():
    class M:
        dimension=126
        def pairwise_distances(self,a,b=None):
            b=a if b is None else b;return np.sqrt(np.square(a[:,None]-b[None]).sum(2))
    # Two contexts and exactties; only context NF20/NQ7 gets evidence. Every
    # reference/query below is synthetic, not a fake statistical traffic event.
    f=np.zeros((40,126));f[20:,0]=2.;g=np.array(['F'+str(i) for i in range(40)]);ctx=np.column_stack((np.r_[np.zeros(20,np.int64),np.ones(20,np.int64)],np.r_[np.full(20,80),np.full(20,443)]))
    ref=dict(Z126=f,groups=g,contexts2=ctx,vocabulary2=np.array([[0,80],[1,443]]),context_counts=np.array([20,20]))
    q=np.zeros((14,126));q[7:,0]=2.;groups=np.array(['Q'+str(i) for i in range(14)]);p=np.r_[np.full(7,80),np.full(7,443)];coarse=np.r_[np.zeros(7,np.int64),np.ones(7,np.int64)]
    value,_=infer(M(),q,groups,p,coarse,ref)
    require(np.all(value['eligible']) and np.all(value['FIT_ball_count']==20) and np.all(value['query_other_ball_count']==6),'all20 exactFITties and6others self excluded bothbanks')
    unknown,_=infer(M(),q,groups,np.full(14,12345),coarse,ref);require(not unknown['eligible'].any() and np.all(unknown['score']==0),'allunseenports failclosed no semanticnormalcertificate')
    clone,_=infer(M(),np.concatenate((q,q[2:3])),np.concatenate((groups,groups[2:3])),np.r_[p,p[2]],np.r_[coarse,coarse[2]],ref)
    require(np.array_equal(value['genuine_score'],clone['genuine_score']) and int(clone['native_groups'])==14,'nativecopy doesnotinflate NQ or reference density')
    native=np.zeros((3,78));native[:,6]=[0,80,65535];require(port_values(native,6).tolist()==[0,80,65535],'indexsuppliedfromrealorderedmetadata no hardcodedzero')
    return dict(synthetic_only=True,realtraffic=0,bothcoarsebanks_sameformula=True,closedties_and_selfexclude=True,allunseenport_failclosed=True,nativecopy_noamplification=True,portindex_from_metadata=True)
