"""One fixed signed-log MHFD control on the unchanged CIC2 coverage cohort."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
from functools import partial
import io
import json
import os
from pathlib import Path
import time

import joblib
import numpy as np
import pandas as pd
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.preprocessing import FunctionTransformer
import torch

from . import data as preprocessing
from . import model as network
from . import mhfd_numeric_checkpoint as numeric_geometry
from .config import CIC_FEATURE_COLUMNS, get_spec

ROOT = Path(__file__).resolve().parents[1]
ROLES = {"FIT": 4187, "CAL": 882, "CP": 882}
EFFECTIVE_ROLES = {"FIT": 4200, "CAL": 900, "CP": 900}
INDEX_FIELDS = {"FIT": "FIT_training_indices", "CAL": "CAL_reporting_indices", "CP": "CP_reporting_indices"}
FAMILIES = ("BEN", *get_spec("CIC Setting2").known_families)
EPOCHS, SEED, TOP_K = 80, 20261008, 50
SOURCE_REPORT = {"path": "data/external_dev/processed/cic2017_setting2_known_fit_coverage_extract_20261008_v1/report.json",
    "sha256": "77eaffd4fa9d35e633cb0d38ab880eff308db742bc6f9b3b6b816ba3554d09c3"}
POLICY = {
    "schema_version": "CIC2017-setting2-fixed-controls-signed-log-MHFD-v1",
    "setting": "CIC Setting2", "datasets_used": ["CIC-2017"],
    "original_roles": ROLES, "effective_roles": EFFECTIVE_ROLES,
    "unique_training_side_original_groups": 5951, "effective_training_side_total": 6000,
    "minimum_family_effective_rows_per_role": 20,
    "minimum_nonHeart_FIT_original_family_rows": 100,
    "fixed_controls": "same original CP882/CAL882 ordered native78,IDs,labels and900 report indices",
    "changed_FIT_groups": 320,
    "source_original_proportions": "FIT floor100 nonHeart/floor20 Heart then exact source-proportion waterfill; deviations reported",
    "runtime_change": "none relative to the coverage NN; same CUBLAS_WORKSPACE_CONFIG and runtime contract", "epochs": EPOCHS, "seed": SEED,
    "preprocessing": "native float64 sign(x)*log1p(abs(x)) before median imputer/StandardScaler; variance/ANOVA top50 fitted on4187 original FIT rows only",
    "representation_only_control": True, "feature_clipping": False,
    "signed_log_saved_inside_preprocessor": True, "preprocessing_roundtrip_required_before_training": True,
    "comparison_primary": "coverage_forest_blend_4cd399_candidate_not_accepted_baseline",
    "optimizer_input": "sealed FIT_training_indices: all4187 originals plus13 cyclic Heartbleed copies;4200 rows",
    "fit_sampler": "unchanged hierarchical family-balanced replacement over4200 optimizer rows",
    "checkpoint_selection": "unchanged train_model on882 original CP only, coarse and fine labels",
    "coarse_threshold_role": "882 original CP after restoring selected checkpoint",
    "CAL_usage": "882 originals diagnostic only after model and threshold freeze",
    "post_training_numeric_roles": ROLES,
    "copies": "13 FIT copies for optimization; CAL18 and CP18 copies reporting only",
    "density_copy_rows": 0, "CAL_CP_copy_rows_in_model_selection_or_calibration": 0,
    "model": "existing MHFDNetwork and unchanged train_model losses/optimizer",
    "cross_setting_parameters_transferred": False, "new_CIC2_model_from_seed": True,
    "known_source_scope": "explicitly warm;11 historically exposed Heartbleed groups; other groups retain original exclusion",
    "physical_event_independence_claimed": False, "historical_exposure_exhaustively_resolved": False,
    "DEV_feature_or_truth_opened": False, "UNA_training_rows": 0,
    "final_test_executed": False, "independent_final_admitted": False,
    "historical_baseline_comparison": "same CP/CAL controls, paired correctness after model freeze", "published": False,
}


class NativeKnownTrainingStop(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise NativeKnownTrainingStop(reason)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def descriptor(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": sha(path)}


def array_descriptor(value):
    value = np.asarray(value)
    return {"shape": list(value.shape), "dtype": str(value.dtype),
            "C_order_bytes_sha256": hashlib.sha256(value.tobytes(order="C")).hexdigest()}


def _write(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        stream.write("\n")
    return descriptor(path)


def _checked(item, pins):
    path = Path(item["path"])
    path = (path if path.is_absolute() else ROOT / path).resolve()
    require(path.is_relative_to(ROOT) and path != ROOT, "workspace_input_required")
    payload = path.read_bytes()
    require(hashlib.sha256(payload).hexdigest() == item["sha256"], "input_pin_changed:" + str(path))
    require(pins.get(str(path), item["sha256"]) == item["sha256"], "conflicting_input_pin")
    pins[str(path)] = item["sha256"]
    return payload


def _load_source(source_report, pins):
    given = Path(source_report["path"])
    given = (given if given.is_absolute() else ROOT / given).resolve()
    require(given == (ROOT / SOURCE_REPORT["path"]).resolve()
            and source_report["sha256"] == SOURCE_REPORT["sha256"], "same_frozen_coverage_source_required")
    source = json.loads(_checked(source_report, pins))
    require(source.get("schema_version") == "CIC2017-setting2-fixed-controls-FIT-coverage-source-v1"
            and source.get("execution_status") == "native_CIC2_fixed_controls_FIT_coverage_extraction_completed"
            and source.get("setting") == "CIC Setting2"
            and source.get("source_extraction_completed") is True
            and source.get("all_input_pins_stable") is True
            and source.get("source_role_binding_verified") is True
            and source.get("Heartbleed_warm_exception_only") is True
            and source.get("control_cohort_unchanged") is True
            and source.get("changed_FIT_groups") == 320
            and source.get("status") == "FAIL_TARGET99" and source.get("published") is False
            and source.get("final_test_executed") is False, "completed_native_CIC2_warm_source_required")
    # Integrity-only streaming avoids materializing large Parquet/SQLite files in RAM.
    for raw_path, expected in source["input_sha256"].items():
        path = Path(raw_path).resolve()
        require(path.is_relative_to(ROOT) and path != ROOT and sha(path) == expected,
                "source_dependency_pin_changed:" + str(path))
        require(pins.get(str(path), expected) == expected, "conflicting_source_dependency_pin")
        pins[str(path)] = expected
    files = source["files"]
    with np.load(io.BytesIO(_checked(files["known_roles_archive"], pins)), allow_pickle=False) as saved:
        arrays = {name: saved[name].copy() for name in saved.files}
    records = json.loads(_checked(files["ordered_source_records"], pins))
    _validate_arrays(arrays, records)
    _validate_fixed_controls(arrays, records, pins)
    return source, arrays, records


def _validate_fixed_controls(arrays, records, pins):
    old_report = json.loads(_checked({"path": str(ROOT/"data/external_dev/processed/cic2017_setting2_warm_known_source_extract_20261008_v1/report.json"),
        "sha256": "411e53400ac69a026eb6b21206ed97f24e14724aaf5073cf52b9c150b160b92a"}, pins))
    with np.load(io.BytesIO(_checked(old_report["files"]["known_roles_archive"], pins)), allow_pickle=False) as z:
        old = {key: z[key].copy() for key in z.files}
    old_records = json.loads(_checked(old_report["files"]["ordered_source_records"], pins))
    for role in ("CP", "CAL"):
        for suffix in ("native78", "ids", "y_fine", "y_coarse"):
            key = role + "_" + suffix
            require(array_descriptor(arrays[key]) == array_descriptor(old[key]), "fixed_control_bytes_changed:" + key)
        require(array_descriptor(arrays[INDEX_FIELDS[role]]) == array_descriptor(old[INDEX_FIELDS[role]])
            and records["roles"][role] == old_records["roles"][role]
            and records["role_effective_indices"][role] == old_records["role_effective_indices"][role],
            "fixed_control_records_and_reporting_mapping_changed:" + role)
    old_all = {r["canonical78_sha256"] for rows in old_records["roles"].values() for r in rows}
    old_fit = {r["canonical78_sha256"] for r in old_records["roles"]["FIT"]}
    new_fit = {r["canonical78_sha256"] for r in records["roles"]["FIT"]}
    require(len(new_fit-old_all) == 320 and len(old_fit-new_fit) == 320
            and len(new_fit & old_fit) == 3867, "exact320_new_and_removed_FIT_groups")
    previous_heart = {r["canonical78_sha256"] for r in old_records["roles"]["FIT"] if r["family"] == "Heartbleed"}
    next_heart = {r["canonical78_sha256"] for r in records["roles"]["FIT"] if r["family"] == "Heartbleed"}
    require(previous_heart == next_heart and len(next_heart) == 7, "same_seven_Heart_originals")


def _validate_arrays(arrays, records):
    required = {role + "_" + name for role in ROLES for name in ("native78", "ids", "y_fine", "y_coarse")} | set(INDEX_FIELDS.values())
    require(set(arrays) == required and set(records["roles"]) == set(ROLES)
            and records["schema_version"] == "CIC2-fixed-controls-FIT-coverage-ordered-source-records-v1"
            and records["setting"] == "CIC Setting2" and tuple(records["family_order"]) == FAMILIES
            and tuple(records["model_columns"]) == CIC_FEATURE_COLUMNS, "exact_CIC2_known_original_and_copy_roles")
    seen_ids, seen_groups = set(), set()
    heart = FAMILIES.index("Heartbleed")
    for role, count in ROLES.items():
        matrix, ids, fine, coarse = (arrays[role + "_" + name] for name in ("native78", "ids", "y_fine", "y_coarse"))
        require(matrix.dtype == np.dtype("<f8") and matrix.shape == (count, 78)
                and np.isfinite(matrix).all(), "finite_canonical_native78:" + role)
        require(ids.dtype.kind == "U" and ids.shape == (count,)
                and fine.dtype == coarse.dtype == np.int64 and fine.shape == coarse.shape == (count,)
                and np.all((fine >= 0) & (fine < len(FAMILIES)))
                and np.array_equal(coarse, (fine != 0).astype(np.int64)), "known_role_labels:" + role)
        require(len(set(ids.tolist())) == count and not seen_ids.intersection(ids.tolist()), "cross_role_source_ID_overlap")
        seen_ids.update(ids.tolist())
        original_counts = Counter(fine.tolist())
        require(set(original_counts) == set(range(len(FAMILIES)))
                and original_counts[heart] == (7 if role == "FIT" else 2)
                and all(v >= (100 if role == "FIT" else 20) for k, v in original_counts.items() if k != heart), "positive_original_family_support")
        indices = arrays[INDEX_FIELDS[role]]
        heart_indices = np.flatnonzero(fine == heart)
        expected_indices = np.concatenate((np.arange(count, dtype=np.int64),
            np.resize(heart_indices, EFFECTIVE_ROLES[role] - count)))
        require(indices.dtype == np.int64 and np.array_equal(indices, expected_indices),
                "exact_role_internal_cyclic_Heart_copy_mapping:" + role)
        require(np.array_equal(indices, np.asarray(records["role_effective_indices"][role]["indices"], dtype=np.int64)),
                "copy_mapping_matches_source_records:" + role)
        require(min(Counter(fine[indices].tolist()).values()) >= 20, "effective_family_floor")
        rows = records["roles"][role]
        require(len(rows) == count, "ordered_source_record_count")
        for index, row in enumerate(rows):
            fingerprint = hashlib.sha256(matrix[index].tobytes(order="C")).hexdigest()
            require(row["sample_id"] == ids[index] and row["family"] == FAMILIES[int(fine[index])]
                    and row["canonical78_sha256"] == fingerprint, "source_record_feature_label_identity_binding")
            is_heart = int(fine[index]) == heart
            require(row["historical_inventory_blocked"] is is_heart
                    and (is_heart or (row["selected_group_historical_excluded_members"] == 0
                        and row["representative_historical_ordinal_excluded"] is False)),
                    "historical_warm_exception_limited_to_Heartbleed")
            require(fingerprint not in seen_groups, "cross_role_or_within_role_feature_group_repeat")
            seen_groups.add(fingerprint)
    require(len(seen_groups) == len(seen_ids) == 5951, "exact_unique_known_original_5951")


def _prepare(arrays):
    require(all(arrays[r + "_native78"].dtype == np.float64
                and np.isfinite(arrays[r + "_native78"]).all() for r in ROLES),
            "native_float64_required_before_signed_log")
    frames = {r: pd.DataFrame(arrays[r + "_native78"], columns=CIC_FEATURE_COLUMNS) for r in ROLES}
    transformer = preprocessing._build_preprocessor(get_spec("CIC Setting2"))
    # This importable callback is serialized INSIDE the full numeric pipeline.
    # Native float64 reaches log1p before the existing downstream float32 cast.
    numeric = transformer.transformers[0][1]
    numeric.steps.insert(0, ("signed_log1p", FunctionTransformer(
        partial(numeric_geometry._geometry, transform="signed_log1p"),
        validate=False, feature_names_out="one-to-one")))
    transformed = {"FIT": np.asarray(transformer.fit_transform(frames["FIT"]), dtype=np.float32)}
    for role in ("CAL", "CP"):
        transformed[role] = np.asarray(transformer.transform(frames[role]), dtype=np.float32)
    variance_mask = np.var(transformed["FIT"], axis=0) > 0.0
    require(int(variance_mask.sum()) >= 2, "two_nonconstant_FIT_features_required")
    selector = SelectKBest(f_classif, k=min(TOP_K, int(variance_mask.sum())))
    features = {"FIT": selector.fit_transform(transformed["FIT"][:, variance_mask], arrays["FIT_y_fine"]).astype(np.float32)}
    for role in ("CAL", "CP"):
        features[role] = selector.transform(transformed[role][:, variance_mask]).astype(np.float32)
    require(all(x.shape[0] == ROLES[r] and np.isfinite(x).all() for r, x in features.items()), "finite_paper_preprocessed_known_features")
    names = tuple(np.asarray(transformer.get_feature_names_out())[variance_mask][selector.get_support()].tolist())
    return features, {"transformer": transformer, "variance_mask": variance_mask,
                      "selector": selector, "selected_feature_names": names, "family_order": FAMILIES,
                      "representation": "native_float64_signed_log1p_before_original_pipeline"}


def _gates(truth, prediction):
    result = {}
    for name, code in (("BEN", 0), ("KNA", 1)):
        mask = truth == code
        n, correct = int(mask.sum()), int(np.sum(prediction[mask] == code))
        require(n > 0, "nonempty_known_gate")
        result[name] = {"correct": correct, "support": n, "required_correct": (99 * n + 99) // 100,
                        "passed": 100 * correct >= 99 * n}
    return result


PARENTS = {
    "coverage_MHFD": {"path": "data/external_dev/processed/cic2017_setting2_known_fit_coverage_training_20261008_v1/CIC_Setting2/report.json",
        "sha256": "753346a9f6c9a276b9becdf5c3102b0905412c98389a8a086c82cfde607823a9", "kind": "NN"},
    "coverage_forest_blend": {"path": "data/external_dev/processed/cic2017_setting2_known_fit_coverage_forest_blend_20261008_v1/CIC_Setting2/report.json",
        "sha256": "4cd3996dc86d8d400f7df650668842b355d158cdd2b69749ed5c53198a2af736", "kind": "forest", "weight": .75, "CP_key": "w3_prediction"},
    "original_forest_blend": {"path": "data/external_dev/processed/cic2017_setting2_warm_known_forest_blend_20261008_v1/CIC_Setting2/report.json",
        "sha256": "e2a2c55da2d0cf8ad64164c4688bd43e0da857aee63e54bb38d266af8f83923c", "kind": "forest", "weight": .25, "CP_key": "w1_prediction"},
}


def transform_native78(transforms, native78):
    """Replay complete saved preprocessing from native values, without fitting."""
    require(native78.dtype == np.float64 and native78.ndim == 2 and native78.shape[1] == 78
            and np.isfinite(native78).all(), "native_float64_required_before_signed_log")
    frame = pd.DataFrame(native78, columns=CIC_FEATURE_COLUMNS)
    values = np.asarray(transforms["transformer"].transform(frame), dtype=np.float32)
    values = transforms["selector"].transform(values[:, transforms["variance_mask"]]).astype(np.float32)
    require(np.isfinite(values).all(), "finite_saved_signed_log_features")
    return values


def _check_preprocessing_roundtrip(item, arrays, features, transforms, pins):
    restored = joblib.load(io.BytesIO(_checked(item, pins)))
    require(restored.get("representation") == "native_float64_signed_log1p_before_original_pipeline"
            and tuple(restored["transformer"].get_feature_names_out()) == tuple(CIC_FEATURE_COLUMNS)
            and tuple(restored["selected_feature_names"]) == tuple(transforms["selected_feature_names"]),
            "saved_full_signed_log_pipeline_and_feature_names")
    checks = {}
    for role in ROLES:
        live = transform_native78(restored, arrays[role + "_native78"])
        require(array_descriptor(live) == array_descriptor(features[role]), "saved_preprocessing_exact_features:" + role)
        checks[role] = {"native_float64": array_descriptor(arrays[role + "_native78"]),
                        "replayed_features": array_descriptor(live), "byte_exact": True}
    return checks


def _check_training_material(item, material, bound, pins):
    with np.load(io.BytesIO(_checked(item, pins)), allow_pickle=False) as z:
        require(set(z.files) == set(material) == set(bound)
                and all(array_descriptor(z[k]) == bound[k]
                        and array_descriptor(material[k]) == bound[k] for k in bound),
                "actual_training_material_matches_prefit_archive")


def _paired_view(truth, before, after):
    a, b = _gates(truth, before), _gates(truth, after)
    delta = {c: b[c]["correct"] - a[c]["correct"] for c in a}
    values = list(delta.values())
    verdict = "UP" if min(values) >= 0 and max(values) > 0 else "DOWN" if max(values) <= 0 and min(values) < 0 else "UNCHANGED" if not any(values) else "MIXED"
    gain, loss = (before != truth) & (after == truth), (before == truth) & (after != truth)
    return dict(verdict=verdict, correct_delta=delta, baseline_gates=a, candidate_gates=b,
                gain=int(gain.sum()), loss=int(loss.sum()),
                gained_by_class={c: int(np.sum(gain & (truth == k))) for c,k in (("BEN",0),("KNA",1))},
                lost_by_class={c: int(np.sum(loss & (truth == k))) for c,k in (("BEN",0),("KNA",1))})


def _paired_known_effect(output, arrays, prediction_arrays, pins):
    result, saved = {}, {}
    for role in ("CP", "CAL"):
        saved.update({role + "_ids": arrays[role + "_ids"], role + "_truth": arrays[role + "_y_coarse"],
            role + "_candidate_prediction": prediction_arrays[role + "_prediction"],
            role + "_reporting_indices": arrays[INDEX_FIELDS[role]]})
    for name, spec in PARENTS.items():
        old = json.loads(_checked(spec, pins))
        require(old.get("metrics_evaluated") is True and old.get("published") is False
                and old.get("accepted_baseline_replaced") is False, "completed_warm_parent_only:" + name)
        result[name] = {}
        for role in ("CP", "CAL"):
            if spec["kind"] == "NN":
                item, key = old["files"]["predictions"], role + "_prediction"
            else:
                require(old["selected"]["weight"] == spec["weight"], "frozen_parent_weight:" + name)
                item = old["CP_candidates" if role == "CP" else "CAL_predictions"]
                key = spec["CP_key"] if role == "CP" else "candidate_prediction"
            with np.load(io.BytesIO(_checked(item, pins)), allow_pickle=False) as z:
                require(array_descriptor(z[role + "_ids"]) == array_descriptor(arrays[role + "_ids"])
                        and array_descriptor(z[role + "_truth"]) == array_descriptor(arrays[role + "_y_coarse"]),
                        "exact_same_parent_control_IDs_truth:" + name + ":" + role)
                before = z[key].copy()
            y, after = arrays[role + "_y_coarse"], prediction_arrays[role + "_prediction"]
            require(before.dtype == np.int64 and before.shape == y.shape and np.isin(before, (0,1)).all(),
                    "parent_known_prediction_domain:" + name + ":" + role)
            indices = arrays[INDEX_FIELDS[role]]
            result[name][role] = dict(original=_paired_view(y,before,after),
                effective_reporting=_paired_view(y[indices],before[indices],after[indices]),
                same_original_IDs_and_order=True, original_rows=len(y), reporting_rows=len(indices),
                scope="warm known controls; copies are reporting only; no UNA/final evidence")
            saved[role + "_" + name + "_prediction"] = before
            saved[role + "_" + name + "_gain"] = (before != y) & (after == y)
            saved[role + "_" + name + "_loss"] = (before == y) & (after != y)
    bound = {k: array_descriptor(v) for k,v in saved.items()}
    path = output / "three_parent_same_control_paired_predictions.npz"
    np.savez_compressed(path, **saved)
    item = descriptor(path)
    with np.load(io.BytesIO(_checked(item, pins)), allow_pickle=False) as z:
        require(set(z.files) == set(saved) and all(array_descriptor(z[k]) == bound[k]
            and array_descriptor(saved[k]) == bound[k] for k in saved), "paired_archive_exact_readback")
    return result, item


def run_training(*, source_report, output_directory):
    output = Path(output_directory).resolve()
    require(output.is_relative_to(ROOT) and output != ROOT, "fresh_workspace_child_required")
    output.mkdir(parents=True, exist_ok=False)
    started, stage, pins = time.perf_counter(), "native_known_source_binding", {}
    report = {"configuration": POLICY, "status": "FAIL_TARGET99", "published": False,
              "runtime_environment": {"CUBLAS_WORKSPACE_CONFIG": os.environ.get("CUBLAS_WORKSPACE_CONFIG")},
              "final_test_executed": False, "training_started": False, "training_completed": False,
              "training_runs": 0, "metrics_evaluated": False, "DEV_executed": False,
              "known_inference_roles_started": [], "known_inference_roles_returned": [],
              "coarse_threshold_sealed": False, "CAL_inference_attempted": False, "CAL_inference_returned": False,
              "accepted_baseline_replaced": False, "EffectDelta": {"verdict": "NOT_COMPARABLE"}}
    try:
        source, arrays, records = _load_source(source_report, pins)
        for path in (Path(__file__), Path(network.__file__), Path(preprocessing.__file__), Path(numeric_geometry.__file__), ROOT / "paper_open_set/config.py"):
            pins[str(path.resolve())] = sha(path)
        stage = "FIT_only_paper_preprocessing"
        features, transforms = _prepare(arrays)
        preprocessing_path = output / "complete_FIT_preprocessing.joblib"
        joblib.dump(transforms, preprocessing_path, compress=3)
        preprocessing_artifact = descriptor(preprocessing_path)
        pins[preprocessing_artifact["path"]] = preprocessing_artifact["sha256"]
        stage = "saved_signed_log_preprocessing_roundtrip_before_training"
        roundtrip = _check_preprocessing_roundtrip(preprocessing_artifact, arrays, features, transforms, pins)
        report["preprocessing_roundtrip"] = roundtrip
        feature_path = output / "exact_known_training_inputs_before_fit.npz"
        material = {**{r + "_features": x for r, x in features.items()},
                    **{k: v for k, v in arrays.items() if not k.endswith("_native78")}}
        material_bound = {k: array_descriptor(v) for k,v in material.items()}
        np.savez_compressed(feature_path, **material)
        feature_artifact = descriptor(feature_path)
        pins[feature_artifact["path"]] = feature_artifact["sha256"]
        prefit = _write(output / "training_policy_before_fit.json", {"configuration": POLICY,
            "runtime_environment": report["runtime_environment"],
            "source_report": source_report, "source_files": source["files"], "known_inputs": feature_artifact,
            "preprocessing": preprocessing_artifact, "complete_preprocessing_roundtrip": roundtrip,
            "comparison_parents": PARENTS, "features": {r: array_descriptor(x) for r, x in features.items()},
            "selected_feature_names": transforms["selected_feature_names"], "family_order": FAMILIES,
            "input_sha256": dict(pins), "CAL_used_in_training_or_selection": False,
            "optimizer_input": array_descriptor(features["FIT"][arrays["FIT_training_indices"]]),
            "optimizer_original_indices": array_descriptor(arrays["FIT_training_indices"]),
            "CP_selection_rows": ROLES["CP"], "CP_reporting_copies_used_for_selection": False})
        pins[prefit["path"]] = prefit["sha256"]
        stage = "bind_actual_training_material_before_optimizer"
        _check_training_material(feature_artifact, material, material_bound, pins)
        stage = "one_fixed_MHFD_known_FIT_training"
        torch.set_num_threads(4)
        report["training_started"], report["training_runs"] = True, None
        result = network.train_model(features["FIT"][arrays["FIT_training_indices"]],
            arrays["FIT_y_coarse"][arrays["FIT_training_indices"]],
            arrays["FIT_y_fine"][arrays["FIT_training_indices"]],
            features["CP"], arrays["CP_y_coarse"], fine_class_count=len(FAMILIES), epochs=EPOCHS,
            seed=SEED, progress_label="CIC2 fixed-controls signed-log", checkpoint_fine_labels=arrays["CP_y_fine"])
        report.update(training_completed=True, training_runs=1, training_seconds=float(result.training_seconds),
                      selected_epoch=int(result.selected_epoch), device=result.device)
        stage = "freeze_selected_model_then_infer_known_roles"
        model_path = output / "selected_MHFD_state.pt"
        state = {k: v.detach().cpu() for k, v in result.model.state_dict().items()}
        torch.save({"state_dict": state, "input_dim": features["FIT"].shape[1], "fine_class_count": len(FAMILIES),
                    "selected_epoch": result.selected_epoch, "seed": SEED}, model_path)
        restored = torch.load(model_path, map_location="cpu", weights_only=True)
        require(set(restored["state_dict"]) == set(state)
                and all(torch.equal(v, restored["state_dict"][k]) for k, v in state.items()), "selected_model_roundtrip")
        model_artifact = descriptor(model_path)
        pins[model_artifact["path"]] = model_artifact["sha256"]
        outputs = {}
        for role in ("FIT", "CP"):
            stage = "post_training_known_inference_" + role
            report["known_inference_roles_started"].append(role)
            outputs[role] = network.infer(result.model, features[role], device=torch.device(result.device))
            report["known_inference_roles_returned"].append(role)
        stage = "freeze_coarse_threshold_from_CP"
        threshold, threshold_metrics = network.choose_coarse_threshold(arrays["CP_y_coarse"], outputs["CP"].attack_probability)
        threshold_artifact = _write(output / "coarse_threshold_from_known_CP.json", {"threshold": float(threshold),
            "selection_role": "CP", "model": model_artifact, "CP_probability": array_descriptor(outputs["CP"].attack_probability),
            "known_CP_metrics": threshold_metrics, "CAL_labels_used": False})
        pins[threshold_artifact["path"]] = threshold_artifact["sha256"]
        report["coarse_threshold_sealed"] = True
        stage = "post_threshold_CAL_known_diagnostic_inference"
        report["CAL_inference_attempted"] = True
        report["known_inference_roles_started"].append("CAL")
        outputs["CAL"] = network.infer(result.model, features["CAL"], device=torch.device(result.device))
        report["CAL_inference_returned"] = True
        report["known_inference_roles_returned"].append("CAL")
        stage = "validate_known_outputs_and_calculate_integer_gates"
        prediction_arrays, gates, reporting_gates = {}, {}, {}
        for role, values in outputs.items():
            require(values.attack_probability.shape == (ROLES[role],)
                    and np.isfinite(values.attack_probability).all()
                    and np.all((values.attack_probability >= 0) & (values.attack_probability <= 1))
                    and values.fine_probability.shape == (ROLES[role], len(FAMILIES))
                    and np.isfinite(values.fine_probability).all()
                    and values.embedding.shape[0] == ROLES[role]
                    and np.isfinite(values.embedding).all()
                    and values.reconstruction_error.shape == (ROLES[role],)
                    and np.isfinite(values.reconstruction_error).all(), "finite_known_inference_outputs:" + role)
            pred = (values.attack_probability >= threshold).astype(np.int64)
            gates[role] = _gates(arrays[role + "_y_coarse"], pred)
            report_indices = arrays[INDEX_FIELDS[role]]
            reporting_gates[role] = _gates(arrays[role + "_y_coarse"][report_indices], pred[report_indices])
            prediction_arrays.update({role + "_prediction": pred, role + "_ids": arrays[role + "_ids"],
                role + "_truth": arrays[role + "_y_coarse"], role + "_fine_truth": arrays[role + "_y_fine"],
                role + "_probability": values.attack_probability, role + "_fine_probability": values.fine_probability,
                role + "_embedding": values.embedding, role + "_reconstruction_error": values.reconstruction_error})
        prediction_path = output / "post_training_known_predictions.npz"
        np.savez_compressed(prediction_path, **prediction_arrays)
        predictions = descriptor(prediction_path)
        pins[predictions["path"]] = predictions["sha256"]
        stage = "sealed_predictions_fixed_control_EffectDelta"
        paired, paired_archive = _paired_known_effect(output, arrays, prediction_arrays, pins)
        history = _write(output / "training_history.json", result.history)
        pins[history["path"]] = history["sha256"]
        stage = "final_source_model_and_training_input_integrity"
        for path, expected in pins.items():
            require(sha(path) == expected, "pinned_input_changed_during_training:" + path)
        report.update(execution_status="native_CIC2_fixed_controls_signed_log_training_completed", metrics_evaluated=True,
            known_class_gates=gates, effective_reporting_class_gates=reporting_gates,
            paired_known_EffectDelta=paired,
            EffectDelta={r: paired["coverage_forest_blend"][r]["original"] for r in ("CP", "CAL")},
            reporting_EffectDelta={r: paired["coverage_forest_blend"][r]["effective_reporting"] for r in ("CP", "CAL")},
            EffectDelta_reference="coverage forest 4cd399 candidate; not an accepted baseline",
            density_copy_rows=0, original_role_sizes=ROLES, effective_role_sizes=EFFECTIVE_ROLES, coarse_threshold=float(threshold),
            CAL_known_diagnostic_passed=all(v["passed"] for views in (gates, reporting_gates)
                                            for v in views["CAL"].values()),
            post_training_known_inference_roles=list(outputs), training_internal_inference="FIT4200 optimization rows and CP882 original rows each epoch in existing trainer",
            files={"prefit": prefit, "preprocessing": preprocessing_artifact, "training_inputs": feature_artifact,
                   "model": model_artifact, "threshold": threshold_artifact, "predictions": predictions, "history": history,
                   "paired_three_parents": paired_archive})
    except Exception as error:
        report.update(execution_status="protocol_stop" if isinstance(error, NativeKnownTrainingStop) else "execution_failed",
                      failed_stage=stage, error_type=type(error).__name__, error_message=str(error))
    report.update(input_sha256=pins, wall_seconds=time.perf_counter() - started)
    _write(output / "report.json", report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-report", required=True)
    parser.add_argument("--source-report-sha256", required=True)
    parser.add_argument("--output-directory", required=True)
    args = parser.parse_args(argv)
    report = run_training(source_report={"path": args.source_report, "sha256": args.source_report_sha256}, output_directory=args.output_directory)
    print(json.dumps({k: report.get(k) for k in ("execution_status", "training_seconds", "selected_epoch", "known_class_gates", "failed_stage", "error_message")}, ensure_ascii=False))
    return 0 if report["metrics_evaluated"] else 2 if report["execution_status"] == "protocol_stop" else 1


if __name__ == "__main__":
    raise SystemExit(main())
