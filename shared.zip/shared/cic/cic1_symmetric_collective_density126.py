"""CIC1 relative collective-density cue -> preserved126 paper DVC."""
import argparse,json,sys,time,types
from pathlib import Path
import numpy as np
from threadpoolctl import threadpool_limits
from . import cic1_symmetric_collective_density_core_v126 as core
from . import nsl1_cic1_equalfine_RFF_candidates_v92 as old

ROOT,files,require=old.ROOT,old.files,old.require
MODULE='paper_open_set.cic1_symmetric_collective_density126_v126'
OUT=ROOT/'tmp/cic1_symmetric_collective_density126_20261012_v126'
BASE=ROOT/'data/external_dev/processed/cic1_symmetric_collective_density126_20261012_v126'
REG=OUT/'CIC1_V126_registry_before_known.json'

def policy():
    return dict(schema_version='CIC1-symmetric-genuine-knowncoarse-collective-density-ratio126-v126',hypotheses=1,
        recipe=core.recipe(),history='transfer V120; not first occupancy or density support; no CIC categorical contexts invented',
        geometry='exact original126 native78+actualprimary32+radial16, original frozen metric',
        CAL='all900 trueknown once finite99; each trueknown coarse population independently supplies its classnegative; both banks treated symmetrically',
        query='preV123 original baseline0 or1 genuinegroups within its own predicted coarse population; no truequerycoarse; both classes same fixed recipe',
        DVC='all symmetric preV123 raw candidates including preserved V123 retained2 members; matching126 SC/CH knee and hierarchical noise; no selected target noise rows',
        merge='copy full650/247/3059; all symmetric raw AND DVC-retained set2; old2 always preserved, old1 may become2; no numerator splice',
        assumptions='knownBEN local shape stable; workload changes can trigger and unknown mimicry can escape; no population coverage guarantee',
        NN_fit=0,metric_fit=0,R7_fit=0,query_fit=False,trueUNA_fit=False,parameter_grid=False,timecap_coded=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False,extension_not_verbatim_paper=True)

def closure():
    found={};seen=set();todo=[sys.modules[__name__]]
    while todo:
        m=todo.pop()
        if m is None or id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if not p or not Path(p).resolve().is_relative_to(ROOT/'paper_open_set'):continue
        found[MODULE if m is sys.modules[__name__] else m.__name__]=files.item(p)
        for v in vars(m).values():
            child=v if isinstance(v,types.ModuleType) else sys.modules.get(getattr(v,'__module__',''))
            if child is not None:todo.append(child)
    require(all(m.__name__ in found for m in (old,core)), 'actual source closure')
    return found

def freeze():
    began=time.perf_counter();pins={};a,ancestry,refs=old.metadata('CIC1',pins)
    v92ref=files.item(old.DIR/'CIC1_V92_EQUALFINE_RFF_COMPLETED_CLOSEOUT.json');v92=files.js(v92ref,pins)
    k=files.js(v92['known_report'],pins);c=files.js(v92['current_report'],pins)
    require(c['prediction_sealed'] and c['original_class_gates']['UNA']['correct']==2402, 'whole frozen2402')
    a.update(population_baseline=c['files']['complete_prediction_before_truth'],population_known_baseline=k['files']['complete_prediction_before_truth'])
    v123ref=files.item(ROOT/'tmp/cic1_collective_density_ratio126_20261012_v123/CIC1_V123_COLLECTIVE_DENSITY_3059_UP_COMPLETED_CLOSEOUT.json');v123=files.js(v123ref,pins)
    c123=files.js(v123['current_report'],pins);k123=files.js(v123['known_report'],pins)
    require(c123['prediction_sealed'] and c123['original_class_gates']['UNA']['correct']==3059,'preserved whole3059')
    a.update(baseline=c123['files']['complete_prediction_before_truth'],known_baseline=k123['files']['complete_prediction_before_truth'])
    src=closure()
    for d in [*a.values(),*src.values()]:files.read(d,pins)
    require(not REG.exists() and not BASE.exists(), 'fresh single126 ratio recipe')
    OUT.mkdir(parents=True,exist_ok=True)
    return files.write(REG,dict(policy=policy(),assets=a,sources=src,input_sha256=pins,ancestry_seconds=ancestry,
        previous_retained_closeout=v92ref,necessary_ancestry_seconds=v123['timing_seconds']['conservative_allprep_plus_ancestry'],
        freeze_seconds=time.perf_counter()-began,current_numeric_decodes=0))

def bind(desc,pins):
    r=files.js(desc,pins);require(r['policy']==policy() and r['sources']==closure(),'frozen sources and exact recipe')
    for p,h in r['input_sha256'].items():files.read(dict(path=p,sha256=h),pins)
    return r

def save(out,r,key,value):return old.save(out,r,key,value)

def run(phase,desc,known_desc=None):
    began=time.perf_counter();pins={};reg=bind(desc,pins);control=None
    if phase=='current':
        control=files.js(known_desc,pins)
        require(control['known_gate_passed'] and control['prediction_sealed'] and control['registry']==desc,'known exact99 before current')
    out=BASE/phase;out.mkdir(parents=True,exist_ok=False)
    r=dict(policy=policy(),phase=phase,registry=desc,files={},NN_fit=0,metric_fit=0,R7_fit=0,CAL_fit=0,
        current_numeric_decodes=0,prediction_sealed=False,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        with threadpool_limits(limits=4):
            a=reg['assets'];payload=files.js(a['metric'],pins)
            metric=old.cic.learned.PaperVariationalPairMetric.from_state(payload['metric_payload'])
            require(metric.dimension==126,'actual original126 distance owner');r['files']['metric']=a['metric']
            if phase=='known':
                mat=old.archive(a['material'],('FIT_ids','FIT_groups','FIT_fine','FIT_Z126','CAL_ids','CAL_groups','CAL_Z126','CAL_stage1'),pins)
                lab=old.archive(a['native_known'],('FIT_ids','FIT_y_fine','CAL_ids','CAL_y_coarse'),pins)
                require(len(mat['FIT_ids'])==6000==len(np.unique(mat['FIT_groups'])) and np.bincount(mat['FIT_fine'],minlength=9).min()>=20 and
                    np.array_equal(mat['FIT_ids'],lab['FIT_ids']) and np.array_equal(mat['FIT_fine'],lab['FIT_y_fine']) and np.array_equal(mat['CAL_ids'],lab['CAL_ids']), 'genuine known FIT and CAL')
                reference={}
                scores=np.zeros(len(mat['CAL_ids']))
                for coarse in (0,1):
                    b=(mat['FIT_fine']!=0)==bool(coarse)
                    background=dict(Z126=mat['FIT_Z126'][b],groups=mat['FIT_groups'][b],ids=mat['FIT_ids'][b])
                    reference[coarse]=background
                    r['files']['reference'+str(coarse)]=save(out,r,'trueknown'+str(coarse)+'_genuineFIT_reference_before_CAL',background)
                    active=(lab['CAL_y_coarse']==coarse)&(mat['CAL_stage1']==coarse)
                    cue=core.infer(metric,mat['CAL_Z126'],mat['CAL_groups'],active,background['Z126'],background['groups'])
                    scores[active]=cue['score'][active]
                    save(out,r,'alltrueknown_CAL900_bank'+str(coarse)+'_population_before_cut',dict(ids=mat['CAL_ids'],truecoarse=lab['CAL_y_coarse'],**cue))
                save(out,r,'alltrueknown_CAL900_joint_scores_before_cut',dict(ids=mat['CAL_ids'],truecoarse=lab['CAL_y_coarse'],score=scores))
                rule=old.cic.dvc.calibrate_known_cutoffs(scores,lab['CAL_y_coarse']);r['CAL_fit']=1
                r['files']['rule']=files.write(out/'alltrueknown_once_finite99.json',rule)
            else:
                reference={coarse:old.archive(control['files']['reference'+str(coarse)],('Z126','groups','ids'),pins) for coarse in (0,1)}
                rule=files.js(control['files']['rule'],pins)
                r['files'].update({key:control['files'][key] for key in ('reference0','reference1','rule')});r['known_report']=known_desc
            q,baseline,_=old.query('CIC1',phase,a,pins);r['current_numeric_decodes']=len(q['ids']) if phase=='current' else 0
            population=old.archive(a['population_known_baseline' if phase=='known' else 'population_baseline'],('ids','prediction'),pins)
            require(np.array_equal(population['ids'],q['ids']),'whole original preV123 population IDs')
            score_start=time.perf_counter();scores=np.zeros(len(q['ids']));eligible=np.zeros(len(q['ids']),bool)
            for coarse in (0,1):
                background=reference[coarse];active=population['prediction']==coarse
                cue=core.infer(metric,q['Z126'],q['groups'],active,background['Z126'],background['groups'])
                scores[active]=cue['score'][active];eligible[active]=cue['eligible'][active]
                save(out,r,'complete_original126_bank'+str(coarse)+'_population_before_DVC',dict(ids=q['ids'],Z126=q['Z126'],groups=q['groups'],stage1=q['stage1'],**cue))
            r['query_score_seconds']=time.perf_counter()-score_start
            raw=(population['prediction']!=2)&eligible&old.cic.dvc.candidate_mask(scores,q['stage1'],rule)
            save(out,r,'complete_original126_symmetric_candidates_before_DVC',dict(ids=q['ids'],score=scores,eligible=eligible,raw=raw,population_prediction=population['prediction'],baseline=baseline))
            route=old.cic.dvc.route_current_candidates(metric,q['Z126'],raw,seed=20261012)
            save(out,r,'original126_rawonly_DVC_before_truth',{k:v for k,v in route.items() if k!='manifest'})
            r['files']['DVC_manifest']=files.write(out/'original126_rawonly_DVC_manifest.json',route['manifest'])
            retained=raw&route['retained'];pred=baseline.copy();pred[retained]=2
            v=dict(ids=q['ids'],prediction=pred,baseline=baseline,raw=raw,retained=retained)
            sealed=save(out,r,'complete_prediction_before_truth',v)
            r['files']['seal']=files.write(out/'prediction_seal_before_truth.json',dict(predictions=sealed,registry=desc,metric=a['metric'],rule=r['files']['rule'],reference0=r['files']['reference0'],reference1=r['files']['reference1'],truth_used=False));r['prediction_sealed']=True
            if phase=='known':y=old.archive(a['known_truth'],('CP_truth',),pins)['CP_truth']
            else:
                truth=old.archive(a['truth'],('ids','truth'),pins);require(np.array_equal(truth['ids'],q['ids']),'same current truth only after seal');y=truth['truth']
            gates,delta,binary=old.helpers.metrics(y,baseline,pred)
            r.update(execution_status='CIC1_collective_density_ratio126_'+phase+'_completed',original_class_gates=gates,
                EffectDelta=delta,binary_attack_detection=binary,known_gate_passed=all(gates[n]['passed'] for n in ('BEN','KNA')),
                candidate_accepted_for_retention=phase=='current' and all(gates[n]['passed'] for n in ('BEN','KNA')) and delta['correct_count_delta']['UNA']>0,
                raw_by_trueclass={n:int(((y==c)&raw).sum()) for c,n in enumerate(('BEN','KNA','UNA'))})
            save(out,r,'postseal_paired_comparison',dict(**v,truth=y))
            if phase=='current':r['perfect_raw_UNA_ceiling']=int(((y==2)&((baseline==2)|raw)).sum())
    except Exception as e:r.update(execution_status='execution_failed',error_type=type(e).__name__,error=str(e));raise
    finally:r.update(input_sha256=pins,wall_seconds=time.perf_counter()-began);files.write(out/'report.json',r)
    return files.item(out/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('freeze','known','current'),required=True)
    for n in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+n)
    args=p.parse_args();desc=None if not args.registry else dict(path=str(Path(args.registry).resolve()),sha256=args.registry_sha256)
    known=None if not args.known_report else dict(path=str(Path(args.known_report).resolve()),sha256=args.known_sha256)
    print(json.dumps(freeze() if args.phase=='freeze' else run(args.phase,desc,known)))
