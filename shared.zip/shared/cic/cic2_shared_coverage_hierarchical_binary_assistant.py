"""One shared-pool, known-only fine-balanced binary assistant for CIC2.

Retain the original primary's coverage4187 FIT groups and append the frozen
1800 genuine groups. The primary and assistant together use5987 originals
and13 optimizer copies. This changes the prior warm training composition
and its weight allocation jointly. The binary target, forest parameters and
quarter contribution remain fixed. No current/unknown records are opened.
"""
from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path
import time

import joblib
import numpy as np
from sklearn.ensemble import ExtraTreesClassifier

from . import cic2_known6000_binary_assistant_v1 as previous
from . import cic_fit6000_mhfd_training_v1 as helpers

ROOT = helpers.ROOT
OUT = ROOT / "data/external_dev/processed/cic2_shared_coverage_hierarchical_binary_assistant_20261010_v2"
REGISTRY_OUT = ROOT / "tmp/cic2_shared_coverage_hierarchical_binary_assistant_20261010_v2"
SCHEMA = "CIC2-shared-coverage-FIT6000-hierarchical-binary-native78-v2"
ORIGINAL_ASSISTANT_SHA256 = "8be2345104f99594b40d18f75b40458b07af002fb8b5f3f58f7032cdb06840ee"
FAMILIES = ("BEN", "FTP-Patator", "SSH-Patator", "PortScan", "DDoS", "Heartbleed", "DoS Slowhttptest", "DoS Hulk", "Bot")
PARAMETERS = dict(previous.PARAMETERS)
PRIOR = dict(path=str(previous.OUT / "report.json"), sha256="0367f191c67209a75a9ca5a977fc33e73cae4cda35651cfdda7df728bef77948")
STRONG = dict(path="data/external_dev/processed/cic2017_setting2_signed_log_cached_blend_20261008_v1/CIC_Setting2/report.json",
              sha256="4286abcff8d7805e44af2d3450d8891ecdd2d43a5fa7d25ab6bd0efec17bb36d")


def policy():
    return dict(schema_version=SCHEMA, setting="CIC Setting2", hypotheses=1,
        forest_parameters=PARAMETERS, forest_target="BEN0/KNA1",
        sample_weight="6000 * .5/count(BEN); 6000 * .5/(8*count(fine)) for each known attack fine, over optimizer indices",
        family_order=FAMILIES, FIT_original=5987, FIT_copies=13, FIT_optimizer=6000,
        CP_original=882, CAL_original=882, controls_reporting_rows=900,
        input="unchanged complete original native78 float32; no clipping or selection",
        blend=".75 frozen original signedlog NN mixed probability + .25 new binary forest KNA probability",
        threshold="exactly one CAL originals choose_coarse_threshold call; CP does not tune weights or threshold",
        intervention="shared coverage4187 plus1800 pool retains rare-family diversity; fine-balanced binary target, joint source and weight change",
        old_model_weights_modified=False, fine_heads_retained=True,
        unknown_reads=0, query_entry=False, NN_fit=0, NN_forward=0,
        warm_known_controls=True, independent_final_claimed=False,
        accepted_baseline_replaced=False, status="FAIL_TARGET99", published=False, final_test_executed=False)


def source_bindings():
    helpers.require(helpers.sha(previous.__file__) == ORIGINAL_ASSISTANT_SHA256, "preceding_binary_assistant_source_preserved")
    modules = (Path(__file__), Path(previous.__file__), Path(helpers.__file__),
               Path(helpers.header_tools.__file__), Path(helpers.network.__file__),
               Path(previous.primary.__file__))
    return {str(p.resolve()): helpers.sha(p) for p in modules}


def hierarchical_binary_weights(fine, coarse):
    """Return mean-one weights, without any CAL/CP or record identifiers."""
    fine, coarse = np.asarray(fine), np.asarray(coarse)
    helpers.require(fine.ndim == 1 and fine.shape == coarse.shape
        and fine.dtype == coarse.dtype == np.int64
        and np.array_equal(coarse, (fine != 0).astype(np.int64)), "true_known_fine_coarse_alignment")
    count = Counter(fine.tolist())
    helpers.require(set(count) == set(range(9)), "all_nine_declared_true_known_families")
    mass = {0: .5, **{k: .5 / 8 for k in range(1, 9)}}
    weight = np.asarray([len(fine) * mass[int(k)] / count[int(k)] for k in fine], np.float64)
    helpers.require(np.isfinite(weight).all() and np.all(weight > 0)
        and np.isclose(weight.sum(), len(fine), rtol=0, atol=1e-8), "known_only_mean_one_weight")
    for label in range(9):
        helpers.require(np.isclose(weight[fine == label].sum() / len(fine), mass[label], rtol=0, atol=1e-12),
                        "exact_fixed_family_supervision_mass:" + str(label))
    return weight


def load(asset, keys, pins):
    with np.load(helpers.checked(asset, pins), allow_pickle=False) as values:
        return {k: values[k].copy() for k in keys}


def save(out, name, values, report):
    item = helpers.npz_new(out / (name + ".npz"), values, {})
    report["files"][name] = item
    return item


def freeze():
    """JSON, array headers and FIT labels/index metadata only; no features."""
    pins = {}
    material = helpers.read({'path': 'F:\\shenpeng\\Experiments\\Chinese Science\\data\\external_dev\\processed\\cic2_shared_coverage_FIT6000_20261010_v1\\report.json', 'sha256': '82010b9b4c47834e9d5dd7ae27d5cd82b7c91a3f5be4c54b64de617f3b83ac06'}, pins)
    nn = helpers.read(previous.NN, pins)
    prior = helpers.read(PRIOR, pins)
    strong = helpers.read(STRONG, pins)
    native, cached = material["source_arrays"], nn["files"]["predictions"]
    headers = helpers.header_tools.npz_headers(helpers.checked(native, pins))
    for role, n in (("FIT", 5987), ("CAL", 882), ("CP", 882)):
        helpers.require(headers[role + "_native78"]["shape"] == [n, 78]
            and headers[role + "_ids"]["shape"] == [n]
            and headers[role + "_y_fine"]["shape"] == [n]
            and headers[role + "_y_coarse"]["shape"] == [n], "actual_complete_native_role_headers:" + role)
    cache_headers = helpers.header_tools.npz_headers(helpers.checked(cached, pins))
    for role in ("CAL", "CP"):
        helpers.require(cache_headers[role + "_probability"]["shape"] == [882], "actual_original_NN_cached_probability_header:" + role)
    meta = load(native, ("FIT_y_fine", "FIT_y_coarse", "FIT_training_indices"), pins)
    index, fine, coarse = meta["FIT_training_indices"], meta["FIT_y_fine"], meta["FIT_y_coarse"]
    helpers.require(index.dtype == np.int64 and index.shape == (6000,)
        and np.all((index >= 0) & (index < 5987))
        and helpers.ad(index) == material['bound']['FIT_training_indices'], "unchanged_fixed6000_optimizer_map")
    repetitions = np.bincount(index, minlength=5987)
    helpers.require(np.all(repetitions >= 1) and int((repetitions - 1).sum()) == 13
        and np.all(fine[repetitions > 1] == FAMILIES.index('Heartbleed')),
        'all_real_originals_once_plus_only13_registered_Heart_optimizer_copies')
    weights = hierarchical_binary_weights(fine[index], coarse[index])
    helpers.require(prior["policy"]["forest_parameters"] == PARAMETERS
        and prior["policy"]["FIT_optimizer"] == 6000 and not prior["both_controls_integer99_passed"], "exact_failed_previous_recipe")
    for item in (prior["files"]["fixed_known_predictions_before_CP_truth"], strong["files"]["paired"]):
        helpers.checked(item, pins)
    prior_headers = helpers.header_tools.npz_headers(helpers.checked(prior["files"]["fixed_known_predictions_before_CP_truth"], pins))
    strong_headers = helpers.header_tools.npz_headers(helpers.checked(strong["files"]["paired"], pins))
    for role in ("CAL", "CP"):
        for suffix in ("ids", "prediction"):
            helpers.require(prior_headers[role + "_" + suffix]["shape"] == [882], "actual_previous_prediction_member:" + role + suffix)
        for suffix in ("ids", "truth", "candidate"):
            helpers.require(strong_headers[role + "_" + suffix]["shape"] == [882], "actual_strong_prediction_member:" + role + suffix)
    bindings = source_bindings()
    for path, sha in bindings.items(): helpers.checked(dict(path=path, sha256=sha), pins)
    reg = dict(schema_version=SCHEMA + "-registry", policy=policy(), material={'path': 'F:\\shenpeng\\Experiments\\Chinese Science\\data\\external_dev\\processed\\cic2_shared_coverage_FIT6000_20261010_v1\\report.json', 'sha256': '82010b9b4c47834e9d5dd7ae27d5cd82b7c91a3f5be4c54b64de617f3b83ac06'},
        primary_NN=previous.NN, native=native, primary_cached=cached, previous=PRIOR, strong=STRONG,
        prior_predictions=prior["files"]["fixed_known_predictions_before_CP_truth"],
        strong_predictions=strong["files"]["paired"], source_bindings=bindings,
        FIT_original_fine_counts={str(k): int(v) for k, v in Counter(fine.tolist()).items()},
        FIT_optimizer_fine_counts={str(k): int(v) for k, v in Counter(fine[index].tolist()).items()},
        FIT_family_weight_mass={str(k): float(weights[fine[index] == k].sum() / 6000) for k in range(9)},
        input_sha256=pins, output=str(OUT), cached_probability_decodes=0,
        numeric_feature_decodes=0, unknown_reads=0, status="FAIL_TARGET99", published=False, final_test_executed=False)
    REGISTRY_OUT.mkdir(exist_ok=False)
    return helpers.json_new(REGISTRY_OUT / "registry_before_hierarchical_binary_FIT.json", reg)


def run(path, sha):
    report = dict(schema_version=SCHEMA, policy=policy(), files={}, forest_fit=0,
        forest_forward_roles=[], CAL_threshold_fit=0, prediction_sealed=False,
        CP_truth_opened=False, prior_predictions_opened=False, NN_fit=0, NN_forward=0,
        unknown_reads=0, query_fit=0, accepted_baseline_replaced=False,
        status="FAIL_TARGET99", published=False, final_test_executed=False)
    pins, began, stage = {}, time.perf_counter(), "bind_frozen_recipe_and_sources"
    registry = dict(path=str(Path(path).resolve()), sha256=sha)
    helpers.require(not OUT.exists(), "fresh_once_only_hierarchical_binary_output")
    OUT.mkdir(parents=True)
    try:
        reg = helpers.read(registry, pins)
        helpers.require(reg["policy"] == json.loads(json.dumps(policy()))
            and reg["source_bindings"] == source_bindings() and reg["output"] == str(OUT), "frozen_hierarchical_binary_recipe_source_and_destination")
        for p, wanted in reg["input_sha256"].items(): helpers.checked(dict(path=p, sha256=wanted), pins)
        stage = "load_fixed_FIT_features_labels_and_unlabelled_known_controls"
        fields = load(reg["native"], ("FIT_native78", "FIT_y_fine", "FIT_y_coarse", "FIT_training_indices", "FIT_ids",
            "CAL_native78", "CAL_ids", "CAL_reporting_indices", "CP_native78", "CP_ids", "CP_reporting_indices"), pins)
        original = load(reg["primary_cached"], ("CAL_ids", "CAL_probability", "CP_ids", "CP_probability"), pins)
        all_ids = np.concatenate([fields[r + "_ids"] for r in ("FIT", "CAL", "CP")])
        helpers.require(len(np.unique(all_ids)) == 7751, "same_known_roles_have_distinct_original_IDs")
        for role in ("CAL", "CP"):
            helpers.require(np.array_equal(fields[role + "_ids"], original[role + "_ids"]), "same_fixed_original_NN_ID_order:" + role)
        index = fields["FIT_training_indices"]
        x = np.ascontiguousarray(fields["FIT_native78"], np.float32)
        y, fine = fields["FIT_y_coarse"], fields["FIT_y_fine"]
        helpers.require(x.shape == (5987, 78) and index.shape == (6000,) and np.isfinite(x).all(), "full_fixed6000_known_only_optimizer_inputs")
        weight = hierarchical_binary_weights(fine[index], y[index])
        helpers.require({str(k): int(v) for k, v in Counter(fine[index].tolist()).items()} == reg["FIT_optimizer_fine_counts"], "same_FIT_optimizer_family_counts")
        weights = save(OUT, "FIT_training_weights_before_forest_fit", dict(indices=index, fine=fine[index], coarse=y[index], sample_weight=weight), report)
        report["files"]["prefit"] = helpers.json_new(OUT / "recipe_before_hierarchical_binary_fit.json",
            dict(policy=policy(), sample_weights=weights, material=reg["native"], primary_cached=reg["primary_cached"],
                 source_bindings=reg["source_bindings"], CAL_truth_used_for_weights=False, CP_truth_opened=False))
        stage = "one_known_FIT_binary_forest_fit_with_fixed_hierarchical_fine_weights"
        forest = ExtraTreesClassifier(**PARAMETERS, class_weight=None)
        started = time.perf_counter()
        forest.fit(x[index], y[index], sample_weight=weight)
        report["forest_fit"] = 1
        report["training_seconds"] = time.perf_counter() - started
        model_path = OUT / "known_only_finebalanced_binary_native78_ExtraTrees512.joblib"
        joblib.dump(forest, model_path)
        report["files"]["model"] = helpers.descriptor(model_path)
        stage = "one_CAL_probability_before_CAL_threshold"
        cal_tree = previous.binary_probability(forest, np.ascontiguousarray(fields["CAL_native78"], np.float32))
        report["forest_forward_roles"].append("CAL")
        cal = .75 * original["CAL_probability"].astype(np.float64) + .25 * cal_tree
        save(OUT, "CAL_original_probabilities_before_threshold", dict(ids=fields["CAL_ids"], probability=cal, tree=cal_tree), report)
        cal_truth = load(reg["native"], ("CAL_y_coarse",), pins)["CAL_y_coarse"]
        theta, metrics = helpers.network.choose_coarse_threshold(cal_truth, cal)
        report["CAL_threshold_fit"] = 1
        report["files"]["threshold"] = helpers.json_new(OUT / "CAL_once_theta_before_CP.json",
            dict(threshold=float(theta), metrics=metrics, source_role="CAL_original882", CP_truth_used=False, weight_or_threshold_sweep=False))
        stage = "one_CP_probability_and_complete_prediction_seal_before_CP_truth"
        cp_tree = previous.binary_probability(forest, np.ascontiguousarray(fields["CP_native78"], np.float32))
        report["forest_forward_roles"].append("CP")
        cp = .75 * original["CP_probability"].astype(np.float64) + .25 * cp_tree
        save(OUT, "CP_original_probabilities_before_truth", dict(ids=fields["CP_ids"], probability=cp, tree=cp_tree), report)
        predictions = dict(CAL_prediction=(cal >= theta).astype(np.int64), CP_prediction=(cp >= theta).astype(np.int64),
                           CAL_ids=fields["CAL_ids"], CP_ids=fields["CP_ids"])
        predicted = save(OUT, "fixed_known_predictions_before_CP_truth_and_prior", predictions, report)
        report["files"]["prediction_seal"] = helpers.json_new(OUT / "known_prediction_seal_before_CP_truth_and_prior.json",
            dict(predictions=predicted, CP_probability=report["files"]["CP_original_probabilities_before_truth"],
                 CAL_probability=report["files"]["CAL_original_probabilities_before_threshold"], model=report["files"]["model"],
                 threshold=report["files"]["threshold"], CP_truth_used=False, prior_predictions_used=False))
        report["prediction_sealed"] = True
        stage = "sealed_known_gate_evaluation_and_saved_prior_comparison"
        cp_truth = load(reg["native"], ("CP_y_coarse",), pins)["CP_y_coarse"]
        report["CP_truth_opened"] = True
        truth = dict(CAL=cal_truth, CP=cp_truth)
        prior = load(reg["prior_predictions"], tuple(r + "_" + k for r in ("CAL", "CP") for k in ("ids", "prediction")), pins)
        strong = load(reg["strong_predictions"], tuple(r + "_" + k for r in ("CAL", "CP") for k in ("ids", "truth", "candidate")), pins)
        report["prior_predictions_opened"] = True
        gates, reporting, effects = {}, {}, {"preceding_binary_assistant": {}, "original_strong_primary": {}}
        paired = {}
        for role in ("CAL", "CP"):
            pred, idx = predictions[role + "_prediction"], fields[role + "_reporting_indices"]
            helpers.require(np.array_equal(fields[role + "_ids"], prior[role + "_ids"])
                and np.array_equal(fields[role + "_ids"], strong[role + "_ids"])
                and np.array_equal(truth[role], strong[role + "_truth"]), "postseal_same_known_ID_truth_order:" + role)
            gates[role] = helpers.gates(truth[role], pred)
            reporting[role] = helpers.gates(truth[role][idx], pred[idx])
            effects["preceding_binary_assistant"][role] = helpers.paired(truth[role], prior[role + "_prediction"], pred)
            effects["original_strong_primary"][role] = helpers.paired(truth[role], strong[role + "_candidate"], pred)
            paired.update({role + "_ids": fields[role + "_ids"], role + "_truth": truth[role], role + "_candidate": pred,
                           role + "_preceding_binary": prior[role + "_prediction"], role + "_strong_primary": strong[role + "_candidate"]})
        save(OUT, "postseal_same_known_paired_predictions", paired, report)
        for p, wanted in pins.items(): helpers.require(helpers.sha(p) == wanted, "hierarchical_binary_input_pin_unchanged:" + p)
        report.update(execution_status="hierarchical_binary_native78_assistant_known_controls_evaluated", known_gates=gates,
            effective_reporting_gates=reporting, EffectDelta=effects, coarse_threshold=float(theta),
            both_controls_integer99_passed=all(v["passed"] for g in gates.values() for v in g.values()),
            unknown_phase_allowed=False, unknown_phase_requires_new_main_CAL_distance_alignment=True)
    except Exception as error:
        report.update(execution_status="execution_failed", failed_stage=stage, error_type=type(error).__name__, error=str(error))
        raise
    finally:
        report.update(registry=registry, input_sha256=pins, wall_seconds=time.perf_counter() - began)
        helpers.json_new(OUT / "report.json", report)
    return helpers.descriptor(OUT / "report.json")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=("freeze", "known"), required=True)
    parser.add_argument("--registry")
    parser.add_argument("--registry-sha256")
    args = parser.parse_args()
    item = freeze() if args.phase == "freeze" else run(args.registry, args.registry_sha256)
    print(json.dumps(item, ensure_ascii=False))


if __name__ == "__main__": main()
