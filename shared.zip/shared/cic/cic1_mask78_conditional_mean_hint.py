"""Known-only, fixed predicted-fine normalized masked-field dependence hint.

Existing unique FIT clean reconstruction outputs set per-known-fine field units.
Existing CAL/CP complete masked-field errors provide the predictive dependence
measure. These are different producer views and are explicitly kept distinct.
Only original CAL fixes one finite99 cutoff per frozen predicted coarse class.
No current/unknown entry is provided by this known-control source.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import numpy as np

from . import cic1_mask78_predictive_increment_v1 as prior

trained, context, files, ROOT = prior.trained, prior.context, prior.files, prior.ROOT
BASE = ROOT / 'data/external_dev/processed/cic1_mask78_conditional_mean_hint_20261011_v1'
SCHEMA = 'CIC1-preserved799-FIT-fine-units-mean78-mask-dependence-known-control-v1'
TRAIN = dict(path=str(trained.BASE / 'report.json'),
             sha256='7b5b0c052b4fc16aec4e944acc6c7f11d0725ec2785f1ffc9a2462a5be7a7106')
MASK_KNOWN = dict(path=str(prior.BASE / 'known/report.json'),
                  sha256='97c1dc1c15324855ad72c2d84ac831752f752347161af4066454293e76715664')
GEOMETRY = prior.GEOMETRY


def policy():
    return dict(schema_version=SCHEMA, setting='CIC Setting1',
        scope='same observed warm development original CP900; no independent final claim',
        original_unique_FIT=6000, original_CAL=900, full_known_CP=900,
        fields='all original78; no feature selection',
        field_units='1 + per-true-fine uniqueFIT mean squared clean reconstruction residual in frozen normalized native78 coordinates',
        FIT_view='existing final80 maskaux network CLEAN full78 raw reconstruction; not masked errors',
        predictive_view='existing complete78 independently masked-field squared errors on original CAL900/CP900',
        selector='frozen ORIGINAL primary predicted_fine for every CAL/CP row; FIT true known fine only in unit fit',
        score='arithmetic mean of all78 masked-field squared errors divided by predicted-fine FIT field units',
        cutoff='one original CAL predicted-coarse finite99 order statistic; strict greater; no sweep',
        second_stage='same frozen learned110 metric, DVC, affinity, reconstruction and noise',
        merge='copy preserved799 known predictions; only this raw AND this current DVC retained becomes UNA',
        gate='complete original CP900 BEN/KNA integer99 and paired zero correct-known loss',
        train_union_unique_rows=6000, optimizer_training_runs=0,
        CP_or_query_units_or_cutoff_fit=False, unknown_values_opened=False,
        current_entry_available=False, accepted_baseline_replaced=False,
        status='FAIL_TARGET99', published=False, final_test_executed=False)


def selected(ref, keys, pins):
    return context.selected(ref, keys, pins)


def conditional_units(clean_reconstruction, FIT_input, true_fine):
    reconstruction = np.asarray(clean_reconstruction, np.float64)
    original = np.asarray(FIT_input, np.float64)
    fine = np.asarray(true_fine)
    files.require(reconstruction.shape == original.shape == (6000, 78)
        and fine.shape == (6000,) and fine.dtype.kind in 'iu'
        and np.isin(fine, range(9)).all()
        and np.isfinite(reconstruction).all() and np.isfinite(original).all(),
        'only complete finite uniqueFIT clean reconstruction and known fine')
    error = np.square(reconstruction-original)
    units = np.empty((9, 78), np.float64)
    support = {}
    for fine_code in range(9):
        rows = fine == fine_code
        support[str(fine_code)] = int(rows.sum())
        files.require(support[str(fine_code)] >= 20, 'genuine FIT fine support at least20')
        units[fine_code] = 1. + np.mean(error[rows], axis=0)
    files.require(np.isfinite(units).all() and np.all(units >= 1.), 'finite stable FIT units')
    return units, support, error


def score_error(masked_field_error, predicted_fine, units):
    error = np.asarray(masked_field_error, np.float64)
    selector = np.asarray(predicted_fine)
    unit = np.asarray(units, np.float64)
    files.require(error.ndim == 2 and error.shape[1] == 78
        and selector.shape == (len(error),) and selector.dtype.kind in 'iu'
        and np.isin(selector, range(9)).all() and unit.shape == (9, 78)
        and np.isfinite(error).all() and np.all(error >= 0)
        and np.isfinite(unit).all() and np.all(unit >= 1.),
        'complete finite masked errors and original predicted-fine selector')
    score = np.mean(error/unit[selector], axis=1)
    files.require(np.isfinite(score).all(), 'finite fixed mean78 conditional score')
    return score


def freeze():
    pins = {}
    train = files.js(TRAIN, pins)
    old = files.js(MASK_KNOWN, pins)
    geometry = files.js(GEOMETRY, pins)
    prior_registry = files.js(old['registry'], pins)
    files.require(train['epochs_completed'] == 80 and train['unknown_values_opened'] is False,
        'exact actual known-only final80 producer')
    files.require(old['phase'] == 'known' and old['prediction_sealed']
        and prior_registry['assets']['known110'] == geometry['known110']
        and old['baseline_class_gates']['BEN']['correct'] == 650
        and old['baseline_class_gates']['KNA']['correct'] == 247,
        'same full900 preserved799 known control identity')
    assets = dict(known110=geometry['known110'],
        mask_model=train['files']['model'],
        FIT_clean_output=train['files']['FIT_complete_all7_raw5_before_caller_guard'],
        known78_inputs=train['files']['known78_inputs_before_training'],
        CAL_masked_error=old['files']['CAL900_all_masked_field_errors'],
        CP_masked_error=old['files']['known_all_masked_field_errors'],
        preserved_known_seal=old['files']['prediction_seal'],
        preserved_known_prediction=old['files']['complete_increment_before_truth'],
        owned_metric=geometry['owned_metric'])
    for asset in assets.values():
        files.read(asset, pins)
    sources = {Path(module.__file__).name: files.item(module.__file__)
        for module in (prior, trained, trained.core, trained.core.previous,
            context, context.geometry, context.geometry.dvc, context.bridge.learned)}
    registry = dict(schema_version=SCHEMA+'-registry-before-known-unit-fit',
        policy=policy(), source=files.item(__file__), sources=sources,
        producer_report=TRAIN, previous_masked_known_report=MASK_KNOWN,
        geometry_registry=GEOMETRY, assets=assets,
        model_state_sha256=train['model_state_sha256'],
        prior_mask_registry=old['registry'], output_directory=str(BASE),
        input_sha256=pins, numeric_values_decoded=0, unknown_values_opened=False,
        status='FAIL_TARGET99', published=False, final_test_executed=False)
    out = ROOT/'tmp/cic1_mask78_conditional_mean_hint_20261011_v1'
    out.mkdir(exist_ok=False)
    return files.write(out/'registry_before_known_conditional_unit_fit.json', registry)


def known(path, sha):
    pins = {}
    ref = dict(path=str(Path(path).resolve()), sha256=sha)
    reg = files.js(ref, pins)
    files.require(reg['policy'] == policy() and reg['source'] == files.item(__file__),
        'fixed new conditional mean source before originalCP')
    for asset in reg['sources'].values():
        files.read(asset, pins)
    out = Path(reg['output_directory'])/'known'
    out.mkdir(parents=True, exist_ok=False)
    began = time.perf_counter()
    report = dict(schema_version=SCHEMA, phase='known', registry=ref,
        policy=policy(), files={}, DVC_calls=0, FIT_unit_fits=0,
        CAL_cutoff_fits=0, optimizer_training_runs=0, model_loads=0,
        masked_forward_calls=0, CUDA_calls=0, metric_fit=0,
        CP_units_or_cutoff_fits=0, current_unknown_numeric_decodes=0,
        unknown_values_opened=False, prediction_sealed=False, truth_opened=False,
        accepted_baseline_replaced=False, status='FAIL_TARGET99',
        published=False, final_test_executed=False)
    try:
        fields = selected(reg['assets']['known110'],
            ('FIT_ids','FIT_groups','FIT_fine') + tuple(role+'_'+key
                for role in ('CAL','CP')
                for key in ('ids','groups','Z110','stage1','predicted_fine')), pins)
        inputs = selected(reg['assets']['known78_inputs'],
            tuple(role+'_'+key for role in ('FIT','CAL','CP')
                for key in ('features','ids')), pins)
        files.require(len(set(fields['FIT_groups'].tolist())) == 6000,
            'only genuine unique6000 FIT groups; no training copies in units')
        group_sets = {role: set(fields[role+'_groups'].tolist())
            for role in ('FIT','CAL','CP')}
        files.require(all(not group_sets[a].intersection(group_sets[b])
            for a,b in (('FIT','CAL'),('FIT','CP'),('CAL','CP'))),
            'FIT CAL CP original groups disjoint')
        for role in ('FIT','CAL','CP'):
            files.require(np.array_equal(fields[role+'_ids'], inputs[role+'_ids']),
                'same mask producer original role IDs and order')
        for role in ('CAL','CP'):
            files.require(np.array_equal(fields[role+'_Z110'][:,:78].astype(np.float32),
                inputs[role+'_features']), 'identical existing masked native78 inputs')
        fit = selected(reg['assets']['FIT_clean_output'], ('raw_reconstruction',), pins)
        units, support, fit_error = conditional_units(fit['raw_reconstruction'],
            inputs['FIT_features'], fields['FIT_fine'])
        report['FIT_unit_fits'] = 1
        source = trained.core.previous.save(out, 'FIT_clean_residuals_and_field_units_before_CAL',
            dict(ids=fields['FIT_ids'], groups=fields['FIT_groups'], fine=fields['FIT_fine'],
                clean_error=fit_error, field_units=units), report)
        report['files']['conditional_units'] = files.write(out/'FIT_conditional_units_before_CAL.json',
            dict(units=units.tolist(), true_unique_FIT_fine_support=support,
                source=source, CP_used=False, unknown_used=False,
                FIT_reconstruction_view='clean; not independently masked'))
        cal_error = selected(reg['assets']['CAL_masked_error'], ('error',), pins)['error']
        files.require(cal_error.shape == (900,78), 'complete originalCAL900 masked errors')
        cal_score = score_error(cal_error, fields['CAL_predicted_fine'], units)
        cal_source = trained.core.previous.save(out, 'CAL_scores_before_original_CP',
            dict(ids=fields['CAL_ids'], score=cal_score, stage1=fields['CAL_stage1'],
                predicted_fine=fields['CAL_predicted_fine']), report)
        cutoffs = context.geometry.dvc.calibrate_known_cutoffs(cal_score, fields['CAL_stage1'])
        files.require(all(node['enabled'] for node in cutoffs.values()),
            'finite originalCAL coarse99 cutoffs')
        report['CAL_cutoff_fits'] = 1
        report['files']['cutoffs'] = files.write(out/'CAL_conditional_mean78_cutoffs_before_CP.json',
            dict(cutoffs=cutoffs, source=cal_source, units=report['files']['conditional_units'],
                strict_greater=True, CP_used=False, unknown_used=False))
        cp_error = selected(reg['assets']['CP_masked_error'], ('error',), pins)['error']
        files.require(cp_error.shape == (900,78), 'complete originalCP900 masked errors')
        query = context.role_query(fields, 'CP')
        score = score_error(cp_error, query['predicted_fine'], units)
        geometry = files.js(reg['geometry_registry'], pins)
        metric = context.metric_from_registry(geometry, pins)
        _, raw, retained = context.geometry.route(metric, query, score, cutoffs,
            out, 'conditional_mean78', report)
        preserved = selected(reg['assets']['preserved_known_prediction'],
            ('ids','baseline'), pins)
        files.require(np.array_equal(query['ids'], preserved['ids']),
            'same complete original900 preserved799 control order')
        prediction = preserved['baseline'].copy()
        prediction[raw & retained] = 2
        prediction_asset = trained.core.previous.save(out, 'complete_known_increment_before_truth',
            dict(ids=query['ids'], prediction=prediction, baseline=preserved['baseline'],
                raw=raw, retained=retained), report)
        report['files']['prediction_seal'] = files.write(out/'complete_known_prediction_seal_before_truth.json',
            dict(prediction=prediction_asset, cutoffs=report['files']['cutoffs'],
                units=report['files']['conditional_units'], truth_opened=False))
        report['prediction_sealed'] = True
        truth = selected(reg['assets']['known110'], ('CP_truth',), pins)['CP_truth']
        report['truth_opened'] = True
        gates = context.integer_gates(truth, prediction, known_only=True)
        baseline_gates = context.integer_gates(truth, preserved['baseline'], known_only=True)
        loss = {name: int(np.sum((truth == code) & (preserved['baseline'] == code)
            & (prediction != code))) for code,name in enumerate(('BEN','KNA'))}
        delta = {name: gates[name]['correct']-baseline_gates[name]['correct'] for name in gates}
        trained.core.previous.save(out, 'postseal_complete_known_comparison',
            dict(ids=query['ids'], truth=truth, prediction=prediction,
                baseline=preserved['baseline'], raw=raw, retained=retained), report)
        report.update(execution_status='complete_original900_known_conditional_mean_evaluated',
            original_class_gates=gates, baseline_class_gates=baseline_gates,
            known_correct_loss=loss, known_gate_passed=all(node['passed'] for node in gates.values())
                and not any(loss.values()), correct_delta=delta,
            EffectDelta='UNCHANGED' if not any(delta.values()) else 'DOWN',
            same_original_ids_and_order=True, full_known_rows=900,
            raw_candidates=int(raw.sum()), retained_candidates=int(retained.sum()),
            true_unique_FIT_fine_support=support, unknown_performance_measured=False)
    except Exception as error:
        report.update(execution_status='execution_failed', error_type=type(error).__name__, error=str(error))
        raise
    finally:
        report['wall_seconds'] = time.perf_counter()-began
        report['input_sha256'] = pins
        files.write(out/'report.json', report)
    return files.item(out/'report.json')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=('freeze','known'), required=True)
    parser.add_argument('--registry')
    parser.add_argument('--registry-sha256')
    args = parser.parse_args()
    print(json.dumps(freeze() if args.phase == 'freeze'
        else known(args.registry, args.registry_sha256)))
