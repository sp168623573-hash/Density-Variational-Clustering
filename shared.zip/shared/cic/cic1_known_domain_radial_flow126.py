"""Known-domain/family conditional flow and component-radial typicality CIC1.

Training component labels come only from knownFIT. Every query evaluates all
16 components; originalcoarse restricts a fixed eight-component bank. Neither
query true nor predicted fine selects a component. All16 generated statistics
remain in the fused geometry; no selected-component onehot is introduced.
"""
from __future__ import annotations
import argparse
import io
import json
from pathlib import Path
import sys
import time
import numpy as np
import torch
from scipy.special import logsumexp
from sklearn.cluster import KMeans
from threadpoolctl import threadpool_limits
from . import conditional_affine_flow_v69 as model
from . import cic1_known_domain_flow126_pair_metric_v69 as learned
from . import cic1_known_domain_flow126_dvc_v69 as dvc
from . import cic1_conditional_flow_typicality188_v68 as previous

ROOT,files,context=previous.ROOT,previous.files,previous.context
BASE=ROOT/'data/external_dev/processed/cic1_known_domain_radial_flow126_20261011_v69'
REGDIR=ROOT/'tmp/cic1_known_domain_radial_flow126_20261011_v69'
MODULE='paper_open_set.cic1_known_domain_radial_flow126_v69'

def policy():
    return dict(schema_version='CIC1-V69-knownBEN8domains-KNA8truefamilies-componentflow-radial126',hypotheses=1,
        pure_model=model.model_recipe(78,16),components='knownFITtrueBEN only KMeans8/n_init1/max_iter100/tol.0001/seed20261011; KNAtruefine1..8 maps8..15; all16 positive realgroups',
        training='fixed30 finalepoch, AdamW.001 wd.0001 cosine30 min.0001 clip5, float32/noAMP; all original6000 permutation each epoch, preservephysicalsourcefine proportions',
        query='all16 componentcountertag forwards, no querytruefine/predfine/labels; originalfrozenprimary coarse selects fixed0..7 or8..15 bank only',
        diagnostic_density='propermodel weightedlogsumexp over allowedcoarse components, weights genuineFITcomponent counts divided by genuineFITcoarse support; not claimed trueoriginaltraffic probabilities',
        component_statistics='genuineassignedFIT latentNormSquared mean/std float64, exactzero std1; no logdet in candidate signal',
        candidate='predeclared min over samecoarse component abs(latentnorm2-FITcomponentmean)/FITcomponentstd; no unknown-dependent choice or scalar/cut scan',
        typicality_scope='pre-registered per-record radial heuristic; no conformal or batch typicality statisticalcoverage guarantee',
        CAL='all900 trueknowncoarse finite99 once; originalfrozencoarsequery bank/cutoff, never queryfine',
        geometry='fullnative78/originalFITunits + preservedMHFDclean32/genuineFITRMS + all16 componentradialtypicality/genuineFITRMS =126; no artificialselectedfineonehot or latent-only deletion',
        metric='fresh126 ownknownFIT Eq9/10 fixed80/8192 genuinefine-balancedpairs; no V68weights',
        DVC='newmatching126 distance, ownraw OR complete2397 predictedUNA, original affinity/reconstruction/localdensity/secondarynoise',
        known_gate='oldcorrectloss0 AND BEN/KNA integer99 before firstnewcurrent; no integer exploration',
        allcoords=True,genuineFIT6000=True,optimizer_rows6000=True,no_extra_copies_reference_density=True,
        old799_2381_2396exploratory_2397_preserved=True,MHFD_classifier_unchanged=True,accepted_baseline_replaced=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False)

def freeze():
    pins={};v68ref=files.item(previous.REGDIR/'registry_before_actual_conditional_flow_training.json');v68=files.js(v68ref,pins)
    assets=dict(v68['assets']);sources=previous.closure_helper.source_closure(sys.modules[__name__],model,learned,dvc,previous)
    for a in (*assets.values(),*sources.values()):files.read(a,pins)
    files.require(not BASE.exists() and not REGDIR.exists(),'fresh independentknownmodeflow')
    REGDIR.mkdir(parents=True,exist_ok=False)
    return files.write(REGDIR/'registry_before_trueknown16component_flow_fit.json',dict(policy=policy(),assets=assets,sources=sources,prior_registry=v68ref,preserved=v68['preserved'],known_parent=v68['known_parent'],current_parent=v68['current_parent'],
        model_recipe=model.model_recipe(78,16),metric_recipe=learned.training_recipe(126),output={p:str(BASE/p) for p in ('train','known','current')},input_sha256=pins,current_numeric_decodes=0,current_truth_decodes=0))

def bind(path,sha):
    pins={};r=dict(path=str(Path(path).resolve()),sha256=sha);reg=files.js(r,pins);files.require(reg['policy']==policy() and reg['sources'][MODULE]==files.item(__file__) and reg['model_recipe']==model.model_recipe(78,16) and reg['metric_recipe']==learned.training_recipe(126),'selfownregistry/closure/recipe')
    for a in reg['sources'].values():files.read(a,pins)
    return r,reg,pins

def save(out,name,value,report):return previous.save(out,name,value,report)

def components(x,coarse,fine):
    files.require(x.shape==(6000,78) and coarse.dtype==fine.dtype==np.int64 and np.array_equal(coarse,(fine!=0).astype(np.int64)),'trueknownFITsource classes only')
    began=time.perf_counter()
    with threadpool_limits(limits=4):km=KMeans(n_clusters=8,n_init=1,max_iter=100,tol=.0001,random_state=20261011,algorithm='lloyd').fit(x[coarse==0])
    assigned=np.empty(6000,np.int64);assigned[coarse==0]=km.labels_;assigned[coarse==1]=fine[coarse==1]+7;counts=np.bincount(assigned,minlength=16);files.require((counts>0).all(),'actual16 positiveknown components, no absentfamily manufacture')
    denominators=np.array([int(np.sum(coarse==0))]*8+[int(np.sum(coarse==1))]*8);weights=counts/denominators
    return assigned,dict(centres=km.cluster_centers_.tolist(),counts=counts.tolist(),coarse_weights=weights.tolist(),coarse_support=[int(np.sum(coarse==c)) for c in (0,1)],KMeans_inertia=float(km.inertia_),KMeans_iterations=int(km.n_iter_),KMeans_fit_seconds=time.perf_counter()-began,FIT_only=True,query_assignment_to_KMeans=False)

def train(path,sha):
    registry,reg,pins=bind(path,sha);out=Path(reg['output']['train']);out.mkdir(parents=True,exist_ok=False);started=time.perf_counter();flags=previous.prior.trained.core.capture_runtime_flags();report=dict(policy=policy(),registry=registry,files={},epochs_completed=0,training_runs=0,optimizer_steps=0,known_query_numeric_decodes=0,current_numeric_decodes=0,current_truth_decodes=0,posttraining_neural_forward=0,status='FAIL_TARGET99',published=False,final_test_executed=False)
    try:
        prep=time.perf_counter();raw=context.selected(reg['assets']['native_known'],('FIT_ids','FIT_native78','FIT_y_coarse','FIT_y_fine'),pins);units=np.array(files.js(reg['assets']['native_RMS'],pins)['native78']);x=previous.geometry_helper.previous.raw_source.normalize(raw['FIT_native78'],units).astype(np.float32);coarse=raw['FIT_y_coarse'];fine=raw['FIT_y_fine']
        files.require(len(np.unique(raw['FIT_ids']))==6000 and np.bincount(fine,minlength=9).min()>=20,'genuine6000 finephysicalsupport20')
        comp,modes=components(x,coarse,fine);report['files']['known_components']=files.write(out/'knownFIT_BEN8_KNA8_components_before_neuraloptimizer.json',modes);save(out,'genuineFIT6000_allcoords_and_truecomponent_before_optimizer',dict(ids=raw['FIT_ids'],features=x,coarse=coarse,fine=fine,component=comp),report)
        torch.set_num_threads(4);previous.prior.trained.helpers.network.set_seed(20261011);device=torch.device('cuda' if torch.cuda.is_available() else 'cpu');net=model.ConditionalAffineFlow(78,num_conditions=16).to(device);report.update(device=str(device),initial_state_sha256=model.state_digest(net))
        opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.0001);sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=30,eta_min=.0001);report['FIT_preparation_seconds']=time.perf_counter()-prep;history=[];began=time.perf_counter();report['training_runs']=1
        for epoch in range(1,31):
            net.train();order=np.random.default_rng(np.random.SeedSequence([20261011,epoch])).permutation(6000);save(out,'original6000_permutation_epoch'+str(epoch),dict(indices=order),report);total=0.;seen=0
            for first in range(0,6000,128):
                selected=order[first:first+128];opt.zero_grad(set_to_none=True);value=net(torch.from_numpy(x[selected].copy()).to(device),torch.from_numpy(comp[selected].copy()).to(device));loss=value['NLL'].mean();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),5.);opt.step();report['optimizer_steps']+=1;seen+=len(selected);total+=float(loss.detach())*len(selected)
            sched.step();history.append(dict(epoch=epoch,mean_NLL=total/seen,actualoriginal_rows=seen,actualfinecounts=np.bincount(fine[order],minlength=9).tolist()));report['files']['history']=files.write(out/('fixedfinal_history_through_'+str(epoch)+'.json'),dict(history=history))
            if epoch==1 or epoch%10==0:print(f'[CIC1 modeflow16] epoch={epoch}/30 NLL={total/seen:.6f} elapsed={time.perf_counter()-began:.1f}s',flush=True)
        report.update(training_seconds=time.perf_counter()-began,epochs_completed=30,actual_FITfinecounts=np.bincount(fine,minlength=9).tolist(),actual_component_counts=modes['counts']);state=model.state_digest(net);p=out/'known_domain16_flow78_fixedfinal30.pt'
        with p.open('xb') as f:torch.save(dict(state_dict={k:v.detach().cpu() for k,v in net.state_dict().items()},model_recipe=model.model_recipe(78,16),training_policy=policy(),model_state_sha256=state),f)
        report.update(model_state_sha256=state,execution_status='known16component_flow_fixedfinal30_completed');report['files']['model']=files.item(p)
        for p,h in pins.items():files.require(files.item(p)['sha256']==h,'originalclosures/weights/assets unchanged')
    except Exception as error:report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        restored=previous.prior.trained.core.restore_runtime_flags(flags);report.update(runtime_restoration=dict(before=flags,after=restored,all_flags_restored=flags==restored),wall_seconds=time.perf_counter()-started,input_sha256=pins);files.write(out/'report.json',report)
    return files.item(out/'report.json')

def network(producer,pins):
    saved=torch.load(io.BytesIO(files.read(producer['files']['model'],pins)),map_location='cpu',weights_only=True);files.require(saved['training_policy']==policy() and saved['model_recipe']==model.model_recipe(78,16),'real16componentfixed30state')
    net=model.ConditionalAffineFlow(78,num_conditions=16).cpu();net.load_state_dict(saved['state_dict'],strict=True);net.eval();files.require(model.state_digest(net)==saved['model_state_sha256']==producer['model_state_sha256'],'fulltensorflowstate exact');return net

@torch.no_grad()
def all_components(net,x,ids,role,out,report):
    began=time.perf_counter();norm2=np.empty((len(x),16),np.float64);NLL=np.empty((len(x),16),np.float32)
    for comp in range(16):
        for first in range(0,len(x),512):
            stop=min(first+512,len(x));tag=torch.full((stop-first,),comp,dtype=torch.int64);value=net(torch.from_numpy(np.ascontiguousarray(x[first:stop],np.float32)),tag);raw={k:v.detach().cpu().numpy().copy() for k,v in value.items()};save(out,role+'_component'+str(comp)+'_batch'+str(first)+'_actual_before_guard',raw,report)
            files.require(raw['latent'].shape==(stop-first,78) and raw['latent'].dtype==np.float32 and raw['condition'].dtype==np.int64 and np.all(raw['condition']==comp),'allcomponentcountertags/CPUlatentshape')
            norm2[first:stop,comp]=np.square(raw['latent'].astype(np.float64)).sum(axis=1);NLL[first:stop,comp]=raw['NLL'];report['neural_forward_batches']+=1
    save(out,role+'_all16_norm2_NLL_before_statistics',dict(ids=ids,norm2=norm2,NLL=NLL),report);report['CPU_component_inference_seconds'][role]=time.perf_counter()-began
    return norm2,NLL

def radial(norm2,stats):return np.abs(norm2-np.array(stats['mean']))/np.array(stats['std'])

def selected(radial16,coarse):
    value=np.empty(len(coarse),np.float64)
    for c in (0,1):value[coarse==c]=np.min(radial16[coarse==c,c*8:(c+1)*8],axis=1)
    return value

def mixture_density(NLL,coarse,weights):
    value=np.empty(len(coarse),np.float64)
    for c in (0,1):value[coarse==c]=-logsumexp(np.log(np.asarray(weights)[c*8:(c+1)*8])[None,:]-NLL[coarse==c,c*8:(c+1)*8].astype(np.float64),axis=1)
    return value

def run(phase,path,sha,known_path=None,known_sha=None):
    registry,reg,pins=bind(path,sha);producerref=files.item(Path(reg['output']['train'])/'report.json');producer=files.js(producerref,pins);files.require(producer['epochs_completed']==30 and producer['execution_status']=='known16component_flow_fixedfinal30_completed' and producer['registry']==registry,'actualknown16producer30')
    if phase=='current':
        control=files.js(dict(path=str(Path(known_path).resolve()),sha256=known_sha),pins);files.require(control['prediction_sealed'] and control['known_gate_passed'] and control['known_correct_loss']==dict(BEN=0,KNA=0) and control['registry']==registry,'strictinteger/zero-loss before current16components')
    out=Path(reg['output'][phase]);out.mkdir(parents=True,exist_ok=False);began,threads=time.perf_counter(),torch.get_num_threads();report=dict(policy=policy(),phase=phase,registry=registry,train_report=producerref,files={},NN_fit=0,neural_forward_batches=0,CPU_component_inference_seconds={},stats_fit=0,units_fit=0,metric_fit=0,CAL_fit=0,DVC_calls=0,prediction_sealed=False,truth_opened=False,status='FAIL_TARGET99',published=False,final_test_executed=False,accepted_baseline_replaced=False)
    try:
        torch.set_num_threads(4);net=network(producer,pins);nativeunits=np.array(files.js(reg['assets']['native_RMS'],pins)['native78']);modes=files.js(producer['files']['known_components'],pins);weights=modes['coarse_weights']
        if phase=='known':
            native=context.selected(reg['assets']['native_known'],tuple(r+'_'+k for r in ('FIT','CAL','CP') for k in ('ids','native78'))+('FIT_y_fine','CAL_y_coarse'),pins);oldfields=context.selected(reg['assets']['known110'],tuple(r+'_'+k for r in ('CAL','CP') for k in ('ids','groups','stage1','predicted_fine')),pins);assigned=context.selected(producer['files']['genuineFIT6000_allcoords_and_truecomponent_before_optimizer'],('ids','component'),pins);files.require(np.array_equal(assigned['ids'],native['FIT_ids']),'genuineFITcomponentindex originalIDs')
            fields={};norms={};NLLs={};nativecoord={};clean={}
            for role in ('FIT','CAL','CP'):
                nativecoord[role]=previous.geometry_helper.previous.raw_source.normalize(native[role+'_native78'],nativeunits);norms[role],NLLs[role]=all_components(net,nativecoord[role].astype(np.float32),native[role+'_ids'],role,out,report);clean[role]=context.selected(reg['assets'][role+'_clean32'],('embedding32',),pins)['embedding32'];groups=previous.geometry_helper.group_ids(native[role+'_native78']);files.require(len(np.unique(groups))==len(groups),'originalnativegroupsnotviews')
                fields.update({role+'_ids':native[role+'_ids'],role+'_groups':groups})
                if role!='FIT':
                    files.require(np.array_equal(native[role+'_ids'],oldfields[role+'_ids']) and np.array_equal(groups,oldfields[role+'_groups']),'originalcoarse/fineentities');fields.update({role+'_'+k:oldfields[role+'_'+k] for k in ('stage1','predicted_fine')})
            stats_began=time.perf_counter();tag=assigned['component'];means=[float(norms['FIT'][tag==j,j].mean()) for j in range(16)];rawstd=[float(norms['FIT'][tag==j,j].std()) for j in range(16)];std=[s if s!=0 else 1. for s in rawstd];stats=dict(mean=means,std=std,rawstd=rawstd,support=modes['counts'],genuine_assignedFIT_only=True,exactzero_std1=[s==0 for s in rawstd]);report['stats_fit']=1;report['FIT_component_radialstats_seconds']=time.perf_counter()-stats_began;report['files']['radialstats']=files.write(out/'genuine_assignedFIT_component_norm2_mean_std_before_CAL.json',stats)
            typ={r:radial(norms[r],stats) for r in norms};scale_began=time.perf_counter();typunits=previous.geometry_helper.bridge.rms_unique(typ['FIT']);cleanunits=previous.geometry_helper.bridge.rms_unique(clean['FIT']);report['units_fit']=1;report['FIT_unit_seconds']=time.perf_counter()-scale_began;report['files']['units']=files.write(out/'genuineFIT_preservedclean32_all16radial_units.json',dict(clean32=cleanunits.tolist(),radial16=typunits.tolist(),genuineFIT_rows=6000,queryfit=False))
            for role in ('FIT','CAL','CP'):fields[role+'_Z126']=np.concatenate((nativecoord[role],clean[role].astype(np.float64)/cleanunits,typ[role]/typunits),axis=1)
            fields['FIT_fine']=native['FIT_y_fine'];save(out,'native78_preserved32_radial16_allrole126_before_metric',fields,report)
            kwargs=dict(known_fine_labels=list(range(9)),fit_ids=fields['FIT_ids'].tolist(),fit_group_ids=fields['FIT_groups'].tolist(),fit_roles=['FIT']*6000);p_began=time.perf_counter();prefit=learned.prefit_descriptor(fields['FIT_Z126'],fields['FIT_fine'],**kwargs);report['FIT_pairprep_seconds']=time.perf_counter()-p_began;report['files']['metric_prefit']=files.write(out/'genuine126_knownfine_pair_plan_before_metric.json',prefit);m_began=time.perf_counter();metric=learned.fit_known_metric(fields['FIT_Z126'],fields['FIT_fine'],expected_prefit_sha256=prefit['prefit_sha256'],**kwargs);report['metric_fit']=1;report['FIT_metric_total_prep_gradient_seconds']=time.perf_counter()-m_began;state=metric.to_state();report['metric_gradient_seconds']=state['trained']['training_seconds'];report['files']['metric']=files.write(out/'new126_metric_before_CAL.json',dict(metric_payload=state,model=producer['files']['model']))
            cal=selected(typ['CAL'],fields['CAL_stage1']);save(out,'knownCAL900_radial_min_and_mixture_before_cut',dict(ids=fields['CAL_ids'],all16_radial=typ['CAL'],score=cal,mixture_NLL=mixture_density(NLLs['CAL'],fields['CAL_stage1'],weights),coarse=fields['CAL_stage1']),report);cut=dvc.calibrate_known_cutoffs(cal,native['CAL_y_coarse']);report['CAL_fit']=1;report['files']['cutoffs']=files.write(out/'alltrueknownCAL900_once_radial_min_finite99_before_CP.json',dict(cutoffs=cut,all900_retained=True,queryfine_selection=False))
            query=dict(ids=fields['CP_ids'],groups=fields['CP_groups'],Z126=fields['CP_Z126'],stage1=fields['CP_stage1'],predicted_fine=fields['CP_predicted_fine']);typical=selected(typ['CP'],query['stage1']);save(out,'knownCP900_all16_radial_and_mixture',dict(ids=query['ids'],all16_radial=typ['CP'],score=typical,mixture_NLL=mixture_density(NLLs['CP'],query['stage1'],weights)),report);baseline=context.selected(reg['assets']['known_baseline'],('ids','prediction'),pins)
        else:
            stats=files.js(control['files']['radialstats'],pins);units=files.js(control['files']['units'],pins);cut=files.js(control['files']['cutoffs'],pins)['cutoffs'];metric=learned.PaperVariationalPairMetric.from_state(files.js(control['files']['metric'],pins)['metric_payload']);native=context.selected(reg['assets']['current_native'],('ids','native78'),pins);oldfields=context.selected(reg['assets']['query110'],('ids','groups','stage1','predicted_fine'),pins);coord=previous.geometry_helper.previous.raw_source.normalize(native['native78'],nativeunits);groups=previous.geometry_helper.group_ids(native['native78']);files.require(len(native['ids'])==len(np.unique(groups))==4056 and np.array_equal(native['ids'],oldfields['ids']) and np.array_equal(groups,oldfields['groups']),'exact4056genuine nativegroups')
            norm2,NLL=all_components(net,coord.astype(np.float32),native['ids'],'current4056',out,report);typ=radial(norm2,stats);clean=context.selected(reg['assets']['current_clean32'],('embedding32',),pins)['embedding32'];query=dict(oldfields,Z126=np.concatenate((coord,clean.astype(np.float64)/np.array(units['clean32']),typ/np.array(units['radial16'])),axis=1));save(out,'whole4056_native32_radial16_Z126_before_score',query,report);typical=selected(typ,query['stage1']);save(out,'whole4056_all16_radial_and_mixture',dict(ids=query['ids'],all16_radial=typ,score=typical,mixture_NLL=mixture_density(NLL,query['stage1'],weights)),report);baseline=context.selected(reg['assets']['current_baseline'],('ids','prediction'),pins)
        files.require(np.array_equal(query['ids'],baseline['ids']),'originalbaseline IDs');before=baseline['prediction'];raw=dvc.candidate_mask(typical,query['stage1'],cut);density=raw|(before==2);save(out,'radial_min_scores_and_density_before_DVC',dict(ids=query['ids'],score=typical,coarse=query['stage1'],raw=raw,density=density),report);route=dvc.route_current_candidates(metric,query['Z126'],density,seed=20261009);report['DVC_calls']=1;save(out,'own126_DVC_before_truth',{k:v for k,v in route.items() if k!='manifest'},report);report['files']['DVC_manifest']=files.write(out/'own126_DVC_manifest_before_truth.json',route['manifest']);prediction=before.copy();prediction[raw&route['retained']]=2
        p=save(out,'complete_prediction_before_truth',dict(ids=query['ids'],prediction=prediction,baseline=before,raw=raw,density=density,retained=route['retained']),report);report['files']['seal']=files.write(out/'radial_prediction_seal_before_truth.json',dict(predictions=p,truth_used=False,registry=registry));report['prediction_sealed']=True
        if phase=='known':truth=context.selected(reg['assets']['known110'],('CP_truth',),pins)['CP_truth']
        else:
            t=context.selected(reg['assets']['truth'],('ids','truth'),pins);files.require(np.array_equal(t['ids'],query['ids']),'matchedtruth afterseal');truth=t['truth']
        report['truth_opened']=True;gates=context.integer_gates(truth,prediction,known_only=phase=='known');gl={n:dict(gain=int(np.sum((truth==c)&(before!=c)&(prediction==c))),loss=int(np.sum((truth==c)&(before==c)&(prediction!=c)))) for c,n in enumerate(gates)};delta={n:x['gain']-x['loss'] for n,x in gl.items()};pos,neg=any(v>0 for v in delta.values()),any(v<0 for v in delta.values());loss={n:gl[n]['loss'] for n in ('BEN','KNA')};save(out,'postseal_paired_comparison',dict(ids=query['ids'],truth=truth,prediction=prediction,baseline=before,raw=raw,density=density,retained=route['retained']),report)
        report.update(execution_status='knownmode16_radial126_'+phase+'_evaluated',original_class_gates=gates,known_correct_loss=loss,known_gate_passed=all(gates[n]['passed'] and loss[n]==0 for n in ('BEN','KNA')),EffectDelta=dict(verdict='MIXED' if pos and neg else 'UP' if pos else 'DOWN' if neg else 'UNCHANGED',correct_count_delta=delta,gain_loss=gl,same_original_IDs=True),raw_by_true_class={n:int(np.sum((truth==c)&raw)) for c,n in enumerate(gates)},all_three_integer99_passed=phase=='current' and all(g['passed'] for g in gates.values()))
        files.require(model.state_digest(net)==producer['model_state_sha256'],'sameflowstate throughoutCPUallcomponents')
        for p,h in pins.items():files.require(files.item(p)['sha256']==h,'frozeninputs/core/producer/sources')
    except Exception as error:report.update(execution_status='execution_failed',error_type=type(error).__name__,error=str(error));raise
    finally:
        torch.set_num_threads(threads);report.update(threads_restored=torch.get_num_threads()==threads,wall_seconds=time.perf_counter()-began,input_sha256=pins);files.write(out/'report.json',report)
    return files.item(out/'report.json')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','train','known','current'),required=True)
    for n in ('registry','registry-sha256','known-report','known-sha256'):p.add_argument('--'+n)
    a=p.parse_args();print(json.dumps(freeze() if a.phase=='freeze' else train(a.registry,a.registry_sha256) if a.phase=='train' else run(a.phase,a.registry,a.registry_sha256,a.known_report,a.known_sha256)))
