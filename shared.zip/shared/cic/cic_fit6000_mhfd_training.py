"""Own CIC1/CIC2 FIT6000 MHFD recipes with immutable original controls.

Root phases: freeze (metadata only), material (known arrays/preprocessing), train.
CIC1 retains standard selected50; CIC2 extends original warm FIT with signed-log
selected50. The CIC2 strong coverage model used320 different FIT groups: this
new recipe changes training composition, count and representation jointly.
No prior weights, query features, unknown truth, novelty scores or DVC are used.
"""
from __future__ import annotations

import argparse
from collections import Counter
from functools import partial
import hashlib
import json
import os
from pathlib import Path
import time

import joblib
import numpy as np
import pandas as pd
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.preprocessing import FunctionTransformer
import torch

from . import data as preprocessing
from . import model as network
from . import mhfd_numeric_checkpoint as geometry
from . import cic2017_native_known_training_v1 as old1
from . import cic2017_setting2_warm_known_training_v1 as old2
from . import cic2017_all_native78_known_material_v1 as header_tools
from . import cic2017_all_native78_known80_v1 as prior_specs
from .config import CIC_FEATURE_COLUMNS, get_spec

ROOT=Path(__file__).resolve().parents[1]
EPOCHS,SEED,TOP_K=80,20261009,50
SOURCE={
    "CIC Setting1":dict(path="data/external_dev/processed/cic2017_native_known_source_extract_20261008_v1/report.json",sha256="6375dd3fd443320c570db263b9ec090f3daf68bce3192252b6e3d3f382de60bc"),
    "CIC Setting2":dict(path="data/external_dev/processed/cic2017_setting2_warm_known_source_extract_20261008_v1/report.json",sha256="411e53400ac69a026eb6b21206ed97f24e14724aaf5073cf52b9c150b160b92a")}
PROJECTION=dict(path="data/external_dev/processed/cic_fit1800_native_projection_20261009_v1/report.json",sha256="b4a93d0b0a48acc0bd4ec937b13347c1794bc5777a4702502f388848ea60fd05")
PLAN=dict(path="tmp/currentdata_expansion_budget_20261009_v1/CIC_expansion_review.json",sha256="38f7b5aab5e85e151ba9b6184a6474ac837f78637bb53980dac85aa076123ad2")
PARTIAL=dict(path="data/external_dev/processed/cic2017_native_partial_dev_source_20261008_v1/ordered_source_records.json",sha256="c6bb4d5ec34a10b383a7f6793dd561e0ee438d9d55c7e30e8023c4693e999283")
FIELDS=("attack_probability","fine_probability","embedding","reconstruction_error","gate_mean","coarse_attack_probability","fine_attack_probability")
INDEX_FIELDS=dict(FIT="FIT_training_indices",CP="CP_reporting_indices",CAL="CAL_reporting_indices")
sha=old1.sha
descriptor=old1.descriptor
ad=old1.array_descriptor
require=old1.require


def checked(item,pins):
    path=Path(item["path"])
    path=(path if path.is_absolute() else ROOT/path).resolve()
    require(path.is_relative_to(ROOT) and path != ROOT,"registered_workspace_input")
    require(sha(path)==item["sha256"],"input_pin_changed:"+str(path))
    require(pins.get(str(path),item["sha256"])==item["sha256"],"conflicting_input_pin")
    pins[str(path)]=item["sha256"]
    return path


def read(item,pins):
    return json.loads(checked(item,pins).read_text(encoding="utf-8"))


def json_new(path,value,pins=None):
    with Path(path).open("x",encoding="utf-8") as handle:
        json.dump(value,handle,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)
        handle.write("\n")
    item=descriptor(path)
    if pins is not None:pins[item["path"]]=item["sha256"]
    return item


def npz_new(path,values,pins):
    with Path(path).open("xb") as handle:np.savez_compressed(handle,**values)
    item=descriptor(path)
    pins[item["path"]]=item["sha256"]
    return item


def policy(setting):
    require(setting in SOURCE,"own_CIC_setting")
    return dict(schema_version="CIC-own-extended-FIT6000-MHFD50-v1",setting=setting,
        original_source="frozen original native known roles; original warm roles for CIC2, not coverage replacement320",
        FIT_unique=6000 if setting=="CIC Setting1" else 5987,FIT_optimizer=6000,
        FIT_copies=0 if setting=="CIC Setting1" else 13,
        CP_original=900 if setting=="CIC Setting1" else 882,CAL_original=900 if setting=="CIC Setting1" else 882,
        CP_CAL_effective_reporting_each=900,holdouts_in_training_budget=False,
        old_role_IDs_order_labels_preserved=True,new_true_FIT_originals=1800,
        native_fields=78,model_feature_width_max=TOP_K,
        representation="standard" if setting=="CIC Setting1" else "signed_log1p_float64_before_standard",
        preprocessing="original unique FIT only: median imputer,StandardScaler,positive variance,ANOVA top50; no clipping; full serialized transform roundtrip",
        model="original MHFD attention/gate/CNN/BiLSTM,embedding32,coarse/fine heads and decoder; fresh own seed",
        loss="unchanged train_model coarseCE +.35 fineCE(smoothing.01)+.03 reconstructionSmoothL1",
        optimizer="unchanged AdamW .001 wd.0002,cosine .0001,clip_norm5;6000 hierarchical-balanced draws",
        epochs=EPOCHS,seed=SEED,training_batch_size=512,inference_batch_size=2048,AMP_on_CUDA=True,
        checkpoint_role="CP originals only; unchanged CP coarse/fine checkpoint score",
        final_coarse_threshold_role="one CAL originals choose_coarse_threshold call after checkpoint seal",
        known_gate="original CP and CAL BEN/KNA exact integer gates;900-copy reports separately",
        unknown_inference_entry=False,unknown_forward_calls=0,unknown_training_rows=0,
        capture="post-checkpoint FIT,CAL,CP raw5 plus derived7 before validation; complete saved arrays before caller gates",
        cross_setting_parameters_transferred=False,old_weights_retrained_or_overwritten=False,
        EffectDelta_scope="same frozen known controls; training count/composition and fitted representation jointly changed, not isolated added-module effect",
        original_unknown_DEV_unchanged=True,warm_holdout_reuse_disclosed=True,
        density_copy_rows=0,physical_event_independence_claimed=False,
        published=False,final_test_executed=False,status="FAIL_TARGET99")


def freeze(setting,output_directory):
    out=Path(output_directory).resolve()
    require(out.is_relative_to(ROOT) and out != ROOT,"fresh_workspace_child")
    out.mkdir(parents=True,exist_ok=False)
    pins={}
    source,projection,plan=read(SOURCE[setting],pins),read(PROJECTION,pins),read(PLAN,pins)
    require(source["source_extraction_completed"] and source["all_input_pins_stable"]
            and not source["published"] and not source["final_test_executed"],"completed_own_source")
    require(projection["native_projection_completed"] and projection["all_input_pins_stable"]
            and not projection["published"] and not projection["final_test_executed"],"completed1800_projection")
    originals=source["files"]["known_roles_archive"]
    records_item=source["files"]["ordered_source_records"]
    records=read(records_item,pins)
    addition=projection["settings"][setting]
    added_records=read(addition["ordered_source_records"],pins)
    headers=header_tools.npz_headers(checked(originals,pins))
    added_headers=header_tools.npz_headers(checked(addition["archive"],pins))
    require(headers["FIT_native78"]["shape"]==[policy(setting)["FIT_unique"]-1800,78]
            and added_headers["native78"]["shape"]==[1800,78],"known_archive_headers")
    family_order=("BEN",*get_spec(setting).known_families)
    require(tuple(records["family_order"])==tuple(added_records["family_order"])==family_order,"own_family_order")
    partial=read(PARTIAL,pins) if setting=="CIC Setting1" else None
    before={row["canonical78_sha256"] for rows in records["roles"].values() for row in rows}
    added={row["canonical78_sha256"] for row in added_records["rows"]}
    require(len(added)==1800 and not added.intersection(before),"added_group_old_role_disjointness")
    if partial is not None:require(not added.intersection(row["canonical78_sha256"] for row in partial["records"]),"frozen_unknown_DEV_disjointness")
    baseline=prior_specs.BASELINES[setting]
    read(baseline["report"],pins)
    for role in ("CP","CAL"):checked(baseline[role]["asset"],pins)
    for module in (Path(__file__),Path(network.__file__),Path(preprocessing.__file__),Path(geometry.__file__),Path(old1.__file__),Path(old2.__file__),Path(header_tools.__file__),Path(prior_specs.__file__),ROOT/"paper_open_set/config.py"):
        pins[str(module.resolve())]=sha(module)
    value=dict(schema_version="CIC-FIT6000-training-registry-before-known-decode-v1",setting=setting,
        output_directory=str(out),configuration=policy(setting),family_order=family_order,
        source_report=SOURCE[setting],projection_report=PROJECTION,plan=PLAN,
        originals=originals,original_records=records_item,addition=addition["archive"],addition_records=addition["ordered_source_records"],
        source_headers=headers,addition_headers=added_headers,
        expected_FIT_family=plan["settings"][setting]["new_training_only_budget_proposal"]["family_extension"],
        baseline=baseline,input_sha256=pins,actual_numeric_decodes=0,model_fit_or_forward=0,
        status="FAIL_TARGET99",published=False,final_test_executed=False)
    return json_new(out/"registry_before_known_numeric_decode.json",value)


def load_registry(item):
    pins={}
    registry=read(item,pins)
    require(registry["configuration"]==policy(registry["setting"]),"frozen_recipe_changed")
    for path,wanted in registry["input_sha256"].items():checked(dict(path=path,sha256=wanted),pins)
    return registry,pins


def combine(setting,old,old_records,added,added_records):
    (old1 if setting=="CIC Setting1" else old2)._validate_arrays(old,old_records)
    expected_family=("BEN",*get_spec(setting).known_families)
    require(added["native78"].shape==(1800,78) and added["native78"].dtype==np.dtype("<f8")
            and np.isfinite(added["native78"]).all(),"finite1800_native78")
    before={row["canonical78_sha256"] for rows in old_records["roles"].values() for row in rows}
    groups=set()
    for i,row in enumerate(added_records["rows"]):
        fp=hashlib.sha256(added["native78"][i].tobytes(order="C")).hexdigest()
        require(fp==row["canonical78_sha256"]==str(added["groups"][i]) and fp not in before and fp not in groups,"addition_exact_group_binding")
        groups.add(fp)
        require(row["sample_id"]==str(added["ids"][i]) and row["family"]==expected_family[int(added["y_fine"][i])]
                and int(added["y_coarse"][i])==int(row["family"]!="BEN"),"addition_known_label_ID_binding")
    require(len(groups)==len(added_records["rows"])==1800,"1800_unique_additions")
    result={key:value.copy() for key,value in old.items()}
    old_count=len(old["FIT_native78"])
    for suffix,key in (("native78","native78"),("ids","ids"),("y_fine","y_fine"),("y_coarse","y_coarse")):
        result["FIT_"+suffix]=np.concatenate((old["FIT_"+suffix],added[key]))
    for role in ("FIT","CP","CAL"):
        key=INDEX_FIELDS[role]
        if key not in old:result[key]=np.arange(len(old[role+"_ids"]),dtype=np.int64)
    result["FIT_training_indices"]=np.concatenate((result["FIT_training_indices"],np.arange(old_count,old_count+1800,dtype=np.int64)))
    require(len(result["FIT_training_indices"])==6000,"optimizer_budget_including_copies")
    for role in ("CP","CAL"):
        for suffix in ("native78","ids","y_fine","y_coarse"):
            require(ad(result[role+"_"+suffix])==ad(old[role+"_"+suffix]),"old_control_bytes_changed")
    effective=result["FIT_y_fine"][result["FIT_training_indices"]]
    require(set(effective.tolist())==set(range(len(expected_family))) and min(Counter(effective.tolist()).values())>=20,"every_FIT_effective_family_floor20")
    return result


def transform_native78(bundle,native):
    frame=pd.DataFrame(native,columns=CIC_FEATURE_COLUMNS)
    values=np.asarray(bundle["transformer"].transform(frame),dtype=np.float32)
    return bundle["selector"].transform(values[:,bundle["variance_mask"]]).astype(np.float32)


def prepare(setting,arrays):
    transformer=preprocessing._build_preprocessor(get_spec(setting))
    if setting=="CIC Setting2":
        transformer.transformers[0][1].steps.insert(0,("signed_log1p",FunctionTransformer(partial(geometry._geometry,transform="signed_log1p"),validate=False,feature_names_out="one-to-one")))
    fit=np.asarray(transformer.fit_transform(pd.DataFrame(arrays["FIT_native78"],columns=CIC_FEATURE_COLUMNS)),dtype=np.float32)
    mask=np.var(fit,axis=0)>0
    require(int(mask.sum())>=2,"two_nonconstant_FIT_features")
    selector=SelectKBest(f_classif,k=min(TOP_K,int(mask.sum())))
    features={"FIT":selector.fit_transform(fit[:,mask],arrays["FIT_y_fine"]).astype(np.float32)}
    bundle=dict(transformer=transformer,variance_mask=mask,selector=selector,
        selected_feature_names=tuple(np.asarray(transformer.get_feature_names_out())[mask][selector.get_support()].tolist()),
        family_order=("BEN",*get_spec(setting).known_families),representation=policy(setting)["representation"])
    for role in ("CP","CAL"):features[role]=transform_native78(bundle,arrays[role+"_native78"])
    require(all(np.isfinite(values).all() and values.shape[1]<=TOP_K for values in features.values()),"finite_selected_features")
    return features,bundle


def material(item):
    registry,pins=load_registry(item)
    out=Path(registry["output_directory"])/"material"
    out.mkdir(exist_ok=False)
    setting=registry["setting"]
    with np.load(checked(registry["originals"],pins),allow_pickle=False) as z:old={key:z[key].copy() for key in z.files}
    with np.load(checked(registry["addition"],pins),allow_pickle=False) as z:added={key:z[key].copy() for key in z.files}
    arrays=combine(setting,old,read(registry["original_records"],pins),added,read(registry["addition_records"],pins))
    for index,family in enumerate(registry["family_order"]):
        target=registry["expected_FIT_family"][family]
        require(int(np.sum(arrays["FIT_y_fine"]==index))==target["new_FIT_original_groups"]
                and int(np.sum(arrays["FIT_y_fine"][arrays["FIT_training_indices"]]==index))==target["new_FIT_effective"],"exact_proportional_FIT_family_counts")
    features,bundle=prepare(setting,arrays)
    bundle_path=out/"complete_FIT_preprocessing.joblib"
    joblib.dump(bundle,bundle_path,compress=3)
    bundle_desc=descriptor(bundle_path)
    pins[bundle_desc["path"]]=bundle_desc["sha256"]
    restored=joblib.load(bundle_path)
    for role in features:require(ad(transform_native78(restored,arrays[role+"_native78"]))==ad(features[role]),"complete_preprocessing_roundtrip:"+role)
    source_array=npz_new(out/"combined_known_roles_native78_before_fit.npz",arrays,pins)
    prepared={**{key:value for key,value in arrays.items() if not key.endswith("_native78")},**{role+"_features":values for role,values in features.items()}}
    feature_array=npz_new(out/"exact_known_training_inputs_before_fit.npz",prepared,pins)
    return json_new(out/"material_report_before_fit.json",dict(schema_version="CIC-FIT6000-known-material-before-training-v1",
        setting=setting,registry=item,configuration=registry["configuration"],family_order=registry["family_order"],
        source_arrays=source_array,features=feature_array,preprocessing=bundle_desc,
        selected_feature_names=bundle["selected_feature_names"],bound={key:ad(value) for key,value in prepared.items()},
        FIT_optimizer_rows=6000,FIT_original_rows=len(arrays["FIT_ids"]),preprocessing_FIT_original_only=True,
        old_CP_CAL_byte_exact=True,network_fits=0,unknown_reads=False,input_sha256=pins,
        status="FAIL_TARGET99",published=False,final_test_executed=False))


@torch.no_grad()
def capture_infer(net,features,device,role,out,report,families):
    net.eval()
    device=torch.device(device)
    pieces={key:[] for key in (*FIELDS,"coarse_logits","fine_logits","reconstruction")}
    for index,start in enumerate(range(0,len(features),2048)):
        batch=torch.from_numpy(features[start:start+2048]).to(device)
        with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=device.type=="cuda"):returned=net(batch)
        raw={key:returned[key].detach().float().cpu().numpy().copy() for key in ("coarse_logits","fine_logits","reconstruction","embedding","gate_mean")}
        report["files"][f"{role}_raw_batch{index}_before_guard"]=npz_new(out/f"{role}_raw_batch{index}_before_guard.npz",raw,{})
        coarse=torch.softmax(returned["coarse_logits"],dim=1)[:,1]
        fine_prob=torch.softmax(returned["fine_logits"],dim=1)
        fine=1-fine_prob[:,0]
        tensors=dict(attack_probability=.55*coarse+.45*fine,fine_probability=fine_prob,embedding=returned["embedding"],
            reconstruction_error=torch.mean((returned["reconstruction"].float()-batch.float())**2,dim=1),gate_mean=returned["gate_mean"],coarse_attack_probability=coarse,fine_attack_probability=fine)
        values={key:value.detach().float().cpu().numpy().copy() for key,value in tensors.items()}
        values.update({key:raw[key] for key in ("coarse_logits","fine_logits","reconstruction")})
        report["files"][f"{role}_complete_batch{index}_before_guard"]=npz_new(out/f"{role}_complete_batch{index}_before_guard.npz",values,{})
        require(all(np.isfinite(value).all() and len(value)==len(batch) for value in values.values())
                and values["fine_probability"].shape==(len(batch),len(families))
                and values["reconstruction"].shape==(len(batch),features.shape[1]),"complete_inference_shapes_and_finite")
        require(np.allclose(values["fine_probability"].sum(axis=1),1,atol=2e-3),"AMP_fine_probability_mass")
        for key,value in values.items():pieces[key].append(value)
    complete={key:np.concatenate(value) for key,value in pieces.items()}
    complete["embedding32"]=complete["embedding"].copy()
    report["files"][role+"_complete_inference_before_guard"]=npz_new(out/(role+"_complete_inference_before_guard.npz"),complete,{})
    return network.InferenceOutput(**{key:complete[key] for key in FIELDS})


def gates(truth,prediction):
    return old1._gates(truth,prediction)


def paired(truth,before,after):
    a,b=gates(truth,before),gates(truth,after)
    delta={key:b[key]["correct"]-a[key]["correct"] for key in a}
    numbers=list(delta.values())
    verdict="UNCHANGED" if not any(numbers) else "UP" if min(numbers)>=0 else "DOWN" if max(numbers)<=0 else "MIXED"
    return dict(verdict=verdict,correct_delta=delta,baseline_gates=a,candidate_gates=b,
        gain=int(np.sum((before!=truth)&(after==truth))),loss=int(np.sum((before==truth)&(after!=truth))))


def train(registry_item,material_item):
    registry,pins=load_registry(registry_item)
    known=read(material_item,pins)
    require(known["registry"]==registry_item and known["configuration"]==registry["configuration"]
            and known["setting"]==registry["setting"] and known["network_fits"]==0,"same_frozen_training_material")
    for path,wanted in known["input_sha256"].items():checked(dict(path=path,sha256=wanted),pins)
    out=Path(registry["output_directory"])/"train"
    out.mkdir(exist_ok=False)
    with np.load(checked(known["features"],pins),allow_pickle=False) as saved:arrays={key:saved[key].copy() for key in saved.files}
    require(set(arrays)==set(known["bound"]) and all(ad(arrays[key])==known["bound"][key] for key in arrays),"sealed_actual_training_material")
    environment={key:os.environ.get(key) for key in ("CUBLAS_WORKSPACE_CONFIG","OMP_NUM_THREADS","MKL_NUM_THREADS")}
    threads=torch.get_num_threads()
    flags=dict(deterministic=torch.are_deterministic_algorithms_enabled(),warn_only=torch.is_deterministic_algorithms_warn_only_enabled(),
        cudnn_deterministic=torch.backends.cudnn.deterministic,cudnn_benchmark=torch.backends.cudnn.benchmark,
        cudnn_tf32=torch.backends.cudnn.allow_tf32,matmul_tf32=torch.backends.cuda.matmul.allow_tf32)
    report=dict(configuration=registry["configuration"],setting=registry["setting"],files={},training_started=False,
        training_completed=False,training_runs=0,known_metrics_evaluated=False,unknown_forward_calls=0,
        unknown_query_allowed=False,accepted_baseline_replaced=False,EffectDelta=dict(verdict="NOT_COMPARABLE"),
        runtime_environment=environment,status="FAIL_TARGET99",published=False,final_test_executed=False)
    began,stage=time.perf_counter(),"training_policy_before_optimizer"
    try:
        require(not torch.cuda.is_available() or environment["CUBLAS_WORKSPACE_CONFIG"]==":4096:8","CUBLAS_workspace_must_be_set_before_ROOT_Python")
        report["files"]["prefit"]=json_new(out/"training_policy_before_optimizer.json",dict(registry=registry_item,material=material_item,configuration=registry["configuration"],runtime_environment=environment,input_sha256=pins))
        torch.set_num_threads(4)
        indices=arrays["FIT_training_indices"]
        require(len(indices)==6000,"exact6000_optimizer_rows")
        stage="actual_extended_FIT6000_MHFD80"
        report.update(training_started=True,training_runs=1)
        result=network.train_model(arrays["FIT_features"][indices],arrays["FIT_y_coarse"][indices],arrays["FIT_y_fine"][indices],
            arrays["CP_features"],arrays["CP_y_coarse"],fine_class_count=len(registry["family_order"]),epochs=EPOCHS,seed=SEED,
            progress_label=registry["setting"]+" own FIT6000",checkpoint_fine_labels=arrays["CP_y_fine"])
        report.update(training_completed=True,training_seconds=float(result.training_seconds),epochs_completed=len(result.history),
            selected_epoch=int(result.selected_epoch),device=result.device)
        require(len(result.history)==EPOCHS,"actual80_epoch_history")
        report["files"]["history"]=json_new(out/"training_history.json",result.history)
        stage="selected_checkpoint_seal"
        checkpoint=out/"selected_MHFD_state.pt"
        state={key:value.detach().cpu().clone() for key,value in result.model.state_dict().items()}
        torch.save(dict(state_dict=state,input_dim=arrays["FIT_features"].shape[1],fine_class_count=len(registry["family_order"]),
            family_order=registry["family_order"],selected_epoch=result.selected_epoch,seed=SEED),checkpoint)
        restored=torch.load(checkpoint,map_location="cpu",weights_only=True)
        require(set(restored["state_dict"])==set(state) and all(torch.equal(value,restored["state_dict"][key]) for key,value in state.items()),"checkpoint_roundtrip")
        report["files"]["model"]=descriptor(checkpoint)
        outputs={}
        for role in ("FIT","CAL"):
            stage="post_checkpoint_complete_inference_"+role
            outputs[role]=capture_infer(result.model,arrays[role+"_features"],result.device,role,out,report,registry["family_order"])
        stage="CAL_original_only_threshold_once"
        threshold,metrics=network.choose_coarse_threshold(arrays["CAL_y_coarse"],outputs["CAL"].attack_probability)
        report["files"]["CAL_threshold"]=json_new(out/"coarse_threshold_from_CAL_once.json",dict(threshold=float(threshold),selection_role="CAL_original",CAL_original_rows=len(arrays["CAL_y_coarse"]),
            model=report["files"]["model"],CAL_output=report["files"]["CAL_complete_inference_before_guard"],known_CAL_metrics=metrics,threshold_fit_calls=1))
        stage="post_CAL_seal_CP_complete_inference"
        outputs["CP"]=capture_infer(result.model,arrays["CP_features"],result.device,"CP",out,report,registry["family_order"])
        predictions={role+"_prediction":(value.attack_probability>=threshold).astype(np.int64) for role,value in outputs.items()}
        report["files"]["predictions_before_prior"]=npz_new(out/"known_predictions_before_prior.npz",predictions,{})
        report["files"]["prediction_seal"]=json_new(out/"known_prediction_seal_before_prior.json",dict(predictions=report["files"]["predictions_before_prior"],model=report["files"]["model"],threshold=report["files"]["CAL_threshold"],prior_predictions_read=False))
        report["original_gates"]={role:gates(arrays[role+"_y_coarse"],predictions[role+"_prediction"]) for role in outputs}
        report["effective_reporting_gates"]={role:gates(arrays[role+"_y_coarse"][arrays[INDEX_FIELDS[role]]],predictions[role+"_prediction"][arrays[INDEX_FIELDS[role]]]) for role in outputs}
        stage="frozen_same_known_control_comparison_after_prediction_seal"
        effect={}
        for role in ("CP","CAL"):
            prior=registry["baseline"][role]
            with np.load(checked(prior["asset"],pins),allow_pickle=False) as saved:
                require(np.array_equal(saved[prior["ids"]],arrays[role+"_ids"]) and np.array_equal(saved[prior["truth"]],arrays[role+"_y_coarse"]),"same_prior_control_ID_order_labels")
                before=saved[prior["prediction"]].copy()
            effect[role]=paired(arrays[role+"_y_coarse"],before,predictions[role+"_prediction"])
        report["EffectDelta"]=dict(same_control_comparison=effect,scope=registry["configuration"]["EffectDelta_scope"],accepted_baseline_replaced=False)
        all_known=all(row["passed"] for role in ("CP","CAL") for row in report["original_gates"][role].values())
        report.update(known_metrics_evaluated=True,all_original_known_gates_passed=all_known,
            unknown_query_allowed=all_known,threshold_fit_calls=1,
            execution_status="CIC_own_FIT6000_MHFD_training_and_known_controls_completed",
            known_failure_reason=None if all_known else "KNOWN_CONTROLS_FAILED_UNKNOWN_UNOPENED")
        for path,wanted in pins.items():require(sha(path)==wanted,"training_input_changed:"+path)
        for item in report["files"].values():require(sha(item["path"])==item["sha256"],"saved_training_output_changed")
    except Exception as error:
        report.update(execution_status="protocol_stop" if isinstance(error,old1.NativeKnownTrainingStop) else "execution_failed",failed_stage=stage,error_type=type(error).__name__,error_message=str(error))
    finally:
        torch.set_num_threads(threads)
        torch.use_deterministic_algorithms(flags["deterministic"],warn_only=flags["warn_only"])
        torch.backends.cudnn.deterministic=flags["cudnn_deterministic"]
        torch.backends.cudnn.benchmark=flags["cudnn_benchmark"]
        torch.backends.cudnn.allow_tf32=flags["cudnn_tf32"]
        torch.backends.cuda.matmul.allow_tf32=flags["matmul_tf32"]
        for key,value in environment.items():
            if value is None:os.environ.pop(key,None)
            else:os.environ[key]=value
        report["threads_restored"]=torch.get_num_threads()==threads
        report["environment_restored"]=all(os.environ.get(key)==value for key,value in environment.items())
        report["torch_flags_restored"]=(torch.are_deterministic_algorithms_enabled()==flags["deterministic"] and torch.is_deterministic_algorithms_warn_only_enabled()==flags["warn_only"] and torch.backends.cudnn.deterministic==flags["cudnn_deterministic"] and torch.backends.cudnn.benchmark==flags["cudnn_benchmark"] and torch.backends.cudnn.allow_tf32==flags["cudnn_tf32"] and torch.backends.cuda.matmul.allow_tf32==flags["matmul_tf32"])
    report["wall_seconds"]=time.perf_counter()-began
    report["input_sha256"]=pins
    report["material"]=material_item
    report["registry"]=registry_item
    return json_new(out/"report.json",report)


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase",choices=("freeze","material","train"))
    parser.add_argument("--setting",choices=tuple(SOURCE))
    parser.add_argument("--output-directory",type=Path)
    parser.add_argument("--registry",type=Path)
    parser.add_argument("--registry-sha256")
    parser.add_argument("--material",type=Path)
    parser.add_argument("--material-sha256")
    args=parser.parse_args(argv)
    if args.phase=="freeze":item=freeze(args.setting,args.output_directory)
    else:
        registry_item=dict(path=str(args.registry.resolve()),sha256=args.registry_sha256)
        item=material(registry_item) if args.phase=="material" else train(registry_item,dict(path=str(args.material.resolve()),sha256=args.material_sha256))
    print(json.dumps(item,ensure_ascii=False))
    if args.phase=="train":
        result=json.loads(Path(item["path"]).read_text(encoding="utf-8"))
        return 0 if result["execution_status"]=="CIC_own_FIT6000_MHFD_training_and_known_controls_completed" else 2 if result["execution_status"]=="protocol_stop" else 1
    return 0


if __name__ == "__main__":raise SystemExit(main())
