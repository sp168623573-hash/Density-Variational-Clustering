"""Full existing Sample3184 DEV with the newly aligned shared-FIT pipeline.

Uses live CPU classifier probabilities, owned110 metric and sealed CAL.
One canonical native78 feature group supplies at most one density point.
All original flow IDs remain in evaluation; duplicate groups are expanded
after routing. No unknown label is read until the prediction seal.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import joblib
import numpy as np
import torch
from . import cic2_class_guard_primary110_alignment_v2 as aligned

h,fine,guard,ROOT=aligned.h,aligned.fine,aligned.guard,aligned.ROOT
OUT=ROOT/'data/external_dev/processed/cic2_live_guard_owned110_current_20261011_v1'
REGDIR=ROOT/'tmp/cic2_live_guard_owned110_current_20261011_v1'
KNOWN=dict(path=str(aligned.OUT/'report.json'),sha256='f9284dc1ec4b816b1513cc67457aa8e8fa35e4ed8bd00275d6f46b835764017e')
QUERY_REPORT=dict(path=str(ROOT/'data/external_dev/processed/cic2_residual30_existing_Sample3184_DEV_20261009_v1/report.json'),sha256='77317e54139a522ded895db4230115a3446daf7274e8027185dd8efdb991b9d6')
TRUTH=dict(path=str(ROOT/'data/external_dev/processed/cic2_fit6000_aux110_Sample3184_20261010_agent_reporting_recovery_v1/postseal_original3184_evaluation_and_comparison.npz'),sha256='2acae7e8d971abcde42627158431505b87a1ee285053db98ec1ed55e35a5ce1e')


def policy():
    return dict(schema_version='CIC2-live-class-guard-owned110-fullSample3184-DEV-v1',hypotheses=1,
        classifier='same live CPU512-batch original signedlog NN .55coarse+.45fine / quarter oldforest / fine9HGB class support as new known alignment',
        geometry='same sealed shared5987 native78+primaryembedding32 RMS units and trained110 Eq9/10 metric',
        cutoffs='owned CAL882 conditional finite99 frozen before query; no query parameter fit',
        density='one representative per exact canonical native78 feature group; expand outcomes to all original flows; no source event independence claim',
        DVC='label-blind original silhouette/CH/kdistance parameter choice plus affinity/reconstruction/local density/secondarynoise',
        roster='all3184 previously observed development IDs; no removal or relabeling',
        training_union_originals=5987,optimizer_including_copies=6000,
        old_current_results='historical1430/510/399 and failed1455/459/322 comparisons only, not prediction decisions',
        primary_fits=0,HGB_fit=0,metric_fit=0,units_fit=0,reference_fit=0,CAL_fit=0,
        query_truth_decision_input=False,query_feature_or_weight_fit=False,
        independent_final_claimed=False,accepted_baseline_replaced=False,status='FAIL_TARGET99',published=False,final_test_executed=False)


def bindings():
    return {str(Path(p).resolve()):h.sha(p) for p in (__file__,aligned.__file__,guard.__file__,aligned.learned.__file__,aligned.dvc.__file__)}


def freeze():
    pins={};known=h.read(KNOWN,pins);reg=h.read(known['registry'],pins)
    h.require(known['own_known_alignment_passed'] and known['prediction_sealed'] and known['unknown_reads']==0,'actual full known alignment passed before unknown')
    qr=h.read(QUERY_REPORT,pins);seal=h.read(qr['prediction_seal'],pins)
    query=seal['predictions'];headers=h.header_tools.npz_headers(h.checked(query,pins))
    h.require(headers['native78']['shape']==[3184,78] and headers['ids']['shape']==[3184],'full genuine feature fixture header')
    assets=dict(query=query,truth_after_seal=TRUTH,model_assets=reg['model_assets'],class_geometry=reg['class_geometry'],envelope=reg['envelope'],
        nativeFIT=reg['native'],metric=known['files']['metric'],units=known['files']['units'],reference=known['files']['reference'],cutoffs=known['files']['cutoffs'])
    for key,value in assets.items():
        if key=='model_assets':
            for a in value.values():h.checked(a,pins)
        else:h.checked(value,pins)
    sources=bindings()
    for p,sha in sources.items():h.checked(dict(path=p,sha256=sha),pins)
    REGDIR.mkdir(parents=True,exist_ok=False)
    return h.json_new(REGDIR/'registry_before_fullDEV_current.json',dict(policy=policy(),known=KNOWN,known_registry=known['registry'],assets=assets,
        sources=sources,input_sha256=pins,output=str(OUT),query_numeric_values_opened=False,query_truth_opened=False))


def gates(truth,prediction):
    result={}
    for index,name in enumerate(('BEN','KNA','UNA')):
        n=int(np.sum(truth==index));c=int(np.sum((truth==index)&(prediction==index)));needed=(99*n+99)//100
        result[name]=dict(correct=c,support=n,required_correct=needed,passed=n>0 and c>=needed,gap=max(0,needed-c))
    return result


def compare(truth,before,after):
    nodes={}
    for index,name in enumerate(('BEN','KNA','UNA')):
        mask=truth==index;nodes[name]=dict(gain=int(np.sum(mask&(before!=index)&(after==index))),loss=int(np.sum(mask&(before==index)&(after!=index))))
    delta={name:n['gain']-n['loss'] for name,n in nodes.items()}
    signs=set(np.sign(list(delta.values())).tolist())
    verdict='MIXED' if -1 in signs and 1 in signs else 'DOWN' if -1 in signs else 'UP' if 1 in signs else 'UNCHANGED'
    return dict(verdict=verdict,correct_count_delta=delta,gain_loss=nodes,scope='same ordered observed3184; changed known training composition and whole pipeline; not controlled isolated effect')


def run(path,sha):
    registry=dict(path=str(Path(path).resolve()),sha256=sha);pins={};began=time.perf_counter();stage='bind'
    report=dict(policy=policy(),registry=registry,files={},model_fits=0,HGB_fit=0,metric_fit=0,units_fit=0,reference_fit=0,CAL_fit=0,
        NN_forward=0,forest_forward=0,HGB_forward=0,new_score=0,DVC=0,prediction_sealed=False,truth_opened=False,
        status='FAIL_TARGET99',published=False,final_test_executed=False,accepted_baseline_replaced=False)
    h.require(not OUT.exists(),'fresh_fullDEV_current_output');OUT.mkdir(parents=True)
    try:
        reg=h.read(registry,pins);h.require(reg['policy']==policy() and reg['sources']==bindings(),'fixed full current source and policy')
        for p,wanted in reg['input_sha256'].items():h.checked(dict(path=p,sha256=wanted),pins)
        torch.set_num_threads(4);stage='restore_same_CPU_model_and_owned_metric'
        a=reg['assets'];saved=torch.load(h.checked(a['model_assets']['NN'],pins),map_location='cpu',weights_only=True)
        net=aligned.nn.network.MHFDNetwork(saved['input_dim'],saved['fine_class_count']);net.load_state_dict(saved['state_dict'],strict=True);net.eval()
        transforms=joblib.load(h.checked(a['model_assets']['preprocessing'],pins));trees=joblib.load(h.checked(a['model_assets']['forest'],pins))
        auxiliary=joblib.load(h.checked(a['model_assets']['HGB'],pins));forest_before=aligned.forest._forest_state(trees)
        metric=aligned.learned.PaperVariationalPairMetric.from_state(h.read(a['metric'],pins))
        units=h.read(a['units'],pins);class_geometry=fine.load(a['class_geometry'],('units','weights'),pins)
        fit=fine.load(a['nativeFIT'],('FIT_native78','FIT_y_fine'),pins)
        zclass=guard.coordinates(fit['FIT_native78'],class_geometry['units'])
        refs={label:zclass[fit['FIT_y_fine']==label] for label in range(9)};weights={label:class_geometry['weights'][label-1] for label in range(1,9)}
        envelope=np.asarray(h.read(a['envelope'],pins)['envelope'],np.float64)
        reference=fine.load(a['reference'],('Z110','true_fine','radius','groups'),pins)
        cut=h.read(a['cutoffs'],pins)['cutoffs']
        stage='complete_original3184_feature_only_CPU_forward'
        data=fine.load(a['query'],('ids','native78'),pins);ids,native=data['ids'],data['native78']
        h.require(len(ids)==3184 and len(np.unique(ids))==3184 and native.shape==(3184,78),'complete unchanged original roster')
        output=aligned.frozen_outputs(net,transforms,trees,native);report['NN_forward']=1;report['forest_forward']=1
        p=fine.fine_probabilities(auxiliary,np.ascontiguousarray(native,np.float32));report['HGB_forward']=1
        primary,proposed,admitted,predf,dben,dfine=guard.class_support(output['main_prediction'],p,envelope,native,class_geometry['units'],refs,weights)
        novel_fine=aligned.novelty_fine(primary,output['neural_fine'],output['forest_fine'],admitted,predf)
        z=np.concatenate((guard.signed_log(native)/np.asarray(units['native78']),output['embedding32'].astype(np.float64)/np.asarray(units['embedding32'])),axis=1)
        groups=aligned.group_hashes(native)
        report['files']['geometry']=h.npz_new(OUT/'actual3184_live_classification_geometry_before_score.npz',dict(ids=ids,native78=native,Z110=z,groups=groups,
            stage1=primary,predicted_fine=novel_fine,guard_admitted=admitted,guard_proposed=proposed,
            neural_probability=output['neural_probability'],main_probability=output['main_probability'],auxiliary_fine=p),{})
        stage='owned110_reference_score_then_canonical_group_density'
        score=aligned.scores(metric,z,novel_fine,reference['Z110'],reference['true_fine'],reference['radius']);report['new_score']=1
        raw=aligned.dvc.candidate_mask(score,primary,cut)
        unique,first,inverse=np.unique(groups,return_index=True,return_inverse=True)
        h.require(np.array_equal(primary,primary[first][inverse]) and np.array_equal(raw,raw[first][inverse]),'duplicate native groups have identical class/candidate decisions')
        routed=aligned.dvc.route_current_candidates(metric,z[first],raw[first],seed=aligned.learned.SEED);report['DVC']=1
        retained=routed['retained'][inverse]
        pred=primary.copy();pred[raw&retained]=2
        report['files']['density_arrays']=h.npz_new(OUT/'canonical_density_before_truth.npz',dict(groups=unique,representative_indices=first,inverse=inverse,
            representative_raw=raw[first],representative_retained=routed['retained'],raw=raw,retained=retained,score=score),{})
        report['files']['DVC_manifest']=h.json_new(OUT/'canonical_DVC_manifest_before_truth.json',routed['manifest'])
        report['files']['predictions']=h.npz_new(OUT/'complete3184_predictions_before_truth.npz',dict(ids=ids,prediction=pred,primary_prediction=primary,raw=raw,retained=retained),{})
        report['files']['prediction_seal']=h.json_new(OUT/'complete3184_prediction_seal_before_truth.json',dict(predictions=report['files']['predictions'],
            owned_known_report=reg['known'],metric=a['metric'],reference=a['reference'],cutoffs=a['cutoffs'],truth_used=False,source_or_difficult_rows_removed=False))
        report['prediction_sealed']=True;stage='postseal_threeclass_scoring'
        truth=fine.load(a['truth_after_seal'],('ids','truth','families','old_comparator','prediction'),pins);report['truth_opened']=True
        h.require(np.array_equal(ids,truth['ids']),'same3184 IDs after complete prediction seal')
        nodes=gates(truth['truth'],pred);primary_nodes=gates(truth['truth'],primary)
        paired=dict(ids=ids,truth=truth['truth'],families=truth['families'],prediction=pred,primary=primary,
                    historical=truth['old_comparator'],previous_failed=truth['prediction'])
        report['files']['postseal_pair']=h.npz_new(OUT/'postseal_complete3184_evaluation_and_comparison.npz',paired,{})
        h.require(all(torch.equal(v.detach().cpu(),saved['state_dict'][k]) for k,v in net.state_dict().items()) and aligned.forest._forest_state(trees)==forest_before,'frozen old model parameters unchanged')
        for p,wanted in pins.items():h.require(h.sha(p)==wanted,'current input pin unchanged:'+p)
        overlap=int(np.sum(np.isin(groups,reference['groups'])))
        report.update(execution_status='owned_live_guard110_full3184_DEV_evaluated',original_class_gates=nodes,primary_classification_diagnostic=primary_nodes,
            all_three_integer99_passed=all(n['passed'] for n in nodes.values()),raw_count=int(raw.sum()),retained_count=int(retained.sum()),
            canonical_density_groups=len(first),raw_density_groups=int(raw[first].sum()),current_known_exact_native78_overlap_rows=overlap,
            overlap_filtering=False,EffectDelta='NOT_COMPARABLE',EffectDelta_reason='same roster, different known training composition and owned pipeline; no automatic baseline promotion',
            descriptive_historical_comparison=compare(truth['truth'],truth['old_comparator'],pred),descriptive_previous_failed_comparison=compare(truth['truth'],truth['prediction'],pred),
            final_independence_admitted=False,training_seconds_this_current=0)
    except Exception as error:
        report.update(execution_status='execution_failed',failed_stage=stage,error_type=type(error).__name__,error=str(error));raise
    finally:
        report.update(input_sha256=pins,wall_seconds=time.perf_counter()-began);h.json_new(OUT/'report.json',report)
    return h.descriptor(OUT/'report.json')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--phase',choices=('freeze','current'),required=True)
    p.add_argument('--registry');p.add_argument('--registry-sha256');a=p.parse_args()
    if a.phase=='current' and (not a.registry or not a.registry_sha256):p.error('current requires frozen registry and SHA')
    print(json.dumps(freeze() if a.phase=='freeze' else run(a.registry,a.registry_sha256)))
