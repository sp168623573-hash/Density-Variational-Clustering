"""Seven distinct same-family source witnesses, source-only paired learning."""
from io34 import *
import time
from sklearn.neighbors import NearestNeighbors
from sklearn.ensemble import HistGradientBoostingClassifier
def check():assert time.time()<float(os.environ['R34_DEADLINE'])-20,'CUMULATIVE_DEADLINE'
def features(a,z,b,w,fields):
    diff=a-b
    return np.column_stack((np.log1p(np.column_stack([np.mean(diff[:,f]**2,axis=1) for f in fields])),np.abs(z-w),(a.astype(float)+b.astype(float))*.5))
def split(ids,fine):
    fit=[];qa=[]
    for f in np.unique(fine):
        at=sorted(np.flatnonzero(fine==f),key=lambda j:hashlib.sha256(str(ids[j]).encode()).hexdigest());k=max(1,int(len(at)*2/3));fit+=at[:k];qa+=at[k:]
    return np.array(fit),np.array(qa)
def weights(width,fields):
    v=np.zeros(width)
    for cols in fields:v[cols]=1/np.sqrt(len(cols))
    return v
def make_pairs(x,y,query,refs,fields,self_exclude):
    w=weights(x.shape[1],fields);left=[];right=[];target=[]
    for f in np.unique(y):
        rows=query[y[query]==f]
        for same in (True,False):
            bank=refs[(y[refs]==f) if same else (y[refs]!=f)];k=min(8 if self_exclude and same else 7,len(bank))
            if not len(rows) or not k:continue
            nn=NearestNeighbors(n_neighbors=k,algorithm='brute',n_jobs=1).fit(x[bank]*w).kneighbors(x[rows]*w,return_distance=False)
            for row,near in zip(rows,nn):
                candidates=[j for j in bank[near] if j!=row][:7];left.extend([row]*len(candidates));right.extend(candidates);target.extend([int(same)]*len(candidates))
    return np.array(left,int),np.array(right,int),np.array(target,int)
def finite99(v,y):
    result=[]
    for c in (0,1):
        a=np.sort(v[y==c]);rank=(99*(len(a)+1)+99)//100
        result.append(dict(coarse=c,parents=len(a),rank=rank,cut=float(a[rank-1]) if 0<rank<=len(a) else 1.,enabled=bool(0<rank<=len(a))))
    return result
def fit(s,fields):
    x,z,y=s['x'],s['z'],s['fine'];f,v=s['fit'],s['qa'];l,r,t=make_pairs(x,y,f,f,fields,True);code=l*2+t;cnt=np.bincount(code,minlength=len(x)*2)
    model=HistGradientBoostingClassifier(max_iter=80,max_leaf_nodes=15,learning_rate=.08,min_samples_leaf=20,l2_regularization=1.,early_stopping=False,random_state=20261031)
    model.fit(features(x[l],z[l],x[r],z[r],fields),t,sample_weight=1/cnt[code]);vl,vr,vt=make_pairs(x,y,v,f,fields,False)
    prob=model.predict_proba(features(x[vl],z[vl],x[vr],z[vr],fields))[:,1];maximum=np.full(len(x),-np.inf);np.maximum.at(maximum,vl[vt==0],prob[vt==0]);assert np.isfinite(maximum[v]).all()
    cuts=finite99(maximum[v],(y[v]>0).astype(int))
    return model,dict(left=l,right=r,target=t,val_left=vl,val_right=vr,val_target=vt,val_probability=prob),dict(cut=max(c['cut'] for c in cuts),classes=cuts)
def score(model,x,z,s,fields,refs):
    # Exact exhaustive search. The seventh affinity requires seven real distinct groups,
    # unlike a single high-scoring anchor or repeated optimizer slots.
    fine=np.zeros((len(x),9));top=np.full((len(x),9,7),-1,int)
    for first in range(0,len(x),32):
        check();rows=np.arange(first,min(first+32,len(x)));l=np.repeat(rows,len(refs));r=np.tile(refs,len(rows))
        prob=model.predict_proba(features(x[l],z[l],s['x'][r],s['z'][r],fields))[:,1].reshape(len(rows),len(refs))
        for f in range(9):
            indices=np.flatnonzero(s['fine'][refs]==f)
            if len(indices)<7:continue
            p=prob[:,indices];order=np.argsort(-p,axis=1,kind='stable')[:,:7];top[rows,f]=refs[indices[order]];fine[rows,f]=np.take_along_axis(p,order,axis=1)[:,-1]
        if first%512==0:print('SOURCE_AFFINITY',first,'/',len(x),flush=True)
    coarse=np.column_stack((fine[:,0],fine[:,1:].max(1)))
    return dict(fine_affinity=fine,source_neighbors=top,coarse_affinity=coarse,nonconformity=1-coarse)
def neighbors_guard(model,q,g,fields,paircut,raw):
    rep,inv,near=g['reps'],g['inverse'],g['neighbors'];seed=np.ones(len(rep),bool);np.logical_and.at(seed,inv,q['seed_parent']==2)
    edge=np.zeros((len(rep),7),bool);prob=np.full((len(rep),7),np.nan)
    for j in np.unique(inv[raw]):
        p=model.predict_proba(features(np.repeat(q['x'][rep[j]][None,:],7,axis=0),np.repeat(q['z'][rep[j]][None,:],7,axis=0),q['x'][rep[near[j]]],q['z'][rep[near[j]]],fields))[:,1]
        prob[j]=p;edge[j]=seed[near[j]]&(p>paircut)
    return dict(edge_affinity=prob,certified_edges=edge,certified_count=edge.sum(1)[inv])
def ben_certificate(q,sc,s,fields,refs,cuts):
    # Original UNA risk veto plus a native reciprocal neighborhood, in addition to
    # seven coherent learned-source witnesses and zero observed opposite-known CAL acceptance.
    a=sc['coarse_affinity'];score=a[:,0]-a[:,1];mask=(q['parent']!=0)&~q['risk']&(a[:,0]>cuts['BEN_false_affinity_max'])&(score>cuts['BEN_false_margin_max'])
    weight=weights(s['x'].shape[1],fields);index=NearestNeighbors(n_neighbors=8,algorithm='brute',n_jobs=1).fit(s['x'][refs]*weight)
    out=np.zeros(len(mask),bool);mutual=np.zeros(len(mask),int);near_all=np.full((len(mask),7),-1,int);distance_all=np.full((len(mask),7),np.nan);radius_all=np.full((len(mask),7),np.nan)
    at=np.flatnonzero(mask)
    if len(at):
        distance,near=index.kneighbors(q['x'][at]*weight,n_neighbors=7)
        for row,ds,ns in zip(at,distance,near):
            src=refs[ns];near_all[row]=src;distance_all[row]=ds
            if not np.all(s['fine'][src]==0):continue
            sd,si=index.kneighbors(s['x'][src]*weight,n_neighbors=8)
            radius=[]
            for j,rr in enumerate(src):radius.append(sd[j,refs[si[j]]!=rr][:7][-1])
            radius_all[row]=radius;mutual[row]=int(np.sum(ds<radius));out[row]=mutual[row]>=4
    return dict(BEN_proposal=out,BEN_eligible_before_native=mask,BEN_native_mutual=mutual,BEN_native_neighbors=near_all,BEN_native_distances=distance_all,BEN_native_radii=radius_all)
