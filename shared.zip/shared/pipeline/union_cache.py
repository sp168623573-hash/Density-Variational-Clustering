"""Compute unchanged pair distances once on a query union, never add DVC vertices."""
from metric_cache import ReuseMetric
import numpy as np
class UnionMetric(ReuseMetric):
    def __init__(self,metric,query):
        super().__init__(metric);self.union=np.unique(np.asarray(query,np.float64),axis=0);self.prefetched=False
    def pairwise_distances(self,x,reference=None,**kw):
        if reference is None and not self.prefetched:
            self.prefetched=True;super().pairwise_distances(self.union,**kw)
        return super().pairwise_distances(x,reference,**kw)
def fixture(metric,query):
    query=np.asarray(query)[:64];u=UnionMetric(metric,query);indices=(np.arange(0,len(query),2),np.arange(1,len(query),3),np.array([3,3,2,0,7]))
    for ix in indices:
        direct=metric.pairwise_distances(query[ix]);cached=u.pairwise_distances(query[ix]);assert np.array_equal(direct,cached)
    centers=query[:4].mean(0,keepdims=True);assert np.array_equal(u.pairwise_distances(query[:9],centers),metric.pairwise_distances(query[:9],centers))
    return dict(every_fixture_distance_bitwise_equal=True,duplicates_and_rectangles_checked=True,only_distance_computation_cached=True,no_DVC_vertices_added=True)
