from io34 import *
import warm_base as W
import context_block as C
import torch
BIND=read(I/'continuation_closeout_20261103_r95/CONTINUATION_MODEL_BINDINGS.json')['settings']
def source_path(s):return Path(BIND[s]['source_roster']['path'])
def restore(s,A):
    net,owner=W.restore(s,A)
    if s=='CIC2':C.install(net,s,'pointwise_control')
    b=BIND[s];net.load_state_dict(torch.load(b['neural_checkpoint']['path'],map_location='cpu',weights_only=False)['state'],strict=True);net.eval();owner=dict(owner,model=b['neural_checkpoint'],source_forward=b['neural_source_forward']);return net,owner
infer=W.infer;split_source=W.split_source
def metric(s):
    b=BIND[s];L=mod(b['own_metric_module']['path'],'r99_owned_'+s);m=L.PaperVariationalPairMetric.from_state(read(b['own_metric']['path']));z=load(b['source_geometry']['path']);return m,z['units']
def raw(s,A,data,role=None):
    if s=='NSL2':return np.asarray(data['x'],float)
    original=A.A.load_source() if role is None else A.A.load_role(role);lookup={str(x):j for j,x in enumerate(original['ids'])};at=np.array([lookup[str(x)] for x in data['ids']]);return original['native' if s=='CIC2' else 'N'][at].astype(float)
