from io34 import *
import cssr_model as C
import normalization_model as N
import torch,time
from torch.nn import functional as F
from scipy.special import logsumexp,softmax
import paper_methods as P
KINDS=('unbounded','bounded');METHODS=('arpl_logit','arpl_msp','fine_msp','coarse_msp','knn');EPOCHS=40;SEED=20261185;PARENT=I/'semantic_reconstruction_20261103_r65/CIC2/reciprocal/reciprocal'
split_source=N.split_source
class Model(torch.nn.Module):
    def __init__(self,backbone,kind):
        super().__init__();self.backbone=backbone;self.kind=kind
        for p in backbone.aes.parameters():p.requires_grad_(False)
        old=torch.random.get_rng_state();torch.manual_seed(SEED);self.points=torch.nn.Parameter(.1*torch.randn(9,32));self.radius=torch.nn.Parameter(torch.zeros(1));torch.random.set_rng_state(old)
    def forward(self,x):
        o=self.backbone(x);h=o['embedding'];dot=h@self.points.T;d=(h.square().sum(1,keepdim=True)-2*dot+self.points.square().sum(1)[None])/h.shape[1];return dict(embedding=h,coarse_logits=o['coarse_logits'],fine_logits=o['fine_logits'],reconstruction=o['reconstruction'],reciprocal_logits=d-dot)
    def forward_masked(self,x,which):return self.backbone.forward_masked(x,which)
def make(A,kind):
    backbone,owner=C.load_model('CIC2',A,'reciprocal',PARENT);return Model(backbone,kind),dict(owner,model=desc(PARENT/'model.pt'),training_receipt=desc(PARENT/'TRAINING.json'))
@torch.no_grad()
def infer(net,x):
    net.eval();out={k:[] for k in ('embedding','coarse_logits','fine_logits','reciprocal_logits')}
    for start in range(0,len(x),128):
        o=net(torch.tensor(x[start:start+128],dtype=torch.float32))
        for k in out:out[k].append(o[k].numpy().astype(float))
    return {k:np.concatenate(v) for k,v in out.items()}
def validate(net,x,s):
    at=s['validation'];out=infer(net,x[at]);fine=s['fine'][at];y=(fine>0).astype(int);recalls=[]
    for p in (out['coarse_logits'].argmax(1),out['reciprocal_logits'].argmax(1)>0):
        recalls.extend(float(np.mean(p[y==c]==c)) for c in (0,1))
    r=out['reciprocal_logits'];ce=float(np.mean(logsumexp(r,1)-r[np.arange(len(at)),fine]));return (min(recalls),sum(recalls)/4,-ce),dict(original_and_reciprocal_coarse_recalls=recalls,arpl_fine_correct=int(np.sum(r.argmax(1)==fine)),arpl_CE=ce,rows=len(at))
def load_model(A,kind,folder):
    net,owner=make(A,kind);net.load_state_dict(torch.load(folder/'model.pt',map_location='cpu',weights_only=False)['model']);return net.eval(),owner
def train(A,s,x,kind,folder,check):
    start=time.perf_counter();net,owner=make(A,kind);core=net.backbone.core;fit=s['fit'];fields=[np.flatnonzero(r.detach().numpy()).tolist() for r in core.field_column_membership];rows=list(fit)
    for f in np.unique(s['fine'][fit]):
        at=fit[s['fine'][fit]==f]
        if len(at)<20:rows.extend(np.resize(at,20-len(at)).tolist())
    rows=np.asarray(rows,int);assert len(rows)<=6000 and set(rows)<=set(fit) and not set(rows)&set(s['original_qa']);mult=np.bincount(rows,minlength=len(x));fine=s['fine'];fw=torch.tensor(len(rows)/(9*np.bincount(fine[rows],minlength=9)),dtype=torch.float32);cw=torch.tensor(len(rows)/(2*np.bincount((fine[rows]>0).astype(int),minlength=2)),dtype=torch.float32);rms=np.sqrt(np.mean(x[fit].astype(float)**2,axis=0));scale=torch.tensor(np.where(rms>0,rms,1.),dtype=torch.float32);params=[p for p in net.parameters() if p.requires_grad];opt=torch.optim.AdamW(params,lr=3e-4,weight_decay=2e-4);scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(opt,EPOCHS,eta_min=3e-5);rng=np.random.default_rng(SEED);bestkey,bestreport=validate(net,x,s);best={k:v.detach().clone() for k,v in net.state_dict().items()};bestepoch=0;history=[];orders=[];masks=[]
    for ep in range(EPOCHS):
        net.train();order=rng.permutation(rows);which=np.arange(len(order))%len(fields);rng.shuffle(which);orders.append(order);masks.append(which);losses=np.zeros(6)
        for step,first in enumerate(range(0,len(order),128)):
            check();at=order[first:first+128];xx=torch.tensor(x[at]);y=torch.tensor(fine[at],dtype=torch.long);cy=(y>0).long();mf=torch.tensor(which[first:first+len(at)],dtype=torch.long);torch.manual_seed(SEED+ep*10000+step);o=net(xx);masked=net.forward_masked(xx,mf);pw=torch.tensor(1/mult[at],dtype=torch.float32);lc=(F.cross_entropy(o['coarse_logits'],cy,reduction='none')*cw[cy]).sum()/cw[cy].sum();lf=(F.cross_entropy(o['fine_logits'],y,label_smoothing=.01,reduction='none')*fw[y]).sum()/fw[y].sum();la=(F.cross_entropy(o['reciprocal_logits'],y,reduction='none')*fw[y]).sum()/fw[y].sum();known_distance=(o['embedding']-net.points[y]).square().mean(1);margin=(F.relu(known_distance-net.radius+1)*pw).sum()/pw.sum();err=F.smooth_l1_loss(masked['reconstruction']/scale,xx/scale,reduction='none');rr=(err*masked['masked_columns']).sum(1)/masked['masked_columns'].sum(1);rec=(rr*pw).sum()/pw.sum();loss=lc+.35*lf+.35*(la+(.1*margin if kind=='bounded' else 0))+.03*rec;assert torch.isfinite(loss);opt.zero_grad(set_to_none=True);loss.backward();grad=torch.nn.utils.clip_grad_norm_(params,5.);assert torch.isfinite(grad);opt.step();losses+=np.array([float(v.detach()) for v in (loss,lc,lf,la,margin,rec)])*len(at)
        scheduler.step();key,valid=validate(net,x,s)
        if key>bestkey:bestkey=key;bestreport=valid;best={k:v.detach().clone() for k,v in net.state_dict().items()};bestepoch=ep+1
        history.append(dict(epoch=ep+1,losses=losses/len(order),validation=valid,radius=float(net.radius.detach()),selected_epoch=bestepoch,seconds=time.perf_counter()-start));print('ARPL_TRAIN',kind,history[-1],flush=True)
    net.load_state_dict(best);out=infer(net,x)
    with (folder/'model.pt').open('xb') as f:torch.save(dict(model=net.state_dict(),kind=kind,selected_epoch=bestepoch,seed=SEED),f)
    save(folder/'source_outputs.npz',ids=s['ids'],**out);save(folder/'optimizer_parent_map.npz',ids=s['ids'],FIT=fit,validation=s['validation'],QA_calibration=s['qa'],original_QA=s['original_qa'],epoch_optimizer_indices=np.stack(orders),masked_physical_fields=np.stack(masks));save(folder/'reconstruction_units.npz',scale=scale.numpy());put(folder/'TRAINING.json',dict(kind=kind,history=history,selected_epoch=bestepoch,selected_validation=bestreport,seconds=time.perf_counter()-start,source_parent=owner['model'],genuine_FIT=len(fit),optimizer_slots=len(rows),radius=float(net.radius.detach()),reciprocal_points_are_parameters_not_traffic=True,confusing_samples_generated_or_trained=0,**STATUS));return net,out,owner
reference=N.reference
def scores(out,ref):
    sc=N.scores(out,ref);l=out['reciprocal_logits'];sc.update(arpl_logit=-l.max(1),arpl_msp=1-softmax(l,axis=1).max(1));return sc
def calibrate(cal,y,ix,qa,sy):
    old=P.METHODS
    try:P.METHODS=METHODS;return P.calibrate(cal,y,ix,qa,sy)
    finally:P.METHODS=old
def fixtures():
    torch.manual_seed(85);x=torch.randn(5,32,dtype=torch.float64);p=torch.randn(9,32,dtype=torch.float64)*.1;dot=x@p.T;d=(x.square().sum(1,keepdim=True)-2*dot+p.square().sum(1)[None])/32;assert torch.allclose(d,(x[:,None]-p[None]).square().mean(2),atol=1e-12,rtol=1e-12);r=torch.tensor(.2,dtype=torch.float64);dy=d[:,0];assert torch.equal(F.relu(dy-r+1),F.margin_ranking_loss(r.expand_as(dy),dy,torch.ones_like(dy),margin=1.,reduction='none'));return dict(author_normalized_L2_minus_raw_dot_formula=True,margin_ranking_hinge_equivalence=True,only_known_class_targets=True,no_GAN_no_fake_unknown_training=True)
