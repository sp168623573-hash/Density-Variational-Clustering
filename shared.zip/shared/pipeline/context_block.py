"""1-D ConvNeXt-inspired residual refinement inside the original CNN branch."""
from io34 import *
import torch
from torch import nn
class ContextConv(nn.Module):
    def __init__(self,base,channels,context):
        super().__init__();self.base=base
        self.depthwise=nn.Conv1d(channels,channels,7,padding=3,groups=channels)
        self.norm=nn.LayerNorm(channels,eps=1e-6)
        self.expand=nn.Linear(channels,4*channels);self.act=nn.GELU();self.project=nn.Linear(4*channels,channels)
        mask=torch.ones_like(self.depthwise.weight)
        if not context:mask.zero_();mask[:,:,3]=1
        self.register_buffer('context_mask',mask);nn.init.zeros_(self.project.weight);nn.init.zeros_(self.project.bias)
    def forward(self,x):
        base=self.base(x);z=torch.nn.functional.conv1d(base,self.depthwise.weight*self.context_mask,self.depthwise.bias,padding=3,groups=base.shape[1]);z=self.project(self.act(self.expand(self.norm(z.transpose(1,2))))).transpose(1,2)
        return base+z
def install(net,setting,kind):
    root=net.backbone.core if setting=='CIC2' else net
    assert not isinstance(root.conv,ContextConv)
    torch.manual_seed(20261193);root.conv=ContextConv(root.conv,root.sequence.input_size,kind=='context7');return net
def fixtures():
    torch.manual_seed(93);net=ContextConv(nn.Identity(),4,True).double();x=torch.randn(2,4,19,dtype=torch.float64);assert torch.equal(net(x),x)
    with torch.no_grad():net.project.weight.normal_(std=.1)
    y=net(x);ref=[]
    for j in range(19):
        v=net.depthwise.bias.clone()
        for k in range(7):
            pos=j+k-3
            if 0<=pos<19:v=v+x[:,:,pos]*net.depthwise.weight[:,0,k]
        ref.append(net.project(net.act(net.expand(net.norm(v)))))
    assert torch.allclose(y,x+torch.stack(ref,2),atol=1e-12,rtol=1e-12)
    control=ContextConv(nn.Identity(),4,False).double();control.load_state_dict(dict(net.state_dict(),context_mask=control.context_mask));a=control(x);changed=x.clone();changed[:,:,7]+=1.;b=control(changed);keep=torch.arange(19)!=7;assert torch.equal(a[:,:,keep],b[:,:,keep]);assert not torch.equal(y[:,:,6],net(changed)[:,:,6])
    (net(x).square().mean()).backward();assert torch.isfinite(net.depthwise.weight.grad).all();return dict(zero_init_exact_identity=True,one_dimensional_kernel_matches_literal=True,pointwise_control_no_crossfield_response=True,context_response_present=True)
