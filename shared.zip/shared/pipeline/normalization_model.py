"""One physical field per MHFD/CNN-LSTM token; all encoded inputs retained."""
from io34 import *
import torch,time,types,copy
from torch.nn import functional as F
from scipy.spatial.distance import cdist
from scipy.special import logsumexp
import field_probe as Base
import paper_methods as P
KINDS=('post','pre','peri')
METHODS=('fine_msp','coarse_msp','knn')
EPOCHS=40
SEED=20261160

def split_source(s):
    s=dict(s);old=s['qa'].copy();valid=[];cal=[]
    for c in (0,1):
        at=old[(s['fine'][old]>0)==c];ordered=sorted(at,key=lambda i:hashlib.sha256(('R58_source_roles:'+str(s['groups'][i])).encode()).digest());mid=len(ordered)//2;valid.extend(ordered[:mid]);cal.extend(ordered[mid:]);assert min(mid,len(ordered)-mid)>=99
    s['original_qa']=old;s['validation']=np.asarray(sorted(valid),int);s['qa']=np.asarray(sorted(cal),int);assert not set(valid)&set(cal);return s
def install(net,fields,physical=False,normalization='post'):
    width=net.feature_weight.shape[0];matrix=np.zeros((len(fields),width),np.float32)
    for j,cols in enumerate(fields):matrix[j,cols]=1
    assert np.all(matrix.sum(0)==1);membership=net.field_column_membership.detach().cpu().numpy();mapping=[]
    for row in matrix:
        matches=np.flatnonzero(np.all(membership==row.astype(bool),axis=1));assert len(matches)==1;mapping.append(int(matches[0]))
    assert len(set(mapping))==len(fields)==len(membership)
    group=torch.tensor(matrix);mean=group/group.sum(1,keepdim=True);bias=mean@(net.feature_bias.detach()+net.position.detach());mask=net.field_mask_tokens.detach()[mapping]-mean@net.feature_bias.detach()
    net.register_buffer('physical_membership',group);net.register_buffer('physical_mask_index',torch.tensor(mapping));net.physical_bias=torch.nn.Parameter(bias.clone());net.physical_mask_value=torch.nn.Parameter(mask.clone());net._physical_mode=physical;net._normalization_mode=normalization
    if normalization=='peri':net.attention_output_norm=copy.deepcopy(net.attention_norm)
    def forward_body(self,x,which=None):
        assert x.dtype==torch.float32 and x.ndim==2 and x.shape[1]==self.feature_count and torch.isfinite(x).all();self._map_check()
        extra=self.num_embedding(x) if hasattr(self,'num_embedding') else torch.zeros((len(x),self.feature_count,self.feature_weight.shape[1]),dtype=x.dtype)
        if self._physical_mode:
            value=x[...,None]*self.feature_weight[None]+extra;tokens=torch.einsum('bfd,kf->bkd',value,self.physical_membership)+self.physical_bias[None]
            if which is not None:
                hidden=self.physical_membership[which].bool();masktoken=self.physical_mask_value[which]+self.physical_bias[which];select=F.one_hot(which,len(fields)).bool();tokens=torch.where(select[:,:,None],masktoken[:,None,:],tokens)
        elif which is None:tokens=x[...,None]*self.feature_weight[None]+self.feature_bias[None]+self.position[None]+extra
        else:
            tokens,hidden=self.masked_tokens(x,self.physical_mask_index[which]);tokens=tokens+torch.where(hidden[:,:,None],torch.zeros_like(extra),extra)
        if self._normalization_mode=='post':
            attended,_=self.attention(tokens,tokens,tokens,need_weights=False);gate=self.gate(attended);enhanced=self.attention_norm(tokens+self.dropout(attended)*gate)
        else:
            normalized=self.attention_norm(tokens);attended,_=self.attention(normalized,normalized,normalized,need_weights=False);gate=self.gate(attended);branch=self.attention_output_norm(attended) if self._normalization_mode=='peri' else attended;enhanced=tokens+self.dropout(branch)*gate
        conv=self.conv(enhanced.transpose(1,2)).transpose(1,2);seq,_=self.sequence(conv);weights=torch.softmax(self.pool_score(seq).squeeze(-1),1);h=self.embedding((seq*weights[:,:,None]).sum(1));result=dict(embedding=h,coarse_logits=self.coarse_head(h),fine_logits=self.fine_head(h),reconstruction=self.decoder(h),gate_mean=gate.mean((1,2)))
        if which is not None:result['masked_columns']=hidden
        return result
    def clean(self,x):return forward_body(self,x)
    def masked(self,x,which):return forward_body(self,x,which)
    net.forward=types.MethodType(clean,net);net.forward_masked=types.MethodType(masked,net);return net
def restore(setting,A):
    net,owner=Base.restore(setting,A)
    if setting in ('CIC2','NSL2'):
        path=I/'instance_representation_20261103_r58/CIC2/SCARF_joint' if setting=='CIC2' else I/'physical_fields_20261103_r60/NSL2/coordinate/coordinate';net.add_module('scarf_projector',torch.nn.Sequential(torch.nn.Linear(32,128),torch.nn.ReLU(),torch.nn.Linear(128,128)));saved=torch.load(path/'model.pt',map_location='cpu',weights_only=False)['core'];saved={k:v for k,v in saved.items() if not k.startswith('physical_')};net.load_state_dict(saved,strict=True);net.eval();owner=dict(owner,model=desc(path/'model.pt'),training_receipt=desc(path/'TRAINING.json'),source_forward=desc(path/'source_outputs.npz'))
    return net,owner
def infer(net,x):return Base.infer(net,x)
def load_model(setting,A,kind,folder):
    net,owner=restore(setting,A);fields=[np.flatnonzero(row.detach().cpu().numpy()).tolist() for row in net.field_column_membership];install(net,fields,False,kind);net.load_state_dict(torch.load(folder/'model.pt',map_location='cpu',weights_only=False)['core'],strict=True);net.eval();return net,owner
def validation(net,x,s):
    at=s['validation'];out=infer(net,x[at]);y=(s['fine'][at]>0).astype(int);p=out['coarse_logits'].argmax(1);r=[float(np.mean(p[y==c]==c)) for c in (0,1)];l=out['coarse_logits'];ce=float(np.mean(logsumexp(l,axis=1)-l[np.arange(len(y)),y]));return (min(r),sum(r)/2,-ce),dict(rows=len(y),coarse_recall=r,coarse_correct=int(np.sum(p==y)),fine_correct=int(np.sum(out['fine_logits'].argmax(1)==s['fine'][at])),coarse_CE=ce)
def train(setting,A,s,x,kind,folder,check):
    started=time.perf_counter();net,owner=restore(setting,A);fields=[np.flatnonzero(row.detach().cpu().numpy()).tolist() for row in net.field_column_membership];initial=infer(net,x[s['fit'][:32]]);install(net,fields,False,kind);net.eval();parity=infer(net,x[s['fit'][:32]])
    if kind=='post':assert all(np.allclose(initial[k],parity[k],atol=5e-5,rtol=5e-5) for k in initial)
    sample=torch.tensor(x[s['fit'][:32]]);which=torch.arange(len(sample))%len(fields);other=sample.clone();hidden=net.physical_membership[which].bool();other[hidden]=torch.roll(sample,1,0)[hidden]
    with torch.no_grad():one=net.forward_masked(sample,which);two=net.forward_masked(other,which)
    assert torch.equal(one['masked_columns'],hidden) and all(torch.equal(one[k],two[k]) for k in ('embedding','coarse_logits','fine_logits','reconstruction')),'HIDDEN_FIELD_VALUE_LEAK'
    fit=s['fit'];rows=list(fit)
    for f in np.unique(s['fine'][fit]):
        at=fit[s['fine'][fit]==f]
        if len(at)<20:rows.extend(np.resize(at,20-len(at)).tolist())
    rows=np.asarray(rows,int);assert len(rows)<=6000 and set(rows)<=set(fit) and not set(rows)&set(s['original_qa']);count=np.bincount(s['fine'][rows],minlength=9);fw=torch.tensor(len(rows)/(9*count),dtype=torch.float32);coarse=(s['fine']>0).astype(int);cw=torch.tensor(len(rows)/(2*np.bincount(coarse[rows],minlength=2)),dtype=torch.float32);multiplicity=np.bincount(rows,minlength=len(x));scale=np.ones(x.shape[1])
    for cols in fields:
        if len(cols)==1:
            v=float(np.sqrt(np.mean(x[fit,cols[0]].astype(float)**2)));scale[cols]=v if v>0 else 1.
    scale=torch.tensor(scale,dtype=torch.float32);params=list(net.parameters());opt=torch.optim.AdamW(params,lr=3e-4,weight_decay=2e-4);scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(opt,EPOCHS,eta_min=3e-5);rng=np.random.default_rng(SEED);best_key,best_report=validation(net,x,s);best={k:v.detach().clone() for k,v in net.state_dict().items()};best_epoch=0;history=[];orders=[];masks=[]
    for epoch in range(EPOCHS):
        net.train();order=rng.permutation(rows);logical=np.arange(len(order))%len(fields);rng.shuffle(logical);orders.append(order);masks.append(logical);losses=np.zeros(4)
        for step,start in enumerate(range(0,len(order),128)):
            check();at=order[start:start+128];field=torch.tensor(logical[start:start+len(at)],dtype=torch.long);features=torch.tensor(x[at]);y=torch.tensor(s['fine'][at],dtype=torch.long);c=(y>0).long();torch.manual_seed(SEED+epoch*10000+step);out=net(features);masked=net.forward_masked(features,field);lc=(F.cross_entropy(out['coarse_logits'],c,reduction='none')*cw[c]).sum()/cw[c].sum();lf=(F.cross_entropy(out['fine_logits'],y,label_smoothing=.01,reduction='none')*fw[y]).sum()/fw[y].sum();err=F.smooth_l1_loss(masked['reconstruction']/scale,features/scale,reduction='none');row=(err*masked['masked_columns']).sum(1)/masked['masked_columns'].sum(1);pw=torch.tensor(1/multiplicity[at],dtype=torch.float32);lr=(row*pw).sum()/pw.sum();loss=lc+.35*lf+.03*lr;assert torch.isfinite(loss)
            opt.zero_grad(set_to_none=True);loss.backward();grad=torch.nn.utils.clip_grad_norm_(params,5.);assert torch.isfinite(grad);opt.step();losses+=np.array([float(v.detach()) for v in (loss,lc,lf,lr)])*len(at)
        scheduler.step();key,valid=validation(net,x,s)
        if key>best_key:best_key=key;best_report=valid;best={k:v.detach().clone() for k,v in net.state_dict().items()};best_epoch=epoch+1
        history.append(dict(epoch=epoch+1,losses=losses/len(order),validation=valid,selected_best_epoch=best_epoch,seconds=time.perf_counter()-started));print('PHYSICAL_TRAIN',setting,kind,history[-1],flush=True)
    net.load_state_dict(best,strict=True);net.eval();out=infer(net,x)
    with (folder/'model.pt').open('xb') as f:torch.save(dict(core=net.state_dict(),kind=kind,attempted_epochs=EPOCHS,selected_epoch=best_epoch,fields=fields,seed=SEED),f)
    save(folder/'source_outputs.npz',ids=s['ids'],**out);save(folder/'optimizer_parent_map.npz',ids=s['ids'],FIT=fit,validation=s['validation'],QA_calibration=s['qa'],original_QA=s['original_qa'],epoch_optimizer_indices=np.stack(orders),masked_physical_field=np.stack(masks));save(folder/'reconstruction_units.npz',scale=scale.numpy())
    return net,out,dict(kind=kind,attempted_epochs=EPOCHS,selected_epoch=best_epoch,history=history,selected_validation=best_report,seconds=time.perf_counter()-started,encoded_width=x.shape[1],sequence_tokens=x.shape[1],normalization_mode=kind,physical_fields=len(fields),all_encoded_coordinates_used=True,masked_field_value_invariance_exact=True,classification_labels=['BEN','KNA'],genuine_FIT=len(fit),optimizer_slots=len(rows),source_parent=owner['model'],validation_and_calibration_QA_disjoint=True)
def reference(out,s):
    h=out['embedding'];fit=s['fit'];mean=h[fit].mean(0);sd=h[fit].std(0,ddof=1);sd=np.where(sd>0,sd,1.);return dict(mean=mean,scale=sd,source_h=(h[fit]-mean)/sd,source_indices=fit)
def scores(out,ref):
    l=out['fine_logits'];c=out['coarse_logits'];d=cdist((out['embedding']-ref['mean'])/ref['scale'],ref['source_h']);return dict(fine_msp=1-np.exp(l-logsumexp(l,axis=1)[:,None]).max(1),coarse_msp=1-np.exp(c-logsumexp(c,axis=1)[:,None]).max(1),knn=np.partition(d,6,axis=1)[:,6],predicted_coarse=c.argmax(1))
def calibrate(cal,y,ix,qa,sy):
    old=P.METHODS
    try:P.METHODS=METHODS;return P.calibrate(cal,y,ix,qa,sy)
    finally:P.METHODS=old
def fixtures():
    rng=np.random.default_rng(60);x=np.array([[1.,0.,0.,2.],[0.,1.,0.,-1.]]);w=rng.normal(size=(4,16));bias=rng.normal(size=(2,16));a=np.stack((x[:,:3]@w[:3],x[:,3,None]*w[3]),1)+bias
    extended=np.column_stack((x[:,:3],np.zeros(len(x)),x[:,3]));ww=np.vstack((w[:3],rng.normal(size=(1,16)),w[3:]));b=np.stack((extended[:,:4]@ww[:4],extended[:,4,None]*ww[4]),1)+bias;assert np.array_equal(a,b)
    return dict(inactive_onehot_column_adds_no_value_token_or_mass=True,field_bias_independent_of_vocabulary_size=True,source_mask_field_binding_checked_before_training=True)

def normalization_fixtures():
    torch.manual_seed(62);t=torch.randn(3,5,16,dtype=torch.float64);attention=torch.nn.MultiheadAttention(16,4,batch_first=True,dropout=0).double().eval();norm=torch.nn.LayerNorm(16,eps=1e-12).double();outnorm=torch.nn.LayerNorm(16,eps=1e-12).double();gate=torch.nn.Sequential(torch.nn.Linear(16,16),torch.nn.Sigmoid()).double()
    def block(x,mode):
        if mode=='post':
            a,_=attention(x,x,x,need_weights=False);return norm(x+a*gate(a))
        z=norm(x);a,_=attention(z,z,z,need_weights=False);return x+(outnorm(a) if mode=='peri' else a)*gate(a)
    with torch.no_grad():
        for mode in ('pre','peri'):assert torch.allclose(block(7*t,mode)-block(t,mode),6*t,atol=1e-9,rtol=1e-9)
        assert torch.allclose(block(t,'post').square().mean(-1),torch.ones((3,5),dtype=torch.float64),atol=1e-9)
    return dict(raw_token_scale_change_survives_pre_and_gated_peri_residual=True,post_norm_controls_each_token_magnitude=True,MHFD_gate_outside_branch_output_norm=True,no_claim_final_encoder_is_invertible_or_OOD_improved=True)
