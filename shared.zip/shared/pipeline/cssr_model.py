"""Known-only CSSR-style semantic sequence reconstruction inside the paper core."""
from io34 import *
import normalization_model as N
import torch,time,copy,math
from torch.nn import functional as F
from scipy.spatial.distance import cdist
from scipy.special import logsumexp
import paper_methods as P
KINDS=('prototype','reciprocal'); METHODS=('reconstruction','cssr_msp','fine_msp','coarse_msp','knn'); EPOCHS=40; SEED=N.SEED
split_source=N.split_source
restore=N.restore

class Model(torch.nn.Module):
    def __init__(self,core,kind):
        super().__init__();self.core=core;self.kind=kind;self.width=core.sequence.hidden_size*(2 if core.sequence.bidirectional else 1);self.latent=max(1,self.width//4);self.aes=torch.nn.ModuleList([torch.nn.Sequential(torch.nn.Linear(self.width,self.latent,bias=False),torch.nn.Tanh(),torch.nn.Linear(self.latent,self.width,bias=False)) for _ in range(9)]);self._sequence=None;core.sequence.register_forward_hook(self.capture)
    def capture(self,module,args,output):self._sequence=output[0]
    def forward(self,x):
        out=self.core(x);seq=self._sequence;assert seq is not None;self._sequence=None;errors=torch.stack([(seq-ae(seq)).abs().sum(-1) for ae in self.aes],-1);signed=(-.1 if self.kind=='prototype' else .1)*errors;tokenlog=F.log_softmax(signed,dim=-1);logprob=torch.logsumexp(tokenlog,dim=1)-math.log(seq.shape[1]);pred=logprob.argmax(1);selected=errors.gather(2,pred[:,None,None].expand(-1,seq.shape[1],1)).squeeze(-1);norm=seq.abs().sum(-1);novelty=(selected/norm.clamp_min(1e-12).square()).mean(1) if self.kind=='prototype' else -selected.mean(1)
        return dict(out,cssr_logprob=logprob,reconstruction_score=novelty,semantic_magnitude=norm.mean(1))
    def forward_masked(self,x,which):
        out=self.core.forward_masked(x,which);self._sequence=None;return out

def make(setting,A,kind):
    core,owner=restore(setting,A);fields=[np.flatnonzero(r.detach().numpy()).tolist() for r in core.field_column_membership];N.install(core,fields,False,'peri' if setting=='CIC2' else 'post');torch.manual_seed(SEED);return Model(core,kind),owner,fields

@torch.no_grad()
def infer(net,x):
    net.eval();out={}
    for start in range(0,len(x),128):
        v=net(torch.tensor(x[start:start+128],dtype=torch.float32))
        for k in ('embedding','fine_logits','coarse_logits','cssr_logprob','reconstruction_score','semantic_magnitude'):out.setdefault(k,[]).append(v[k].numpy().astype(float))
    return {k:np.concatenate(v) for k,v in out.items()}

def validation(net,x,s):
    at=s['validation'];out=infer(net,x[at]);fine=s['fine'][at];p=out['cssr_logprob'].argmax(1);y=fine>0;r=[float(np.mean((p[y==c]>0)==c)) for c in (0,1)];ce=float(-np.mean(out['cssr_logprob'][np.arange(len(at)),fine]));return (min(r),sum(r)/2,-ce),dict(rows=len(at),coarse_recall=r,coarse_correct=int(np.sum((p>0)==y)),fine_correct=int(np.sum(p==fine)),CSSR_CE=ce,original_head_coarse_correct=int(np.sum(out['coarse_logits'].argmax(1)==y)))

def load_model(setting,A,kind,folder):
    net,owner,fields=make(setting,A,kind);net.load_state_dict(torch.load(folder/'model.pt',map_location='cpu',weights_only=False)['model'],strict=True);return net.eval(),owner

def train(setting,A,s,x,kind,folder,check):
    started=time.perf_counter();net,owner,fields=make(setting,A,kind);fit=s['fit'];rows=list(fit)
    for f in np.unique(s['fine'][fit]):
        at=fit[s['fine'][fit]==f]
        if len(at)<20:rows.extend(np.resize(at,20-len(at)).tolist())
    rows=np.asarray(rows,int);assert len(rows)<=6000 and set(rows)<=set(fit) and not set(rows)&set(s['original_qa']);count=np.bincount(s['fine'][rows],minlength=9);fw=torch.tensor(len(rows)/(9*count),dtype=torch.float32);coarse=(s['fine']>0).astype(int);cw=torch.tensor(len(rows)/(2*np.bincount(coarse[rows],minlength=2)),dtype=torch.float32);multiplicity=np.bincount(rows,minlength=len(x));scale=np.ones(x.shape[1])
    for cols in fields:
        if len(cols)==1:
            v=float(np.sqrt(np.mean(x[fit,cols[0]].astype(float)**2)));scale[cols]=v if v>0 else 1.
    scale=torch.tensor(scale,dtype=torch.float32);params=list(net.parameters());opt=torch.optim.AdamW(params,lr=3e-4,weight_decay=2e-4);scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(opt,EPOCHS,eta_min=3e-5);rng=np.random.default_rng(SEED);bestkey,bestreport=validation(net,x,s);best={k:v.detach().clone() for k,v in net.state_dict().items()};bestepoch=0;history=[];orders=[];masks=[]
    for epoch in range(EPOCHS):
        net.train();order=rng.permutation(rows);logical=np.arange(len(order))%len(fields);rng.shuffle(logical);orders.append(order);masks.append(logical);losses=np.zeros(5)
        for step,start in enumerate(range(0,len(order),128)):
            check();at=order[start:start+128];field=torch.tensor(logical[start:start+len(at)],dtype=torch.long);features=torch.tensor(x[at]);y=torch.tensor(s['fine'][at],dtype=torch.long);c=(y>0).long();torch.manual_seed(SEED+epoch*10000+step);out=net(features);masked=net.forward_masked(features,field);lc=(F.cross_entropy(out['coarse_logits'],c,reduction='none')*cw[c]).sum()/cw[c].sum();lf=(F.cross_entropy(out['fine_logits'],y,label_smoothing=.01,reduction='none')*fw[y]).sum()/fw[y].sum();la=(-out['cssr_logprob'][torch.arange(len(y)),y]*fw[y]).sum()/fw[y].sum();err=F.smooth_l1_loss(masked['reconstruction']/scale,features/scale,reduction='none');row=(err*masked['masked_columns']).sum(1)/masked['masked_columns'].sum(1);pw=torch.tensor(1/multiplicity[at],dtype=torch.float32);lr=(row*pw).sum()/pw.sum();loss=lc+.35*lf+.35*la+.03*lr;assert torch.isfinite(loss)
            opt.zero_grad(set_to_none=True);loss.backward();grad=torch.nn.utils.clip_grad_norm_(params,5.);assert torch.isfinite(grad);opt.step();losses+=np.array([float(v.detach()) for v in (loss,lc,lf,la,lr)])*len(at)
        scheduler.step();key,valid=validation(net,x,s)
        if key>bestkey:bestkey=key;bestreport=valid;best={k:v.detach().clone() for k,v in net.state_dict().items()};bestepoch=epoch+1
        history.append(dict(epoch=epoch+1,losses=losses/len(order),validation=valid,selected_epoch=bestepoch,seconds=time.perf_counter()-started));print('CSSR_TRAIN',setting,kind,history[-1],flush=True)
    net.load_state_dict(best,strict=True);out=infer(net,x)
    with (folder/'model.pt').open('xb') as f:torch.save(dict(model=net.state_dict(),kind=kind,selected_epoch=bestepoch,seed=SEED),f)
    save(folder/'source_outputs.npz',ids=s['ids'],**out);save(folder/'optimizer_parent_map.npz',ids=s['ids'],FIT=fit,validation=s['validation'],QA_calibration=s['qa'],original_QA=s['original_qa'],epoch_optimizer_indices=np.stack(orders),masked_physical_field=np.stack(masks));save(folder/'reconstruction_units.npz',scale=scale.numpy())
    return net,out,dict(kind=kind,attempted_epochs=EPOCHS,selected_epoch=bestepoch,selected_validation=bestreport,history=history,seconds=time.perf_counter()-started,source_parent=owner['model'],semantic_width=net.width,AE_bottleneck=net.latent,AE_count=9,optimizer_slots=len(rows),genuine_FIT=len(fit),only_BEN_KNA_training=True)

reference=N.reference
def scores(out,ref):
    sc=N.scores(out,ref);sc['reconstruction']=out['reconstruction_score'];sc['cssr_msp']=1-np.exp(out['cssr_logprob']).max(1);return sc
def calibrate(cal,y,ix,qa,sy):
    old=P.METHODS
    try:P.METHODS=METHODS;return P.calibrate(cal,y,ix,qa,sy)
    finally:P.METHODS=old
def fixtures():
    torch.manual_seed(65);x=torch.randn(3,7,8,dtype=torch.float64);ae=torch.nn.Sequential(torch.nn.Linear(8,2,bias=False),torch.nn.Tanh(),torch.nn.Linear(2,8,bias=False)).double();e=(x-ae(x)).abs().sum(-1);assert torch.allclose(e,torch.norm(x-ae(x),p=1,dim=-1));zero=torch.zeros_like(x);assert torch.equal(ae(zero),zero);logits=torch.randn(3,7,9,dtype=torch.float64);a=torch.logsumexp(F.log_softmax(logits,-1),1)-math.log(7);b=F.softmax(logits,-1).mean(1);assert torch.allclose(a.exp(),b) and not torch.allclose(a.exp(),F.softmax(logits.mean(1),-1));a.sum().backward() if a.requires_grad else None
    return dict(L1_sum_not_squared_error=True,zero_no_bias_exact=True,token_softmax_then_mean_not_meanlogit_softmax=True,no_synthetic_UNA_samples=True)
