"""CoVer mean confidence with deterministic, FIT-owned field neutralization."""
from io34 import *
import torch
import mc_core as Core
import embedding_model as Q
import joint_model as J
import paper_methods as P
from scipy.special import softmax
METHODS=('fine_cover','coarse_cover','fine_anchor','coarse_anchor')
def restore(setting,A):
    if setting=='CIC2':
        folder=I/'numerical_embedding_20261102_r48/CIC2/quantile_PLE';net,owner=Q.load_model(setting,A,'quantile_PLE',folder);receipt=folder/'TRAINING.json';cached=folder/'source_outputs.npz'
    elif setting=='NSL2':
        folder=I/'nsl2_joint_confidence_20261102_r53/NSL2/joint_quantile_PLE';net,owner=J.load_model(setting,A,'joint_quantile_PLE',folder);receipt=folder/'TRAINING.json';cached=folder/'source_outputs.npz'
    else:
        folder=I/'ben_structure_20261102_r43/NSL1/staged';net,owner=Core.restore(setting,A);saved=torch.load(folder/'model.pt',map_location='cpu',weights_only=False);net.load_state_dict(saved['core'],strict=True);net.eval();receipt=folder/'SOURCE_REPORT.json';cached=folder/'source_after.npz'
    owner=dict(owner,model=desc(folder/'model.pt'),training_receipt=desc(receipt),source_forward=desc(cached));return net,owner
def infer(net,x):return Q.infer(net,x,batch=128)
def neutral(x,fit,fields):
    flat=[j for f in fields for j in f];assert sorted(flat)==list(range(x.shape[1]))
    value=np.zeros(x.shape[1],np.float32);parents=[]
    for cols in fields:
        a=x[fit][:,cols]
        if len(cols)==1:order=np.argsort(a[:,0],kind='stable');index=int(order[(len(a)-1)//2])
        else:
            u,first,count=np.unique(a,axis=0,return_index=True,return_counts=True);index=int(first[np.argmax(count)])
        value[cols]=a[index];parents.append(int(fit[index]))
    return dict(neutral=value,parent_indices=np.asarray(parents,int))
def cache_key(x):return np.ascontiguousarray(x,dtype=np.float32).tobytes()
def probe(net,x,fields,state,cache,check):
    x=np.array(x,np.float32,copy=True);x[x==0]=0;unique,inv=np.unique(x,axis=0,return_inverse=True);keys0=[cache_key(v) for v in unique];new=[j for j,k in enumerate(keys0) if k not in cache]
    if new:
        inputs=unique[new];fine=[];coarse=[]
        for step,cols in enumerate([None]+fields):
            check();changed=inputs.copy()
            if cols is not None:changed[:,cols]=state['neutral'][cols]
            out=infer(net,changed);fine.append(out['fine_logits']);coarse.append(out['coarse_logits'])
            if step%10==0:print('FIELD_FORWARD',step,'/',len(fields),'unique',len(inputs),flush=True)
        fs=np.stack(fine,1);cs=np.stack(coarse,1)
        for j,index in enumerate(new):cache[keys0[index]]=(fs[j],cs[j])
    fine=np.stack([cache[k][0] for k in keys0])[inv];coarse=np.stack([cache[k][1] for k in keys0])[inv]
    return dict(fine_logits=fine,coarse_logits=coarse),dict(rows=len(x),unique_rows=len(unique),newly_computed_unique_inputs=len(new),views=1+len(fields),views_are_not_independent_records=True)
def scores(v):
    fp=softmax(v['fine_logits'],axis=2);cp=softmax(v['coarse_logits'],axis=2);fine=fp[:,0].argmax(1);coarse=cp[:,0].argmax(1)
    f_anchor=np.take_along_axis(fp,np.broadcast_to(fine[:,None,None],(len(fine),fp.shape[1],1)),axis=2).squeeze(2).mean(1)
    c_anchor=np.take_along_axis(cp,np.broadcast_to(coarse[:,None,None],(len(coarse),cp.shape[1],1)),axis=2).squeeze(2).mean(1)
    return dict(fine_cover=1-fp.max(2).mean(1),coarse_cover=1-cp.max(2).mean(1),fine_anchor=1-f_anchor,coarse_anchor=1-c_anchor,predicted_coarse=coarse,BEN_mean_confidence=np.minimum(fp[:,:,0].mean(1),cp[:,:,0].mean(1)),all_views_BEN=np.all(fp.argmax(2)==0,axis=1)&np.all(cp.argmax(2)==0,axis=1))
def calibrate(cal,y,ix,qa,sy):
    old=P.METHODS
    try:P.METHODS=METHODS;return P.calibrate(cal,y,ix,qa,sy)
    finally:P.METHODS=old
def fixtures():
    a=np.array([[[2.,1.,0.],[0.,2.,1.]]]);c=np.array([[[2.,0.],[0.,2.]]]);v=dict(fine_logits=a,coarse_logits=c);r=scores(v);p=softmax(a,axis=2);assert np.allclose(r['fine_cover'],1-p.max(2).mean(1));assert np.allclose(r['fine_anchor'],1-p[:,:,0].mean(1));assert r['fine_anchor'][0]>r['fine_cover'][0]
    return dict(CoVer_Eq6_mean_score_not_mean_logits=True,anchor_score_original_class_retained=True,field_probes_have_no_training_labels=True)
