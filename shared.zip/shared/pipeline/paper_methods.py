"""Locally implemented fDBD, NCI and RankFeat equations; no downloaded code runs."""
from io34 import *
import torch
from scipy.special import logsumexp
import mc_core as Core
METHODS=('fdbd','nci_nofilter','nci_001','rankfeat')

def restore(setting,A):
    net,state=Core.restore(setting,A)
    path=I/'value_residual_20261102_r44'/setting/'mass_fixed/control/model.pt';saved=torch.load(path,map_location='cpu',weights_only=False);assert saved['value_residual'] is False
    net.load_state_dict(saved['core'],strict=True);net.eval();state['model']=desc(path)
    assert tuple(net.fine_head.weight.shape)==(9,32)
    return net,state

def pool_head(net,seq):
    weights=torch.softmax(net.pool_score(seq).squeeze(-1),1);h=net.embedding((seq*weights[...,None]).sum(1))
    return dict(embedding=h,fine_logits=net.fine_head(h),coarse_logits=net.coarse_head(h))

def stages(net,x):
    tokens=x[...,None]*net.feature_weight[None]+net.feature_bias[None]+net.position[None]
    attention,_=net.attention(tokens,tokens,tokens,need_weights=False);enhanced=net.attention_norm(tokens+net.dropout(attention)*net.gate(attention));conv=net.conv(enhanced.transpose(1,2)).transpose(1,2);seq,_=net.sequence(conv)
    return conv,seq

def remove_rank1(feature):
    # Paper matrix is [channels, spatial positions]; here positions are fields.
    a=feature.transpose(1,2).to(torch.float64);u,s,vh=torch.linalg.svd(a,full_matrices=False);rank1=(u[:,:,:1]*s[:,:1,None])@vh[:,:1,:];res=(a-rank1).transpose(1,2).to(feature.dtype)
    return res,s[:,0],s[:,0].square()/s.square().sum(1).clamp_min(torch.finfo(s.dtype).tiny)

@torch.no_grad()
def infer(net,x,rankfeat=True,batch=128):
    net.eval();output={k:[] for k in ('embedding','fine_logits','coarse_logits')}
    if rankfeat:output.update({k:[] for k in ('rankfeat_cnn_logits','rankfeat_lstm_logits','rankfeat_logits','cnn_sigma1','lstm_sigma1','cnn_rank1_fraction','lstm_rank1_fraction')})
    for first in range(0,len(x),batch):
        bx=torch.from_numpy(x[first:first+batch]);conv,seq=stages(net,bx);clean=pool_head(net,seq)
        for k in clean:output[k].append(clean[k].numpy().astype(float))
        if rankfeat:
            conv_removed,c1,cr=remove_rank1(conv);seq_after,_=net.sequence(conv_removed);cnn=pool_head(net,seq_after)['fine_logits']
            seq_removed,l1,lr=remove_rank1(seq);lstm=pool_head(net,seq_removed)['fine_logits'];fused=(cnn+lstm)/2
            for k,v in dict(rankfeat_cnn_logits=cnn,rankfeat_lstm_logits=lstm,rankfeat_logits=fused,cnn_sigma1=c1,lstm_sigma1=l1,cnn_rank1_fraction=cr,lstm_rank1_fraction=lr).items():output[k].append(v.numpy().astype(float))
    result={k:np.concatenate(v) for k,v in output.items()};assert all(np.isfinite(v).all() for v in result.values());return result

def fit(source,fit_indices,net):
    w=net.fine_head.weight.detach().numpy().astype(float);b=net.fine_head.bias.detach().numpy().astype(float);mean=source['embedding'][fit_indices].mean(0)
    distance=np.linalg.norm(w[:,None]-w[None,:],axis=2);np.fill_diagonal(distance,1.);assert np.all(distance>0)
    return dict(weight=w,bias=b,FIT_mean=mean,pair_weight_distance=distance,classes=len(w),nci_alpha=.001)

def score(output,state):
    h=output['embedding'];logits=output['fine_logits'];assert logits.shape==(len(h),9);k=logits.argmax(1);delta=h-state['FIT_mean'];norm=np.linalg.norm(delta,axis=1);assert (norm>0).all(),'UNDEFINED_FEATURE_AT_SOURCE_MEAN'
    margins=logits[np.arange(len(k)),k,None]-logits;assert np.all(margins>=0)
    fdbd=(margins/state['pair_weight_distance'][k]).sum(1)/(state['classes']-1)/norm
    nci=(state['weight'][k]*delta).sum(1)/norm;norm1=np.abs(h).sum(1)
    out=dict(fdbd=-fdbd,nci_nofilter=-nci,nci_001=-(nci+.001*norm1),rankfeat=-logsumexp(output['rankfeat_logits'],axis=1),predicted_coarse=(k>0).astype(int),original_energy=-logsumexp(logits,axis=1),mean_deviation=norm,feature_L1=norm1)
    assert all(np.isfinite(v).all() for v in out.values());return out

def finite(v):
    v=np.sort(np.asarray(v,float));rank=(99*(len(v)+1)+99)//100;assert len(v)>0 and rank<=len(v) and np.isfinite(v).all();return dict(n=len(v),rank=rank,cut=float(v[rank-1]))

def calibrate(cal,y,ix,qa,sy):
    result={}
    for method in METHODS:
        rows=[]
        for c in (0,1):
            a=finite(cal[method][ix[y[ix]==c]]);b=finite(qa[method][sy==c]);rows.append(dict(truecoarse=c,CAL=a,sourceQA=b))
        global_cut=max(v[k]['cut'] for v in rows for k in ('CAL','sourceQA'));bins=[]
        for c in (0,1):
            ca=cal[method][ix[cal['predicted_coarse'][ix]==c]];so=qa[method][qa['predicted_coarse']==c]
            if len(ca)>=99 and len(so)>=99:
                a=finite(ca);b=finite(so);bins.append(dict(predicted_coarse=c,CAL=a,sourceQA=b,cut=max(a['cut'],b['cut']),fallback=False))
            else:bins.append(dict(predicted_coarse=c,CAL_n=len(ca),sourceQA_n=len(so),cut=global_cut,fallback=True))
        result[method]=dict(global_cut=global_cut,global_truecoarse_calibration=rows,predicted_bins=bins)
    return result

def mathematical_checks():
    rng=np.random.default_rng(46);w=rng.normal(size=(9,32));b=rng.normal(size=9);h=rng.normal(size=(23,32));mean=rng.normal(size=32);l=h@w.T+b;dist=np.linalg.norm(w[:,None]-w[None,:],axis=2);np.fill_diagonal(dist,1)
    state=dict(weight=w,bias=b,FIT_mean=mean,pair_weight_distance=dist,classes=9,nci_alpha=.001);o=dict(embedding=h,fine_logits=l,rankfeat_logits=l);s=score(o,state)
    literal=[]
    for z,logits in zip(h,l):
        k=int(logits.argmax());literal.append(-sum((logits[k]-logits[j])/np.linalg.norm(w[k]-w[j]) for j in range(9) if j!=k)/8/np.linalg.norm(z-mean))
    assert np.allclose(literal,s['fdbd'],rtol=1e-12,atol=1e-12)
    translation=rng.normal(size=32);shifted=dict(state,FIT_mean=mean+translation,bias=b-w@translation);s2=score(dict(embedding=h+translation,fine_logits=l,rankfeat_logits=l),shifted);assert np.allclose(s['fdbd'],s2['fdbd'],rtol=1e-12,atol=1e-12)
    expected=[]
    for z,logits in zip(h,l):
        k=int(logits.argmax());expected.append(-np.dot(w[k],z-mean)/np.linalg.norm(z-mean))
    assert np.allclose(expected,s['nci_nofilter'],rtol=1e-12,atol=1e-12)
    example=torch.diag(torch.tensor([3.,2.,1.],dtype=torch.float32))[None];res,sigma,fraction=remove_rank1(example);assert torch.allclose(res,torch.diag(torch.tensor([0.,2.,1.]))[None]) and float(sigma[0])==3
    return dict(fdbd_paper_average_equals_official_sum_divided_by_Cminus1=True,fdbd_translation_with_bias_compensation_invariant=True,NCI_dot_equals_norm_weighted_cosine=True,RankFeat_exact_rank1_fixture=True,no_real_traffic_or_target_labels_in_tests=True)
