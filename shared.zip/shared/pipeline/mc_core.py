"""Stability of the existing trained MHFD/CNN-LSTM cores; no new dropout rate."""
from io34 import *
import torch
from torch import nn
import time
DRAWS=8
SALT=b'R42_existing_dropout_20261102'

def digest(net):
    h=hashlib.sha256()
    for k,v in sorted(net.state_dict().items()):
        a=v.detach().cpu().contiguous().numpy();h.update(k.encode());h.update(str(a.dtype).encode());h.update(str(a.shape).encode());h.update(a.tobytes())
    return h.hexdigest()

def canonical_signature(value):
    if isinstance(value,dict):
        out={k:canonical_signature(v) for k,v in value.items()}
        if 'path' in value and 'sha256' in value:
            path=Path(value['path']).resolve(strict=True);assert B.digest(path)==value['sha256'];out['path']=str(path)
        return out
    if isinstance(value,list):return [canonical_signature(v) for v in value]
    return value

def restore(setting,A):
    torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
    if setting=='CIC2':
        from paper_open_set import cic2_coarse_conditional78_runtime_v65 as C
        reg=read(C.REG);frame=read(ROOT/'tmp/cic2_allpair_relation_adapter158_20261012_v106/registry_before_train.json');path=Path(frame['assets']['model']['path']);saved=torch.load(path,map_location='cpu',weights_only=True)
        net=C.make_model(reg,{});net.load_state_dict(saved['state_dict'],strict=True);net=net.backbone
        pre=load(reg['assets']['encoder_preprocessing']['path']);units=load(frame['assets']['units']['path'])['embedding32'];state=dict(kind=setting,pre=pre,runtime=C,unit=np.asarray(units),model=desc(path),encoding=desc(reg['assets']['encoder_preprocessing']['path']))
    elif setting=='NSL1':
        from paper_open_set import nsl1_nativecell_Student3_typedmask_v60 as C
        reg=read(ROOT/'tmp/nsl1_nativecell_clean149_20261011_v62/registry_before_clean149_known.json');tr=read(reg['masked_registry']['path']);mapping=C.field_map_from_state(read(reg['assets']['field_map']['path']));path=Path(reg['assets']['model']['path']);saved=torch.load(path,map_location='cpu',weights_only=True)
        expected=C.checkpoint_signature(tr);assert canonical_signature(saved['network_signature'])==canonical_signature(expected)
        # Only equivalent junction path spellings in metadata are normalized in
        # memory; original checkpoint bytes and all tensor values remain fixed.
        aligned=dict(saved,network_signature=expected);net=C.load_checkpoint(aligned,tr,mapping,device=torch.device('cpu'));units=read(ROOT/'data/external_dev/processed/nsl1_nativecell_clean149_20261011_v62/known/FIT_only_maskclean_embedding32_units_before_metric.json')['scale']
        state=dict(kind=setting,unit=np.asarray(units),model=desc(path),encoding=desc(reg['assets']['encoded']['path']),signature_aliases_resolve_to_same_files_and_SHA=True)
    else:
        C=A.C;w=C.Adapter.restore_warm();path=C.R21/'hard_ben_once/model.pt';saved=torch.load(path,map_location='cpu',weights_only=False);net=w['net'];net.load_state_dict(saved['state_dict'],strict=True)
        F=mod(I/'mhfd_field_measure_20261031_r17/nsl2/field_measure.py','r42_mc_forward');F.install(net,w['field_columns'],False)
        state=dict(kind=setting,unit=np.ones(32),model=desc(path),encoding=desc(C.Adapter.manifest()['encoding']['path']))
    net.cpu().eval();torch.set_num_threads(2)
    return net,state

def inputs(setting,A,s_or_q,state,source=False):
    q=s_or_q
    if setting=='CIC2':
        raw=A.A.load_source() if source else A.A.load_role(q['role_name']);lookup={str(v):j for j,v in enumerate(raw['ids'])};at=np.array([lookup[str(v)] for v in q['ids']]);x=state['runtime'].encode_input(raw['native'][at],state['pre'])
    elif setting=='NSL1':
        if source:
            raw=A.A.load_source();lookup={str(v):j for j,v in enumerate(raw['ids'])};at=np.array([lookup[str(v)] for v in q['ids']]);value=raw['Z'][at,32:]
        else:value=q['Z'][:,32:]
        x=value.astype(np.float32);assert np.array_equal(x.astype(float),value)
    else:x=q['x'].astype(np.float32);assert np.array_equal(x.astype(q['x'].dtype),q['x'])
    assert x.ndim==2 and np.isfinite(x).all();return np.ascontiguousarray(x)

def stochastic_mode(net):
    net.eval();active=[]
    for name,m in net.named_modules():
        p=None
        if isinstance(m,(nn.Dropout,nn.Dropout1d,nn.Dropout2d,nn.Dropout3d,nn.AlphaDropout,nn.FeatureAlphaDropout)):p=float(m.p)
        elif isinstance(m,nn.MultiheadAttention):p=float(m.dropout)
        elif isinstance(m,(nn.LSTM,nn.GRU,nn.RNN)) and m.num_layers>1:p=float(m.dropout)
        if p is not None and p>0:m.training=True;active.append(dict(module=name,kind=type(m).__name__,trained_probability=p))
    assert active,'NO_TRAINED_STOCHASTIC_MODULE'
    assert all(not m.training for m in net.modules() if isinstance(m,nn.modules.batchnorm._BatchNorm))
    return active

@torch.no_grad()
def clean_check(net,state,x,expected_scaled):
    net.eval();out=net(torch.from_numpy(x));z=out['embedding'].numpy().astype(float)/state['unit'];err=float(np.max(np.abs(z-expected_scaled)))
    assert np.allclose(z,expected_scaled,atol=5e-5,rtol=5e-5),('DETERMINISTIC_EMBEDDING_PARITY',err)
    assert out['coarse_logits'].shape==(len(x),2)
    return dict(max_scaled_embedding_absolute_error=err,rtol=5e-5,atol=5e-5,exact_input_binding=True)

@torch.no_grad()
def infer(net,x,cache,check):
    x=np.array(x,np.float32,copy=True);x[x==0]=0
    unique,rep,inv=np.unique(x,axis=0,return_index=True,return_inverse=True);logits=[];emb=[];computed=0;active=stochastic_mode(net);before=digest(net)
    for j,row in enumerate(unique):
        if j%64==0:check()
        key=hashlib.sha256(SALT+row.tobytes()).digest()
        if key not in cache:
            # Input-derived, role-independent seed. IDs/truth never enter it.
            seed=int.from_bytes(key[:8],'little')%(2**63-1);torch.manual_seed(seed)
            tensor=torch.from_numpy(np.repeat(row[None,:],DRAWS,axis=0));o=net(tensor)
            cache[key]=(o['coarse_logits'].numpy().copy(),o['embedding'].numpy().copy());computed+=1
        p,h=cache[key];assert p.shape==(DRAWS,2) and h.shape==(DRAWS,32);logits.append(p);emb.append(h)
        if j%1000==0:print('MC_GROUPS',j,'/',len(unique),flush=True)
    assert digest(net)==before
    l=np.asarray(logits);h=np.asarray(emb);prob=torch.softmax(torch.tensor(l,dtype=torch.float64),dim=2).numpy();mean=prob.mean(1);entropy=lambda a:-(a*np.log(np.maximum(a,np.finfo(float).tiny))).sum(-1)
    mi=np.maximum(entropy(mean)-entropy(prob).mean(1),0.);margin=l[:,:,0].astype(float)-l[:,:,1].astype(float)
    margin_std=np.std(margin,axis=1,ddof=1);embedding_std=np.sqrt(np.var(h.astype(float),axis=1,ddof=1).mean(1));ben=mean[:,0]
    scores=np.column_stack((ben*mi,ben*margin_std,ben*embedding_std))[inv];assert np.isfinite(scores).all()
    return dict(scores=scores,mean_BEN_probability=ben[inv],input_inverse=inv,representatives=rep,unique_logits=l,unique_embeddings=h),dict(rows=len(x),unique_neural_inputs=len(unique),new_input_forwards=computed,dropout_views_per_input=DRAWS,active_modules=active,state_sha256=before,weights_and_buffers_unchanged=True)
