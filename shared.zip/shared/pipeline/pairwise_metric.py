"""Known-FIT concretisation of manuscript Eq.9/10, for DVC distances only.

The paper leaves F', phi_j and the learning objective unspecified. This
declared adaptation uses frozen MHFD Z, a FIT-only global RMS scale,
F'_j(delta_j)=delta_j**2, phi_j=[delta_j, delta_j**2], and nonnegative
learned softmax weights and mu. It is a dissimilarity, not a proven metric:
triangle inequality is not assumed. No classifier, candidate threshold,
query labels, calibration optimisation or DVC routing lives in this module.

Feature-equivalent original records form one group with a SET of true known
fine labels. Positive pairs share a label; negative pairs have disjoint sets.
Pair views do not increase the number of training traffic records.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import time
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

SCHEMA = "R108-known-only-context-conv-owned-native-plus-semantic32"
SEED = 20261008
PAIR_COUNT = 8192
EPOCHS = 80
MAX_ROWS = 6000
MAX_DIMENSION = 158


class PairMetricProtocolStop(ValueError):
    pass


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise PairMetricProtocolStop(message)


def _digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode("utf-8")).hexdigest()


def _array_descriptor(value: np.ndarray) -> dict:
    a = np.asarray(value)
    _require(not a.dtype.hasobject, "object_arrays_forbidden")
    return {"shape": list(a.shape), "dtype": a.dtype.str,
            "sha256": hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()}


def _immutable(value: Any, dtype: Any = np.float64) -> np.ndarray:
    a = np.ascontiguousarray(value, dtype=dtype)
    return np.frombuffer(a.tobytes(), dtype=a.dtype).reshape(a.shape)


def _matrix(value: Any, *, width: int | None = None) -> np.ndarray:
    a = np.asarray(value)
    _require(a.dtype in (np.dtype("float32"), np.dtype("float64")) and a.ndim == 2
             and 0 < len(a) <= MAX_ROWS and 0 < a.shape[1] <= MAX_DIMENSION
             and (width is None or a.shape[1] == width) and np.isfinite(a).all(),
             "finite_float32_or_float64_MHFD_Z_up_to_6000x128_required")
    return a


def training_recipe(dimension: int) -> dict:
    _require(type(dimension) is int and 0 < dimension <= MAX_DIMENSION,
             "MHFD_embedding_dimension_1_to_128_required")
    return {
        "schema_version": SCHEMA, "embedding_dimension": dimension,
        "input": "complete existing native coordinates plus R43 staged trained32 / new FIT RMS; owned110,149,147 dimensions",
        "scaling": "one global RMS L2 norm of unique known FIT group representatives; frozen",
        "group_representative": "original FIT record with lexicographically smallest FIT ID",
        "phi": "sum_j abs((Za-Zb)/FIT_RMS)_j**2",
        "F_prime_j": "delta_j**2", "phi_j": "[delta_j,delta_j**2]",
        "omega_j": "softmax_j(dot(softplus(raw_W_j),phi_j))",
        "distance": "sqrt(phi+softplus(raw_mu)*sum_j(omega_j*delta_j**2))",
        "triangle_inequality_proven": False, "W_shape": [dimension, 2],
        "mu_initial": float(dimension), "W_initial_each_component": 0.05,
        "pair_count": PAIR_COUNT, "pair_seed": SEED,
        "coverage": "every unique FIT group occurs; first pair is closest admissible negative, otherwise closest positive",
        "positive": "closest other group sharing the selected actual known fine label",
        "negative": "closest other group with disjoint known fine-label sets and strictly positive base distance",
        "zero_distance_disjoint_negatives": "excluded and counted; cannot learn to separate identical Z",
        "remaining_pairs": "round-robin actual fine families, seeded shuffled anchor cycles, nearest positives",
        "pair_weights": "equal positive/negative total mass; uniform anchor-fine mass within each type; inverse pair frequency",
        "loss": "same*d**2 + different*relu(2-d)**2, weighted",
        "contrastive_margin": 2.0, "epochs": EPOCHS, "minibatch": 256,
        "optimizer": "Adam", "learning_rate": 0.01, "weight_decay": 1e-6,
        "gradient_clip_max_norm": 10.0, "dtype": "float64", "device": "cpu",
        "CPU_threads": 4, "checkpoint": "fixed final epoch; no selection",
        "training_roles": ["FIT"], "CP_CAL_DEV_query_used_for_optimization": False,
        "pair_views_are_additional_traffic": False, "query_scaler_fit": False,
        "published": False, "final_test_executed": False, "target99_status": "FAIL_TARGET99",
    }


def _squared_blocks(left: np.ndarray, right: np.ndarray) -> np.ndarray:
    try:
        with np.errstate(over="raise", invalid="raise"):
            result = np.sum((left[:, None, :] - right[None, :, :]) ** 2, axis=2)
    except FloatingPointError as exc:
        raise PairMetricProtocolStop("MHFD_pair_squared_distance_overflow") from exc
    _require(np.isfinite(result).all(), "nonfinite_MHFD_pair_squared_distance")
    return result


def _nearest_members(z: np.ndarray, members: np.ndarray) -> np.ndarray:
    """Exact nearest other member; equal distances choose lowest group index."""
    nearest = np.full(len(z), -1, np.int64)
    if len(members) < 2:
        return nearest
    for start in range(0, len(members), 64):
        left = members[start:start + 64]
        best = np.full(len(left), np.inf)
        chosen = np.full(len(left), -1, np.int64)
        for ref_start in range(0, len(members), 256):
            right = members[ref_start:ref_start + 256]
            distances = _squared_blocks(z[left], z[right])
            distances[left[:, None] == right[None, :]] = np.inf
            local = np.argmin(distances, axis=1)
            value = distances[np.arange(len(left)), local]
            improve = value < best
            best[improve] = value[improve]
            chosen[improve] = right[local[improve]]
        nearest[left] = chosen
    return nearest


def _nearest_disjoint(z: np.ndarray, membership: np.ndarray) -> tuple[np.ndarray, int]:
    nearest = np.full(len(z), -1, np.int64)
    zero_directed = 0
    for start in range(0, len(z), 64):
        left = np.arange(start, min(start + 64, len(z)))
        best = np.full(len(left), np.inf)
        chosen = np.full(len(left), -1, np.int64)
        for ref_start in range(0, len(z), 256):
            right = np.arange(ref_start, min(ref_start + 256, len(z)))
            distances = _squared_blocks(z[left], z[right])
            shared = (membership[left] @ membership[right].T) > 0
            zero_disjoint = ~shared & (distances == 0.0)
            zero_directed += int(zero_disjoint.sum())
            distances[shared | (distances == 0.0)] = np.inf
            local = np.argmin(distances, axis=1)
            value = distances[np.arange(len(left)), local]
            improve = value < best
            best[improve] = value[improve]
            chosen[improve] = right[local[improve]]
        nearest[left] = chosen
    _require(zero_directed % 2 == 0, "asymmetric_zero_disjoint_pair_count")
    return nearest, zero_directed // 2


def _prepare(z_fit: Any, y_fit_fine: Any, *, known_fine_labels: Any,
             fit_ids: Any, fit_group_ids: Any, fit_roles: Any) -> tuple:
    original = _matrix(z_fit)
    truth = np.asarray(y_fit_fine)
    declared = tuple(known_fine_labels)
    _require(truth.shape == (len(original),) and truth.dtype.kind in "iu"
             and len(declared) >= 2 and len(declared) <= 64
             and all(type(v) in (int, np.int32, np.int64) and int(v) >= 0 for v in declared)
             and len(set(map(int, declared))) == len(declared) and 0 in declared
             and set(map(int, truth)) == set(map(int, declared)),
             "all_and_only_declared_known_fine_FIT_labels_including_BEN0_required")
    declared = tuple(sorted(map(int, declared)))
    ids, groups, roles = tuple(fit_ids), tuple(fit_group_ids), tuple(fit_roles)
    _require(len(ids) == len(groups) == len(roles) == len(original)
             and len(set(ids)) == len(ids)
             and all(isinstance(v, str) and v for v in (*ids, *groups))
             and all(v == "FIT" for v in roles),
             "original_unique_FIT_IDs_group_IDs_and_FIT_only_roles_required")
    parents: dict[str, list[int]] = {}
    for i, group in enumerate(groups):
        parents.setdefault(group, []).append(i)
    ordered_groups = sorted(parents)
    representatives = np.asarray([min(parents[g], key=lambda i: ids[i])
                                  for g in ordered_groups], np.int64)
    label_sets = [sorted({int(truth[i]) for i in parents[g]}) for g in ordered_groups]
    raw = np.asarray(original[representatives], np.float64)
    largest = float(np.max(np.abs(raw)))
    _require(largest > 0.0, "all_zero_known_FIT_MHFD_embedding")
    # Stable RMS computation: avoid squaring unscaled large finite embeddings.
    rms = largest * float(np.sqrt(np.mean(np.sum((raw / largest) ** 2, axis=1))))
    _require(np.isfinite(rms) and rms > 0.0, "invalid_known_FIT_RMS_scale")
    z = raw / rms
    _require(np.isfinite(z).all(), "known_FIT_RMS_scaled_embedding_nonfinite")
    membership = np.asarray([[fine in labels for fine in declared]
                             for labels in label_sets], np.uint8)
    positive = {fine: _nearest_members(z, np.flatnonzero(membership[:, j]))
                for j, fine in enumerate(declared)}
    negative, zero_disjoint = _nearest_disjoint(z, membership)
    _require(np.any(negative >= 0), "no_informative_disjoint_known_fine_negative_pair")
    positive_families = [f for f in declared if np.any(positive[f] >= 0)]
    _require(bool(positive_families), "no_other_group_known_fine_positive_pair")
    pairs: list[tuple[int, int]] = []
    same: list[bool] = []
    anchor_fine: list[int] = []
    for i, labels in enumerate(label_sets):
        if negative[i] >= 0:
            pairs.append((i, int(negative[i]))); same.append(False)
            anchor_fine.append(labels[i % len(labels)])
        else:
            admissible = [f for f in labels if positive[f][i] >= 0]
            _require(bool(admissible), "FIT_group_without_admissible_other_group_peer")
            f = admissible[0]
            pairs.append((i, int(positive[f][i]))); same.append(True); anchor_fine.append(f)
    # Mixed groups keep all their true memberships; make missing negative
    # anchor-family mass explicit instead of inventing one fine label.
    for fine in declared:
        if any(f == fine and not s for f, s in zip(anchor_fine, same)):
            continue
        j = declared.index(fine)
        available = np.flatnonzero(membership[:, j] & (negative >= 0))
        if len(available):
            i = int(available[0]); pairs.append((i, int(negative[i])))
            same.append(False); anchor_fine.append(fine)
    rng = np.random.default_rng(SEED)
    queues = {f: rng.permutation(np.flatnonzero(positive[f] >= 0)).tolist()
              for f in positive_families}
    positions = {f: 0 for f in positive_families}
    cursor = 0
    while len(pairs) < PAIR_COUNT:
        fine = positive_families[cursor % len(positive_families)]; cursor += 1
        if positions[fine] == len(queues[fine]):
            queues[fine] = rng.permutation(queues[fine]).tolist(); positions[fine] = 0
        i = queues[fine][positions[fine]]; positions[fine] += 1
        pairs.append((i, int(positive[fine][i]))); same.append(True); anchor_fine.append(fine)
    _require(len(pairs) == PAIR_COUNT, "fixed_pair_budget_exceeded")
    pairs_a, same_a, fine_a = (np.asarray(pairs, np.int64), np.asarray(same, bool),
                             np.asarray(anchor_fine, np.int64))
    weights = np.zeros(PAIR_COUNT, np.float64)
    for is_same in (False, True):
        present = sorted(set(fine_a[same_a == is_same].tolist()))
        for fine in present:
            selected = (same_a == is_same) & (fine_a == fine)
            weights[selected] = 0.5 / (len(present) * int(selected.sum()))
    _require(np.isfinite(weights).all() and np.all(weights > 0)
             and np.isclose(weights.sum(), 1.0, rtol=0, atol=1e-12),
             "invalid_known_pair_family_weights")
    covered = sorted(set(pairs_a.ravel().tolist()))
    _require(covered == list(range(len(z))), "known_FIT_group_pair_coverage_incomplete")
    original_rows = [dict(group_id=g, original_fit_ids=sorted(ids[i] for i in parents[g]),
                          representative_fit_id=ids[int(representatives[k])],
                          known_fine_label_set=label_sets[k])
                     for k, g in enumerate(ordered_groups)]
    prefit = {
        "schema_version": SCHEMA + "-before-fit", "recipe": training_recipe(original.shape[1]),
        "FIT_MHFD_Z": _array_descriptor(original), "FIT_known_fine": _array_descriptor(truth),
        "FIT_ordered_ids": list(ids), "FIT_ordered_group_ids": list(groups),
        "FIT_ordered_roles": list(roles), "declared_known_fine_labels": list(declared),
        "original_training_traffic_rows": len(original), "unique_FIT_feature_groups": len(z),
        "mixed_known_fine_groups": sum(len(v) > 1 for v in label_sets),
        "groups": original_rows, "frozen_FIT_RMS_scale": rms,
        "unique_group_scaled_Z": _array_descriptor(z),
        "zero_distance_disjoint_unique_group_pairs_excluded": zero_disjoint,
        "negative_available_group_count": int(np.sum(negative >= 0)),
        "positive_available_group_count": int(np.sum(np.any(np.stack(list(positive.values())) >= 0, axis=0))),
        "all_unique_FIT_groups_have_pair_coverage": True,
        "positive_anchor_groups": len(set(pairs_a[same_a, 0].tolist())),
        "negative_anchor_groups": len(set(pairs_a[~same_a, 0].tolist())),
        "pair_count": PAIR_COUNT, "positive_pair_count": int(same_a.sum()),
        "negative_pair_count": int((~same_a).sum()), "pair_group_indices": pairs_a.tolist(),
        "pair_is_positive": same_a.tolist(), "pair_anchor_known_fine": fine_a.tolist(),
        "pair_weights": weights.tolist(), "pair_view_is_additional_traffic": False,
        "CP_CAL_DEV_query_labels_or_features_used": False,
    }
    prefit["prefit_sha256"] = _digest(prefit)
    return z, pairs_a, same_a, weights, prefit


def prefit_descriptor(z_fit: Any, y_fit_fine: Any, **kwargs: Any) -> dict:
    """Deterministic known-FIT pair/scaler plan; no optimisation is performed."""
    return _prepare(z_fit, y_fit_fine, **kwargs)[-1]


class VariationalPairNetwork(nn.Module):
    def __init__(self, dimension: int):
        super().__init__()
        training_recipe(dimension)
        self.dimension = dimension
        raw_mu = dimension if dimension > 20 else np.log(np.expm1(float(dimension)))
        self.raw_mu = nn.Parameter(torch.tensor(raw_mu, dtype=torch.float64))
        raw_w = float(np.log(np.expm1(0.05)))
        self.raw_W = nn.Parameter(torch.full((dimension, 2), raw_w, dtype=torch.float64))

    def squared_distance(self, left: torch.Tensor, right: torch.Tensor) -> torch.Tensor:
        _require(left.shape == right.shape and left.ndim == 2
                 and left.shape[1] == self.dimension
                 and left.dtype == right.dtype == torch.float64
                 and left.device.type == right.device.type == "cpu",
                 "paired_float64_CPU_scaled_MHFD_tensors_required")
        delta = torch.abs(left - right)
        squared = delta.square()
        w = F.softplus(self.raw_W)
        omega = torch.softmax(delta * w[:, 0] + squared * w[:, 1], dim=1)
        return squared.sum(dim=1) + F.softplus(self.raw_mu) * (omega * squared).sum(dim=1)

    def forward(self, left: torch.Tensor, right: torch.Tensor) -> torch.Tensor:
        squared = self.squared_distance(left, right)
        # Finite derivative at exact zero without perturbing exact-zero output.
        return torch.where(squared > 0.0, torch.sqrt(squared.clamp_min(1e-24)), squared)


def _json_state(value: Any) -> Any:
    if isinstance(value, torch.Tensor):
        a = value.detach().cpu().numpy()
        return {"tensor_dtype": a.dtype.str, "shape": list(a.shape), "values": a.tolist()}
    if isinstance(value, dict):
        return {str(k): _json_state(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json_state(v) for v in value]
    return value


def _summary(value: np.ndarray) -> dict:
    a = np.asarray(value, np.float64)
    _require(len(a) > 0 and np.isfinite(a).all(), "finite_nonempty_audit_distribution_required")
    return {"count": len(a), "min": float(a.min()), "median": float(np.median(a)),
            "mean": float(a.mean()), "p95": float(np.quantile(a, 0.95)), "max": float(a.max())}


def _train(z: np.ndarray, pairs: np.ndarray, same: np.ndarray,
           weights: np.ndarray) -> dict:
    previous_threads = torch.get_num_threads()
    previous_deterministic = torch.are_deterministic_algorithms_enabled()
    previous_warn_only = torch.is_deterministic_algorithms_warn_only_enabled()
    try:
        torch.set_num_threads(4)
        torch.use_deterministic_algorithms(True)
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(SEED)
            model = VariationalPairNetwork(z.shape[1])
            optimizer = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=1e-6)
            generator = torch.Generator().manual_seed(SEED)
            values = torch.from_numpy(np.array(z, copy=True))
            index = torch.from_numpy(pairs.copy())
            is_same = torch.from_numpy(same.copy())
            importance = torch.from_numpy(weights.copy())
            with torch.no_grad():
                before = model(values[index[:, 0]], values[index[:, 1]]).numpy()
            history = []
            started = time.perf_counter()
            for epoch in range(1, EPOCHS + 1):
                epoch_loss = 0.0; max_gradient = 0.0
                for selection in torch.randperm(len(index), generator=generator).split(256):
                    optimizer.zero_grad(set_to_none=True)
                    part = index[selection]
                    distance = model(values[part[:, 0]], values[part[:, 1]])
                    row_loss = torch.where(is_same[selection], distance.square(),
                                           torch.relu(2.0 - distance).square())
                    loss = (row_loss * importance[selection]).sum() * len(index) / len(selection)
                    _require(bool(torch.isfinite(loss)), "nonfinite_known_pair_loss")
                    loss.backward()
                    _require(all(p.grad is not None and bool(torch.isfinite(p.grad).all())
                                 for p in model.parameters()), "nonfinite_known_pair_gradient")
                    gradient = float(torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0))
                    optimizer.step()
                    _require(all(bool(torch.isfinite(p).all()) for p in model.parameters()),
                             "nonfinite_learned_known_pair_parameters")
                    max_gradient = max(max_gradient, gradient)
                    epoch_loss += float(loss.detach()) * len(selection) / len(index)
                history.append({"epoch": epoch, "weighted_loss": epoch_loss,
                                "mu": float(F.softplus(model.raw_mu).detach()),
                                "max_gradient_norm_before_clip": max_gradient})
            seconds = time.perf_counter() - started
            with torch.no_grad():
                after = model(values[index[:, 0]], values[index[:, 1]]).numpy()
                raw_mu = float(model.raw_mu)
                raw_w = model.raw_W.numpy().copy()
                mu = float(F.softplus(model.raw_mu))
                w = F.softplus(model.raw_W).numpy().copy()
            base = np.sqrt(np.sum((z[pairs[:, 0]] - z[pairs[:, 1]]) ** 2, axis=1))
            return {"raw_mu": raw_mu, "raw_W": raw_w.tolist(), "mu": mu, "W": w.tolist(),
                    "history": history, "training_seconds": seconds,
                    "optimizer_state": _json_state(optimizer.state_dict()),
                    "pair_distance_audit": {
                        "base_positive": _summary(base[same]), "base_negative": _summary(base[~same]),
                        "initial_positive": _summary(before[same]), "initial_negative": _summary(before[~same]),
                        "trained_positive": _summary(after[same]), "trained_negative": _summary(after[~same]),
                        "mu_changed": mu != float(z.shape[1]), "mu_initial": float(z.shape[1]),
                        "mu_final": mu, "W_min": float(w.min()), "W_max": float(w.max()),
                        "learned_mu_near_zero_1e_minus8": mu <= 1e-8,
                    }}
    finally:
        torch.set_num_threads(previous_threads)
        torch.use_deterministic_algorithms(previous_deterministic, warn_only=previous_warn_only)


class PaperVariationalPairMetric:
    """Frozen serializable dissimilarity; inference never fits or mutates state."""
    def __init__(self, state: dict):
        state = copy.deepcopy(state)
        supplied = state.pop("state_sha256", None)
        _require(supplied == _digest(state), "serialized_pair_metric_state_digest_mismatch")
        _require(state.get("schema_version") == SCHEMA, "unexpected_pair_metric_schema")
        prefit = state["prefit_descriptor"]
        dimension = prefit["recipe"]["embedding_dimension"]
        _require(prefit["recipe"] == training_recipe(dimension), "pair_metric_recipe_drift")
        check_prefit = dict(prefit); stored_prefit_digest = check_prefit.pop("prefit_sha256")
        _require(stored_prefit_digest == _digest(check_prefit), "pair_metric_prefit_digest_mismatch")
        self.dimension = dimension
        self.scale = float(prefit["frozen_FIT_RMS_scale"])
        self.mu = float(state["trained"]["mu"])
        self.W = _immutable(state["trained"]["W"])
        _require(np.isfinite(self.scale) and self.scale > 0 and np.isfinite(self.mu) and self.mu >= 0
                 and self.W.shape == (dimension, 2) and np.isfinite(self.W).all()
                 and np.all(self.W >= 0), "finite_nonnegative_frozen_pair_parameters_required")
        trained = state["trained"]
        raw_w = np.asarray(trained["raw_W"], np.float64)
        raw_mu = float(trained["raw_mu"])
        _require(raw_w.shape == (dimension, 2) and np.isfinite(raw_w).all()
                 and np.isfinite(raw_mu), "finite_complete_raw_pair_parameters_required")
        with torch.no_grad():
            expected_w = F.softplus(torch.from_numpy(raw_w)).numpy()
            expected_mu = float(F.softplus(torch.tensor(raw_mu, dtype=torch.float64)))
        _require(np.array_equal(expected_w, self.W) and expected_mu == self.mu,
                 "serialized_raw_positive_pair_parameters_disagree")
        _require(len(trained["history"]) == EPOCHS
                 and [v["epoch"] for v in trained["history"]] == list(range(1, EPOCHS + 1))
                 and all(np.isfinite(v[k]) and v[k] >= 0 for v in trained["history"]
                         for k in ("weighted_loss", "mu", "max_gradient_norm_before_clip"))
                 and np.isfinite(state["trained"]["training_seconds"])
                 and state["trained"]["training_seconds"] >= 0,
                 "complete_fixed_epoch_pair_training_required")
        self._state = state
        self.state_sha256 = supplied

    def _check(self) -> None:
        _require(self.state_sha256 == _digest(self._state)
                 and self.dimension == self._state["prefit_descriptor"]["recipe"]["embedding_dimension"]
                 and self.scale == self._state["prefit_descriptor"]["frozen_FIT_RMS_scale"]
                 and self.mu == self._state["trained"]["mu"]
                 and np.array_equal(self.W, self._state["trained"]["W"]),
                 "frozen_pair_metric_state_changed")

    def to_state(self) -> dict:
        self._check()
        return dict(copy.deepcopy(self._state), state_sha256=self.state_sha256)

    @classmethod
    def from_state(cls, state: dict) -> "PaperVariationalPairMetric":
        return cls(state)

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.to_state(), ensure_ascii=False,
                                        sort_keys=True, allow_nan=False), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "PaperVariationalPairMetric":
        return cls.from_state(json.loads(Path(path).read_text(encoding="utf-8")))

    def pairwise_distances(self, z_query: Any, z_reference: Any | None = None,
                           *, block_size: int = 128) -> np.ndarray:
        self._check()
        query = _matrix(z_query, width=self.dimension)
        reference = query if z_reference is None else _matrix(z_reference, width=self.dimension)
        _require(type(block_size) is int and 1 <= block_size <= 256, "block_size_1_to_256_required")
        with np.errstate(over="raise", invalid="raise", divide="raise"):
            try:
                left, right = np.asarray(query, np.float64) / self.scale, np.asarray(reference, np.float64) / self.scale
            except FloatingPointError as exc:
                raise PairMetricProtocolStop("frozen_FIT_scaling_overflow") from exc
        _require(np.isfinite(left).all() and np.isfinite(right).all(), "nonfinite_frozen_scaled_query")
        result = np.empty((len(left), len(right)), np.float64)
        square = z_reference is None
        for i in range(0, len(left), block_size):
            for j in range(i if square else 0, len(right), block_size):
                try:
                    with np.errstate(over="raise", invalid="raise", divide="raise"):
                        delta = np.abs(left[i:i + block_size, None, :] - right[None, j:j + block_size, :])
                        squared = delta ** 2
                        logits = delta * self.W[:, 0] + squared * self.W[:, 1]
                        logits -= logits.max(axis=2, keepdims=True)
                        omega = np.exp(logits); omega /= omega.sum(axis=2, keepdims=True)
                        distances = np.sqrt(squared.sum(axis=2) + self.mu * (omega * squared).sum(axis=2))
                except FloatingPointError as exc:
                    raise PairMetricProtocolStop("learned_pair_distance_overflow") from exc
                _require(np.isfinite(distances).all() and np.all(distances >= 0), "nonfinite_learned_pair_distance")
                result[i:i + len(distances), j:j + distances.shape[1]] = distances
                if square and j != i:
                    result[j:j + distances.shape[1], i:i + len(distances)] = distances.T
        if square:
            np.fill_diagonal(result, 0.0)
        self._check()
        return result


def fit_known_metric(z_fit: Any, y_fit_fine: Any, *, expected_prefit_sha256: str,
                     known_fine_labels: Any, fit_ids: Any,
                     fit_group_ids: Any, fit_roles: Any) -> PaperVariationalPairMetric:
    """One fixed FIT-only training run, pinned to a caller-frozen prefit plan."""
    kwargs = dict(known_fine_labels=known_fine_labels, fit_ids=fit_ids,
                  fit_group_ids=fit_group_ids, fit_roles=fit_roles)
    z, pairs, same, weights, prefit = _prepare(z_fit, y_fit_fine, **kwargs)
    _require(type(expected_prefit_sha256) is str and expected_prefit_sha256 == prefit["prefit_sha256"],
             "caller_frozen_prefit_plan_mismatch_before_optimization")
    trained = _train(z, pairs, same, weights)
    _require(_array_descriptor(np.asarray(z_fit)) == prefit["FIT_MHFD_Z"]
             and _array_descriptor(np.asarray(y_fit_fine)) == prefit["FIT_known_fine"],
             "FIT_material_changed_during_metric_optimization")
    state = {"schema_version": SCHEMA, "prefit_descriptor": prefit, "trained": trained,
             "target99_status": "FAIL_TARGET99", "published": False, "final_test_executed": False,
             "new_final_source_authority": False}
    state["state_sha256"] = _digest(state)
    return PaperVariationalPairMetric.from_state(state)


def sorted_knn(distances: Any, k: int, *, exclude_self: bool = False) -> tuple[np.ndarray, np.ndarray]:
    """Distance then reference-column index, with explicit optional self exclusion."""
    values = np.asarray(distances)
    _require(values.dtype == np.float64 and values.ndim == 2 and 0 < values.shape[0] <= MAX_ROWS
             and 0 < values.shape[1] <= MAX_ROWS and np.isfinite(values).all()
             and np.all(values >= 0) and type(k) is int and k >= 1,
             "finite_nonnegative_float64_precomputed_distances_and_positive_k_required")
    if exclude_self:
        _require(values.shape[0] == values.shape[1] and np.array_equal(values, values.T)
                 and np.all(np.diag(values) == 0), "self_exclusion_requires_symmetric_exactzero_square_matrix")
    _require(k <= values.shape[1] - int(exclude_self), "k_exceeds_available_reference_rows")
    sortable = values.copy()
    if exclude_self:
        np.fill_diagonal(sortable, np.inf)
    index = np.argsort(sortable, axis=1, kind="stable")[:, :k]
    return np.take_along_axis(values, index, axis=1), index
