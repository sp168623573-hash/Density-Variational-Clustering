"""Same original DVC, exact row-identity metric reuse across nested candidate contexts."""
from io34 import *

from threadpoolctl import threadpool_limits
RECEIPTS=[]
class ReuseMetric:
    def __init__(self,metric):self.metric=metric;self.rows=None;self.distance=None;self.lookup=None;self.rectangles={};self.rectangular_hits=0
    def __getattr__(self,k):return getattr(self.metric,k)
    def pairwise_distances(self,x,reference=None,**kw):
        a=np.asarray(x,np.float64)
        rectangle=None
        if reference is not None:
            b=np.asarray(reference,np.float64);rectangle=(a.shape,b.shape,hashlib.sha256(np.ascontiguousarray(a).tobytes()).digest(),hashlib.sha256(np.ascontiguousarray(b).tobytes()).digest(),json.dumps(kw,sort_keys=True))
            if rectangle in self.rectangles:
                self.rectangular_hits+=1;return self.rectangles[rectangle].copy()
        if reference is None and self.lookup is not None:
            rowkeys=[np.ascontiguousarray(row).tobytes() for row in a]
            if all(key in self.lookup for key in rowkeys):
                ix=np.array([self.lookup[key] for key in rowkeys]);out=self.distance[np.ix_(ix,ix)].copy();np.fill_diagonal(out,0.)
                check=np.unique(np.r_[np.arange(min(8,len(a))),np.arange(max(0,len(a)-8),len(a))]);direct=self.metric.pairwise_distances(a[check],**kw)
                assert np.array_equal(direct,out[np.ix_(check,check)])
                RECEIPTS.append(dict(rows=len(a),cached_rows=len(self.rows),exact_byte_row_identity=True,scalar_metric_state_unchanged=True,independent_submatrix_exact=True))
                return out
        out=self.metric.pairwise_distances(x,reference,**kw)
        if rectangle is not None:self.rectangles[rectangle]=out.copy()
        if reference is None and (self.rows is None or len(a)>len(self.rows)):
            self.rows=a.copy();self.distance=out.copy();self.lookup={np.ascontiguousarray(row).tobytes():i for i,row in enumerate(a)}
        return out
