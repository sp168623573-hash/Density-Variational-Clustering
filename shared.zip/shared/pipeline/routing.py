from io34 import *
import runtime as E
import model_nsl8 as M
import mc_core as Core
import own_metric as L
from metric_cache import ReuseMetric
from vector_review_nsl8 import review
from scipy.spatial.distance import cdist
from scipy.special import softmax
from threadpoolctl import threadpool_limits

D, S, A = E.D, E.SETTING, E.A
CIC_DVC = mod(H / "cic2_dvc.py", "paper_open_set.r108_cic2")
NSL_DVC = mod(H / "nsl2_dvc.py", "paper_open_set.r108_nsl2")
ARMS = {
    "fine_guarded": ("fine_msp", True, ()),
    "fine_reviewed": ("fine_msp", False, ()),
    "coarse_guarded": ("coarse_msp", True, ()),
    "knn_guarded": ("knn", True, ()),
    "BEN_recovery": (None, False, (0,)),
    "KNA_recovery": (None, False, (1,)),
    "joint": ("fine_msp", True, (0, 1)),
}
if S == "NSL1":
    ARMS["BEN_specialist_knn"] = ("BEN_knn", True, ())


def check():
    E.check()


def eq(a, b):
    for k, v in a.items():
        assert np.array_equal(v, b[k]), k


def role(r):
    q = E.role(r, {k: np.asarray(v) for k, v in read(E.P / "units.json").items()})
    q["role_name"] = r
    if r != "current":
        q["control_labels"] = A.labels(r)
    return q


def class_confidence(out):
    f = softmax(out["fine_logits"], axis=1)
    c = softmax(out["coarse_logits"], axis=1)
    return np.minimum(c, np.column_stack((f[:, 0], 1 - f[:, 0])))


def known_support(x, out, s, bank, cuts):
    conf = class_confidence(out)
    pred = out["coarse_logits"].argmax(1)
    eligible = (pred == (out["fine_logits"].argmax(1) > 0)) & (
        conf[np.arange(len(x)), pred] > np.asarray(cuts)[pred]
    )
    at = np.flatnonzero(eligible)
    cert = np.full(len(x), -1, int)
    nnall = np.full((len(x), 7), -1, int)
    lnall = nnall.copy()
    recip = np.zeros(len(x), int)
    fit = s["fit"]
    if len(at):
        d = cdist(x[at], s["x"][fit])
        nn = np.argsort(d, axis=1, kind="stable")[:, :7]
        dd = np.take_along_axis(d, nn, 1)
        nnall[at] = fit[nn]
        recip[at] = (dd < bank["radius"][nn]).sum(1)
        h = out["embedding"][at]
        ld = cdist(
            h / np.maximum(np.linalg.norm(h, axis=1, keepdims=True), 1e-15),
            bank["latent"],
        )
        ln = np.argsort(ld, axis=1, kind="stable")[:, :7]
        lld = np.take_along_axis(ld, ln, 1)
        lnall[at] = fit[ln]
        for j, row in enumerate(at):
            c = pred[row]
            pure = np.all((s["fine"][fit[d[j] <= dd[j, -1]]] > 0) == c) and np.all(
                (s["fine"][fit[ld[j] <= lld[j, -1]]] > 0) == c
            )
            if pure and recip[row] >= 4 and len(set(nnall[row]) & set(lnall[row])) >= 4:
                cert[row] = c
    return dict(
        certificate=cert,
        eligible=eligible,
        native_neighbors=nnall,
        latent_neighbors=lnall,
        native_reciprocal=recip,
    )


def train_metric(s, out):
    fit = s["fit"]
    units = np.maximum(np.sqrt(np.mean(out["embedding"][fit] ** 2, axis=0)), 1e-8)
    z = np.column_stack((s["x"], out["embedding"] / units))
    assert z.shape[1] == {"CIC2": 110, "NSL1": 149, "NSL2": 147}[S]
    x, pairs, same, w, plan = L._prepare(
        z[fit],
        s["fine"][fit],
        known_fine_labels=np.unique(s["fine"][fit]).tolist(),
        fit_ids=s["ids"][fit].tolist(),
        fit_group_ids=s["groups"][fit].tolist(),
        fit_roles=["FIT"] * len(fit),
    )
    put(D / "PLAN_BEFORE_METRIC_FIT.json", plan)
    st = dict(
        schema_version=L.SCHEMA,
        prefit_descriptor=plan,
        trained=L._train(x, pairs, same, w),
        target99_status="FAIL_TARGET99",
        published=False,
        final_test_executed=False,
        new_final_source_authority=False,
    )
    st["state_sha256"] = L._digest(st)
    metric = L.PaperVariationalPairMetric.from_state(st)
    put(D / "metric.json", metric.to_state())
    save(D / "source_geometry.npz", ids=s["ids"], Z=z, units=units, fit=fit, qa=s["qa"])
    return metric, units


def route(q, z, context, g):
    key = context.tobytes()
    if key not in g["routes"]:
        if S == "CIC2":
            rep = q["density_frame"]["representatives"]
            inv = q["density_frame"]["inverse"]
            flag = np.zeros(len(rep), bool)
            np.logical_or.at(flag, inv, context)
            d = CIC_DVC.route_current_candidates(
                g["metric"], z[rep], flag, seed=20261008
            )
            g["routes"][key] = dict(
                retained=d["retained"][inv] & context, manifest=d["manifest"]
            )
        elif S == "NSL1":
            g["routes"][key] = E.route(
                dict(q, density_Z=z), context, dict(metric=g["metric"], routes={})
            )
        else:
            g["routes"][key] = NSL_DVC.make_dvc_callback(q["groups"])(
                g["metric"], z, context
            )
    return g["routes"][key]


def apply(q, z, sc, cuts, ev, qualified, g, method, guard, classes):
    ret = np.isin(ev["certificate"], classes) & (ev["certificate"] != q["parent"])
    for c in (0, 1):
        if not qualified[c]:
            ret &= ev["certificate"] != c
    if method == "BEN_knn":
        b = next(
            v
            for v in cuts["knn"]["global_truecoarse_calibration"]
            if v["truecoarse"] == 0
        )
        cut = max(b["CAL"]["cut"], b["sourceQA"]["cut"])
        raw = (q["parent"] == 0) & (sc["knn"] > cut)
    else:
        raw = (
            (q["parent"] == 0) & (sc[method] > cuts[method]["global_cut"])
            if method
            else np.zeros(len(ret), bool)
        )
    if guard:
        raw &= ~q["veto"]
    raw &= ~ret
    for action in (ret, raw):
        for group in np.unique(q["groups"][action]):
            for before in (0, 1, 2):
                at = (q["groups"] == group) & (q["parent"] == before)
                if action[at].any() and not action[at].all():
                    action[at] = False
    context = ((q["parent"] == 2) & ~ret) | raw
    den = (
        route(q, z, context, g)
        if raw.any()
        else dict(retained=np.zeros(len(raw), bool))
    )
    p = q["parent"].copy()
    p[ret] = ev["certificate"][ret]
    p[raw & den["retained"]] = 2
    return (
        dict(
            prediction=p,
            raw=raw,
            retained=den["retained"],
            context=context,
            known_reclassification=ret,
        ),
        den,
    )
