"""FIT-only GradOrth with literal all-one CE gradient and balanced subspace control."""
from io34 import *
import pnml_model as Parent
import torch
from scipy.special import softmax
BIND=Parent.BIND;split_source=Parent.split_source
METHODS=('projected','balanced','projection_fraction','full_gradient_control')
def basis(h,weights):
    # Uncentered representation matrix, as in GradOrth Algorithm1/Eq5.
    _,s,v=np.linalg.svd(h*np.sqrt(weights[:,None]),full_matrices=False);energy=s*s;assert energy.sum()>0;k=int(np.searchsorted(np.cumsum(energy),.97*energy.sum(),side='left')+1);b=v[:k].T;return dict(basis=b,singular_values=s,rank=k,energy_fraction=float(energy[:k].sum()/energy.sum()),fixed_energy_target=.97)
def score_one(h,logit,state):
    p=softmax(logit,axis=1);delta=p*logit.shape[1]-1.;gn=np.linalg.norm(delta,axis=1);norm=np.linalg.norm(h,axis=1);projected={}
    for name in ('empirical','balanced'):
        b=np.asarray(state[name]['basis']);hp=np.einsum('nd,dk->nk',h,b,optimize=False);projected[name]=np.linalg.norm(hp,axis=1)
    fraction=np.divide(projected['empirical'],norm,out=np.zeros(len(h)),where=norm>0)
    return dict(projected=-gn*projected['empirical'],balanced=-gn*projected['balanced'],projection_fraction=1-fraction,full_gradient_control=-gn*norm),dict(full_gradient_norm=gn*norm,important_gradient_norm=gn*projected['empirical'],known_subspace_fraction=fraction)
class Predictor(Parent.Predictor):
    def __init__(self,s,A):
        super().__init__(s,A)
        if BIND[s].get('coarse_logits_are_derived_fine_family_logits',False):
            original=self.net.forward
            def tied(x):
                o=original(x);f=o['fine_logits'];o['coarse_logits']=torch.stack((f[:,0],torch.logsumexp(f[:,1:],1)),1);return o
            self.net.forward=tied
        if s=='CIC2':
            names=set(read(BIND[s]['training_flags_manifest']['path'])['trainable_parameter_names'])
            for k,p in self.net.named_parameters():p.requires_grad_(k in names)
    def fit(self,raw,s):
        fit=s['fit'];fine=s['fine'][fit];counts=np.bincount(fine,minlength=9);assert np.all(counts>0);uniform=np.full(len(fit),1/len(fit));balanced=1/(9*counts[fine]);self.stat=[dict(empirical=basis(h[fit],uniform),balanced=basis(h[fit],balanced)) for h in raw['embedding']];return self.stat
    def score(self,raw):
        vals=[];info=[]
        for j,st in enumerate(self.stat):
            sc,det=score_one(raw['embedding'][j],raw['fine_logits'][j],st);vals.append(sc);info.append(det)
        out=self.clean(raw);scores={k:np.mean([v[k] for v in vals],axis=0) for k in METHODS};scores['predicted_coarse']=out['coarse_logits'].argmax(1);detail={k:np.stack([v[k] for v in info]) for k in info[0]};return out,scores,detail
def fixtures():
    torch.manual_seed(130);h=torch.randn(5,6,dtype=torch.float64);w=torch.randn(4,6,dtype=torch.float64,requires_grad=True);bias=torch.randn(4,dtype=torch.float64);q,_=torch.linalg.qr(torch.randn(6,3,dtype=torch.float64));values=[]
    for row in h:
        logits=row@w.T+bias;loss=-logits.log_softmax(0).sum();g=torch.autograd.grad(loss,w,retain_graph=True)[0];delta=logits.softmax(0)*4-1;literal=delta[:,None]*row[None];assert torch.allclose(g,literal,atol=1e-13);projection=g@q@q.T;fast=delta.norm()*(row@q).norm();assert torch.allclose(projection.norm(),fast,atol=1e-13);values.append(float(fast))
    rng=np.random.default_rng(130);x=rng.normal(size=(30,6));b=basis(x,np.full(30,1/30));assert b['energy_fraction']>=.97;assert np.allclose(b['basis'].T@b['basis'],np.eye(b['rank']),atol=1e-12);return dict(autograd_allonesCE_gradient_matches_outerproduct=True,projected_Frobenius_norm_equals_factoredL2=True,uncentered_SVD_energy97_checked=True,no_query_optimization=True)
