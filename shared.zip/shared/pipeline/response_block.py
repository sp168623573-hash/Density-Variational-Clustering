from io34 import *
import torch
from torch import nn
class Response(nn.Module):
    def __init__(self,channels,kind):
        super().__init__();self.gamma=nn.Parameter(torch.zeros(1,channels,1));self.beta=nn.Parameter(torch.zeros(1,channels,1));self.kind=kind
    def forward(self,x):
        gx=torch.linalg.vector_norm(x,dim=2,keepdim=True);nx=gx/(gx.mean(dim=1,keepdim=True)+1e-6)
        if self.kind=='affine_control':nx=torch.ones_like(nx)
        return x+self.gamma*(x*nx)+self.beta
def install(net,setting,kind):
    root=net.backbone.core if setting=='CIC2' else net;root.conv=nn.Sequential(root.conv,Response(root.sequence.input_size,kind));return net
def fixtures():
    torch.manual_seed(99);x=torch.randn(2,4,11,dtype=torch.float64);m=Response(4,'grn').double();assert torch.equal(m(x),x)
    with torch.no_grad():m.gamma.fill_(.2);m.beta.fill_(.1)
    g=torch.stack([torch.stack([torch.sqrt(torch.sum(x[b,c]**2)) for c in range(4)]) for b in range(2)]);n=g/(g.mean(1,keepdim=True)+1e-6);assert torch.allclose(m(x),x+.2*x*n[:,:,None]+.1,atol=1e-14,rtol=1e-14)
    z=torch.zeros((2,4,11),dtype=torch.float64,requires_grad=True);m(z).sum().backward();assert torch.isfinite(z.grad).all();assert torch.equal(m(x)[[1,0]],m(x[[1,0]]));return dict(zero_initialization_exact=True,literal_GRN_equation_matches=True,zero_channel_gradient_finite=True,no_batch_mixing=True)
