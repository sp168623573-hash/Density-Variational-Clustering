from io34 import *
import bootstrap_model as B
import torch
BIND=read(I/'continuation_closeout_20261103_r106/CONTINUATION_MODEL_BINDINGS.json')['settings']
def source_path(s):return Path(BIND[s]['source_roster']['path'])
def restore(s,A):
    net,o=B.restore(s,A);b=BIND[s]
    if s=='NSL1':path=b['optional_training_warm_start']['checkpoint']['path'];equivalent=False
    elif s=='NSL2':path=b['parameter_state_files'][0]['path'];equivalent=True
    else:path=b['neural_checkpoint']['path'];equivalent=True
    net.load_state_dict(torch.load(path,map_location='cpu',weights_only=False)['state'],strict=True);net.eval();return net,dict(o,model=desc(path),source_forward=b['neural_source_forward'],warm_start_function_equivalent_to_parent=equivalent)
infer=B.infer;split_source=B.split_source
