from io34 import *
import bootstrap_r95 as B
import response_block as R
import torch
BIND=read(I/'hour_closeout_20261103_r100/CONTINUATION_MODEL_BINDINGS.json')['settings']
def source_path(s):return Path(BIND[s]['source_roster']['path'])
def restore(s,A):
    net,owner=B.restore(s,A)
    if s=='NSL1':R.install(net,s,'affine_control')
    b=BIND[s];net.load_state_dict(torch.load(b['neural_checkpoint']['path'],map_location='cpu',weights_only=False)['state'],strict=True);net.eval();return net,dict(owner,model=b['neural_checkpoint'],source_forward=b['neural_source_forward'])
infer=B.infer;split_source=B.split_source
def metric(s):
    b=BIND[s];L=mod(b['own_metric_module']['path'],'r103_owned_'+s);return L.PaperVariationalPairMetric.from_state(read(b['own_metric']['path'])),load(b['source_geometry']['path'])['units']
