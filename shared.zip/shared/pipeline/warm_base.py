"""Known-parent interpolation regularization; no unknown class or extra traffic."""
from io34 import *
import arpl_model as AR
import group_model as GR
import normalization_model as N
import torch,time
from torch.nn import functional as F
from scipy.special import logsumexp,softmax
KINDS=('matched_clean','regmixup');METHODS=('fine_msp','coarse_msp','knn');EPOCHS=30;SEED=20261189
split_source=N.split_source
def source_path(setting):
    return I/'neighborhood_coverage_20261103_r72/NSL2/patch10/source.npz' if setting=='NSL2' else I/'coherent_affinity_20261102_r34'/setting/'source.npz'
def restore(setting,A):
    if setting=='CIC2':
        folder=I/'reciprocal_margin_20261103_r85/CIC2/bounded/core';net,owner=AR.load_model(A,'bounded',folder)
    elif setting=='NSL1':
        folder=I/'known_group_robustness_20261103_r82/NSL1/group_ERM/inputs_v2/post';net,owner=GR.load_model(setting,A,'group_ERM',folder)
    else:
        folder=I/'neighborhood_coverage_20261103_r72/NSL2/patch10/post';net,owner=N.load_model(setting,A,'post',folder)
    if setting in ('CIC2','NSL1'):
        folder=I/'sharpness_training_20261103_r90'/setting/'sam05/core';net.load_state_dict(torch.load(folder/'model.pt',map_location='cpu',weights_only=False)['state'],strict=True);net.eval()
    return net,dict(owner,model=desc(folder/'model.pt'),training_receipt=desc(folder/'TRAINING.json'),source_forward=desc(folder/'source_outputs.npz'))
def core(net,setting):return net.backbone.core if setting=='CIC2' else net
@torch.no_grad()
def infer(net,x):
    net.eval();parts={}
    for first in range(0,len(x),128):
        out=net(torch.tensor(x[first:first+128],dtype=torch.float32))
        for k in ('embedding','coarse_logits','fine_logits'):
            parts.setdefault(k,[]).append(out[k].numpy().astype(float))
        if 'reciprocal_logits' in out:parts.setdefault('reciprocal_logits',[]).append(out['reciprocal_logits'].numpy().astype(float))
    return {k:np.concatenate(v) for k,v in parts.items()}
def load_model(setting,A,kind,folder):
    net,owner=restore(setting,A);state=torch.load(folder/'model.pt',map_location='cpu',weights_only=False);net.load_state_dict(state['state'],strict=True);return net.eval(),owner
def validation(net,x,s):
    at=s['validation'];o=infer(net,x[at]);y=(s['fine'][at]>0).astype(int);p=o['coarse_logits'].argmax(1);r=[float(np.mean(p[y==c]==c)) for c in (0,1)];l=o['coarse_logits'];ce=float(np.mean(logsumexp(l,1)-l[np.arange(len(at)),y]));return (min(r),sum(r)/2,-ce),dict(rows=len(at),coarse_recall=r,coarse_correct=int(np.sum(p==y)),fine_correct=int(np.sum(o['fine_logits'].argmax(1)==s['fine'][at])),coarse_CE=ce)
def weighted(logits,y,w,smooth=0.):
    return (F.cross_entropy(logits,y,reduction='none',label_smoothing=smooth)*w[y]).sum()/w[y].sum()
def mixed(logits,a,b,lam,w,smooth=0.):
    numerator=lam*F.cross_entropy(logits,a,reduction='none',label_smoothing=smooth)*w[a]+(1-lam)*F.cross_entropy(logits,b,reduction='none',label_smoothing=smooth)*w[b]
    return numerator.sum()/(lam*w[a]+(1-lam)*w[b]).sum()

reference=N.reference;scores=N.scores;calibrate=N.calibrate
