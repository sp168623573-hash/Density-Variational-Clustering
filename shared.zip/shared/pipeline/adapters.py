from io34 import *


class Adapter:
    def __init__(self, setting):
        self.setting = setting
        sys.path.insert(0, str(ROOT))
        if setting == "NSL2":
            sys.path.insert(0, str(I / "semantic_neighbors_20261101_r33/nsl2"))
            self.C = mod(
                I / "semantic_neighbors_20261101_r33/nsl2/common.py", "r34_nsl2_common"
            )
            sys.modules["common"] = self.C
            self.A = self.C.A
            self.fields = [
                v["columns"]
                for v in read(self.C.Clean.O / "INPUT_MANIFEST.json")["field_groups"]
            ]
        elif setting == "NSL1":
            self.A = mod(
                I / "target99_v1060_20261025/nsl1/inputs_nsl1_v1060.py",
                "r34_nsl1_inputs",
            )
            F = mod(I / "paper_firststage_20261029_r7/source_audit.py", "r34_fields")
            self.fields = [v["columns"] for v in F.fieldmap("NSL1")[0]]
        else:
            self.A = mod(
                I / "target99_v1050_20261024/cic2/inputs_v1050.py", "r34_cic2_inputs"
            )
            self.fields = [[j] for j in range(78)]

    def source(self):
        if self.setting == "NSL2":
            p = read(
                I / "source_enrichment_20261101_r32/nsl2/SOURCE_ROSTER_MANIFEST.json"
            )["rosters"]["hard_BEN_and_rare_KNA"]["data"]["path"]
            s = load(p)
            tr = load(
                I / "source_enrichment_20261101_r32/nsl2/refreshed_once/pair_trace.npz"
            )
            return dict(
                ids=s["ids"],
                groups=s["groups"],
                x=s["native115"],
                z=s["embedding"],
                fine=s["fine"],
                fit=tr["refs"],
                qa=tr["qa"],
                source_ref=desc(p),
            )
        s = self.A.load_source()
        x = s["N"] if self.setting == "NSL1" else s["native"]
        z = s["Z"][:, :32] if self.setting == "NSL1" else s["Z"]
        ambiguous = np.zeros(len(x), bool)
        if self.setting == "NSL1":
            for j in np.unique(s["logical_to_genuine"]):
                ambiguous[j] = (
                    len(
                        np.unique(
                            s["logical_original_fine"][s["logical_to_genuine"] == j]
                        )
                    )
                    > 1
                )
        return dict(
            ids=s["ids"],
            groups=s["groups"],
            x=x,
            z=z,
            fine=s["fine"],
            ambiguous=ambiguous,
        )

    def role(self, role):
        if self.setting == "NSL2":
            q = self.C.role_data(role)
            p = (
                I
                / "supervised_views_20261102_r37/NSL2/coverage_BEN_boundary_UNA"
                / role
                / "prediction_before_truth.npz"
            )
            a = load(p)
            assert np.array_equal(a["ids"], q["ids"])
            q["parent"] = a["prediction"]
            q["x"] = q["native"]
            binding = PARENT_ROLES["NSL2"][role]
            assert desc(binding["path"]) == binding
            accepted = load(binding["path"])
            assert np.array_equal(accepted["ids"], q["ids"])
            q["parent"] = accepted["prediction"]
            sc = load(self.C.R21 / "hard_ben_once" / (role + "_scores.npz"))
            assert np.array_equal(sc["ids"], q["ids"])
            q["z"] = sc["embedding"]
            q["veto"] = q["parent_fields"]["known_certificate_pool"]
            q["risk"] = q["base_raw"] | q["head_unknown"] | q["hard_OOD"]
            return q
        q = self.A.load_role(role)
        q["parent"] = q["parent_prediction"]
        q["x"] = q["N"] if self.setting == "NSL1" else q["native"]
        q["z"] = q["Z"][:, :32] if self.setting == "NSL1" else q["Z"]
        if self.setting == "CIC2":
            phase = "current-predict" if role == "current" else "known-predict"
            p = (
                I
                / "target99_v1050_20261024/cic2/actual_once"
                / phase
                / (role + "_complete_prediction_before_truth.npz")
            )
            old = load(p)
            assert np.array_equal(old["ids"], q["ids"])
            q["parent"] = old["prediction"]
            q["veto"] = old["known_certificate"]
            q["risk"] = old["original_META_U_certificate"]
            binding = PARENT_ROLES["CIC2"][role]
            assert desc(binding["path"]) == binding
            accepted = load(binding["path"])
            assert np.array_equal(accepted["ids"], q["ids"])
            q["parent"] = accepted["prediction"]
        else:
            p = PARENT_ROLES["NSL1"][role]["path"]
            assert desc(p) == PARENT_ROLES["NSL1"][role]
            base = load(p)
            assert np.array_equal(base["ids"], q["ids"])
            q["parent"] = base["prediction"]
            q["veto"] = np.zeros(len(q["ids"]), bool)
            q["risk"] = q["parent"] == 2
            geometry = load(
                I
                / "ben_structure_20261102_r43/NSL1/reencoded"
                / (role + "_geometry.npz")
            )
            assert np.array_equal(geometry["ids"], q["ids"])
            q["density_Z"] = geometry["Z"]
        q["seed_parent"] = q["parent"].copy()
        return q

    def labels(self, role):
        t = self.A.load_known_labels(role)
        return t["ids"], t.get("coarse", t.get("truth"))

    def calibration_indices(self, q):
        if self.setting == "NSL2":
            return np.array(
                read(self.C.Clean.O / "INPUT_MANIFEST.json")["calibration_indices"]
            )
        # Use one CAL row per native feature group and exclude groups shared with the query.
        current = self.role("current")
        held = set(keys(current["x"]))
        ix = []
        seen = set()
        for j, g in enumerate(keys(q["x"])):
            if g not in seen and g not in held:
                ix.append(j)
                seen.add(g)
        return np.array(ix, int)

    def geometry(self, role, q):
        if self.setting == "NSL2":
            return dict(
                reps=q["reps"],
                inverse=q["inverse"],
                neighbors=q["geom"]["physical_neighbors"],
                distance=self.C.Base.distances(role, q),
            )
        _, rep, inv = np.unique(q["groups"], return_index=True, return_inverse=True)
        if self.setting == "CIC2":
            metric = self.A.fixed_metric()
        else:
            from paper_open_set import (
                nsl1_complete_frequency_negative_soft149_v716c as old,
            )

            metric = old.nsl.learned.PaperVariationalPairMetric.from_state(
                self.A.js(self.A.manifest()["original_metric149"])
            )
        distance = metric.pairwise_distances(q["Z"][rep])
        w = distance.copy()
        np.fill_diagonal(w, np.inf)
        near = np.argsort(w, axis=1, kind="stable")[:, :7]
        return dict(
            reps=rep, inverse=inv, neighbors=near, distance=distance, metric=metric
        )

    def route(self, q, context, g):
        if self.setting == "NSL2":
            return self.C.Base.replay(q, context, g["distance"])
        if self.setting == "NSL1":
            route, manifest = self.A.original149_route(q, context, lambda *a: None)
            return dict(
                retained=route["retained"],
                first=route["first"],
                second=route["second"],
                suspected=route["suspected"],
                manifest=manifest,
            )
        from paper_open_set import cic2_allpair_relation158_dvc_v106 as dvc

        # Mark a density group if any of its rows is a candidate.
        rep = q["density_frame"]["representatives"]
        inv = q["density_frame"]["inverse"]
        raw = np.zeros(len(rep), bool)
        np.logical_or.at(raw, inv, context)
        r = dvc.route_current_candidates(g["metric"], q["Z"][rep], raw, seed=20261008)
        return dict(
            retained=r["retained"][inv] & context,
            first=r["first"][inv],
            second=r["second"][inv],
            suspected=r["suspected"][inv],
            manifest=r["manifest"],
        )
