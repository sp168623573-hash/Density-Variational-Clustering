"""Eq.12/17/20 pNML on frozen MHFD/CNN-LSTM; no query optimization."""
from io34 import *
import bootstrap_model as Base
import normalization_model as Roles
import torch
from scipy.special import logsumexp,softmax
BIND=read(I/'continuation_closeout_20261103_r131/CONTINUATION_MODEL_BINDINGS.json')['settings']
METHODS=('regret_fine','regret_coarse','leverage')
split_source=Roles.split_source

def unit(h):
    norm=np.linalg.norm(h,axis=1,keepdims=True);assert np.all(norm>0)
    return h/norm

def basis(h):
    # Section 4.2 explicitly L2 normalizes the original last-layer embedding.
    x=unit(h);_,sv,vt=np.linalg.svd(x,full_matrices=False)
    tol=np.finfo(float).eps*max(x.shape)*sv[0];rank=int(np.sum(sv>tol));assert rank>0
    return dict(whitener=vt[:rank].T/sv[:rank],null_basis=vt[rank:].T,singular_values=sv,rank=rank,rows=len(h),numerical_rank_tolerance=tol)

def leverage(h,b):
    x=unit(h);q=np.einsum('nd,dk->nk',x,b['whitener'],optimize=False);v=np.sum(q*q,axis=1);beta=v/(1+v)
    residual=np.linalg.norm(np.einsum('nd,dk->nk',x,b['null_basis'],optimize=False),axis=1)
    outside=residual>128*np.finfo(float).eps
    beta=np.where(outside,1.,beta);assert np.isfinite(beta).all() and np.all((beta>=0)&(beta<=1))
    return beta,residual

def pnml(logits,beta):
    lp=logits-logsumexp(logits,axis=1)[:,None]
    # Stable log(1-p) even when a classifier probability rounds to one.
    other=np.column_stack([logsumexp(np.delete(logits,j,axis=1),axis=1) for j in range(logits.shape[1])])-logsumexp(logits,axis=1)[:,None]
    lg=lp-np.logaddexp(lp,beta[:,None]*lp+other)
    regret=logsumexp(lg,axis=1);prob=np.exp(lg-regret[:,None])
    assert np.isfinite(regret).all() and regret.min()>-1e-12
    return np.maximum(regret,0),prob

class Predictor:
    def __init__(self,setting,A):
        self.setting=setting;self.net,self.owner=Base.restore(setting,A);b=BIND[setting]
        refs=b['parameter_state_files'] if setting=='NSL1' else [b['neural_checkpoint']]
        self.states=[]
        for ref in refs:
            assert desc(ref['path'])==ref;self.states.append(torch.load(ref['path'],map_location='cpu',weights_only=False)['state'])
        self.refs=refs;self.stat=None
    def raw(self,x,check):
        vals=[]
        for state in self.states:
            check();self.net.load_state_dict(state,strict=True);vals.append(Base.infer(self.net,x))
        return {k:np.stack([o[k] for o in vals]) for k in ('embedding','coarse_logits','fine_logits')}
    def clean(self,raw):
        h=raw['embedding'].mean(0)
        if len(self.states)==1:return dict(embedding=h,coarse_logits=raw['coarse_logits'][0],fine_logits=raw['fine_logits'][0])
        return dict(embedding=h,**{k:np.log(np.maximum(softmax(raw[k],axis=2).mean(0),1e-300)) for k in ('coarse_logits','fine_logits')})
    def fit(self,raw,fit):self.stat=[basis(h[fit]) for h in raw['embedding']];return self.stat
    def score(self,raw):
        assert self.stat is not None
        out=self.clean(raw);rf=[];rc=[];fp=[];cp=[];beta=[];res=[]
        for j,b in enumerate(self.stat):
            z,r=leverage(raw['embedding'][j],b);f,p=pnml(raw['fine_logits'][j],z);c,q=pnml(raw['coarse_logits'][j],z)
            rf.append(f);rc.append(c);fp.append(p);cp.append(q);beta.append(z);res.append(r)
        out.update(fine_logits=np.log(np.maximum(np.mean(fp,0),1e-300)),coarse_logits=np.log(np.maximum(np.mean(cp,0),1e-300)))
        sc=dict(regret_fine=np.mean(rf,0),regret_coarse=np.mean(rc,0),leverage=np.mean(beta,0),predicted_coarse=out['coarse_logits'].argmax(1))
        return out,sc,dict(beta=np.stack(beta),null_residual=np.stack(res))

def fixtures():
    rng=np.random.default_rng(111);x=rng.normal(size=(80,6));h=rng.normal(size=(9,6));b=basis(x);beta,res=leverage(h,b);xu=unit(x);hu=unit(h);inv=np.linalg.inv(xu.T@xu);q=np.einsum('nd,dk,nk->n',hu,inv,hu);assert np.allclose(beta,q/(1+q),rtol=1e-12,atol=1e-14)
    logits=rng.normal(size=(9,4));p=softmax(logits,1);g=p/(p+p**beta[:,None]*(1-p));r,pr=pnml(logits,beta);assert np.allclose(r,np.log(g.sum(1)),atol=1e-14) and np.allclose(pr,g/g.sum(1)[:,None],atol=1e-14)
    rz,pz=pnml(logits,np.zeros(9));assert np.allclose(rz,0,atol=1e-14) and np.allclose(pz,p,atol=1e-14)
    for k in range(len(h)):
        direct=float(hu[k]@np.linalg.inv(xu.T@xu+np.outer(hu[k],hu[k]))@hu[k]);assert abs(direct-beta[k])<1e-12
    xx=np.column_stack((x,np.zeros(len(x))));bb=basis(xx);z=np.zeros((1,7));z[0,-1]=1;assert leverage(z,bb)[0][0]==1
    for v in pnml(np.array([[1000.,-1000.],[-1000.,1000.]]),np.array([.1,1.])):assert np.isfinite(v).all()
    return dict(literal_Eq17_20=True,Sherman_Morrison_Eq12=True,rank_deficient_null_case=True,zero_leverage_no_probability_change=True,extreme_logits_finite=True,L2_normalization_section4_2=True)
