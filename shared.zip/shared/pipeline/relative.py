"""Known-source local affinity contrast; no query labels or synthetic witnesses."""
from io34 import *
import affinity as Pair
from sklearn.neighbors import NearestNeighbors
def fit_references(s,fields,model):
    weights=Pair.weights(s['x'].shape[1],fields);refs=s['fit'];logs=np.full(len(s['ids']),np.nan);neighbors=np.full((len(s['ids']),7),-1,int);p=np.full((len(s['ids']),7),np.nan)
    for fine in range(9):
        rr=refs[s['fine'][refs]==fine]
        if len(rr)<8:continue
        near=NearestNeighbors(n_neighbors=8,algorithm='brute',n_jobs=1).fit(s['x'][rr]*weights).kneighbors(s['x'][rr]*weights,return_distance=False)
        right=np.array([[j for j in rr[row] if j!=query][:7] for query,row in zip(rr,near)]);left=np.repeat(rr,7)
        prob=model.predict_proba(Pair.features(s['x'][left],s['z'][left],s['x'][right.reshape(-1)],s['z'][right.reshape(-1)],fields))[:,1].reshape(-1,7)
        assert (prob>0).all() and (prob<=1).all();logs[rr]=np.log(prob).mean(1);neighbors[rr]=right;p[rr]=prob
    return dict(reference_log_affinity=logs,source_native_neighbors=neighbors,source_neighbor_affinity=p)
def score(x,z,s,fields,model,reference):
    weights=Pair.weights(s['x'].shape[1],fields);fine=np.full((len(x),9),np.inf);near_all=np.full((len(x),9,7),-1,int);prob_all=np.full((len(x),9,7),np.nan)
    for c in range(9):
        rr=s['fit'][s['fine'][s['fit']]==c]
        if len(rr)<8:continue
        near=NearestNeighbors(n_neighbors=7,algorithm='brute',n_jobs=1).fit(s['x'][rr]*weights).kneighbors(x*weights,return_distance=False);right=rr[near];left=np.repeat(np.arange(len(x)),7)
        prob=model.predict_proba(Pair.features(x[left],z[left],s['x'][right.reshape(-1)],s['z'][right.reshape(-1)],fields))[:,1].reshape(-1,7)
        assert (prob>0).all() and (prob<=1).all()
        fine[:,c]=(reference['reference_log_affinity'][right]-np.log(prob)).mean(1);near_all[:,c]=right;prob_all[:,c]=prob
    coarse=np.column_stack((fine[:,0],fine[:,1:].min(1)));assert np.isfinite(coarse).all()
    return dict(fine_score=fine,coarse_score=coarse,source_neighbors=near_all,query_source_affinity=prob_all)
def finite(v):
    a=np.sort(v);rank=(99*(len(a)+1)+99)//100;assert 0<rank<=len(a) and np.isfinite(a).all()
    return dict(parents=len(a),rank=rank,cut=float(a[rank-1]))
def calibrate(sc,y,ix,qa,sy):
    cuts=[];classes=[];margins=[]
    for c in (0,1):
        cal=finite(sc[ix[y[ix]==c],c]);src=finite(qa[sy==c,c]);cuts.append(max(cal['cut'],src['cut']));classes.append(dict(coarse=c,CAL=cal,sourceQA=src))
        opposite=np.vstack((sc[ix[y[ix]!=c]],qa[sy!=c]));margins.append(float((opposite[:,1-c]-opposite[:,c]).max()))
    return dict(cuts=cuts,classes=classes,known_margin_limits=margins,rule='Per genuine truecoarse parent finite99; use stricter sourceQA/CAL cut. Known-label switch exceeds ALL opposite-known sourceQA/CAL margins, and singleton class acceptance.')
def actions(q,sc,cuts):
    score=sc['coarse_score'];accepted=score<=np.array(cuts['cuts'])[None,:];raw=(q['parent']<2)&~accepted.any(1)&~q['veto'];dest=score.argmin(1).astype(np.int8)
    cross=(q['parent']<2)&(dest!=q['parent'])&accepted[np.arange(len(dest)),dest]&~accepted[np.arange(len(dest)),1-dest]
    margin=score[np.arange(len(dest)),1-dest]-score[np.arange(len(dest)),dest];cross&=margin>np.array(cuts['known_margin_limits'])[dest]
    assert not np.any(cross&raw)
    return dict(raw=raw,cross=cross,destination=dest,margin=margin,accepted_classes=accepted)
