from io34 import *
import latest_model as L
import warm_base as W
import calibration_objective as CAL
import torch,time
from torch.nn import functional as F
from scipy.special import softmax
KINDS=('matched_ce','rdrop');EPOCHS=8;SEED=202611108
source_path=L.source_path;restore=L.restore;infer=L.infer;split_source=L.split_source;reference=W.reference;scores=W.scores;calibrate=W.calibrate
def core(net,s):return net.backbone.core if s=='CIC2' else net
def validation(net,x,s,setting):return CAL.validation(net,x,s) if setting=='NSL1' else W.validation(net,x,s)
def symmetric_kl(a,b):
    la=F.log_softmax(a,1);lb=F.log_softmax(b,1);return .5*((la.exp()*(la-lb)).sum(1)+(lb.exp()*(lb-la)).sum(1))
def train(setting,A,s,x,kind,folder,check):
    t=time.perf_counter();net,owner=restore(setting,A);fields=[np.flatnonzero(v.detach().numpy()).tolist() for v in core(net,setting).field_column_membership];fit=s['fit'];rows=list(fit)
    for f in np.unique(s['fine'][fit]):
        at=fit[s['fine'][fit]==f]
        if len(at)<20:rows.extend(np.resize(at,20-len(at)).tolist())
    rows=np.asarray(rows,int);assert len(rows)<=6000 and not set(rows)&set(s['original_qa']);multi=np.bincount(rows,minlength=len(x));cw=torch.tensor(len(rows)/(2*np.bincount((s['fine'][rows]>0).astype(int),minlength=2)),dtype=torch.float32);fw=torch.tensor(len(rows)/(9*np.bincount(s['fine'][rows],minlength=9)),dtype=torch.float32);scale=np.ones(x.shape[1])
    for cols in fields:
        if len(cols)==1:
            rms=float(np.sqrt(np.mean(x[fit,cols[0]].astype(float)**2)));scale[cols]=rms if rms>0 else 1.
    scale=torch.tensor(scale,dtype=torch.float32);parameters=[p for p in net.parameters() if p.requires_grad];opt=torch.optim.AdamW(parameters,lr=3e-4,weight_decay=2e-4);schedule=torch.optim.lr_scheduler.CosineAnnealingLR(opt,EPOCHS,eta_min=3e-5);rng=np.random.default_rng(SEED);bestkey,bestreport=validation(net,x,s,setting);best={k:v.detach().clone() for k,v in net.state_dict().items()};bestep=0;orders=[];masks=[];history=[];bn=[m for m in net.modules() if isinstance(m,torch.nn.modules.batchnorm._BatchNorm)]
    for ep in range(EPOCHS):
        net.train();order=rng.permutation(rows);field=np.arange(len(order))%len(fields);rng.shuffle(field);orders.append(order);masks.append(field);totals=np.zeros(5)
        for step,start in enumerate(range(0,len(order),128)):
            check();at=order[start:start+128];bx=torch.tensor(x[at]);y=torch.tensor(s['fine'][at],dtype=torch.long);cy=(y>0).long();mf=torch.tensor(field[start:start+len(at)],dtype=torch.long);pw=torch.tensor(1/multi[at],dtype=torch.float32);seed=SEED+ep*10000+step;torch.manual_seed(seed);a=net(bx);stats=[(m.running_mean.clone(),m.running_var.clone(),m.num_batches_tracked.clone(),m.momentum) for m in bn]
            for m in bn:m.momentum=0
            torch.manual_seed(seed+10000000);b=net(bx)
            for m,(mean,var,count,mom) in zip(bn,stats):
                assert mom is not None and torch.equal(m.running_mean,mean) and torch.equal(m.running_var,var);m.momentum=mom
            def cl(o):return W.weighted(o['coarse_logits'],cy,cw)+.35*W.weighted(o['fine_logits'],y,fw,0. if setting=='NSL1' else .01)
            classification=.5*(cl(a)+cl(b));row=symmetric_kl(a['coarse_logits'],b['coarse_logits'])+.35*symmetric_kl(a['fine_logits'],b['fine_logits']);consistency=(row*pw).sum()/pw.sum();torch.manual_seed(seed+20000000);masked=net.forward_masked(bx,mf);err=F.smooth_l1_loss(masked['reconstruction']/scale,bx/scale,reduction='none');rr=(err*masked['masked_columns']).sum(1)/masked['masked_columns'].sum(1);rec=(rr*pw).sum()/pw.sum();extra=torch.zeros(())
            if setting=='CIC2':
                dist=(a['embedding']-net.points[y]).square().mean(1);margin=(F.relu(dist-net.radius+1)*pw).sum()/pw.sum();extra=.35*(W.weighted(a['reciprocal_logits'],y,fw)+.1*margin)
            loss=classification+(consistency if kind=='rdrop' else 0)+.03*rec+extra;assert torch.isfinite(loss);opt.zero_grad(set_to_none=True);loss.backward();
            with torch.no_grad():
                for m in bn:m.num_batches_tracked.sub_(1)
            torch.nn.utils.clip_grad_norm_(parameters,5);opt.step();totals+=np.array([float(v.detach()) for v in (loss,classification,consistency,rec,extra)])*len(at)
        schedule.step();key,val=validation(net,x,s,setting)
        if key>bestkey:bestkey=key;bestreport=val;best={k:v.detach().clone() for k,v in net.state_dict().items()};bestep=ep+1
        history.append(dict(epoch=ep+1,losses=totals/len(order),validation=val,selected_epoch=bestep,seconds=time.perf_counter()-t));print('RDROP_TRAIN',setting,kind,history[-1],flush=True)
    net.load_state_dict(best);out=infer(net,x)
    with (folder/'model.pt').open('xb') as f:torch.save(dict(state=net.state_dict(),kind=kind,selected_epoch=bestep,seed=SEED),f)
    save(folder/'source_outputs.npz',ids=s['ids'],**out);save(folder/'training_parents.npz',ids=s['ids'],FIT=fit,VALID=s['validation'],QA=s['qa'],original_QA=s['original_qa'],anchors=np.stack(orders),masked_fields=np.stack(masks),field_count=np.array(len(fields)));put(folder/'TRAINING.json',dict(kind=kind,selected_epoch=bestep,selected_validation=bestreport,history=history,seconds=time.perf_counter()-t,source_parent=owner['model'],warm_function_equivalent_to_full_parent=owner['warm_start_function_equivalent_to_parent'],new_neural_training_epochs=EPOCHS,KL_coefficient=1. if kind=='rdrop' else 0.,optimizer_slots=len(rows),genuine_FIT=len(fit),second_clean_BN_stats_not_double_counted=True,**STATUS));return net,out,owner
def load_model(setting,A,kind,folder):
    net,o=restore(setting,A);v=torch.load(folder/'model.pt',map_location='cpu',weights_only=False);assert v['kind']==kind;net.load_state_dict(v['state'],strict=True);return net.eval(),o
def audit_parents(folder,s):
    v=load(folder/'training_parents.npz');assert np.array_equal(v['ids'],s['ids']);assert set(v['anchors'].ravel())<=set(s['fit']) and not set(v['anchors'].ravel())&set(s['original_qa']);put(folder/'PARENT_AUDIT.json',dict(no_VALID_QA_or_query_parents=True,all_actual_FIT_parents=True,noise_masks_not_new_traffic=True,**STATUS))
def fixtures():
    a=torch.tensor([[1.,2.,3.],[-1.,.2,.8]],dtype=torch.float64,requires_grad=True);b=torch.tensor([[.1,3.,1.],[1.,.5,-.1]],dtype=torch.float64,requires_grad=True);p=a.softmax(1);q=b.softmax(1);expected=.5*((p*(p.log()-q.log())).sum(1)+(q*(q.log()-p.log())).sum(1));assert torch.allclose(symmetric_kl(a,b),expected,rtol=1e-13,atol=1e-13);assert torch.equal(symmetric_kl(a,a),torch.zeros(2,dtype=torch.float64));symmetric_kl(a,b).sum().backward();assert torch.isfinite(a.grad).all() and torch.isfinite(b.grad).all();return dict(symmetric_KL_literal=True,identical_KL_zero=True,both_views_receive_gradients=True)
