"""NeurIPS2022 continuous PLE inside the existing MHFD token path."""
from io34 import *
import torch,types,time
from torch.nn import functional as F
from sklearn.tree import DecisionTreeClassifier
from scipy.special import logsumexp
import paper_methods as P
KINDS=('ce','quantile_PLE','known_tree_PLE')
METHODS=('msp','energy','fdbd')
SEED=20261147
EPOCHS=30
PRIOR=I/'normalization_losses_20261102_r47'

def bins(x,fit,y,kind):
    edges=[];n=x.shape[1]
    for j in range(n):
        v=x[fit,j].astype(float);u=np.unique(v)
        if len(u)<=2:edges.append(None);continue
        if kind=='quantile_PLE':b=np.unique(np.quantile(v,np.linspace(0,1,17)))
        else:
            tree=DecisionTreeClassifier(max_leaf_nodes=16,min_samples_leaf=8,random_state=SEED);tree.fit(v[:,None],y[fit]);threshold=tree.tree_.threshold[tree.tree_.children_left!=-1];b=np.unique(np.r_[u[0],threshold,u[-1]])
        assert len(b)>=2 and np.all(np.diff(b)>0);edges.append(b)
    low=np.zeros((n,16));width=np.ones((n,16));valid=np.zeros((n,16),bool);first=valid.copy();last=valid.copy()
    for j,b in enumerate(edges):
        if b is None:continue
        m=len(b)-1;low[j,:m]=b[:-1];width[j,:m]=np.diff(b);valid[j,:m]=True;first[j,0]=True;last[j,m-1]=True
    return dict(low=low.astype(np.float32),width=width.astype(np.float32),valid=valid,first=first,last=last)

def encode(x,state):
    ratio=(x[:,:,None]-state['low'][None])/state['width'][None]
    # Only interior sides clip: retain unbounded tails required by paper Eq1.
    low=torch.where(state['first'][None],ratio,ratio.clamp_min(0))
    result=torch.where(state['last'][None],low,low.clamp_max(1))
    return result*state['valid'][None]

class PLE(torch.nn.Module):
    def __init__(self,state,width):
        super().__init__()
        for k,v in state.items():self.register_buffer(k,torch.from_numpy(v))
        self.delta=torch.nn.Parameter(torch.zeros((*state['low'].shape,width)))
    def forward(self,x):
        z=encode(x,{k:getattr(self,k) for k in ('low','width','valid','first','last')});return torch.einsum('bfk,fkh->bfh',z,self.delta)

def install(net,state):
    net.add_module('num_embedding',PLE(state,net.feature_weight.shape[1]))
    def forward(self,x):
        tokens=x[...,None]*self.feature_weight[None]+self.feature_bias[None]+self.position[None]+self.num_embedding(x)
        v,_=self.attention(tokens,tokens,tokens,need_weights=False);u=self.attention_norm(tokens+self.dropout(v)*self.gate(v));cnn=self.conv(u.transpose(1,2)).transpose(1,2);seq,_=self.sequence(cnn);weights=torch.softmax(self.pool_score(seq).squeeze(-1),1);h=self.embedding((seq*weights[...,None]).sum(1))
        return dict(embedding=h,fine_logits=self.fine_head(h),coarse_logits=self.coarse_head(h))
    net.forward=types.MethodType(forward,net);return net

def restore(setting,A):return P.restore(setting,A)

@torch.no_grad()
def infer(net,x,batch=128):
    net.eval();values={k:[] for k in ('embedding','fine_logits','coarse_logits')}
    for start in range(0,len(x),batch):
        v=net(torch.from_numpy(x[start:start+batch]))
        for k in values:values[k].append(v[k].numpy().astype(float))
    return {k:np.concatenate(v) for k,v in values.items()}

def load_model(setting,A,kind,folder):
    net,owner=restore(setting,A);saved=torch.load(folder/'model.pt',map_location='cpu',weights_only=False)
    if kind!='ce':install(net,load(folder/'bins.npz'))
    net.load_state_dict(saved['core'],strict=True);net.eval();return net,owner

def train(setting,A,s,x,kind,folder,check):
    t=time.perf_counter();net,owner=restore(setting,A);torch.manual_seed(SEED);rng=np.random.default_rng(SEED);initial=infer(net,x[:128]);state=bins(x,s['fit'],s['fine'],kind);save(folder/'bins.npz',**state);install(net,state);same=infer(net,x[:128]);assert all(np.array_equal(initial[k],same[k]) for k in same),'ZERO_RESIDUAL_INITIAL_FUNCTION_PARITY'
    rows=list(s['fit'])
    for c in np.unique(s['fine'][s['fit']]):
        at=s['fit'][s['fine'][s['fit']]==c]
        if len(at)<20:rows.extend(np.resize(at,20-len(at)).tolist())
    rows=np.asarray(rows,int);assert len(rows)<=6000 and set(rows)<=set(s['fit']) and not set(rows)&set(s['qa']);count=np.bincount(s['fine'][rows],minlength=9);cw=torch.tensor(len(rows)/(9*count),dtype=torch.float32)
    parameters=[p for n,p in net.named_parameters() if p.requires_grad and not any(v in n for v in ('decoder','variance_head','coarse_head'))]
    opt=torch.optim.AdamW(parameters,lr=3e-4,weight_decay=2e-4);schedule=torch.optim.lr_scheduler.CosineAnnealingLR(opt,EPOCHS,eta_min=3e-5);history=[]
    for epoch in range(EPOCHS):
        net.train();order=rng.permutation(rows);total=0.
        for start in range(0,len(order),128):
            check();at=order[start:start+128];y=torch.tensor(s['fine'][at],dtype=torch.long);o=net(torch.from_numpy(x[at]));loss=(F.cross_entropy(o['fine_logits'],y,reduction='none')*cw[y]).sum()/cw[y].sum();assert torch.isfinite(loss)
            opt.zero_grad(set_to_none=True);loss.backward();norm=torch.nn.utils.clip_grad_norm_(parameters,5.);assert torch.isfinite(norm);opt.step();total+=float(loss.detach())*len(at)
        schedule.step();history.append(dict(epoch=epoch+1,loss=total/len(rows),seconds=time.perf_counter()-t));print('PLE_TRAIN',setting,kind,history[-1],flush=True)
    out=infer(net,x);assert net.num_embedding.delta.detach().abs().sum()>0
    with (folder/'model.pt').open('xb') as f:torch.save(dict(core=net.state_dict(),kind=kind,epochs=EPOCHS,seed=SEED),f)
    save(folder/'source_outputs.npz',ids=s['ids'],**out);save(folder/'optimizer_parent_map.npz',ids=s['ids'],FIT=s['fit'],QA=s['qa'],optimizer_indices=rows)
    return net,out,dict(method=kind,epochs=EPOCHS,history=history,seconds=time.perf_counter()-t,optimizer_slots=len(rows),source_FIT_parents=len(s['fit']),slot_counts=count,source_parent=owner['model'],initial_function_exact_parity=True,feature_bin_counts=state['valid'].sum(1),binary_and_constant_passthrough=True,bin_fit_genuine_FIT_only=True,no_OOD_training=True,extra_params=int(net.num_embedding.delta.numel()))

def scores(o,state):
    l=o['fine_logits'];h=o['embedding'];k=l.argmax(1);prob=np.exp(l-logsumexp(l,axis=1)[:,None]);norm=np.linalg.norm(h-state['FIT_mean'],axis=1);assert np.all(norm>0);distance=(l[np.arange(len(l)),k,None]-l)/state['pair_weight_distance'][k]
    return dict(msp=1-prob.max(1),energy=-logsumexp(l,axis=1),fdbd=-distance.sum(1)/8/norm,predicted_coarse=(k>0).astype(int),fine_probability=prob)
def calibrate(cal,y,ix,qa,sy):
    old=P.METHODS
    try:P.METHODS=METHODS;return P.calibrate(cal,y,ix,qa,sy)
    finally:P.METHODS=old
def fixtures():
    x=np.array([[-2.],[0.],[1.],[3.],[4.],[7.]],np.float32);b=dict(low=np.array([[0.,1.,3.]],np.float32),width=np.array([[1.,2.,1.]],np.float32),valid=np.ones((1,3),bool),first=np.array([[1,0,0]],bool),last=np.array([[0,0,1]],bool));s={k:torch.tensor(v) for k,v in b.items()};z=encode(torch.tensor(x),s).numpy();expected=np.array([[-2,0,0],[0,0,0],[1,0,0],[1,1,0],[1,1,1],[1,1,4]],np.float32)[:,None];assert np.array_equal(z,expected);assert np.array_equal((z*b['width']).sum(2)+b['low'][:,:1].T,x)
    return dict(Eq1_knots_and_both_unbounded_tails=True,continuous_scalar_exact_reconstruction=True,no_discrete_quantization=True)
