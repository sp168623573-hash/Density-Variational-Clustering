"""Source-only service-conditioned evidence for the existing MHFD latent.

The protocol/service/flag partition is fixed, not selected using query labels.
No DVC geometry or threshold changes. Exactly seven distinct FIT references.
"""
from io34 import *
import gradient_model as Parent
from scipy.spatial.distance import cdist
from scipy.special import logsumexp,softmax
from sklearn.covariance import OAS
BIND=Parent.BIND
METHODS=('native7','latent7','joint7','local_mahalanobis','fine_uncertainty')

def metadata(setting,A,x):
    if setting=='NSL1':
        enc=read(ROOT/'data/external_dev/processed/nsl1_expanded_FIT6000_all41_20261009_v1/material/new_unique_FIT6000_all41_encoder_before_training.json');groups=[(enc['original_field_groups'][k]['selected_columns'],enc['categorical_vocabularies'][str(k)]) for k in (1,2,3)]
    else:
        enc=read(A.C.Adapter.manifest()['encoding']['path']);fm={v['name']:v['columns'] for v in read(A.C.Clean.O/'INPUT_MANIFEST.json')['field_groups']};groups=[(fm[k],enc['vocabulary'][k]) for k in ('protocol_type','service','flag')]
    rows=[]
    for row in x:
        val=[]
        for cols,vocab in groups:
            a=row[cols];assert np.isclose(a.sum(),1);j=int(a.argmax());val.append(vocab[j] if j<len(vocab) else '<UNSEEN>')
        rows.append('|'.join(val))
    numeric=np.asarray([i for i in range(x.shape[1]) if all(i not in cols for cols,_ in groups)],int)
    return np.asarray(rows),numeric

def coordinates(x,out,state,duration=None):
    native=x[:,state['numeric']].astype(float)/np.sqrt(len(state['numeric']));h=out['embedding']/state['latent_unit']
    if duration is not None:native=np.c_[native,np.log1p(duration)/state['duration_unit']]
    return native,h,np.c_[native,h]

def fit(x,out,fine,cells,numeric,ids,duration,check):
    state=dict(numeric=numeric,latent_unit=float(np.sqrt(np.mean(np.sum(out['embedding']**2,axis=1)))),duration_unit=float(max(1,np.sqrt(np.mean(np.log1p(duration)**2)))) if duration is not None else 1.,cells={},fine=fine,ids=ids)
    native,latent,joint=coordinates(x,out,state,duration)
    for cell in sorted(set(cells)):
        at=np.flatnonzero(cells==cell)
        if len(at)<8:continue
        check();banks=dict(native7=native[at],latent7=latent[at],joint7=joint[at]);radius={}
        for name,bank in banks.items():
            d=cdist(bank,bank);np.fill_diagonal(d,np.inf);radius[name]=np.partition(d,6,axis=1)[:,6]
        cov=OAS().fit(joint[at]);state['cells'][str(cell)]=dict(indices=at,banks=banks,radius=radius,mean=cov.location_,precision=cov.precision_,shrinkage=float(cov.shrinkage_))
    assert len(state['cells'])>0;return state

def score(x,out,cells,state,duration,available,check):
    native,latent,joint=coordinates(x,out,state,None if duration is None else np.where(available,duration,0));coords=dict(native7=native,latent7=latent,joint7=joint);n=len(x);sc={k:np.zeros(n) for k in METHODS};app=np.zeros(n,bool);certificate=np.zeros(n,bool);support=np.zeros(n);local_indices=np.full((n,7),-1,int)
    margin=out['fine_logits'][:,0]-logsumexp(out['fine_logits'][:,1:],axis=1);confidence=1-softmax(out['fine_logits'],axis=1).max(1);pred=out['coarse_logits'].argmax(1);fp=out['fine_logits'].argmax(1)
    for cell in sorted(set(cells)):
        if str(cell) not in state['cells']:continue
        c=state['cells'][str(cell)];query=np.flatnonzero((cells==cell)&available);app[query]=True;accepted=np.ones(len(query),bool)
        for name,bank in c['banks'].items():
            for start in range(0,len(query),256):
                check();at=query[start:start+256];d=cdist(coords[name][at],bank);nn=np.argsort(d,axis=1,kind='stable')[:,:7];dd=np.take_along_axis(d,nn,1);sc[name][at]=dd[:,-1]
                if name in ('native7','joint7'):
                    pure=np.asarray([np.all(state['fine'][c['indices'][d[j]<=dd[j,-1]]]==0) for j in range(len(at))]);mutual=np.all(dd<=c['radius'][name][nn],axis=1);accepted[start:start+len(at)]&=pure&mutual
                if name=='joint7':local_indices[at]=c['indices'][nn]
        z=joint[query]-c['mean'];sc['local_mahalanobis'][query]=np.maximum(np.einsum('nd,dk,nk->n',z,c['precision'],z,optimize=False),0);sc['fine_uncertainty'][query]=confidence[query];certificate[query]=accepted&(pred[query]==0)&(fp[query]==0);support[query]=np.where(certificate[query],margin[query],0)
    return sc,dict(applicable=app,certificate=certificate,support=support,margin=margin,neighbors=local_indices,cells=cells)

def quantile99(a):
    a=np.asarray(a,float);n=len(a);assert n>=99;rank=(99*(n+1)+99)//100;return float(np.sort(a)[min(rank,n)-1])

def calibrate(qc,qcd,qcy,audit,ad,ay,old,od,oy,cal,cd,cy,ix):
    cuts={};proof={};qualification={};knowncuts={}
    for cell in sorted(set(qcd['cells'])):
        cq=(qcd['cells']==cell)&qcd['applicable'];aq=(ad['cells']==cell)&ad['applicable'];oldq=(od['cells']==cell)&od['applicable'];at=ix[(cd['cells'][ix]==cell)&cd['applicable'][ix]]
        if cq.sum()<99 or aq.sum()<99:continue
        cuts[str(cell)]={}
        for name in METHODS:
            cut=max(quantile99(qc[name][cq]),float(old[name][oldq].max(initial=0)),float(cal[name][at].max(initial=0)));cuts[str(cell)][name]=cut
            ok=[]
            for coarse in (0,1):
                mask=aq&((ay>0)==coarse);n=int(mask.sum());loss=int(np.sum(audit[name][mask]>cut));ok.append(dict(coarse=coarse,rows=n,false_unknown=loss,within_integer99=(n-loss)*100>=99*n))
            qualification[(str(cell),name)]=all(r['within_integer99'] for r in ok);proof[(str(cell),name)]=ok
        false=np.r_[qcd['margin'][cq&(qcy>0)],od['margin'][oldq&(oy>0)],cd['margin'][at[cy[at]>0]]];knowncuts[str(cell)]=float(max(0,false.max(initial=0)))
    qualified=[]
    for cell,cut in knowncuts.items():
        cert=(ad['cells']==cell)&ad['certificate']&(ad['support']>cut)
        for name in METHODS:cert&=audit[name]<=cuts[cell][name]
        pos=int(np.sum(cert&(ay==0)));neg=int(np.sum(cert&(ay>0)));qualified.append(dict(cell=cell,correct=pos,wrong=neg,qualified=pos>=20 and neg==0))
    return dict(cuts=cuts,novelty_qualified=[dict(cell=c,method=m,qualified=v,audit=proof[c,m]) for (c,m),v in qualification.items()],known_cuts=knowncuts,known_qualified=qualified)

def decisions(sc,det,state):
    novel={m:np.zeros(len(det['applicable']),bool) for m in METHODS};known=np.zeros(len(det['applicable']),bool)
    qualified={(v['cell'],v['method']):v['qualified'] for v in state['novelty_qualified']}
    for cell,cut in state['cuts'].items():
        at=(det['cells']==cell)&det['applicable']
        for name in METHODS:
            if qualified[cell,name]:novel[name][at]=sc[name][at]>cut[name]
    for p in state['known_qualified']:
        if not p['qualified']:continue
        cell=p['cell'];at=(det['cells']==cell)&det['certificate']&(det['support']>state['known_cuts'][cell])
        for name in METHODS:at&=sc[name]<=state['cuts'][cell][name]
        known|=at
    return novel,known
