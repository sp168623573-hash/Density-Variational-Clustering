from io34 import *
import normalization_model as N
import torch,time
from torch.nn import functional as F
from scipy.special import logsumexp
KINDS=('group_ERM','group_DRO');METHODS=N.METHODS;EPOCHS=40;SEED=20261182
split_source=N.split_source;restore=N.restore;infer=N.infer;reference=N.reference;scores=N.scores;calibrate=N.calibrate
def make_groups(net,x,s):
    names=list(net.field_map.names);cols=[j for j,n in enumerate(names) if n.startswith('protocol_type_') or n.startswith('flag_')];assert len(cols)>=5
    for prefix in ('protocol_type_','flag_'):
        part=[j for j,n in enumerate(names) if n.startswith(prefix)];assert any(np.array_equal(np.flatnonzero(row.detach().numpy()),part) for row in net.field_column_membership)
    keys0=['BEN:'+np.ascontiguousarray(x[j,cols]).tobytes().hex() if s['fine'][j]==0 else 'KNA:'+str(int(s['fine'][j])) for j in range(len(x))];vocab=sorted({keys0[j] for j in s['fit']});mapping={v:j for j,v in enumerate(vocab)};g=np.array([mapping.get(k,-1) for k in keys0]);count=np.bincount(g[s['fit']],minlength=len(vocab));ben=np.array([k.startswith('BEN:') for k in vocab]);mass=np.zeros(len(vocab));mass[ben]=.5/ben.sum();mass[~ben]=.5/(~ben).sum();assert (count>0).all() and np.isclose(mass.sum(),1)
    return dict(group=g,count=count,initial_mass=mass,group_is_BEN=ben,columns=np.asarray(cols),vocab=np.asarray(vocab))
def row_loss(out,fine):
    c=(fine>0).astype(int);l=out['coarse_logits'];f=out['fine_logits'];lc=logsumexp(l,1)-l[np.arange(len(fine)),c];lp=f-logsumexp(f,1)[:,None];lf=-(.99*lp[np.arange(len(fine)),fine]+.01*lp.mean(1));return lc+.35*lf
def validate(net,x,s,groups):
    at=s['validation'];o=infer(net,x[at]);y=(s['fine'][at]>0).astype(int);p=o['coarse_logits'].argmax(1);recall=[float(np.mean(p[y==c]==c)) for c in (0,1)];loss=row_loss(o,s['fine'][at]);g=groups['group'][at];bucket=g.copy()
    for k in np.unique(g):
        if k<0 or np.sum(g==k)<8:bucket[g==k]=-1
    losses=[float(loss[bucket==k].mean()) for k in np.unique(bucket)];worst=max(losses);ce=float(np.mean(logsumexp(o['coarse_logits'],1)-o['coarse_logits'][np.arange(len(y)),y]));return (min(recall),sum(recall)/2,-worst,-ce),dict(coarse_recall=recall,coarse_correct=int(np.sum(p==y)),fine_correct=int(np.sum(o['fine_logits'].argmax(1)==s['fine'][at])),worst_group_validation_loss=worst,validation_groups=len(losses),coarse_CE=ce,rows=len(y))
def load_model(setting,A,kind,folder):
    net,owner=restore(setting,A);fields=[np.flatnonzero(r.detach().numpy()).tolist() for r in net.field_column_membership];N.install(net,fields,False,'post');net.load_state_dict(torch.load(folder/'model.pt',map_location='cpu',weights_only=False)['core'],strict=True);return net.eval(),owner
def train(setting,A,s,x,kind,folder,check):
    started=time.perf_counter();net,owner=restore(setting,A);fields=[np.flatnonzero(r.detach().numpy()).tolist() for r in net.field_column_membership];N.install(net,fields,False,'post');groups=make_groups(net,x,s);save(folder/'source_groups.npz',ids=s['ids'],**groups);fit=s['fit'];rows=list(fit)
    for f in np.unique(s['fine'][fit]):
        at=fit[s['fine'][fit]==f]
        if len(at)<20:rows.extend(np.resize(at,20-len(at)).tolist())
    rows=np.asarray(rows,int);assert len(rows)<=6000 and set(rows)<=set(fit) and not set(rows)&set(s['original_qa']);multiplicity=np.bincount(rows,minlength=len(x));scale=np.ones(x.shape[1])
    for cols in fields:
        if len(cols)==1:
            value=float(np.sqrt(np.mean(x[fit,cols[0]].astype(float)**2)));scale[cols]=value if value>0 else 1.
    scale=torch.tensor(scale,dtype=torch.float32);params=list(net.parameters());opt=torch.optim.AdamW(params,lr=3e-4,weight_decay=.01);scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(opt,EPOCHS,eta_min=3e-5);rng=np.random.default_rng(SEED);q=groups['initial_mass'].copy();bestkey,bestreport=validate(net,x,s,groups);best={k:v.detach().clone() for k,v in net.state_dict().items()};bestepoch=0;history=[];orders=[];masks=[];weights=[]
    for ep in range(EPOCHS):
        net.train();order=rng.permutation(rows);logical=np.arange(len(order))%len(fields);rng.shuffle(logical);orders.append(order);masks.append(logical);weights.append(q.copy());w=q[groups['group'][rows]]/(groups['count'][groups['group'][rows]]*multiplicity[rows]);assert np.isclose(w.sum(),1.);losses=np.zeros(3)
        for step,start in enumerate(range(0,len(order),128)):
            check();at=order[start:start+128];xx=torch.tensor(x[at]);y=torch.tensor(s['fine'][at],dtype=torch.long);cy=(y>0).long();which=torch.tensor(logical[start:start+len(at)]);torch.manual_seed(SEED+ep*10000+step);o=net(xx);masked=net.forward_masked(xx,which);row=F.cross_entropy(o['coarse_logits'],cy,reduction='none')+.35*F.cross_entropy(o['fine_logits'],y,label_smoothing=.01,reduction='none');rw=torch.tensor(q[groups['group'][at]]/(groups['count'][groups['group'][at]]*multiplicity[at]),dtype=torch.float32);classification=(row*rw).sum()*len(rows)/len(at);err=F.smooth_l1_loss(masked['reconstruction']/scale,xx/scale,reduction='none');rr=(err*masked['masked_columns']).sum(1)/masked['masked_columns'].sum(1);pw=torch.tensor(1/multiplicity[at],dtype=torch.float32);reconstruction=(rr*pw).sum()/pw.sum();loss=classification+.03*reconstruction;assert torch.isfinite(loss);opt.zero_grad(set_to_none=True);loss.backward();grad=torch.nn.utils.clip_grad_norm_(params,5.);assert torch.isfinite(grad);opt.step();losses+=np.array([float(v.detach()) for v in (loss,classification,reconstruction)])*len(at)
        scheduler.step();fo=infer(net,x[fit]);rl=row_loss(fo,s['fine'][fit]);group_loss=np.bincount(groups['group'][fit],weights=rl,minlength=len(q))/groups['count']
        if kind=='group_DRO':
            logq=np.log(q)+.01*group_loss;logq-=logsumexp(logq);q=np.exp(logq)
        key,valid=validate(net,x,s,groups)
        if key>bestkey:bestkey=key;bestreport=valid;best={k:v.detach().clone() for k,v in net.state_dict().items()};bestepoch=ep+1
        history.append(dict(epoch=ep+1,losses=losses/len(order),group_FIT_loss=group_loss,next_group_mass=q.copy(),validation=valid,selected_epoch=bestepoch,seconds=time.perf_counter()-started));print('GROUP_TRAIN',setting,kind,dict(epoch=ep+1,losses=losses/len(order),validation=valid,selected_epoch=bestepoch,seconds=time.perf_counter()-started),flush=True)
    net.load_state_dict(best,strict=True);out=infer(net,x)
    with (folder/'model.pt').open('xb') as f:torch.save(dict(core=net.state_dict(),kind=kind,selected_epoch=bestepoch,seed=SEED),f)
    save(folder/'source_outputs.npz',ids=s['ids'],**out);save(folder/'optimizer_parent_map.npz',ids=s['ids'],FIT=fit,original_QA=s['original_qa'],validation=s['validation'],QA_calibration=s['qa'],epoch_optimizer_indices=np.stack(orders),epoch_group_mass=np.stack(weights),masked_field=np.stack(masks));save(folder/'reconstruction_units.npz',scale=scale.numpy());put(folder/'TRAINING.json',dict(kind=kind,attempted_epochs=EPOCHS,selected_epoch=bestepoch,selected_validation=bestreport,history=history,source_groups=len(q),source_parent=owner['model'],genuine_FIT=len(fit),optimizer_slots=len(rows),only_BEN_KNA=True,seconds=time.perf_counter()-started,**STATUS));return net,out,owner
def fixtures():
    groups=np.array([0,0,1]);loss=np.array([1.,3.,5.]);q=np.array([.4,.6]);rows=np.array([0,1,2,2,2]);mult=np.bincount(rows,minlength=3);count=np.bincount(groups);w=q[groups[rows]]/(count[groups[rows]]*mult[rows]);assert np.isclose(w.sum(),1.) and np.isclose((w*loss[rows]).sum(),q@np.array([2.,5.]));updated=q*np.exp(.01*np.array([2.,5.]));updated/=updated.sum();assert updated[1]>q[1];return dict(copy_invariant_physical_group_mean_exact=True,harder_known_group_gets_more_mass=True,no_query_group_labels_used=True)
