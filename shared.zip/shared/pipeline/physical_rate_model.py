"""Source-known service-conditioned time/byte/process evidence."""

from io34 import *
import cell_model149 as C
from scipy.spatial.distance import cdist
from scipy.special import logsumexp
from sklearn.covariance import OAS

Parent = C.Parent
BIND = Parent.BIND
metadata = C.metadata
METHODS = ("process7", "relative7", "process_cov")
NAMES = (
    "duration",
    "src_bytes",
    "dst_bytes",
    "count",
    "srv_count",
    "dst_host_count",
    "dst_host_srv_count",
)


def log_values(setting, A, x, duration):
    if setting == "NSL1":
        enc = read(
            ROOT
            / "data/external_dev/processed/nsl1_expanded_FIT6000_all41_20261009_v1/material/new_unique_FIT6000_all41_encoder_before_training.json"
        )
        values = {}
        for n, i in enumerate(enc["numeric_indices"]):
            g = enc["original_field_groups"][i]
            values[g["field"]] = (
                x[:, g["selected_columns"][0]].astype(float)
                * enc["log_numeric_FIT_RMS"][n]
            )
    else:
        enc = read(A.C.Adapter.manifest()["encoding"]["path"])
        values = {
            name: x[:, j].astype(float) * enc["std"][j] + enc["mean"][j]
            for j, name in enumerate(enc["numeric"])
        }
        values["duration"] = np.log1p(duration)
    out = np.column_stack([values[k] for k in NAMES])
    assert np.isfinite(out).all() and out.min() > -2e-5
    return np.maximum(out, 0)


def physical(l, kind):
    t, s, d, c, sc, h, hs = l.T
    if kind == "volumes":
        return l
    assert kind == "rates"
    # Smooth log rates with a one-second or one-event offset.
    total = np.logaddexp(s, d) + np.log1p(-np.exp(-np.logaddexp(s, d)))
    return np.column_stack(
        (s - t, d - t, s - d, total - c, total - sc, sc - c, hs - h, total - h)
    )


def fit(l, out, fine, cells, ids, kind, check):
    z = physical(l, kind)
    state = dict(
        kind=kind,
        ids=ids,
        fine=fine,
        cells={},
        feature_names=(
            list(NAMES)
            if kind == "volumes"
            else [
                "log_src_over_time",
                "log_dst_over_time",
                "log_direction_ratio",
                "log_bytes_over_count",
                "log_bytes_over_srvcount",
                "log_srvcount_over_count",
                "log_hostsrv_over_host",
                "log_bytes_over_hostcount",
            ]
        ),
    )
    latent = out["embedding"]
    latent = latent / np.maximum(np.linalg.norm(latent, axis=1, keepdims=True), 1e-15)
    for cell in sorted(set(cells)):
        at = np.flatnonzero(cells == cell)
        ben = at[fine[at] == 0]
        if len(ben) < 20 or "<UNSEEN>" in cell:
            continue
        check()
        mu = np.median(z[ben], axis=0)
        scale = np.quantile(z[ben], 0.75, axis=0) - np.quantile(z[ben], 0.25, axis=0)
        scale = np.where(scale > 1e-6, scale, 1.0)
        bank = (z[at] - mu) / scale
        bb = bank[fine[at] == 0]
        bd = cdist(bb, bb)
        np.fill_diagonal(bd, np.inf)
        br = np.partition(bd, 6, axis=1)[:, 6]
        allr = cdist(bank, bank)
        np.fill_diagonal(allr, np.inf)
        ar = np.partition(allr, 6, axis=1)[:, 6]
        lat = latent[at]
        ld = cdist(lat, lat)
        np.fill_diagonal(ld, np.inf)
        lr = np.partition(ld, 6, axis=1)[:, 6]
        cov = OAS().fit(bb)
        state["cells"][str(cell)] = dict(
            indices=at,
            ben_indices=ben,
            mean=mu,
            scale=scale,
            bank=bank,
            BEN_bank=bb,
            BEN_radius=br,
            radius=ar,
            latent=lat,
            latent_radius=lr,
            cov_mean=cov.location_,
            precision=cov.precision_,
        )
    return state


def score(l, out, cells, available, state, check):
    z = physical(l, state["kind"])
    latent = out["embedding"]
    latent = latent / np.maximum(np.linalg.norm(latent, axis=1, keepdims=True), 1e-15)
    n = len(l)
    sc = {k: np.zeros(n) for k in METHODS}
    app = np.zeros(n, bool)
    certificate = np.zeros(n, bool)
    margin = out["fine_logits"][:, 0] - logsumexp(out["fine_logits"][:, 1:], axis=1)
    pred = np.where(
        (out["coarse_logits"].argmax(1) == 0) & (out["fine_logits"].argmax(1) == 0),
        0,
        1,
    )
    for cell in sorted(set(cells)):
        if cell not in state["cells"]:
            continue
        bank = state["cells"][str(cell)]
        rows = np.flatnonzero((cells == cell) & available)
        app[rows] = True
        for start in range(0, len(rows), 256):
            check()
            at = rows[start : start + 256]
            v = (z[at] - bank["mean"]) / bank["scale"]
            d = cdist(v, bank["BEN_bank"])
            nn = np.argsort(d, axis=1, kind="stable")[:, :7]
            dd = np.take_along_axis(d, nn, 1)
            sc["process7"][at] = dd[:, -1]
            sc["relative7"][at] = dd[:, -1] / np.maximum(
                bank["BEN_radius"][nn].mean(1), 1e-6
            )
            delta = v - bank["cov_mean"]
            sc["process_cov"][at] = np.maximum(
                np.einsum(
                    "nd,dk,nk->n", delta, bank["precision"], delta, optimize=False
                ),
                0,
            )
            pd = cdist(v, bank["bank"])
            ld = cdist(latent[at], bank["latent"])
            pn = np.argsort(pd, axis=1, kind="stable")[:, :7]
            ln = np.argsort(ld, axis=1, kind="stable")[:, :7]
            for j, row in enumerate(at):
                pure = np.all(
                    state["fine"][bank["indices"][pd[j] <= pd[j, pn[j, -1]]]] == 0
                ) and np.all(
                    state["fine"][bank["indices"][ld[j] <= ld[j, ln[j, -1]]]] == 0
                )
                mutual = (
                    np.sum(pd[j, pn[j]] <= bank["radius"][pn[j]]) >= 4
                    and np.sum(ld[j, ln[j]] <= bank["latent_radius"][ln[j]]) >= 4
                )
                certificate[row] = (
                    pred[row] == 0
                    and pure
                    and mutual
                    and len(set(pn[j]) & set(ln[j])) >= 4
                )
    assert all(np.isfinite(v).all() for v in sc.values())
    return sc, dict(
        applicable=app,
        cells=cells,
        predicted=pred,
        certificate=certificate,
        margin=margin,
    )


def finite(v):
    rank = (99 * (len(v) + 1) + 99) // 100
    assert len(v) >= 99 and rank <= len(v)
    return float(np.sort(v)[rank - 1])


def calibrate(qs, qd, qy, audit, ad, ay, old, od, oy, cal, cd, cy, ci):
    result = {}
    known = {}
    for cell in sorted(set(qd["cells"])):
        qb = (
            (qd["cells"] == cell)
            & qd["applicable"]
            & (qd["predicted"] == 0)
            & (qy == 0)
        )
        ab = (
            (ad["cells"] == cell)
            & ad["applicable"]
            & (ad["predicted"] == 0)
            & (ay == 0)
        )
        if qb.sum() < 99 or ab.sum() < 99:
            continue
        result[str(cell)] = {}
        oq = (od["cells"] == cell) & od["applicable"] & (od["predicted"] == 0)
        cc = ci[
            (cd["cells"][ci] == cell)
            & cd["applicable"][ci]
            & (cd["predicted"][ci] == 0)
        ]
        qk = (
            (qd["cells"] == cell) & qd["applicable"] & (qd["predicted"] == 0) & (qy > 0)
        )
        for method in METHODS:
            bound = max(
                finite(qs[method][qb]),
                float(old[method][oq].max(initial=0)),
                float(cal[method][cc].max(initial=0)),
                float(qs[method][qk].max(initial=0)),
            )
            bad = (
                (ad["cells"] == cell)
                & ad["applicable"]
                & (ad["predicted"] == 0)
                & (audit[method] > bound)
            )
            nb = int(np.sum(bad & (ay == 0)))
            nk = int(np.sum(bad & (ay > 0)))
            result[str(cell)][method] = dict(
                cut=bound,
                qualified=100 * (int(ab.sum()) - nb) >= 99 * int(ab.sum()) and nk == 0,
                QCAL_BEN=int(qb.sum()),
                QAUDIT_BEN=int(ab.sum()),
                QAUDIT_BEN_false=nb,
                QAUDIT_KNA_false=nk,
            )
        opposite = np.r_[
            qd["margin"][(qd["cells"] == cell) & qd["applicable"] & (qy > 0)],
            od["margin"][(od["cells"] == cell) & od["applicable"] & (oy > 0)],
            cd["margin"][cc[cy[cc] > 0]],
        ]
        cut = float(max(0, opposite.max(initial=0)))
        normal = np.ones(len(ay), bool)
        for method in METHODS:
            normal &= audit[method] <= result[str(cell)][method]["cut"]
        cert = (ad["cells"] == cell) & ad["certificate"] & normal & (ad["margin"] > cut)
        positive = int(np.sum(cert & (ay == 0)))
        negative = int(np.sum(cert & (ay > 0)))
        known[str(cell)] = dict(
            cut=cut,
            qualified=positive >= 20 and negative == 0,
            QAUDIT_BEN=positive,
            QAUDIT_KNA_wrong=negative,
        )
    return dict(cuts=result, known=known)


def decisions(scores, det, cal):
    raw = {k: np.zeros(len(det["applicable"]), bool) for k in METHODS}
    known = np.zeros(len(det["applicable"]), bool)
    for cell, values in cal["cuts"].items():
        at = (det["cells"] == cell) & det["applicable"] & (det["predicted"] == 0)
        normal = at.copy()
        for name, cfg in values.items():
            if cfg["qualified"]:
                raw[name] |= at & (scores[name] > cfg["cut"])
            normal &= scores[name] <= cfg["cut"]
        cfg = cal["known"][cell]
        if cfg["qualified"]:
            known |= normal & det["certificate"] & (det["margin"] > cfg["cut"])
    return raw, known


def fixtures():
    l = np.log1p(np.array([[9.0, 19.0, 29.0, 4.0, 2.0, 9.0, 4.0]]))
    r = physical(l, "rates")
    assert (
        np.isclose(r[0, 0], np.log(20 / 10))
        and np.isclose(r[0, 2], np.log(20 / 30))
        and np.isclose(r[0, 3], np.log(49 / 5))
    )
    return dict(
        smoothed_rate_formula_literal=True,
        no_raw_bytes_per_second_claim=True,
        zero_duration_finite=True,
        no_query_statistics_fit=True,
    )
